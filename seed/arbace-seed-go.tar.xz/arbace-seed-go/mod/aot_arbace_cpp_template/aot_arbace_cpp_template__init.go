//line aot_arbace_cpp_template__init.ae:1
package aot_arbace_cpp_template

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_cpp_template__init_A_Load__O() any { jrt.StartCheck(); A_arbace_cpp_template__init_part0_A_Init__O(); A_arbace_cpp_template__init_part1_A_Init__O(); A_arbace_cpp_template__init_part2_A_Init__O(); A_arbace_cpp_template__init_part0_A_Load__O(); A_arbace_cpp_template__init_part1_A_Load__O(); A_arbace_cpp_template__init_part2_A_Load__O(); return nil }











func A_arbace_cpp_template__init_part0_A_Unit0__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return lang.IFn_Cast(A_arbace_cpp_template__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_template__init_part0_A_const_1) }
//line :17:1
func A_arbace_cpp_template__init_part0_A_Unit1__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_cpp_template__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_2)) }
//line :17:1
func A_arbace_cpp_template__init_part0_A_Unit2__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_template_eval960000004_loading__1927001464__auto____960000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_template_eval960000004_loading__1927001464__auto____960000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_890, false, nil); A_arbace_cpp_template_eval960000004_loading__1927001464__auto____960000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :17:1
func A_arbace_cpp_template__init_part0_A_Unit3__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_cpp_template__init_part0_A_const_1)).Equals_O__Z(A_arbace_cpp_template__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_template_eval960000008_fn__960000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_template_eval960000008_fn__960000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_891, false, nil); A_arbace_cpp_template_eval960000008_fn__960000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :17:1
func A_arbace_cpp_template__init_part0_A_Init__O() any { A_arbace_cpp_template__init_part0_A_Init(); return nil }
//line :17:1
func A_arbace_cpp_template__init_part0_A_Load__O() any { A_arbace_cpp_template__init_part0_A_Init(); A_arbace_cpp_template__init_part0_A_Unit0__O(); A_arbace_cpp_template__init_part0_A_Unit1__O(); A_arbace_cpp_template__init_part0_A_Unit2__O(); A_arbace_cpp_template__init_part0_A_Unit3__O(); A_arbace_cpp_template__init_part0_A_Unit4__O(); A_arbace_cpp_template__init_part0_A_Unit5__O(); A_arbace_cpp_template__init_part0_A_Unit6__O(); A_arbace_cpp_template__init_part0_A_Unit7__O(); A_arbace_cpp_template__init_part0_A_Unit8__O(); A_arbace_cpp_template__init_part0_A_Unit9__O(); A_arbace_cpp_template__init_part0_A_Unit10__O(); A_arbace_cpp_template__init_part0_A_Unit11__O(); A_arbace_cpp_template__init_part0_A_Unit12__O(); A_arbace_cpp_template__init_part0_A_Unit13__O(); A_arbace_cpp_template__init_part0_A_Unit14__O(); A_arbace_cpp_template__init_part0_A_Unit15__O(); A_arbace_cpp_template__init_part0_A_Unit16__O(); A_arbace_cpp_template__init_part0_A_Unit17__O(); A_arbace_cpp_template__init_part0_A_Unit18__O(); A_arbace_cpp_template__init_part0_A_Unit19__O(); A_arbace_cpp_template__init_part0_A_Unit20__O(); A_arbace_cpp_template__init_part0_A_Unit21__O(); A_arbace_cpp_template__init_part0_A_Unit22__O(); A_arbace_cpp_template__init_part0_A_Unit23__O(); A_arbace_cpp_template__init_part0_A_Unit24__O(); A_arbace_cpp_template__init_part0_A_Unit25__O(); A_arbace_cpp_template__init_part0_A_Unit26__O(); A_arbace_cpp_template__init_part0_A_Unit27__O(); A_arbace_cpp_template__init_part0_A_Unit28__O(); A_arbace_cpp_template__init_part0_A_Unit29__O(); A_arbace_cpp_template__init_part0_A_Unit30__O(); A_arbace_cpp_template__init_part0_A_Unit31__O(); A_arbace_cpp_template__init_part0_A_Unit32__O(); A_arbace_cpp_template__init_part0_A_Unit33__O(); A_arbace_cpp_template__init_part0_A_Unit34__O(); A_arbace_cpp_template__init_part0_A_Unit35__O(); A_arbace_cpp_template__init_part0_A_Unit36__O(); A_arbace_cpp_template__init_part0_A_Unit37__O(); A_arbace_cpp_template__init_part0_A_Unit38__O(); A_arbace_cpp_template__init_part0_A_Unit39__O(); A_arbace_cpp_template__init_part0_A_Unit40__O(); A_arbace_cpp_template__init_part0_A_Unit41__O(); A_arbace_cpp_template__init_part0_A_Unit42__O(); A_arbace_cpp_template__init_part0_A_Unit43__O(); A_arbace_cpp_template__init_part0_A_Unit44__O(); A_arbace_cpp_template__init_part0_A_Unit45__O(); A_arbace_cpp_template__init_part0_A_Unit46__O(); A_arbace_cpp_template__init_part0_A_Unit47__O(); A_arbace_cpp_template__init_part0_A_Unit48__O(); A_arbace_cpp_template__init_part0_A_Unit49__O(); A_arbace_cpp_template__init_part0_A_Unit50__O(); A_arbace_cpp_template__init_part0_A_Unit51__O(); A_arbace_cpp_template__init_part0_A_Unit52__O(); A_arbace_cpp_template__init_part0_A_Unit53__O(); A_arbace_cpp_template__init_part0_A_Unit54__O(); A_arbace_cpp_template__init_part0_A_Unit55__O(); A_arbace_cpp_template__init_part0_A_Unit56__O(); A_arbace_cpp_template__init_part0_A_Unit57__O(); A_arbace_cpp_template__init_part0_A_Unit58__O(); A_arbace_cpp_template__init_part0_A_Unit59__O(); A_arbace_cpp_template__init_part0_A_Unit60__O(); A_arbace_cpp_template__init_part0_A_Unit61__O(); A_arbace_cpp_template__init_part0_A_Unit62__O(); A_arbace_cpp_template__init_part0_A_Unit63__O(); A_arbace_cpp_template__init_part0_A_Unit64__O(); A_arbace_cpp_template__init_part0_A_Unit65__O(); A_arbace_cpp_template__init_part0_A_Unit66__O(); A_arbace_cpp_template__init_part0_A_Unit67__O(); A_arbace_cpp_template__init_part0_A_Unit68__O(); A_arbace_cpp_template__init_part0_A_Unit69__O(); A_arbace_cpp_template__init_part0_A_Unit70__O(); A_arbace_cpp_template__init_part0_A_Unit71__O(); A_arbace_cpp_template__init_part0_A_Unit72__O(); A_arbace_cpp_template__init_part0_A_Unit73__O(); A_arbace_cpp_template__init_part0_A_Unit74__O(); A_arbace_cpp_template__init_part0_A_Unit75__O(); A_arbace_cpp_template__init_part0_A_Unit76__O(); A_arbace_cpp_template__init_part0_A_Unit77__O(); A_arbace_cpp_template__init_part0_A_Unit78__O(); A_arbace_cpp_template__init_part0_A_Unit79__O(); A_arbace_cpp_template__init_part0_A_Unit80__O(); A_arbace_cpp_template__init_part0_A_Unit81__O(); A_arbace_cpp_template__init_part0_A_Unit82__O(); A_arbace_cpp_template__init_part0_A_Unit83__O(); A_arbace_cpp_template__init_part0_A_Unit84__O(); A_arbace_cpp_template__init_part0_A_Unit85__O(); A_arbace_cpp_template__init_part0_A_Unit86__O(); A_arbace_cpp_template__init_part0_A_Unit87__O(); A_arbace_cpp_template__init_part0_A_Unit88__O(); A_arbace_cpp_template__init_part0_A_Unit89__O(); A_arbace_cpp_template__init_part0_A_Unit90__O(); A_arbace_cpp_template__init_part0_A_Unit91__O(); A_arbace_cpp_template__init_part0_A_Unit92__O(); A_arbace_cpp_template__init_part0_A_Unit93__O(); A_arbace_cpp_template__init_part0_A_Unit94__O(); A_arbace_cpp_template__init_part0_A_Unit95__O(); A_arbace_cpp_template__init_part0_A_Unit96__O(); A_arbace_cpp_template__init_part0_A_Unit97__O(); A_arbace_cpp_template__init_part0_A_Unit98__O(); A_arbace_cpp_template__init_part0_A_Unit99__O(); return nil }






















func A_arbace_cpp_template__init_part0_A_Unit4__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); return A_arbace_cpp_template__init_part0_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_cpp_template__init_part0_A_Unit5__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_5; tmp1.BindRoot_O__V(A_arbace_cpp_template__init_part0_A_const_6.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_cpp_template__init_part0_A_const_5; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_7)); return A_arbace_cpp_template__init_part0_A_const_5 }


func A_arbace_cpp_template__init_part0_A_Unit6__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_template_next_id_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_template_next_id_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_892, false, nil); A_arbace_cpp_template_next_id_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_9)); return A_arbace_cpp_template__init_part0_A_const_8 }
func A_arbace_cpp_template__init_part0_A_Unit7__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_10; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__8 any = A_arbace_cpp_template_new_scope_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_template_new_scope_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_893, true, nil); A_arbace_cpp_template_new_scope_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__8, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_11)); return A_arbace_cpp_template__init_part0_A_const_10 }
func A_arbace_cpp_template__init_part0_A_Unit8__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_template_enter_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_template_enter_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_894, false, nil); A_arbace_cpp_template_enter_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_13)); return A_arbace_cpp_template__init_part0_A_const_12 }
func A_arbace_cpp_template__init_part0_A_Unit9__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__12 any = A_arbace_cpp_template_upd_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_template_upd_fn_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_895, true, nil); A_arbace_cpp_template_upd_fn_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__12, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_15)); return A_arbace_cpp_template__init_part0_A_const_14 }
func A_arbace_cpp_template__init_part0_A_Unit10__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_16; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__14 any = A_arbace_cpp_template_upd_var_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_template_upd_var_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_896, true, nil); A_arbace_cpp_template_upd_var_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__14, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_17)); return A_arbace_cpp_template__init_part0_A_const_16 }
func A_arbace_cpp_template__init_part0_A_Unit11__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_template_kids_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_template_kids_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_897, false, nil); A_arbace_cpp_template_kids_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_19)); return A_arbace_cpp_template__init_part0_A_const_18 }
func A_arbace_cpp_template__init_part0_A_Unit12__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_template_node_text_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_template_node_text_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_898, false, nil); A_arbace_cpp_template_node_text_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_21)); return A_arbace_cpp_template__init_part0_A_const_20 }









func A_arbace_cpp_template__init_part0_A_Unit13__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); A_arbace_cpp_template__init_part0_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_23)); return A_arbace_cpp_template__init_part0_A_const_22.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_template__init_part0_A_Unit14__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); A_arbace_cpp_template__init_part0_A_const_24.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_25)); return A_arbace_cpp_template__init_part0_A_const_24.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_template__init_part0_A_Unit15__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_template_same_arg_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_template_same_arg_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_899, false, nil); A_arbace_cpp_template_same_arg_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_27)); return A_arbace_cpp_template__init_part0_A_const_26 }
func A_arbace_cpp_template__init_part0_A_Unit16__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); A_arbace_cpp_template__init_part0_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_29)); return A_arbace_cpp_template__init_part0_A_const_28.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_template__init_part0_A_Unit17__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); A_arbace_cpp_template__init_part0_A_const_30.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_31)); return A_arbace_cpp_template__init_part0_A_const_30.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_template__init_part0_A_Unit18__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_template_tmpl_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_template_tmpl_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_900, false, nil); A_arbace_cpp_template_tmpl_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_33)); return A_arbace_cpp_template__init_part0_A_const_32 }
func A_arbace_cpp_template__init_part0_A_Unit19__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_34; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__24 any = A_arbace_cpp_template_upd_tmpl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_template_upd_tmpl_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_901, true, nil); A_arbace_cpp_template_upd_tmpl_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__24, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_35)); return A_arbace_cpp_template__init_part0_A_const_34 }

func A_arbace_cpp_template__init_part0_A_Unit20__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_template_dependent_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_template_dependent_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_902, false, nil); A_arbace_cpp_template_dependent_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_37)); return A_arbace_cpp_template__init_part0_A_const_36 }










func A_arbace_cpp_template__init_part0_A_Unit21__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_template_tc_arg_forms_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_template_tc_arg_forms_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_903, false, nil); A_arbace_cpp_template_tc_arg_forms_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_39)); return A_arbace_cpp_template__init_part0_A_const_38 }








func A_arbace_cpp_template__init_part0_A_Unit22__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_template_tparams_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_template_tparams_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_904, false, nil); A_arbace_cpp_template_tparams_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_41)); return A_arbace_cpp_template__init_part0_A_const_40 }
























func A_arbace_cpp_template__init_part0_A_Unit23__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_template_strip_tparam_kids_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_template_strip_tparam_kids_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_905, false, nil); A_arbace_cpp_template_strip_tparam_kids_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_43)); return A_arbace_cpp_template__init_part0_A_const_42 }





func A_arbace_cpp_template__init_part0_A_Unit24__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_template_param_type_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_template_param_type_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_906, false, nil); A_arbace_cpp_template_param_type_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_45)); return A_arbace_cpp_template__init_part0_A_const_44 }

func A_arbace_cpp_template__init_part0_A_Unit25__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_47)); return A_arbace_cpp_template__init_part0_A_const_46 }
func A_arbace_cpp_template__init_part0_A_Unit26__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_48; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_49)); return A_arbace_cpp_template__init_part0_A_const_48.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_template__init_part0_A_Unit27__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_template_bind_scope_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_template_bind_scope_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_907, false, nil); A_arbace_cpp_template_bind_scope_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_51)); return A_arbace_cpp_template__init_part0_A_const_50 }














func A_arbace_cpp_template__init_part0_A_Unit28__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_template_arg_entity_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_template_arg_entity_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_908, false, nil); A_arbace_cpp_template_arg_entity_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_52)); return A_arbace_cpp_template__init_part0_A_const_46 }


















func A_arbace_cpp_template__init_part0_A_Unit29__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_54)); return A_arbace_cpp_template__init_part0_A_const_53 }

func A_arbace_cpp_template__init_part0_A_Unit30__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_template_var_value_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_template_var_value_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_909, false, nil); A_arbace_cpp_template_var_value_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_56)); return A_arbace_cpp_template__init_part0_A_const_55 }





func A_arbace_cpp_template__init_part0_A_Unit31__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_template_const_entity_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_template_const_entity_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_910, false, nil); A_arbace_cpp_template_const_entity_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_58)); return A_arbace_cpp_template__init_part0_A_const_57 }










func A_arbace_cpp_template__init_part0_A_Unit32__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_template_member_constant_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_template_member_constant_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_911, false, nil); A_arbace_cpp_template_member_constant_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_60)); return A_arbace_cpp_template__init_part0_A_const_59 }













func A_arbace_cpp_template__init_part0_A_Unit33__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_61; var tmp2 any = A_arbace_cpp_template__init_part0_A_const_62.GetRawRoot__O(); var tmp3 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_template_fn__960000103_A_New(); var tmp4 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_template_fn__960000103_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_912, false, nil); A_arbace_cpp_template_fn__960000103_A_fn_class = fncls__45d; tmp4 = fncls__45d } else { tmp4 = fncls__45 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp4, nil); var tmp5 any = tmp3.Ref(); var tmp6 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_template_fn__960000105_A_New(); var tmp7 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_template_fn__960000105_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_913, false, nil); A_arbace_cpp_template_fn__960000105_A_fn_class = fncls__47d; tmp7 = fncls__47d } else { tmp7 = fncls__47 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp7, nil); var tmp8 any = tmp6.Ref(); var tmp9 any = A_arbace_cpp_template__init_part0_A_const_63.GetRawRoot__O(); var tmp10 any = A_arbace_cpp_template__init_part0_A_const_64.GetRawRoot__O(); var tmp11 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_template_fn__960000107_A_New(); var tmp12 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_template_fn__960000107_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_914, false, nil); A_arbace_cpp_template_fn__960000107_A_fn_class = fncls__49d; tmp12 = fncls__49d } else { tmp12 = fncls__49 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp12, nil); var tmp13 any = tmp11.Ref(); var tmp14 any = A_arbace_cpp_template__init_part0_A_const_65.GetRawRoot__O(); var tmp15 any = A_arbace_cpp_template__init_part0_A_const_66.GetRawRoot__O(); var tmp16 any = A_arbace_cpp_template__init_part0_A_const_67.GetRawRoot__O(); var tmp17 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_template_fn__960000109_A_New(); var tmp18 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_template_fn__960000109_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_915, false, nil); A_arbace_cpp_template_fn__960000109_A_fn_class = fncls__51d; tmp18 = fncls__51d } else { tmp18 = fncls__51 }; tmp17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp18, nil); var tmp19 any = tmp17.Ref(); var tmp20 any = A_arbace_cpp_template__init_part0_A_const_68.GetRawRoot__O(); var tmp21 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_template_fn__960000111_A_New(); var tmp22 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_template_fn__960000111_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_916, false, nil); A_arbace_cpp_template_fn__960000111_A_fn_class = fncls__53d; tmp22 = fncls__53d } else { tmp22 = fncls__53 }; tmp21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp22, nil); var tmp23 any = tmp21.Ref(); var tmp24 any = A_arbace_cpp_template__init_part0_A_const_69.GetRawRoot__O(); var tmp25 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_template_fn__960000113_A_New(); var tmp26 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_template_fn__960000113_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_917, false, nil); A_arbace_cpp_template_fn__960000113_A_fn_class = fncls__55d; tmp26 = fncls__55d } else { tmp26 = fncls__55 }; tmp25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp26, nil); var tmp27 any = tmp25.Ref(); var tmp28 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_template_fn__960000115_A_New(); var tmp29 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_template_fn__960000115_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_918, false, nil); A_arbace_cpp_template_fn__960000115_A_fn_class = fncls__57d; tmp29 = fncls__57d } else { tmp29 = fncls__57 }; tmp28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp29, nil); var tmp30 any = tmp28.Ref(); var tmp31 any = A_arbace_cpp_template__init_part0_A_const_70.GetRawRoot__O(); var tmp32 any = A_arbace_cpp_template__init_part0_A_const_71.GetRawRoot__O(); var tmp33 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_template_fn__960000117_A_New(); var tmp34 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_template_fn__960000117_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_919, false, nil); A_arbace_cpp_template_fn__960000117_A_fn_class = fncls__59d; tmp34 = fncls__59d } else { tmp34 = fncls__59 }; tmp33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp34, nil); tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_652, tmp2, Lit_637, tmp5, Lit_636, tmp8, Lit_634, tmp9, Lit_646, tmp10, Lit_639, tmp13, Lit_456, tmp14, Lit_216, tmp15, Lit_552, tmp16, Lit_641, tmp19, Lit_283, tmp20, Lit_559, tmp23, Lit_651, tmp24, Lit_638, tmp27, Lit_640, tmp30, Lit_648, tmp31, Lit_554, tmp32, Lit_160, tmp33.Ref()))); var tmp35 *lang.Var = A_arbace_cpp_template__init_part0_A_const_61; tmp35.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_72)); return A_arbace_cpp_template__init_part0_A_const_61 }





func A_arbace_cpp_template__init_part0_A_Unit34__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); A_arbace_cpp_template__init_part0_A_const_73.BindRoot_O__V(A_arbace_cpp_template__init_part0_A_const_74); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_75)); return A_arbace_cpp_template__init_part0_A_const_73 }

func A_arbace_cpp_template__init_part0_A_Unit35__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_template_u64_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_template_u64_QMARK__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_920, false, nil); A_arbace_cpp_template_u64_QMARK__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_77)); return A_arbace_cpp_template__init_part0_A_const_76 }




func A_arbace_cpp_template__init_part0_A_Unit36__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_template_lng_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_template_lng_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_921, false, nil); A_arbace_cpp_template_lng_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_79)); return A_arbace_cpp_template__init_part0_A_const_78 }










func A_arbace_cpp_template__init_part0_A_Unit37__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_template_dbl_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_template_dbl_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_922, false, nil); A_arbace_cpp_template_dbl_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_81)); return A_arbace_cpp_template__init_part0_A_const_80 }





func A_arbace_cpp_template__init_part0_A_Unit38__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(225, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_template_falsy_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_template_falsy_QMARK__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_923, false, nil); A_arbace_cpp_template_falsy_QMARK__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_83)); return A_arbace_cpp_template__init_part0_A_const_82 }




func A_arbace_cpp_template__init_part0_A_Unit39__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_template_u64_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_template_u64_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_924, false, nil); A_arbace_cpp_template_u64_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_85)); return A_arbace_cpp_template__init_part0_A_const_84 }





func A_arbace_cpp_template__init_part0_A_Unit40__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_template_fold_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_template_fold_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_925, false, nil); A_arbace_cpp_template_fold_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_87)); return A_arbace_cpp_template__init_part0_A_const_86 }

















































func A_arbace_cpp_template__init_part0_A_Unit41__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); A_arbace_cpp_template__init_part0_A_const_88.BindRoot_O__V(A_arbace_cpp_template__init_part0_A_const_89); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_90)); return A_arbace_cpp_template__init_part0_A_const_88 }

func A_arbace_cpp_template__init_part0_A_Unit42__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_cpp_template_cast_to_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_template_cast_to_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_926, false, nil); A_arbace_cpp_template_cast_to_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_92)); return A_arbace_cpp_template__init_part0_A_const_91 }





















func A_arbace_cpp_template__init_part0_A_Unit43__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(310, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_93; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_94)); return A_arbace_cpp_template__init_part0_A_const_93 }






func A_arbace_cpp_template__init_part0_A_Unit44__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(317, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_template_declval_node_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_template_declval_node_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_927, false, nil); A_arbace_cpp_template_declval_node_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_96)); return A_arbace_cpp_template__init_part0_A_const_95 }






func A_arbace_cpp_template__init_part0_A_Unit45__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(324, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_cpp_template_works_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_cpp_template_works_QMARK__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_928, false, nil); A_arbace_cpp_template_works_QMARK__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_98)); return A_arbace_cpp_template__init_part0_A_const_97 }

func A_arbace_cpp_template__init_part0_A_Unit46__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_cpp_template_complete_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_cpp_template_complete_class_QMARK__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_929, false, nil); A_arbace_cpp_template_complete_class_QMARK__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_100)); return A_arbace_cpp_template__init_part0_A_const_99 }

func A_arbace_cpp_template__init_part0_A_Unit47__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_template_object_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_template_object_type_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_930, false, nil); A_arbace_cpp_template_object_type_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_102)); return A_arbace_cpp_template__init_part0_A_const_101 }

func A_arbace_cpp_template__init_part0_A_Unit48__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); A_arbace_cpp_template__init_part0_A_const_103.BindRoot_O__V(lang.PersistentHashSet_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_103; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_104)); return A_arbace_cpp_template__init_part0_A_const_103.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_template__init_part0_A_Unit49__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(332, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_template_trait_constructible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_template_trait_constructible_QMARK__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_931, false, nil); A_arbace_cpp_template_trait_constructible_QMARK__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_106)); return A_arbace_cpp_template__init_part0_A_const_105 }













func A_arbace_cpp_template__init_part0_A_Unit50__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_107; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_108)); return A_arbace_cpp_template__init_part0_A_const_107 }

func A_arbace_cpp_template__init_part0_A_Unit51__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(348, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_cpp_template_calls_nothrow_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_cpp_template_calls_nothrow_QMARK__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_932, false, nil); A_arbace_cpp_template_calls_nothrow_QMARK__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_110)); return A_arbace_cpp_template__init_part0_A_const_109 }








func A_arbace_cpp_template__init_part0_A_Unit52__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_cpp_template_trait_nothrow_constructible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_cpp_template_trait_nothrow_constructible_QMARK__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_933, false, nil); A_arbace_cpp_template_trait_nothrow_constructible_QMARK__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_112)); return A_arbace_cpp_template__init_part0_A_const_111 }







func A_arbace_cpp_template__init_part0_A_Unit53__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_template_trait_nothrow_assignable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_template_trait_nothrow_assignable_QMARK__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_934, false, nil); A_arbace_cpp_template_trait_nothrow_assignable_QMARK__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_114)); return A_arbace_cpp_template__init_part0_A_const_113 }



func A_arbace_cpp_template__init_part0_A_Unit54__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_template_trait_convertible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_template_trait_convertible_QMARK__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_935, false, nil); A_arbace_cpp_template_trait_convertible_QMARK__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_116)); return A_arbace_cpp_template__init_part0_A_const_115 }





func A_arbace_cpp_template__init_part0_A_Unit55__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_template_trait_assignable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_template_trait_assignable_QMARK__A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_936, false, nil); A_arbace_cpp_template_trait_assignable_QMARK__A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_118)); return A_arbace_cpp_template__init_part0_A_const_117 }


func A_arbace_cpp_template__init_part0_A_Unit56__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_cpp_template_trivial_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_template_trivial_class_QMARK__A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_937, false, nil); A_arbace_cpp_template_trivial_class_QMARK__A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_120)); return A_arbace_cpp_template__init_part0_A_const_119 }



func A_arbace_cpp_template__init_part0_A_Unit57__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(382, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_template_trivially_default_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_template_trivially_default_QMARK__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_938, false, nil); A_arbace_cpp_template_trivially_default_QMARK__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_122)); return A_arbace_cpp_template__init_part0_A_const_121 }






func A_arbace_cpp_template__init_part0_A_Unit58__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_cpp_template_fn__960000188_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_template_fn__960000188_A_fn_class; if


































	fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_940, false, nil); A_arbace_cpp_template_fn__960000188_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); var tmp4 any = /*line :389:1*/tmp2.Ref(); var tmp5 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_cpp_template_fn__960000195_A_New(); var tmp6 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_template_fn__960000195_A_fn_class; if




























































	fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_942, false, nil); A_arbace_cpp_template_fn__960000195_A_fn_class = fncls__101d; tmp6 = fncls__101d } else { tmp6 = fncls__101 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp6, nil); var tmp7 any = /*line :389:1*/tmp5.Ref(); var tmp8 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_cpp_template_fn__960000203_A_New(); var tmp9 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_cpp_template_fn__960000203_A_fn_class; if









	fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_944, false, nil); A_arbace_cpp_template_fn__960000203_A_fn_class = fncls__103d; tmp9 = fncls__103d } else { tmp9 = fncls__103 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp9, nil); var tmp10 any = /*line :389:1*/tmp8.Ref(); var tmp11 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_cpp_template_fn__960000209_A_New(); var tmp12 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_cpp_template_fn__960000209_A_fn_class; if









































	fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_946, false, nil); A_arbace_cpp_template_fn__960000209_A_fn_class = fncls__105d; tmp12 = fncls__105d } else { tmp12 = fncls__105 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp12, nil); var tmp13 any = /*line :389:1*/tmp11.Ref(); var tmp14 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_cpp_template_fn__960000215_A_New(); var tmp15 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_cpp_template_fn__960000215_A_fn_class; if









































































	fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_948, false, nil); A_arbace_cpp_template_fn__960000215_A_fn_class = fncls__107d; tmp15 = fncls__107d } else { tmp15 = fncls__107 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp15, nil); var tmp16 any = /*line :389:1*/tmp14.Ref(); var tmp17 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_cpp_template_fn__960000221_A_New(); var tmp18 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_cpp_template_fn__960000221_A_fn_class; if































































	fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_950, false, nil); A_arbace_cpp_template_fn__960000221_A_fn_class = fncls__109d; tmp18 = fncls__109d } else { tmp18 = fncls__109 }; tmp17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp18, nil); var tmp19 any = /*line :389:1*/tmp17.Ref(); var tmp20 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_cpp_template_fn__960000229_A_New(); var tmp21 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_cpp_template_fn__960000229_A_fn_class; if






















	fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_952, false, nil); A_arbace_cpp_template_fn__960000229_A_fn_class = fncls__111d; tmp21 = fncls__111d } else { tmp21 = fncls__111 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp21, nil); var tmp22 any = /*line :389:1*/tmp20.Ref(); var tmp23 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_cpp_template_fn__960000235_A_New(); var tmp24 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_cpp_template_fn__960000235_A_fn_class; if










































	fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_954, false, nil); A_arbace_cpp_template_fn__960000235_A_fn_class = fncls__113d; tmp24 = fncls__113d } else { tmp24 = fncls__113 }; tmp23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp24, nil); var tmp25 any = /*line :389:1*/tmp23.Ref(); var tmp26 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_cpp_template_fn__960000241_A_New(); var tmp27 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_cpp_template_fn__960000241_A_fn_class; if














	fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_956, false, nil); A_arbace_cpp_template_fn__960000241_A_fn_class = fncls__115d; tmp27 = fncls__115d } else { tmp27 = fncls__115 }; tmp26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp27, nil); var tmp28 any = /*line :389:1*/tmp26.Ref(); var tmp29 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_cpp_template_fn__960000247_A_New(); var tmp30 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_cpp_template_fn__960000247_A_fn_class; if


	fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_958, false, nil); A_arbace_cpp_template_fn__960000247_A_fn_class = fncls__117d; tmp30 = fncls__117d } else { tmp30 = fncls__117 }; tmp29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp30, nil); var tmp31 any = /*line :389:1*/tmp29.Ref(); var tmp32 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_cpp_template_fn__960000253_A_New(); var tmp33 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_cpp_template_fn__960000253_A_fn_class; if

























	fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_960, false, nil); A_arbace_cpp_template_fn__960000253_A_fn_class = fncls__119d; tmp33 = fncls__119d } else { tmp33 = fncls__119 }; tmp32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp33, nil); var tmp34 any = /*line :389:1*/tmp32.Ref(); var tmp35 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_cpp_template_fn__960000259_A_New(); var tmp36 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_cpp_template_fn__960000259_A_fn_class; if

































































	fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_962, false, nil); A_arbace_cpp_template_fn__960000259_A_fn_class = fncls__121d; tmp36 = fncls__121d } else { tmp36 = fncls__121 }; tmp35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp36, nil); var tmp37 any = /*line :389:1*/tmp35.Ref(); var tmp38 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_cpp_template_fn__960000267_A_New(); var tmp39 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_cpp_template_fn__960000267_A_fn_class; if


























	fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_964, false, nil); A_arbace_cpp_template_fn__960000267_A_fn_class = fncls__123d; tmp39 = fncls__123d } else { tmp39 = fncls__123 }; tmp38 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp39, nil); var tmp40 any = /*line :389:1*/tmp38.Ref(); var tmp41 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_cpp_template_fn__960000273_A_New(); var tmp42 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_cpp_template_fn__960000273_A_fn_class; if













	fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_966, false, nil); A_arbace_cpp_template_fn__960000273_A_fn_class = fncls__125d; tmp42 = fncls__125d } else { tmp42 = fncls__125 }; tmp41 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp42, nil); var tmp43 any = /*line :389:1*/tmp41.Ref(); var tmp44 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_cpp_template_fn__960000279_A_New(); var tmp45 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_cpp_template_fn__960000279_A_fn_class; if








































	fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_968, false, nil); A_arbace_cpp_template_fn__960000279_A_fn_class = fncls__127d; tmp45 = fncls__127d } else { tmp45 = fncls__127 }; tmp44 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp45, nil); var tmp46 any = /*line :389:1*/tmp44.Ref(); var tmp47 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_cpp_template_fn__960000285_A_New(); var tmp48 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_cpp_template_fn__960000285_A_fn_class; if











































































	fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_970, false, nil); A_arbace_cpp_template_fn__960000285_A_fn_class = fncls__129d; tmp48 = fncls__129d } else { tmp48 = fncls__129 }; tmp47 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp48, nil); var tmp49 any = /*line :389:1*/tmp47.Ref(); var tmp50 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_cpp_template_fn__960000291_A_New(); var tmp51 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_cpp_template_fn__960000291_A_fn_class; if





























































	fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_972, false, nil); A_arbace_cpp_template_fn__960000291_A_fn_class = fncls__131d; tmp51 = fncls__131d } else { tmp51 = fncls__131 }; tmp50 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp51, nil); var tmp52 any = /*line :389:1*/tmp50.Ref(); var tmp53 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_cpp_template_fn__960000299_A_New(); var tmp54 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_cpp_template_fn__960000299_A_fn_class; if































	fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_974, false, nil); A_arbace_cpp_template_fn__960000299_A_fn_class = fncls__133d; tmp54 = fncls__133d } else { tmp54 = fncls__133 }; tmp53 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp54, nil); var tmp55 any = /*line :389:1*/tmp53.Ref(); var tmp56 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_cpp_template_fn__960000307_A_New(); var tmp57 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_cpp_template_fn__960000307_A_fn_class; if




















	fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_976, false, nil); A_arbace_cpp_template_fn__960000307_A_fn_class = fncls__135d; tmp57 = fncls__135d } else { tmp57 = fncls__135 }; tmp56 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp57, nil); var tmp58 any = /*line :389:1*/tmp56.Ref(); var tmp59 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_cpp_template_fn__960000313_A_New(); var tmp60 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_cpp_template_fn__960000313_A_fn_class; if





















































	fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_978, false, nil); A_arbace_cpp_template_fn__960000313_A_fn_class = fncls__137d; tmp60 = fncls__137d } else { tmp60 = fncls__137 }; tmp59 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp60, nil); var tmp61 any = /*line :389:1*/tmp59.Ref(); var tmp62 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_cpp_template_fn__960000319_A_New(); var tmp63 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_cpp_template_fn__960000319_A_fn_class; if



















	fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_980, false, nil); A_arbace_cpp_template_fn__960000319_A_fn_class = fncls__139d; tmp63 = fncls__139d } else { tmp63 = fncls__139 }; tmp62 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp63, nil); var tmp64 any = /*line :389:1*/tmp62.Ref(); var tmp65 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_cpp_template_fn__960000325_A_New(); var tmp66 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_cpp_template_fn__960000325_A_fn_class; if

















	fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_982, false, nil); A_arbace_cpp_template_fn__960000325_A_fn_class = fncls__141d; tmp66 = fncls__141d } else { tmp66 = fncls__141 }; tmp65 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp66, nil); var tmp67 any = /*line :389:1*/tmp65.Ref(); var tmp68 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_cpp_template_fn__960000331_A_New(); var tmp69 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_cpp_template_fn__960000331_A_fn_class; if


















	fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_984, false, nil); A_arbace_cpp_template_fn__960000331_A_fn_class = fncls__143d; tmp69 = fncls__143d } else { tmp69 = fncls__143 }; tmp68 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp69, nil); var tmp70 any = /*line :389:1*/tmp68.Ref(); var tmp71 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_cpp_template_fn__960000337_A_New(); var tmp72 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_cpp_template_fn__960000337_A_fn_class; if






























	fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_986, false, nil); A_arbace_cpp_template_fn__960000337_A_fn_class = fncls__145d; tmp72 = fncls__145d } else { tmp72 = fncls__145 }; tmp71 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp72, nil); var tmp73 any = /*line :389:1*/tmp71.Ref(); var tmp74 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_cpp_template_fn__960000343_A_New(); var tmp75 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_cpp_template_fn__960000343_A_fn_class; if



























	fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_988, false, nil); A_arbace_cpp_template_fn__960000343_A_fn_class = fncls__147d; tmp75 = fncls__147d } else { tmp75 = fncls__147 }; tmp74 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp75, nil); var tmp76 any = /*line :389:1*/tmp74.Ref(); var tmp77 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_cpp_template_fn__960000349_A_New(); var tmp78 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_cpp_template_fn__960000349_A_fn_class; if






































































	fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_990, false, nil); A_arbace_cpp_template_fn__960000349_A_fn_class = fncls__149d; tmp78 = fncls__149d } else { tmp78 = fncls__149 }; tmp77 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp78, nil); var tmp79 any = /*line :389:1*/tmp77.Ref(); var tmp80 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_cpp_template_fn__960000355_A_New(); var tmp81 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_cpp_template_fn__960000355_A_fn_class; if























	fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_992, false, nil); A_arbace_cpp_template_fn__960000355_A_fn_class = fncls__151d; tmp81 = fncls__151d } else { tmp81 = fncls__151 }; tmp80 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp81, nil); var tmp82 any = /*line :389:1*/tmp80.Ref(); var tmp83 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_cpp_template_fn__960000363_A_New(); var tmp84 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_cpp_template_fn__960000363_A_fn_class; if












































	fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_994, false, nil); A_arbace_cpp_template_fn__960000363_A_fn_class = fncls__153d; tmp84 = fncls__153d } else { tmp84 = fncls__153 }; tmp83 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp84, nil); var tmp85 any = /*line :389:1*/tmp83.Ref(); var tmp86 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_cpp_template_fn__960000368_A_New(); var tmp87 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_cpp_template_fn__960000368_A_fn_class; if







































































	fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_996, false, nil); A_arbace_cpp_template_fn__960000368_A_fn_class = fncls__155d; tmp87 = fncls__155d } else { tmp87 = fncls__155 }; tmp86 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp87, nil); var tmp88 any = /*line :389:1*/tmp86.Ref(); var tmp89 *lang.Compiler_AOTFn; var fnbody__158 any = A_arbace_cpp_template_fn__960000371_A_New(); var tmp90 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_cpp_template_fn__960000371_A_fn_class; if















	fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_998, false, nil); A_arbace_cpp_template_fn__960000371_A_fn_class = fncls__157d; tmp90 = fncls__157d } else { tmp90 = fncls__157 }; tmp89 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__158, tmp90, nil); var tmp91 any = /*line :389:1*/tmp89.Ref(); var tmp92 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_cpp_template_fn__960000377_A_New(); var tmp93 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_cpp_template_fn__960000377_A_fn_class; if
























	fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1000, false, nil); A_arbace_cpp_template_fn__960000377_A_fn_class = fncls__159d; tmp93 = fncls__159d } else { tmp93 = fncls__159 }; tmp92 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp93, nil); var tmp94 any = /*line :389:1*/tmp92.Ref(); var tmp95 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_cpp_template_fn__960000385_A_New(); var tmp96 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_cpp_template_fn__960000385_A_fn_class; if





































































	fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1002, false, nil); A_arbace_cpp_template_fn__960000385_A_fn_class = fncls__161d; tmp96 = fncls__161d } else { tmp96 = fncls__161 }; tmp95 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp96, nil); var tmp97 any = /*line :389:1*/tmp95.Ref(); var tmp98 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_cpp_template_fn__960000391_A_New(); var tmp99 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_cpp_template_fn__960000391_A_fn_class; if























































	fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1004, false, nil); A_arbace_cpp_template_fn__960000391_A_fn_class = fncls__163d; tmp99 = fncls__163d } else { tmp99 = fncls__163 }; tmp98 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp99, nil); var tmp100 any = /*line :389:1*/tmp98.Ref(); var tmp101 *lang.Compiler_AOTFn; var fnbody__166 any = A_arbace_cpp_template_fn__960000397_A_New(); var tmp102 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_cpp_template_fn__960000397_A_fn_class; if








	fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1006, false, nil); A_arbace_cpp_template_fn__960000397_A_fn_class = fncls__165d; tmp102 = fncls__165d } else { tmp102 = fncls__165 }; tmp101 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp102, nil); var tmp103 any = /*line :389:1*/tmp101.Ref(); var tmp104 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_cpp_template_fn__960000403_A_New(); var tmp105 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_cpp_template_fn__960000403_A_fn_class; if














































	fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1008, false, nil); A_arbace_cpp_template_fn__960000403_A_fn_class = fncls__167d; tmp105 = fncls__167d } else { tmp105 = fncls__167 }; tmp104 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp105, nil); var tmp106 any = /*line :389:1*/tmp104.Ref(); var tmp107 *lang.Compiler_AOTFn; var fnbody__170 any = A_arbace_cpp_template_fn__960000411_A_New(); var tmp108 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_cpp_template_fn__960000411_A_fn_class; if



	fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1010, false, nil); A_arbace_cpp_template_fn__960000411_A_fn_class = fncls__169d; tmp108 = fncls__169d } else { tmp108 = fncls__169 }; tmp107 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp108, nil); var tmp109 any = /*line :389:1*/tmp107.Ref(); var tmp110 *lang.Compiler_AOTFn; var fnbody__172 any = A_arbace_cpp_template_fn__960000417_A_New(); var tmp111 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_cpp_template_fn__960000417_A_fn_class; if






















































	fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1012, false, nil); A_arbace_cpp_template_fn__960000417_A_fn_class = fncls__171d; tmp111 = fncls__171d } else { tmp111 = fncls__171 }; tmp110 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__172, tmp111, nil); var tmp112 any = /*line :389:1*/tmp110.Ref(); var tmp113 *lang.Compiler_AOTFn; var fnbody__174 any = A_arbace_cpp_template_fn__960000423_A_New(); var tmp114 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_cpp_template_fn__960000423_A_fn_class; if



































































	fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1014, false, nil); A_arbace_cpp_template_fn__960000423_A_fn_class = fncls__173d; tmp114 = fncls__173d } else { tmp114 = fncls__173 }; tmp113 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__174, tmp114, nil); var tmp115 any = /*line :389:1*/tmp113.Ref(); var tmp116 *lang.Compiler_AOTFn; var fnbody__176 any = A_arbace_cpp_template_fn__960000431_A_New(); var tmp117 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_cpp_template_fn__960000431_A_fn_class; if
	fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1016, false, nil); A_arbace_cpp_template_fn__960000431_A_fn_class = fncls__175d; tmp117 = fncls__175d } else { tmp117 = fncls__175 }; tmp116 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__176, tmp117, nil); var tmp118 any = /*line :389:1*/tmp116.Ref(); var tmp119 *lang.Compiler_AOTFn; var fnbody__178 any = A_arbace_cpp_template_fn__960000437_A_New(); var tmp120 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_cpp_template_fn__960000437_A_fn_class; if




























	fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1018, false, nil); A_arbace_cpp_template_fn__960000437_A_fn_class = fncls__177d; tmp120 = fncls__177d } else { tmp120 = fncls__177 }; tmp119 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__178, tmp120, nil); var tmp121 any = /*line :389:1*/tmp119.Ref(); var tmp122 *lang.Compiler_AOTFn; var fnbody__180 any = A_arbace_cpp_template_fn__960000443_A_New(); var tmp123 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_cpp_template_fn__960000443_A_fn_class; if





















	fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1020, false, nil); A_arbace_cpp_template_fn__960000443_A_fn_class = fncls__179d; tmp123 = fncls__179d } else { tmp123 = fncls__179 }; tmp122 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__180, tmp123, nil); var tmp124 any = /*line :389:1*/tmp122.Ref(); var tmp125 *lang.Compiler_AOTFn; var fnbody__182 any = A_arbace_cpp_template_fn__960000449_A_New(); var tmp126 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_cpp_template_fn__960000449_A_fn_class; if











	fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1022, false, nil); A_arbace_cpp_template_fn__960000449_A_fn_class = fncls__181d; tmp126 = fncls__181d } else { tmp126 = fncls__181 }; tmp125 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__182, tmp126, nil); var tmp127 any = /*line :389:1*/tmp125.Ref(); var tmp128 *lang.Compiler_AOTFn; var fnbody__184 any = A_arbace_cpp_template_fn__960000455_A_New(); var tmp129 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_cpp_template_fn__960000455_A_fn_class; if






	fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1024, false, nil); A_arbace_cpp_template_fn__960000455_A_fn_class = fncls__183d; tmp129 = fncls__183d } else { tmp129 = fncls__183 }; tmp128 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__184, tmp129, nil); var tmp130 any = /*line :389:1*/tmp128.Ref(); var tmp131 *lang.Compiler_AOTFn; var fnbody__186 any = A_arbace_cpp_template_fn__960000461_A_New(); var tmp132 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_cpp_template_fn__960000461_A_fn_class; if







	fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1026, false, nil); A_arbace_cpp_template_fn__960000461_A_fn_class = fncls__185d; tmp132 = fncls__185d } else { tmp132 = fncls__185 }; tmp131 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__186, tmp132, nil); var tmp133 any = /*line :389:1*/tmp131.Ref(); var tmp134 *lang.Compiler_AOTFn; var fnbody__188 any = A_arbace_cpp_template_fn__960000467_A_New(); var tmp135 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_cpp_template_fn__960000467_A_fn_class; if










	fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1028, false, nil); A_arbace_cpp_template_fn__960000467_A_fn_class = fncls__187d; tmp135 = fncls__187d } else { tmp135 = fncls__187 }; tmp134 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__188, tmp135, nil); var tmp136 any = /*line :389:1*/tmp134.Ref(); var tmp137 *lang.Compiler_AOTFn; var fnbody__190 any = A_arbace_cpp_template_fn__960000473_A_New(); var tmp138 *jrt.Class; var fncls__189 *jrt.Class = A_arbace_cpp_template_fn__960000473_A_fn_class; if
















	fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1030, false, nil); A_arbace_cpp_template_fn__960000473_A_fn_class = fncls__189d; tmp138 = fncls__189d } else { tmp138 = fncls__189 }; tmp137 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__190, tmp138, nil); var tmp139 any = /*line :389:1*/tmp137.Ref(); var tmp140 *lang.Compiler_AOTFn; var fnbody__192 any = A_arbace_cpp_template_fn__960000479_A_New(); var tmp141 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_cpp_template_fn__960000479_A_fn_class; if




	fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1032, false, nil); A_arbace_cpp_template_fn__960000479_A_fn_class = fncls__191d; tmp141 = fncls__191d } else { tmp141 = fncls__191 }; tmp140 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__192, tmp141, nil); var tmp142 any = /*line :389:1*/tmp140.Ref(); var tmp143 *lang.Compiler_AOTFn; var fnbody__194 any = A_arbace_cpp_template_fn__960000485_A_New(); var tmp144 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_cpp_template_fn__960000485_A_fn_class; if



























































	fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1034, false, nil); A_arbace_cpp_template_fn__960000485_A_fn_class = fncls__193d; tmp144 = fncls__193d } else { tmp144 = fncls__193 }; tmp143 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__194, tmp144, nil); var tmp145 any = /*line :389:1*/tmp143.Ref(); var tmp146 *lang.Compiler_AOTFn; var fnbody__196 any = A_arbace_cpp_template_fn__960000493_A_New(); var tmp147 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_cpp_template_fn__960000493_A_fn_class; if


























































	fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1036, false, nil); A_arbace_cpp_template_fn__960000493_A_fn_class = fncls__195d; tmp147 = fncls__195d } else { tmp147 = fncls__195 }; tmp146 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__196, tmp147, nil); var tmp148 any = /*line :389:1*/tmp146.Ref(); var tmp149 *lang.Compiler_AOTFn; var fnbody__198 any = A_arbace_cpp_template_fn__960000499_A_New(); var tmp150 *jrt.Class; var fncls__197 *jrt.Class = A_arbace_cpp_template_fn__960000499_A_fn_class; if











































	fncls__197 == nil { var fncls__197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1038, false, nil); A_arbace_cpp_template_fn__960000499_A_fn_class = fncls__197d; tmp150 = fncls__197d } else { tmp150 = fncls__197 }; tmp149 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__198, tmp150, nil); var tmp151 any = /*line :389:1*/tmp149.Ref(); var tmp152 *lang.Compiler_AOTFn; var fnbody__200 any = A_arbace_cpp_template_fn__960000505_A_New(); var tmp153 *jrt.Class; var fncls__199 *jrt.Class = A_arbace_cpp_template_fn__960000505_A_fn_class; if





	fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1040, false, nil); A_arbace_cpp_template_fn__960000505_A_fn_class = fncls__199d; tmp153 = fncls__199d } else { tmp153 = fncls__199 }; tmp152 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__200, tmp153, nil); var tmp154 any = /*line :389:1*/tmp152.Ref(); var tmp155 *lang.Compiler_AOTFn; var fnbody__202 any = A_arbace_cpp_template_fn__960000511_A_New(); var tmp156 *jrt.Class; var fncls__201 *jrt.Class = A_arbace_cpp_template_fn__960000511_A_fn_class; if
































	fncls__201 == nil { var fncls__201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1042, false, nil); A_arbace_cpp_template_fn__960000511_A_fn_class = fncls__201d; tmp156 = fncls__201d } else { tmp156 = fncls__201 }; tmp155 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__202, tmp156, nil); var tmp157 any = /*line :389:1*/tmp155.Ref(); var tmp158 *lang.Compiler_AOTFn; var fnbody__204 any = A_arbace_cpp_template_fn__960000517_A_New(); var tmp159 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_cpp_template_fn__960000517_A_fn_class; if












	fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1044, false, nil); A_arbace_cpp_template_fn__960000517_A_fn_class = fncls__203d; tmp159 = fncls__203d } else { tmp159 = fncls__203 }; tmp158 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__204, tmp159, nil); var tmp160 any = /*line :389:1*/tmp158.Ref(); var tmp161 *lang.Compiler_AOTFn; var fnbody__206 any = A_arbace_cpp_template_fn__960000523_A_New(); var tmp162 *jrt.Class; var fncls__205 *jrt.Class = A_arbace_cpp_template_fn__960000523_A_fn_class; if



































	fncls__205 == nil { var fncls__205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1046, false, nil); A_arbace_cpp_template_fn__960000523_A_fn_class = fncls__205d; tmp162 = fncls__205d } else { tmp162 = fncls__205 }; tmp161 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__206, tmp162, nil); var tmp163 any = /*line :389:1*/tmp161.Ref(); var tmp164 *lang.Compiler_AOTFn; var fnbody__208 any = A_arbace_cpp_template_fn__960000530_A_New(); var tmp165 *jrt.Class; var fncls__207 *jrt.Class = A_arbace_cpp_template_fn__960000530_A_fn_class; if

























































	fncls__207 == nil { var fncls__207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1048, false, nil); A_arbace_cpp_template_fn__960000530_A_fn_class = fncls__207d; tmp165 = fncls__207d } else { tmp165 = fncls__207 }; tmp164 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__208, tmp165, nil); var tmp166 any = /*line :389:1*/tmp164.Ref(); var tmp167 *lang.Compiler_AOTFn; var fnbody__210 any = A_arbace_cpp_template_fn__960000536_A_New(); var tmp168 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_cpp_template_fn__960000536_A_fn_class; if





























	fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1050, false, nil); A_arbace_cpp_template_fn__960000536_A_fn_class = fncls__209d; tmp168 = fncls__209d } else { tmp168 = fncls__209 }; tmp167 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__210, tmp168, nil); var tmp169 any = /*line :389:1*/tmp167.Ref(); var tmp170 *lang.Compiler_AOTFn; var fnbody__212 any = A_arbace_cpp_template_fn__960000542_A_New(); var tmp171 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_cpp_template_fn__960000542_A_fn_class; if

































	fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1052, false, nil); A_arbace_cpp_template_fn__960000542_A_fn_class = fncls__211d; tmp171 = fncls__211d } else { tmp171 = fncls__211 }; tmp170 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__212, tmp171, nil); /*line :389:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_939, tmp4, Lit_941, tmp7, Lit_943, tmp10, Lit_945, tmp13, Lit_947, tmp16, Lit_949, tmp19, Lit_951, tmp22, Lit_953, tmp25, Lit_955, tmp28, Lit_957, tmp31, Lit_959, tmp34, Lit_961, tmp37, Lit_963, tmp40, Lit_965, tmp43, Lit_967, tmp46, Lit_969, tmp49, Lit_971, tmp52, Lit_973, tmp55, Lit_975, tmp58, Lit_977, tmp61, Lit_979, tmp64, Lit_981, tmp67, Lit_983, tmp70, Lit_985, tmp73, Lit_987, tmp76, Lit_989, tmp79, Lit_991, tmp82, Lit_993, tmp85, Lit_995, tmp88, Lit_997, tmp91, Lit_999, tmp94, Lit_1001, tmp97, Lit_1003, tmp100, Lit_1005, tmp103, Lit_1007, tmp106, Lit_1009, tmp109, Lit_1011, tmp112, Lit_1013, tmp115, Lit_1015, tmp118, Lit_1017, tmp121, Lit_1019, tmp124, Lit_1021, tmp127, Lit_1023, tmp130, Lit_1025, tmp133, Lit_1027, tmp136, Lit_1029, tmp139, Lit_1031, tmp142, Lit_1033, tmp145, Lit_1035, tmp148, Lit_1037, tmp151, Lit_1039, tmp154, Lit_1041, tmp157, Lit_1043, tmp160, Lit_1045, tmp163, Lit_1047, tmp166, Lit_1049, tmp169, Lit_1051, tmp170.Ref()))); var tmp172 *lang.Var = A_arbace_cpp_template__init_part0_A_const_123; tmp172.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_124)); return A_arbace_cpp_template__init_part0_A_const_123 }













































































func A_arbace_cpp_template__init_part0_A_Unit59__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(467, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__214 any = A_arbace_cpp_template_decay_A_New(); var tmp3 *jrt.Class; var fncls__213 *jrt.Class = A_arbace_cpp_template_decay_A_fn_class; if fncls__213 == nil { var fncls__213d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1053, false, nil); A_arbace_cpp_template_decay_A_fn_class = fncls__213d; tmp3 = fncls__213d } else { tmp3 = fncls__213 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__214, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_126)); return A_arbace_cpp_template__init_part0_A_const_125 }





func A_arbace_cpp_template__init_part0_A_Unit60__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(473, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__216 any = A_arbace_cpp_template_fn__960000549_A_New(); var tmp3 *jrt.Class; var fncls__215 *jrt.Class = A_arbace_cpp_template_fn__960000549_A_fn_class; if



	fncls__215 == nil { var fncls__215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1055, false, nil); A_arbace_cpp_template_fn__960000549_A_fn_class = fncls__215d; tmp3 = fncls__215d } else { tmp3 = fncls__215 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__216, tmp3, nil); var tmp4 any = /*line :473:1*/tmp2.Ref(); var tmp5 *lang.Compiler_AOTFn; var fnbody__218 any = A_arbace_cpp_template_fn__960000555_A_New(); var tmp6 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_cpp_template_fn__960000555_A_fn_class; if








	fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1057, false, nil); A_arbace_cpp_template_fn__960000555_A_fn_class = fncls__217d; tmp6 = fncls__217d } else { tmp6 = fncls__217 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__218, tmp6, nil); var tmp7 any = /*line :473:1*/tmp5.Ref(); var tmp8 *lang.Compiler_AOTFn; var fnbody__220 any = A_arbace_cpp_template_fn__960000561_A_New(); var tmp9 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_cpp_template_fn__960000561_A_fn_class; if




	fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1059, false, nil); A_arbace_cpp_template_fn__960000561_A_fn_class = fncls__219d; tmp9 = fncls__219d } else { tmp9 = fncls__219 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__220, tmp9, nil); var tmp10 any = /*line :473:1*/tmp8.Ref(); var tmp11 *lang.Compiler_AOTFn; var fnbody__222 any = A_arbace_cpp_template_fn__960000567_A_New(); var tmp12 *jrt.Class; var fncls__221 *jrt.Class = A_arbace_cpp_template_fn__960000567_A_fn_class; if
	fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1061, false, nil); A_arbace_cpp_template_fn__960000567_A_fn_class = fncls__221d; tmp12 = fncls__221d } else { tmp12 = fncls__221 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__222, tmp12, nil); var tmp13 any = /*line :473:1*/tmp11.Ref(); var tmp14 *lang.Compiler_AOTFn; var fnbody__224 any = A_arbace_cpp_template_fn__960000573_A_New(); var tmp15 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_cpp_template_fn__960000573_A_fn_class; if









	fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1063, false, nil); A_arbace_cpp_template_fn__960000573_A_fn_class = fncls__223d; tmp15 = fncls__223d } else { tmp15 = fncls__223 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__224, tmp15, nil); var tmp16 any = /*line :473:1*/tmp14.Ref(); var tmp17 *lang.Compiler_AOTFn; var fnbody__226 any = A_arbace_cpp_template_fn__960000579_A_New(); var tmp18 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_cpp_template_fn__960000579_A_fn_class; if





	fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1065, false, nil); A_arbace_cpp_template_fn__960000579_A_fn_class = fncls__225d; tmp18 = fncls__225d } else { tmp18 = fncls__225 }; tmp17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__226, tmp18, nil); var tmp19 any = /*line :473:1*/tmp17.Ref(); var tmp20 *lang.Compiler_AOTFn; var fnbody__228 any = A_arbace_cpp_template_fn__960000585_A_New(); var tmp21 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_cpp_template_fn__960000585_A_fn_class; if










	fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1067, false, nil); A_arbace_cpp_template_fn__960000585_A_fn_class = fncls__227d; tmp21 = fncls__227d } else { tmp21 = fncls__227 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__228, tmp21, nil); var tmp22 any = /*line :473:1*/tmp20.Ref(); var tmp23 *lang.Compiler_AOTFn; var fnbody__230 any = A_arbace_cpp_template_fn__960000591_A_New(); var tmp24 *jrt.Class; var fncls__229 *jrt.Class = A_arbace_cpp_template_fn__960000591_A_fn_class; if












	fncls__229 == nil { var fncls__229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1069, false, nil); A_arbace_cpp_template_fn__960000591_A_fn_class = fncls__229d; tmp24 = fncls__229d } else { tmp24 = fncls__229 }; tmp23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__230, tmp24, nil); var tmp25 any = /*line :473:1*/tmp23.Ref(); var tmp26 *lang.Compiler_AOTFn; var fnbody__232 any = A_arbace_cpp_template_fn__960000597_A_New(); var tmp27 *jrt.Class; var fncls__231 *jrt.Class = A_arbace_cpp_template_fn__960000597_A_fn_class; if


	fncls__231 == nil { var fncls__231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1071, false, nil); A_arbace_cpp_template_fn__960000597_A_fn_class = fncls__231d; tmp27 = fncls__231d } else { tmp27 = fncls__231 }; tmp26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__232, tmp27, nil); var tmp28 any = /*line :473:1*/tmp26.Ref(); var tmp29 *lang.Compiler_AOTFn; var fnbody__234 any = A_arbace_cpp_template_fn__960000603_A_New(); var tmp30 *jrt.Class; var fncls__233 *jrt.Class = A_arbace_cpp_template_fn__960000603_A_fn_class; if











	fncls__233 == nil { var fncls__233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1073, false, nil); A_arbace_cpp_template_fn__960000603_A_fn_class = fncls__233d; tmp30 = fncls__233d } else { tmp30 = fncls__233 }; tmp29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__234, tmp30, nil); var tmp31 any = /*line :473:1*/tmp29.Ref(); var tmp32 *lang.Compiler_AOTFn; var fnbody__236 any = A_arbace_cpp_template_fn__960000609_A_New(); var tmp33 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_cpp_template_fn__960000609_A_fn_class; if






	fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1075, false, nil); A_arbace_cpp_template_fn__960000609_A_fn_class = fncls__235d; tmp33 = fncls__235d } else { tmp33 = fncls__235 }; tmp32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__236, tmp33, nil); var tmp34 any = /*line :473:1*/tmp32.Ref(); var tmp35 *lang.Compiler_AOTFn; var fnbody__238 any = A_arbace_cpp_template_fn__960000615_A_New(); var tmp36 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_cpp_template_fn__960000615_A_fn_class; if







	fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1077, false, nil); A_arbace_cpp_template_fn__960000615_A_fn_class = fncls__237d; tmp36 = fncls__237d } else { tmp36 = fncls__237 }; tmp35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__238, tmp36, nil); var tmp37 any = /*line :473:1*/tmp35.Ref(); var tmp38 *lang.Compiler_AOTFn; var fnbody__240 any = A_arbace_cpp_template_fn__960000621_A_New(); var tmp39 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_cpp_template_fn__960000621_A_fn_class; if

	fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1079, false, nil); A_arbace_cpp_template_fn__960000621_A_fn_class = fncls__239d; tmp39 = fncls__239d } else { tmp39 = fncls__239 }; tmp38 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__240, tmp39, nil); /*line :473:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_1054, tmp4, Lit_1056, tmp7, Lit_1058, tmp10, Lit_1060, tmp13, Lit_1062, tmp16, Lit_1064, tmp19, Lit_1066, tmp22, Lit_1068, tmp25, Lit_1070, tmp28, Lit_1072, tmp31, Lit_1074, tmp34, Lit_1076, tmp37, Lit_1078, tmp38.Ref()))); var tmp40 *lang.Var = A_arbace_cpp_template__init_part0_A_const_127; tmp40.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_128)); return A_arbace_cpp_template__init_part0_A_const_127 }














func A_arbace_cpp_template__init_part0_A_Unit61__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(488, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__242 any = A_arbace_cpp_template_split_top_commas_A_New(); var tmp3 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_cpp_template_split_top_commas_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1080, false, nil); A_arbace_cpp_template_split_top_commas_A_fn_class = fncls__241d; tmp3 = fncls__241d } else { tmp3 = fncls__241 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__242, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_130)); return A_arbace_cpp_template__init_part0_A_const_129 }











func A_arbace_cpp_template__init_part0_A_Unit62__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(500, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__244 any = A_arbace_cpp_template_trait_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__243 *jrt.Class = A_arbace_cpp_template_trait_name_QMARK__A_fn_class; if fncls__243 == nil { var fncls__243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1081, false, nil); A_arbace_cpp_template_trait_name_QMARK__A_fn_class = fncls__243d; tmp3 = fncls__243d } else { tmp3 = fncls__243 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__244, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_132)); return A_arbace_cpp_template__init_part0_A_const_131 }

func A_arbace_cpp_template__init_part0_A_Unit63__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(502, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__246 any = A_arbace_cpp_template_trait_args_A_New(); var tmp3 *jrt.Class; var fncls__245 *jrt.Class = A_arbace_cpp_template_trait_args_A_fn_class; if fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1082, false, nil); A_arbace_cpp_template_trait_args_A_fn_class = fncls__245d; tmp3 = fncls__245d } else { tmp3 = fncls__245 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__246, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_134)); return A_arbace_cpp_template__init_part0_A_const_133 }






func A_arbace_cpp_template__init_part0_A_Unit64__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(509, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__248 any = A_arbace_cpp_template_trait_value_A_New(); var tmp3 *jrt.Class; var fncls__247 *jrt.Class = A_arbace_cpp_template_trait_value_A_fn_class; if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1083, false, nil); A_arbace_cpp_template_trait_value_A_fn_class = fncls__247d; tmp3 = fncls__247d } else { tmp3 = fncls__247 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__248, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_136)); return A_arbace_cpp_template__init_part0_A_const_135 }








func A_arbace_cpp_template__init_part0_A_Unit65__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(518, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__250 any = A_arbace_cpp_template_trait_type_A_New(); var tmp3 *jrt.Class; var fncls__249 *jrt.Class = A_arbace_cpp_template_trait_type_A_fn_class; if fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1084, false, nil); A_arbace_cpp_template_trait_type_A_fn_class = fncls__249d; tmp3 = fncls__249d } else { tmp3 = fncls__249 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__250, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_138)); return A_arbace_cpp_template__init_part0_A_const_137 }








func A_arbace_cpp_template__init_part0_A_Unit66__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(527, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__252 any = A_arbace_cpp_template_template_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_cpp_template_template_name_QMARK__A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1085, false, nil); A_arbace_cpp_template_template_name_QMARK__A_fn_class = fncls__251d; tmp3 = fncls__251d } else { tmp3 = fncls__251 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__252, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_140)); return A_arbace_cpp_template__init_part0_A_const_139 }



func A_arbace_cpp_template__init_part0_A_Unit67__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__254 any = A_arbace_cpp_template_qualified_template_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__253 *jrt.Class = A_arbace_cpp_template_qualified_template_name_QMARK__A_fn_class; if fncls__253 == nil { var fncls__253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1086, false, nil); A_arbace_cpp_template_qualified_template_name_QMARK__A_fn_class = fncls__253d; tmp3 = fncls__253d } else { tmp3 = fncls__253 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__254, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_142)); return A_arbace_cpp_template__init_part0_A_const_141 }








func A_arbace_cpp_template__init_part0_A_Unit68__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(540, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_143; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_144)); return A_arbace_cpp_template__init_part0_A_const_143 }
//line :540:1
func A_arbace_cpp_template__init_part0_A_Unit69__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(540, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_145; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_146)); return A_arbace_cpp_template__init_part0_A_const_145 }
//line :540:1
func A_arbace_cpp_template__init_part0_A_Unit70__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(540, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_147; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_148)); return A_arbace_cpp_template__init_part0_A_const_147 }

func A_arbace_cpp_template__init_part0_A_Unit71__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(542, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__256 any = A_arbace_cpp_template_eval_text_A_New(); var tmp3 *jrt.Class; var fncls__255 *jrt.Class = A_arbace_cpp_template_eval_text_A_fn_class; if fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1087, false, nil); A_arbace_cpp_template_eval_text_A_fn_class = fncls__255d; tmp3 = fncls__255d } else { tmp3 = fncls__255 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__256, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_150)); return A_arbace_cpp_template__init_part0_A_const_149 }































































































































































































func A_arbace_cpp_template__init_part0_A_Unit72__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(734, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_151; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_152)); return A_arbace_cpp_template__init_part0_A_const_151 }
//line :734:1
func A_arbace_cpp_template__init_part0_A_Unit73__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(734, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_153; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_154)); return A_arbace_cpp_template__init_part0_A_const_153 }
//line :734:1
func A_arbace_cpp_template__init_part0_A_Unit74__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(734, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_155; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_156)); return A_arbace_cpp_template__init_part0_A_const_155 }
//line :734:1
func A_arbace_cpp_template__init_part0_A_Unit75__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(734, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_157; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_158)); return A_arbace_cpp_template__init_part0_A_const_157 }
//line :734:1
func A_arbace_cpp_template__init_part0_A_Unit76__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(734, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_159; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_160)); return A_arbace_cpp_template__init_part0_A_const_159 }

func A_arbace_cpp_template__init_part0_A_Unit77__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(736, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__258 any = A_arbace_cpp_template_static_call_value_A_New(); var tmp3 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_cpp_template_static_call_value_A_fn_class; if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1088, false, nil); A_arbace_cpp_template_static_call_value_A_fn_class = fncls__257d; tmp3 = fncls__257d } else { tmp3 = fncls__257 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__258, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_161)); return A_arbace_cpp_template__init_part0_A_const_143 }


































func A_arbace_cpp_template__init_part0_A_Unit78__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(771, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__260 any = A_arbace_cpp_template_written_qualifier_A_New(); var tmp3 *jrt.Class; var fncls__259 *jrt.Class = A_arbace_cpp_template_written_qualifier_A_fn_class; if fncls__259 == nil { var fncls__259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1089, false, nil); A_arbace_cpp_template_written_qualifier_A_fn_class = fncls__259d; tmp3 = fncls__259d } else { tmp3 = fncls__259 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__260, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_162)); return A_arbace_cpp_template__init_part0_A_const_159 }














func A_arbace_cpp_template__init_part0_A_Unit79__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(786, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__262 any = A_arbace_cpp_template_concept_named_A_New(); var tmp3 *jrt.Class; var fncls__261 *jrt.Class = A_arbace_cpp_template_concept_named_A_fn_class; if fncls__261 == nil { var fncls__261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1090, false, nil); A_arbace_cpp_template_concept_named_A_fn_class = fncls__261d; tmp3 = fncls__261d } else { tmp3 = fncls__261 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__262, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_164)); return A_arbace_cpp_template__init_part0_A_const_163 }






func A_arbace_cpp_template__init_part0_A_Unit80__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(793, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_165; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_166)); return A_arbace_cpp_template__init_part0_A_const_165 }

func A_arbace_cpp_template__init_part0_A_Unit81__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(795, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__264 any = A_arbace_cpp_template_const_form_A_New(); var tmp3 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_cpp_template_const_form_A_fn_class; if fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1091, false, nil); A_arbace_cpp_template_const_form_A_fn_class = fncls__263d; tmp3 = fncls__263d } else { tmp3 = fncls__263 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__264, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_167)); return A_arbace_cpp_template__init_part0_A_const_147 }
































































func A_arbace_cpp_template__init_part0_A_Unit82__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(860, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_168; var tmp2 *lang.Compiler_AOTFn; var fnbody__266 any = A_arbace_cpp_template_value_arg_A_New(); var tmp3 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_cpp_template_value_arg_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1092, false, nil); A_arbace_cpp_template_value_arg_A_fn_class = fncls__265d; tmp3 = fncls__265d } else { tmp3 = fncls__265 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__266, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_169)); return A_arbace_cpp_template__init_part0_A_const_168 }


func A_arbace_cpp_template__init_part0_A_Unit83__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(863, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__268 any = A_arbace_cpp_template_template_arg_of_A_New(); var tmp3 *jrt.Class; var fncls__267 *jrt.Class = A_arbace_cpp_template_template_arg_of_A_fn_class; if fncls__267 == nil { var fncls__267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1093, false, nil); A_arbace_cpp_template_template_arg_of_A_fn_class = fncls__267d; tmp3 = fncls__267d } else { tmp3 = fncls__267 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__268, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_171)); return A_arbace_cpp_template__init_part0_A_const_170 }
































func A_arbace_cpp_template__init_part0_A_Unit84__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(896, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__270 any = A_arbace_cpp_template_decl_arg_A_New(); var tmp3 *jrt.Class; var fncls__269 *jrt.Class = A_arbace_cpp_template_decl_arg_A_fn_class; if fncls__269 == nil { var fncls__269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1094, false, nil); A_arbace_cpp_template_decl_arg_A_fn_class = fncls__269d; tmp3 = fncls__269d } else { tmp3 = fncls__269 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__270, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_173)); return A_arbace_cpp_template__init_part0_A_const_172 }













































func A_arbace_cpp_template__init_part0_A_Unit85__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(942, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_53; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__272 any = A_arbace_cpp_template_resolve_arg_A_New(); var tmp3 *jrt.Class; var fncls__271 *jrt.Class = A_arbace_cpp_template_resolve_arg_A_fn_class; if fncls__271 == nil { var fncls__271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1095, true, nil); A_arbace_cpp_template_resolve_arg_A_fn_class = fncls__271d; tmp3 = fncls__271d } else { tmp3 = fncls__271 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__272, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_174)); return A_arbace_cpp_template__init_part0_A_const_53 }










func A_arbace_cpp_template__init_part0_A_Unit86__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(953, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__274 any = A_arbace_cpp_template_node_arg_A_New(); var tmp3 *jrt.Class; var fncls__273 *jrt.Class = A_arbace_cpp_template_node_arg_A_fn_class; if fncls__273 == nil { var fncls__273d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1096, false, nil); A_arbace_cpp_template_node_arg_A_fn_class = fncls__273d; tmp3 = fncls__273d } else { tmp3 = fncls__273 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__274, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_176)); return A_arbace_cpp_template__init_part0_A_const_175 }









func A_arbace_cpp_template__init_part0_A_Unit87__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(963, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_177; var tmp2 *lang.Compiler_AOTFn; var fnbody__276 any = A_arbace_cpp_template_inherit_default_A_New(); var tmp3 *jrt.Class; var fncls__275 *jrt.Class = A_arbace_cpp_template_inherit_default_A_fn_class; if fncls__275 == nil { var fncls__275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1097, false, nil); A_arbace_cpp_template_inherit_default_A_fn_class = fncls__275d; tmp3 = fncls__275d } else { tmp3 = fncls__275 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__276, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_178)); return A_arbace_cpp_template__init_part0_A_const_177 }










func A_arbace_cpp_template__init_part0_A_Unit88__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(974, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_153; var tmp2 *lang.Compiler_AOTFn; var fnbody__278 any = A_arbace_cpp_template_complete_args_A_New(); var tmp3 *jrt.Class; var fncls__277 *jrt.Class = A_arbace_cpp_template_complete_args_A_fn_class; if fncls__277 == nil { var fncls__277d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1098, false, nil); A_arbace_cpp_template_complete_args_A_fn_class = fncls__277d; tmp3 = fncls__277d } else { tmp3 = fncls__277 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__278, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_179)); return A_arbace_cpp_template__init_part0_A_const_153 }































func A_arbace_cpp_template__init_part0_A_Unit89__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1006, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_180; var tmp2 *lang.Compiler_AOTFn; var fnbody__280 any = A_arbace_cpp_template_form_symbols_A_New(); var tmp3 *jrt.Class; var fncls__279 *jrt.Class = A_arbace_cpp_template_form_symbols_A_fn_class; if fncls__279 == nil { var fncls__279d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1099, false, nil); A_arbace_cpp_template_form_symbols_A_fn_class = fncls__279d; tmp3 = fncls__279d } else { tmp3 = fncls__279 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__280, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_181)); return A_arbace_cpp_template__init_part0_A_const_180 }







func A_arbace_cpp_template__init_part0_A_Unit90__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1014, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__282 any = A_arbace_cpp_template_packs_named_A_New(); var tmp3 *jrt.Class; var fncls__281 *jrt.Class = A_arbace_cpp_template_packs_named_A_fn_class; if fncls__281 == nil { var fncls__281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1100, false, nil); A_arbace_cpp_template_packs_named_A_fn_class = fncls__281d; tmp3 = fncls__281d } else { tmp3 = fncls__281 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__282, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_182)); return A_arbace_cpp_template__init_part0_A_const_145 }







func A_arbace_cpp_template__init_part0_A_Unit91__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1022, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_183; var tmp2 *lang.Compiler_AOTFn; var fnbody__284 any = A_arbace_cpp_template_elementwise_A_New(); var tmp3 *jrt.Class; var fncls__283 *jrt.Class = A_arbace_cpp_template_elementwise_A_fn_class; if fncls__283 == nil { var fncls__283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1101, false, nil); A_arbace_cpp_template_elementwise_A_fn_class = fncls__283d; tmp3 = fncls__283d } else { tmp3 = fncls__283 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__284, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_184)); return A_arbace_cpp_template__init_part0_A_const_183 }










func A_arbace_cpp_template__init_part0_A_Unit92__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1033, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__286 any = A_arbace_cpp_template_expand_type_pack_A_New(); var tmp3 *jrt.Class; var fncls__285 *jrt.Class = A_arbace_cpp_template_expand_type_pack_A_fn_class; if fncls__285 == nil { var fncls__285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1102, false, nil); A_arbace_cpp_template_expand_type_pack_A_fn_class = fncls__285d; tmp3 = fncls__285d } else { tmp3 = fncls__285 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__286, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_185)); return A_arbace_cpp_template__init_part0_A_const_93 }










func A_arbace_cpp_template__init_part0_A_Unit93__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1044, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_186; var tmp2 *lang.Compiler_AOTFn; var fnbody__288 any = A_arbace_cpp_template_expand_expr_pack_A_New(); var tmp3 *jrt.Class; var fncls__287 *jrt.Class = A_arbace_cpp_template_expand_expr_pack_A_fn_class; if fncls__287 == nil { var fncls__287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1103, false, nil); A_arbace_cpp_template_expand_expr_pack_A_fn_class = fncls__287d; tmp3 = fncls__287d } else { tmp3 = fncls__287 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__288, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_187)); return A_arbace_cpp_template__init_part0_A_const_186 }








func A_arbace_cpp_template__init_part0_A_Unit94__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1053, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_151; var tmp2 *lang.Compiler_AOTFn; var fnbody__290 any = A_arbace_cpp_template_resolve_args_A_New(); var tmp3 *jrt.Class; var fncls__289 *jrt.Class = A_arbace_cpp_template_resolve_args_A_fn_class; if fncls__289 == nil { var fncls__289d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1104, false, nil); A_arbace_cpp_template_resolve_args_A_fn_class = fncls__289d; tmp3 = fncls__289d } else { tmp3 = fncls__289 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__290, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_188)); return A_arbace_cpp_template__init_part0_A_const_151 }






































func A_arbace_cpp_template__init_part0_A_Unit95__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1092, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_189; var tmp2 *lang.Compiler_AOTFn; var fnbody__292 any = A_arbace_cpp_template_tparam_of_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__291 *jrt.Class = A_arbace_cpp_template_tparam_of_QMARK__A_fn_class; if fncls__291 == nil { var fncls__291d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1105, false, nil); A_arbace_cpp_template_tparam_of_QMARK__A_fn_class = fncls__291d; tmp3 = fncls__291d } else { tmp3 = fncls__291 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__292, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_189; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_190)); return A_arbace_cpp_template__init_part0_A_const_189 }


func A_arbace_cpp_template__init_part0_A_Unit96__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1095, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_191; var tmp2 *lang.Compiler_AOTFn; var fnbody__294 any = A_arbace_cpp_template_arr_cv_A_New(); var tmp3 *jrt.Class; var fncls__293 *jrt.Class = A_arbace_cpp_template_arr_cv_A_fn_class; if fncls__293 == nil { var fncls__293d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1106, false, nil); A_arbace_cpp_template_arr_cv_A_fn_class = fncls__293d; tmp3 = fncls__293d } else { tmp3 = fncls__293 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__294, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_191; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_192)); return A_arbace_cpp_template__init_part0_A_const_191 }
func A_arbace_cpp_template__init_part0_A_Unit97__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1096, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_193; var tmp2 *lang.Compiler_AOTFn; var fnbody__296 any = A_arbace_cpp_template_quals_A_New(); var tmp3 *jrt.Class; var fncls__295 *jrt.Class = A_arbace_cpp_template_quals_A_fn_class; if fncls__295 == nil { var fncls__295d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1107, false, nil); A_arbace_cpp_template_quals_A_fn_class = fncls__295d; tmp3 = fncls__295d } else { tmp3 = fncls__295 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__296, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_193; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_194)); return A_arbace_cpp_template__init_part0_A_const_193 }
func A_arbace_cpp_template__init_part0_A_Unit98__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1097, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_195; var tmp2 *lang.Compiler_AOTFn; var fnbody__298 any = A_arbace_cpp_template_unq_array_A_New(); var tmp3 *jrt.Class; var fncls__297 *jrt.Class = A_arbace_cpp_template_unq_array_A_fn_class; if fncls__297 == nil { var fncls__297d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1108, false, nil); A_arbace_cpp_template_unq_array_A_fn_class = fncls__297d; tmp3 = fncls__297d } else { tmp3 = fncls__297 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__298, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_195; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_196)); return A_arbace_cpp_template__init_part0_A_const_195 }
func A_arbace_cpp_template__init_part0_A_Unit99__O() any { A_arbace_cpp_template__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1098, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part0_A_const_197; var tmp2 *lang.Compiler_AOTFn; var fnbody__300 any = A_arbace_cpp_template_with_quals_A_New(); var tmp3 *jrt.Class; var fncls__299 *jrt.Class = A_arbace_cpp_template_with_quals_A_fn_class; if fncls__299 == nil { var fncls__299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1109, false, nil); A_arbace_cpp_template_with_quals_A_fn_class = fncls__299d; tmp3 = fncls__299d } else { tmp3 = fncls__299 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__300, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part0_A_const_197; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part0_A_const_198)); return A_arbace_cpp_template__init_part0_A_const_197 }

func A_arbace_cpp_template__init_part1_A_Unit100__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1100, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_template_inconsistent_or_superset_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_template_inconsistent_or_superset_QMARK__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1111, false, nil); A_arbace_cpp_template_inconsistent_or_superset_QMARK__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_1)); return A_arbace_cpp_template__init_part1_A_const_0 }
//line :1100:1
func A_arbace_cpp_template__init_part1_A_Init__O() any { A_arbace_cpp_template__init_part1_A_Init(); return nil }
//line :1100:1
func A_arbace_cpp_template__init_part1_A_Load__O() any { A_arbace_cpp_template__init_part1_A_Init(); A_arbace_cpp_template__init_part1_A_Unit100__O(); A_arbace_cpp_template__init_part1_A_Unit101__O(); A_arbace_cpp_template__init_part1_A_Unit102__O(); A_arbace_cpp_template__init_part1_A_Unit103__O(); A_arbace_cpp_template__init_part1_A_Unit104__O(); A_arbace_cpp_template__init_part1_A_Unit105__O(); A_arbace_cpp_template__init_part1_A_Unit106__O(); A_arbace_cpp_template__init_part1_A_Unit107__O(); A_arbace_cpp_template__init_part1_A_Unit108__O(); A_arbace_cpp_template__init_part1_A_Unit109__O(); A_arbace_cpp_template__init_part1_A_Unit110__O(); A_arbace_cpp_template__init_part1_A_Unit111__O(); A_arbace_cpp_template__init_part1_A_Unit112__O(); A_arbace_cpp_template__init_part1_A_Unit113__O(); A_arbace_cpp_template__init_part1_A_Unit114__O(); A_arbace_cpp_template__init_part1_A_Unit115__O(); A_arbace_cpp_template__init_part1_A_Unit116__O(); A_arbace_cpp_template__init_part1_A_Unit117__O(); A_arbace_cpp_template__init_part1_A_Unit118__O(); A_arbace_cpp_template__init_part1_A_Unit119__O(); A_arbace_cpp_template__init_part1_A_Unit120__O(); A_arbace_cpp_template__init_part1_A_Unit121__O(); A_arbace_cpp_template__init_part1_A_Unit122__O(); A_arbace_cpp_template__init_part1_A_Unit123__O(); A_arbace_cpp_template__init_part1_A_Unit124__O(); A_arbace_cpp_template__init_part1_A_Unit125__O(); A_arbace_cpp_template__init_part1_A_Unit126__O(); A_arbace_cpp_template__init_part1_A_Unit127__O(); A_arbace_cpp_template__init_part1_A_Unit128__O(); A_arbace_cpp_template__init_part1_A_Unit129__O(); A_arbace_cpp_template__init_part1_A_Unit130__O(); A_arbace_cpp_template__init_part1_A_Unit131__O(); A_arbace_cpp_template__init_part1_A_Unit132__O(); A_arbace_cpp_template__init_part1_A_Unit133__O(); A_arbace_cpp_template__init_part1_A_Unit134__O(); A_arbace_cpp_template__init_part1_A_Unit135__O(); A_arbace_cpp_template__init_part1_A_Unit136__O(); A_arbace_cpp_template__init_part1_A_Unit137__O(); A_arbace_cpp_template__init_part1_A_Unit138__O(); A_arbace_cpp_template__init_part1_A_Unit139__O(); A_arbace_cpp_template__init_part1_A_Unit140__O(); A_arbace_cpp_template__init_part1_A_Unit141__O(); A_arbace_cpp_template__init_part1_A_Unit142__O(); A_arbace_cpp_template__init_part1_A_Unit143__O(); A_arbace_cpp_template__init_part1_A_Unit144__O(); A_arbace_cpp_template__init_part1_A_Unit145__O(); A_arbace_cpp_template__init_part1_A_Unit146__O(); A_arbace_cpp_template__init_part1_A_Unit147__O(); A_arbace_cpp_template__init_part1_A_Unit148__O(); A_arbace_cpp_template__init_part1_A_Unit149__O(); A_arbace_cpp_template__init_part1_A_Unit150__O(); A_arbace_cpp_template__init_part1_A_Unit151__O(); A_arbace_cpp_template__init_part1_A_Unit152__O(); A_arbace_cpp_template__init_part1_A_Unit153__O(); A_arbace_cpp_template__init_part1_A_Unit154__O(); A_arbace_cpp_template__init_part1_A_Unit155__O(); A_arbace_cpp_template__init_part1_A_Unit156__O(); A_arbace_cpp_template__init_part1_A_Unit157__O(); A_arbace_cpp_template__init_part1_A_Unit158__O(); A_arbace_cpp_template__init_part1_A_Unit159__O(); A_arbace_cpp_template__init_part1_A_Unit160__O(); A_arbace_cpp_template__init_part1_A_Unit161__O(); A_arbace_cpp_template__init_part1_A_Unit162__O(); A_arbace_cpp_template__init_part1_A_Unit163__O(); A_arbace_cpp_template__init_part1_A_Unit164__O(); A_arbace_cpp_template__init_part1_A_Unit165__O(); A_arbace_cpp_template__init_part1_A_Unit166__O(); A_arbace_cpp_template__init_part1_A_Unit167__O(); A_arbace_cpp_template__init_part1_A_Unit168__O(); A_arbace_cpp_template__init_part1_A_Unit169__O(); A_arbace_cpp_template__init_part1_A_Unit170__O(); A_arbace_cpp_template__init_part1_A_Unit171__O(); A_arbace_cpp_template__init_part1_A_Unit172__O(); A_arbace_cpp_template__init_part1_A_Unit173__O(); A_arbace_cpp_template__init_part1_A_Unit174__O(); A_arbace_cpp_template__init_part1_A_Unit175__O(); A_arbace_cpp_template__init_part1_A_Unit176__O(); A_arbace_cpp_template__init_part1_A_Unit177__O(); A_arbace_cpp_template__init_part1_A_Unit178__O(); A_arbace_cpp_template__init_part1_A_Unit179__O(); A_arbace_cpp_template__init_part1_A_Unit180__O(); A_arbace_cpp_template__init_part1_A_Unit181__O(); A_arbace_cpp_template__init_part1_A_Unit182__O(); A_arbace_cpp_template__init_part1_A_Unit183__O(); A_arbace_cpp_template__init_part1_A_Unit184__O(); A_arbace_cpp_template__init_part1_A_Unit185__O(); A_arbace_cpp_template__init_part1_A_Unit186__O(); A_arbace_cpp_template__init_part1_A_Unit187__O(); A_arbace_cpp_template__init_part1_A_Unit188__O(); A_arbace_cpp_template__init_part1_A_Unit189__O(); A_arbace_cpp_template__init_part1_A_Unit190__O(); A_arbace_cpp_template__init_part1_A_Unit191__O(); A_arbace_cpp_template__init_part1_A_Unit192__O(); A_arbace_cpp_template__init_part1_A_Unit193__O(); A_arbace_cpp_template__init_part1_A_Unit194__O(); A_arbace_cpp_template__init_part1_A_Unit195__O(); A_arbace_cpp_template__init_part1_A_Unit196__O(); A_arbace_cpp_template__init_part1_A_Unit197__O(); A_arbace_cpp_template__init_part1_A_Unit198__O(); A_arbace_cpp_template__init_part1_A_Unit199__O(); return nil }



func A_arbace_cpp_template__init_part1_A_Unit101__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1104, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_template_canonical_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_template_canonical_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1112, false, nil); A_arbace_cpp_template_canonical_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_3)); return A_arbace_cpp_template__init_part1_A_const_2 }





func A_arbace_cpp_template__init_part1_A_Unit102__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1110, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_template_unspelled_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_template_unspelled_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1113, false, nil); A_arbace_cpp_template_unspelled_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_5)); return A_arbace_cpp_template__init_part1_A_const_4 }






func A_arbace_cpp_template__init_part1_A_Unit103__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1117, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_7)); return A_arbace_cpp_template__init_part1_A_const_6 }
func A_arbace_cpp_template__init_part1_A_Unit104__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1118, 1); A_arbace_cpp_template__init_part1_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_9)); return A_arbace_cpp_template__init_part1_A_const_8.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_template__init_part1_A_Unit105__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1119, 1); A_arbace_cpp_template__init_part1_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_11)); return A_arbace_cpp_template__init_part1_A_const_10.SetDynamic_Z__Var(true).Ref() }







func A_arbace_cpp_template__init_part1_A_Unit106__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1127, 1); A_arbace_cpp_template__init_part1_A_const_12.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_13)); return A_arbace_cpp_template__init_part1_A_const_12.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_template__init_part1_A_Unit107__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1128, 1); A_arbace_cpp_template__init_part1_A_const_14.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_15)); return A_arbace_cpp_template__init_part1_A_const_14.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_template__init_part1_A_Unit108__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1129, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_template_unsure_BANG__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_template_unsure_BANG__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1114, false, nil); A_arbace_cpp_template_unsure_BANG__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_17)); return A_arbace_cpp_template__init_part1_A_const_16 }
func A_arbace_cpp_template__init_part1_A_Unit109__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1130, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_template_sure_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_template_sure_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1115, false, nil); A_arbace_cpp_template_sure_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_19)); return A_arbace_cpp_template__init_part1_A_const_18 }

func A_arbace_cpp_template__init_part1_A_Unit110__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1132, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_template_bind_arg_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_template_bind_arg_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1116, false, nil); A_arbace_cpp_template_bind_arg_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_21)); return A_arbace_cpp_template__init_part1_A_const_20 }





func A_arbace_cpp_template__init_part1_A_Unit111__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1138, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_template_subst_value_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_template_subst_value_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1117, false, nil); A_arbace_cpp_template_subst_value_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_23)); return A_arbace_cpp_template__init_part1_A_const_22 }









func A_arbace_cpp_template__init_part1_A_Unit112__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1148, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_template_dependent_on_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_template_dependent_on_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1118, false, nil); A_arbace_cpp_template_dependent_on_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_25)); return A_arbace_cpp_template__init_part1_A_const_24 }

func A_arbace_cpp_template__init_part1_A_Unit113__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1150, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_27)); return A_arbace_cpp_template__init_part1_A_const_26 }

func A_arbace_cpp_template__init_part1_A_Unit114__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1152, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_template_match_arg_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_template_match_arg_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1119, false, nil); A_arbace_cpp_template_match_arg_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_29)); return A_arbace_cpp_template__init_part1_A_const_28 }













func A_arbace_cpp_template__init_part1_A_Unit115__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1166, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_template_pack_pattern_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_template_pack_pattern_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1120, false, nil); A_arbace_cpp_template_pack_pattern_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_31)); return A_arbace_cpp_template__init_part1_A_const_30 }




func A_arbace_cpp_template__init_part1_A_Unit116__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1171, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_template_match_args_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_template_match_args_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1121, false, nil); A_arbace_cpp_template_match_args_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_32)); return A_arbace_cpp_template__init_part1_A_const_26 }

















func A_arbace_cpp_template__init_part1_A_Unit117__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1189, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_template_deduce_template_spec_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_template_deduce_template_spec_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1122, false, nil); A_arbace_cpp_template_deduce_template_spec_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_34)); return A_arbace_cpp_template__init_part1_A_const_33 }
































func A_arbace_cpp_template__init_part1_A_Unit118__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_template_deduce_by_type_match_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_template_deduce_by_type_match_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1123, false, nil); A_arbace_cpp_template_deduce_by_type_match_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_35)); return A_arbace_cpp_template__init_part1_A_const_6 }

















































































func A_arbace_cpp_template__init_part1_A_Unit119__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1304, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_template_deduce_type_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_template_deduce_type_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1124, false, nil); A_arbace_cpp_template_deduce_type_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_37)); return A_arbace_cpp_template__init_part1_A_const_36 }

func A_arbace_cpp_template__init_part1_A_Unit120__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1306, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_template_sym_scope_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_template_sym_scope_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1125, false, nil); A_arbace_cpp_template_sym_scope_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_39)); return A_arbace_cpp_template__init_part1_A_const_38 }

func A_arbace_cpp_template__init_part1_A_Unit121__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1308, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_template_sym_sig_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_template_sym_sig_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1126, false, nil); A_arbace_cpp_template_sym_sig_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_41)); return A_arbace_cpp_template__init_part1_A_const_40 }













func A_arbace_cpp_template__init_part1_A_Unit122__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1322, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_template_finish_deduction_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_template_finish_deduction_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1127, false, nil); A_arbace_cpp_template_finish_deduction_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_43)); return A_arbace_cpp_template__init_part1_A_const_42 }


























func A_arbace_cpp_template__init_part1_A_Unit123__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1349, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_template_explicit_args_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_template_explicit_args_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1128, false, nil); A_arbace_cpp_template_explicit_args_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_45)); return A_arbace_cpp_template__init_part1_A_const_44 }








func A_arbace_cpp_template__init_part1_A_Unit124__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_template_forwarding_reference_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_template_forwarding_reference_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1129, false, nil); A_arbace_cpp_template_forwarding_reference_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_47)); return A_arbace_cpp_template__init_part1_A_const_46 }




func A_arbace_cpp_template__init_part1_A_Unit125__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1363, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_template_simple_template_id_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_template_simple_template_id_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1130, false, nil); A_arbace_cpp_template_simple_template_id_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_49)); return A_arbace_cpp_template__init_part1_A_const_48 }

func A_arbace_cpp_template__init_part1_A_Unit126__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1365, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_template_adjust_for_deduction_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_template_adjust_for_deduction_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1131, false, nil); A_arbace_cpp_template_adjust_for_deduction_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_51)); return A_arbace_cpp_template__init_part1_A_const_50 }






















func A_arbace_cpp_template__init_part1_A_Unit127__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1388, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_template_tparams_in_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_template_tparams_in_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1132, false, nil); A_arbace_cpp_template_tparams_in_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_53)); return A_arbace_cpp_template__init_part1_A_const_52 }


func A_arbace_cpp_template__init_part1_A_Unit128__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1391, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_template_deducible_tparams_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_template_deducible_tparams_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1133, false, nil); A_arbace_cpp_template_deducible_tparams_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_55)); return A_arbace_cpp_template__init_part1_A_const_54 }











func A_arbace_cpp_template__init_part1_A_Unit129__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1403, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_template_deduce_call_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_template_deduce_call_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1134, false, nil); A_arbace_cpp_template_deduce_call_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_57)); return A_arbace_cpp_template__init_part1_A_const_56 }










































































func A_arbace_cpp_template__init_part1_A_Unit130__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1478, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_58; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_59)); return A_arbace_cpp_template__init_part1_A_const_58 }

func A_arbace_cpp_template__init_part1_A_Unit131__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1480, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_template_fnaddr_specs_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_template_fnaddr_specs_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1135, false, nil); A_arbace_cpp_template_fnaddr_specs_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_61)); return A_arbace_cpp_template__init_part1_A_const_60 }


















func A_arbace_cpp_template__init_part1_A_Unit132__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1499, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_template_at_least_as_specialized_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_template_at_least_as_specialized_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1136, false, nil); A_arbace_cpp_template_at_least_as_specialized_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_63)); return A_arbace_cpp_template__init_part1_A_const_62 }















func A_arbace_cpp_template__init_part1_A_Unit133__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1515, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_65)); return A_arbace_cpp_template__init_part1_A_const_64 }





func A_arbace_cpp_template__init_part1_A_Unit134__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1521, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_template_concept_ref_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_template_concept_ref_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1137, false, nil); A_arbace_cpp_template_concept_ref_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_67)); return A_arbace_cpp_template__init_part1_A_const_66 }

















func A_arbace_cpp_template__init_part1_A_Unit135__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1539, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_template_normal_form_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_template_normal_form_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1138, false, nil); A_arbace_cpp_template_normal_form_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_69)); return A_arbace_cpp_template__init_part1_A_const_68 }

















func A_arbace_cpp_template__init_part1_A_Unit136__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1557, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_template_associated_constraints_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_template_associated_constraints_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1139, false, nil); A_arbace_cpp_template_associated_constraints_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_71)); return A_arbace_cpp_template__init_part1_A_const_70 }















func A_arbace_cpp_template__init_part1_A_Unit137__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1573, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_template_dnf_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_template_dnf_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1140, false, nil); A_arbace_cpp_template_dnf_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_73)); return A_arbace_cpp_template__init_part1_A_const_72 }





func A_arbace_cpp_template__init_part1_A_Unit138__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1579, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_template_cnf_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_template_cnf_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1141, false, nil); A_arbace_cpp_template_cnf_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_75)); return A_arbace_cpp_template__init_part1_A_const_74 }





func A_arbace_cpp_template__init_part1_A_Unit139__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1585, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_template_subsumes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_template_subsumes_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1142, false, nil); A_arbace_cpp_template_subsumes_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_77)); return A_arbace_cpp_template__init_part1_A_const_76 }








func A_arbace_cpp_template__init_part1_A_Unit140__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1594, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_template_more_constrained_fn_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_template_more_constrained_fn_QMARK__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1143, false, nil); A_arbace_cpp_template_more_constrained_fn_QMARK__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_79)); return A_arbace_cpp_template__init_part1_A_const_78 }












func A_arbace_cpp_template__init_part1_A_Unit141__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1607, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_template_more_specialized_fn_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_template_more_specialized_fn_QMARK__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1144, false, nil); A_arbace_cpp_template_more_specialized_fn_QMARK__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_81)); return A_arbace_cpp_template__init_part1_A_const_80 }

















func A_arbace_cpp_template__init_part1_A_Unit142__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1625, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_82; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__70 any = A_arbace_cpp_template_tiebreak_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_template_tiebreak_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1145, true, nil); A_arbace_cpp_template_tiebreak_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__70, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_83)); return A_arbace_cpp_template__init_part1_A_const_82 }
































func A_arbace_cpp_template__init_part1_A_Unit143__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1658, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_85)); return A_arbace_cpp_template__init_part1_A_const_84 }
//line :1658:1
func A_arbace_cpp_template__init_part1_A_Unit144__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1658, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_87)); return A_arbace_cpp_template__init_part1_A_const_86 }
//line :1658:1
func A_arbace_cpp_template__init_part1_A_Unit145__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1658, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_58; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_88)); return A_arbace_cpp_template__init_part1_A_const_58 }

func A_arbace_cpp_template__init_part1_A_Unit146__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1660, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_89; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_90)); return A_arbace_cpp_template__init_part1_A_const_89 }

func A_arbace_cpp_template__init_part1_A_Unit147__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1662, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_template_declare_instance_BANG__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_template_declare_instance_BANG__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1146, false, nil); A_arbace_cpp_template_declare_instance_BANG__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_92)); return A_arbace_cpp_template__init_part1_A_const_91 }


























































func A_arbace_cpp_template__init_part1_A_Unit148__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1721, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_cpp_template_class_completed_BANG__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_template_class_completed_BANG__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1147, false, nil); A_arbace_cpp_template_class_completed_BANG__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_94)); return A_arbace_cpp_template__init_part1_A_const_93 }
































func A_arbace_cpp_template__init_part1_A_Unit149__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1754, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_95; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_96)); return A_arbace_cpp_template__init_part1_A_const_95 }

func A_arbace_cpp_template__init_part1_A_Unit150__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1756, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_template_partial_args_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_template_partial_args_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1148, false, nil); A_arbace_cpp_template_partial_args_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_98)); return A_arbace_cpp_template__init_part1_A_const_97 }












func A_arbace_cpp_template__init_part1_A_Unit151__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1769, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_cpp_template_partial_match_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_cpp_template_partial_match_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1149, false, nil); A_arbace_cpp_template_partial_match_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_100)); return A_arbace_cpp_template__init_part1_A_const_99 }




































func A_arbace_cpp_template__init_part1_A_Unit152__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1806, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_cpp_template_partial_constraints_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_cpp_template_partial_constraints_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1150, false, nil); A_arbace_cpp_template_partial_constraints_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_102)); return A_arbace_cpp_template__init_part1_A_const_101 }














func A_arbace_cpp_template__init_part1_A_Unit153__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1821, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_template_more_constrained_partial_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_template_more_constrained_partial_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1151, false, nil); A_arbace_cpp_template_more_constrained_partial_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_104)); return A_arbace_cpp_template__init_part1_A_const_103 }










func A_arbace_cpp_template__init_part1_A_Unit154__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1832, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_template_more_specialized_partial_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_template_more_specialized_partial_QMARK__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1152, false, nil); A_arbace_cpp_template_more_specialized_partial_QMARK__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_106)); return A_arbace_cpp_template__init_part1_A_const_105 }













func A_arbace_cpp_template__init_part1_A_Unit155__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1846, 1); A_arbace_cpp_template__init_part1_A_const_107.BindRoot_O__V(A_arbace_cpp_template__init_part1_A_const_108); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_107; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_109)); return A_arbace_cpp_template__init_part1_A_const_107.SetDynamic_Z__Var(true).Ref() }




func A_arbace_cpp_template__init_part1_A_Unit156__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1851, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_110; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_111)); return A_arbace_cpp_template__init_part1_A_const_110 }
//line :1851:1
func A_arbace_cpp_template__init_part1_A_Unit157__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1851, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_113)); return A_arbace_cpp_template__init_part1_A_const_112 }
//line :1851:1
func A_arbace_cpp_template__init_part1_A_Unit158__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1851, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_114; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_115)); return A_arbace_cpp_template__init_part1_A_const_114 }

func A_arbace_cpp_template__init_part1_A_Unit159__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1853, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_cpp_template_instantiate_class_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_cpp_template_instantiate_class_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1153, false, nil); A_arbace_cpp_template_instantiate_class_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_117)); return A_arbace_cpp_template__init_part1_A_const_116 }














func A_arbace_cpp_template__init_part1_A_Unit160__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1868, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_cpp_template_instantiate_class_STAR__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_cpp_template_instantiate_class_STAR__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1154, false, nil); A_arbace_cpp_template_instantiate_class_STAR__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_118)); return A_arbace_cpp_template__init_part1_A_const_110 }
















func A_arbace_cpp_template__init_part1_A_Unit161__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1885, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_template_select_instance_BANG__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_template_select_instance_BANG__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1155, false, nil); A_arbace_cpp_template_select_instance_BANG__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_119)); return A_arbace_cpp_template__init_part1_A_const_112 }


























func A_arbace_cpp_template__init_part1_A_Unit162__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1912, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_template_incomplete_instance_BANG__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_template_incomplete_instance_BANG__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1156, false, nil); A_arbace_cpp_template_incomplete_instance_BANG__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_120)); return A_arbace_cpp_template__init_part1_A_const_114 }

















func A_arbace_cpp_template__init_part1_A_Unit163__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1930, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_template_drop_layouts_BANG__A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_template_drop_layouts_BANG__A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1157, false, nil); A_arbace_cpp_template_drop_layouts_BANG__A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_122)); return A_arbace_cpp_template__init_part1_A_const_121 }


func A_arbace_cpp_template__init_part1_A_Unit164__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1933, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_cpp_template_complete_instance_BANG__A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_template_complete_instance_BANG__A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1158, false, nil); A_arbace_cpp_template_complete_instance_BANG__A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_124)); return A_arbace_cpp_template__init_part1_A_const_123 }












func A_arbace_cpp_template__init_part1_A_Unit165__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1946, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_template_incomplete_waiting_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_template_incomplete_waiting_QMARK__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1159, false, nil); A_arbace_cpp_template_incomplete_waiting_QMARK__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_126)); return A_arbace_cpp_template__init_part1_A_const_125 }


func A_arbace_cpp_template__init_part1_A_Unit166__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1949, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_cpp_template_template_defined_BANG__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_template_template_defined_BANG__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1160, false, nil); A_arbace_cpp_template_template_defined_BANG__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_128)); return A_arbace_cpp_template__init_part1_A_const_127 }







func A_arbace_cpp_template__init_part1_A_Unit167__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1957, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_cpp_template_tmpl_of_entity_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_template_tmpl_of_entity_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1161, false, nil); A_arbace_cpp_template_tmpl_of_entity_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_130)); return A_arbace_cpp_template__init_part1_A_const_129 }



func A_arbace_cpp_template__init_part1_A_Unit168__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1961, 1); A_arbace_cpp_template__init_part1_A_const_131.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_131; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_132)); return A_arbace_cpp_template__init_part1_A_const_131.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_template__init_part1_A_Unit169__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1963, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_cpp_template_type_pack_element_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_cpp_template_type_pack_element_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1162, false, nil); A_arbace_cpp_template_type_pack_element_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_134)); return A_arbace_cpp_template__init_part1_A_const_133 }

















func A_arbace_cpp_template__init_part1_A_Unit170__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1981, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_135; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_136)); return A_arbace_cpp_template__init_part1_A_const_135 }

func A_arbace_cpp_template__init_part1_A_Unit171__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1983, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_cpp_template_make_integer_seq_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_cpp_template_make_integer_seq_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1163, false, nil); A_arbace_cpp_template_make_integer_seq_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_138)); return A_arbace_cpp_template__init_part1_A_const_137 }





















func A_arbace_cpp_template__init_part1_A_Unit172__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2005, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_cpp_template_template_id_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_cpp_template_template_id_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1164, false, nil); A_arbace_cpp_template_template_id_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_139)); return A_arbace_cpp_template__init_part1_A_const_135 }





















































func A_arbace_cpp_template__init_part1_A_Unit173__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_cpp_template_header_params_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_cpp_template_header_params_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1165, false, nil); A_arbace_cpp_template_header_params_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_141)); return A_arbace_cpp_template__init_part1_A_const_140 }

















func A_arbace_cpp_template__init_part1_A_Unit174__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2077, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_142; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_143)); return A_arbace_cpp_template__init_part1_A_const_142 }

func A_arbace_cpp_template__init_part1_A_Unit175__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2079, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_cpp_template_ool_class_name_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_cpp_template_ool_class_name_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1166, false, nil); A_arbace_cpp_template_ool_class_name_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_145)); return A_arbace_cpp_template__init_part1_A_const_144 }




func A_arbace_cpp_template__init_part1_A_Unit176__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2084, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_cpp_template_ool_qualifier_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_cpp_template_ool_qualifier_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1167, false, nil); A_arbace_cpp_template_ool_qualifier_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_146)); return A_arbace_cpp_template__init_part1_A_const_142 }

























func A_arbace_cpp_template__init_part1_A_Unit177__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2110, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_cpp_template_class_key_scope_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_cpp_template_class_key_scope_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1168, false, nil); A_arbace_cpp_template_class_key_scope_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_148)); return A_arbace_cpp_template__init_part1_A_const_147 }














func A_arbace_cpp_template__init_part1_A_Unit178__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2125, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_cpp_template_ool_class_template_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_cpp_template_ool_class_template_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1169, false, nil); A_arbace_cpp_template_ool_class_template_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_150)); return A_arbace_cpp_template__init_part1_A_const_149 }












func A_arbace_cpp_template__init_part1_A_Unit179__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2138, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_86; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__120 any = A_arbace_cpp_template_attach_one_BANG__A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_cpp_template_attach_one_BANG__A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1170, true, nil); A_arbace_cpp_template_attach_one_BANG__A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__120, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_151)); return A_arbace_cpp_template__init_part1_A_const_86 }

















































func A_arbace_cpp_template__init_part1_A_Unit180__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2188, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_152; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_153)); return A_arbace_cpp_template__init_part1_A_const_152 }

func A_arbace_cpp_template__init_part1_A_Unit181__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2190, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_cpp_template_attach_ool_BANG__A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_cpp_template_attach_ool_BANG__A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1171, false, nil); A_arbace_cpp_template_attach_ool_BANG__A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_154)); return A_arbace_cpp_template__init_part1_A_const_84 }








func A_arbace_cpp_template__init_part1_A_Unit182__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2199, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_cpp_template_concept_of_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_cpp_template_concept_of_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1172, false, nil); A_arbace_cpp_template_concept_of_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_155)); return A_arbace_cpp_template__init_part1_A_const_64 }








func A_arbace_cpp_template__init_part1_A_Unit183__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2208, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_cpp_template_tn_types_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_cpp_template_tn_types_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1173, false, nil); A_arbace_cpp_template_tn_types_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_157)); return A_arbace_cpp_template__init_part1_A_const_156 }














func A_arbace_cpp_template__init_part1_A_Unit184__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2223, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_cpp_template_concept_satisfied_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_cpp_template_concept_satisfied_QMARK__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1174, false, nil); A_arbace_cpp_template_concept_satisfied_QMARK__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_159)); return A_arbace_cpp_template__init_part1_A_const_158 }


































func A_arbace_cpp_template__init_part1_A_Unit185__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2258, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_cpp_template_type_constraints_satisfied_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_cpp_template_type_constraints_satisfied_QMARK__A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1175, false, nil); A_arbace_cpp_template_type_constraints_satisfied_QMARK__A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_160)); return A_arbace_cpp_template__init_part1_A_const_95 }




















func A_arbace_cpp_template__init_part1_A_Unit186__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2279, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_cpp_template_name_pack_params_BANG__A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_cpp_template_name_pack_params_BANG__A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1176, false, nil); A_arbace_cpp_template_name_pack_params_BANG__A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_161)); return A_arbace_cpp_template__init_part1_A_const_89 }















func A_arbace_cpp_template__init_part1_A_Unit187__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2295, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_cpp_template_template_depth_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_cpp_template_template_depth_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1177, false, nil); A_arbace_cpp_template_template_depth_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_163)); return A_arbace_cpp_template__init_part1_A_const_162 }








func A_arbace_cpp_template__init_part1_A_Unit188__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2304, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_164; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_cpp_template_decltype_failed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_cpp_template_decltype_failed_QMARK__A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1178, false, nil); A_arbace_cpp_template_decltype_failed_QMARK__A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_165)); return A_arbace_cpp_template__init_part1_A_const_164 }





func A_arbace_cpp_template__init_part1_A_Unit189__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2310, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_cpp_template_instantiate_fn_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_cpp_template_instantiate_fn_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1179, false, nil); A_arbace_cpp_template_instantiate_fn_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_166)); return A_arbace_cpp_template__init_part1_A_const_58 }


































































func A_arbace_cpp_template__init_part1_A_Unit190__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2377, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_cpp_template_adl_templates_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_cpp_template_adl_templates_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1180, false, nil); A_arbace_cpp_template_adl_templates_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_168)); return A_arbace_cpp_template__init_part1_A_const_167 }













func A_arbace_cpp_template__init_part1_A_Unit191__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2391, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_cpp_template_too_few_args_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_cpp_template_too_few_args_QMARK__A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1181, false, nil); A_arbace_cpp_template_too_few_args_QMARK__A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_170)); return A_arbace_cpp_template__init_part1_A_const_169 }


















func A_arbace_cpp_template__init_part1_A_Unit192__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2410, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_cpp_template_call_candidates_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_cpp_template_call_candidates_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1182, false, nil); A_arbace_cpp_template_call_candidates_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_172)); return A_arbace_cpp_template__init_part1_A_const_171 }






































func A_arbace_cpp_template__init_part1_A_Unit193__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2449, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_173; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__146 any = A_arbace_cpp_template_explicit_fn_spec_BANG__A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_cpp_template_explicit_fn_spec_BANG__A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1183, true, nil); A_arbace_cpp_template_explicit_fn_spec_BANG__A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__146, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_174)); return A_arbace_cpp_template__init_part1_A_const_173 }

































func A_arbace_cpp_template__init_part1_A_Unit194__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2483, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_cpp_template_var_template_A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_cpp_template_var_template_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1184, false, nil); A_arbace_cpp_template_var_template_A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_176)); return A_arbace_cpp_template__init_part1_A_const_175 }







func A_arbace_cpp_template__init_part1_A_Unit195__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2491, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_99; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_177)); return A_arbace_cpp_template__init_part1_A_const_99 }
//line :2491:1
func A_arbace_cpp_template__init_part1_A_Unit196__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2491, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_105; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_178)); return A_arbace_cpp_template__init_part1_A_const_105 }

func A_arbace_cpp_template__init_part1_A_Unit197__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2493, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_179; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_cpp_template_var_template_inst_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_cpp_template_var_template_inst_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1185, false, nil); A_arbace_cpp_template_var_template_inst_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_180)); return A_arbace_cpp_template__init_part1_A_const_179 }























func A_arbace_cpp_template__init_part1_A_Unit198__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2517, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_181; var tmp2 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_cpp_template_template_text_args_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_cpp_template_template_text_args_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1186, false, nil); A_arbace_cpp_template_template_text_args_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_182)); return A_arbace_cpp_template__init_part1_A_const_181 }























func A_arbace_cpp_template__init_part1_A_Unit199__O() any { A_arbace_cpp_template__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2541, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part1_A_const_183; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_cpp_template_var_text_args_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_cpp_template_var_text_args_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1187, false, nil); A_arbace_cpp_template_var_text_args_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part1_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part1_A_const_184)); return A_arbace_cpp_template__init_part1_A_const_183 }








func A_arbace_cpp_template__init_part2_A_Unit200__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2550, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_template_find_template_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_template_find_template_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1189, false, nil); A_arbace_cpp_template_find_template_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_1)); return A_arbace_cpp_template__init_part2_A_const_0 }
//line :2550:1
func A_arbace_cpp_template__init_part2_A_Init__O() any { A_arbace_cpp_template__init_part2_A_Init(); return nil }
//line :2550:1
func A_arbace_cpp_template__init_part2_A_Load__O() any { A_arbace_cpp_template__init_part2_A_Init(); A_arbace_cpp_template__init_part2_A_Unit200__O(); A_arbace_cpp_template__init_part2_A_Unit201__O(); A_arbace_cpp_template__init_part2_A_Unit202__O(); A_arbace_cpp_template__init_part2_A_Unit203__O(); A_arbace_cpp_template__init_part2_A_Unit204__O(); A_arbace_cpp_template__init_part2_A_Unit205__O(); A_arbace_cpp_template__init_part2_A_Unit206__O(); A_arbace_cpp_template__init_part2_A_Unit207__O(); A_arbace_cpp_template__init_part2_A_Unit208__O(); A_arbace_cpp_template__init_part2_A_Unit209__O(); A_arbace_cpp_template__init_part2_A_Unit210__O(); A_arbace_cpp_template__init_part2_A_Unit211__O(); A_arbace_cpp_template__init_part2_A_Unit212__O(); A_arbace_cpp_template__init_part2_A_Unit213__O(); A_arbace_cpp_template__init_part2_A_Unit214__O(); A_arbace_cpp_template__init_part2_A_Unit215__O(); A_arbace_cpp_template__init_part2_A_Unit216__O(); A_arbace_cpp_template__init_part2_A_Unit217__O(); A_arbace_cpp_template__init_part2_A_Unit218__O(); A_arbace_cpp_template__init_part2_A_Unit219__O(); A_arbace_cpp_template__init_part2_A_Unit220__O(); A_arbace_cpp_template__init_part2_A_Unit221__O(); A_arbace_cpp_template__init_part2_A_Unit222__O(); A_arbace_cpp_template__init_part2_A_Unit223__O(); A_arbace_cpp_template__init_part2_A_Unit224__O(); A_arbace_cpp_template__init_part2_A_Unit225__O(); A_arbace_cpp_template__init_part2_A_Unit226__O(); A_arbace_cpp_template__init_part2_A_Unit227__O(); A_arbace_cpp_template__init_part2_A_Unit228__O(); A_arbace_cpp_template__init_part2_A_Unit229__O(); A_arbace_cpp_template__init_part2_A_Unit230__O(); A_arbace_cpp_template__init_part2_A_Unit231__O(); A_arbace_cpp_template__init_part2_A_Unit232__O(); A_arbace_cpp_template__init_part2_A_Unit233__O(); A_arbace_cpp_template__init_part2_A_Unit234__O(); A_arbace_cpp_template__init_part2_A_Unit235__O(); A_arbace_cpp_template__init_part2_A_Unit236__O(); A_arbace_cpp_template__init_part2_A_Unit237__O(); A_arbace_cpp_template__init_part2_A_Unit238__O(); A_arbace_cpp_template__init_part2_A_Unit239__O(); A_arbace_cpp_template__init_part2_A_Unit240__O(); A_arbace_cpp_template__init_part2_A_Unit241__O(); A_arbace_cpp_template__init_part2_A_Unit242__O(); return nil }


func A_arbace_cpp_template__init_part2_A_Unit201__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2553, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_3)); return A_arbace_cpp_template__init_part2_A_const_2 }
//line :2553:1
func A_arbace_cpp_template__init_part2_A_Unit202__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2553, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_5)); return A_arbace_cpp_template__init_part2_A_const_4 }


func A_arbace_cpp_template__init_part2_A_Unit203__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2556, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_template_friend_BANG__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_template_friend_BANG__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1190, false, nil); A_arbace_cpp_template_friend_BANG__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_7)); return A_arbace_cpp_template__init_part2_A_const_6 }






















































func A_arbace_cpp_template__init_part2_A_Unit204__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2611, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_template_explicit_member_spec_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_template_explicit_member_spec_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1191, false, nil); A_arbace_cpp_template_explicit_member_spec_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_9)); return A_arbace_cpp_template__init_part2_A_const_8 }



































func A_arbace_cpp_template__init_part2_A_Unit205__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2647, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_template_attach_member_template_BANG__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_template_attach_member_template_BANG__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1192, false, nil); A_arbace_cpp_template_attach_member_template_BANG__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_11)); return A_arbace_cpp_template__init_part2_A_const_10 }




























func A_arbace_cpp_template__init_part2_A_Unit206__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2676, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_template_ool_member_template_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_template_ool_member_template_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1193, false, nil); A_arbace_cpp_template_ool_member_template_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_13)); return A_arbace_cpp_template__init_part2_A_const_12 }














func A_arbace_cpp_template__init_part2_A_Unit207__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2691, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_template_explicit_fn_instantiation_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_template_explicit_fn_instantiation_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1194, false, nil); A_arbace_cpp_template_explicit_fn_instantiation_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_15)); return A_arbace_cpp_template__init_part2_A_const_14 }







































func A_arbace_cpp_template__init_part2_A_Unit208__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2731, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_template_constraint_spelling_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_template_constraint_spelling_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1195, false, nil); A_arbace_cpp_template_constraint_spelling_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_17)); return A_arbace_cpp_template__init_part2_A_const_16 }












func A_arbace_cpp_template__init_part2_A_Unit209__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2744, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_template_declare_template_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_template_declare_template_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1196, false, nil); A_arbace_cpp_template_declare_template_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_18)); return A_arbace_cpp_template__init_part2_A_const_2 }







































































































































































































































































































func A_arbace_cpp_template__init_part2_A_Unit210__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3040, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_template_walk_refs_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_template_walk_refs_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1197, false, nil); A_arbace_cpp_template_walk_refs_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_20)); return A_arbace_cpp_template__init_part2_A_const_19 }













func A_arbace_cpp_template__init_part2_A_Unit211__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3054, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_template_class_closure_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_template_class_closure_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1198, false, nil); A_arbace_cpp_template_class_closure_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_22)); return A_arbace_cpp_template__init_part2_A_const_21 }












func A_arbace_cpp_template__init_part2_A_Unit212__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3067, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_template_extern_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_template_extern_class_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1199, false, nil); A_arbace_cpp_template_extern_class_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_24)); return A_arbace_cpp_template__init_part2_A_const_23 }








func A_arbace_cpp_template__init_part2_A_Unit213__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3076, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_template_pending_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_template_pending_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1200, false, nil); A_arbace_cpp_template_pending_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_26)); return A_arbace_cpp_template__init_part2_A_const_25 }



























































func A_arbace_cpp_template__init_part2_A_Unit214__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3136, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_template_guide_class_name_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_template_guide_class_name_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1201, false, nil); A_arbace_cpp_template_guide_class_name_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_28)); return A_arbace_cpp_template__init_part2_A_const_27 }

func A_arbace_cpp_template__init_part2_A_Unit215__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3138, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_template_explicit_guide_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_template_explicit_guide_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1202, false, nil); A_arbace_cpp_template_explicit_guide_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_30)); return A_arbace_cpp_template__init_part2_A_const_29 }









func A_arbace_cpp_template__init_part2_A_Unit216__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3148, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_template_user_guide_BANG__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_template_user_guide_BANG__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1203, false, nil); A_arbace_cpp_template_user_guide_BANG__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_31)); return A_arbace_cpp_template__init_part2_A_const_4 }









func A_arbace_cpp_template__init_part2_A_Unit217__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3158, 1); A_arbace_cpp_template__init_part2_A_const_32.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_33)); return A_arbace_cpp_template__init_part2_A_const_32.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_template__init_part2_A_Unit218__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3160, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_template_guide_scope_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_template_guide_scope_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1204, false, nil); A_arbace_cpp_template_guide_scope_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_35)); return A_arbace_cpp_template__init_part2_A_const_34 }











func A_arbace_cpp_template__init_part2_A_Unit219__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3172, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_template_ctor_nodes_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_template_ctor_nodes_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1205, false, nil); A_arbace_cpp_template_ctor_nodes_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_37)); return A_arbace_cpp_template__init_part2_A_const_36 }








func A_arbace_cpp_template__init_part2_A_Unit220__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3181, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_template_param_defaults_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_template_param_defaults_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1206, false, nil); A_arbace_cpp_template_param_defaults_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_39)); return A_arbace_cpp_template__init_part2_A_const_38 }


func A_arbace_cpp_template__init_part2_A_Unit221__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3184, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_template_self_text_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_template_self_text_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1207, false, nil); A_arbace_cpp_template_self_text_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_41)); return A_arbace_cpp_template__init_part2_A_const_40 }




func A_arbace_cpp_template__init_part2_A_Unit222__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3189, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_template_aggregate_pattern_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_template_aggregate_pattern_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1208, false, nil); A_arbace_cpp_template_aggregate_pattern_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_43)); return A_arbace_cpp_template__init_part2_A_const_42 }















func A_arbace_cpp_template__init_part2_A_Unit223__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3205, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_template_class_guides_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_template_class_guides_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1209, false, nil); A_arbace_cpp_template_class_guides_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_45)); return A_arbace_cpp_template__init_part2_A_const_44 }

















































func A_arbace_cpp_template__init_part2_A_Unit224__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3255, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_template_aggregate_guide_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_template_aggregate_guide_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1210, false, nil); A_arbace_cpp_template_aggregate_guide_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_47)); return A_arbace_cpp_template__init_part2_A_const_46 }









































func A_arbace_cpp_template__init_part2_A_Unit225__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3297, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_template_class_and_bases_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_template_class_and_bases_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1211, false, nil); A_arbace_cpp_template_class_and_bases_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_49)); return A_arbace_cpp_template__init_part2_A_const_48 }

func A_arbace_cpp_template__init_part2_A_Unit226__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3299, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_template_guide_min_args_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_template_guide_min_args_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1212, false, nil); A_arbace_cpp_template_guide_min_args_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_51)); return A_arbace_cpp_template__init_part2_A_const_50 }



func A_arbace_cpp_template__init_part2_A_Unit227__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3303, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_template_guide_candidate_BANG__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_template_guide_candidate_BANG__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1213, false, nil); A_arbace_cpp_template_guide_candidate_BANG__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_53)); return A_arbace_cpp_template__init_part2_A_const_52 }












































func A_arbace_cpp_template__init_part2_A_Unit228__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3348, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_template_init_list_guide_elem_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_template_init_list_guide_elem_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1214, false, nil); A_arbace_cpp_template_init_list_guide_elem_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_55)); return A_arbace_cpp_template__init_part2_A_const_54 }
























func A_arbace_cpp_template__init_part2_A_Unit229__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3373, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_template_alias_rhs_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_template_alias_rhs_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1215, false, nil); A_arbace_cpp_template_alias_rhs_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_57)); return A_arbace_cpp_template__init_part2_A_const_56 }










func A_arbace_cpp_template__init_part2_A_Unit230__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3384, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_template_entity_arg_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_template_entity_arg_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1216, false, nil); A_arbace_cpp_template_entity_arg_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_59)); return A_arbace_cpp_template__init_part2_A_const_58 }













func A_arbace_cpp_template__init_part2_A_Unit231__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3398, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_template_guide_ret_pattern_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_template_guide_ret_pattern_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1217, false, nil); A_arbace_cpp_template_guide_ret_pattern_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_61)); return A_arbace_cpp_template__init_part2_A_const_60 }










func A_arbace_cpp_template__init_part2_A_Unit232__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3409, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_template_alias_deducible_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_template_alias_deducible_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1218, false, nil); A_arbace_cpp_template_alias_deducible_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_63)); return A_arbace_cpp_template__init_part2_A_const_62 }




























func A_arbace_cpp_template__init_part2_A_Unit233__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3438, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_template_deduce_from_rhs_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_template_deduce_from_rhs_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1219, false, nil); A_arbace_cpp_template_deduce_from_rhs_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_65)); return A_arbace_cpp_template__init_part2_A_const_64 }
















func A_arbace_cpp_template__init_part2_A_Unit234__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3455, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_template_alias_result_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_template_alias_result_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1220, false, nil); A_arbace_cpp_template_alias_result_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_67)); return A_arbace_cpp_template__init_part2_A_const_66 }




func A_arbace_cpp_template__init_part2_A_Unit235__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3460, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_template_alias_guide_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_template_alias_guide_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1221, false, nil); A_arbace_cpp_template_alias_guide_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_69)); return A_arbace_cpp_template__init_part2_A_const_68 }

























































func A_arbace_cpp_template__init_part2_A_Unit236__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3518, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_template_alias_guides_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_template_alias_guides_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1222, false, nil); A_arbace_cpp_template_alias_guides_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_71)); return A_arbace_cpp_template__init_part2_A_const_70 }










func A_arbace_cpp_template__init_part2_A_Unit237__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3529, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_template_inherited_guides_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_template_inherited_guides_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1223, false, nil); A_arbace_cpp_template_inherited_guides_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_73)); return A_arbace_cpp_template__init_part2_A_const_72 }








































func A_arbace_cpp_template__init_part2_A_Unit238__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3570, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_template_ctad_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_template_ctad_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1224, false, nil); A_arbace_cpp_template_ctad_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_75)); return A_arbace_cpp_template__init_part2_A_const_74 }









































































































func A_arbace_cpp_template__init_part2_A_Unit239__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3676, 1); A_arbace_cpp_template__init_part2_A_const_76.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_77)); return A_arbace_cpp_template__init_part2_A_const_76.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_template__init_part2_A_Unit240__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3678, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_cpp_template_deduce_conv_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_template_deduce_conv_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1225, false, nil); A_arbace_cpp_template_deduce_conv_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_79)); return A_arbace_cpp_template__init_part2_A_const_78 }

























func A_arbace_cpp_template__init_part2_A_Unit241__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3704, 1); var tmp1 *lang.Var = A_arbace_cpp_template__init_part2_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_template_conv_candidates_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_template_conv_candidates_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1226, false, nil); A_arbace_cpp_template_conv_candidates_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_template__init_part2_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_template__init_part2_A_const_81)); return A_arbace_cpp_template__init_part2_A_const_80 }






















func A_arbace_cpp_template__init_part2_A_Unit242__O() any { A_arbace_cpp_template__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3727, 1); var root_77 any = A_arbace_cpp_template__init_part2_A_const_82.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = A_arbace_cpp_template__init_part2_A_const_83.GetRawRoot__O(); var arg_81 any; var tmp1 any = A_arbace_cpp_template__init_part2_A_const_84; var tmp2 any = A_arbace_cpp_template__init_part2_A_const_2.GetRawRoot__O(); var tmp3 any = A_arbace_cpp_template__init_part2_A_const_85; var tmp4 any = A_arbace_cpp_template__init_part2_A_const_86.GetRawRoot__O(); var tmp5 any = A_arbace_cpp_template__init_part2_A_const_87; var tmp6 *lang.Compiler_AOTFn; var fnbody__83 any = A_arbace_cpp_template_eval960002931_fn__960002932_A_New(); var tmp7 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002932_A_fn_class; if


	fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1227, false, nil); A_arbace_cpp_template_eval960002931_fn__960002932_A_fn_class = fncls__82d; tmp7 = fncls__82d } else { tmp7 = fncls__82 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__83, tmp7, nil); var tmp8 any = /*line :3727:1*/tmp6.Ref(); var tmp9 any = A_arbace_cpp_template__init_part2_A_const_88; var tmp10 *lang.Compiler_AOTFn; var fnbody__85 any = A_arbace_cpp_template_eval960002931_fn__960002934_A_New(); var tmp11 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002934_A_fn_class; if



	fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1228, false, nil); A_arbace_cpp_template_eval960002931_fn__960002934_A_fn_class = fncls__84d; tmp11 = fncls__84d } else { tmp11 = fncls__84 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp11, nil); var tmp12 any = /*line :3727:1*/tmp10.Ref(); var tmp13 any = A_arbace_cpp_template__init_part2_A_const_89; var tmp14 any = A_arbace_cpp_template__init_part2_A_const_90.GetRawRoot__O(); var tmp15 any = A_arbace_cpp_template__init_part2_A_const_91; var tmp16 any = A_arbace_cpp_template__init_part2_A_const_74.GetRawRoot__O(); var tmp17 any = A_arbace_cpp_template__init_part2_A_const_92; var tmp18 *lang.Compiler_AOTFn; var fnbody__87 any = A_arbace_cpp_template_eval960002931_fn__960002936_A_New(); var tmp19 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002936_A_fn_class; if






	fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1229, false, nil); A_arbace_cpp_template_eval960002931_fn__960002936_A_fn_class = fncls__86d; tmp19 = fncls__86d } else { tmp19 = fncls__86 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__87, tmp19, nil); var tmp20 any = /*line :3727:1*/tmp18.Ref(); var tmp21 any = A_arbace_cpp_template__init_part2_A_const_93; var tmp22 any = A_arbace_cpp_template__init_part2_A_const_94.GetRawRoot__O(); var tmp23 any = A_arbace_cpp_template__init_part2_A_const_95; var tmp24 any = A_arbace_cpp_template__init_part2_A_const_96.GetRawRoot__O(); var tmp25 any = A_arbace_cpp_template__init_part2_A_const_97; var tmp26 *lang.Compiler_AOTFn; var fnbody__89 any = A_arbace_cpp_template_eval960002931_fn__960002960_A_New(); var tmp27 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002960_A_fn_class; if
































	fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1230, false, nil); A_arbace_cpp_template_eval960002931_fn__960002960_A_fn_class = fncls__88d; tmp27 = fncls__88d } else { tmp27 = fncls__88 }; tmp26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__89, tmp27, nil); var tmp28 any = /*line :3727:1*/tmp26.Ref(); var tmp29 any = A_arbace_cpp_template__init_part2_A_const_98; var tmp30 any = A_arbace_cpp_template__init_part2_A_const_99.GetRawRoot__O(); var tmp31 any = A_arbace_cpp_template__init_part2_A_const_100; var tmp32 *lang.Compiler_AOTFn; var fnbody__91 any = A_arbace_cpp_template_eval960002931_fn__960002962_A_New(); var tmp33 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002962_A_fn_class; if


































	fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1231, false, nil); A_arbace_cpp_template_eval960002931_fn__960002962_A_fn_class = fncls__90d; tmp33 = fncls__90d } else { tmp33 = fncls__90 }; tmp32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__91, tmp33, nil); var tmp34 any = /*line :3727:1*/tmp32.Ref(); var tmp35 any = A_arbace_cpp_template__init_part2_A_const_101; var tmp36 *lang.Compiler_AOTFn; var fnbody__93 any = A_arbace_cpp_template_eval960002931_fn__960002966_A_New(); var tmp37 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002966_A_fn_class; if






































	fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1232, false, nil); A_arbace_cpp_template_eval960002931_fn__960002966_A_fn_class = fncls__92d; tmp37 = fncls__92d } else { tmp37 = fncls__92 }; tmp36 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__93, tmp37, nil); var tmp38 any = /*line :3727:1*/tmp36.Ref(); var tmp39 any = A_arbace_cpp_template__init_part2_A_const_102; var tmp40 *lang.Compiler_AOTFn; var fnbody__95 any = A_arbace_cpp_template_eval960002931_fn__960002968_A_New(); var tmp41 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002968_A_fn_class; if







































	fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1233, false, nil); A_arbace_cpp_template_eval960002931_fn__960002968_A_fn_class = fncls__94d; tmp41 = fncls__94d } else { tmp41 = fncls__94 }; tmp40 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__95, tmp41, nil); var tmp42 any = /*line :3727:1*/tmp40.Ref(); var tmp43 any = A_arbace_cpp_template__init_part2_A_const_103; var tmp44 *lang.Compiler_AOTFn; var fnbody__97 any = A_arbace_cpp_template_eval960002931_fn__960002970_A_New(); var tmp45 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002970_A_fn_class; if










































	fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1234, false, nil); A_arbace_cpp_template_eval960002931_fn__960002970_A_fn_class = fncls__96d; tmp45 = fncls__96d } else { tmp45 = fncls__96 }; tmp44 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp45, nil); var tmp46 any = /*line :3727:1*/tmp44.Ref(); var tmp47 any = A_arbace_cpp_template__init_part2_A_const_104; var tmp48 *lang.Compiler_AOTFn; var fnbody__99 any = A_arbace_cpp_template_eval960002931_fn__960002979_A_New(); var tmp49 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002979_A_fn_class; if
























































	fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1235, false, nil); A_arbace_cpp_template_eval960002931_fn__960002979_A_fn_class = fncls__98d; tmp49 = fncls__98d } else { tmp49 = fncls__98 }; tmp48 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__99, tmp49, nil); var tmp50 any = /*line :3727:1*/tmp48.Ref(); var tmp51 any = A_arbace_cpp_template__init_part2_A_const_105; var tmp52 any = A_arbace_cpp_template__init_part2_A_const_25.GetRawRoot__O(); var tmp53 any = A_arbace_cpp_template__init_part2_A_const_106; var tmp54 *lang.Compiler_AOTFn; var fnbody__101 any = A_arbace_cpp_template_eval960002931_fn__960002981_A_New(); var tmp55 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002981_A_fn_class; if



































































	fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1236, false, nil); A_arbace_cpp_template_eval960002931_fn__960002981_A_fn_class = fncls__100d; tmp55 = fncls__100d } else { tmp55 = fncls__100 }; tmp54 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__101, tmp55, nil); var tmp56 any = /*line :3727:1*/tmp54.Ref(); var tmp57 any = A_arbace_cpp_template__init_part2_A_const_107; var tmp58 any = A_arbace_cpp_template__init_part2_A_const_108.GetRawRoot__O(); var tmp59 any = A_arbace_cpp_template__init_part2_A_const_109; var tmp60 any = A_arbace_cpp_template__init_part2_A_const_80.GetRawRoot__O(); var tmp61 any = A_arbace_cpp_template__init_part2_A_const_110; var tmp62 *lang.Compiler_AOTFn; var fnbody__103 any = A_arbace_cpp_template_eval960002931_fn__960002985_A_New(); var tmp63 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002985_A_fn_class; if











































































	fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1237, false, nil); A_arbace_cpp_template_eval960002931_fn__960002985_A_fn_class = fncls__102d; tmp63 = fncls__102d } else { tmp63 = fncls__102 }; tmp62 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp63, nil); var tmp64 any = /*line :3727:1*/tmp62.Ref(); var tmp65 any = A_arbace_cpp_template__init_part2_A_const_111; var tmp66 *lang.Compiler_AOTFn; var fnbody__105 any = A_arbace_cpp_template_eval960002931_fn__960002987_A_New(); var tmp67 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002987_A_fn_class; if













































































	fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1238, false, nil); A_arbace_cpp_template_eval960002931_fn__960002987_A_fn_class = fncls__104d; tmp67 = fncls__104d } else { tmp67 = fncls__104 }; tmp66 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__105, tmp67, nil); var tmp68 any = /*line :3727:1*/tmp66.Ref(); var tmp69 any = A_arbace_cpp_template__init_part2_A_const_112; var tmp70 *lang.Compiler_AOTFn; var fnbody__107 any = A_arbace_cpp_template_eval960002931_fn__960002989_A_New(); var tmp71 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002989_A_fn_class; if














































































	fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1239, false, nil); A_arbace_cpp_template_eval960002931_fn__960002989_A_fn_class = fncls__106d; tmp71 = fncls__106d } else { tmp71 = fncls__106 }; tmp70 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__107, tmp71, nil); var tmp72 any = /*line :3727:1*/tmp70.Ref(); var tmp73 any = A_arbace_cpp_template__init_part2_A_const_113; var tmp74 *lang.Compiler_AOTFn; var fnbody__109 any = A_arbace_cpp_template_eval960002931_fn__960002991_A_New(); var tmp75 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_cpp_template_eval960002931_fn__960002991_A_fn_class; if















































































	fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1240, false, nil); A_arbace_cpp_template_eval960002931_fn__960002991_A_fn_class = fncls__108d; tmp75 = fncls__108d } else { tmp75 = fncls__108 }; tmp74 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__109, tmp75, nil); arg_81 = /*line :3727:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp8, tmp9, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp28, tmp29, tmp30, tmp31, tmp34, tmp35, tmp38, tmp39, tmp42, tmp43, tmp46, tmp47, tmp50, tmp51, tmp52, tmp53, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, tmp64, tmp65, tmp68, tmp69, tmp72, tmp73, tmp74.Ref())); if linked_78 == nil { return ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { return linked_78.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_77, arg_80, arg_81) } }






type A_arbace_cpp_template__init_A struct{ jrt.Object }

func A_arbace_cpp_template__init_A_New() *A_arbace_cpp_template__init_A { t := &A_arbace_cpp_template__init_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_template__init_A) Ctor() {}

func (t *A_arbace_cpp_template__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_template__init_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_template__init_A_class }

func (t *A_arbace_cpp_template__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_template__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_template__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_template__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_template__init_A); return ok }

func A_arbace_cpp_template__init_A_Cast(x any) *A_arbace_cpp_template__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_template__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_template__init_A_class)) }; return v }



type A_arbace_cpp_template__init_part0_A struct{ jrt.Object }

var A_arbace_cpp_template__init_part0_A_const_pool *jrt.RefArray

var A_arbace_cpp_template__init_part0_A_const_0 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_1 any

var A_arbace_cpp_template__init_part0_A_const_2 any

var A_arbace_cpp_template__init_part0_A_const_3 any

var A_arbace_cpp_template__init_part0_A_const_4 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_5 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_6 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_7 any

var A_arbace_cpp_template__init_part0_A_const_8 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_9 any

var A_arbace_cpp_template__init_part0_A_const_10 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_11 any

var A_arbace_cpp_template__init_part0_A_const_12 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_13 any

var A_arbace_cpp_template__init_part0_A_const_14 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_15 any

var A_arbace_cpp_template__init_part0_A_const_16 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_17 any

var A_arbace_cpp_template__init_part0_A_const_18 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_19 any

var A_arbace_cpp_template__init_part0_A_const_20 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_21 any

var A_arbace_cpp_template__init_part0_A_const_22 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_23 any

var A_arbace_cpp_template__init_part0_A_const_24 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_25 any

var A_arbace_cpp_template__init_part0_A_const_26 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_27 any

var A_arbace_cpp_template__init_part0_A_const_28 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_29 any

var A_arbace_cpp_template__init_part0_A_const_30 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_31 any

var A_arbace_cpp_template__init_part0_A_const_32 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_33 any

var A_arbace_cpp_template__init_part0_A_const_34 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_35 any

var A_arbace_cpp_template__init_part0_A_const_36 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_37 any

var A_arbace_cpp_template__init_part0_A_const_38 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_39 any

var A_arbace_cpp_template__init_part0_A_const_40 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_41 any

var A_arbace_cpp_template__init_part0_A_const_42 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_43 any

var A_arbace_cpp_template__init_part0_A_const_44 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_45 any

var A_arbace_cpp_template__init_part0_A_const_46 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_47 any

var A_arbace_cpp_template__init_part0_A_const_48 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_49 any

var A_arbace_cpp_template__init_part0_A_const_50 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_51 any

var A_arbace_cpp_template__init_part0_A_const_52 any

var A_arbace_cpp_template__init_part0_A_const_53 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_54 any

var A_arbace_cpp_template__init_part0_A_const_55 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_56 any

var A_arbace_cpp_template__init_part0_A_const_57 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_58 any

var A_arbace_cpp_template__init_part0_A_const_59 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_60 any

var A_arbace_cpp_template__init_part0_A_const_61 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_62 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_63 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_64 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_65 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_66 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_67 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_68 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_69 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_70 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_71 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_72 any

var A_arbace_cpp_template__init_part0_A_const_73 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_74 any

var A_arbace_cpp_template__init_part0_A_const_75 any

var A_arbace_cpp_template__init_part0_A_const_76 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_77 any

var A_arbace_cpp_template__init_part0_A_const_78 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_79 any

var A_arbace_cpp_template__init_part0_A_const_80 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_81 any

var A_arbace_cpp_template__init_part0_A_const_82 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_83 any

var A_arbace_cpp_template__init_part0_A_const_84 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_85 any

var A_arbace_cpp_template__init_part0_A_const_86 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_87 any

var A_arbace_cpp_template__init_part0_A_const_88 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_89 any

var A_arbace_cpp_template__init_part0_A_const_90 any

var A_arbace_cpp_template__init_part0_A_const_91 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_92 any

var A_arbace_cpp_template__init_part0_A_const_93 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_94 any

var A_arbace_cpp_template__init_part0_A_const_95 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_96 any

var A_arbace_cpp_template__init_part0_A_const_97 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_98 any

var A_arbace_cpp_template__init_part0_A_const_99 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_100 any

var A_arbace_cpp_template__init_part0_A_const_101 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_102 any

var A_arbace_cpp_template__init_part0_A_const_103 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_104 any

var A_arbace_cpp_template__init_part0_A_const_105 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_106 any

var A_arbace_cpp_template__init_part0_A_const_107 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_108 any

var A_arbace_cpp_template__init_part0_A_const_109 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_110 any

var A_arbace_cpp_template__init_part0_A_const_111 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_112 any

var A_arbace_cpp_template__init_part0_A_const_113 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_114 any

var A_arbace_cpp_template__init_part0_A_const_115 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_116 any

var A_arbace_cpp_template__init_part0_A_const_117 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_118 any

var A_arbace_cpp_template__init_part0_A_const_119 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_120 any

var A_arbace_cpp_template__init_part0_A_const_121 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_122 any

var A_arbace_cpp_template__init_part0_A_const_123 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_124 any

var A_arbace_cpp_template__init_part0_A_const_125 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_126 any

var A_arbace_cpp_template__init_part0_A_const_127 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_128 any

var A_arbace_cpp_template__init_part0_A_const_129 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_130 any

var A_arbace_cpp_template__init_part0_A_const_131 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_132 any

var A_arbace_cpp_template__init_part0_A_const_133 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_134 any

var A_arbace_cpp_template__init_part0_A_const_135 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_136 any

var A_arbace_cpp_template__init_part0_A_const_137 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_138 any

var A_arbace_cpp_template__init_part0_A_const_139 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_140 any

var A_arbace_cpp_template__init_part0_A_const_141 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_142 any

var A_arbace_cpp_template__init_part0_A_const_143 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_144 any

var A_arbace_cpp_template__init_part0_A_const_145 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_146 any

var A_arbace_cpp_template__init_part0_A_const_147 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_148 any

var A_arbace_cpp_template__init_part0_A_const_149 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_150 any

var A_arbace_cpp_template__init_part0_A_const_151 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_152 any

var A_arbace_cpp_template__init_part0_A_const_153 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_154 any

var A_arbace_cpp_template__init_part0_A_const_155 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_156 any

var A_arbace_cpp_template__init_part0_A_const_157 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_158 any

var A_arbace_cpp_template__init_part0_A_const_159 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_160 any

var A_arbace_cpp_template__init_part0_A_const_161 any

var A_arbace_cpp_template__init_part0_A_const_162 any

var A_arbace_cpp_template__init_part0_A_const_163 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_164 any

var A_arbace_cpp_template__init_part0_A_const_165 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_166 any

var A_arbace_cpp_template__init_part0_A_const_167 any

var A_arbace_cpp_template__init_part0_A_const_168 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_169 any

var A_arbace_cpp_template__init_part0_A_const_170 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_171 any

var A_arbace_cpp_template__init_part0_A_const_172 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_173 any

var A_arbace_cpp_template__init_part0_A_const_174 any

var A_arbace_cpp_template__init_part0_A_const_175 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_176 any

var A_arbace_cpp_template__init_part0_A_const_177 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_178 any

var A_arbace_cpp_template__init_part0_A_const_179 any

var A_arbace_cpp_template__init_part0_A_const_180 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_181 any

var A_arbace_cpp_template__init_part0_A_const_182 any

var A_arbace_cpp_template__init_part0_A_const_183 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_184 any

var A_arbace_cpp_template__init_part0_A_const_185 any

var A_arbace_cpp_template__init_part0_A_const_186 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_187 any

var A_arbace_cpp_template__init_part0_A_const_188 any

var A_arbace_cpp_template__init_part0_A_const_189 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_190 any

var A_arbace_cpp_template__init_part0_A_const_191 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_192 any

var A_arbace_cpp_template__init_part0_A_const_193 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_194 any

var A_arbace_cpp_template__init_part0_A_const_195 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_196 any

var A_arbace_cpp_template__init_part0_A_const_197 *lang.Var

var A_arbace_cpp_template__init_part0_A_const_198 any

var A_arbace_cpp_template__init_part0_A_init jrt.ClassInit

func A_arbace_cpp_template__init_part0_A_Init() { if !A_arbace_cpp_template__init_part0_A_init.Done() { A_arbace_cpp_template__init_part0_A_init.Run(A_arbace_cpp_template__init_part0_A_clinit) } }

func A_arbace_cpp_template__init_part0_A_clinit() { A_arbace_cpp_template__init_part0_A_clinit_p0(); A_arbace_cpp_template__init_part0_A_clinit_p1(); A_arbace_cpp_template__init_part0_A_clinit_p2(); A_arbace_cpp_template__init_part0_A_clinit_p3(); A_arbace_cpp_template__init_part0_A_clinit_p4(); A_arbace_cpp_template__init_part0_A_clinit_p5(); A_arbace_cpp_template__init_part0_A_clinit_p6(); A_arbace_cpp_template__init_part0_A_clinit_p7(); A_arbace_cpp_template__init_part0_A_clinit_p8(); A_arbace_cpp_template__init_part0_A_clinit_p9(); A_arbace_cpp_template__init_part0_A_clinit_p10(); A_arbace_cpp_template__init_part0_A_clinit_p11(); A_arbace_cpp_template__init_part0_A_clinit_p12(); A_arbace_cpp_template__init_part0_A_clinit_p13(); A_arbace_cpp_template__init_part0_A_clinit_p14(); A_arbace_cpp_template__init_part0_A_clinit_p15() }

func A_arbace_cpp_template__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_template__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_889, 252); A_arbace_cpp_template__init_part0_A_const_0 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[53]); A_arbace_cpp_template__init_part0_A_const_1 = A_arbace_cpp_template__init_part0_A_const_pool.A[54]; A_arbace_cpp_template__init_part0_A_const_2 = A_arbace_cpp_template__init_part0_A_const_pool.A[55]; A_arbace_cpp_template__init_part0_A_const_3 = A_arbace_cpp_template__init_part0_A_const_pool.A[56]; A_arbace_cpp_template__init_part0_A_const_4 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[57]); A_arbace_cpp_template__init_part0_A_const_5 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[58]); A_arbace_cpp_template__init_part0_A_const_6 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[59]); A_arbace_cpp_template__init_part0_A_const_7 = A_arbace_cpp_template__init_part0_A_const_pool.A[60]; A_arbace_cpp_template__init_part0_A_const_8 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[61]); A_arbace_cpp_template__init_part0_A_const_9 = A_arbace_cpp_template__init_part0_A_const_pool.A[62]; A_arbace_cpp_template__init_part0_A_const_10 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[63]); A_arbace_cpp_template__init_part0_A_const_11 = A_arbace_cpp_template__init_part0_A_const_pool.A[64] }

func A_arbace_cpp_template__init_part0_A_clinit_p1() { A_arbace_cpp_template__init_part0_A_const_12 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[65]); A_arbace_cpp_template__init_part0_A_const_13 = A_arbace_cpp_template__init_part0_A_const_pool.A[66]; A_arbace_cpp_template__init_part0_A_const_14 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[67]); A_arbace_cpp_template__init_part0_A_const_15 = A_arbace_cpp_template__init_part0_A_const_pool.A[68]; A_arbace_cpp_template__init_part0_A_const_16 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[69]); A_arbace_cpp_template__init_part0_A_const_17 = A_arbace_cpp_template__init_part0_A_const_pool.A[70]; A_arbace_cpp_template__init_part0_A_const_18 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[71]); A_arbace_cpp_template__init_part0_A_const_19 = A_arbace_cpp_template__init_part0_A_const_pool.A[72]; A_arbace_cpp_template__init_part0_A_const_20 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[73]); A_arbace_cpp_template__init_part0_A_const_21 = A_arbace_cpp_template__init_part0_A_const_pool.A[74]; A_arbace_cpp_template__init_part0_A_const_22 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[75]); A_arbace_cpp_template__init_part0_A_const_23 = A_arbace_cpp_template__init_part0_A_const_pool.A[76]; A_arbace_cpp_template__init_part0_A_const_24 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[77]) }

func A_arbace_cpp_template__init_part0_A_clinit_p2() { A_arbace_cpp_template__init_part0_A_const_25 = A_arbace_cpp_template__init_part0_A_const_pool.A[78]; A_arbace_cpp_template__init_part0_A_const_26 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[79]); A_arbace_cpp_template__init_part0_A_const_27 = A_arbace_cpp_template__init_part0_A_const_pool.A[80]; A_arbace_cpp_template__init_part0_A_const_28 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[81]); A_arbace_cpp_template__init_part0_A_const_29 = A_arbace_cpp_template__init_part0_A_const_pool.A[82]; A_arbace_cpp_template__init_part0_A_const_30 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[83]); A_arbace_cpp_template__init_part0_A_const_31 = A_arbace_cpp_template__init_part0_A_const_pool.A[84]; A_arbace_cpp_template__init_part0_A_const_32 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[85]); A_arbace_cpp_template__init_part0_A_const_33 = A_arbace_cpp_template__init_part0_A_const_pool.A[86]; A_arbace_cpp_template__init_part0_A_const_34 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[87]); A_arbace_cpp_template__init_part0_A_const_35 = A_arbace_cpp_template__init_part0_A_const_pool.A[88]; A_arbace_cpp_template__init_part0_A_const_36 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[89]); A_arbace_cpp_template__init_part0_A_const_37 = A_arbace_cpp_template__init_part0_A_const_pool.A[90] }

func A_arbace_cpp_template__init_part0_A_clinit_p3() { A_arbace_cpp_template__init_part0_A_const_38 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[91]); A_arbace_cpp_template__init_part0_A_const_39 = A_arbace_cpp_template__init_part0_A_const_pool.A[92]; A_arbace_cpp_template__init_part0_A_const_40 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[93]); A_arbace_cpp_template__init_part0_A_const_41 = A_arbace_cpp_template__init_part0_A_const_pool.A[94]; A_arbace_cpp_template__init_part0_A_const_42 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[95]); A_arbace_cpp_template__init_part0_A_const_43 = A_arbace_cpp_template__init_part0_A_const_pool.A[96]; A_arbace_cpp_template__init_part0_A_const_44 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[97]); A_arbace_cpp_template__init_part0_A_const_45 = A_arbace_cpp_template__init_part0_A_const_pool.A[98]; A_arbace_cpp_template__init_part0_A_const_46 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[99]); A_arbace_cpp_template__init_part0_A_const_47 = A_arbace_cpp_template__init_part0_A_const_pool.A[100]; A_arbace_cpp_template__init_part0_A_const_48 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[101]); A_arbace_cpp_template__init_part0_A_const_49 = A_arbace_cpp_template__init_part0_A_const_pool.A[102]; A_arbace_cpp_template__init_part0_A_const_50 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[103]) }

func A_arbace_cpp_template__init_part0_A_clinit_p4() { A_arbace_cpp_template__init_part0_A_const_51 = A_arbace_cpp_template__init_part0_A_const_pool.A[104]; A_arbace_cpp_template__init_part0_A_const_52 = A_arbace_cpp_template__init_part0_A_const_pool.A[105]; A_arbace_cpp_template__init_part0_A_const_53 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[106]); A_arbace_cpp_template__init_part0_A_const_54 = A_arbace_cpp_template__init_part0_A_const_pool.A[107]; A_arbace_cpp_template__init_part0_A_const_55 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[108]); A_arbace_cpp_template__init_part0_A_const_56 = A_arbace_cpp_template__init_part0_A_const_pool.A[109]; A_arbace_cpp_template__init_part0_A_const_57 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[110]); A_arbace_cpp_template__init_part0_A_const_58 = A_arbace_cpp_template__init_part0_A_const_pool.A[111]; A_arbace_cpp_template__init_part0_A_const_59 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[112]); A_arbace_cpp_template__init_part0_A_const_60 = A_arbace_cpp_template__init_part0_A_const_pool.A[113]; A_arbace_cpp_template__init_part0_A_const_61 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[114]); A_arbace_cpp_template__init_part0_A_const_62 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[115]); A_arbace_cpp_template__init_part0_A_const_63 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[116]) }

func A_arbace_cpp_template__init_part0_A_clinit_p5() { A_arbace_cpp_template__init_part0_A_const_64 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[117]); A_arbace_cpp_template__init_part0_A_const_65 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[118]); A_arbace_cpp_template__init_part0_A_const_66 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[119]); A_arbace_cpp_template__init_part0_A_const_67 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[120]); A_arbace_cpp_template__init_part0_A_const_68 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[121]); A_arbace_cpp_template__init_part0_A_const_69 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[122]); A_arbace_cpp_template__init_part0_A_const_70 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[123]); A_arbace_cpp_template__init_part0_A_const_71 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[124]); A_arbace_cpp_template__init_part0_A_const_72 = A_arbace_cpp_template__init_part0_A_const_pool.A[125]; A_arbace_cpp_template__init_part0_A_const_73 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[126]); A_arbace_cpp_template__init_part0_A_const_74 = A_arbace_cpp_template__init_part0_A_const_pool.A[127]; A_arbace_cpp_template__init_part0_A_const_75 = A_arbace_cpp_template__init_part0_A_const_pool.A[128] }

func A_arbace_cpp_template__init_part0_A_clinit_p6() { A_arbace_cpp_template__init_part0_A_const_76 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[129]); A_arbace_cpp_template__init_part0_A_const_77 = A_arbace_cpp_template__init_part0_A_const_pool.A[130]; A_arbace_cpp_template__init_part0_A_const_78 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[131]); A_arbace_cpp_template__init_part0_A_const_79 = A_arbace_cpp_template__init_part0_A_const_pool.A[132]; A_arbace_cpp_template__init_part0_A_const_80 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[133]); A_arbace_cpp_template__init_part0_A_const_81 = A_arbace_cpp_template__init_part0_A_const_pool.A[134]; A_arbace_cpp_template__init_part0_A_const_82 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[135]); A_arbace_cpp_template__init_part0_A_const_83 = A_arbace_cpp_template__init_part0_A_const_pool.A[136]; A_arbace_cpp_template__init_part0_A_const_84 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[137]); A_arbace_cpp_template__init_part0_A_const_85 = A_arbace_cpp_template__init_part0_A_const_pool.A[138]; A_arbace_cpp_template__init_part0_A_const_86 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[139]); A_arbace_cpp_template__init_part0_A_const_87 = A_arbace_cpp_template__init_part0_A_const_pool.A[140]; A_arbace_cpp_template__init_part0_A_const_88 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[141]) }

func A_arbace_cpp_template__init_part0_A_clinit_p7() { A_arbace_cpp_template__init_part0_A_const_89 = A_arbace_cpp_template__init_part0_A_const_pool.A[142]; A_arbace_cpp_template__init_part0_A_const_90 = A_arbace_cpp_template__init_part0_A_const_pool.A[143]; A_arbace_cpp_template__init_part0_A_const_91 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[144]); A_arbace_cpp_template__init_part0_A_const_92 = A_arbace_cpp_template__init_part0_A_const_pool.A[145]; A_arbace_cpp_template__init_part0_A_const_93 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[146]); A_arbace_cpp_template__init_part0_A_const_94 = A_arbace_cpp_template__init_part0_A_const_pool.A[147]; A_arbace_cpp_template__init_part0_A_const_95 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[148]); A_arbace_cpp_template__init_part0_A_const_96 = A_arbace_cpp_template__init_part0_A_const_pool.A[149]; A_arbace_cpp_template__init_part0_A_const_97 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[150]); A_arbace_cpp_template__init_part0_A_const_98 = A_arbace_cpp_template__init_part0_A_const_pool.A[151]; A_arbace_cpp_template__init_part0_A_const_99 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[152]); A_arbace_cpp_template__init_part0_A_const_100 = A_arbace_cpp_template__init_part0_A_const_pool.A[153]; A_arbace_cpp_template__init_part0_A_const_101 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[154]); A_arbace_cpp_template__init_part0_A_const_102 = A_arbace_cpp_template__init_part0_A_const_pool.A[155] }

func A_arbace_cpp_template__init_part0_A_clinit_p8() { A_arbace_cpp_template__init_part0_A_const_103 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[156]); A_arbace_cpp_template__init_part0_A_const_104 = A_arbace_cpp_template__init_part0_A_const_pool.A[157]; A_arbace_cpp_template__init_part0_A_const_105 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[158]); A_arbace_cpp_template__init_part0_A_const_106 = A_arbace_cpp_template__init_part0_A_const_pool.A[159]; A_arbace_cpp_template__init_part0_A_const_107 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[160]); A_arbace_cpp_template__init_part0_A_const_108 = A_arbace_cpp_template__init_part0_A_const_pool.A[161]; A_arbace_cpp_template__init_part0_A_const_109 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[162]); A_arbace_cpp_template__init_part0_A_const_110 = A_arbace_cpp_template__init_part0_A_const_pool.A[163]; A_arbace_cpp_template__init_part0_A_const_111 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[164]); A_arbace_cpp_template__init_part0_A_const_112 = A_arbace_cpp_template__init_part0_A_const_pool.A[165]; A_arbace_cpp_template__init_part0_A_const_113 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[166]); A_arbace_cpp_template__init_part0_A_const_114 = A_arbace_cpp_template__init_part0_A_const_pool.A[167]; A_arbace_cpp_template__init_part0_A_const_115 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[168]) }

func A_arbace_cpp_template__init_part0_A_clinit_p9() { A_arbace_cpp_template__init_part0_A_const_116 = A_arbace_cpp_template__init_part0_A_const_pool.A[169]; A_arbace_cpp_template__init_part0_A_const_117 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[170]); A_arbace_cpp_template__init_part0_A_const_118 = A_arbace_cpp_template__init_part0_A_const_pool.A[171]; A_arbace_cpp_template__init_part0_A_const_119 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[172]); A_arbace_cpp_template__init_part0_A_const_120 = A_arbace_cpp_template__init_part0_A_const_pool.A[173]; A_arbace_cpp_template__init_part0_A_const_121 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[174]); A_arbace_cpp_template__init_part0_A_const_122 = A_arbace_cpp_template__init_part0_A_const_pool.A[175]; A_arbace_cpp_template__init_part0_A_const_123 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[176]); A_arbace_cpp_template__init_part0_A_const_124 = A_arbace_cpp_template__init_part0_A_const_pool.A[177]; A_arbace_cpp_template__init_part0_A_const_125 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[178]); A_arbace_cpp_template__init_part0_A_const_126 = A_arbace_cpp_template__init_part0_A_const_pool.A[179]; A_arbace_cpp_template__init_part0_A_const_127 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[180]); A_arbace_cpp_template__init_part0_A_const_128 = A_arbace_cpp_template__init_part0_A_const_pool.A[181] }

func A_arbace_cpp_template__init_part0_A_clinit_p10() { A_arbace_cpp_template__init_part0_A_const_129 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[182]); A_arbace_cpp_template__init_part0_A_const_130 = A_arbace_cpp_template__init_part0_A_const_pool.A[183]; A_arbace_cpp_template__init_part0_A_const_131 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[184]); A_arbace_cpp_template__init_part0_A_const_132 = A_arbace_cpp_template__init_part0_A_const_pool.A[185]; A_arbace_cpp_template__init_part0_A_const_133 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[186]); A_arbace_cpp_template__init_part0_A_const_134 = A_arbace_cpp_template__init_part0_A_const_pool.A[187]; A_arbace_cpp_template__init_part0_A_const_135 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[188]); A_arbace_cpp_template__init_part0_A_const_136 = A_arbace_cpp_template__init_part0_A_const_pool.A[189]; A_arbace_cpp_template__init_part0_A_const_137 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[190]); A_arbace_cpp_template__init_part0_A_const_138 = A_arbace_cpp_template__init_part0_A_const_pool.A[191]; A_arbace_cpp_template__init_part0_A_const_139 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[192]); A_arbace_cpp_template__init_part0_A_const_140 = A_arbace_cpp_template__init_part0_A_const_pool.A[193]; A_arbace_cpp_template__init_part0_A_const_141 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[194]) }

func A_arbace_cpp_template__init_part0_A_clinit_p11() { A_arbace_cpp_template__init_part0_A_const_142 = A_arbace_cpp_template__init_part0_A_const_pool.A[195]; A_arbace_cpp_template__init_part0_A_const_143 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[196]); A_arbace_cpp_template__init_part0_A_const_144 = A_arbace_cpp_template__init_part0_A_const_pool.A[197]; A_arbace_cpp_template__init_part0_A_const_145 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[198]); A_arbace_cpp_template__init_part0_A_const_146 = A_arbace_cpp_template__init_part0_A_const_pool.A[199]; A_arbace_cpp_template__init_part0_A_const_147 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[200]); A_arbace_cpp_template__init_part0_A_const_148 = A_arbace_cpp_template__init_part0_A_const_pool.A[201]; A_arbace_cpp_template__init_part0_A_const_149 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[202]); A_arbace_cpp_template__init_part0_A_const_150 = A_arbace_cpp_template__init_part0_A_const_pool.A[203]; A_arbace_cpp_template__init_part0_A_const_151 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[204]); A_arbace_cpp_template__init_part0_A_const_152 = A_arbace_cpp_template__init_part0_A_const_pool.A[205]; A_arbace_cpp_template__init_part0_A_const_153 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[206]); A_arbace_cpp_template__init_part0_A_const_154 = A_arbace_cpp_template__init_part0_A_const_pool.A[207] }

func A_arbace_cpp_template__init_part0_A_clinit_p12() { A_arbace_cpp_template__init_part0_A_const_155 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[208]); A_arbace_cpp_template__init_part0_A_const_156 = A_arbace_cpp_template__init_part0_A_const_pool.A[209]; A_arbace_cpp_template__init_part0_A_const_157 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[210]); A_arbace_cpp_template__init_part0_A_const_158 = A_arbace_cpp_template__init_part0_A_const_pool.A[211]; A_arbace_cpp_template__init_part0_A_const_159 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[212]); A_arbace_cpp_template__init_part0_A_const_160 = A_arbace_cpp_template__init_part0_A_const_pool.A[213]; A_arbace_cpp_template__init_part0_A_const_161 = A_arbace_cpp_template__init_part0_A_const_pool.A[214]; A_arbace_cpp_template__init_part0_A_const_162 = A_arbace_cpp_template__init_part0_A_const_pool.A[215]; A_arbace_cpp_template__init_part0_A_const_163 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[216]); A_arbace_cpp_template__init_part0_A_const_164 = A_arbace_cpp_template__init_part0_A_const_pool.A[217]; A_arbace_cpp_template__init_part0_A_const_165 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[218]); A_arbace_cpp_template__init_part0_A_const_166 = A_arbace_cpp_template__init_part0_A_const_pool.A[219]; A_arbace_cpp_template__init_part0_A_const_167 = A_arbace_cpp_template__init_part0_A_const_pool.A[220]; A_arbace_cpp_template__init_part0_A_const_168 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[221]) }

func A_arbace_cpp_template__init_part0_A_clinit_p13() { A_arbace_cpp_template__init_part0_A_const_169 = A_arbace_cpp_template__init_part0_A_const_pool.A[222]; A_arbace_cpp_template__init_part0_A_const_170 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[223]); A_arbace_cpp_template__init_part0_A_const_171 = A_arbace_cpp_template__init_part0_A_const_pool.A[224]; A_arbace_cpp_template__init_part0_A_const_172 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[225]); A_arbace_cpp_template__init_part0_A_const_173 = A_arbace_cpp_template__init_part0_A_const_pool.A[226]; A_arbace_cpp_template__init_part0_A_const_174 = A_arbace_cpp_template__init_part0_A_const_pool.A[227]; A_arbace_cpp_template__init_part0_A_const_175 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[228]); A_arbace_cpp_template__init_part0_A_const_176 = A_arbace_cpp_template__init_part0_A_const_pool.A[229]; A_arbace_cpp_template__init_part0_A_const_177 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[230]); A_arbace_cpp_template__init_part0_A_const_178 = A_arbace_cpp_template__init_part0_A_const_pool.A[231]; A_arbace_cpp_template__init_part0_A_const_179 = A_arbace_cpp_template__init_part0_A_const_pool.A[232]; A_arbace_cpp_template__init_part0_A_const_180 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[233]); A_arbace_cpp_template__init_part0_A_const_181 = A_arbace_cpp_template__init_part0_A_const_pool.A[234]; A_arbace_cpp_template__init_part0_A_const_182 = A_arbace_cpp_template__init_part0_A_const_pool.A[235] }

func A_arbace_cpp_template__init_part0_A_clinit_p14() { A_arbace_cpp_template__init_part0_A_const_183 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[236]); A_arbace_cpp_template__init_part0_A_const_184 = A_arbace_cpp_template__init_part0_A_const_pool.A[237]; A_arbace_cpp_template__init_part0_A_const_185 = A_arbace_cpp_template__init_part0_A_const_pool.A[238]; A_arbace_cpp_template__init_part0_A_const_186 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[239]); A_arbace_cpp_template__init_part0_A_const_187 = A_arbace_cpp_template__init_part0_A_const_pool.A[240]; A_arbace_cpp_template__init_part0_A_const_188 = A_arbace_cpp_template__init_part0_A_const_pool.A[241]; A_arbace_cpp_template__init_part0_A_const_189 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[242]); A_arbace_cpp_template__init_part0_A_const_190 = A_arbace_cpp_template__init_part0_A_const_pool.A[243]; A_arbace_cpp_template__init_part0_A_const_191 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[244]); A_arbace_cpp_template__init_part0_A_const_192 = A_arbace_cpp_template__init_part0_A_const_pool.A[245]; A_arbace_cpp_template__init_part0_A_const_193 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[246]); A_arbace_cpp_template__init_part0_A_const_194 = A_arbace_cpp_template__init_part0_A_const_pool.A[247]; A_arbace_cpp_template__init_part0_A_const_195 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[248]); A_arbace_cpp_template__init_part0_A_const_196 = A_arbace_cpp_template__init_part0_A_const_pool.A[249] }

func A_arbace_cpp_template__init_part0_A_clinit_p15() { A_arbace_cpp_template__init_part0_A_const_197 = lang.Var_Cast(A_arbace_cpp_template__init_part0_A_const_pool.A[250]); A_arbace_cpp_template__init_part0_A_const_198 = A_arbace_cpp_template__init_part0_A_const_pool.A[251] }

func A_arbace_cpp_template__init_part0_A_New() *A_arbace_cpp_template__init_part0_A { A_arbace_cpp_template__init_part0_A_Init(); t := &A_arbace_cpp_template__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_template__init_part0_A) Ctor() {}

func (t *A_arbace_cpp_template__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_template__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_template__init_part0_A_class }

func (t *A_arbace_cpp_template__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_template__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_template__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_template__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_template__init_part0_A); return ok }

func A_arbace_cpp_template__init_part0_A_Cast(x any) *A_arbace_cpp_template__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_template__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_template__init_part0_A_class)) }; return v }



type A_arbace_cpp_template__init_part1_A struct{ jrt.Object }

var A_arbace_cpp_template__init_part1_A_const_pool *jrt.RefArray

var A_arbace_cpp_template__init_part1_A_const_0 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_1 any

var A_arbace_cpp_template__init_part1_A_const_2 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_3 any

var A_arbace_cpp_template__init_part1_A_const_4 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_5 any

var A_arbace_cpp_template__init_part1_A_const_6 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_7 any

var A_arbace_cpp_template__init_part1_A_const_8 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_9 any

var A_arbace_cpp_template__init_part1_A_const_10 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_11 any

var A_arbace_cpp_template__init_part1_A_const_12 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_13 any

var A_arbace_cpp_template__init_part1_A_const_14 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_15 any

var A_arbace_cpp_template__init_part1_A_const_16 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_17 any

var A_arbace_cpp_template__init_part1_A_const_18 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_19 any

var A_arbace_cpp_template__init_part1_A_const_20 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_21 any

var A_arbace_cpp_template__init_part1_A_const_22 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_23 any

var A_arbace_cpp_template__init_part1_A_const_24 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_25 any

var A_arbace_cpp_template__init_part1_A_const_26 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_27 any

var A_arbace_cpp_template__init_part1_A_const_28 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_29 any

var A_arbace_cpp_template__init_part1_A_const_30 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_31 any

var A_arbace_cpp_template__init_part1_A_const_32 any

var A_arbace_cpp_template__init_part1_A_const_33 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_34 any

var A_arbace_cpp_template__init_part1_A_const_35 any

var A_arbace_cpp_template__init_part1_A_const_36 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_37 any

var A_arbace_cpp_template__init_part1_A_const_38 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_39 any

var A_arbace_cpp_template__init_part1_A_const_40 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_41 any

var A_arbace_cpp_template__init_part1_A_const_42 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_43 any

var A_arbace_cpp_template__init_part1_A_const_44 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_45 any

var A_arbace_cpp_template__init_part1_A_const_46 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_47 any

var A_arbace_cpp_template__init_part1_A_const_48 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_49 any

var A_arbace_cpp_template__init_part1_A_const_50 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_51 any

var A_arbace_cpp_template__init_part1_A_const_52 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_53 any

var A_arbace_cpp_template__init_part1_A_const_54 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_55 any

var A_arbace_cpp_template__init_part1_A_const_56 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_57 any

var A_arbace_cpp_template__init_part1_A_const_58 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_59 any

var A_arbace_cpp_template__init_part1_A_const_60 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_61 any

var A_arbace_cpp_template__init_part1_A_const_62 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_63 any

var A_arbace_cpp_template__init_part1_A_const_64 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_65 any

var A_arbace_cpp_template__init_part1_A_const_66 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_67 any

var A_arbace_cpp_template__init_part1_A_const_68 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_69 any

var A_arbace_cpp_template__init_part1_A_const_70 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_71 any

var A_arbace_cpp_template__init_part1_A_const_72 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_73 any

var A_arbace_cpp_template__init_part1_A_const_74 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_75 any

var A_arbace_cpp_template__init_part1_A_const_76 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_77 any

var A_arbace_cpp_template__init_part1_A_const_78 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_79 any

var A_arbace_cpp_template__init_part1_A_const_80 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_81 any

var A_arbace_cpp_template__init_part1_A_const_82 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_83 any

var A_arbace_cpp_template__init_part1_A_const_84 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_85 any

var A_arbace_cpp_template__init_part1_A_const_86 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_87 any

var A_arbace_cpp_template__init_part1_A_const_88 any

var A_arbace_cpp_template__init_part1_A_const_89 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_90 any

var A_arbace_cpp_template__init_part1_A_const_91 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_92 any

var A_arbace_cpp_template__init_part1_A_const_93 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_94 any

var A_arbace_cpp_template__init_part1_A_const_95 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_96 any

var A_arbace_cpp_template__init_part1_A_const_97 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_98 any

var A_arbace_cpp_template__init_part1_A_const_99 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_100 any

var A_arbace_cpp_template__init_part1_A_const_101 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_102 any

var A_arbace_cpp_template__init_part1_A_const_103 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_104 any

var A_arbace_cpp_template__init_part1_A_const_105 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_106 any

var A_arbace_cpp_template__init_part1_A_const_107 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_108 any

var A_arbace_cpp_template__init_part1_A_const_109 any

var A_arbace_cpp_template__init_part1_A_const_110 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_111 any

var A_arbace_cpp_template__init_part1_A_const_112 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_113 any

var A_arbace_cpp_template__init_part1_A_const_114 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_115 any

var A_arbace_cpp_template__init_part1_A_const_116 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_117 any

var A_arbace_cpp_template__init_part1_A_const_118 any

var A_arbace_cpp_template__init_part1_A_const_119 any

var A_arbace_cpp_template__init_part1_A_const_120 any

var A_arbace_cpp_template__init_part1_A_const_121 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_122 any

var A_arbace_cpp_template__init_part1_A_const_123 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_124 any

var A_arbace_cpp_template__init_part1_A_const_125 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_126 any

var A_arbace_cpp_template__init_part1_A_const_127 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_128 any

var A_arbace_cpp_template__init_part1_A_const_129 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_130 any

var A_arbace_cpp_template__init_part1_A_const_131 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_132 any

var A_arbace_cpp_template__init_part1_A_const_133 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_134 any

var A_arbace_cpp_template__init_part1_A_const_135 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_136 any

var A_arbace_cpp_template__init_part1_A_const_137 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_138 any

var A_arbace_cpp_template__init_part1_A_const_139 any

var A_arbace_cpp_template__init_part1_A_const_140 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_141 any

var A_arbace_cpp_template__init_part1_A_const_142 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_143 any

var A_arbace_cpp_template__init_part1_A_const_144 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_145 any

var A_arbace_cpp_template__init_part1_A_const_146 any

var A_arbace_cpp_template__init_part1_A_const_147 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_148 any

var A_arbace_cpp_template__init_part1_A_const_149 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_150 any

var A_arbace_cpp_template__init_part1_A_const_151 any

var A_arbace_cpp_template__init_part1_A_const_152 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_153 any

var A_arbace_cpp_template__init_part1_A_const_154 any

var A_arbace_cpp_template__init_part1_A_const_155 any

var A_arbace_cpp_template__init_part1_A_const_156 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_157 any

var A_arbace_cpp_template__init_part1_A_const_158 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_159 any

var A_arbace_cpp_template__init_part1_A_const_160 any

var A_arbace_cpp_template__init_part1_A_const_161 any

var A_arbace_cpp_template__init_part1_A_const_162 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_163 any

var A_arbace_cpp_template__init_part1_A_const_164 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_165 any

var A_arbace_cpp_template__init_part1_A_const_166 any

var A_arbace_cpp_template__init_part1_A_const_167 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_168 any

var A_arbace_cpp_template__init_part1_A_const_169 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_170 any

var A_arbace_cpp_template__init_part1_A_const_171 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_172 any

var A_arbace_cpp_template__init_part1_A_const_173 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_174 any

var A_arbace_cpp_template__init_part1_A_const_175 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_176 any

var A_arbace_cpp_template__init_part1_A_const_177 any

var A_arbace_cpp_template__init_part1_A_const_178 any

var A_arbace_cpp_template__init_part1_A_const_179 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_180 any

var A_arbace_cpp_template__init_part1_A_const_181 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_182 any

var A_arbace_cpp_template__init_part1_A_const_183 *lang.Var

var A_arbace_cpp_template__init_part1_A_const_184 any

var A_arbace_cpp_template__init_part1_A_init jrt.ClassInit

func A_arbace_cpp_template__init_part1_A_Init() { if !A_arbace_cpp_template__init_part1_A_init.Done() { A_arbace_cpp_template__init_part1_A_init.Run(A_arbace_cpp_template__init_part1_A_clinit) } }

func A_arbace_cpp_template__init_part1_A_clinit() { A_arbace_cpp_template__init_part1_A_clinit_p0(); A_arbace_cpp_template__init_part1_A_clinit_p1() }

func A_arbace_cpp_template__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_template__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1110, 248); A_arbace_cpp_template__init_part1_A_const_0 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[67]); A_arbace_cpp_template__init_part1_A_const_1 = A_arbace_cpp_template__init_part1_A_const_pool.A[68]; A_arbace_cpp_template__init_part1_A_const_2 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[69]); A_arbace_cpp_template__init_part1_A_const_3 = A_arbace_cpp_template__init_part1_A_const_pool.A[70]; A_arbace_cpp_template__init_part1_A_const_4 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[71]); A_arbace_cpp_template__init_part1_A_const_5 = A_arbace_cpp_template__init_part1_A_const_pool.A[72]; A_arbace_cpp_template__init_part1_A_const_6 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[73]); A_arbace_cpp_template__init_part1_A_const_7 = A_arbace_cpp_template__init_part1_A_const_pool.A[74]; A_arbace_cpp_template__init_part1_A_const_8 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[75]); A_arbace_cpp_template__init_part1_A_const_9 = A_arbace_cpp_template__init_part1_A_const_pool.A[76] }

func A_arbace_cpp_template__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_cpp_template__init_part0_A_Init(); tmp1 = A_arbace_cpp_template__init_part0_A_const_48; A_arbace_cpp_template__init_part1_A_const_10 = tmp1; A_arbace_cpp_template__init_part1_A_const_11 = A_arbace_cpp_template__init_part1_A_const_pool.A[77]; A_arbace_cpp_template__init_part1_A_const_12 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[78]); A_arbace_cpp_template__init_part1_A_const_13 = A_arbace_cpp_template__init_part1_A_const_pool.A[79]; A_arbace_cpp_template__init_part1_A_const_14 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[80]); A_arbace_cpp_template__init_part1_A_const_15 = A_arbace_cpp_template__init_part1_A_const_pool.A[81]; A_arbace_cpp_template__init_part1_A_const_16 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[82]); A_arbace_cpp_template__init_part1_A_const_17 = A_arbace_cpp_template__init_part1_A_const_pool.A[83]; A_arbace_cpp_template__init_part1_A_const_18 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[84]); A_arbace_cpp_template__init_part1_A_const_19 = A_arbace_cpp_template__init_part1_A_const_pool.A[85]; A_arbace_cpp_template__init_part1_A_const_20 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[86]); A_arbace_cpp_template__init_part1_A_const_21 = A_arbace_cpp_template__init_part1_A_const_pool.A[87]; A_arbace_cpp_template__init_part1_A_const_22 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[88]); A_arbace_cpp_template__init_part1_A_const_23 = A_arbace_cpp_template__init_part1_A_const_pool.A[89]; A_arbace_cpp_template__init_part1_A_const_24 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[90]); A_arbace_cpp_template__init_part1_A_const_25 = A_arbace_cpp_template__init_part1_A_const_pool.A[91]; A_arbace_cpp_template__init_part1_A_const_26 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[92]); A_arbace_cpp_template__init_part1_A_const_27 = A_arbace_cpp_template__init_part1_A_const_pool.A[93]; A_arbace_cpp_template__init_part1_A_const_28 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[94]); A_arbace_cpp_template__init_part1_A_const_29 = A_arbace_cpp_template__init_part1_A_const_pool.A[95]; A_arbace_cpp_template__init_part1_A_const_30 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[96]); A_arbace_cpp_template__init_part1_A_const_31 = A_arbace_cpp_template__init_part1_A_const_pool.A[97]; A_arbace_cpp_template__init_part1_A_const_32 = A_arbace_cpp_template__init_part1_A_const_pool.A[98]; A_arbace_cpp_template__init_part1_A_const_33 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[99]); A_arbace_cpp_template__init_part1_A_const_34 = A_arbace_cpp_template__init_part1_A_const_pool.A[100]; A_arbace_cpp_template__init_part1_A_const_35 = A_arbace_cpp_template__init_part1_A_const_pool.A[101]; A_arbace_cpp_template__init_part1_A_const_36 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[102]); A_arbace_cpp_template__init_part1_A_const_37 = A_arbace_cpp_template__init_part1_A_const_pool.A[103]; A_arbace_cpp_template__init_part1_A_const_38 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[104]); A_arbace_cpp_template__init_part1_A_const_39 = A_arbace_cpp_template__init_part1_A_const_pool.A[105]; A_arbace_cpp_template__init_part1_A_const_40 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[106]); A_arbace_cpp_template__init_part1_A_const_41 = A_arbace_cpp_template__init_part1_A_const_pool.A[107]; A_arbace_cpp_template__init_part1_A_const_42 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[108]); A_arbace_cpp_template__init_part1_A_const_43 = A_arbace_cpp_template__init_part1_A_const_pool.A[109]; A_arbace_cpp_template__init_part1_A_const_44 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[110]); A_arbace_cpp_template__init_part1_A_const_45 = A_arbace_cpp_template__init_part1_A_const_pool.A[111]; A_arbace_cpp_template__init_part1_A_const_46 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[112]); A_arbace_cpp_template__init_part1_A_const_47 = A_arbace_cpp_template__init_part1_A_const_pool.A[113]; A_arbace_cpp_template__init_part1_A_const_48 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[114]); A_arbace_cpp_template__init_part1_A_const_49 = A_arbace_cpp_template__init_part1_A_const_pool.A[115]; A_arbace_cpp_template__init_part1_A_const_50 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[116]); A_arbace_cpp_template__init_part1_A_const_51 = A_arbace_cpp_template__init_part1_A_const_pool.A[117]; A_arbace_cpp_template__init_part1_A_const_52 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[118]); A_arbace_cpp_template__init_part1_A_const_53 = A_arbace_cpp_template__init_part1_A_const_pool.A[119]; A_arbace_cpp_template__init_part1_A_const_54 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[120]); A_arbace_cpp_template__init_part1_A_const_55 = A_arbace_cpp_template__init_part1_A_const_pool.A[121]; A_arbace_cpp_template__init_part1_A_const_56 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[122]); A_arbace_cpp_template__init_part1_A_const_57 = A_arbace_cpp_template__init_part1_A_const_pool.A[123]; var tmp2 *lang.Var; A_arbace_cpp_template__init_part0_A_Init(); tmp2 = A_arbace_cpp_template__init_part0_A_const_155; A_arbace_cpp_template__init_part1_A_const_58 = tmp2; A_arbace_cpp_template__init_part1_A_const_59 = A_arbace_cpp_template__init_part1_A_const_pool.A[124]; A_arbace_cpp_template__init_part1_A_const_60 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[125]); A_arbace_cpp_template__init_part1_A_const_61 = A_arbace_cpp_template__init_part1_A_const_pool.A[126]; A_arbace_cpp_template__init_part1_A_const_62 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[127]); A_arbace_cpp_template__init_part1_A_const_63 = A_arbace_cpp_template__init_part1_A_const_pool.A[128]; A_arbace_cpp_template__init_part1_A_const_64 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[129]); A_arbace_cpp_template__init_part1_A_const_65 = A_arbace_cpp_template__init_part1_A_const_pool.A[130]; A_arbace_cpp_template__init_part1_A_const_66 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[131]); A_arbace_cpp_template__init_part1_A_const_67 = A_arbace_cpp_template__init_part1_A_const_pool.A[132]; A_arbace_cpp_template__init_part1_A_const_68 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[133]); A_arbace_cpp_template__init_part1_A_const_69 = A_arbace_cpp_template__init_part1_A_const_pool.A[134]; A_arbace_cpp_template__init_part1_A_const_70 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[135]); A_arbace_cpp_template__init_part1_A_const_71 = A_arbace_cpp_template__init_part1_A_const_pool.A[136]; A_arbace_cpp_template__init_part1_A_const_72 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[137]); A_arbace_cpp_template__init_part1_A_const_73 = A_arbace_cpp_template__init_part1_A_const_pool.A[138]; A_arbace_cpp_template__init_part1_A_const_74 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[139]); A_arbace_cpp_template__init_part1_A_const_75 = A_arbace_cpp_template__init_part1_A_const_pool.A[140]; A_arbace_cpp_template__init_part1_A_const_76 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[141]); A_arbace_cpp_template__init_part1_A_const_77 = A_arbace_cpp_template__init_part1_A_const_pool.A[142]; A_arbace_cpp_template__init_part1_A_const_78 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[143]); A_arbace_cpp_template__init_part1_A_const_79 = A_arbace_cpp_template__init_part1_A_const_pool.A[144]; A_arbace_cpp_template__init_part1_A_const_80 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[145]); A_arbace_cpp_template__init_part1_A_const_81 = A_arbace_cpp_template__init_part1_A_const_pool.A[146]; A_arbace_cpp_template__init_part1_A_const_82 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[147]); A_arbace_cpp_template__init_part1_A_const_83 = A_arbace_cpp_template__init_part1_A_const_pool.A[148]; A_arbace_cpp_template__init_part1_A_const_84 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[149]); A_arbace_cpp_template__init_part1_A_const_85 = A_arbace_cpp_template__init_part1_A_const_pool.A[150]; A_arbace_cpp_template__init_part1_A_const_86 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[151]); A_arbace_cpp_template__init_part1_A_const_87 = A_arbace_cpp_template__init_part1_A_const_pool.A[152]; A_arbace_cpp_template__init_part1_A_const_88 = A_arbace_cpp_template__init_part1_A_const_pool.A[153]; A_arbace_cpp_template__init_part1_A_const_89 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[154]); A_arbace_cpp_template__init_part1_A_const_90 = A_arbace_cpp_template__init_part1_A_const_pool.A[155]; A_arbace_cpp_template__init_part1_A_const_91 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[156]); A_arbace_cpp_template__init_part1_A_const_92 = A_arbace_cpp_template__init_part1_A_const_pool.A[157]; A_arbace_cpp_template__init_part1_A_const_93 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[158]); A_arbace_cpp_template__init_part1_A_const_94 = A_arbace_cpp_template__init_part1_A_const_pool.A[159]; A_arbace_cpp_template__init_part1_A_const_95 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[160]); A_arbace_cpp_template__init_part1_A_const_96 = A_arbace_cpp_template__init_part1_A_const_pool.A[161]; A_arbace_cpp_template__init_part1_A_const_97 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[162]); A_arbace_cpp_template__init_part1_A_const_98 = A_arbace_cpp_template__init_part1_A_const_pool.A[163]; A_arbace_cpp_template__init_part1_A_const_99 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[164]); A_arbace_cpp_template__init_part1_A_const_100 = A_arbace_cpp_template__init_part1_A_const_pool.A[165]; A_arbace_cpp_template__init_part1_A_const_101 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[166]); A_arbace_cpp_template__init_part1_A_const_102 = A_arbace_cpp_template__init_part1_A_const_pool.A[167]; A_arbace_cpp_template__init_part1_A_const_103 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[168]); A_arbace_cpp_template__init_part1_A_const_104 = A_arbace_cpp_template__init_part1_A_const_pool.A[169]; A_arbace_cpp_template__init_part1_A_const_105 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[170]); A_arbace_cpp_template__init_part1_A_const_106 = A_arbace_cpp_template__init_part1_A_const_pool.A[171]; A_arbace_cpp_template__init_part1_A_const_107 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[172]); A_arbace_cpp_template__init_part1_A_const_108 = A_arbace_cpp_template__init_part1_A_const_pool.A[173]; A_arbace_cpp_template__init_part1_A_const_109 = A_arbace_cpp_template__init_part1_A_const_pool.A[174]; A_arbace_cpp_template__init_part1_A_const_110 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[175]); A_arbace_cpp_template__init_part1_A_const_111 = A_arbace_cpp_template__init_part1_A_const_pool.A[176]; A_arbace_cpp_template__init_part1_A_const_112 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[177]); A_arbace_cpp_template__init_part1_A_const_113 = A_arbace_cpp_template__init_part1_A_const_pool.A[178]; A_arbace_cpp_template__init_part1_A_const_114 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[179]); A_arbace_cpp_template__init_part1_A_const_115 = A_arbace_cpp_template__init_part1_A_const_pool.A[180]; A_arbace_cpp_template__init_part1_A_const_116 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[181]); A_arbace_cpp_template__init_part1_A_const_117 = A_arbace_cpp_template__init_part1_A_const_pool.A[182]; A_arbace_cpp_template__init_part1_A_const_118 = A_arbace_cpp_template__init_part1_A_const_pool.A[183]; A_arbace_cpp_template__init_part1_A_const_119 = A_arbace_cpp_template__init_part1_A_const_pool.A[184]; A_arbace_cpp_template__init_part1_A_const_120 = A_arbace_cpp_template__init_part1_A_const_pool.A[185]; A_arbace_cpp_template__init_part1_A_const_121 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[186]); A_arbace_cpp_template__init_part1_A_const_122 = A_arbace_cpp_template__init_part1_A_const_pool.A[187]; A_arbace_cpp_template__init_part1_A_const_123 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[188]); A_arbace_cpp_template__init_part1_A_const_124 = A_arbace_cpp_template__init_part1_A_const_pool.A[189]; A_arbace_cpp_template__init_part1_A_const_125 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[190]); A_arbace_cpp_template__init_part1_A_const_126 = A_arbace_cpp_template__init_part1_A_const_pool.A[191]; A_arbace_cpp_template__init_part1_A_const_127 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[192]); A_arbace_cpp_template__init_part1_A_const_128 = A_arbace_cpp_template__init_part1_A_const_pool.A[193]; A_arbace_cpp_template__init_part1_A_const_129 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[194]); A_arbace_cpp_template__init_part1_A_const_130 = A_arbace_cpp_template__init_part1_A_const_pool.A[195]; A_arbace_cpp_template__init_part1_A_const_131 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[196]); A_arbace_cpp_template__init_part1_A_const_132 = A_arbace_cpp_template__init_part1_A_const_pool.A[197]; A_arbace_cpp_template__init_part1_A_const_133 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[198]); A_arbace_cpp_template__init_part1_A_const_134 = A_arbace_cpp_template__init_part1_A_const_pool.A[199]; A_arbace_cpp_template__init_part1_A_const_135 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[200]); A_arbace_cpp_template__init_part1_A_const_136 = A_arbace_cpp_template__init_part1_A_const_pool.A[201]; A_arbace_cpp_template__init_part1_A_const_137 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[202]); A_arbace_cpp_template__init_part1_A_const_138 = A_arbace_cpp_template__init_part1_A_const_pool.A[203]; A_arbace_cpp_template__init_part1_A_const_139 = A_arbace_cpp_template__init_part1_A_const_pool.A[204]; A_arbace_cpp_template__init_part1_A_const_140 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[205]); A_arbace_cpp_template__init_part1_A_const_141 = A_arbace_cpp_template__init_part1_A_const_pool.A[206]; A_arbace_cpp_template__init_part1_A_const_142 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[207]); A_arbace_cpp_template__init_part1_A_const_143 = A_arbace_cpp_template__init_part1_A_const_pool.A[208]; A_arbace_cpp_template__init_part1_A_const_144 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[209]); A_arbace_cpp_template__init_part1_A_const_145 = A_arbace_cpp_template__init_part1_A_const_pool.A[210]; A_arbace_cpp_template__init_part1_A_const_146 = A_arbace_cpp_template__init_part1_A_const_pool.A[211]; A_arbace_cpp_template__init_part1_A_const_147 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[212]); A_arbace_cpp_template__init_part1_A_const_148 = A_arbace_cpp_template__init_part1_A_const_pool.A[213]; A_arbace_cpp_template__init_part1_A_const_149 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[214]); A_arbace_cpp_template__init_part1_A_const_150 = A_arbace_cpp_template__init_part1_A_const_pool.A[215]; A_arbace_cpp_template__init_part1_A_const_151 = A_arbace_cpp_template__init_part1_A_const_pool.A[216]; A_arbace_cpp_template__init_part1_A_const_152 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[217]); A_arbace_cpp_template__init_part1_A_const_153 = A_arbace_cpp_template__init_part1_A_const_pool.A[218]; A_arbace_cpp_template__init_part1_A_const_154 = A_arbace_cpp_template__init_part1_A_const_pool.A[219]; A_arbace_cpp_template__init_part1_A_const_155 = A_arbace_cpp_template__init_part1_A_const_pool.A[220]; A_arbace_cpp_template__init_part1_A_const_156 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[221]); A_arbace_cpp_template__init_part1_A_const_157 = A_arbace_cpp_template__init_part1_A_const_pool.A[222]; var tmp3 *lang.Var; A_arbace_cpp_template__init_part0_A_Init(); tmp3 = A_arbace_cpp_template__init_part0_A_const_165; A_arbace_cpp_template__init_part1_A_const_158 = tmp3; A_arbace_cpp_template__init_part1_A_const_159 = A_arbace_cpp_template__init_part1_A_const_pool.A[223]; A_arbace_cpp_template__init_part1_A_const_160 = A_arbace_cpp_template__init_part1_A_const_pool.A[224]; A_arbace_cpp_template__init_part1_A_const_161 = A_arbace_cpp_template__init_part1_A_const_pool.A[225]; A_arbace_cpp_template__init_part1_A_const_162 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[226]); A_arbace_cpp_template__init_part1_A_const_163 = A_arbace_cpp_template__init_part1_A_const_pool.A[227]; A_arbace_cpp_template__init_part1_A_const_164 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[228]); A_arbace_cpp_template__init_part1_A_const_165 = A_arbace_cpp_template__init_part1_A_const_pool.A[229]; A_arbace_cpp_template__init_part1_A_const_166 = A_arbace_cpp_template__init_part1_A_const_pool.A[230]; A_arbace_cpp_template__init_part1_A_const_167 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[231]); A_arbace_cpp_template__init_part1_A_const_168 = A_arbace_cpp_template__init_part1_A_const_pool.A[232]; A_arbace_cpp_template__init_part1_A_const_169 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[233]); A_arbace_cpp_template__init_part1_A_const_170 = A_arbace_cpp_template__init_part1_A_const_pool.A[234]; A_arbace_cpp_template__init_part1_A_const_171 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[235]); A_arbace_cpp_template__init_part1_A_const_172 = A_arbace_cpp_template__init_part1_A_const_pool.A[236]; A_arbace_cpp_template__init_part1_A_const_173 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[237]); A_arbace_cpp_template__init_part1_A_const_174 = A_arbace_cpp_template__init_part1_A_const_pool.A[238]; A_arbace_cpp_template__init_part1_A_const_175 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[239]); A_arbace_cpp_template__init_part1_A_const_176 = A_arbace_cpp_template__init_part1_A_const_pool.A[240]; A_arbace_cpp_template__init_part1_A_const_177 = A_arbace_cpp_template__init_part1_A_const_pool.A[241]; A_arbace_cpp_template__init_part1_A_const_178 = A_arbace_cpp_template__init_part1_A_const_pool.A[242]; var tmp4 *lang.Var; A_arbace_cpp_template__init_part0_A_Init(); tmp4 = A_arbace_cpp_template__init_part0_A_const_157; A_arbace_cpp_template__init_part1_A_const_179 = tmp4; A_arbace_cpp_template__init_part1_A_const_180 = A_arbace_cpp_template__init_part1_A_const_pool.A[243]; A_arbace_cpp_template__init_part1_A_const_181 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[244]); A_arbace_cpp_template__init_part1_A_const_182 = A_arbace_cpp_template__init_part1_A_const_pool.A[245]; A_arbace_cpp_template__init_part1_A_const_183 = lang.Var_Cast(A_arbace_cpp_template__init_part1_A_const_pool.A[246]); A_arbace_cpp_template__init_part1_A_const_184 = A_arbace_cpp_template__init_part1_A_const_pool.A[247] }

func A_arbace_cpp_template__init_part1_A_New() *A_arbace_cpp_template__init_part1_A { A_arbace_cpp_template__init_part1_A_Init(); t := &A_arbace_cpp_template__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_template__init_part1_A) Ctor() {}

func (t *A_arbace_cpp_template__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_template__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_template__init_part1_A_class }

func (t *A_arbace_cpp_template__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_template__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_template__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_template__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_template__init_part1_A); return ok }

func A_arbace_cpp_template__init_part1_A_Cast(x any) *A_arbace_cpp_template__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_template__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_template__init_part1_A_class)) }; return v }



type A_arbace_cpp_template__init_part2_A struct{ jrt.Object }

var A_arbace_cpp_template__init_part2_A_const_pool *jrt.RefArray

var A_arbace_cpp_template__init_part2_A_const_0 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_1 any

var A_arbace_cpp_template__init_part2_A_const_2 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_3 any

var A_arbace_cpp_template__init_part2_A_const_4 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_5 any

var A_arbace_cpp_template__init_part2_A_const_6 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_7 any

var A_arbace_cpp_template__init_part2_A_const_8 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_9 any

var A_arbace_cpp_template__init_part2_A_const_10 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_11 any

var A_arbace_cpp_template__init_part2_A_const_12 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_13 any

var A_arbace_cpp_template__init_part2_A_const_14 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_15 any

var A_arbace_cpp_template__init_part2_A_const_16 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_17 any

var A_arbace_cpp_template__init_part2_A_const_18 any

var A_arbace_cpp_template__init_part2_A_const_19 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_20 any

var A_arbace_cpp_template__init_part2_A_const_21 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_22 any

var A_arbace_cpp_template__init_part2_A_const_23 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_24 any

var A_arbace_cpp_template__init_part2_A_const_25 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_26 any

var A_arbace_cpp_template__init_part2_A_const_27 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_28 any

var A_arbace_cpp_template__init_part2_A_const_29 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_30 any

var A_arbace_cpp_template__init_part2_A_const_31 any

var A_arbace_cpp_template__init_part2_A_const_32 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_33 any

var A_arbace_cpp_template__init_part2_A_const_34 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_35 any

var A_arbace_cpp_template__init_part2_A_const_36 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_37 any

var A_arbace_cpp_template__init_part2_A_const_38 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_39 any

var A_arbace_cpp_template__init_part2_A_const_40 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_41 any

var A_arbace_cpp_template__init_part2_A_const_42 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_43 any

var A_arbace_cpp_template__init_part2_A_const_44 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_45 any

var A_arbace_cpp_template__init_part2_A_const_46 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_47 any

var A_arbace_cpp_template__init_part2_A_const_48 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_49 any

var A_arbace_cpp_template__init_part2_A_const_50 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_51 any

var A_arbace_cpp_template__init_part2_A_const_52 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_53 any

var A_arbace_cpp_template__init_part2_A_const_54 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_55 any

var A_arbace_cpp_template__init_part2_A_const_56 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_57 any

var A_arbace_cpp_template__init_part2_A_const_58 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_59 any

var A_arbace_cpp_template__init_part2_A_const_60 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_61 any

var A_arbace_cpp_template__init_part2_A_const_62 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_63 any

var A_arbace_cpp_template__init_part2_A_const_64 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_65 any

var A_arbace_cpp_template__init_part2_A_const_66 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_67 any

var A_arbace_cpp_template__init_part2_A_const_68 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_69 any

var A_arbace_cpp_template__init_part2_A_const_70 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_71 any

var A_arbace_cpp_template__init_part2_A_const_72 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_73 any

var A_arbace_cpp_template__init_part2_A_const_74 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_75 any

var A_arbace_cpp_template__init_part2_A_const_76 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_77 any

var A_arbace_cpp_template__init_part2_A_const_78 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_79 any

var A_arbace_cpp_template__init_part2_A_const_80 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_81 any

var A_arbace_cpp_template__init_part2_A_const_82 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_83 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_84 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_85 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_86 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_87 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_88 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_89 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_90 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_91 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_92 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_93 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_94 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_95 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_96 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_97 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_98 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_99 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_100 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_101 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_102 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_103 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_104 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_105 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_106 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_107 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_108 *lang.Var

var A_arbace_cpp_template__init_part2_A_const_109 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_110 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_111 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_112 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_const_113 *lang.Keyword

var A_arbace_cpp_template__init_part2_A_init jrt.ClassInit

func A_arbace_cpp_template__init_part2_A_Init() { if !A_arbace_cpp_template__init_part2_A_init.Done() { A_arbace_cpp_template__init_part2_A_init.Run(A_arbace_cpp_template__init_part2_A_clinit) } }

func A_arbace_cpp_template__init_part2_A_clinit() { A_arbace_cpp_template__init_part2_A_clinit_p0(); A_arbace_cpp_template__init_part2_A_clinit_p1() }

func A_arbace_cpp_template__init_part2_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_template__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1188, 179); A_arbace_cpp_template__init_part2_A_const_0 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[73]); A_arbace_cpp_template__init_part2_A_const_1 = A_arbace_cpp_template__init_part2_A_const_pool.A[74]; A_arbace_cpp_template__init_part2_A_const_2 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[75]); A_arbace_cpp_template__init_part2_A_const_3 = A_arbace_cpp_template__init_part2_A_const_pool.A[76]; A_arbace_cpp_template__init_part2_A_const_4 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[77]); A_arbace_cpp_template__init_part2_A_const_5 = A_arbace_cpp_template__init_part2_A_const_pool.A[78]; A_arbace_cpp_template__init_part2_A_const_6 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[79]); A_arbace_cpp_template__init_part2_A_const_7 = A_arbace_cpp_template__init_part2_A_const_pool.A[80]; A_arbace_cpp_template__init_part2_A_const_8 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[81]); A_arbace_cpp_template__init_part2_A_const_9 = A_arbace_cpp_template__init_part2_A_const_pool.A[82] }

func A_arbace_cpp_template__init_part2_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_cpp_template__init_part1_A_Init(); tmp1 = A_arbace_cpp_template__init_part1_A_const_152; A_arbace_cpp_template__init_part2_A_const_10 = tmp1; A_arbace_cpp_template__init_part2_A_const_11 = A_arbace_cpp_template__init_part2_A_const_pool.A[83]; A_arbace_cpp_template__init_part2_A_const_12 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[84]); A_arbace_cpp_template__init_part2_A_const_13 = A_arbace_cpp_template__init_part2_A_const_pool.A[85]; A_arbace_cpp_template__init_part2_A_const_14 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[86]); A_arbace_cpp_template__init_part2_A_const_15 = A_arbace_cpp_template__init_part2_A_const_pool.A[87]; A_arbace_cpp_template__init_part2_A_const_16 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[88]); A_arbace_cpp_template__init_part2_A_const_17 = A_arbace_cpp_template__init_part2_A_const_pool.A[89]; A_arbace_cpp_template__init_part2_A_const_18 = A_arbace_cpp_template__init_part2_A_const_pool.A[90]; var tmp2 *lang.Var; A_arbace_cpp_template__init_part0_A_Init(); tmp2 = A_arbace_cpp_template__init_part0_A_const_107; A_arbace_cpp_template__init_part2_A_const_19 = tmp2; A_arbace_cpp_template__init_part2_A_const_20 = A_arbace_cpp_template__init_part2_A_const_pool.A[91]; A_arbace_cpp_template__init_part2_A_const_21 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[92]); A_arbace_cpp_template__init_part2_A_const_22 = A_arbace_cpp_template__init_part2_A_const_pool.A[93]; A_arbace_cpp_template__init_part2_A_const_23 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[94]); A_arbace_cpp_template__init_part2_A_const_24 = A_arbace_cpp_template__init_part2_A_const_pool.A[95]; A_arbace_cpp_template__init_part2_A_const_25 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[96]); A_arbace_cpp_template__init_part2_A_const_26 = A_arbace_cpp_template__init_part2_A_const_pool.A[97]; A_arbace_cpp_template__init_part2_A_const_27 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[98]); A_arbace_cpp_template__init_part2_A_const_28 = A_arbace_cpp_template__init_part2_A_const_pool.A[99]; A_arbace_cpp_template__init_part2_A_const_29 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[100]); A_arbace_cpp_template__init_part2_A_const_30 = A_arbace_cpp_template__init_part2_A_const_pool.A[101]; A_arbace_cpp_template__init_part2_A_const_31 = A_arbace_cpp_template__init_part2_A_const_pool.A[102]; A_arbace_cpp_template__init_part2_A_const_32 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[103]); A_arbace_cpp_template__init_part2_A_const_33 = A_arbace_cpp_template__init_part2_A_const_pool.A[104]; A_arbace_cpp_template__init_part2_A_const_34 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[105]); A_arbace_cpp_template__init_part2_A_const_35 = A_arbace_cpp_template__init_part2_A_const_pool.A[106]; A_arbace_cpp_template__init_part2_A_const_36 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[107]); A_arbace_cpp_template__init_part2_A_const_37 = A_arbace_cpp_template__init_part2_A_const_pool.A[108]; A_arbace_cpp_template__init_part2_A_const_38 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[109]); A_arbace_cpp_template__init_part2_A_const_39 = A_arbace_cpp_template__init_part2_A_const_pool.A[110]; A_arbace_cpp_template__init_part2_A_const_40 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[111]); A_arbace_cpp_template__init_part2_A_const_41 = A_arbace_cpp_template__init_part2_A_const_pool.A[112]; A_arbace_cpp_template__init_part2_A_const_42 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[113]); A_arbace_cpp_template__init_part2_A_const_43 = A_arbace_cpp_template__init_part2_A_const_pool.A[114]; A_arbace_cpp_template__init_part2_A_const_44 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[115]); A_arbace_cpp_template__init_part2_A_const_45 = A_arbace_cpp_template__init_part2_A_const_pool.A[116]; A_arbace_cpp_template__init_part2_A_const_46 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[117]); A_arbace_cpp_template__init_part2_A_const_47 = A_arbace_cpp_template__init_part2_A_const_pool.A[118]; A_arbace_cpp_template__init_part2_A_const_48 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[119]); A_arbace_cpp_template__init_part2_A_const_49 = A_arbace_cpp_template__init_part2_A_const_pool.A[120]; A_arbace_cpp_template__init_part2_A_const_50 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[121]); A_arbace_cpp_template__init_part2_A_const_51 = A_arbace_cpp_template__init_part2_A_const_pool.A[122]; A_arbace_cpp_template__init_part2_A_const_52 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[123]); A_arbace_cpp_template__init_part2_A_const_53 = A_arbace_cpp_template__init_part2_A_const_pool.A[124]; A_arbace_cpp_template__init_part2_A_const_54 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[125]); A_arbace_cpp_template__init_part2_A_const_55 = A_arbace_cpp_template__init_part2_A_const_pool.A[126]; A_arbace_cpp_template__init_part2_A_const_56 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[127]); A_arbace_cpp_template__init_part2_A_const_57 = A_arbace_cpp_template__init_part2_A_const_pool.A[128]; A_arbace_cpp_template__init_part2_A_const_58 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[129]); A_arbace_cpp_template__init_part2_A_const_59 = A_arbace_cpp_template__init_part2_A_const_pool.A[130]; A_arbace_cpp_template__init_part2_A_const_60 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[131]); A_arbace_cpp_template__init_part2_A_const_61 = A_arbace_cpp_template__init_part2_A_const_pool.A[132]; A_arbace_cpp_template__init_part2_A_const_62 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[133]); A_arbace_cpp_template__init_part2_A_const_63 = A_arbace_cpp_template__init_part2_A_const_pool.A[134]; A_arbace_cpp_template__init_part2_A_const_64 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[135]); A_arbace_cpp_template__init_part2_A_const_65 = A_arbace_cpp_template__init_part2_A_const_pool.A[136]; A_arbace_cpp_template__init_part2_A_const_66 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[137]); A_arbace_cpp_template__init_part2_A_const_67 = A_arbace_cpp_template__init_part2_A_const_pool.A[138]; A_arbace_cpp_template__init_part2_A_const_68 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[139]); A_arbace_cpp_template__init_part2_A_const_69 = A_arbace_cpp_template__init_part2_A_const_pool.A[140]; A_arbace_cpp_template__init_part2_A_const_70 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[141]); A_arbace_cpp_template__init_part2_A_const_71 = A_arbace_cpp_template__init_part2_A_const_pool.A[142]; A_arbace_cpp_template__init_part2_A_const_72 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[143]); A_arbace_cpp_template__init_part2_A_const_73 = A_arbace_cpp_template__init_part2_A_const_pool.A[144]; A_arbace_cpp_template__init_part2_A_const_74 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[145]); A_arbace_cpp_template__init_part2_A_const_75 = A_arbace_cpp_template__init_part2_A_const_pool.A[146]; A_arbace_cpp_template__init_part2_A_const_76 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[147]); A_arbace_cpp_template__init_part2_A_const_77 = A_arbace_cpp_template__init_part2_A_const_pool.A[148]; A_arbace_cpp_template__init_part2_A_const_78 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[149]); A_arbace_cpp_template__init_part2_A_const_79 = A_arbace_cpp_template__init_part2_A_const_pool.A[150]; A_arbace_cpp_template__init_part2_A_const_80 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[151]); A_arbace_cpp_template__init_part2_A_const_81 = A_arbace_cpp_template__init_part2_A_const_pool.A[152]; A_arbace_cpp_template__init_part2_A_const_82 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[153]); A_arbace_cpp_template__init_part2_A_const_83 = lang.Var_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[154]); A_arbace_cpp_template__init_part2_A_const_84 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[155]); A_arbace_cpp_template__init_part2_A_const_85 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[156]); var tmp3 *lang.Var; A_arbace_cpp_template__init_part1_A_Init(); tmp3 = A_arbace_cpp_template__init_part1_A_const_135; A_arbace_cpp_template__init_part2_A_const_86 = tmp3; A_arbace_cpp_template__init_part2_A_const_87 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[157]); A_arbace_cpp_template__init_part2_A_const_88 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[158]); A_arbace_cpp_template__init_part2_A_const_89 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[159]); var tmp4 *lang.Var; A_arbace_cpp_template__init_part1_A_Init(); tmp4 = A_arbace_cpp_template__init_part1_A_const_82; A_arbace_cpp_template__init_part2_A_const_90 = tmp4; A_arbace_cpp_template__init_part2_A_const_91 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[160]); A_arbace_cpp_template__init_part2_A_const_92 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[161]); A_arbace_cpp_template__init_part2_A_const_93 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[162]); var tmp5 *lang.Var; A_arbace_cpp_template__init_part0_A_Init(); tmp5 = A_arbace_cpp_template__init_part0_A_const_93; A_arbace_cpp_template__init_part2_A_const_94 = tmp5; A_arbace_cpp_template__init_part2_A_const_95 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[163]); var tmp6 *lang.Var; A_arbace_cpp_template__init_part0_A_Init(); tmp6 = A_arbace_cpp_template__init_part0_A_const_186; A_arbace_cpp_template__init_part2_A_const_96 = tmp6; A_arbace_cpp_template__init_part2_A_const_97 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[164]); A_arbace_cpp_template__init_part2_A_const_98 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[165]); var tmp7 *lang.Var; A_arbace_cpp_template__init_part1_A_Init(); tmp7 = A_arbace_cpp_template__init_part1_A_const_175; A_arbace_cpp_template__init_part2_A_const_99 = tmp7; A_arbace_cpp_template__init_part2_A_const_100 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[166]); A_arbace_cpp_template__init_part2_A_const_101 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[167]); A_arbace_cpp_template__init_part2_A_const_102 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[168]); A_arbace_cpp_template__init_part2_A_const_103 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[169]); A_arbace_cpp_template__init_part2_A_const_104 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[170]); A_arbace_cpp_template__init_part2_A_const_105 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[171]); A_arbace_cpp_template__init_part2_A_const_106 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[172]); A_arbace_cpp_template__init_part2_A_const_107 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[173]); var tmp8 *lang.Var; A_arbace_cpp_template__init_part1_A_Init(); tmp8 = A_arbace_cpp_template__init_part1_A_const_60; A_arbace_cpp_template__init_part2_A_const_108 = tmp8; A_arbace_cpp_template__init_part2_A_const_109 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[174]); A_arbace_cpp_template__init_part2_A_const_110 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[175]); A_arbace_cpp_template__init_part2_A_const_111 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[176]); A_arbace_cpp_template__init_part2_A_const_112 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[177]); A_arbace_cpp_template__init_part2_A_const_113 = lang.Keyword_Cast(A_arbace_cpp_template__init_part2_A_const_pool.A[178]) }

func A_arbace_cpp_template__init_part2_A_New() *A_arbace_cpp_template__init_part2_A { A_arbace_cpp_template__init_part2_A_Init(); t := &A_arbace_cpp_template__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_template__init_part2_A) Ctor() {}

func (t *A_arbace_cpp_template__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_template__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_template__init_part2_A_class }

func (t *A_arbace_cpp_template__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_template__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_template__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_template__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_template__init_part2_A); return ok }

func A_arbace_cpp_template__init_part2_A_Cast(x any) *A_arbace_cpp_template__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_template__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_template__init_part2_A_class)) }; return v }
