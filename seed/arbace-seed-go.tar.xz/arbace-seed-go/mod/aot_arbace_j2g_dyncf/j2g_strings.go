//line j2g_strings.ae:1
package aot_arbace_j2g_dyncf

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn11,arbace.walkyn4,walkyn20,arbace.classes.typesyn1,tyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn15,arbace.j2g.codeyn1,cyn14,arbace.j2g.dynyn3,dynyn14,arbace.j2g.jrtyn3,jrtyn11,arbace.corekn3,dockn3,tagkn4,elseyn6,assertkn4,langyn8,dynUnboxyn4,instys3,jrt2,Asyn1,*kn3,pkgys2,go4,funcyn2,dcyn8,DynClasskn4,linekn6,columnyn1,fyn5,sliceyn3,anyyn2,doyn3,letyn4,set!yn6,.-Selfyn12,.MarkDynamicyn4,addryn3,litkn7,dynCoreyn7,dynCorekn1,Dkn1,Fys2,go3,varyn3,mapyn6,stringyn4,funckn4,namekn4,desckn3,jrtyn2,fnyn1,oyn4,argsyn4,agetkn7,methodskn4,kindkn7,defaultkn5,ownerkn8,jrt-implkn5,classkn8,promotedyn6,returnys3,jrt3,Boxyn8,cfSubForkn7,resultsyn6,switchyn4,caseys3,jrt5,Classyn12,cfIsInstanceyn4,boolyn4,whenyn2,==yn1,xyn6,valuesyn1,_yn2,okys3,jrt8,Object_Iyn3,notyn1,kys3,jrt8,GetClassyn5,whileyn2,!=yn7,.-Superyn5,.Infoyn4,makeyn13,cfInterpretedyn5,.Lockyn5,dynMuyn10,dynClassesyn7,.Unlockyn3,andyn4,.-CFyn9,cfGoValueyn15,.IsPrimitive__Zyn5,ftypeyn1,vys3,jrt5,Unboxys3,j2g7,commentyn4,nameys3,jrt6,Stringyn5,superyn10,interfacesys3,jrt8,RefArrayyn5,flagsyn5,int32yn4,kindyn5,klassyn3,ifsyn12,dynClassListyn4,infoys3,jrt9,ClassInfokn4,Nameyn7,.Stringys3,jrt2,NNkn9,Modifiersyn6,bit-orys3,jrt12,AccInterfaceys3,jrt11,AccAbstractkn4,Kindys3,jrt13,KindInterfacekn10,Interfaceskn2,Goys3,jrt13,DefineDynamicyn12,.-IsInstanceyn1,dyn9,dynObjectyn14,.DynImplementsys3,jrt12,Object_classys3,jrt9,KindClasskn5,Superyn4,baseyn2,nwyn6,bslotsyn4,bownyn9,dynSubForyn5,panicys3,jrt6,Thrownys3,jrt40,UnsupportedOperationException_New_Stringys3,jrt3,Stryn1,+yn6,.-Nameyn5,slotskn5,Slotsyn3,IFnyn3,lenkn7,SlotMapkn3,Ownkn6,Ifaceskn5,ByKeykn2,CFyn9,.-SlotMapyn8,dynSlotsyn7,.-Slotsyn5,rangeyn1,iyn15,dynAddInterfaceyn1,syn12,.-Interfacesyn5,.-Clsyn4,asetyn6,cfNewsyn10,dynClassOfyn3,.-Ayn6,newDynyn2,oryn5,ctorsyn4,descyn3,keyyn6,supersyn11,.-Declaringyn5,outeryn6,simpleyn8,.-Simpleyn9,.-Methodsyn7,.-Ctorsyn8,.-Fieldsys3,jrt21,ClearReflectionCachesyn6,.-Kindys3,jrt8,KindEnumyn6,.-Enumyn10,.Invoke__Oyn11,.DynClassOfyn2,psyn6,paramsyn7,bit-andys3,jrt9,AccStaticyn6,appendys3,jrt10,MethodInfokn6,Paramskn6,Returnyn3,retkn6,Invokeyn10,dynConvertyn7,dynCallyn4,implyn1,pyn11,.Descriptoryn7,.-ByKeyyn5,dynOfyn4,thisyn11,dynAbstractys3,jrt8,CtorInfokn3,Newys3,jrt9,FieldInfokn4,Typekn3,Getys11,arbace.core5,derefyn10,.DynFieldskn3,Setyn5,storeyn4,inityn6,.-Initkn4,annskn4,anonkn5,localkn7,nestingkn7,tparamskn6,superskn5,flagskn4,argskn5,ctorskn6,paramskn6,boundsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,v11,arbace.core5,referR19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.dyncfm2,R20,s596,The natives of Compiler$CFGo (arbace/lang/Compiler.ae), the Go build's host of the class\n  forms at the REPL (doc/go/CLASSFORMS-REPL.md), in arbace/lang's j2g_cf.go: classes made at run\n  time for interpreted classes, over Dyn (J2G-SPEC §5.12, arbace.j2g.dyn): a class extending\n  Object or another interpreted class, implementing interfaces of the world (Dyn's slots) and\n  interfaces made at run time (the class's methods by key); an interface; a Clojure fn's class\n  (objects CF$FnObj). Member tables carry the classes' methods, constructors and fields, with\n  their modifiers, for reflection.v16,arbace.j2g.model11,translated?v16,arbace.j2g.dyncf9,api-classv11,arbace.core9,with-metaR21,v11,arbace.core6,symbolv16,arbace.j2g.model7,go-namev16,arbace.j2g.names11,method-basev20,arbace.classes.types5,prim?v11,arbace.core4,listR22,R23,v16,arbace.j2g.model7,go-typeR24,R25,v20,arbace.classes.types15,prim-desc->nameR26,R27,v16,arbace.j2g.dyncf8,sub-namev11,arbace.core19,pop-thread-bindingsR28,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv15,arbace.j2g.code3,*f*m2,R29,R24,R30,v16,arbace.j2g.dyncf3,tagR31,ML2,R28,R32,m4,R33,i55,R34,i74,R35,ML2,R36,R37,m4,R33,i55,R34,i97,m2,R21,R37,v16,arbace.j2g.model13,hand-written?v16,arbace.j2g.model13,trivial-init?ML1,R38,m4,R33,i57,R34,i17,v16,arbace.j2g.model9,class-symR39,ML3,R40,ML2,R41,R6,m4,R33,i60,R34,i27,R6,m4,R33,i60,R34,i21,ML2,R42,R6,m4,R33,i62,R34,i21,R6,R6,R43,R44,R45,ML6,R44,R46,R47,R31,R48,R35,m4,R33,i59,R34,i73,R49,ML3,R50,R51,ML2,R52,V2,R37,ML2,R36,R37,m4,R33,i64,R34,i82,m4,R33,i64,R34,i71,m4,R33,i64,R34,i59,v11,arbace.core5,applyR44,ML3,R50,R51,ML2,R52,V2,R37,ML2,R36,R37,m4,R33,i65,R34,i55,m4,R33,i65,R34,i44,m4,R33,i65,R34,i32,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferR53,v11,arbace.core3,notv16,arbace.j2g.model8,private?v16,arbace.j2g.model15,mdesc-in-world?R54,v11,arbace.core9,contains?v14,arbace.j2g.jrt14,struct-methodsR55,v16,arbace.j2g.model3,*w*v16,arbace.j2g.names9,ctor-basev22,arbace.classes.analyze14,ctor-real-descv20,arbace.classes.types17,parse-method-descv11,arbace.core12,chunk-appendR56,R57,R37,R58,ML2,R36,R37,m4,R33,i75,R34,i61,R39,R6,R6,v11,arbace.core11,map-indexedv16,arbace.j2g.dyncf11,from-objectR59,R58,R6,R23,R57,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv16,arbace.j2g.model10,methods-ofR60,v22,arbace.classes.analyze4,declR49,ML3,R50,R51,ML3,R52,V2,R37,ML2,R36,R37,m4,R33,i80,R34,i83,V1,R37,m4,R33,i80,R34,i72,m4,R33,i80,R34,i60,R44,ML3,R50,R51,ML3,R52,V2,R37,ML2,R36,R37,m4,R33,i81,R34,i55,V1,R37,m4,R33,i81,R34,i44,m4,R33,i81,R34,i32,v16,arbace.j2g.model7,impl-ofR59,R58,R61,R62,R63,R6,R64,R6,R6,R65,R66,R6,R56,R57,R37,R58,ML2,R36,R37,m4,R33,i95,R34,i72,m2,R21,R37,R39,R6,R23,R57,R38,ML2,R67,nm4,R33,i98,R34,i54,R67,R68,m2,R21,R37,v11,arbace.core7,sort-byv16,arbace.j2g.model8,vmethodsv14,arbace.j2g.dyn13,proxy-classesv11,arbace.core6,concatv11,arbace.core6,mapcatv16,arbace.j2g.dyncf9,sub-formsR30,R69,R70,V3,ML3,R52,V2,ML2,R28,R32,m4,R33,i111,R34,i32,ML2,R36,R37,m4,R33,i111,R34,i45,V1,R37,m4,R33,i111,R34,i25,ML3,R50,R51,ML2,R52,V2,R37,ML2,R36,R37,m4,R33,i111,R34,i88,m4,R33,i111,R34,i77,m4,R33,i111,R34,i65,ML3,R50,R51,ML3,R52,V2,R37,ML2,R36,R37,m4,R33,i112,R34,i48,V1,R37,m4,R33,i112,R34,i37,m4,R33,i112,R34,i25,R71,R14,R72,R67,ML4,R67,nnnm4,R33,i118,R34,i15,R14,ML2,R28,R73,m4,R33,i110,R34,i24,v16,arbace.j2g.dyncf10,subs-formsML8,R30,R74,s139,cfIsInstance: whether x's class is c or a subclass of c (an interpreted class's objects: Dyn,\nor CF$FnObj, whose getClass is their class).\nMV2,Myn1,cm2,R21,ML2,R28,R73,m4,R33,i129,R34,i21,Myn1,xm2,R21,R37,m2,R21,R75,ML3,R76,ML3,R77,R78,nm4,R33,i130,R34,i13,ML2,R67,Fm4,R33,i130,R34,i24,m4,R33,i130,R34,i7,ML3,R39,V2,ML3,R79,R80,R81,m4,R33,i131,R34,i13,ML3,R23,R82,R78,m4,R33,i131,R34,i27,ML3,R76,ML2,R83,R81,m4,R33,i132,R34,i15,ML2,R67,Fm4,R33,i132,R34,i24,m4,R33,i132,R34,i9,m4,R33,i131,R34,i7,ML3,R39,V2,R84,ML2,R85,R78,m4,R33,i133,R34,i15,ML4,R86,ML3,R87,R84,nm4,R33,i134,R34,i16,ML3,R76,ML3,R77,R84,R14,m4,R33,i135,R34,i17,ML2,R67,Tm4,R33,i135,R34,i26,m4,R33,i135,R34,i11,ML3,R40,R84,ML2,R88,ML2,R89,R84,m4,R33,i136,R34,i28,m4,R33,i136,R34,i19,m4,R33,i136,R34,i11,m4,R33,i134,R34,i9,m4,R33,i133,R34,i7,Fm4,R33,i126,R34,i5,ML3,R49,Myn6,cfNewsm4,R21,ML3,R50,ML2,R28,R73,m4,R33,i194,R34,i25,ML3,R52,V2,ML2,R28,R32,m4,R33,i194,R34,i46,ML2,R36,R37,m4,R33,i194,R34,i59,V1,R37,m4,R33,i194,R34,i39,m4,R33,i194,R34,i20,R20,s92,cfNews: the allocation of the interpreted classes whose objects are DynSub_C (under dynMu).\nML2,R90,ML3,R50,ML2,R28,R73,m4,R33,i196,R34,i25,ML3,R52,V2,ML2,R28,R32,m4,R33,i196,R34,i46,ML2,R36,R37,m4,R33,i196,R34,i59,V1,R37,m4,R33,i196,R34,i39,m4,R33,i196,R34,i20,m4,R33,i196,R34,i14,m4,R33,i194,R34,i5,ML6,R30,R91,s74,cfInterpreted: whether c is an interpreted class (made by Compiler$CFGo).\nMV1,Myn1,cm2,R21,ML2,R28,R73,m4,R33,i198,R34,i21,m2,R21,R75,ML2,R92,R93,m4,R33,i199,R34,i7,ML4,R39,V2,ML3,R79,R31,R81,m4,R33,i200,R34,i13,ML3,R59,R94,R14,m4,R33,i200,R34,i28,ML2,R95,R93,m4,R33,i201,R34,i9,ML3,R96,R81,ML3,R87,ML2,R97,R31,m4,R33,i202,R34,i21,nm4,R33,i202,R34,i17,m4,R33,i202,R34,i9,m4,R33,i200,R34,i7,m4,R33,i197,R34,i5,ML6,R30,R98,s102,cfGoValue: a field's value (an object) in the member tables' convention: a primitive as its Go\nvalue.\nMV2,Myn5,ftypem2,R21,ML2,R28,R73,m4,R33,i321,R34,i20,Myn1,vm2,R21,R37,m2,R21,R37,ML3,R76,ML3,R96,ML2,R99,R100,m4,R33,i322,R34,i18,ML3,R87,R101,nm4,R33,i322,R34,i42,m4,R33,i322,R34,i13,ML3,R39,V2,ML3,R79,R78,R81,m4,R33,i323,R34,i15,ML3,R102,R100,R101,m4,R33,i323,R34,i29,ML3,R76,R81,ML2,R67,R78,m4,R33,i324,R34,i20,m4,R33,i324,R34,i11,m4,R33,i323,R34,i9,m4,R33,i322,R34,i7,R101,m4,R33,i318,R34,i5,R103,R30,v16,arbace.j2g.dyncf11,native-nameR104,ML2,R28,R105,m4,R33,i139,R34,i34,R106,ML2,R28,R73,m4,R33,i139,R34,i63,R107,ML2,R28,R108,m4,R33,i139,R34,i96,R109,R110,R111,R110,R112,R37,m2,R21,ML2,R28,R73,m4,R33,i141,R34,i19,ML6,R39,V2,R113,ML2,R114,R107,m4,R33,i142,R34,i21,ML3,R76,ML3,R77,R111,l1,m4,R33,i143,R34,i19,ML4,R39,V4,R115,ML2,R43,ML12,R44,R116,R117,ML2,R118,ML2,R119,R104,m4,R33,i144,R34,i66,m4,R33,i144,R34,i57,R120,ML4,R121,R109,R122,R123,m4,R33,i145,R34,i48,R124,R125,R126,R113,R127,s37,arbace/lang.Dyn (Java form interface)m4,R33,i144,R34,i32,m4,R33,i144,R34,i26,R14,ML2,R128,R115,m4,R33,i148,R34,i23,ML3,R40,ML2,R129,R115,m4,R33,i149,R34,i23,ML3,R56,MV1,Myn1,xm2,R21,R37,m2,R21,R75,ML3,R39,V2,ML3,R79,R130,R81,m4,R33,i151,R34,i31,ML3,R23,R131,R78,m4,R33,i151,R34,i45,ML3,R96,R81,ML3,R132,R130,R14,m4,R33,i152,R34,i35,m4,R33,i152,R34,i27,m4,R33,i151,R34,i25,m4,R33,i150,R34,i23,m4,R33,i149,R34,i17,ML2,R67,R14,m4,R33,i153,R34,i17,m4,R33,i144,R34,i15,m4,R33,i143,R34,i13,ML3,R76,ML3,R77,R106,nm4,R33,i154,R34,i19,ML3,R40,R106,R133,m4,R33,i154,R34,i34,m4,R33,i154,R34,i13,ML3,R76,ML3,R77,R111,l2,m4,R33,i155,R34,i19,ML4,R39,V4,R115,ML2,R43,ML14,R44,R116,R117,ML2,R118,ML2,R119,R104,m4,R33,i156,R34,i66,m4,R33,i156,R34,i57,R120,R109,R124,R134,R135,R106,R126,R113,R127,s44,arbace/lang.Compiler_CF_FnObj (Java form fn)m4,R33,i156,R34,i32,m4,R33,i156,R34,i26,R14,ML2,R128,R115,m4,R33,i159,R34,i23,ML3,R40,ML2,R129,R115,m4,R33,i160,R34,i23,ML3,R56,MV1,Myn1,xm2,R21,R37,m2,R21,R75,ML3,R74,R14,R78,m4,R33,i160,R34,i62,m4,R33,i160,R34,i43,m4,R33,i160,R34,i17,ML2,R67,R14,m4,R33,i161,R34,i17,m4,R33,i156,R34,i15,m4,R33,i155,R34,i13,ML4,R39,V2,R136,R106,ML3,R86,ML2,R91,R136,m4,R33,i164,R34,i22,ML3,R40,R136,ML2,R88,ML2,R89,R136,m4,R33,i164,R34,i63,m4,R33,i164,R34,i54,m4,R33,i164,R34,i43,m4,R33,i164,R34,i15,ML4,R39,V4,ML4,R79,R137,R80,R80,m4,R33,i165,R34,i21,ML2,R69,R136,m4,R33,i165,R34,i37,ML4,R79,R138,R80,R139,m4,R33,i166,R34,i21,ML2,R140,R136,m4,R33,i166,R34,i44,ML3,R76,ML3,R96,ML3,R87,R136,R133,m4,R33,i167,R34,i28,ML3,R77,R137,nm4,R33,i167,R34,i55,m4,R33,i167,R34,i23,ML2,R141,ML2,R142,ML2,R143,ML2,R144,ML4,R145,s18,a class extending ML2,R146,ML2,R89,R136,m4,R33,i169,R34,i81,m4,R33,i169,R34,i73,s23, is not in the Go buildm4,R33,i169,R34,i49,m4,R33,i169,R34,i40,m4,R33,i168,R34,i38,m4,R33,i168,R34,i26,m4,R33,i168,R34,i19,m4,R33,i167,R34,i17,ML6,R39,V6,R147,R138,R115,ML2,R43,ML14,R44,R116,R117,ML2,R118,ML2,R119,R104,m4,R33,i171,R34,i64,m4,R33,i171,R34,i55,R120,R109,R124,R134,R135,R106,R126,R113,R127,s27,arbace/lang.Dyn (Java form)m4,R33,i171,R34,i30,m4,R33,i171,R34,i24,R31,ML2,R43,ML14,R44,R32,R148,ML3,R90,ML2,R36,R149,m4,R33,i174,R34,i55,ML2,R150,R147,m4,R33,i174,R34,i67,m4,R33,i174,R34,i49,R151,R147,R152,R139,R153,ML2,R90,ML3,R50,ML2,R28,R73,m4,R33,i175,R34,i52,R75,m4,R33,i175,R34,i47,m4,R33,i175,R34,i41,R154,ML2,R90,ML3,R50,R51,R149,m4,R33,i175,R34,i86,m4,R33,i175,R34,i80,R155,R112,m4,R33,i174,R34,i28,m4,R33,i174,R34,i22,ML4,R76,ML3,R77,R137,nm4,R33,i177,R34,i21,ML3,R40,ML2,R156,R31,m4,R33,i178,R34,i23,R157,m4,R33,i178,R34,i17,ML3,R40,ML2,R158,R31,m4,R33,i179,R34,i23,ML3,R90,ML2,R36,R149,m4,R33,i179,R34,i42,ML2,R150,R157,m4,R33,i179,R34,i54,m4,R33,i179,R34,i36,m4,R33,i179,R34,i17,m4,R33,i177,R34,i15,ML3,R159,V3,R80,R160,R113,ML3,R161,R31,R160,m4,R33,i180,R34,i32,m4,R33,i180,R34,i15,ML3,R39,V2,R162,R106,ML4,R86,ML3,R87,R162,nm4,R33,i183,R34,i24,ML3,R159,V3,R80,R160,ML2,R163,ML2,R89,R162,m4,R33,i184,R34,i45,m4,R33,i184,R34,i31,ML3,R161,R31,R160,m4,R33,i184,R34,i57,m4,R33,i184,R34,i19,ML3,R40,R162,ML2,R88,ML2,R89,R162,m4,R33,i185,R34,i36,m4,R33,i185,R34,i27,m4,R33,i185,R34,i19,m4,R33,i183,R34,i17,m4,R33,i182,R34,i15,ML9,R39,V2,R14,ML2,R128,R115,m4,R33,i186,R34,i23,ML3,R40,ML2,R164,R31,m4,R33,i187,R34,i23,R14,m4,R33,i187,R34,i17,ML3,R40,ML2,R129,R115,m4,R33,i188,R34,i23,ML3,R56,MV1,Myn1,xm2,R21,R37,m2,R21,R75,ML3,R74,R14,R78,m4,R33,i188,R34,i62,m4,R33,i188,R34,i43,m4,R33,i188,R34,i17,ML2,R92,R93,m4,R33,i189,R34,i17,ML4,R165,R94,R14,R31,m4,R33,i190,R34,i17,ML3,R76,ML3,R87,R137,nm4,R33,i191,R34,i23,ML4,R165,R166,R14,R137,m4,R33,i191,R34,i35,m4,R33,i191,R34,i17,ML2,R95,R93,m4,R33,i192,R34,i17,R14,m4,R33,i186,R34,i15,m4,R33,i170,R34,i13,m4,R33,i165,R34,i15,m4,R33,i163,R34,i13,m4,R33,i142,R34,i11,R30,R14,ML2,R28,R73,m4,R33,i204,R34,i31,R79,ML2,R28,R108,m4,R33,i204,R34,i60,m2,R21,R37,ML4,R39,V2,R31,ML2,R167,R14,m4,R33,i205,R34,i20,ML2,R92,R93,m4,R33,i206,R34,i13,ML5,R39,V2,R137,ML3,R59,R166,R14,m4,R33,i207,R34,i22,ML2,R95,R93,m4,R33,i208,R34,i15,ML3,R76,ML3,R87,R137,nm4,R33,i209,R34,i21,ML2,R67,ML3,R137,R31,ML2,R168,R79,m4,R33,i209,R34,i48,m4,R33,i209,R34,i41,m4,R33,i209,R34,i33,m4,R33,i209,R34,i15,ML3,R169,R31,ML2,R168,R79,m4,R33,i210,R34,i26,m4,R33,i210,R34,i15,m4,R33,i207,R34,i13,m4,R33,i205,R34,i11,R30,R14,ML2,R28,R73,m4,R33,i212,R34,i31,m2,R21,R75,ML3,R39,V2,ML4,R79,R137,R80,R80,m4,R33,i213,R34,i17,ML2,R69,R14,m4,R33,i213,R34,i33,ML3,R170,ML3,R77,R14,R133,m4,R33,i214,R34,i17,ML3,R87,R137,nm4,R33,i214,R34,i41,m4,R33,i214,R34,i13,m4,R33,i213,R34,i11,R30,ML4,R39,V4,ML4,R79,R80,R171,R80,m4,R33,i217,R34,i17,ML2,R69,R14,m4,R33,i217,R34,i36,R35,ML3,R59,R171,ML2,R118,ML2,R119,R172,m4,R33,i218,R34,i40,m4,R33,i218,R34,i31,m4,R33,i218,R34,i19,ML3,R76,ML3,R77,R35,nm4,R33,i219,R34,i19,ML2,R141,ML2,R142,ML2,R143,ML2,R144,ML5,R145,s12,constructor ML2,R146,ML2,R89,R14,m4,R33,i221,R34,i71,m4,R33,i221,R34,i63,ML2,R118,R172,m4,R33,i221,R34,i82,s23, is not in the Go buildm4,R33,i221,R34,i45,m4,R33,i221,R34,i36,m4,R33,i220,R34,i34,m4,R33,i220,R34,i22,m4,R33,i220,R34,i15,m4,R33,i219,R34,i13,ML3,R35,R57,ML2,R168,R58,m4,R33,i222,R34,i18,m4,R33,i222,R34,i13,m4,R33,i217,R34,i11,R57,R37,R14,ML2,R28,R73,m4,R33,i216,R34,i34,R172,ML2,R28,R105,m4,R33,i216,R34,i61,R58,ML2,R28,R108,m4,R33,i216,R34,i89,R30,R57,R37,R14,ML2,R28,R73,m4,R33,i224,R34,i45,R173,ML2,R28,R105,m4,R33,i224,R34,i71,R58,ML2,R28,R108,m4,R33,i224,R34,i99,m2,R21,R37,ML4,R39,V4,ML4,R79,R80,R80,R174,m4,R33,i225,R34,i17,ML2,R69,R14,m4,R33,i225,R34,i37,R35,ML3,R59,R174,ML2,R118,ML2,R119,R173,m4,R33,i226,R34,i41,m4,R33,i226,R34,i32,m4,R33,i226,R34,i19,ML3,R76,ML3,R77,R35,nm4,R33,i227,R34,i19,ML2,R141,ML2,R142,ML2,R143,ML2,R144,ML6,R145,s14,super call of ML2,R146,ML2,R89,R14,m4,R33,i229,R34,i73,m4,R33,i229,R34,i65,s1,.ML2,R118,R173,m4,R33,i229,R34,i88,s23, is not in the Go buildm4,R33,i229,R34,i45,m4,R33,i229,R34,i36,m4,R33,i228,R34,i34,m4,R33,i228,R34,i22,m4,R33,i228,R34,i15,m4,R33,i227,R34,i13,ML3,R35,R57,ML2,R168,R58,m4,R33,i230,R34,i18,m4,R33,i230,R34,i13,m4,R33,i225,R34,i11,R30,ML4,R39,V2,R115,ML2,R89,R14,m4,R33,i233,R34,i22,ML3,R40,ML2,R175,R115,m4,R33,i234,R34,i19,R176,m4,R33,i234,R34,i13,ML3,R76,ML3,R87,R177,nm4,R33,i235,R34,i19,ML3,R40,ML2,R178,R115,m4,R33,i235,R34,i41,ML2,R118,R177,m4,R33,i235,R34,i57,m4,R33,i235,R34,i35,m4,R33,i235,R34,i13,m4,R33,i233,R34,i11,R14,ML2,R28,R73,m4,R33,i232,R34,i20,R176,ML2,R28,R73,m4,R33,i232,R34,i48,R177,ML2,R28,R105,m4,R33,i232,R34,i77,R30,ML6,R39,V2,R115,ML2,R89,R14,m4,R33,i241,R34,i22,ML3,R40,ML2,R179,R115,m4,R33,i242,R34,i19,nm4,R33,i242,R34,i13,ML3,R40,ML2,R180,R115,m4,R33,i243,R34,i19,nm4,R33,i243,R34,i13,ML3,R40,ML2,R181,R115,m4,R33,i244,R34,i19,nm4,R33,i244,R34,i13,ML1,R182,m4,R33,i245,R34,i13,m4,R33,i241,R34,i11,R14,ML2,R28,R73,m4,R33,i240,R34,i20,R30,ML4,R39,V2,R115,ML2,R89,R14,m4,R33,i248,R34,i22,ML3,R40,ML2,R183,R115,m4,R33,i249,R34,i19,R184,m4,R33,i249,R34,i13,ML3,R40,ML2,R185,R115,m4,R33,i250,R34,i19,ML3,R56,MV0,m2,R21,ML2,R28,R108,m4,R33,i250,R34,i44,ML3,R23,ML2,R28,R108,m4,R33,i250,R34,i73,ML2,R186,R79,m4,R33,i250,R34,i90,m4,R33,i250,R34,i65,m4,R33,i250,R34,i33,m4,R33,i250,R34,i13,m4,R33,i248,R34,i11,R14,ML2,R28,R73,m4,R33,i247,R34,i20,R79,R149,R30,R57,R37,m2,R21,R37,ML4,R39,V2,ML3,R79,R130,R81,m4,R33,i253,R34,i17,ML3,R23,R131,R57,m4,R33,i253,R34,i31,ML3,R76,ML2,R83,R81,m4,R33,i254,R34,i19,ML2,R67,nm4,R33,i254,R34,i28,m4,R33,i254,R34,i13,ML2,R97,ML2,R187,R130,m4,R33,i255,R34,i19,m4,R33,i255,R34,i13,m4,R33,i253,R34,i11,R30,ML4,R39,V4,R115,ML2,R89,R14,m4,R33,i259,R34,i22,R188,ML2,R114,R189,m4,R33,i260,R34,i20,ML4,R76,ML3,R87,ML3,R190,R109,R191,m4,R33,i261,R34,i23,l0,m4,R33,i261,R34,i19,ML3,R40,ML2,R179,R115,m4,R33,i262,R34,i21,ML3,R192,ML2,R179,R115,m4,R33,i263,R34,i29,ML12,R44,R193,R117,ML2,R118,ML2,R119,R104,m4,R33,i264,R34,i64,m4,R33,i264,R34,i55,R194,R188,R195,R196,R120,R109,R197,ML3,R56,MV2,Myn4,thism2,R21,R37,Myn4,argsm2,R21,ML2,R36,R37,m4,R33,i265,R34,i69,m2,R21,R37,ML3,R198,R196,ML4,R199,R200,nR58,m4,R33,i266,R34,i60,m4,R33,i266,R34,i44,m4,R33,i265,R34,i42,m4,R33,i264,R34,i29,m4,R33,i263,R34,i21,m4,R33,i262,R34,i15,ML1,R67,m4,R33,i267,R34,i15,m4,R33,i261,R34,i13,ML7,R39,V2,R173,ML3,R145,ML2,R118,ML2,R119,R104,m4,R33,i268,R34,i35,m4,R33,i268,R34,i26,s1,(m4,R33,i268,R34,i23,ML3,R159,V3,R80,R201,R188,ML3,R40,R173,ML3,R145,R173,ML2,R202,R201,m4,R33,i269,R34,i48,m4,R33,i269,R34,i41,m4,R33,i269,R34,i31,m4,R33,i269,R34,i15,ML3,R40,R173,ML4,R145,R173,s1,)ML2,R202,ML2,R119,R196,m4,R33,i270,R34,i49,m4,R33,i270,R34,i36,m4,R33,i270,R34,i25,m4,R33,i270,R34,i15,ML2,R92,R93,m4,R33,i272,R34,i15,ML4,R39,V2,ML3,R79,R31,R81,m4,R33,i273,R34,i21,ML3,R59,R94,R14,m4,R33,i273,R34,i36,ML2,R95,R93,m4,R33,i274,R34,i17,ML4,R76,ML3,R96,R81,ML3,R87,R200,nm4,R33,i275,R34,i31,m4,R33,i275,R34,i23,ML3,R39,V2,ML3,R79,R160,R81,m4,R33,i276,R34,i25,ML3,R59,ML2,R156,R31,m4,R33,i276,R34,i45,R173,m4,R33,i276,R34,i39,ML3,R76,R81,ML4,R165,ML2,R158,R31,m4,R33,i277,R34,i36,R160,R200,m4,R33,i277,R34,i30,m4,R33,i277,R34,i21,m4,R33,i276,R34,i19,ML4,R165,ML2,R203,R31,m4,R33,i278,R34,i25,R173,R200,m4,R33,i278,R34,i19,m4,R33,i275,R34,i17,m4,R33,i273,R34,i15,ML3,R40,ML2,R179,R115,m4,R33,i279,R34,i21,ML3,R192,ML2,R179,R115,m4,R33,i280,R34,i29,ML12,R44,R193,R117,ML2,R118,R104,m4,R33,i281,R34,i55,R194,R188,R195,R196,R120,R109,R197,ML3,R56,MV2,Myn4,thism2,R21,R37,Myn4,argsm2,R21,ML2,R36,R37,m4,R33,i282,R34,i69,m2,R21,R37,ML5,R39,V4,R130,ML2,R204,R205,m4,R33,i284,R34,i52,R35,ML3,R59,ML2,R203,ML2,R187,R130,m4,R33,i285,R34,i67,m4,R33,i285,R34,i58,R173,m4,R33,i285,R34,i52,ML3,R76,ML3,R77,R35,nm4,R33,i286,R34,i52,ML3,R40,R35,R200,m4,R33,i286,R34,i63,m4,R33,i286,R34,i46,ML3,R76,ML3,R77,R35,nm4,R33,i287,R34,i52,ML2,R141,ML3,R206,R130,ML5,R145,s1,'ML2,R118,R104,m4,R33,i288,R34,i77,s5,' of ML2,R146,ML2,R89,R14,m4,R33,i288,R34,i108,m4,R33,i288,R34,i100,m4,R33,i288,R34,i70,m4,R33,i288,R34,i55,m4,R33,i288,R34,i48,m4,R33,i287,R34,i46,ML3,R198,R196,ML4,R199,R35,R130,R58,m4,R33,i289,R34,i62,m4,R33,i289,R34,i46,m4,R33,i284,R34,i44,m4,R33,i282,R34,i42,m4,R33,i281,R34,i29,m4,R33,i280,R34,i21,m4,R33,i279,R34,i15,m4,R33,i268,R34,i13,m4,R33,i259,R34,i11,R14,ML2,R28,R73,m4,R33,i257,R34,i20,R104,ML2,R28,R105,m4,R33,i257,R34,i47,R189,ML2,R28,R108,m4,R33,i257,R34,i77,R196,ML2,R28,R73,m4,R33,i257,R34,i106,R109,R110,R200,R149,R30,ML3,R39,V2,R115,ML2,R89,R14,m4,R33,i292,R34,i22,ML3,R40,ML2,R180,R115,m4,R33,i293,R34,i19,ML3,R192,ML2,R180,R115,m4,R33,i294,R34,i27,ML8,R44,R207,R194,ML2,R114,R189,m4,R33,i295,R34,i53,R120,R109,R208,ML3,R56,MV1,Myn4,argsm2,R21,ML2,R36,R37,m4,R33,i296,R34,i54,m2,R21,R37,ML4,R199,R200,nR58,m4,R33,i296,R34,i73,m4,R33,i296,R34,i37,m4,R33,i295,R34,i27,m4,R33,i294,R34,i19,m4,R33,i293,R34,i13,m4,R33,i292,R34,i11,R14,ML2,R28,R73,m4,R33,i291,R34,i20,R189,ML2,R28,R108,m4,R33,i291,R34,i49,R109,R110,R200,R149,R30,ML3,R39,V4,R115,ML2,R89,R14,m4,R33,i299,R34,i22,R84,R160,ML3,R40,ML2,R181,R115,m4,R33,i301,R34,i19,ML3,R192,ML2,R181,R115,m4,R33,i302,R34,i27,ML12,R44,R209,R117,ML2,R118,ML2,R119,R104,m4,R33,i303,R34,i61,m4,R33,i303,R34,i52,R210,R100,R120,R109,R211,ML3,R56,MV1,Myn1,om2,R21,R37,m2,R21,R37,ML3,R98,R100,ML3,R59,ML2,R212,ML2,R213,ML2,R204,R57,m4,R33,i304,R34,i109,m4,R33,i304,R34,i97,m4,R33,i304,R34,i78,R84,m4,R33,i304,R34,i72,m4,R33,i304,R34,i55,m4,R33,i304,R34,i37,R214,ML3,R56,V2,Myn1,om2,R21,R37,Myn1,vm2,R21,R37,ML4,R165,ML2,R212,ML2,R213,ML2,R204,R57,m4,R33,i305,R34,i94,m4,R33,i305,R34,i82,m4,R33,i305,R34,i63,R84,ML2,R68,R101,m4,R33,i305,R34,i108,m4,R33,i305,R34,i57,m4,R33,i305,R34,i37,m4,R33,i303,R34,i27,m4,R33,i302,R34,i19,m4,R33,i301,R34,i13,m4,R33,i299,R34,i11,R14,ML2,R28,R73,m4,R33,i298,R34,i20,R104,ML2,R28,R105,m4,R33,i298,R34,i47,R100,ML2,R28,R73,m4,R33,i298,R34,i76,R109,R110,R160,R110,R30,R14,ML2,R28,R73,m4,R33,i307,R34,i20,R104,ML2,R28,R105,m4,R33,i307,R34,i47,R100,ML2,R28,R73,m4,R33,i307,R34,i76,R109,R110,R215,ML2,R28,R108,m4,R33,i308,R34,i24,R160,R110,R216,R149,ML4,R39,V4,R115,ML2,R89,R14,m4,R33,i309,R34,i22,R84,R160,ML3,R76,ML3,R77,ML2,R217,R115,m4,R33,i311,R34,i23,nm4,R33,i311,R34,i19,ML3,R40,ML2,R217,R115,m4,R33,i312,R34,i21,ML3,R56,V0,ML2,R186,R216,m4,R33,i312,R34,i42,m4,R33,i312,R34,i35,m4,R33,i312,R34,i15,m4,R33,i311,R34,i13,ML3,R40,ML2,R181,R115,m4,R33,i313,R34,i19,ML3,R192,ML2,R181,R115,m4,R33,i314,R34,i27,ML12,R44,R209,R117,ML2,R118,ML2,R119,R104,m4,R33,i315,R34,i61,m4,R33,i315,R34,i52,R210,R100,R120,R109,R211,ML4,R56,MV1,Myn1,om2,R21,R37,m2,R21,R37,ML2,R186,R216,m4,R33,i316,R34,i55,ML3,R98,R100,ML3,R59,ML2,R168,R215,m4,R33,i316,R34,i96,R84,m4,R33,i316,R34,i90,m4,R33,i316,R34,i73,m4,R33,i316,R34,i37,R214,ML4,R56,V2,Myn1,om2,R21,R37,Myn1,vm2,R21,R37,ML2,R186,R216,m4,R33,i317,R34,i57,ML4,R165,ML2,R168,R215,m4,R33,i317,R34,i81,R84,ML2,R68,R101,m4,R33,i317,R34,i95,m4,R33,i317,R34,i75,m4,R33,i317,R34,i37,m4,R33,i315,R34,i27,m4,R33,i314,R34,i19,m4,R33,i313,R34,i13,m4,R33,i309,R34,i11,v11,arbace.walk8,postwalkv11,arbace.core4,map?R218,v11,arbace.core6,dissocv11,arbace.core3,setv14,arbace.j2g.dyn10,sub-supersV2,s21,arbace/lang/AFunctions18,arbace/lang/RestFnS2,R219,R220,R221,v16,arbace.j2g.model10,interface?v22,arbace.classes.analyze14,class-genericsR222,v11,arbace.core3,vecv11,arbace.core6,removev11,arbace.core4,nil?R223,R224,l0,v11,arbace.core4,somev11,arbace.core4,compR225,v16,arbace.j2g.dyncf10,strip-annsv11,arbace.core5,assocR226,v11,arbace.core11,select-keysV5,R53,R54,R224,R227,R228,V5,R53,R54,R224,R227,R228,S2,R219,R220,V5,R53,R54,R224,R227,R228,V5,R53,R54,R224,R227,R228,v13,arbace.string4,joinv11,arbace.core6,pr-strv11,arbace.core4,sortv11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core12,*print-meta*")

var Lit_1 *jrt.String = jrt.Intern("---- the Java forms at the REPL: Compiler$CFGo's natives (doc/go/CLASSFORMS-REPL.md)")

var Lit_2 *jrt.String = jrt.Intern("defineClass")

var Lit_3 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/Class;[Ljava/lang/Class;IILjava/lang/Object;)Ljava/lang/Class;")

var Lit_4 *jrt.String = jrt.Intern("alloc")

var Lit_5 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_6 *jrt.String = jrt.Intern("canExtend")

var Lit_7 *jrt.String = jrt.Intern("(Ljava/lang/Class;)Z")

var Lit_8 *jrt.String = jrt.Intern("superCtor")

var Lit_9 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V")

var Lit_10 *jrt.String = jrt.Intern("superCall")

var Lit_11 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_12 *jrt.String = jrt.Intern("setOuter")

var Lit_13 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)V")

var Lit_14 *jrt.String = jrt.Intern("clearMembers")

var Lit_15 *jrt.String = jrt.Intern("(Ljava/lang/Class;)V")

var Lit_16 *jrt.String = jrt.Intern("setEnum")

var Lit_17 *jrt.String = jrt.Intern("(Ljava/lang/Class;Larbace/lang/IFn;)V")

var Lit_18 *jrt.String = jrt.Intern("klassOf")

var Lit_19 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_20 *jrt.String = jrt.Intern("setMethod")

var Lit_21 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;ILarbace/lang/IFn;)V")

var Lit_22 *jrt.String = jrt.Intern("addCtor")

var Lit_23 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Class;ILarbace/lang/IFn;)V")

var Lit_24 *jrt.String = jrt.Intern("addField")

var Lit_25 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;II)V")

var Lit_26 *jrt.String = jrt.Intern("addStatic")

var Lit_27 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;I[Ljava/lang/Object;ILarbace/lang/IFn;)V")

var Lit_28 *jrt.String = jrt.Intern("jrt/Prim_")

var Lit_29 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097")

var Lit_31 *jrt.String = jrt.Intern(";; Written by j2g --program (arbace.j2g.dyncf/generics-text): the generic signatures of the\n")

var Lit_32 *jrt.String = jrt.Intern(";; classes of the world, for the Java forms' analysis (doc/go/CLASSFORMS-REPL.md).\n{")

var Lit_33 *jrt.String = jrt.Intern("}\n")

var Lit_34 *jrt.String = jrt.Intern("\n ")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000149__292000153")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000099")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000124")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$iter__292000127__292000131")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$iter__292000137__292000141")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000099$fn__292000100")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000099$iter__292000103__292000107")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000099$iter__292000113__292000117")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000099$iter__292000103__292000107$fn__292000108")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000099$iter__292000103__292000107$fn__292000108$fn__292000109")

var Lit_46 *jrt.String = jrt.Intern("<init>")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000099$iter__292000113__292000117$fn__292000118")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$fn__292000099$iter__292000113__292000117$fn__292000118$fn__292000119")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$iter__292000127__292000131$fn__292000132")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$iter__292000127__292000131$fn__292000132$fn__292000133")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$iter__292000137__292000141$fn__292000142")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000093__292000097$fn__292000098$iter__292000137__292000141$fn__292000142$fn__292000143")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000149__292000153$fn__292000154")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text$iter__292000149__292000153$fn__292000154$fn__292000155")

var Lit_55 *jrt.String = jrt.Intern(" ")

var Lit_56 *jrt.String = jrt.Intern("_")

var Lit_57 *jrt.String = jrt.Intern("_native")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.dyncf$strip_anns$fn__292000090")

var Lit_59 *jrt.String = jrt.Intern("dynCfNew_")

var Lit_60 *jrt.String = jrt.Intern("_Init")

var Lit_61 *jrt.String = jrt.Intern("dynCfCtors_")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000017__292000021")

var Lit_63 *jrt.String = jrt.Intern("dynCfSupers_")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000043__292000047")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000017__292000021$fn__292000022")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000017__292000021$fn__292000022$fn__292000023")

var Lit_67 *jrt.String = jrt.Intern(".")

var Lit_68 *jrt.String = jrt.Intern(".-")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000017__292000021$fn__292000022$fn__292000039")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000017__292000021$fn__292000022$fn__292000023$fn__292000030")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000043__292000047$fn__292000048")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000043__292000047$fn__292000048$fn__292000049")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000043__292000047$fn__292000048$fn__292000072")

var Lit_74 *jrt.String = jrt.Intern(".Impl_")

var Lit_75 *jrt.String = jrt.Intern("V")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms$iter__292000043__292000047$fn__292000048$fn__292000049$fn__292000059")

var Lit_77 *jrt.String = jrt.Intern("DynSub_")

var Lit_78 *jrt.String = jrt.Intern("cfSubFor: the allocation, constructors and implementations of superclass c of the world\n(nil: c has no DynSub type).\n")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.dyncf$subs_forms$iter__292000078__292000082")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.dyncf$subs_forms$iter__292000078__292000082$fn__292000083")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.dyncf$subs_forms$iter__292000078__292000082$fn__292000083$fn__292000084")

var Lit_82 *jrt.String = jrt.Intern("_class")

var Lit_83 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn8,arglistskn7,privateyn3,symyn4,typeyn5,mnameyn4,descyn1,nyn1,dyn1,xyn1,Tv11,arbace.core5,in-nsMyn16,arbace.j2g.dyncfm2,R0,s596,The natives of Compiler$CFGo (arbace/lang/Compiler.ae), the Go build's host of the class\n  forms at the REPL (doc/go/CLASSFORMS-REPL.md), in arbace/lang's j2g_cf.go: classes made at run\n  time for interpreted classes, over Dyn (J2G-SPEC §5.12, arbace.j2g.dyn): a class extending\n  Object or another interpreted class, implementing interfaces of the world (Dyn's slots) and\n  interfaces made at run time (the class's methods by key); an interface; a Clojure fn's class\n  (objects CF$FnObj). Member tables carry the classes' methods, constructors and fields, with\n  their modifiers, for reflection.m2,R0,s596,The natives of Compiler$CFGo (arbace/lang/Compiler.ae), the Go build's host of the class\n  forms at the REPL (doc/go/CLASSFORMS-REPL.md), in arbace/lang's j2g_cf.go: classes made at run\n  time for interpreted classes, over Dyn (J2G-SPEC §5.12, arbace.j2g.dyn): a class extending\n  Object or another interpreted class, implementing interfaces of the world (Dyn's slots) and\n  interfaces made at run time (the class's methods by key); an interface; a Clojure fn's class\n  (objects CF$FnObj). Member tables carry the classes' methods, constructors and fields, with\n  their modifiers, for reflection.R1,v16,arbace.j2g.dyncf9,api-classm6,R2,i19,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf8,enabled?m10,R5,L1,V0,R0,s51,Is the Java forms' host in this world (translated)?R2,i21,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf3,tagm10,R6,TR5,L1,V2,R7,R8,R2,i26,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf11,native-namem10,R6,TR5,L1,V2,R9,R10,R2,i28,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf8,sub-namem10,R6,TR5,L1,V1,R11,R2,i39,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf11,from-objectm12,R6,TR5,L1,V2,R12,R13,R0,s78,The Java object x (an interpreter's argument) as the Go value of descriptor d.R2,i41,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf9,sub-formsm12,R6,TR5,L1,V1,R11,R0,s51,dynCfNew_G, dynCfCtors_G, dynCfSupers_G of class n.R2,i49,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf10,subs-formsm10,R5,L1,V1,R14,R0,s79,The forms of the superclasses of the world, and cfSubFor (nil when c has none).R2,i101,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf5,formsm10,R5,L1,V1,R14,R0,s45,The forms of j2g_cf.go (package arbace/lang).R2,i120,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf10,strip-annsm10,R6,TR5,L1,V1,R13,R2,i331,R3,i1,R4,s19,arbace/j2g/dyncf.aev16,arbace.j2g.dyncf13,generics-textm10,R5,L1,V1,R14,R0,s282,The generic view (class-generics) of the classes of T that are generic or have generic\n  supertypes, as text read by arbace.classes.go/generics: {internal-name {:tparams [sym]\n  :supers [tnode] :methods [...]}}, methods only for generic classes (the others' come from\n  reflection).R2,i334,R3,i1,R4,s19,arbace/j2g/dyncf.ae")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.dyncf$eval292000004$loading__1927001464__auto____292000005")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.dyncf$eval292000008$fn__292000009")

var Lit_86 *jrt.String = jrt.Intern("arbace/lang/Compiler$CFGo")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.dyncf$enabled_QMARK_")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.dyncf$tag")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.dyncf$native_name")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_name")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.dyncf$from_object")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.dyncf$sub_forms")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.dyncf$subs_forms")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.dyncf$forms")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.dyncf$strip_anns")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.dyncf$generics_text")
