//line aot_arbace_j2g_dyncf.ae:1
package aot_arbace_j2g_dyncf

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_code"
	"arbace/aot_arbace_j2g_dyn"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/aot_arbace_walk"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_New() *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyncf_A_const_13); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_1, A_arbace_j2g_dyncf_A_const_2, A_arbace_j2g_dyncf_A_const_3, A_arbace_j2g_dyncf_A_const_4, A_arbace_j2g_dyncf_A_const_5, A_arbace_j2g_dyncf_A_const_6, A_arbace_j2g_dyncf_A_const_7, A_arbace_j2g_dyncf_A_const_8, A_arbace_j2g_dyncf_A_const_9, A_arbace_j2g_dyncf_A_const_10, A_arbace_j2g_dyncf_A_const_11); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_New() *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000008_fn__292000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_14.GetRawRoot__O()); var tmp2 any; var root_25 any = A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_j2g_dyncf_A_const_16; if linked_26 == nil { tmp2 = ifn_27.Invoke_O__O(arg_28) } else { tmp2 = linked_26.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_25, arg_28) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(), A_arbace_j2g_dyncf_A_const_18) }





















func A_arbace_j2g_dyncf_enabled_QMARK__A_New() *A_arbace_j2g_dyncf_enabled_QMARK__A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_enabled_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_29 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_j2g_dyncf_A_const_20.GetRawRoot__O(); if linked_30 == nil { return ifn_31.Invoke_O__O(arg_32) } else { return linked_30.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_29, arg_32)
	} }
func A_arbace_j2g_dyncf_tag_A_New() *A_arbace_j2g_dyncf_tag_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_tag_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_j2g_dyncf_tag_A) Ctor() {}
//line :28:1
func (t *A_arbace_j2g_dyncf_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_33 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = sym__0; var arg_37 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyncf_A_const_22, type__1)); if linked_34 == nil { return ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { return linked_34.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) } }

func A_arbace_j2g_dyncf_native_name_A_New() *A_arbace_j2g_dyncf_native_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_native_name_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_j2g_dyncf_native_name_A) Ctor() {}
//line :30:1
func (t *A_arbace_j2g_dyncf_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var root_38 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_104); var tmp2 any; var root_42 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_j2g_dyncf_A_const_20.GetRawRoot__O(); if linked_43 == nil { tmp2 = ifn_44.Invoke_O__O(arg_45) } else { tmp2 = linked_43.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_42, arg_45) }; var tmp3 any = tmp2; var tmp4 any; var root_46 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = mname__0; var arg_50 any = desc__1; if linked_47 == nil { tmp4 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { tmp4 = linked_47.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; arg_41 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref(); if linked_39 == nil { return ifn_40.Invoke_O__O(arg_41) } else { return linked_39.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_38, arg_41)
	}
}









func A_arbace_j2g_dyncf_sub_name_A_New() *A_arbace_j2g_dyncf_sub_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_name_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Ctor() {}
//line :43:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_163, nil); var tmp2 any; var root_51 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = n__0; if linked_52 == nil { tmp2 = ifn_53.Invoke_O__O(arg_54) } else { tmp2 = linked_52.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_51, arg_54) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyncf_from_object_A_New() *A_arbace_j2g_dyncf_from_object_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_from_object_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_j2g_dyncf_from_object_A) Ctor() {}
//line :45:1
func (t *A_arbace_j2g_dyncf_from_object_A) Invoke_O_O_O__O(self, d__0, x__1 any) any {


	var tmp1 any; var root_55 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = d__0; if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_55, arg_58) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_29; var tmp4 any; var root_59 any = A_arbace_j2g_dyncf_A_const_30.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_j2g_dyncf_A_const_31; var arg_63 any = d__0; if linked_60 == nil { tmp4 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { tmp4 = linked_60.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_32; var tmp8 any; var root_64 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_66 lang.IFn
		if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_38, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_33.GetRawRoot__O()).Invoke_O__O(d__0))).Ref(); if linked_65 == nil { tmp8 = ifn_66.Invoke_O__O(arg_67) } else { tmp8 = linked_65.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_64, arg_67) }
//line :48:1
		return tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O__O(tmp7, tmp8, x__1)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_39) { return x__1 } else { if A_arbace_j2g_dyncf_A_const_28 != nil {


			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_34; var tmp12 any = A_arbace_j2g_dyncf_A_const_35; var tmp13 any; var root_68 any = A_arbace_j2g_dyncf_A_const_30.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_j2g_dyncf_A_const_31; var arg_72 any = d__0; if linked_69 == nil { tmp13 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { tmp13 = linked_69.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; return tmp9.Invoke_O_O__O(tmp10.Invoke_O_O_O__O(tmp11, tmp12, tmp13), x__1) } else {
//line :48:1
				return nil
			}
		}
		}
}
func A_arbace_j2g_dyncf_sub_forms_A_New() *A_arbace_j2g_dyncf_sub_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Ctor() {}
//line :53:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_73 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_75 lang.IFn; if


	linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = n__0; if linked_74 == nil { g__2 = ifn_75.Invoke_O__O(arg_76) } else { g__2 = linked_74.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_73, arg_76) }; var recv__3 any; var tmp1 lang.IFn = /*line :53:1*/lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_38; var tmp3 any; var root_80 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_82 lang.IFn; if



	linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = g__2; if linked_81 == nil { tmp3 = ifn_82.Invoke_O__O(arg_83) } else { tmp3 = linked_81.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_80, arg_83) }; recv__3 = tmp1.Invoke_O_O__O(tmp2, tmp3); var root_84 any =
	A_arbace_j2g_dyncf_A_const_39.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_41, A_arbace_j2g_dyncf_A_const_42); if linked_85 == nil { ifn_86.Invoke_O__O(arg_87) } else { linked_85.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_84, arg_87) }; var tmp4 any; tmp57 := /*line :53:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyncf_A_const_43; var tmp7 any; var root_93 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_95 lang.IFn





		if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_141, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_94 == nil { tmp7 = ifn_95.Invoke_O__O(arg_96) } else { tmp7 = linked_94.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_93, arg_96) }
//line :53:1
		var tmp8 any = tmp7; var tmp9 any; var root_97 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_99 lang.IFn





		if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var tmp10 any; var root_102 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = A_arbace_j2g_dyncf_A_const_45; var arg_106 any = A_arbace_j2g_dyncf_A_const_46; if linked_103 == nil { tmp10 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { tmp10 = linked_103.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }; var tmp11 any = tmp10; var tmp12 any; var root_107 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_j2g_dyncf_A_const_47; var arg_111 any = A_arbace_j2g_dyncf_A_const_48; if linked_108 == nil { tmp12 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { tmp12 = linked_108.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }; arg_100 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12); var arg_101 any = A_arbace_j2g_dyncf_A_const_49; if linked_98 == nil { tmp9 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { tmp9 = linked_98.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }
//line :53:1
		var tmp13 any = tmp9; var tmp14 any; var tmp15 any; var or__1927000174__auto____6 any; var root_112 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_114 lang.IFn






		if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = n__0; if linked_113 == nil { or__1927000174__auto____6 = ifn_114.Invoke_O__O(arg_115) } else { or__1927000174__auto____6 = linked_113.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp15 = or__1927000174__auto____6 } else { var root_116 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = n__0; if linked_117 == nil { tmp15 = ifn_118.Invoke_O__O(arg_119) } else { tmp15 = linked_117.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_116, arg_119) } }; if jrt.J2g_Truth(tmp15) { tmp14 = A_arbace_j2g_dyncf_A_const_52 } else {

			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp17 any; var root_120 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = A_arbace_j2g_dyncf_A_const_31; var arg_124 any = n__0; var arg_125 any = Lit_142; if linked_121 == nil { tmp17 = ifn_122.Invoke_O_O_O__O(arg_123, arg_124, arg_125) } else { tmp17 = linked_121.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_120, arg_123, arg_124, arg_125) }; tmp14 = tmp16.Invoke_O__O(tmp17) }
//line :53:1
		var tmp18 any = tmp14; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyncf_A_const_54; var tmp21 any = A_arbace_j2g_dyncf_A_const_58; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_59; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyncf_A_const_60; var tmp26 any; var root_126 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_128 lang.IFn









		if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = g__2; if linked_127 == nil { tmp26 = ifn_128.Invoke_O__O(arg_129) } else { tmp26 = linked_127.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_126, arg_129) }
//line :53:1
		var tmp27 any = tmp5.Invoke_O_O_O_O_O__O(tmp6, tmp8, tmp13, tmp18, tmp19.Invoke_O_O_O_O_O__O(tmp20, lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp22.Invoke_O_O__O(tmp23, tmp24.Invoke_O_O_O_O__O(tmp25, tmp26, A_arbace_j2g_dyncf_A_const_61, A_arbace_j2g_dyncf_A_const_62))), A_arbace_j2g_dyncf_A_const_55, A_arbace_j2g_dyncf_A_const_56, A_arbace_j2g_dyncf_A_const_57)); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyncf_A_const_63; var tmp30 any; var root_130 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_132 lang.IFn














		if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var root_135 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_136 == nil { arg_133 = ifn_137.Invoke_O__O(arg_138) } else { arg_133 = linked_136.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_135, arg_138) }; var arg_134 any = A_arbace_j2g_dyncf_A_const_64; if linked_131 == nil { tmp30 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { tmp30 = linked_131.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }
//line :53:1
		var tmp31 any = tmp30; var tmp32 any; var root_139 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_141 lang.IFn















		if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_143 any = A_arbace_j2g_dyncf_A_const_66; var arg_144 any = A_arbace_j2g_dyncf_A_const_67; var arg_145 any; var iter__1927001039__auto____6 any; var fnbody__421 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(recv__3, n__0); var tmp33 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class
		if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, fnbody__421); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class = fncls__420d; tmp33 = fncls__420d } else { tmp33 = fncls__420 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__421, tmp33, nil); var tmp34 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp35 any; var tmp36 any; var root_422 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = n__0; if linked_423 == nil { tmp36 = ifn_424.Invoke_O__O(arg_425) } else { tmp36 = linked_423.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(tmp36) { var root_426 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = n__0; if linked_427 == nil { tmp35 = ifn_428.Invoke_O__O(arg_429) } else { tmp35 = linked_427.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_426, arg_429) } } else { var tmp37 *lang.Keyword = A_arbace_j2g_dyncf_A_const_108; var tmp38 any; var root_430 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = n__0; if linked_431 == nil { tmp38 = ifn_432.Invoke_O__O(arg_433) } else { tmp38 = linked_431.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_430, arg_433) }; tmp35 = tmp37.Invoke_O__O(tmp38) }; arg_145 = tmp34.Invoke_O__O(tmp35)
//line :69:1
		if linked_140 == nil { tmp32 = ifn_141.Invoke_O_O_O_O__O(arg_142, arg_143, arg_144, arg_145) } else { tmp32 = linked_140.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_139, arg_142, arg_143, arg_144, arg_145) }
//line :53:1
		var tmp39 any = tmp28.Invoke_O_O_O__O(tmp29, tmp31, tmp32); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_dyncf_A_const_110; var tmp42 any; var root_434 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_436 lang.IFn






























		if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var root_439 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_145, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_440 == nil { arg_437 = ifn_441.Invoke_O__O(arg_442) } else { arg_437 = linked_440.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_439, arg_442) }; var arg_438 any = A_arbace_j2g_dyncf_A_const_111; if linked_435 == nil { tmp42 = ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { tmp42 = linked_435.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) }
//line :53:1
		var tmp43 any = tmp42; var tmp44 any; var root_443 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_445 lang.IFn































		if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_447 any = A_arbace_j2g_dyncf_A_const_112; var arg_448 any = A_arbace_j2g_dyncf_A_const_113; var arg_449 any; var iter__1927001039__auto____6_2 any; var fnbody__723 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(recv__3, n__0); var tmp45 *jrt.Class; var fncls__722 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class
		if fncls__722 == nil { var fncls__722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, fnbody__723); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class = fncls__722d; tmp45 = fncls__722d } else { tmp45 = fncls__722 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__723, tmp45, nil); var tmp46 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6_2); var tmp47 any; var root_724 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var arg_728 any; var root_729 any = A_arbace_j2g_dyncf_A_const_145.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = n__0; if linked_730 == nil { arg_728 = ifn_731.Invoke_O__O(arg_732) } else { arg_728 = linked_730.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_729, arg_732) }; if linked_725 == nil { tmp47 = ifn_726.Invoke_O_O__O(arg_727, arg_728) } else { tmp47 = linked_725.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_724, arg_727, arg_728) }; arg_449 = tmp46.Invoke_O__O(tmp47)
//line :85:1
		if linked_444 == nil { tmp44 = ifn_445.Invoke_O_O_O_O__O(arg_446, arg_447, arg_448, arg_449) } else { tmp44 = linked_444.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_443, arg_446, arg_447, arg_448, arg_449) }
//line :53:1
		var tmp48 any = tmp40.Invoke_O_O_O__O(tmp41, tmp43, tmp44); var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp50 any = A_arbace_j2g_dyncf_A_const_146; var tmp51 any; var root_733 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_735 lang.IFn



















































		if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any; var root_738 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_147, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_739 == nil { arg_736 = ifn_740.Invoke_O__O(arg_741) } else { arg_736 = linked_739.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_738, arg_741) }; var arg_737 any = A_arbace_j2g_dyncf_A_const_147; if linked_734 == nil { tmp51 = ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { tmp51 = linked_734.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_733, arg_736, arg_737) }
//line :53:1
		var tmp52 any = tmp51; var tmp53 any; var root_742 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_744 lang.IFn




















































		if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_746 any = A_arbace_j2g_dyncf_A_const_148; var arg_747 any = A_arbace_j2g_dyncf_A_const_149; var arg_748 any; var seen__6 any; var root_749 any = A_arbace_j2g_dyncf_A_const_150.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_751 lang.IFn
		if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_750 == nil { seen__6 = ifn_751.Invoke_O__O(arg_752) } else { seen__6 = linked_750.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_749, arg_752) }
		var root_753 any = A_arbace_j2g_dyncf_A_const_151.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any; var iter__1927001039__auto____7 any; var fnbody__1055 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_New_O_O(recv__3, seen__6); var tmp54 *jrt.Class; var fncls__1054 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_fn_class
		if fncls__1054 == nil { var fncls__1054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, fnbody__1055); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_fn_class = fncls__1054d; tmp54 = fncls__1054d } else { tmp54 = fncls__1054 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1055, tmp54, nil); var tmp55 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp56 any; var root_1056 any = A_arbace_j2g_dyncf_A_const_192.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = n__0; if linked_1057 == nil { tmp56 = ifn_1058.Invoke_O__O(arg_1059) } else { tmp56 = linked_1057.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1056, arg_1059) }; arg_756 = tmp55.Invoke_O__O(tmp56)
//line :108:1
		if linked_754 == nil { arg_748 = ifn_755.Invoke_O__O(arg_756) } else { arg_748 = linked_754.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_753, arg_756) }
//line :106:1
		if linked_743 == nil { tmp53 = ifn_744.Invoke_O_O_O_O__O(arg_745, arg_746, arg_747, arg_748) } else { tmp53 = linked_743.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_742, arg_745, arg_746, arg_747, arg_748) }
//line :53:1
		tmp4 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp27, tmp39, tmp48, tmp49.Invoke_O_O_O__O(tmp50, tmp52, tmp53)) }; return nil }(); var root_77 any = A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_79 lang.IFn; if




	linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; if linked_78 == nil { ifn_79.Invoke__O() } else { linked_78.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_77) }; if /*line :53:1*/ tmp57 != nil { panic(tmp57) }; return tmp4 }
















func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Invoke_O_O__O(self, s__292000018__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__419 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000018__1); var tmp2 *jrt.Class; var fncls__418 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class; if fncls__418 == nil { var fncls__418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, fnbody__419); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class = fncls__418d; tmp2 = fncls__418d } else { tmp2 = fncls__418 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__419, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :70:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000017, c__s__292000018 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000017 = c__iter__292000017; t.F_s__292000018 = c__s__292000018 }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Invoke_O__O(self any) any { { var s__292000018__1 any; var t_ any = t.F_s__292000018; t.F_s__292000018 = nil; s__292000018__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_146 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = s__292000018__1; if linked_147 == nil { temp__1927000414__auto____2 = ifn_148.Invoke_O__O(arg_149) } else { temp__1927000414__auto____2 = linked_147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_146, arg_149) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000018__3 any = temp__1927000414__auto____2; var tmp1 any; var root_150 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = s__292000018__3; if linked_151 == nil { tmp1 = ifn_152.Invoke_O__O(arg_153) } else { tmp1 = linked_151.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_150, arg_153) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_154 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__292000018__3; if linked_155 == nil { c__1927001037__auto____4 = ifn_156.Invoke_O__O(arg_157) } else { c__1927001037__auto____4 = linked_155.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_154, arg_157) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000020__6 any; var root_158 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_159 == nil { b__292000020__6 = ifn_160.Invoke_O__O(arg_161) } else { b__292000020__6 = linked_159.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_158, arg_161) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__269 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(b__292000020__6, t.F_recv, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__268 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class; if fncls__268 == nil { var fncls__268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, fnbody__269); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class = fncls__268d; tmp3 = fncls__268d } else { tmp3 = fncls__268 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__269, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_270 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any; var root_275 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = b__292000020__6; if linked_276 == nil { arg_273 = ifn_277.Invoke_O__O(arg_278) } else { arg_273 = linked_276.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_275, arg_278) }; var arg_274 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp5 any; var root_279 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = s__292000018__3; if linked_280 == nil { tmp5 = ifn_281.Invoke_O__O(arg_282) } else { tmp5 = linked_280.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_279, arg_282) }; arg_274 = tmp4.Invoke_O__O(tmp5); if linked_271 == nil { return ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { return linked_271.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) } } else { var root_283 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any; var root_288 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = b__292000020__6; if linked_289 == nil { arg_286 = ifn_290.Invoke_O__O(arg_291) } else { arg_286 = linked_289.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_288, arg_291) }; var arg_287 any; if linked_284 == nil { return ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { return linked_284.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_283, arg_286, arg_287) } } } else { var mm__4 any; var root_292 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = s__292000018__3; if linked_293 == nil { mm__4 = ifn_294.Invoke_O__O(arg_295) } else { mm__4 = linked_293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_292, arg_295) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_296 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any; var root_300 any = A_arbace_j2g_dyncf_A_const_74.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = mm__4; if linked_301 == nil { arg_299 = ifn_302.Invoke_O__O(arg_303) } else { arg_299 = linked_301.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_300, arg_303) }; if linked_297 == nil { and__1927000168__auto____6 = ifn_298.Invoke_O__O(arg_299) } else { and__1927000168__auto____6 = linked_297.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_296, arg_299) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_304 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_305 == nil { tmp6 = ifn_306.Invoke_O__O(arg_307) } else { tmp6 = linked_305.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_304, arg_307) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :70:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_308 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_310 lang.IFn

		if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any; var root_312 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = t.F_n; if linked_313 == nil { arg_311 = ifn_314.Invoke_O__O(arg_315) } else { arg_311 = linked_313.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_312, arg_315) }; if linked_309 == nil { or__1927000174__auto____5 = ifn_310.Invoke_O__O(arg_311) } else { or__1927000174__auto____5 = linked_309.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_316 any = A_arbace_j2g_dyncf_A_const_77.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any; var root_321 any = A_arbace_j2g_dyncf_A_const_78.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyncf_A_const_79; var arg_324 any = tmp8.Invoke_O__O(A_arbace_j2g_dyncf_A_const_80.Get__O()); var arg_325 any; var root_326 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = t.F_n; if linked_327 == nil { arg_325 = ifn_328.Invoke_O__O(arg_329) } else { arg_325 = linked_327.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_326, arg_329) }; if linked_322 == nil { arg_319 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { arg_319 = linked_322.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_321, arg_324, arg_325) }; var arg_320 any; var root_330 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_331 == nil { arg_320 = ifn_332.Invoke_O__O(arg_333) } else { arg_320 = linked_331.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_330, arg_333) }; if linked_317 == nil { tmp7 = ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { tmp7 = linked_317.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_316, arg_319, arg_320) } }
//line :70:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_334 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_336 lang.IFn



			if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = t.F_n; if linked_335 == nil { tmp9 = ifn_336.Invoke_O__O(arg_337) } else { tmp9 = linked_335.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4) } else { var root_338 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = t.F_n; var arg_342 any = mm__4; if linked_339 == nil { real__5 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { real__5 = linked_339.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) } }
//line :70:1
			var vec__292000033__6 any; var root_343 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_345 lang.IFn




			if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_344 == nil { vec__292000033__6 = ifn_345.Invoke_O__O(arg_346) } else { vec__292000033__6 = linked_344.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_343, arg_346) }
//line :70:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000036__9 any; var root_347 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_349 lang.IFn; _ = ___8





			if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = real__5; if linked_348 == nil { vec__292000036__9 = ifn_349.Invoke_O__O(arg_350) } else { vec__292000036__9 = linked_348.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_347, arg_350) }
//line :70:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_351 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any; var tmp10 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyncf_A_const_85; var tmp13 any; var root_356 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_358 lang.IFn








				if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = A_arbace_j2g_dyncf_A_const_86; var arg_360 any = A_arbace_j2g_dyncf_A_const_87; if linked_357 == nil { tmp13 = ifn_358.Invoke_O_O__O(arg_359, arg_360) } else { tmp13 = linked_357.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_356, arg_359, arg_360) }
//line :70:1
				var tmp14 any = tmp13; var tmp15 any; var root_361 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_363 lang.IFn








				if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = A_arbace_j2g_dyncf_A_const_88; var arg_365 any = A_arbace_j2g_dyncf_A_const_105; if linked_362 == nil { tmp15 = ifn_363.Invoke_O_O__O(arg_364, arg_365) } else { tmp15 = linked_362.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_361, arg_364, arg_365) }
//line :70:1
				var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyncf_A_const_90; var tmp19 any = A_arbace_j2g_dyncf_A_const_97; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_98, t.F_recv, A_arbace_j2g_dyncf_A_const_99)); var tmp21 any; var root_366 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_368 lang.IFn










				if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_370 any; var root_374 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil); var tmp23 any; var root_378 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = real__5; if linked_379 == nil { tmp23 = ifn_380.Invoke_O__O(arg_381) } else { tmp23 = linked_379.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_378, arg_381) }; arg_377 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_375 == nil { arg_370 = ifn_376.Invoke_O__O(arg_377) } else { arg_370 = linked_375.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_374, arg_377) }; var arg_371 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp25 any; var root_382 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_384 lang.IFn
				if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any; var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp27 any; var root_386 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = t.F_n; if linked_387 == nil { tmp27 = ifn_388.Invoke_O__O(arg_389) } else { tmp27 = linked_387.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_386, arg_389) }; arg_385 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp27)).Ref(); if linked_383 == nil { tmp25 = ifn_384.Invoke_O__O(arg_385) } else { tmp25 = linked_383.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_382, arg_385) }; arg_371 = tmp24.Invoke_O_O__O(tmp25, A_arbace_j2g_dyncf_A_const_91)
//line :81:1
				var arg_372 any = A_arbace_j2g_dyncf_A_const_92; var arg_373 any; var root_390 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_392 lang.IFn

				if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any; var fnbody__401 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New(); var tmp28 *jrt.Class; var fncls__400 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class; if fncls__400 == nil { var fncls__400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, nil); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class = fncls__400d; tmp28 = fncls__400d } else { tmp28 = fncls__400 }; arg_393 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__401, tmp28, nil); var arg_394 any = ps__7; if linked_391 == nil { arg_373 = ifn_392.Invoke_O_O__O(arg_393, arg_394) } else { arg_373 = linked_391.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_390, arg_393, arg_394) }
//line :81:1
				if linked_367 == nil { tmp21 = ifn_368.Invoke_O_O_O_O_O__O(arg_369, arg_370, arg_371, arg_372, arg_373) } else { tmp21 = linked_367.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_366, arg_369, arg_370, arg_371, arg_372, arg_373) }
//line :70:1
				arg_354 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp20, tmp21))); var arg_355 any; var tmp29 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp30 any; var root_402 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = s__292000018__3; if linked_403 == nil { tmp30 = ifn_404.Invoke_O__O(arg_405) } else { tmp30 = linked_403.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_402, arg_405) }; arg_355 = tmp29.Invoke_O__O(tmp30); if linked_352 == nil { return ifn_353.Invoke_O_O__O(arg_354, arg_355) } else { return linked_352.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_351, arg_354, arg_355) } } else { var tmp31 any; var root_406 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = s__292000018__3; if linked_407 == nil { tmp31 = ifn_408.Invoke_O__O(arg_409) } else { tmp31 = linked_407.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_406, arg_409) }; s__292000018__1 = tmp31; continue L1 } } else { var tmp32 any; var root_410 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = s__292000018__3; if linked_411 == nil { tmp32 = ifn_412.Invoke_O__O(arg_413) } else { tmp32 = linked_411.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_410, arg_413) }; s__292000018__1 = tmp32; continue L1 } } else { var tmp33 any; var root_414 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = s__292000018__3; if linked_415 == nil { tmp33 = ifn_416.Invoke_O__O(arg_417) } else { tmp33 = linked_415.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_414, arg_417) }; s__292000018__1 = tmp33; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :70:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Ctor_O_O_O_I_O(c__b__292000020, c__recv, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000020 = c__b__292000020; t.F_recv = c__recv; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Invoke_O__O(self any) any { { var i__292000019__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000019__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000019__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_162 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any; var root_166 any = A_arbace_j2g_dyncf_A_const_74.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = mm__2; if linked_167 == nil { arg_165 = ifn_168.Invoke_O__O(arg_169) } else { arg_165 = linked_167.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if linked_163 == nil { and__1927000168__auto____4 = ifn_164.Invoke_O__O(arg_165) } else { and__1927000168__auto____4 = linked_163.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_170 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_171 == nil { tmp2 = ifn_172.Invoke_O__O(arg_173) } else { tmp2 = linked_171.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_170, arg_173) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :70:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_174 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_176 lang.IFn

		if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any; var root_178 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = t.F_n; if linked_179 == nil { arg_177 = ifn_180.Invoke_O__O(arg_181) } else { arg_177 = linked_179.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_178, arg_181) }; if linked_175 == nil { or__1927000174__auto____3 = ifn_176.Invoke_O__O(arg_177) } else { or__1927000174__auto____3 = linked_175.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_174, arg_177) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_182 any = A_arbace_j2g_dyncf_A_const_77.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var root_187 any = A_arbace_j2g_dyncf_A_const_78.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyncf_A_const_79; var arg_190 any = tmp4.Invoke_O__O(A_arbace_j2g_dyncf_A_const_80.Get__O()); var arg_191 any; var root_192 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = t.F_n; if linked_193 == nil { arg_191 = ifn_194.Invoke_O__O(arg_195) } else { arg_191 = linked_193.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_192, arg_195) }; if linked_188 == nil { arg_185 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { arg_185 = linked_188.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; var arg_186 any; var root_196 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_197 == nil { arg_186 = ifn_198.Invoke_O__O(arg_199) } else { arg_186 = linked_197.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_196, arg_199) }; if linked_183 == nil { tmp3 = ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { tmp3 = linked_183.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_182, arg_185, arg_186) } }
//line :70:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_200 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_202 lang.IFn



			if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = t.F_n; if linked_201 == nil { tmp5 = ifn_202.Invoke_O__O(arg_203) } else { tmp5 = linked_201.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2) } else { var root_204 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = t.F_n; var arg_208 any = mm__2; if linked_205 == nil { real__3 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { real__3 = linked_205.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } }
//line :70:1
			var vec__292000024__4 any; var root_209 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_211 lang.IFn




			if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_210 == nil { vec__292000024__4 = ifn_211.Invoke_O__O(arg_212) } else { vec__292000024__4 = linked_210.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_209, arg_212) }
//line :70:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000027__7 any; var root_213 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_215 lang.IFn; _ = ___6





			if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = real__3; if linked_214 == nil { vec__292000027__7 = ifn_215.Invoke_O__O(arg_216) } else { vec__292000027__7 = linked_214.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_213, arg_216) }
//line :70:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_217 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = t.F_b__292000020; var arg_221 any; var tmp6 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyncf_A_const_85; var tmp9 any; var root_222 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_224 lang.IFn








				if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = A_arbace_j2g_dyncf_A_const_86; var arg_226 any = A_arbace_j2g_dyncf_A_const_87; if linked_223 == nil { tmp9 = ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { tmp9 = linked_223.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) }
//line :70:1
				var tmp10 any = tmp9; var tmp11 any; var root_227 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_229 lang.IFn








				if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = A_arbace_j2g_dyncf_A_const_88; var arg_231 any = A_arbace_j2g_dyncf_A_const_89; if linked_228 == nil { tmp11 = ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { tmp11 = linked_228.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) }
//line :70:1
				var tmp12 any = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyncf_A_const_90; var tmp15 any = A_arbace_j2g_dyncf_A_const_97; var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_98, t.F_recv, A_arbace_j2g_dyncf_A_const_99)); var tmp17 any; var root_232 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_234 lang.IFn










				if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_236 any; var root_240 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil); var tmp19 any; var root_244 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = real__3; if linked_245 == nil { tmp19 = ifn_246.Invoke_O__O(arg_247) } else { tmp19 = linked_245.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_244, arg_247) }; arg_243 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19)).Ref(); if linked_241 == nil { arg_236 = ifn_242.Invoke_O__O(arg_243) } else { arg_236 = linked_241.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_240, arg_243) }; var arg_237 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp21 any; var root_248 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_250 lang.IFn
				if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp23 any; var root_252 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = t.F_n; if linked_253 == nil { tmp23 = ifn_254.Invoke_O__O(arg_255) } else { tmp23 = linked_253.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_252, arg_255) }; arg_251 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_249 == nil { tmp21 = ifn_250.Invoke_O__O(arg_251) } else { tmp21 = linked_249.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_248, arg_251) }; arg_237 = tmp20.Invoke_O_O__O(tmp21, A_arbace_j2g_dyncf_A_const_91)
//line :81:1
				var arg_238 any = A_arbace_j2g_dyncf_A_const_92; var arg_239 any; var root_256 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_258 lang.IFn

				if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any; var fnbody__267 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New(); var tmp24 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class = fncls__266d; tmp24 = fncls__266d } else { tmp24 = fncls__266 }; arg_259 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__267, tmp24, nil); var arg_260 any = ps__5; if linked_257 == nil { arg_239 = ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { arg_239 = linked_257.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_256, arg_259, arg_260) }
//line :81:1
				if linked_233 == nil { tmp17 = ifn_234.Invoke_O_O_O_O_O__O(arg_235, arg_236, arg_237, arg_238, arg_239) } else { tmp17 = linked_233.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_232, arg_235, arg_236, arg_237, arg_238, arg_239) }
//line :70:1
				arg_221 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp16, tmp17))); if linked_218 == nil { ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { linked_218.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) }; i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_261 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = p__2; var arg_265 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_95, A_arbace_j2g_dyncf_A_const_96, i__1); if linked_262 == nil { return ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { return linked_262.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) } }
//line :83:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_395 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = p__2; var arg_399 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_95, A_arbace_j2g_dyncf_A_const_96, i__1); if linked_396 == nil { return ifn_397.Invoke_O_O__O(arg_398, arg_399) } else { return linked_396.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_395, arg_398, arg_399) } }


func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Invoke_O_O__O(self, s__292000044__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__721 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000044__1); var tmp2 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, fnbody__721); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class = fncls__720d; tmp2 = fncls__720d } else { tmp2 = fncls__720 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__721, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :86:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000043, c__s__292000044 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000043 = c__iter__292000043; t.F_s__292000044 = c__s__292000044 }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Invoke_O__O(self any) any { { var s__292000044__1 any; var t_ any = t.F_s__292000044; t.F_s__292000044 = nil; s__292000044__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_450 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = s__292000044__1; if linked_451 == nil { temp__1927000414__auto____2 = ifn_452.Invoke_O__O(arg_453) } else { temp__1927000414__auto____2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000044__3 any = temp__1927000414__auto____2; var tmp1 any; var root_454 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = s__292000044__3; if linked_455 == nil { tmp1 = ifn_456.Invoke_O__O(arg_457) } else { tmp1 = linked_455.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_458 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__292000044__3; if linked_459 == nil { c__1927001037__auto____4 = ifn_460.Invoke_O__O(arg_461) } else { c__1927001037__auto____4 = linked_459.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_458, arg_461) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000046__6 any; var root_462 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_463 == nil { b__292000046__6 = ifn_464.Invoke_O__O(arg_465) } else { b__292000046__6 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_462, arg_465) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__574 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(t.F_recv, b__292000046__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__573 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class; if fncls__573 == nil { var fncls__573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, fnbody__574); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class = fncls__573d; tmp3 = fncls__573d } else { tmp3 = fncls__573 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__574, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_575 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var root_580 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = b__292000046__6; if linked_581 == nil { arg_578 = ifn_582.Invoke_O__O(arg_583) } else { arg_578 = linked_581.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_580, arg_583) }; var arg_579 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp5 any; var root_584 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = s__292000044__3; if linked_585 == nil { tmp5 = ifn_586.Invoke_O__O(arg_587) } else { tmp5 = linked_585.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_584, arg_587) }; arg_579 = tmp4.Invoke_O__O(tmp5); if linked_576 == nil { return ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { return linked_576.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_575, arg_578, arg_579) } } else { var root_588 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_593 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = b__292000046__6; if linked_594 == nil { arg_591 = ifn_595.Invoke_O__O(arg_596) } else { arg_591 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_593, arg_596) }; var arg_592 any; if linked_589 == nil { return ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { return linked_589.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) } } } else { var vec__292000063__4 any; var root_597 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = s__292000044__3; if linked_598 == nil { vec__292000063__4 = ifn_599.Invoke_O__O(arg_600) } else { vec__292000063__4 = linked_598.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_597, arg_600) }; var vec__292000066__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(0), nil); var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__292000066__5; var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_601 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_603 lang.IFn; _ = ___9
														if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = desc__7; if linked_602 == nil { tmp6 = ifn_603.Invoke_O__O(arg_604) } else { tmp6 = linked_602.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_601, arg_604) }
//line :86:1
	if jrt.J2g_Truth(tmp6) { var impl__10 any; var root_605 any = A_arbace_j2g_dyncf_A_const_114.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_607 lang.IFn

		if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = t.F_n; var arg_609 any = k__8; if linked_606 == nil { impl__10 = ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { impl__10 = linked_606.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) }
//line :86:1
		var base__11 any; var root_610 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_612 lang.IFn


		if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = name__6; var arg_614 any = desc__7; if linked_611 == nil { base__11 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { base__11 = linked_611.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }
//line :86:1
		var vec__292000069__12 any; var root_615 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_617 lang.IFn



		if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = desc__7; if linked_616 == nil { vec__292000069__12 = ifn_617.Invoke_O__O(arg_618) } else { vec__292000069__12 = linked_616.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_615, arg_618) }
//line :86:1
		var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(0), nil); var r__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__15 any; var root_619 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_621 lang.IFn




		if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any; var fnbody__630 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New(); var tmp7 *jrt.Class; var fncls__629 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class; if fncls__629 == nil { var fncls__629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, nil); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class = fncls__629d; tmp7 = fncls__629d } else { tmp7 = fncls__629 }; arg_622 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__630, tmp7, nil); var arg_623 any = ps__13; if linked_620 == nil { pn__15 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { pn__15 = linked_620.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }
//line :86:1
		var call__16 any; var G__292000074__16_ any = A_arbace_j2g_dyncf_A_const_117.Invoke_O__O(impl__10)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000074__16_) >> 4 & 3 { case 0: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_118) {

		var root_632 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_636 any; var root_639 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = A_arbace_j2g_dyncf_A_const_31; var arg_643 any = A_arbace_j2g_dyncf_A_const_119.Invoke_O__O(impl__10); var arg_644 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_640 == nil { arg_636 = ifn_641.Invoke_O_O_O__O(arg_642, arg_643, arg_644) } else { arg_636 = linked_640.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_639, arg_642, arg_643, arg_644) }; var arg_637 any = A_arbace_j2g_dyncf_A_const_120; var arg_638 any = pn__15; if linked_633 == nil { call__16 = ifn_634.Invoke_O_O_O_O__O(arg_635, arg_636, arg_637, arg_638) } else { call__16 = linked_633.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_632, arg_635, arg_636, arg_637, arg_638) }
//line :92:1
		break L2 }; case 1: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_121) {
			var root_645 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_649 any; var root_653 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_654 == nil { arg_649 = ifn_655.Invoke_O__O(arg_656) } else { arg_649 = linked_654.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_653, arg_656) }; var arg_650 any = A_arbace_j2g_dyncf_A_const_122; var arg_651 any = A_arbace_j2g_dyncf_A_const_123; var arg_652 any = pn__15; if linked_646 == nil { call__16 = ifn_647.Invoke_O_O_O_O_O__O(arg_648, arg_649, arg_650, arg_651, arg_652) } else { call__16 = linked_646.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_645, arg_648, arg_649, arg_650, arg_651, arg_652) }
//line :92:1
			break L2 }; case 2: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_124) {
				var root_657 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_661 any; var root_665 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_666 == nil { arg_661 = ifn_667.Invoke_O__O(arg_668) } else { arg_661 = linked_666.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_665, arg_668) }; var arg_662 any = A_arbace_j2g_dyncf_A_const_122; var arg_663 any = A_arbace_j2g_dyncf_A_const_123; var arg_664 any = pn__15; if linked_658 == nil { call__16 = ifn_659.Invoke_O_O_O_O_O__O(arg_660, arg_661, arg_662, arg_663, arg_664) } else { call__16 = linked_658.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_657, arg_660, arg_661, arg_662, arg_663, arg_664) }
//line :92:1
				break L2 }; case 3: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_125) {


					var root_669 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_673 any; var root_676 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_677 == nil { arg_673 = ifn_678.Invoke_O__O(arg_679) } else { arg_673 = linked_677.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_676, arg_679) }; var arg_674 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp9 any; var root_680 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp11 any; var root_684 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = t.F_n; if linked_685 == nil { tmp11 = ifn_686.Invoke_O__O(arg_687) } else { tmp11 = linked_685.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_684, arg_687) }; arg_683 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(); if linked_681 == nil { tmp9 = ifn_682.Invoke_O__O(arg_683) } else { tmp9 = linked_681.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_680, arg_683) }; arg_674 = tmp8.Invoke_O_O__O(tmp9, A_arbace_j2g_dyncf_A_const_126); var arg_675 any = pn__15; if linked_670 == nil { call__16 = ifn_671.Invoke_O_O_O_O__O(arg_672, arg_673, arg_674, arg_675) } else { call__16 = linked_670.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_669, arg_672, arg_673, arg_674, arg_675) }
//line :92:1
					break L2 }; default:}; call__16 = nil}
//line :86:1
		if jrt.J2g_Truth(call__16) { var root_688 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__6, desc__7)).Ref(); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyncf_A_const_127; var tmp15 any; var root_693 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_695 lang.IFn












			if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any; var tmp16 any; var root_698 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = A_arbace_j2g_dyncf_A_const_128; var arg_702 any = A_arbace_j2g_dyncf_A_const_129; if linked_699 == nil { tmp16 = ifn_700.Invoke_O_O__O(arg_701, arg_702) } else { tmp16 = linked_699.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_698, arg_701, arg_702) }; var tmp17 any = tmp16; var tmp18 any; var root_703 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = A_arbace_j2g_dyncf_A_const_130; var arg_707 any = A_arbace_j2g_dyncf_A_const_141; if linked_704 == nil { tmp18 = ifn_705.Invoke_O_O__O(arg_706, arg_707) } else { tmp18 = linked_704.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_703, arg_706, arg_707) }; arg_696 = lang.Tuple_Create_O_O__IPersistentVector(tmp17, tmp18); var arg_697 any = A_arbace_j2g_dyncf_A_const_142; if linked_694 == nil { tmp15 = ifn_695.Invoke_O_O__O(arg_696, arg_697) } else { tmp15 = linked_694.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_693, arg_696, arg_697) }
//line :86:1
			var tmp19 any = tmp15; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyncf_A_const_133; var tmp22 any = A_arbace_j2g_dyncf_A_const_134; var tmp23 any = lang.Tuple_Create_O_O__IPersistentVector(tmp22, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_135, t.F_recv, A_arbace_j2g_dyncf_A_const_136)); var tmp24 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_157, r__14) {
				tmp24 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_137, call__16, A_arbace_j2g_dyncf_A_const_143) } else {
					var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyncf_A_const_139; tmp24 = tmp25.Invoke_O_O__O(tmp26, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_140, call__16)) }
//line :86:1
			arg_691 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp19, tmp20.Invoke_O_O_O__O(tmp21, tmp23, tmp24))); var arg_692 any; var tmp27 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp28 any; var root_708 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = s__292000044__3; if linked_709 == nil { tmp28 = ifn_710.Invoke_O__O(arg_711) } else { tmp28 = linked_709.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_708, arg_711) }; arg_692 = tmp27.Invoke_O__O(tmp28); if linked_689 == nil { return ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { return linked_689.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) } } else { var tmp29 any; var root_712 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = s__292000044__3; if linked_713 == nil { tmp29 = ifn_714.Invoke_O__O(arg_715) } else { tmp29 = linked_713.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_712, arg_715) }; s__292000044__1 = tmp29; continue L1 } } else { var tmp30 any; var root_716 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = s__292000044__3; if linked_717 == nil { tmp30 = ifn_718.Invoke_O__O(arg_719) } else { tmp30 = linked_717.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_716, arg_719) }; s__292000044__1 = tmp30; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :86:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Ctor_O_O_O_I_O(c__recv, c__b__292000046, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_b__292000046 = c__b__292000046; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Invoke_O__O(self any) any { { var i__292000045__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000045__1)); var vec__292000053__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__292000053__3; var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_466 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_468 lang.IFn; _ = ___7
																if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = desc__5; if linked_467 == nil { tmp2 = ifn_468.Invoke_O__O(arg_469) } else { tmp2 = linked_467.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_466, arg_469) }
//line :86:1
	if jrt.J2g_Truth(tmp2) { var impl__8 any; var root_470 any = A_arbace_j2g_dyncf_A_const_114.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_472 lang.IFn

		if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = t.F_n; var arg_474 any = k__6; if linked_471 == nil { impl__8 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { impl__8 = linked_471.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }
//line :86:1
		var base__9 any; var root_475 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_477 lang.IFn


		if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = name__4; var arg_479 any = desc__5; if linked_476 == nil { base__9 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { base__9 = linked_476.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }
//line :86:1
		var vec__292000056__10 any; var root_480 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_482 lang.IFn



		if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = desc__5; if linked_481 == nil { vec__292000056__10 = ifn_482.Invoke_O__O(arg_483) } else { vec__292000056__10 = linked_481.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_480, arg_483) }
//line :86:1
		var ps__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_484 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_486 lang.IFn




		if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any; var fnbody__495 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New(); var tmp3 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, nil); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class = fncls__494d; tmp3 = fncls__494d } else { tmp3 = fncls__494 }; arg_487 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__495, tmp3, nil); var arg_488 any = ps__11; if linked_485 == nil { pn__13 = ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { pn__13 = linked_485.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_484, arg_487, arg_488) }
//line :86:1
		var call__14 any; var G__292000061__14_ any = A_arbace_j2g_dyncf_A_const_117.Invoke_O__O(impl__8)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000061__14_) >> 4 & 3 { case 0: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_118) {

		var root_497 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_501 any; var root_504 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = A_arbace_j2g_dyncf_A_const_31; var arg_508 any = A_arbace_j2g_dyncf_A_const_119.Invoke_O__O(impl__8); var arg_509 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_505 == nil { arg_501 = ifn_506.Invoke_O_O_O__O(arg_507, arg_508, arg_509) } else { arg_501 = linked_505.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_504, arg_507, arg_508, arg_509) }; var arg_502 any = A_arbace_j2g_dyncf_A_const_120; var arg_503 any = pn__13; if linked_498 == nil { call__14 = ifn_499.Invoke_O_O_O_O__O(arg_500, arg_501, arg_502, arg_503) } else { call__14 = linked_498.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_497, arg_500, arg_501, arg_502, arg_503) }
//line :92:1
		break L2 }; case 1: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_121) {
			var root_510 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_514 any; var root_518 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_519 == nil { arg_514 = ifn_520.Invoke_O__O(arg_521) } else { arg_514 = linked_519.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_518, arg_521) }; var arg_515 any = A_arbace_j2g_dyncf_A_const_122; var arg_516 any = A_arbace_j2g_dyncf_A_const_123; var arg_517 any = pn__13; if linked_511 == nil { call__14 = ifn_512.Invoke_O_O_O_O_O__O(arg_513, arg_514, arg_515, arg_516, arg_517) } else { call__14 = linked_511.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_510, arg_513, arg_514, arg_515, arg_516, arg_517) }
//line :92:1
			break L2 }; case 2: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_124) {
				var root_522 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_526 any; var root_530 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_531 == nil { arg_526 = ifn_532.Invoke_O__O(arg_533) } else { arg_526 = linked_531.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_530, arg_533) }; var arg_527 any = A_arbace_j2g_dyncf_A_const_122; var arg_528 any = A_arbace_j2g_dyncf_A_const_123; var arg_529 any = pn__13; if linked_523 == nil { call__14 = ifn_524.Invoke_O_O_O_O_O__O(arg_525, arg_526, arg_527, arg_528, arg_529) } else { call__14 = linked_523.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_522, arg_525, arg_526, arg_527, arg_528, arg_529) }
//line :92:1
				break L2 }; case 3: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_125) {


					var root_534 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_538 any; var root_541 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_542 == nil { arg_538 = ifn_543.Invoke_O__O(arg_544) } else { arg_538 = linked_542.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_541, arg_544) }; var arg_539 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp5 any; var root_545 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp7 any; var root_549 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = t.F_n; if linked_550 == nil { tmp7 = ifn_551.Invoke_O__O(arg_552) } else { tmp7 = linked_550.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_549, arg_552) }; arg_548 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref(); if linked_546 == nil { tmp5 = ifn_547.Invoke_O__O(arg_548) } else { tmp5 = linked_546.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_545, arg_548) }; arg_539 = tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_dyncf_A_const_126); var arg_540 any = pn__13; if linked_535 == nil { call__14 = ifn_536.Invoke_O_O_O_O__O(arg_537, arg_538, arg_539, arg_540) } else { call__14 = linked_535.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_534, arg_537, arg_538, arg_539, arg_540) }
//line :92:1
					break L2 }; default:}; call__14 = nil}
//line :86:1
		if jrt.J2g_Truth(call__14) { var root_553 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = t.F_b__292000046; var arg_557 any; var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__4, desc__5)).Ref(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyncf_A_const_127; var tmp11 any; var root_558 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_560 lang.IFn












			if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any; var tmp12 any; var root_563 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = A_arbace_j2g_dyncf_A_const_128; var arg_567 any = A_arbace_j2g_dyncf_A_const_129; if linked_564 == nil { tmp12 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { tmp12 = linked_564.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_563, arg_566, arg_567) }; var tmp13 any = tmp12; var tmp14 any; var root_568 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = A_arbace_j2g_dyncf_A_const_130; var arg_572 any = A_arbace_j2g_dyncf_A_const_131; if linked_569 == nil { tmp14 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { tmp14 = linked_569.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }; arg_561 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14); var arg_562 any = A_arbace_j2g_dyncf_A_const_132; if linked_559 == nil { tmp11 = ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { tmp11 = linked_559.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_558, arg_561, arg_562) }
//line :86:1
			var tmp15 any = tmp11; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyncf_A_const_133; var tmp18 any = A_arbace_j2g_dyncf_A_const_134; var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(tmp18, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_135, t.F_recv, A_arbace_j2g_dyncf_A_const_136)); var tmp20 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_157, r__12) {
				tmp20 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_137, call__14, A_arbace_j2g_dyncf_A_const_138) } else {
					var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyncf_A_const_139; tmp20 = tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_140, call__14)) }
//line :86:1
			arg_557 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9.Invoke_O_O_O__O(tmp10, tmp15, tmp16.Invoke_O_O_O__O(tmp17, tmp19, tmp20))); if linked_554 == nil { ifn_555.Invoke_O_O__O(arg_556, arg_557) } else { linked_554.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_553, arg_556, arg_557) }; i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Ctor() {}
//line :91:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_489 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = p__2; var arg_493 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_115, A_arbace_j2g_dyncf_A_const_116, i__1); if linked_490 == nil { return ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { return linked_490.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) } }
//line :91:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Ctor() {}
//line :91:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_624 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = p__2; var arg_628 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_115, A_arbace_j2g_dyncf_A_const_116, i__1); if linked_625 == nil { return ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { return linked_625.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) } }

















func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A) Ctor_O_O(c__recv, c__seen any) { t.F_recv = c__recv; t.F_seen = c__seen }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A) Invoke_O_O__O(self, s__292000078__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1053 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_New_O_O_O_O(t.F_recv, self, t.F_seen, s__292000078__1); var tmp2 *jrt.Class; var fncls__1052 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_fn_class; if fncls__1052 == nil { var fncls__1052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, fnbody__1053); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_fn_class = fncls__1052d; tmp2 = fncls__1052d } else { tmp2 = fncls__1052 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1053, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :109:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A) Ctor_O_O_O_O(c__recv, c__iter__292000077, c__seen, c__s__292000078 any) { t.F_recv = c__recv; t.F_iter__292000077 = c__iter__292000077; t.F_seen = c__seen; t.F_s__292000078 = c__s__292000078 }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A) Invoke_O__O(self any) any { { var s__292000078__1 any; var t_ any = t.F_s__292000078; t.F_s__292000078 = nil; s__292000078__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_757 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = s__292000078__1; if linked_758 == nil { temp__1927000414__auto____2 = ifn_759.Invoke_O__O(arg_760) } else { temp__1927000414__auto____2 = linked_758.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_757, arg_760) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_761 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = xs__1927001018__auto____3; if linked_762 == nil { c__4 = ifn_763.Invoke_O__O(arg_764) } else { c__4 = linked_762.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_761, arg_764) }; var tmp1 any; var and__1927000168__auto____5 any = c__4
														if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_765 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = c__4; var arg_769 any = Lit_110; if linked_766 == nil { and__1927000168__auto____6 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { and__1927000168__auto____6 = linked_766.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_770 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var root_774 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = c__4; if linked_775 == nil { arg_773 = ifn_776.Invoke_O__O(arg_777) } else { arg_773 = linked_775.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_774, arg_777) }; if linked_771 == nil { tmp1 = ifn_772.Invoke_O__O(arg_773) } else { tmp1 = linked_771.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_770, arg_773) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }
//line :109:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__1021 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_New_O_O_O(t.F_recv, t.F_seen, c__4); var tmp2 *jrt.Class; var fncls__1020 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_fn_class; if fncls__1020 == nil { var fncls__1020d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, fnbody__1021); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_fn_class = fncls__1020d; tmp2 = fncls__1020d } else { tmp2 = fncls__1020 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1021, tmp2, nil); var fs__1927001036__auto____6 any; var root_1022 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1026 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1028 lang.IFn

		if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = A_arbace_j2g_dyncf_A_const_72; var arg_1030 any; var root_1031 any = A_arbace_j2g_dyncf_A_const_190.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = c__4; if linked_1032 == nil { arg_1030 = ifn_1033.Invoke_O__O(arg_1034) } else { arg_1030 = linked_1032.(*aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A).Invoke_O_O__O(root_1031, arg_1034) }; if linked_1027 == nil { tmp4 = ifn_1028.Invoke_O_O__O(arg_1029, arg_1030) } else { tmp4 = linked_1027.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1026, arg_1029, arg_1030) }
//line :109:1
		arg_1025 = tmp3.Invoke_O__O(tmp4); if linked_1023 == nil { fs__1927001036__auto____6 = ifn_1024.Invoke_O__O(arg_1025) } else { fs__1927001036__auto____6 = linked_1023.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1022, arg_1025) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1035 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = fs__1927001036__auto____6; var arg_1039 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__292000077); var tmp6 any; var root_1040 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = s__292000078__1; if linked_1041 == nil { tmp6 = ifn_1042.Invoke_O__O(arg_1043) } else { tmp6 = linked_1041.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1040, arg_1043) }; arg_1039 = tmp5.Invoke_O__O(tmp6); if linked_1036 == nil { return ifn_1037.Invoke_O_O__O(arg_1038, arg_1039) } else { return linked_1036.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1035, arg_1038, arg_1039) } } else { var tmp7 any; var root_1044 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = s__292000078__1; if linked_1045 == nil { tmp7 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp7 = linked_1045.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1044, arg_1047) }; s__292000078__1 = tmp7; continue L1 } } else { var tmp8 any; var root_1048 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = s__292000078__1; if linked_1049 == nil { tmp8 = ifn_1050.Invoke_O__O(arg_1051) } else { tmp8 = linked_1049.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1048, arg_1051) }; s__292000078__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A) Ctor_O_O_O(c__recv, c__seen, c__c any) { t.F_recv = c__recv; t.F_seen = c__seen; t.F_c = c__c }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A) Invoke_O_O__O(self, s__292000080__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1019 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_New_O_O_O_O_O(t.F_recv, s__292000080__1, t.F_seen, self, t.F_c); var tmp2 *jrt.Class; var fncls__1018 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_fn_class; if fncls__1018 == nil { var fncls__1018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, fnbody__1019); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_fn_class = fncls__1018d; tmp2 = fncls__1018d } else { tmp2 = fncls__1018 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1019, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :109:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A) Ctor_O_O_O_O_O(c__recv, c__s__292000080, c__seen, c__iter__292000079, c__c any) { t.F_recv = c__recv; t.F_s__292000080 = c__s__292000080; t.F_seen = c__seen; t.F_iter__292000079 = c__iter__292000079; t.F_c = c__c }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A) Invoke_O__O(self any) any { { var s__292000080__1 any; var t_ any = t.F_s__292000080; t.F_s__292000080 = nil; s__292000080__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_778 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = s__292000080__1; if linked_779 == nil { temp__1927000414__auto____2 = ifn_780.Invoke_O__O(arg_781) } else { temp__1927000414__auto____2 = linked_779.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_778, arg_781) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000080__3 any = temp__1927000414__auto____2; var tmp1 any; var root_782 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = s__292000080__3; if linked_783 == nil { tmp1 = ifn_784.Invoke_O__O(arg_785) } else { tmp1 = linked_783.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_782, arg_785) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_786 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = s__292000080__3; if linked_787 == nil { c__1927001037__auto____4 = ifn_788.Invoke_O__O(arg_789) } else { c__1927001037__auto____4 = linked_787.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_786, arg_789) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000082__6 any; var root_790 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_791 == nil { b__292000082__6 = ifn_792.Invoke_O__O(arg_793) } else { b__292000082__6 = linked_791.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_790, arg_793) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__887 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_New_O_O_I_O_O_O(t.F_recv, t.F_seen, size__1927001038__auto____5, b__292000082__6, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__886 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_fn_class; if fncls__886 == nil { var fncls__886d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, fnbody__887); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_fn_class = fncls__886d; tmp3 = fncls__886d } else { tmp3 = fncls__886 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__887, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_888 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var root_893 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = b__292000082__6; if linked_894 == nil { arg_891 = ifn_895.Invoke_O__O(arg_896) } else { arg_891 = linked_894.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_893, arg_896) }; var arg_892 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000079); var tmp5 any; var root_897 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = s__292000080__3; if linked_898 == nil { tmp5 = ifn_899.Invoke_O__O(arg_900) } else { tmp5 = linked_898.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_897, arg_900) }; arg_892 = tmp4.Invoke_O__O(tmp5); if linked_889 == nil { return ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { return linked_889.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_888, arg_891, arg_892) } } else { var root_901 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any; var root_906 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = b__292000082__6; if linked_907 == nil { arg_904 = ifn_908.Invoke_O__O(arg_909) } else { arg_904 = linked_907.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_906, arg_909) }; var arg_905 any; if linked_902 == nil { return ifn_903.Invoke_O_O__O(arg_904, arg_905) } else { return linked_902.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_901, arg_904, arg_905) } } } else { var f__4 any; var root_910 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = s__292000080__3; if linked_911 == nil { f__4 = ifn_912.Invoke_O__O(arg_913) } else { f__4 = linked_911.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_910, arg_913) }; var tmp6 any; var root_914 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_916 lang.IFn


	if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = f__4; if linked_915 == nil { tmp6 = ifn_916.Invoke_O__O(arg_917) } else { tmp6 = linked_915.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_914, arg_917) }
//line :109:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_918 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_920 lang.IFn



		if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any; var tmp8 any; var root_922 any = A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = t.F_seen; if linked_923 == nil { tmp8 = ifn_924.Invoke_O__O(arg_925) } else { tmp8 = linked_923.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_922, arg_925) }; arg_921 = lang.IFn_Cast(tmp8).Invoke_O__O(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4)); if linked_919 == nil { tmp7 = ifn_920.Invoke_O__O(arg_921) } else { tmp7 = linked_919.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_918, arg_921) }
//line :109:1
		if jrt.J2g_Truth(tmp7) { var ___5 any; var root_926 any = A_arbace_j2g_dyncf_A_const_154.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_928 lang.IFn; _ = ___5




			if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = t.F_seen; var arg_930 any = A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(); var arg_931 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); if linked_927 == nil { ___5 = ifn_928.Invoke_O_O_O__O(arg_929, arg_930, arg_931) } else { ___5 = linked_927.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_926, arg_929, arg_930, arg_931) }
//line :109:1
			var d__6 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); var place__7 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp10 any; var root_994 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_996 lang.IFn






			if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp12 any; var root_998 any = A_arbace_j2g_dyncf_A_const_155.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); if linked_999 == nil { tmp12 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp12 = linked_999.(*aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A).Invoke_O_O__O(root_998, arg_1001) }; arg_997 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); if linked_995 == nil { tmp10 = ifn_996.Invoke_O__O(arg_997) } else { tmp10 = linked_995.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_994, arg_997) }; var tmp13 any = tmp10; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp15 any; var root_1002 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1004 lang.IFn
			if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp17 any; var root_1006 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = t.F_c; if linked_1007 == nil { tmp17 = ifn_1008.Invoke_O__O(arg_1009) } else { tmp17 = linked_1007.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1006, arg_1009) }; arg_1005 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17)).Ref(); if linked_1003 == nil { tmp15 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp15 = linked_1003.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1002, arg_1005) }
//line :116:1
			place__7 = tmp9.Invoke_O_O__O(tmp13, tmp14.Invoke_O_O__O(tmp15, A_arbace_j2g_dyncf_A_const_156))
//line :109:1
			var root_932 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any; var tmp18 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp19 any; var vol__8 any; var root_937 any = A_arbace_j2g_dyncf_A_const_157.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_field_QMARK__A_fn_class); var ifn_939 lang.IFn









			if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = f__4; if linked_938 == nil { vol__8 = ifn_939.Invoke_O__O(arg_940) } else { vol__8 = linked_938.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_field_QMARK__A).Invoke_O_O__O(root_937, arg_940) }
//line :109:1
			var rd__9 any










			if jrt.J2g_Truth(vol__8) { var root_941 any = A_arbace_j2g_dyncf_A_const_158.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_read_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = place__7; var arg_945 any = d__6; if linked_942 == nil { rd__9 = ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { rd__9 = linked_942.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_read_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) } } else { rd__9 = place__7 }
			var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyncf_A_const_159; var tmp22 any; var root_946 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var tmp23 any; var root_951 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = A_arbace_j2g_dyncf_A_const_160; var arg_955 any = A_arbace_j2g_dyncf_A_const_161; if linked_952 == nil { tmp23 = ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { tmp23 = linked_952.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) }; var tmp24 any = tmp23; var tmp25 any; var root_956 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = A_arbace_j2g_dyncf_A_const_162; var arg_960 any = A_arbace_j2g_dyncf_A_const_163; if linked_957 == nil { tmp25 = ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { tmp25 = linked_957.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }; var tmp26 any = tmp25; var tmp27 any; var root_961 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = A_arbace_j2g_dyncf_A_const_164; var arg_965 any = A_arbace_j2g_dyncf_A_const_165; if linked_962 == nil { tmp27 = ifn_963.Invoke_O_O__O(arg_964, arg_965) } else { tmp27 = linked_962.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_961, arg_964, arg_965) }; arg_949 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp24, tmp26, tmp27); var arg_950 any = A_arbace_j2g_dyncf_A_const_186; if linked_947 == nil { tmp22 = ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { tmp22 = linked_947.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }; var tmp28 any = tmp22; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_dyncf_A_const_167; var tmp31 any = A_arbace_j2g_dyncf_A_const_169; var tmp32 any = lang.Tuple_Create_O_O__IPersistentVector(tmp31, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_170, t.F_recv, A_arbace_j2g_dyncf_A_const_171)); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp34 any = A_arbace_j2g_dyncf_A_const_172; var tmp35 any = A_arbace_j2g_dyncf_A_const_173; var tmp36 any


			if jrt.J2g_Truth(vol__8) { var root_974 any = A_arbace_j2g_dyncf_A_const_174.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_write_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = place__7; var arg_978 any = d__6; var arg_979 any; var root_980 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = d__6; var arg_984 any = A_arbace_j2g_dyncf_A_const_175; if linked_981 == nil { arg_979 = ifn_982.Invoke_O_O__O(arg_983, arg_984) } else { arg_979 = linked_981.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_980, arg_983, arg_984) }; if linked_975 == nil { tmp36 = ifn_976.Invoke_O_O_O__O(arg_977, arg_978, arg_979) } else { tmp36 = linked_975.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_write_A).Invoke_O_O_O_O__O(root_974, arg_977, arg_978, arg_979) } } else { var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp38 any = A_arbace_j2g_dyncf_A_const_177; var tmp39 any; var root_985 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = d__6; var arg_989 any = A_arbace_j2g_dyncf_A_const_178; if linked_986 == nil { tmp39 = ifn_987.Invoke_O_O__O(arg_988, arg_989) } else { tmp39 = linked_986.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_985, arg_988, arg_989) }; tmp36 = tmp37.Invoke_O_O_O__O(tmp38, place__7, tmp39) }
//line :121:1
			var tmp40 any = tmp33.Invoke_O_O_O_O__O(tmp34, tmp35, tmp36, A_arbace_j2g_dyncf_A_const_187); var tmp41 any; var tmp42 any; var root_966 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_968 lang.IFn





			if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = d__6; if linked_967 == nil { tmp42 = ifn_968.Invoke_O__O(arg_969) } else { tmp42 = linked_967.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_966, arg_969) }
//line :126:1
			if jrt.J2g_Truth(tmp42) {
				var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_dyncf_A_const_179; tmp41 = tmp43.Invoke_O_O__O(tmp44, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_180, rd__9)) } else {
//line :126:1
					var tmp45 any; var root_970 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_972 lang.IFn


					if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = d__6; if linked_971 == nil { tmp45 = ifn_972.Invoke_O__O(arg_973) } else { tmp45 = linked_971.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_970, arg_973) }
//line :126:1
					if jrt.J2g_Truth(tmp45) {


						var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp47 any = A_arbace_j2g_dyncf_A_const_181; tmp41 = tmp46.Invoke_O_O_O_O__O(tmp47, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_184, rd__9), A_arbace_j2g_dyncf_A_const_188, A_arbace_j2g_dyncf_A_const_189) } else {
//line :126:1
							if A_arbace_j2g_dyncf_A_const_28 != nil {



								tmp41 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_185, rd__9) } else {
//line :126:1
									tmp41 = nil } } }
//line :121:1
			tmp19 = tmp20.Invoke_O_O_O__O(tmp21, tmp28, tmp29.Invoke_O_O_O_O__O(tmp30, tmp32, tmp40, tmp41))
//line :109:1
			arg_935 = lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19); var arg_936 any; var tmp48 lang.IFn = lang.IFn_Cast(t.F_iter__292000079); var tmp49 any; var root_990 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = s__292000080__3; if linked_991 == nil { tmp49 = ifn_992.Invoke_O__O(arg_993) } else { tmp49 = linked_991.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_990, arg_993) }; arg_936 = tmp48.Invoke_O__O(tmp49); if linked_933 == nil { return ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { return linked_933.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_932, arg_935, arg_936) } } else { var tmp50 any; var root_1010 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = s__292000080__3; if linked_1011 == nil { tmp50 = ifn_1012.Invoke_O__O(arg_1013) } else { tmp50 = linked_1011.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1010, arg_1013) }; s__292000080__1 = tmp50; continue L1 } } else { var tmp51 any; var root_1014 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = s__292000080__3; if linked_1015 == nil { tmp51 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp51 = linked_1015.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1014, arg_1017) }; s__292000080__1 = tmp51; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_New_O_O_I_O_O_O(p0, p1 any, p2 int32, p3, p4, p5 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A{}; t.Ctor_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A) Ctor_O_O_I_O_O_O(c__recv, c__seen any, c__size__1927001038__auto__ int32, c__b__292000082, c__c__1927001037__auto__, c__c any) { t.F_recv = c__recv; t.F_seen = c__seen; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__292000082 = c__b__292000082; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A) Invoke_O__O(self any) any { { var i__292000081__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000081__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000081__1)); var tmp2 any; var root_794 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_796 lang.IFn


	if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = f__2; if linked_795 == nil { tmp2 = ifn_796.Invoke_O__O(arg_797) } else { tmp2 = linked_795.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_794, arg_797) }
//line :109:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_798 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_800 lang.IFn



		if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var tmp4 any; var root_802 any = A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = t.F_seen; if linked_803 == nil { tmp4 = ifn_804.Invoke_O__O(arg_805) } else { tmp4 = linked_803.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_802, arg_805) }; arg_801 = lang.IFn_Cast(tmp4).Invoke_O__O(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2)); if linked_799 == nil { tmp3 = ifn_800.Invoke_O__O(arg_801) } else { tmp3 = linked_799.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_798, arg_801) }
//line :109:1
		if jrt.J2g_Truth(tmp3) { var ___3 any; var root_806 any = A_arbace_j2g_dyncf_A_const_154.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_808 lang.IFn; _ = ___3




			if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = t.F_seen; var arg_810 any = A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(); var arg_811 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); if linked_807 == nil { ___3 = ifn_808.Invoke_O_O_O__O(arg_809, arg_810, arg_811) } else { ___3 = linked_807.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_806, arg_809, arg_810, arg_811) }
//line :109:1
			var d__4 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); var place__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp6 any; var root_812 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_814 lang.IFn






			if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp8 any; var root_816 any = A_arbace_j2g_dyncf_A_const_155.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); if linked_817 == nil { tmp8 = ifn_818.Invoke_O__O(arg_819) } else { tmp8 = linked_817.(*aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A).Invoke_O_O__O(root_816, arg_819) }; arg_815 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(); if linked_813 == nil { tmp6 = ifn_814.Invoke_O__O(arg_815) } else { tmp6 = linked_813.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_812, arg_815) }; var tmp9 any = tmp6; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any; var root_820 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_822 lang.IFn
			if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp13 any; var root_824 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = t.F_c; if linked_825 == nil { tmp13 = ifn_826.Invoke_O__O(arg_827) } else { tmp13 = linked_825.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_824, arg_827) }; arg_823 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13)).Ref(); if linked_821 == nil { tmp11 = ifn_822.Invoke_O__O(arg_823) } else { tmp11 = linked_821.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_820, arg_823) }
//line :116:1
			place__5 = tmp5.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O__O(tmp11, A_arbace_j2g_dyncf_A_const_156))
//line :109:1
			var root_828 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = t.F_b__292000082; var arg_832 any; var tmp14 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp15 any; var vol__6 any; var root_833 any = A_arbace_j2g_dyncf_A_const_157.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_field_QMARK__A_fn_class); var ifn_835 lang.IFn









			if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = f__2; if linked_834 == nil { vol__6 = ifn_835.Invoke_O__O(arg_836) } else { vol__6 = linked_834.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_field_QMARK__A).Invoke_O_O__O(root_833, arg_836) }
//line :109:1
			var rd__7 any










			if jrt.J2g_Truth(vol__6) { var root_837 any = A_arbace_j2g_dyncf_A_const_158.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_read_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = place__5; var arg_841 any = d__4; if linked_838 == nil { rd__7 = ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { rd__7 = linked_838.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_read_A).Invoke_O_O_O__O(root_837, arg_840, arg_841) } } else { rd__7 = place__5 }
			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyncf_A_const_159; var tmp18 any; var root_842 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var tmp19 any; var root_847 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = A_arbace_j2g_dyncf_A_const_160; var arg_851 any = A_arbace_j2g_dyncf_A_const_161; if linked_848 == nil { tmp19 = ifn_849.Invoke_O_O__O(arg_850, arg_851) } else { tmp19 = linked_848.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_847, arg_850, arg_851) }; var tmp20 any = tmp19; var tmp21 any; var root_852 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = A_arbace_j2g_dyncf_A_const_162; var arg_856 any = A_arbace_j2g_dyncf_A_const_163; if linked_853 == nil { tmp21 = ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { tmp21 = linked_853.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }; var tmp22 any = tmp21; var tmp23 any; var root_857 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = A_arbace_j2g_dyncf_A_const_164; var arg_861 any = A_arbace_j2g_dyncf_A_const_165; if linked_858 == nil { tmp23 = ifn_859.Invoke_O_O__O(arg_860, arg_861) } else { tmp23 = linked_858.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_857, arg_860, arg_861) }; arg_845 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp20, tmp22, tmp23); var arg_846 any = A_arbace_j2g_dyncf_A_const_166; if linked_843 == nil { tmp18 = ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { tmp18 = linked_843.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_842, arg_845, arg_846) }; var tmp24 any = tmp18; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyncf_A_const_167; var tmp27 any = A_arbace_j2g_dyncf_A_const_169; var tmp28 any = lang.Tuple_Create_O_O__IPersistentVector(tmp27, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_170, t.F_recv, A_arbace_j2g_dyncf_A_const_171)); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_dyncf_A_const_172; var tmp31 any = A_arbace_j2g_dyncf_A_const_173; var tmp32 any


			if jrt.J2g_Truth(vol__6) { var root_870 any = A_arbace_j2g_dyncf_A_const_174.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_write_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = place__5; var arg_874 any = d__4; var arg_875 any; var root_876 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = d__4; var arg_880 any = A_arbace_j2g_dyncf_A_const_175; if linked_877 == nil { arg_875 = ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { arg_875 = linked_877.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_876, arg_879, arg_880) }; if linked_871 == nil { tmp32 = ifn_872.Invoke_O_O_O__O(arg_873, arg_874, arg_875) } else { tmp32 = linked_871.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_write_A).Invoke_O_O_O_O__O(root_870, arg_873, arg_874, arg_875) } } else { var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp34 any = A_arbace_j2g_dyncf_A_const_177; var tmp35 any; var root_881 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = d__4; var arg_885 any = A_arbace_j2g_dyncf_A_const_178; if linked_882 == nil { tmp35 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { tmp35 = linked_882.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }; tmp32 = tmp33.Invoke_O_O_O__O(tmp34, place__5, tmp35) }
//line :121:1
			var tmp36 any = tmp29.Invoke_O_O_O_O__O(tmp30, tmp31, tmp32, A_arbace_j2g_dyncf_A_const_176); var tmp37 any; var tmp38 any; var root_862 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_864 lang.IFn





			if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = d__4; if linked_863 == nil { tmp38 = ifn_864.Invoke_O__O(arg_865) } else { tmp38 = linked_863.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_862, arg_865) }
//line :126:1
			if jrt.J2g_Truth(tmp38) {
				var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_dyncf_A_const_179; tmp37 = tmp39.Invoke_O_O__O(tmp40, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_180, rd__7)) } else {
//line :126:1
					var tmp41 any; var root_866 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_868 lang.IFn


					if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = d__4; if linked_867 == nil { tmp41 = ifn_868.Invoke_O__O(arg_869) } else { tmp41 = linked_867.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_866, arg_869) }
//line :126:1
					if jrt.J2g_Truth(tmp41) {


						var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp43 any = A_arbace_j2g_dyncf_A_const_181; tmp37 = tmp42.Invoke_O_O_O_O__O(tmp43, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_184, rd__7), A_arbace_j2g_dyncf_A_const_182, A_arbace_j2g_dyncf_A_const_183) } else {
//line :126:1
							if A_arbace_j2g_dyncf_A_const_28 != nil {



								tmp37 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_185, rd__7) } else {
//line :126:1
									tmp37 = nil } } }
//line :121:1
			tmp15 = tmp16.Invoke_O_O_O__O(tmp17, tmp24, tmp25.Invoke_O_O_O_O__O(tmp26, tmp28, tmp36, tmp37))
//line :109:1
			arg_832 = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); if linked_829 == nil { ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { linked_829.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) }; i__292000081__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000081__1); continue L1 } else { i__292000081__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000081__1); continue L1 } } else { i__292000081__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000081__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_j2g_dyncf_serial_init_body_A_New() *A_arbace_j2g_dyncf_serial_init_body_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_serial_init_body_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_dyncf_serial_init_body_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_dyncf_serial_init_body_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any; var root_1060 any = A_arbace_j2g_dyncf_A_const_193.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_j2g_model.A_arbace_j2g_model_serialization_QMARK__A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; if linked_1061 == nil { and__1927000168__auto____2 = ifn_1062.Invoke__O() } else { and__1927000168__auto____2 = linked_1061.(*aot_arbace_j2g_model.A_arbace_j2g_model_serialization_QMARK__A).Invoke_O__O(root_1060) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1063 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any; var root_1067 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = n__0; if linked_1068 == nil { arg_1066 = ifn_1069.Invoke_O__O(arg_1070) } else { arg_1066 = linked_1068.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1067, arg_1070) }; if linked_1064 == nil { and__1927000168__auto____3 = ifn_1065.Invoke_O__O(arg_1066) } else { and__1927000168__auto____3 = linked_1064.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1063, arg_1066) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1071 any = A_arbace_j2g_dyncf_A_const_194.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_j2g_model.A_arbace_j2g_model_foreign_super_accessible_QMARK__A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = n__0; if linked_1072 == nil { tmp1 = ifn_1073.Invoke_O__O(arg_1074) } else { tmp1 = linked_1072.(*aot_arbace_j2g_model.A_arbace_j2g_model_foreign_super_accessible_QMARK__A).Invoke_O_O__O(root_1071, arg_1074) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var g__2 any; var root_1075 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1077 lang.IFn
		if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = n__0; if linked_1076 == nil { g__2 = ifn_1077.Invoke_O__O(arg_1078) } else { g__2 = linked_1076.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1075, arg_1078) }
//line :136:1
		var recv__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_208; var tmp4 any; var root_1142 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1144 lang.IFn

		if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = g__2; if linked_1143 == nil { tmp4 = ifn_1144.Invoke_O__O(arg_1145) } else { tmp4 = linked_1143.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1142, arg_1145) }; recv__3 = tmp2.Invoke_O_O__O(tmp3, tmp4)
//line :136:1
		var on_t__4 any; var fnbody__1105 any = A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A_New_O(recv__3); var tmp5 *jrt.Class
		var fncls__1104 /*line :136:1*/*jrt.Class = A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A_fn_class


		if fncls__1104 == nil { var fncls__1104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__1105); A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A_fn_class = fncls__1104d; tmp5 = fncls__1104d } else { tmp5 = fncls__1104 }; on_t__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1105, tmp5, nil)



		var tmp6 any; var root_1106 any = A_arbace_j2g_dyncf_A_const_201.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, aot_arbace_j2g_model.A_arbace_j2g_model_serializable_QMARK__A_fn_class); var ifn_1108 lang.IFn; if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = n__0; if linked_1107 == nil { tmp6 = ifn_1108.Invoke_O__O(arg_1109) } else { tmp6 = linked_1107.(*aot_arbace_j2g_model.A_arbace_j2g_model_serializable_QMARK__A).Invoke_O_O__O(root_1106, arg_1109) }; if jrt.J2g_Truth(tmp6) { var temp__1927000414__auto____5 any; var root_1110 any = A_arbace_j2g_dyncf_A_const_202.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, aot_arbace_j2g_model.A_arbace_j2g_model_serial_chain_super_A_fn_class); var ifn_1112 lang.IFn
			if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = n__0; if linked_1111 == nil { temp__1927000414__auto____5 = ifn_1112.Invoke_O__O(arg_1113) } else { temp__1927000414__auto____5 = linked_1111.(*aot_arbace_j2g_model.A_arbace_j2g_model_serial_chain_super_A).Invoke_O_O__O(root_1110, arg_1113) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var vec__292000097__6 any = temp__1927000414__auto____5; var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000097__6, lang.RT_IntCast_J__I_NoInit(0), nil); var k__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000097__6, lang.RT_IntCast_J__I_NoInit(1), nil)
				if jrt.J2g_Truth(s__7) { return lang.IFn_Cast(on_t__4).Invoke_O_O__O(s__7, k__8) } else { return A_arbace_j2g_dyncf_A_const_203 } } else {
//line :144:1
					return nil } } else {
//line :143:1
						var pp__5 int64 = lang.Numbers_Or_J_J__J_NoInit(1, 4); var k__6 any; var root_1114 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1116 lang.IFn




						if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any; var root_1118 any = A_arbace_j2g_dyncf_A_const_204.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any; var fnbody__1124 any = A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A_New(); var tmp7 *jrt.Class; var fncls__1123 *jrt.Class = A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A_fn_class; if fncls__1123 == nil { var fncls__1123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, nil); A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A_fn_class = fncls__1123d; tmp7 = fncls__1123d } else { tmp7 = fncls__1123 }; arg_1121 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1124, tmp7, nil); var arg_1122 any; var tmp8 *lang.Keyword = A_arbace_j2g_dyncf_A_const_108; var tmp9 any; var root_1125 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = n__0; if linked_1126 == nil { tmp9 = ifn_1127.Invoke_O__O(arg_1128) } else { tmp9 = linked_1126.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1125, arg_1128) }; arg_1122 = tmp8.Invoke_O__O(tmp9); if linked_1119 == nil { arg_1117 = ifn_1120.Invoke_O_O__O(arg_1121, arg_1122) } else { arg_1117 = linked_1119.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1118, arg_1121, arg_1122) }; if linked_1115 == nil { k__6 = ifn_1116.Invoke_O__O(arg_1117) } else { k__6 = linked_1115.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1114, arg_1117) }
						var tmp10 any; var and__1927000168__auto____7 any = k__6; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 bool; var tmp11 int64; var na_1129 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(k__6); if jrt.J2g_Truth(or__1927000174__auto____8) { na_1129 = or__1927000174__auto____8 } else { na_1129 = A_arbace_j2g_dyncf_A_const_206 }; var na_1130 int64 = pp__5; if jrt.Long_InstanceOf(na_1129) { var n0_1131 int64 = jrt.NN(jrt.Long_Cast(na_1129)).LongValue__J(); var n1_1132 int64 = na_1130; tmp11 = n0_1131 & n1_1132 } else { tmp11 = lang.Numbers_And_O_J__J_NoInit(na_1129, na_1130) }; and__1927000168__auto____8 = lang.Numbers_IsPos_J__Z_NoInit(tmp11); if and__1927000168__auto____8 { var root_1134 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any; var tmp12 *lang.Keyword = A_arbace_j2g_dyncf_A_const_207; var tmp13 any; var root_1138 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = n__0; if linked_1139 == nil { tmp13 = ifn_1140.Invoke_O__O(arg_1141) } else { tmp13 = linked_1139.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1138, arg_1141) }; arg_1137 = tmp12.Invoke_O__O(tmp13); if linked_1135 == nil { tmp10 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp10 = linked_1135.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1134, arg_1137) } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp10 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp10) {
							return lang.IFn_Cast(on_t__4).Invoke_O_O__O(n__0, k__6) } else {
//line :149:1
								return nil } } } else {
//line :136:1
									return nil
								}
}
func A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A_New_O(p0 any) *A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A{}; t.Ctor_O(p0); return t }
//line :139:1
func (t *A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A) Ctor_O(c__recv any) { t.F_recv = c__recv }
//line :139:1
func (t *A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A) Invoke_O_O_O__O(self, s__1, k__2 any) any { var real__3 any; var tmp1 any; var root_1079 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1081 lang.IFn; if
														linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = s__1; if linked_1080 == nil { tmp1 = ifn_1081.Invoke_O__O(arg_1082) } else { tmp1 = linked_1080.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1079, arg_1082) }; if jrt.J2g_Truth(tmp1) { var root_1083 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = s__1; var arg_1087 any = k__2; if linked_1084 == nil { real__3 = ifn_1085.Invoke_O_O__O(arg_1086, arg_1087) } else { real__3 = linked_1084.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1083, arg_1086, arg_1087) } } else { real__3 = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(k__2) }; var tmp2 lang.IFn = /*line :139:1*/lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_195; var tmp4 any = A_arbace_j2g_dyncf_A_const_196; var tmp5 any = lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_197, t.F_recv, A_arbace_j2g_dyncf_A_const_198)); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any; var root_1088 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1090 lang.IFn; if


	linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil); var tmp9 any; var root_1092 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = real__3; if linked_1093 == nil { tmp9 = ifn_1094.Invoke_O__O(arg_1095) } else { tmp9 = linked_1093.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1092, arg_1095) }; arg_1091 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9)).Ref(); if linked_1089 == nil { tmp7 = ifn_1090.Invoke_O__O(arg_1091) } else { tmp7 = linked_1089.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1088, arg_1091) }; var tmp10 any = tmp7; var tmp11 lang.IFn = /*line :139:1*/lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp12 any; var root_1096 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1098 lang.IFn; if


	linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp14 any; var root_1100 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = s__1; if linked_1101 == nil { tmp14 = ifn_1102.Invoke_O__O(arg_1103) } else { tmp14 = linked_1101.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1100, arg_1103) }; arg_1099 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1097 == nil { tmp12 = ifn_1098.Invoke_O__O(arg_1099) } else { tmp12 = linked_1097.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1096, arg_1099) }; return /*line :139:1*/ lang.Tuple_Create_O__IPersistentVector(tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O__O(tmp10, tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyncf_A_const_200), A_arbace_j2g_dyncf_A_const_199))) }








func A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A_New() *A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A) Ctor() {}
//line :148:1
func (t *A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A) Invoke_O_O__O(self, p1__292000094_SHARP___1 any) any { var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(p1__292000094_SHARP___1)); if and__1927000168__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_137, A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(p1__292000094_SHARP___1))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_dyncf_subs_forms_A_New() *A_arbace_j2g_dyncf_subs_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Ctor() {}
//line :152:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Invoke_O_O__O(self, T__0_ any) any { var cs__2 any; var root_1146 any = A_arbace_j2g_dyncf_A_const_209.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_1148 lang.IFn; if


	linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = T__0_; if linked_1147 == nil { cs__2 = ifn_1148.Invoke_O__O(arg_1149) } else { cs__2 = linked_1147.(*aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_1146, arg_1149) }; var root_1150 any =
	A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_210.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_211.GetRawRoot__O(), cs__2); var arg_1154 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_212; var tmp3 any = A_arbace_j2g_dyncf_A_const_213; var tmp4 any; var root_1273 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1275 lang.IFn; if




	linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = A_arbace_j2g_dyncf_A_const_221; var arg_1277 any = A_arbace_j2g_dyncf_A_const_222; if linked_1274 == nil { tmp4 = ifn_1275.Invoke_O_O__O(arg_1276, arg_1277) } else { tmp4 = linked_1274.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1273, arg_1276, arg_1277) }; var tmp5 any = /*line :156:1*/lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 any = A_arbace_j2g_dyncf_A_const_214; var tmp7 any = A_arbace_j2g_dyncf_A_const_215; var tmp8 any; var root_1160 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1162 lang.IFn; if







	linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_1164 any = A_arbace_j2g_dyncf_A_const_216; var arg_1165 any = A_arbace_j2g_dyncf_A_const_217; var arg_1166 any; var iter__1927001039__auto____3 any; var fnbody__1272 any = A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A_New(); var tmp9 *jrt.Class; var fncls__1271 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A_fn_class; if
	fncls__1271 == nil { var fncls__1271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, nil); A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A_fn_class = fncls__1271d; tmp9 = fncls__1271d } else { tmp9 = fncls__1271 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1272, tmp9, nil); arg_1166 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(cs__2); if /*line :164:1*/ linked_1161 == nil { tmp8 = ifn_1162.Invoke_O_O_O_O__O(arg_1163, arg_1164, arg_1165, arg_1166) } else { tmp8 = linked_1161.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1160, arg_1163, arg_1164, arg_1165, arg_1166) }; var tmp10 any = /*line :156:1*/tmp1.Invoke_O_O_O_O_O_O_O_O__O(tmp2, tmp3, Lit_164, tmp5, tmp6, tmp7, tmp8, A_arbace_j2g_dyncf_A_const_220); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyncf_A_const_223; var tmp13 any = A_arbace_j2g_dyncf_A_const_224; var tmp14 any; var root_1278 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1280 lang.IFn; if





















	linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any; var tmp15 any; var root_1283 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = A_arbace_j2g_dyncf_A_const_225; var arg_1287 any = A_arbace_j2g_dyncf_A_const_226; if linked_1284 == nil { tmp15 = ifn_1285.Invoke_O_O__O(arg_1286, arg_1287) } else { tmp15 = linked_1284.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1283, arg_1286, arg_1287) }; arg_1281 = lang.Tuple_Create_O__IPersistentVector(tmp15); var arg_1282 any = A_arbace_j2g_dyncf_A_const_227; if linked_1279 == nil { tmp14 = ifn_1280.Invoke_O_O__O(arg_1281, arg_1282) } else { tmp14 = linked_1279.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1278, arg_1281, arg_1282) }; var tmp16 any = tmp14; var tmp17 any; var root_1288 any = /*line :156:1*/A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1290 lang.IFn; if






















	linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_1292 any = A_arbace_j2g_dyncf_A_const_228; var arg_1293 any = A_arbace_j2g_dyncf_A_const_229; var arg_1294 any; var iter__1927001039__auto____3_2 any; var fnbody__1410 any = A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A_New(); var tmp18 *jrt.Class; var fncls__1409 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A_fn_class; if
	fncls__1409 == nil { var fncls__1409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_167, false, nil); A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A_fn_class = fncls__1409d; tmp18 = fncls__1409d } else { tmp18 = fncls__1409 }; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1410, tmp18, nil); arg_1294 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(cs__2); if /*line :179:1*/ linked_1289 == nil { tmp17 = ifn_1290.Invoke_O_O_O_O__O(arg_1291, arg_1292, arg_1293, arg_1294) } else { tmp17 = linked_1289.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1288, arg_1291, arg_1292, arg_1293, arg_1294) }; var tmp19 any = /*line :156:1*/tmp11.Invoke_O_O_O_O_O_O__O(tmp12, tmp13, Lit_166, tmp16, tmp17, A_arbace_j2g_dyncf_A_const_237); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyncf_A_const_238; var tmp22 any = A_arbace_j2g_dyncf_A_const_239; var tmp23 any; var root_1411 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1413 lang.IFn; if

































	linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any; var tmp24 any; var root_1416 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = A_arbace_j2g_dyncf_A_const_240; var arg_1420 any = A_arbace_j2g_dyncf_A_const_241; if linked_1417 == nil { tmp24 = ifn_1418.Invoke_O_O__O(arg_1419, arg_1420) } else { tmp24 = linked_1417.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1416, arg_1419, arg_1420) }; arg_1414 = lang.Tuple_Create_O__IPersistentVector(tmp24); var arg_1415 any = A_arbace_j2g_dyncf_A_const_242; if linked_1412 == nil { tmp23 = ifn_1413.Invoke_O_O__O(arg_1414, arg_1415) } else { tmp23 = linked_1412.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1411, arg_1414, arg_1415) }; var tmp25 any = tmp23; var tmp26 any; var root_1421 any = /*line :156:1*/A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1423 lang.IFn; if


































	linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_1425 any = A_arbace_j2g_dyncf_A_const_243; var arg_1426 any = A_arbace_j2g_dyncf_A_const_244; var arg_1427 any; var iter__1927001039__auto____3_3 any; var fnbody__1517 any = A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A_New(); var tmp27 *jrt.Class; var fncls__1516 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A_fn_class; if
	fncls__1516 == nil { var fncls__1516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_169, false, nil); A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A_fn_class = fncls__1516d; tmp27 = fncls__1516d } else { tmp27 = fncls__1516 }; iter__1927001039__auto____3_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1517, tmp27, nil); arg_1427 = lang.IFn_Cast(iter__1927001039__auto____3_3).Invoke_O__O(cs__2); if /*line :191:1*/ linked_1422 == nil { tmp26 = ifn_1423.Invoke_O_O_O_O__O(arg_1424, arg_1425, arg_1426, arg_1427) } else { tmp26 = linked_1422.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1421, arg_1424, arg_1425, arg_1426, arg_1427) }; arg_1154 = /*line :156:1*/lang.Tuple_Create_O_O_O__IPersistentVector(tmp10, tmp19, tmp20.Invoke_O_O_O_O_O_O__O(tmp21, tmp22, Lit_168, tmp25, tmp26, A_arbace_j2g_dyncf_A_const_247)); if linked_1151 == nil { return ifn_1152.Invoke_O_O__O(arg_1153, arg_1154) } else { return linked_1151.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1150, arg_1153, arg_1154) } }








func A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A_New() *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A) Ctor() {}
//line :165:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A) Invoke_O_O__O(self, s__292000104__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1270 any = A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A_New_O_O(self, s__292000104__1); var tmp2 *jrt.Class; var fncls__1269 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A_fn_class; if fncls__1269 == nil { var fncls__1269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, fnbody__1270); A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A_fn_class = fncls__1269d; tmp2 = fncls__1269d } else { tmp2 = fncls__1269 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1270, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :165:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A{}; t.Ctor_O_O(p0, p1); return t }
//line :165:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A) Ctor_O_O(c__iter__292000103, c__s__292000104 any) { t.F_iter__292000103 = c__iter__292000103; t.F_s__292000104 = c__s__292000104 }
//line :165:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A) Invoke_O__O(self any) any { { var s__292000104__1 any; var t_ any = t.F_s__292000104; t.F_s__292000104 = nil; s__292000104__1 = t_; for { var temp__1927000414__auto____2 any; var root_1167 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = s__292000104__1; if linked_1168 == nil { temp__1927000414__auto____2 = ifn_1169.Invoke_O__O(arg_1170) } else { temp__1927000414__auto____2 = linked_1168.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1167, arg_1170) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1171 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = s__292000104__3; if linked_1172 == nil { tmp1 = ifn_1173.Invoke_O__O(arg_1174) } else { tmp1 = linked_1172.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1171, arg_1174) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1175 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = s__292000104__3; if linked_1176 == nil { c__1927001037__auto____4 = ifn_1177.Invoke_O__O(arg_1178) } else { c__1927001037__auto____4 = linked_1176.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1175, arg_1178) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000106__6 any; var root_1179 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1180 == nil { b__292000106__6 = ifn_1181.Invoke_O__O(arg_1182) } else { b__292000106__6 = linked_1180.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1179, arg_1182) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1211 any = A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A_New_O_I_O(b__292000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1210 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class; if fncls__1210 == nil { var fncls__1210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, fnbody__1211); A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class = fncls__1210d; tmp3 = fncls__1210d } else { tmp3 = fncls__1210 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1211, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1212 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any; var root_1217 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = b__292000106__6; if linked_1218 == nil { arg_1215 = ifn_1219.Invoke_O__O(arg_1220) } else { arg_1215 = linked_1218.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1217, arg_1220) }; var arg_1216 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000103); var tmp5 any; var root_1221 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = s__292000104__3; if linked_1222 == nil { tmp5 = ifn_1223.Invoke_O__O(arg_1224) } else { tmp5 = linked_1222.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1221, arg_1224) }; arg_1216 = tmp4.Invoke_O__O(tmp5); if linked_1213 == nil { return ifn_1214.Invoke_O_O__O(arg_1215, arg_1216) } else { return linked_1213.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1212, arg_1215, arg_1216) } } else { var root_1225 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any; var root_1230 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = b__292000106__6; if linked_1231 == nil { arg_1228 = ifn_1232.Invoke_O__O(arg_1233) } else { arg_1228 = linked_1231.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1230, arg_1233) }; var arg_1229 any; if linked_1226 == nil { return ifn_1227.Invoke_O_O__O(arg_1228, arg_1229) } else { return linked_1226.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1225, arg_1228, arg_1229) } } } else { var p__4 any; var root_1234 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = s__292000104__3; if linked_1235 == nil { p__4 = ifn_1236.Invoke_O__O(arg_1237) } else { p__4 = linked_1235.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1234, arg_1237) }; var g__5 any; var root_1238 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = p__4; if linked_1239 == nil { g__5 = ifn_1240.Invoke_O__O(arg_1241) } else { g__5 = linked_1239.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1238, arg_1241) }; var root_1242 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_218; var tmp8 any; var root_1247 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1249 lang.IFn
														if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = A_arbace_j2g_dyncf_A_const_31; var arg_1251 any = p__4; var arg_1252 any = Lit_172; if linked_1248 == nil { tmp8 = ifn_1249.Invoke_O_O_O__O(arg_1250, arg_1251, arg_1252) } else { tmp8 = linked_1248.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1247, arg_1250, arg_1251, arg_1252) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_219; var tmp12 any; var root_1253 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1255 lang.IFn
														if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_141, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_1254 == nil { tmp12 = ifn_1255.Invoke_O__O(arg_1256) } else { tmp12 = linked_1254.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1253, arg_1256) }
//line :166:1
	var tmp13 any = tmp12; var tmp14 any; var root_1257 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1259 lang.IFn
	if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_1258 == nil { tmp14 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp14 = linked_1258.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1257, arg_1260) }
//line :166:1
	var tmp15 any = tmp14; var tmp16 any; var root_1261 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1263 lang.IFn

	if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_145, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_1262 == nil { tmp16 = ifn_1263.Invoke_O__O(arg_1264) } else { tmp16 = linked_1262.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1261, arg_1264) }
//line :166:1
	arg_1245 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp13, tmp15, tmp16))
//line :165:1
	var arg_1246 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__292000103); var tmp18 any; var root_1265 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = s__292000104__3; if linked_1266 == nil { tmp18 = ifn_1267.Invoke_O__O(arg_1268) } else { tmp18 = linked_1266.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1265, arg_1268) }; arg_1246 = tmp17.Invoke_O__O(tmp18); if linked_1243 == nil { return ifn_1244.Invoke_O_O__O(arg_1245, arg_1246) } else { return linked_1243.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1242, arg_1245, arg_1246) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :165:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :165:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A) Ctor_O_I_O(c__b__292000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000106 = c__b__292000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :165:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A) Invoke_O__O(self any) any { { var i__292000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000105__1)); var g__3 any; var root_1183 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = p__2; if linked_1184 == nil { g__3 = ifn_1185.Invoke_O__O(arg_1186) } else { g__3 = linked_1184.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1183, arg_1186) }; var root_1187 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = t.F_b__292000106; var arg_1191 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_218; var tmp4 any; var root_1192 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1194 lang.IFn
																if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = A_arbace_j2g_dyncf_A_const_31; var arg_1196 any = p__2; var arg_1197 any = Lit_172; if linked_1193 == nil { tmp4 = ifn_1194.Invoke_O_O_O__O(arg_1195, arg_1196, arg_1197) } else { tmp4 = linked_1193.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1192, arg_1195, arg_1196, arg_1197) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_219; var tmp8 any; var root_1198 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1200 lang.IFn
																if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_141, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_1199 == nil { tmp8 = ifn_1200.Invoke_O__O(arg_1201) } else { tmp8 = linked_1199.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1198, arg_1201) }
//line :166:1
	var tmp9 any = tmp8; var tmp10 any; var root_1202 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1204 lang.IFn
	if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_1203 == nil { tmp10 = ifn_1204.Invoke_O__O(arg_1205) } else { tmp10 = linked_1203.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1202, arg_1205) }
//line :166:1
	var tmp11 any = tmp10; var tmp12 any; var root_1206 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1208 lang.IFn

	if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_145, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_1207 == nil { tmp12 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp12 = linked_1207.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1206, arg_1209) }
//line :166:1
	arg_1191 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp9, tmp11, tmp12))
//line :165:1
	if linked_1188 == nil { ifn_1189.Invoke_O_O__O(arg_1190, arg_1191) } else { linked_1188.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1187, arg_1190, arg_1191) }; i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A_New() *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A) Ctor() {}
//line :180:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A) Invoke_O_O__O(self, s__292000114__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1408 any = A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A_New_O_O(self, s__292000114__1); var tmp2 *jrt.Class; var fncls__1407 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A_fn_class; if fncls__1407 == nil { var fncls__1407d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, fnbody__1408); A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A_fn_class = fncls__1407d; tmp2 = fncls__1407d } else { tmp2 = fncls__1407 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1408, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :180:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :180:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A) Ctor_O_O(c__iter__292000113, c__s__292000114 any) { t.F_iter__292000113 = c__iter__292000113; t.F_s__292000114 = c__s__292000114 }
//line :180:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A) Invoke_O__O(self any) any { { var s__292000114__1 any; var t_ any = t.F_s__292000114; t.F_s__292000114 = nil; s__292000114__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1295 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = s__292000114__1; if linked_1296 == nil { temp__1927000414__auto____2 = ifn_1297.Invoke_O__O(arg_1298) } else { temp__1927000414__auto____2 = linked_1296.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1295, arg_1298) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000114__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1299 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = s__292000114__3; if linked_1300 == nil { tmp1 = ifn_1301.Invoke_O__O(arg_1302) } else { tmp1 = linked_1300.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1299, arg_1302) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1303 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = s__292000114__3; if linked_1304 == nil { c__1927001037__auto____4 = ifn_1305.Invoke_O__O(arg_1306) } else { c__1927001037__auto____4 = linked_1304.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1303, arg_1306) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000116__6 any; var root_1307 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1308 == nil { b__292000116__6 = ifn_1309.Invoke_O__O(arg_1310) } else { b__292000116__6 = linked_1308.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1307, arg_1310) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1342 any = A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A_New_O_I_O(b__292000116__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1341 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class; if fncls__1341 == nil { var fncls__1341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, fnbody__1342); A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class = fncls__1341d; tmp3 = fncls__1341d } else { tmp3 = fncls__1341 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1342, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1343 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any; var root_1348 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = b__292000116__6; if linked_1349 == nil { arg_1346 = ifn_1350.Invoke_O__O(arg_1351) } else { arg_1346 = linked_1349.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1348, arg_1351) }; var arg_1347 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000113); var tmp5 any; var root_1352 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = s__292000114__3; if linked_1353 == nil { tmp5 = ifn_1354.Invoke_O__O(arg_1355) } else { tmp5 = linked_1353.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1352, arg_1355) }; arg_1347 = tmp4.Invoke_O__O(tmp5); if linked_1344 == nil { return ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { return linked_1344.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) } } else { var root_1356 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any; var root_1361 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = b__292000116__6; if linked_1362 == nil { arg_1359 = ifn_1363.Invoke_O__O(arg_1364) } else { arg_1359 = linked_1362.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1361, arg_1364) }; var arg_1360 any; if linked_1357 == nil { return ifn_1358.Invoke_O_O__O(arg_1359, arg_1360) } else { return linked_1357.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1356, arg_1359, arg_1360) } } } else { var p__4 any; var root_1365 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = s__292000114__3; if linked_1366 == nil { p__4 = ifn_1367.Invoke_O__O(arg_1368) } else { p__4 = linked_1366.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1365, arg_1368) }; var g__5 any; var root_1369 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1371 lang.IFn; _ = g__5
														if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = p__4; if linked_1370 == nil { g__5 = ifn_1371.Invoke_O__O(arg_1372) } else { g__5 = linked_1370.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1369, arg_1372) }
//line :180:1
	var body__6 any; var root_1373 any = A_arbace_j2g_dyncf_A_const_230.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, A_arbace_j2g_dyncf_serial_init_body_A_fn_class); var ifn_1375 lang.IFn

	if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = p__4; if linked_1374 == nil { body__6 = ifn_1375.Invoke_O__O(arg_1376) } else { body__6 = linked_1374.(*A_arbace_j2g_dyncf_serial_init_body_A).Invoke_O_O__O(root_1373, arg_1376) }
//line :180:1
	if jrt.J2g_Truth(body__6) { var root_1377 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_231; var tmp8 any; var root_1382 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1384 lang.IFn



		if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = A_arbace_j2g_dyncf_A_const_31; var arg_1386 any = p__4; var arg_1387 any = Lit_172; if linked_1383 == nil { tmp8 = ifn_1384.Invoke_O_O_O__O(arg_1385, arg_1386, arg_1387) } else { tmp8 = linked_1383.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1382, arg_1385, arg_1386, arg_1387) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_232; var tmp12 any; var root_1388 any = A_arbace_j2g_dyncf_A_const_233.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1390 lang.IFn
		if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = A_arbace_j2g_dyncf_A_const_234; var arg_1392 any; var tmp13 any; var root_1394 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = A_arbace_j2g_dyncf_A_const_235; var arg_1398 any = A_arbace_j2g_dyncf_A_const_236; if linked_1395 == nil { tmp13 = ifn_1396.Invoke_O_O__O(arg_1397, arg_1398) } else { tmp13 = linked_1395.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1394, arg_1397, arg_1398) }; arg_1392 = lang.Tuple_Create_O__IPersistentVector(tmp13); var arg_1393 any = body__6; if linked_1389 == nil { tmp12 = ifn_1390.Invoke_O_O_O__O(arg_1391, arg_1392, arg_1393) } else { tmp12 = linked_1389.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1388, arg_1391, arg_1392, arg_1393) }
//line :184:1
		arg_1380 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12))
//line :180:1
		var arg_1381 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__292000113); var tmp15 any; var root_1399 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = s__292000114__3; if linked_1400 == nil { tmp15 = ifn_1401.Invoke_O__O(arg_1402) } else { tmp15 = linked_1400.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1399, arg_1402) }; arg_1381 = tmp14.Invoke_O__O(tmp15); if linked_1378 == nil { return ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { return linked_1378.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) } } else { var tmp16 any; var root_1403 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = s__292000114__3; if linked_1404 == nil { tmp16 = ifn_1405.Invoke_O__O(arg_1406) } else { tmp16 = linked_1404.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1403, arg_1406) }; s__292000114__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :180:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A) Ctor_O_I_O(c__b__292000116 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000116 = c__b__292000116; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :180:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A) Invoke_O__O(self any) any { { var i__292000115__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000115__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000115__1)); var g__3 any; var root_1311 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1313 lang.IFn; _ = g__3
																if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = p__2; if linked_1312 == nil { g__3 = ifn_1313.Invoke_O__O(arg_1314) } else { g__3 = linked_1312.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1311, arg_1314) }
//line :180:1
	var body__4 any; var root_1315 any = A_arbace_j2g_dyncf_A_const_230.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, A_arbace_j2g_dyncf_serial_init_body_A_fn_class); var ifn_1317 lang.IFn

	if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = p__2; if linked_1316 == nil { body__4 = ifn_1317.Invoke_O__O(arg_1318) } else { body__4 = linked_1316.(*A_arbace_j2g_dyncf_serial_init_body_A).Invoke_O_O__O(root_1315, arg_1318) }
//line :180:1
	if jrt.J2g_Truth(body__4) { var root_1319 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = t.F_b__292000116; var arg_1323 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_231; var tmp4 any; var root_1324 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1326 lang.IFn



		if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = A_arbace_j2g_dyncf_A_const_31; var arg_1328 any = p__2; var arg_1329 any = Lit_172; if linked_1325 == nil { tmp4 = ifn_1326.Invoke_O_O_O__O(arg_1327, arg_1328, arg_1329) } else { tmp4 = linked_1325.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1324, arg_1327, arg_1328, arg_1329) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_232; var tmp8 any; var root_1330 any = A_arbace_j2g_dyncf_A_const_233.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1332 lang.IFn
		if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = A_arbace_j2g_dyncf_A_const_234; var arg_1334 any; var tmp9 any; var root_1336 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = A_arbace_j2g_dyncf_A_const_235; var arg_1340 any = A_arbace_j2g_dyncf_A_const_236; if linked_1337 == nil { tmp9 = ifn_1338.Invoke_O_O__O(arg_1339, arg_1340) } else { tmp9 = linked_1337.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1336, arg_1339, arg_1340) }; arg_1334 = lang.Tuple_Create_O__IPersistentVector(tmp9); var arg_1335 any = body__4; if linked_1331 == nil { tmp8 = ifn_1332.Invoke_O_O_O__O(arg_1333, arg_1334, arg_1335) } else { tmp8 = linked_1331.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1330, arg_1333, arg_1334, arg_1335) }
//line :184:1
		arg_1323 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))
//line :180:1
		if linked_1320 == nil { ifn_1321.Invoke_O_O__O(arg_1322, arg_1323) } else { linked_1320.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1319, arg_1322, arg_1323) }; i__292000115__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000115__1); continue L1 } else { i__292000115__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000115__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A_New() *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A) Invoke_O_O__O(self, s__292000124__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1515 any = A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A_New_O_O(self, s__292000124__1); var tmp2 *jrt.Class; var fncls__1514 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A_fn_class; if fncls__1514 == nil { var fncls__1514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, fnbody__1515); A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A_fn_class = fncls__1514d; tmp2 = fncls__1514d } else { tmp2 = fncls__1514 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1515, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :192:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :192:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A) Ctor_O_O(c__iter__292000123, c__s__292000124 any) { t.F_iter__292000123 = c__iter__292000123; t.F_s__292000124 = c__s__292000124 }
//line :192:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A) Invoke_O__O(self any) any { { var s__292000124__1 any; var t_ any = t.F_s__292000124; t.F_s__292000124 = nil; s__292000124__1 = t_; for { var temp__1927000414__auto____2 any; var root_1428 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = s__292000124__1; if linked_1429 == nil { temp__1927000414__auto____2 = ifn_1430.Invoke_O__O(arg_1431) } else { temp__1927000414__auto____2 = linked_1429.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1428, arg_1431) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000124__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1432 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = s__292000124__3; if linked_1433 == nil { tmp1 = ifn_1434.Invoke_O__O(arg_1435) } else { tmp1 = linked_1433.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1432, arg_1435) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1436 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = s__292000124__3; if linked_1437 == nil { c__1927001037__auto____4 = ifn_1438.Invoke_O__O(arg_1439) } else { c__1927001037__auto____4 = linked_1437.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1436, arg_1439) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000126__6 any; var root_1440 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1441 == nil { b__292000126__6 = ifn_1442.Invoke_O__O(arg_1443) } else { b__292000126__6 = linked_1441.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1440, arg_1443) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1464 any = A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A_New_O_I_O(b__292000126__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1463 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A_fn_class; if fncls__1463 == nil { var fncls__1463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, fnbody__1464); A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A_fn_class = fncls__1463d; tmp3 = fncls__1463d } else { tmp3 = fncls__1463 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1464, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1465 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any; var root_1470 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = b__292000126__6; if linked_1471 == nil { arg_1468 = ifn_1472.Invoke_O__O(arg_1473) } else { arg_1468 = linked_1471.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1470, arg_1473) }; var arg_1469 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000123); var tmp5 any; var root_1474 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = s__292000124__3; if linked_1475 == nil { tmp5 = ifn_1476.Invoke_O__O(arg_1477) } else { tmp5 = linked_1475.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1474, arg_1477) }; arg_1469 = tmp4.Invoke_O__O(tmp5); if linked_1466 == nil { return ifn_1467.Invoke_O_O__O(arg_1468, arg_1469) } else { return linked_1466.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1465, arg_1468, arg_1469) } } else { var root_1478 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any; var root_1483 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = b__292000126__6; if linked_1484 == nil { arg_1481 = ifn_1485.Invoke_O__O(arg_1486) } else { arg_1481 = linked_1484.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1483, arg_1486) }; var arg_1482 any; if linked_1479 == nil { return ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { return linked_1479.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) } } } else { var p__4 any; var root_1487 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = s__292000124__3; if linked_1488 == nil { p__4 = ifn_1489.Invoke_O__O(arg_1490) } else { p__4 = linked_1488.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1487, arg_1490) }; var g__5 any; var root_1491 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = p__4; if linked_1492 == nil { g__5 = ifn_1493.Invoke_O__O(arg_1494) } else { g__5 = linked_1492.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1491, arg_1494) }; var root_1495 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_245; var tmp8 any; var root_1500 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1502 lang.IFn
														if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = A_arbace_j2g_dyncf_A_const_31; var arg_1504 any = p__4; var arg_1505 any = Lit_172; if linked_1501 == nil { tmp8 = ifn_1502.Invoke_O_O_O__O(arg_1503, arg_1504, arg_1505) } else { tmp8 = linked_1501.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1500, arg_1503, arg_1504, arg_1505) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_246; var tmp12 any; var root_1506 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1508 lang.IFn
														if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_147, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_1507 == nil { tmp12 = ifn_1508.Invoke_O__O(arg_1509) } else { tmp12 = linked_1507.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1506, arg_1509) }
//line :193:1
	arg_1498 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12))
//line :192:1
	var arg_1499 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__292000123); var tmp14 any; var root_1510 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = s__292000124__3; if linked_1511 == nil { tmp14 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp14 = linked_1511.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1510, arg_1513) }; arg_1499 = tmp13.Invoke_O__O(tmp14); if linked_1496 == nil { return ifn_1497.Invoke_O_O__O(arg_1498, arg_1499) } else { return linked_1496.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1495, arg_1498, arg_1499) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :192:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :192:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A) Ctor_O_I_O(c__b__292000126 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000126 = c__b__292000126; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :192:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A) Invoke_O__O(self any) any { { var i__292000125__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000125__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000125__1)); var g__3 any; var root_1444 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = p__2; if linked_1445 == nil { g__3 = ifn_1446.Invoke_O__O(arg_1447) } else { g__3 = linked_1445.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1444, arg_1447) }; var root_1448 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = t.F_b__292000126; var arg_1452 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_245; var tmp4 any; var root_1453 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1455 lang.IFn
																if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = A_arbace_j2g_dyncf_A_const_31; var arg_1457 any = p__2; var arg_1458 any = Lit_172; if linked_1454 == nil { tmp4 = ifn_1455.Invoke_O_O_O__O(arg_1456, arg_1457, arg_1458) } else { tmp4 = linked_1454.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1453, arg_1456, arg_1457, arg_1458) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_246; var tmp8 any; var root_1459 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1461 lang.IFn
																if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_147, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_1460 == nil { tmp8 = ifn_1461.Invoke_O__O(arg_1462) } else { tmp8 = linked_1460.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1459, arg_1462) }
//line :193:1
	arg_1452 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))
//line :192:1
	if linked_1449 == nil { ifn_1450.Invoke_O_O__O(arg_1451, arg_1452) } else { linked_1449.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1448, arg_1451, arg_1452) }; i__292000125__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000125__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_forms_A_New() *A_arbace_j2g_dyncf_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_forms_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_j2g_dyncf_forms_A) Ctor() {}
//line :197:1
func (t *A_arbace_j2g_dyncf_forms_A) Invoke_O_O__O(self, T__0_ any) any {


	var root_1518 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any; var root_1523 any = A_arbace_j2g_dyncf_A_const_248.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, A_arbace_j2g_dyncf_subs_forms_A_fn_class); var ifn_1525 lang.IFn
	if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = T__0_; if linked_1524 == nil { arg_1521 = ifn_1525.Invoke_O__O(arg_1526) } else { arg_1521 = linked_1524.(*A_arbace_j2g_dyncf_subs_forms_A).Invoke_O_O__O(root_1523, arg_1526) }
//line :200:1
	var arg_1522 any; var tmp1 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_253, Lit_1); var tmp2 any = A_arbace_j2g_dyncf_A_const_249; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyncf_A_const_254; var tmp5 any; var root_1527 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1529 lang.IFn














	if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = Lit_2; var arg_1531 any = Lit_3; if linked_1528 == nil { tmp5 = ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { tmp5 = linked_1528.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) }
//line :200:1
	var tmp6 any = tmp5; var tmp7 any; var root_1532 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1534 lang.IFn















	if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any; var tmp8 any; var root_1537 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = A_arbace_j2g_dyncf_A_const_256; var arg_1541 any = A_arbace_j2g_dyncf_A_const_257; if linked_1538 == nil { tmp8 = ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { tmp8 = linked_1538.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) }; var tmp9 any = tmp8; var tmp10 any; var root_1542 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = A_arbace_j2g_dyncf_A_const_258; var arg_1546 any = A_arbace_j2g_dyncf_A_const_259; if linked_1543 == nil { tmp10 = ifn_1544.Invoke_O_O__O(arg_1545, arg_1546) } else { tmp10 = linked_1543.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1542, arg_1545, arg_1546) }; var tmp11 any = tmp10; var tmp12 any; var root_1547 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = A_arbace_j2g_dyncf_A_const_260; var arg_1551 any = A_arbace_j2g_dyncf_A_const_261; if linked_1548 == nil { tmp12 = ifn_1549.Invoke_O_O__O(arg_1550, arg_1551) } else { tmp12 = linked_1548.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1547, arg_1550, arg_1551) }; var tmp13 any = tmp12; var tmp14 any; var root_1552 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1554 lang.IFn
	if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = A_arbace_j2g_dyncf_A_const_262; var arg_1556 any = A_arbace_j2g_dyncf_A_const_263; if linked_1553 == nil { tmp14 = ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { tmp14 = linked_1553.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) }
//line :216:1
	var tmp15 any = tmp14; var tmp16 any; var root_1557 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1559 lang.IFn
	if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = A_arbace_j2g_dyncf_A_const_264; var arg_1561 any = A_arbace_j2g_dyncf_A_const_265; if linked_1558 == nil { tmp16 = ifn_1559.Invoke_O_O__O(arg_1560, arg_1561) } else { tmp16 = linked_1558.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1557, arg_1560, arg_1561) }
//line :216:1
	var tmp17 any = tmp16; var tmp18 any; var root_1562 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1564 lang.IFn
	if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = A_arbace_j2g_dyncf_A_const_266; var arg_1566 any = A_arbace_j2g_dyncf_A_const_267; if linked_1563 == nil { tmp18 = ifn_1564.Invoke_O_O__O(arg_1565, arg_1566) } else { tmp18 = linked_1563.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1562, arg_1565, arg_1566) }
//line :216:1
	arg_1535 = lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp9, tmp11, tmp13, tmp15, tmp17, tmp18); var arg_1536 any = A_arbace_j2g_dyncf_A_const_268; if linked_1533 == nil { tmp7 = ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { tmp7 = linked_1533.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) }
//line :200:1
	var tmp19 any = tmp3.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, A_arbace_j2g_dyncf_A_const_269); var tmp20 any = A_arbace_j2g_dyncf_A_const_250; var tmp21 any = A_arbace_j2g_dyncf_A_const_251; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_270; var tmp24 any; var root_1567 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1569 lang.IFn





















































































	if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = Lit_4; var arg_1571 any = Lit_5; if linked_1568 == nil { tmp24 = ifn_1569.Invoke_O_O__O(arg_1570, arg_1571) } else { tmp24 = linked_1568.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1567, arg_1570, arg_1571) }
//line :200:1
	var tmp25 any = tmp24; var tmp26 any; var root_1572 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1574 lang.IFn






















































































	if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any; var tmp27 any; var root_1577 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = A_arbace_j2g_dyncf_A_const_271; var arg_1581 any = A_arbace_j2g_dyncf_A_const_272; if linked_1578 == nil { tmp27 = ifn_1579.Invoke_O_O__O(arg_1580, arg_1581) } else { tmp27 = linked_1578.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1577, arg_1580, arg_1581) }; var tmp28 any = tmp27; var tmp29 any; var root_1582 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = A_arbace_j2g_dyncf_A_const_273; var arg_1586 any = A_arbace_j2g_dyncf_A_const_274; if linked_1583 == nil { tmp29 = ifn_1584.Invoke_O_O__O(arg_1585, arg_1586) } else { tmp29 = linked_1583.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1582, arg_1585, arg_1586) }; arg_1575 = lang.Tuple_Create_O_O__IPersistentVector(tmp28, tmp29); var arg_1576 any = A_arbace_j2g_dyncf_A_const_275; if linked_1573 == nil { tmp26 = ifn_1574.Invoke_O_O__O(arg_1575, arg_1576) } else { tmp26 = linked_1573.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1572, arg_1575, arg_1576) }
//line :200:1
	var tmp30 any = tmp22.Invoke_O_O_O_O__O(tmp23, tmp25, tmp26, A_arbace_j2g_dyncf_A_const_276); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_dyncf_A_const_277; var tmp33 any; var root_1587 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1589 lang.IFn





























































































	if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = Lit_6; var arg_1591 any = Lit_7; if linked_1588 == nil { tmp33 = ifn_1589.Invoke_O_O__O(arg_1590, arg_1591) } else { tmp33 = linked_1588.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1587, arg_1590, arg_1591) }
//line :200:1
	var tmp34 any = tmp33; var tmp35 any; var root_1592 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1594 lang.IFn






























































































	if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any; var tmp36 any; var root_1597 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = A_arbace_j2g_dyncf_A_const_278; var arg_1601 any = A_arbace_j2g_dyncf_A_const_279; if linked_1598 == nil { tmp36 = ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { tmp36 = linked_1598.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) }; arg_1595 = lang.Tuple_Create_O__IPersistentVector(tmp36); var arg_1596 any = A_arbace_j2g_dyncf_A_const_280; if linked_1593 == nil { tmp35 = ifn_1594.Invoke_O_O__O(arg_1595, arg_1596) } else { tmp35 = linked_1593.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1592, arg_1595, arg_1596) }
//line :200:1
	var tmp37 any = tmp31.Invoke_O_O_O_O__O(tmp32, tmp34, tmp35, A_arbace_j2g_dyncf_A_const_281); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp39 any = A_arbace_j2g_dyncf_A_const_282; var tmp40 any; var root_1602 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1604 lang.IFn

































































































	if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = Lit_8; var arg_1606 any = Lit_9; if linked_1603 == nil { tmp40 = ifn_1604.Invoke_O_O__O(arg_1605, arg_1606) } else { tmp40 = linked_1603.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1602, arg_1605, arg_1606) }
//line :200:1
	var tmp41 any = tmp40; var tmp42 any; var root_1607 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1609 lang.IFn


































































































	if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = A_arbace_j2g_dyncf_A_const_284; var arg_1611 any = A_arbace_j2g_dyncf_A_const_285; if linked_1608 == nil { tmp42 = ifn_1609.Invoke_O_O__O(arg_1610, arg_1611) } else { tmp42 = linked_1608.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1607, arg_1610, arg_1611) }
//line :200:1
	var tmp43 any = tmp42; var tmp44 any; var root_1612 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1614 lang.IFn


































































































	if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = A_arbace_j2g_dyncf_A_const_286; var arg_1616 any = A_arbace_j2g_dyncf_A_const_287; if linked_1613 == nil { tmp44 = ifn_1614.Invoke_O_O__O(arg_1615, arg_1616) } else { tmp44 = linked_1613.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1612, arg_1615, arg_1616) }
//line :200:1
	var tmp45 any = tmp44; var tmp46 any; var root_1617 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1619 lang.IFn


































































































	if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = A_arbace_j2g_dyncf_A_const_288; var arg_1621 any = A_arbace_j2g_dyncf_A_const_289; if linked_1618 == nil { tmp46 = ifn_1619.Invoke_O_O__O(arg_1620, arg_1621) } else { tmp46 = linked_1618.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1617, arg_1620, arg_1621) }
//line :200:1
	var tmp47 any = tmp46; var tmp48 any; var root_1622 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1624 lang.IFn


































































































	if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = A_arbace_j2g_dyncf_A_const_290; var arg_1626 any = A_arbace_j2g_dyncf_A_const_291; if linked_1623 == nil { tmp48 = ifn_1624.Invoke_O_O__O(arg_1625, arg_1626) } else { tmp48 = linked_1623.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1622, arg_1625, arg_1626) }
//line :200:1
	var tmp49 any = tmp38.Invoke_O_O_O_O__O(tmp39, tmp41, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp43, tmp45, tmp47, tmp48), A_arbace_j2g_dyncf_A_const_283); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp51 any = A_arbace_j2g_dyncf_A_const_292; var tmp52 any; var root_1627 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1629 lang.IFn









































































































	if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = Lit_10; var arg_1631 any = Lit_11; if linked_1628 == nil { tmp52 = ifn_1629.Invoke_O_O__O(arg_1630, arg_1631) } else { tmp52 = linked_1628.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1627, arg_1630, arg_1631) }
//line :200:1
	var tmp53 any = tmp52; var tmp54 any; var root_1632 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1634 lang.IFn










































































































	if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any; var tmp55 any; var root_1637 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = A_arbace_j2g_dyncf_A_const_293; var arg_1641 any = A_arbace_j2g_dyncf_A_const_294; if linked_1638 == nil { tmp55 = ifn_1639.Invoke_O_O__O(arg_1640, arg_1641) } else { tmp55 = linked_1638.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1637, arg_1640, arg_1641) }; var tmp56 any = tmp55; var tmp57 any; var root_1642 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = A_arbace_j2g_dyncf_A_const_295; var arg_1646 any = A_arbace_j2g_dyncf_A_const_296; if linked_1643 == nil { tmp57 = ifn_1644.Invoke_O_O__O(arg_1645, arg_1646) } else { tmp57 = linked_1643.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1642, arg_1645, arg_1646) }; var tmp58 any = tmp57; var tmp59 any; var root_1647 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = A_arbace_j2g_dyncf_A_const_297; var arg_1651 any = A_arbace_j2g_dyncf_A_const_298; if linked_1648 == nil { tmp59 = ifn_1649.Invoke_O_O__O(arg_1650, arg_1651) } else { tmp59 = linked_1648.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1647, arg_1650, arg_1651) }; var tmp60 any = tmp59; var tmp61 any; var root_1652 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = A_arbace_j2g_dyncf_A_const_299; var arg_1656 any = A_arbace_j2g_dyncf_A_const_300; if linked_1653 == nil { tmp61 = ifn_1654.Invoke_O_O__O(arg_1655, arg_1656) } else { tmp61 = linked_1653.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1652, arg_1655, arg_1656) }; arg_1635 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp56, tmp58, tmp60, tmp61); var arg_1636 any = A_arbace_j2g_dyncf_A_const_301; if linked_1633 == nil { tmp54 = ifn_1634.Invoke_O_O__O(arg_1635, arg_1636) } else { tmp54 = linked_1633.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1632, arg_1635, arg_1636) }
//line :200:1
	var tmp62 any = tmp50.Invoke_O_O_O_O__O(tmp51, tmp53, tmp54, A_arbace_j2g_dyncf_A_const_302); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyncf_A_const_303; var tmp65 any; var root_1657 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1659 lang.IFn

















































































































	if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = Lit_12; var arg_1661 any = Lit_13; if linked_1658 == nil { tmp65 = ifn_1659.Invoke_O_O__O(arg_1660, arg_1661) } else { tmp65 = linked_1658.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1657, arg_1660, arg_1661) }
//line :200:1
	var tmp66 any = tmp65; var tmp67 any; var root_1662 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1664 lang.IFn


















































































































	if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any; var tmp68 any; var root_1667 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = A_arbace_j2g_dyncf_A_const_304; var arg_1671 any = A_arbace_j2g_dyncf_A_const_305; if linked_1668 == nil { tmp68 = ifn_1669.Invoke_O_O__O(arg_1670, arg_1671) } else { tmp68 = linked_1668.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1667, arg_1670, arg_1671) }; var tmp69 any = tmp68; var tmp70 any; var root_1672 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = A_arbace_j2g_dyncf_A_const_306; var arg_1676 any = A_arbace_j2g_dyncf_A_const_307; if linked_1673 == nil { tmp70 = ifn_1674.Invoke_O_O__O(arg_1675, arg_1676) } else { tmp70 = linked_1673.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1672, arg_1675, arg_1676) }; var tmp71 any = tmp70; var tmp72 any; var root_1677 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = A_arbace_j2g_dyncf_A_const_308; var arg_1681 any = A_arbace_j2g_dyncf_A_const_309; if linked_1678 == nil { tmp72 = ifn_1679.Invoke_O_O__O(arg_1680, arg_1681) } else { tmp72 = linked_1678.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1677, arg_1680, arg_1681) }; var tmp73 any = tmp72; var tmp74 any; var root_1682 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = A_arbace_j2g_dyncf_A_const_310; var arg_1686 any = A_arbace_j2g_dyncf_A_const_311; if linked_1683 == nil { tmp74 = ifn_1684.Invoke_O_O__O(arg_1685, arg_1686) } else { tmp74 = linked_1683.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1682, arg_1685, arg_1686) }; var tmp75 any = tmp74; var tmp76 any; var root_1687 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any = A_arbace_j2g_dyncf_A_const_312; var arg_1691 any = A_arbace_j2g_dyncf_A_const_313; if linked_1688 == nil { tmp76 = ifn_1689.Invoke_O_O__O(arg_1690, arg_1691) } else { tmp76 = linked_1688.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1687, arg_1690, arg_1691) }; arg_1665 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp69, tmp71, tmp73, tmp75, tmp76); var arg_1666 any = A_arbace_j2g_dyncf_A_const_314; if linked_1663 == nil { tmp67 = ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { tmp67 = linked_1663.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) }
//line :200:1
	var tmp77 any = tmp63.Invoke_O_O_O_O__O(tmp64, tmp66, tmp67, A_arbace_j2g_dyncf_A_const_315); var tmp78 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp79 any = A_arbace_j2g_dyncf_A_const_316; var tmp80 any; var root_1692 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1694 lang.IFn


























































































































	if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = Lit_14; var arg_1696 any = Lit_15; if linked_1693 == nil { tmp80 = ifn_1694.Invoke_O_O__O(arg_1695, arg_1696) } else { tmp80 = linked_1693.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1692, arg_1695, arg_1696) }
//line :200:1
	var tmp81 any = tmp80; var tmp82 any; var root_1697 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1699 lang.IFn



























































































































	if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = A_arbace_j2g_dyncf_A_const_318; var arg_1701 any = A_arbace_j2g_dyncf_A_const_319; if linked_1698 == nil { tmp82 = ifn_1699.Invoke_O_O__O(arg_1700, arg_1701) } else { tmp82 = linked_1698.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1697, arg_1700, arg_1701) }
//line :200:1
	var tmp83 any = tmp82; var tmp84 any; var root_1702 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1704 lang.IFn



























































































































	if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any = A_arbace_j2g_dyncf_A_const_320; var arg_1706 any = A_arbace_j2g_dyncf_A_const_321; if linked_1703 == nil { tmp84 = ifn_1704.Invoke_O_O__O(arg_1705, arg_1706) } else { tmp84 = linked_1703.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1702, arg_1705, arg_1706) }
//line :200:1
	var tmp85 any = tmp78.Invoke_O_O_O_O__O(tmp79, tmp81, lang.Tuple_Create_O_O__IPersistentVector(tmp83, tmp84), A_arbace_j2g_dyncf_A_const_317); var tmp86 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp87 any = A_arbace_j2g_dyncf_A_const_322; var tmp88 any; var root_1707 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1709 lang.IFn






























































































































	if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = Lit_16; var arg_1711 any = Lit_17; if linked_1708 == nil { tmp88 = ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { tmp88 = linked_1708.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) }
//line :200:1
	var tmp89 any = tmp88; var tmp90 any; var root_1712 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1714 lang.IFn































































































































	if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = A_arbace_j2g_dyncf_A_const_324; var arg_1716 any = A_arbace_j2g_dyncf_A_const_325; if linked_1713 == nil { tmp90 = ifn_1714.Invoke_O_O__O(arg_1715, arg_1716) } else { tmp90 = linked_1713.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1712, arg_1715, arg_1716) }
//line :200:1
	var tmp91 any = tmp90; var tmp92 any; var root_1717 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1719 lang.IFn































































































































	if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = A_arbace_j2g_dyncf_A_const_326; var arg_1721 any = A_arbace_j2g_dyncf_A_const_327; if linked_1718 == nil { tmp92 = ifn_1719.Invoke_O_O__O(arg_1720, arg_1721) } else { tmp92 = linked_1718.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1717, arg_1720, arg_1721) }
//line :200:1
	var tmp93 any = tmp86.Invoke_O_O_O_O__O(tmp87, tmp89, lang.Tuple_Create_O_O__IPersistentVector(tmp91, tmp92), A_arbace_j2g_dyncf_A_const_323); var tmp94 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp95 any = A_arbace_j2g_dyncf_A_const_328; var tmp96 any; var root_1722 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1724 lang.IFn



































































































































	if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = Lit_18; var arg_1726 any = Lit_7; if linked_1723 == nil { tmp96 = ifn_1724.Invoke_O_O__O(arg_1725, arg_1726) } else { tmp96 = linked_1723.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1722, arg_1725, arg_1726) }
//line :200:1
	var tmp97 any = tmp96; var tmp98 any; var root_1727 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1729 lang.IFn




































































































































	if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any; var tmp99 any; var root_1732 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = A_arbace_j2g_dyncf_A_const_329; var arg_1736 any = A_arbace_j2g_dyncf_A_const_330; if linked_1733 == nil { tmp99 = ifn_1734.Invoke_O_O__O(arg_1735, arg_1736) } else { tmp99 = linked_1733.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1732, arg_1735, arg_1736) }; arg_1730 = lang.Tuple_Create_O__IPersistentVector(tmp99); var arg_1731 any = A_arbace_j2g_dyncf_A_const_331; if linked_1728 == nil { tmp98 = ifn_1729.Invoke_O_O__O(arg_1730, arg_1731) } else { tmp98 = linked_1728.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1727, arg_1730, arg_1731) }
//line :200:1
	var tmp100 any = tmp94.Invoke_O_O_O_O__O(tmp95, tmp97, tmp98, A_arbace_j2g_dyncf_A_const_332); var tmp101 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp102 any = A_arbace_j2g_dyncf_A_const_333; var tmp103 any; var root_1737 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1739 lang.IFn






































































































































	if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any = Lit_19; var arg_1741 any = Lit_20; if linked_1738 == nil { tmp103 = ifn_1739.Invoke_O_O__O(arg_1740, arg_1741) } else { tmp103 = linked_1738.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1737, arg_1740, arg_1741) }
//line :200:1
	var tmp104 any = tmp103; var tmp105 any; var root_1742 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1744 lang.IFn







































































































































	if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = A_arbace_j2g_dyncf_A_const_335; var arg_1746 any = A_arbace_j2g_dyncf_A_const_336; if linked_1743 == nil { tmp105 = ifn_1744.Invoke_O_O__O(arg_1745, arg_1746) } else { tmp105 = linked_1743.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1742, arg_1745, arg_1746) }
//line :200:1
	var tmp106 any = tmp105; var tmp107 any; var root_1747 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1749 lang.IFn







































































































































	if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any = A_arbace_j2g_dyncf_A_const_337; var arg_1751 any = A_arbace_j2g_dyncf_A_const_338; if linked_1748 == nil { tmp107 = ifn_1749.Invoke_O_O__O(arg_1750, arg_1751) } else { tmp107 = linked_1748.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1747, arg_1750, arg_1751) }
//line :200:1
	var tmp108 any = tmp101.Invoke_O_O_O_O__O(tmp102, tmp104, lang.Tuple_Create_O_O__IPersistentVector(tmp106, tmp107), A_arbace_j2g_dyncf_A_const_334); var tmp109 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp110 any = A_arbace_j2g_dyncf_A_const_339; var tmp111 any; var root_1752 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1754 lang.IFn













































































































































	if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = Lit_21; var arg_1756 any = Lit_22; if linked_1753 == nil { tmp111 = ifn_1754.Invoke_O_O__O(arg_1755, arg_1756) } else { tmp111 = linked_1753.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1752, arg_1755, arg_1756) }
//line :200:1
	var tmp112 any = tmp111; var tmp113 any; var root_1757 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1759 lang.IFn














































































































































	if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = A_arbace_j2g_dyncf_A_const_341; var arg_1761 any = A_arbace_j2g_dyncf_A_const_342; if linked_1758 == nil { tmp113 = ifn_1759.Invoke_O_O__O(arg_1760, arg_1761) } else { tmp113 = linked_1758.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1757, arg_1760, arg_1761) }
//line :200:1
	var tmp114 any = tmp113; var tmp115 any; var root_1762 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1764 lang.IFn














































































































































	if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = A_arbace_j2g_dyncf_A_const_343; var arg_1766 any = A_arbace_j2g_dyncf_A_const_344; if linked_1763 == nil { tmp115 = ifn_1764.Invoke_O_O__O(arg_1765, arg_1766) } else { tmp115 = linked_1763.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1762, arg_1765, arg_1766) }
//line :200:1
	var tmp116 any = tmp115; var tmp117 any; var root_1767 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1769 lang.IFn














































































































































	if linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = A_arbace_j2g_dyncf_A_const_345; var arg_1771 any = A_arbace_j2g_dyncf_A_const_346; if linked_1768 == nil { tmp117 = ifn_1769.Invoke_O_O__O(arg_1770, arg_1771) } else { tmp117 = linked_1768.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1767, arg_1770, arg_1771) }
//line :200:1
	var tmp118 any = tmp109.Invoke_O_O_O_O__O(tmp110, tmp112, lang.Tuple_Create_O_O_O__IPersistentVector(tmp114, tmp116, tmp117), A_arbace_j2g_dyncf_A_const_340); var tmp119 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp120 any = A_arbace_j2g_dyncf_A_const_347; var tmp121 any; var root_1772 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1774 lang.IFn





















































































































































	if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = Lit_23; var arg_1776 any = Lit_24; if linked_1773 == nil { tmp121 = ifn_1774.Invoke_O_O__O(arg_1775, arg_1776) } else { tmp121 = linked_1773.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1772, arg_1775, arg_1776) }
//line :200:1
	var tmp122 any = tmp121; var tmp123 any; var root_1777 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1779 lang.IFn






















































































































































	if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = A_arbace_j2g_dyncf_A_const_349; var arg_1781 any = A_arbace_j2g_dyncf_A_const_350; if linked_1778 == nil { tmp123 = ifn_1779.Invoke_O_O__O(arg_1780, arg_1781) } else { tmp123 = linked_1778.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1777, arg_1780, arg_1781) }
//line :200:1
	var tmp124 any = tmp119.Invoke_O_O_O_O__O(tmp120, tmp122, lang.Tuple_Create_O__IPersistentVector(tmp123), A_arbace_j2g_dyncf_A_const_348); var tmp125 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp126 any = A_arbace_j2g_dyncf_A_const_351; var tmp127 any; var root_1782 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1784 lang.IFn





























































































































































	if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = Lit_25; var arg_1786 any = Lit_26; if linked_1783 == nil { tmp127 = ifn_1784.Invoke_O_O__O(arg_1785, arg_1786) } else { tmp127 = linked_1783.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1782, arg_1785, arg_1786) }
//line :200:1
	var tmp128 any = tmp127; var tmp129 any; var root_1787 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1789 lang.IFn






























































































































































	if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = A_arbace_j2g_dyncf_A_const_353; var arg_1791 any = A_arbace_j2g_dyncf_A_const_354; if linked_1788 == nil { tmp129 = ifn_1789.Invoke_O_O__O(arg_1790, arg_1791) } else { tmp129 = linked_1788.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1787, arg_1790, arg_1791) }
//line :200:1
	var tmp130 any = tmp129; var tmp131 any; var root_1792 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1794 lang.IFn






























































































































































	if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = A_arbace_j2g_dyncf_A_const_355; var arg_1796 any = A_arbace_j2g_dyncf_A_const_356; if linked_1793 == nil { tmp131 = ifn_1794.Invoke_O_O__O(arg_1795, arg_1796) } else { tmp131 = linked_1793.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1792, arg_1795, arg_1796) }
//line :200:1
	var tmp132 any = tmp125.Invoke_O_O_O_O__O(tmp126, tmp128, lang.Tuple_Create_O_O__IPersistentVector(tmp130, tmp131), A_arbace_j2g_dyncf_A_const_352); var tmp133 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp134 any = A_arbace_j2g_dyncf_A_const_357; var tmp135 any; var root_1797 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1799 lang.IFn
































































































































































	if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = Lit_27; var arg_1801 any = Lit_15; if linked_1798 == nil { tmp135 = ifn_1799.Invoke_O_O__O(arg_1800, arg_1801) } else { tmp135 = linked_1798.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1797, arg_1800, arg_1801) }
//line :200:1
	var tmp136 any = tmp135; var tmp137 any; var root_1802 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1804 lang.IFn

































































































































































	if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = A_arbace_j2g_dyncf_A_const_359; var arg_1806 any = A_arbace_j2g_dyncf_A_const_360; if linked_1803 == nil { tmp137 = ifn_1804.Invoke_O_O__O(arg_1805, arg_1806) } else { tmp137 = linked_1803.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1802, arg_1805, arg_1806) }
//line :200:1
	var tmp138 any = tmp137; var tmp139 any; var root_1807 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1809 lang.IFn

































































































































































	if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = A_arbace_j2g_dyncf_A_const_361; var arg_1811 any = A_arbace_j2g_dyncf_A_const_362; if linked_1808 == nil { tmp139 = ifn_1809.Invoke_O_O__O(arg_1810, arg_1811) } else { tmp139 = linked_1808.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1807, arg_1810, arg_1811) }
//line :200:1
	var tmp140 any = tmp133.Invoke_O_O_O_O__O(tmp134, tmp136, lang.Tuple_Create_O_O__IPersistentVector(tmp138, tmp139), A_arbace_j2g_dyncf_A_const_358); var tmp141 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp142 any = A_arbace_j2g_dyncf_A_const_363; var tmp143 any; var root_1812 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1814 lang.IFn





































































































































































	if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = Lit_28; var arg_1816 any = Lit_29; if linked_1813 == nil { tmp143 = ifn_1814.Invoke_O_O__O(arg_1815, arg_1816) } else { tmp143 = linked_1813.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1812, arg_1815, arg_1816) }
//line :200:1
	var tmp144 any = tmp143; var tmp145 any; var root_1817 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1819 lang.IFn






































































































































































	if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any; var tmp146 any; var root_1822 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = A_arbace_j2g_dyncf_A_const_364; var arg_1826 any = A_arbace_j2g_dyncf_A_const_365; if linked_1823 == nil { tmp146 = ifn_1824.Invoke_O_O__O(arg_1825, arg_1826) } else { tmp146 = linked_1823.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1822, arg_1825, arg_1826) }; arg_1820 = lang.Tuple_Create_O__IPersistentVector(tmp146); var arg_1821 any = A_arbace_j2g_dyncf_A_const_366; if linked_1818 == nil { tmp145 = ifn_1819.Invoke_O_O__O(arg_1820, arg_1821) } else { tmp145 = linked_1818.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1817, arg_1820, arg_1821) }
//line :200:1
	var tmp147 any = tmp141.Invoke_O_O_O_O__O(tmp142, tmp144, tmp145, A_arbace_j2g_dyncf_A_const_367); var tmp148 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp149 any = A_arbace_j2g_dyncf_A_const_368; var tmp150 any; var root_1827 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1829 lang.IFn










































































































































































	if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any = Lit_30; var arg_1831 any = Lit_31; if linked_1828 == nil { tmp150 = ifn_1829.Invoke_O_O__O(arg_1830, arg_1831) } else { tmp150 = linked_1828.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1827, arg_1830, arg_1831) }
//line :200:1
	var tmp151 any = tmp150; var tmp152 any; var root_1832 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1834 lang.IFn











































































































































































	if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = A_arbace_j2g_dyncf_A_const_370; var arg_1836 any = A_arbace_j2g_dyncf_A_const_371; if linked_1833 == nil { tmp152 = ifn_1834.Invoke_O_O__O(arg_1835, arg_1836) } else { tmp152 = linked_1833.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1832, arg_1835, arg_1836) }
//line :200:1
	var tmp153 any = tmp152; var tmp154 any; var root_1837 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1839 lang.IFn











































































































































































	if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = A_arbace_j2g_dyncf_A_const_372; var arg_1841 any = A_arbace_j2g_dyncf_A_const_373; if linked_1838 == nil { tmp154 = ifn_1839.Invoke_O_O__O(arg_1840, arg_1841) } else { tmp154 = linked_1838.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1837, arg_1840, arg_1841) }
//line :200:1
	var tmp155 any = tmp154; var tmp156 any; var root_1842 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1844 lang.IFn











































































































































































	if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = A_arbace_j2g_dyncf_A_const_374; var arg_1846 any = A_arbace_j2g_dyncf_A_const_375; if linked_1843 == nil { tmp156 = ifn_1844.Invoke_O_O__O(arg_1845, arg_1846) } else { tmp156 = linked_1843.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1842, arg_1845, arg_1846) }
//line :200:1
	var tmp157 any = tmp156; var tmp158 any; var root_1847 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1849 lang.IFn











































































































































































	if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = A_arbace_j2g_dyncf_A_const_376; var arg_1851 any = A_arbace_j2g_dyncf_A_const_377; if linked_1848 == nil { tmp158 = ifn_1849.Invoke_O_O__O(arg_1850, arg_1851) } else { tmp158 = linked_1848.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1847, arg_1850, arg_1851) }
//line :200:1
	var tmp159 any = tmp158; var tmp160 any; var root_1852 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1854 lang.IFn












































































































































































	if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = A_arbace_j2g_dyncf_A_const_378; var arg_1856 any = A_arbace_j2g_dyncf_A_const_379; if linked_1853 == nil { tmp160 = ifn_1854.Invoke_O_O__O(arg_1855, arg_1856) } else { tmp160 = linked_1853.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1852, arg_1855, arg_1856) }
//line :200:1
	var tmp161 any = tmp160; var tmp162 any; var root_1857 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1859 lang.IFn












































































































































































	if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = A_arbace_j2g_dyncf_A_const_380; var arg_1861 any = A_arbace_j2g_dyncf_A_const_381; if linked_1858 == nil { tmp162 = ifn_1859.Invoke_O_O__O(arg_1860, arg_1861) } else { tmp162 = linked_1858.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1857, arg_1860, arg_1861) }
//line :200:1
	var tmp163 any = tmp148.Invoke_O_O_O_O__O(tmp149, tmp151, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp153, tmp155, tmp157, tmp159, tmp161, tmp162), A_arbace_j2g_dyncf_A_const_369); var tmp164 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp165 any = A_arbace_j2g_dyncf_A_const_382; var tmp166 any; var root_1862 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1864 lang.IFn






















































































































































































































	if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = Lit_32; var arg_1866 any = Lit_33; if linked_1863 == nil { tmp166 = ifn_1864.Invoke_O_O__O(arg_1865, arg_1866) } else { tmp166 = linked_1863.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1862, arg_1865, arg_1866) }
//line :200:1
	var tmp167 any = tmp166; var tmp168 any; var root_1867 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1869 lang.IFn























































































































































































































	if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = A_arbace_j2g_dyncf_A_const_384; var arg_1871 any = A_arbace_j2g_dyncf_A_const_385; if linked_1868 == nil { tmp168 = ifn_1869.Invoke_O_O__O(arg_1870, arg_1871) } else { tmp168 = linked_1868.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1867, arg_1870, arg_1871) }
//line :200:1
	var tmp169 any = tmp168; var tmp170 any; var root_1872 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1874 lang.IFn























































































































































































































	if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = A_arbace_j2g_dyncf_A_const_386; var arg_1876 any = A_arbace_j2g_dyncf_A_const_387; if linked_1873 == nil { tmp170 = ifn_1874.Invoke_O_O__O(arg_1875, arg_1876) } else { tmp170 = linked_1873.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1872, arg_1875, arg_1876) }
//line :200:1
	var tmp171 any = tmp170; var tmp172 any; var root_1877 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1879 lang.IFn























































































































































































































	if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = A_arbace_j2g_dyncf_A_const_388; var arg_1881 any = A_arbace_j2g_dyncf_A_const_389; if linked_1878 == nil { tmp172 = ifn_1879.Invoke_O_O__O(arg_1880, arg_1881) } else { tmp172 = linked_1878.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1877, arg_1880, arg_1881) }
//line :200:1
	var tmp173 any = tmp172; var tmp174 any; var root_1882 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1882, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1884 lang.IFn























































































































































































































	if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any = A_arbace_j2g_dyncf_A_const_390; var arg_1886 any = A_arbace_j2g_dyncf_A_const_391; if linked_1883 == nil { tmp174 = ifn_1884.Invoke_O_O__O(arg_1885, arg_1886) } else { tmp174 = linked_1883.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1882, arg_1885, arg_1886) }
//line :200:1
	var tmp175 any = tmp164.Invoke_O_O_O_O__O(tmp165, tmp167, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp169, tmp171, tmp173, tmp174), A_arbace_j2g_dyncf_A_const_383); var tmp176 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp177 any = A_arbace_j2g_dyncf_A_const_392; var tmp178 any; var root_1887 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1889 lang.IFn





























































































































































































































	if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = Lit_34; var arg_1891 any = Lit_35; if linked_1888 == nil { tmp178 = ifn_1889.Invoke_O_O__O(arg_1890, arg_1891) } else { tmp178 = linked_1888.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1887, arg_1890, arg_1891) }
//line :200:1
	var tmp179 any = tmp178; var tmp180 any; var root_1892 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1894 lang.IFn






























































































































































































































	if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = A_arbace_j2g_dyncf_A_const_394; var arg_1896 any = A_arbace_j2g_dyncf_A_const_395; if linked_1893 == nil { tmp180 = ifn_1894.Invoke_O_O__O(arg_1895, arg_1896) } else { tmp180 = linked_1893.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1892, arg_1895, arg_1896) }
//line :200:1
	var tmp181 any = tmp180; var tmp182 any; var root_1897 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1899 lang.IFn






























































































































































































































	if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = A_arbace_j2g_dyncf_A_const_396; var arg_1901 any = A_arbace_j2g_dyncf_A_const_397; if linked_1898 == nil { tmp182 = ifn_1899.Invoke_O_O__O(arg_1900, arg_1901) } else { tmp182 = linked_1898.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1897, arg_1900, arg_1901) }
//line :200:1
	var tmp183 any = tmp182; var tmp184 any; var root_1902 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1904 lang.IFn






























































































































































































































	if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = A_arbace_j2g_dyncf_A_const_398; var arg_1906 any = A_arbace_j2g_dyncf_A_const_399; if linked_1903 == nil { tmp184 = ifn_1904.Invoke_O_O__O(arg_1905, arg_1906) } else { tmp184 = linked_1903.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1902, arg_1905, arg_1906) }
//line :200:1
	var tmp185 any = tmp184; var tmp186 any; var root_1907 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1909 lang.IFn






























































































































































































































	if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = A_arbace_j2g_dyncf_A_const_400; var arg_1911 any = A_arbace_j2g_dyncf_A_const_401; if linked_1908 == nil { tmp186 = ifn_1909.Invoke_O_O__O(arg_1910, arg_1911) } else { tmp186 = linked_1908.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1907, arg_1910, arg_1911) }
//line :200:1
	var tmp187 any = tmp186; var tmp188 any; var root_1912 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1912, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1914 lang.IFn






























































































































































































































	if linked_1913 == nil { ifn_1914 = lang.IFn_Cast(root_1912) } else { ifn_1914 = nil }; var arg_1915 any = A_arbace_j2g_dyncf_A_const_402; var arg_1916 any = A_arbace_j2g_dyncf_A_const_403; if linked_1913 == nil { tmp188 = ifn_1914.Invoke_O_O__O(arg_1915, arg_1916) } else { tmp188 = linked_1913.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1912, arg_1915, arg_1916) }
//line :200:1
	var tmp189 any = tmp176.Invoke_O_O_O_O__O(tmp177, tmp179, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp181, tmp183, tmp185, tmp187, tmp188), A_arbace_j2g_dyncf_A_const_393); var tmp190 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp191 any = A_arbace_j2g_dyncf_A_const_404; var tmp192 any; var root_1917 any = A_arbace_j2g_dyncf_A_const_255.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1919 lang.IFn






































































































































































































































	if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = Lit_36; var arg_1921 any = Lit_37; if linked_1918 == nil { tmp192 = ifn_1919.Invoke_O_O__O(arg_1920, arg_1921) } else { tmp192 = linked_1918.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1917, arg_1920, arg_1921) }
//line :200:1
	var tmp193 any = tmp192; var tmp194 any; var root_1922 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1924 lang.IFn







































































































































































































































	if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any = A_arbace_j2g_dyncf_A_const_405; var arg_1926 any = A_arbace_j2g_dyncf_A_const_406; if linked_1923 == nil { tmp194 = ifn_1924.Invoke_O_O__O(arg_1925, arg_1926) } else { tmp194 = linked_1923.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1922, arg_1925, arg_1926) }
//line :200:1
	var tmp195 any = tmp194; var tmp196 any; var root_1927 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1929 lang.IFn







































































































































































































































	if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = A_arbace_j2g_dyncf_A_const_407; var arg_1931 any = A_arbace_j2g_dyncf_A_const_408; if linked_1928 == nil { tmp196 = ifn_1929.Invoke_O_O__O(arg_1930, arg_1931) } else { tmp196 = linked_1928.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1927, arg_1930, arg_1931) }
//line :200:1
	var tmp197 any = tmp196; var tmp198 any; var root_1932 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1934 lang.IFn







































































































































































































































	if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = A_arbace_j2g_dyncf_A_const_409; var arg_1936 any = A_arbace_j2g_dyncf_A_const_410; if linked_1933 == nil { tmp198 = ifn_1934.Invoke_O_O__O(arg_1935, arg_1936) } else { tmp198 = linked_1933.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1932, arg_1935, arg_1936) }
//line :200:1
	var tmp199 any = tmp198; var tmp200 any; var root_1937 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1939 lang.IFn







































































































































































































































	if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = A_arbace_j2g_dyncf_A_const_411; var arg_1941 any = A_arbace_j2g_dyncf_A_const_412; if linked_1938 == nil { tmp200 = ifn_1939.Invoke_O_O__O(arg_1940, arg_1941) } else { tmp200 = linked_1938.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1937, arg_1940, arg_1941) }
//line :200:1
	var tmp201 any = tmp200; var tmp202 any; var root_1942 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1944 lang.IFn








































































































































































































































	if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = A_arbace_j2g_dyncf_A_const_413; var arg_1946 any = A_arbace_j2g_dyncf_A_const_414; if linked_1943 == nil { tmp202 = ifn_1944.Invoke_O_O__O(arg_1945, arg_1946) } else { tmp202 = linked_1943.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1942, arg_1945, arg_1946) }
//line :200:1
	var tmp203 any = tmp202; var tmp204 any; var root_1947 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1949 lang.IFn








































































































































































































































	if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = A_arbace_j2g_dyncf_A_const_415; var arg_1951 any = A_arbace_j2g_dyncf_A_const_416; if linked_1948 == nil { tmp204 = ifn_1949.Invoke_O_O__O(arg_1950, arg_1951) } else { tmp204 = linked_1948.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1947, arg_1950, arg_1951) }
//line :200:1
	var tmp205 any = tmp204; var tmp206 any; var root_1952 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1954 lang.IFn








































































































































































































































	if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = A_arbace_j2g_dyncf_A_const_417; var arg_1956 any = A_arbace_j2g_dyncf_A_const_418; if linked_1953 == nil { tmp206 = ifn_1954.Invoke_O_O__O(arg_1955, arg_1956) } else { tmp206 = linked_1953.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1952, arg_1955, arg_1956) }
//line :200:1
	arg_1522 = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp19, tmp20, tmp21, tmp30, tmp37, tmp49, tmp62, tmp77, tmp85, tmp93, tmp100, tmp108, tmp118, tmp124, tmp132, tmp140, tmp147, tmp163, tmp175, tmp189, tmp190.Invoke_O_O_O_O__O(tmp191, tmp193, lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp195, tmp197, tmp199, tmp201, tmp203, tmp205, tmp206)), A_arbace_j2g_dyncf_A_const_419), A_arbace_j2g_dyncf_A_const_252)); if linked_1519 == nil { return ifn_1520.Invoke_O_O__O(arg_1521, arg_1522) } else { return linked_1519.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1518, arg_1521, arg_1522)
	}
}





























































































































































































































































func A_arbace_j2g_dyncf_strip_anns_A_New() *A_arbace_j2g_dyncf_strip_anns_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_A{}; t.Ctor(); return t }
//line :456:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Ctor() {}
//line :456:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Invoke_O_O__O(self, x__0 any) any {
	var root_1957 any = A_arbace_j2g_dyncf_A_const_420.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_walk.A_arbace_walk_postwalk_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any; var fnbody__1972 any = A_arbace_j2g_dyncf_strip_anns_fn__292000135_A_New(); var tmp1 *jrt.Class; var fncls__1971 *jrt.Class = A_arbace_j2g_dyncf_strip_anns_fn__292000135_A_fn_class; if fncls__1971 == nil { var fncls__1971d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, nil); A_arbace_j2g_dyncf_strip_anns_fn__292000135_A_fn_class = fncls__1971d; tmp1 = fncls__1971d } else { tmp1 = fncls__1971 }; arg_1960 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1972, tmp1, nil); var arg_1961 any = x__0; if linked_1958 == nil { return ifn_1959.Invoke_O_O__O(arg_1960, arg_1961) } else { return linked_1958.(*aot_arbace_walk.A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_1957, arg_1960, arg_1961) } }
//line :457:1
func A_arbace_j2g_dyncf_strip_anns_fn__292000135_A_New() *A_arbace_j2g_dyncf_strip_anns_fn__292000135_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_fn__292000135_A{}; t.Ctor(); return t }
//line :457:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000135_A) Ctor() {}
//line :457:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000135_A) Invoke_O_O__O(self, y__1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_1962 any = A_arbace_j2g_dyncf_A_const_421.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = y__1; if linked_1963 == nil { and__1927000168__auto____2 = ifn_1964.Invoke_O__O(arg_1965) } else { and__1927000168__auto____2 = linked_1963.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1962, arg_1965) }; if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = A_arbace_j2g_dyncf_A_const_422.Invoke_O__O(y__1) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_1966 any = A_arbace_j2g_dyncf_A_const_423.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = y__1; var arg_1970 any = A_arbace_j2g_dyncf_A_const_422; if linked_1967 == nil { return ifn_1968.Invoke_O_O__O(arg_1969, arg_1970) } else { return linked_1967.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1966, arg_1969, arg_1970) } } else { return y__1 } }



func A_arbace_j2g_dyncf_protected_field_QMARK__A_New() *A_arbace_j2g_dyncf_protected_field_QMARK__A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_field_QMARK__A{}; t.Ctor(); return t }
//line :461:1
func (t *A_arbace_j2g_dyncf_protected_field_QMARK__A) Ctor() {}
//line :461:1
func (t *A_arbace_j2g_dyncf_protected_field_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var fl__2 any; var or__1927000174__auto____2 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__0); if



	jrt.J2g_Truth(or__1927000174__auto____2) { fl__2 = or__1927000174__auto____2 } else { fl__2 = A_arbace_j2g_dyncf_A_const_206 }; var and__1927000168__auto____3 bool; var tmp1 int64; var na_1973 any = fl__2; var na_1974 any = /*line :461:1*/A_arbace_j2g_dyncf_A_const_424.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 =




	jrt.Long_InstanceOf(na_1973); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1974) }; tmp2 = tmp3; if tmp2 { var n0_1975 int64 = jrt.NN(jrt.Long_Cast(na_1973)).LongValue__J(); var n1_1976 int64 = jrt.NN(jrt.Long_Cast(na_1974)).LongValue__J(); tmp1 = n0_1975 & n1_1976 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_1973, na_1974) }; and__1927000168__auto____3 = lang.Numbers_IsPos_J__Z_NoInit(tmp1); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool; var tmp4 int64; var na_1978 any = fl__2; var na_1979 int64 = 9; if jrt.Long_InstanceOf(na_1978) { var n0_1980 int64 = jrt.NN(jrt.Long_Cast(na_1978)).LongValue__J(); var n1_1981 int64 = na_1979; tmp4 = n0_1980 & n1_1981 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_1978, na_1979) }; and__1927000168__auto____4 = lang.Numbers_IsZero_J__Z_NoInit(tmp4); if and__1927000168__auto____4 { var root_1983 any = A_arbace_j2g_dyncf_A_const_425.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_j2g_model.A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__0); if linked_1984 == nil { return ifn_1985.Invoke_O__O(arg_1986) } else { return linked_1984.(*aot_arbace_j2g_model.A_arbace_j2g_model_desc_in_world_QMARK__A).Invoke_O_O__O(root_1983, arg_1986) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

func A_arbace_j2g_dyncf_protected_chain_A_New() *A_arbace_j2g_dyncf_protected_chain_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_j2g_dyncf_protected_chain_A) Ctor() {}
//line :468:1
func (t *A_arbace_j2g_dyncf_protected_chain_A) Invoke_O_O__O(self, T__0_ any) any {



	var root_1987 any = A_arbace_j2g_dyncf_A_const_426.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any; var root_1991 any = A_arbace_j2g_dyncf_A_const_427.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1993 lang.IFn; if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any; var iter__1927001039__auto____2 any; var fnbody__2103 any = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A_New(); var tmp1 *jrt.Class; var fncls__2102 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A_fn_class; if fncls__2102 == nil { var fncls__2102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A_fn_class = fncls__2102d; tmp1 = fncls__2102d } else { tmp1 = fncls__2102 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2103, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_2104 any = A_arbace_j2g_dyncf_A_const_209.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any = T__0_; if linked_2105 == nil { tmp3 = ifn_2106.Invoke_O__O(arg_2107) } else { tmp3 = linked_2105.(*aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_2104, arg_2107) }; arg_1994 = tmp2.Invoke_O__O(tmp3); if linked_1992 == nil { arg_1990 = ifn_1993.Invoke_O__O(arg_1994) } else { arg_1990 = linked_1992.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1991, arg_1994) }; if linked_1988 == nil { return ifn_1989.Invoke_O__O(arg_1990) } else { return linked_1988.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1987, arg_1990) } }
//line :472:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A_New() *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A) Ctor() {}
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A) Invoke_O_O__O(self, s__292000140__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2101 any = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A_New_O_O(s__292000140__1, self); var tmp2 *jrt.Class; var fncls__2100 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A_fn_class; if fncls__2100 == nil { var fncls__2100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, fnbody__2101); A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A_fn_class = fncls__2100d; tmp2 = fncls__2100d } else { tmp2 = fncls__2100 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2101, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :472:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A{}; t.Ctor_O_O(p0, p1); return t }
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A) Ctor_O_O(c__s__292000140, c__iter__292000139 any) { t.F_s__292000140 = c__s__292000140; t.F_iter__292000139 = c__iter__292000139 }
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A) Invoke_O__O(self any) any { { var s__292000140__1 any; var t_ any = t.F_s__292000140; t.F_s__292000140 = nil; s__292000140__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1995 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1997 lang.IFn; if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = s__292000140__1; if linked_1996 == nil { temp__1927000414__auto____2 = ifn_1997.Invoke_O__O(arg_1998) } else { temp__1927000414__auto____2 = linked_1996.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1995, arg_1998) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var p__4 any; var root_1999 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2001 lang.IFn; if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = xs__1927001018__auto____3; if linked_2000 == nil { p__4 = ifn_2001.Invoke_O__O(arg_2002) } else { p__4 = linked_2000.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1999, arg_2002) }; var iterys__1927001035__auto____5 any; var fnbody__2078 any = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A_New(); var tmp1 *jrt.Class; var fncls__2077 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A_fn_class; if fncls__2077 == nil { var fncls__2077d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, nil); A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A_fn_class = fncls__2077d; tmp1 = fncls__2077d } else { tmp1 = fncls__2077 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2078, tmp1, nil); var fs__1927001036__auto____6 any; var root_2079 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_2083 any = A_arbace_j2g_dyncf_A_const_192.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_2085 lang.IFn
															if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = p__4; if linked_2084 == nil { tmp3 = ifn_2085.Invoke_O__O(arg_2086) } else { tmp3 = linked_2084.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_2083, arg_2086) }
//line :472:1
	arg_2082 = tmp2.Invoke_O__O(tmp3); if linked_2080 == nil { fs__1927001036__auto____6 = ifn_2081.Invoke_O__O(arg_2082) } else { fs__1927001036__auto____6 = linked_2080.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2079, arg_2082) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2087 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2087, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2089 lang.IFn; if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = fs__1927001036__auto____6; var arg_2091 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000139); var tmp5 any; var root_2092 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = s__292000140__1; if linked_2093 == nil { tmp5 = ifn_2094.Invoke_O__O(arg_2095) } else { tmp5 = linked_2093.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2092, arg_2095) }; arg_2091 = tmp4.Invoke_O__O(tmp5); if linked_2088 == nil { return ifn_2089.Invoke_O_O__O(arg_2090, arg_2091) } else { return linked_2088.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2087, arg_2090, arg_2091) } } else { var tmp6 any; var root_2096 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = s__292000140__1; if linked_2097 == nil { tmp6 = ifn_2098.Invoke_O__O(arg_2099) } else { tmp6 = linked_2097.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2096, arg_2099) }; s__292000140__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :472:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A_New() *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A) Ctor() {}
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A) Invoke_O_O__O(self, s__292000142__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2076 any = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A_New_O_O(self, s__292000142__1); var tmp2 *jrt.Class; var fncls__2075 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A_fn_class; if fncls__2075 == nil { var fncls__2075d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__2076); A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A_fn_class = fncls__2075d; tmp2 = fncls__2075d } else { tmp2 = fncls__2075 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2076, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :472:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A{}; t.Ctor_O_O(p0, p1); return t }
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A) Ctor_O_O(c__iter__292000141, c__s__292000142 any) { t.F_iter__292000141 = c__iter__292000141; t.F_s__292000142 = c__s__292000142 }
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A) Invoke_O__O(self any) any { { var s__292000142__1 any; var t_ any = t.F_s__292000142; t.F_s__292000142 = nil; s__292000142__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2003 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2005 lang.IFn; if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = s__292000142__1; if linked_2004 == nil { temp__1927000414__auto____2 = ifn_2005.Invoke_O__O(arg_2006) } else { temp__1927000414__auto____2 = linked_2004.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2003, arg_2006) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000142__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2007 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = s__292000142__3; if linked_2008 == nil { tmp1 = ifn_2009.Invoke_O__O(arg_2010) } else { tmp1 = linked_2008.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2007, arg_2010) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2011 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = s__292000142__3; if linked_2012 == nil { c__1927001037__auto____4 = ifn_2013.Invoke_O__O(arg_2014) } else { c__1927001037__auto____4 = linked_2012.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2011, arg_2014) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000144__6 any; var root_2015 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2017 lang.IFn; if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2016 == nil { b__292000144__6 = ifn_2017.Invoke_O__O(arg_2018) } else { b__292000144__6 = linked_2016.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2015, arg_2018) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2030 any = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A_New_O_I_O(b__292000144__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2029 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A_fn_class; if fncls__2029 == nil { var fncls__2029d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, fnbody__2030); A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A_fn_class = fncls__2029d; tmp3 = fncls__2029d } else { tmp3 = fncls__2029 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2030, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2031 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any; var root_2036 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = b__292000144__6; if linked_2037 == nil { arg_2034 = ifn_2038.Invoke_O__O(arg_2039) } else { arg_2034 = linked_2037.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2036, arg_2039) }; var arg_2035 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000141); var tmp5 any; var root_2040 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = s__292000142__3; if linked_2041 == nil { tmp5 = ifn_2042.Invoke_O__O(arg_2043) } else { tmp5 = linked_2041.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2040, arg_2043) }; arg_2035 = tmp4.Invoke_O__O(tmp5); if linked_2032 == nil { return ifn_2033.Invoke_O_O__O(arg_2034, arg_2035) } else { return linked_2032.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2031, arg_2034, arg_2035) } } else { var root_2044 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any; var root_2049 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = b__292000144__6; if linked_2050 == nil { arg_2047 = ifn_2051.Invoke_O__O(arg_2052) } else { arg_2047 = linked_2050.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2049, arg_2052) }; var arg_2048 any; if linked_2045 == nil { return ifn_2046.Invoke_O_O__O(arg_2047, arg_2048) } else { return linked_2045.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2044, arg_2047, arg_2048) } } } else { var c__4 any; var root_2053 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = s__292000142__3; if linked_2054 == nil { c__4 = ifn_2055.Invoke_O__O(arg_2056) } else { c__4 = linked_2054.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2053, arg_2056) }; var tmp6 any
																				var and__1927000168__auto____5 any = c__4
																				if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2057 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2057, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2059 lang.IFn; if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; var arg_2060 any = c__4; var arg_2061 any = Lit_110; if linked_2058 == nil { tmp6 = ifn_2059.Invoke_O_O__O(arg_2060, arg_2061) } else { tmp6 = linked_2058.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2057, arg_2060, arg_2061) } } else { tmp6 = and__1927000168__auto____5 }
//line :472:1
	if jrt.J2g_Truth(tmp6) { var root_2062 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = c__4; var arg_2066 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000141); var tmp8 any; var root_2067 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = s__292000142__3; if linked_2068 == nil { tmp8 = ifn_2069.Invoke_O__O(arg_2070) } else { tmp8 = linked_2068.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2067, arg_2070) }; arg_2066 = tmp7.Invoke_O__O(tmp8); if linked_2063 == nil { return ifn_2064.Invoke_O_O__O(arg_2065, arg_2066) } else { return linked_2063.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2062, arg_2065, arg_2066) } } else { var tmp9 any; var root_2071 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = s__292000142__3; if linked_2072 == nil { tmp9 = ifn_2073.Invoke_O__O(arg_2074) } else { tmp9 = linked_2072.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2071, arg_2074) }; s__292000142__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :472:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A) Ctor_O_I_O(c__b__292000144 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000144 = c__b__292000144; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :472:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A) Invoke_O__O(self any) any { { var i__292000143__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000143__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000143__1)); var tmp2 any
																						var and__1927000168__auto____3 any = c__2
																						if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2019 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any = c__2; var arg_2023 any = Lit_110; if linked_2020 == nil { tmp2 = ifn_2021.Invoke_O_O__O(arg_2022, arg_2023) } else { tmp2 = linked_2020.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2019, arg_2022, arg_2023) } } else { tmp2 = and__1927000168__auto____3 }
//line :472:1
	if jrt.J2g_Truth(tmp2) { var root_2024 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = t.F_b__292000144; var arg_2028 any = c__2; if linked_2025 == nil { ifn_2026.Invoke_O_O__O(arg_2027, arg_2028) } else { linked_2025.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2024, arg_2027, arg_2028) }; i__292000143__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000143__1); continue L1 } else { i__292000143__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000143__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_protected_members_A_New() *A_arbace_j2g_dyncf_protected_members_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_j2g_dyncf_protected_members_A) Ctor() {}
//line :477:1
func (t *A_arbace_j2g_dyncf_protected_members_A) Invoke_O_O__O(self, T__0_ any) any { var iter__1927001039__auto____2 any; var fnbody__2845 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A_New(); var tmp1 *jrt.Class; var fncls__2844 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A_fn_class; if




	fncls__2844 == nil { var fncls__2844d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A_fn_class = fncls__2844d; tmp1 = fncls__2844d } else { tmp1 = fncls__2844 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2845, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_2846 any = A_arbace_j2g_dyncf_A_const_433.GetRawRoot__O(); var linked_2847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2846, A_arbace_j2g_dyncf_protected_chain_A_fn_class); var ifn_2848 lang.IFn; if linked_2847 == nil { ifn_2848 = lang.IFn_Cast(root_2846) } else { ifn_2848 = nil }; var arg_2849 any = T__0_; if linked_2847 == nil { tmp3 = ifn_2848.Invoke_O__O(arg_2849) } else { tmp3 = linked_2847.(*A_arbace_j2g_dyncf_protected_chain_A).Invoke_O_O__O(root_2846, arg_2849) }; return tmp2.Invoke_O__O(tmp3) }
//line :482:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A) Ctor() {}
//line :482:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A) Invoke_O_O__O(self, s__292000157__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2843 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A_New_O_O(self, s__292000157__1); var tmp2 *jrt.Class; var fncls__2842 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A_fn_class; if fncls__2842 == nil { var fncls__2842d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, fnbody__2843); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A_fn_class = fncls__2842d; tmp2 = fncls__2842d } else { tmp2 = fncls__2842 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2843, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :482:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A{}; t.Ctor_O_O(p0, p1); return t }
//line :482:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A) Ctor_O_O(c__iter__292000156, c__s__292000157 any) { t.F_iter__292000156 = c__iter__292000156; t.F_s__292000157 = c__s__292000157 }
//line :482:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A) Invoke_O__O(self any) any { { var s__292000157__1 any; var t_ any = t.F_s__292000157; t.F_s__292000157 = nil; s__292000157__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2108 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2108, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2110 lang.IFn; if linked_2109 == nil { ifn_2110 = lang.IFn_Cast(root_2108) } else { ifn_2110 = nil }; var arg_2111 any = s__292000157__1; if linked_2109 == nil { temp__1927000414__auto____2 = ifn_2110.Invoke_O__O(arg_2111) } else { temp__1927000414__auto____2 = linked_2109.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2108, arg_2111) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000157__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2112 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = s__292000157__3; if linked_2113 == nil { tmp1 = ifn_2114.Invoke_O__O(arg_2115) } else { tmp1 = linked_2113.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2112, arg_2115) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2116 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2118 lang.IFn; if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = s__292000157__3; if linked_2117 == nil { c__1927001037__auto____4 = ifn_2118.Invoke_O__O(arg_2119) } else { c__1927001037__auto____4 = linked_2117.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2116, arg_2119) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000159__6 any; var root_2120 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2121 == nil { b__292000159__6 = ifn_2122.Invoke_O__O(arg_2123) } else { b__292000159__6 = linked_2121.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2120, arg_2123) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2466 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A_New_O_I_O(b__292000159__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2465 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class; if fncls__2465 == nil { var fncls__2465d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, fnbody__2466); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class = fncls__2465d; tmp3 = fncls__2465d } else { tmp3 = fncls__2465 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2466, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2467 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any; var root_2472 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = b__292000159__6; if linked_2473 == nil { arg_2470 = ifn_2474.Invoke_O__O(arg_2475) } else { arg_2470 = linked_2473.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2472, arg_2475) }; var arg_2471 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000156); var tmp5 any; var root_2476 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = s__292000157__3; if linked_2477 == nil { tmp5 = ifn_2478.Invoke_O__O(arg_2479) } else { tmp5 = linked_2477.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2476, arg_2479) }; arg_2471 = tmp4.Invoke_O__O(tmp5); if linked_2468 == nil { return ifn_2469.Invoke_O_O__O(arg_2470, arg_2471) } else { return linked_2468.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2467, arg_2470, arg_2471) } } else { var root_2480 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any; var root_2485 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any = b__292000159__6; if linked_2486 == nil { arg_2483 = ifn_2487.Invoke_O__O(arg_2488) } else { arg_2483 = linked_2486.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2485, arg_2488) }; var arg_2484 any; if linked_2481 == nil { return ifn_2482.Invoke_O_O__O(arg_2483, arg_2484) } else { return linked_2481.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2480, arg_2483, arg_2484) } } } else { var c__4 any; var root_2489 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2491 lang.IFn; if linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any = s__292000157__3; if linked_2490 == nil { c__4 = ifn_2491.Invoke_O__O(arg_2492) } else { c__4 = linked_2490.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2489, arg_2492) }; var prot_QMARK___5 any; var fnbody__2504 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A_New(); var tmp6 *jrt.Class; var fncls__2503 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A_fn_class
															if fncls__2503 == nil { var fncls__2503d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A_fn_class = fncls__2503d; tmp6 = fncls__2503d } else { tmp6 = fncls__2503 }; prot_QMARK___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2504, tmp6, nil)
//line :482:1
	var ms__6 any; var root_2505 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2505, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2507 lang.IFn


	if linked_2506 == nil { ifn_2507 = lang.IFn_Cast(root_2505) } else { ifn_2507 = nil }; var arg_2508 any; var iter__1927001039__auto____6 any; var fnbody__2602 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A_New_O(prot_QMARK___5); var tmp7 *jrt.Class; var fncls__2601 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A_fn_class; if fncls__2601 == nil { var fncls__2601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, fnbody__2602); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A_fn_class = fncls__2601d; tmp7 = fncls__2601d } else { tmp7 = fncls__2601 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2602, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp9 any; var root_2603 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2603, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2605 lang.IFn; if linked_2604 == nil { ifn_2605 = lang.IFn_Cast(root_2603) } else { ifn_2605 = nil }; var arg_2606 any; var root_2608 any = A_arbace_j2g_dyncf_A_const_429.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = A_arbace_j2g_dyncf_A_const_72; var arg_2612 any = A_arbace_j2g_dyncf_A_const_76; if linked_2609 == nil { arg_2606 = ifn_2610.Invoke_O_O__O(arg_2611, arg_2612) } else { arg_2606 = linked_2609.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2608, arg_2611, arg_2612) }; var arg_2607 any; var root_2613 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2615 lang.IFn; if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = c__4; if linked_2614 == nil { arg_2607 = ifn_2615.Invoke_O__O(arg_2616) } else { arg_2607 = linked_2614.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2613, arg_2616) }; if linked_2604 == nil { tmp9 = ifn_2605.Invoke_O_O__O(arg_2606, arg_2607) } else { tmp9 = linked_2604.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2603, arg_2606, arg_2607) }; arg_2508 = tmp8.Invoke_O__O(tmp9); if linked_2506 == nil { ms__6 = ifn_2507.Invoke_O__O(arg_2508) } else { ms__6 = linked_2506.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2505, arg_2508) }
//line :482:1
	var cs__7 any; var root_2617 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2619 lang.IFn






	if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any; var iter__1927001039__auto____7 any; var fnbody__2694 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A_New_O(prot_QMARK___5); var tmp10 *jrt.Class; var fncls__2693 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A_fn_class; if fncls__2693 == nil { var fncls__2693d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, fnbody__2694); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A_fn_class = fncls__2693d; tmp10 = fncls__2693d } else { tmp10 = fncls__2693 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2694, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp12 any; var root_2695 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2695, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2697 lang.IFn; if linked_2696 == nil { ifn_2697 = lang.IFn_Cast(root_2695) } else { ifn_2697 = nil }; var arg_2698 any = A_arbace_j2g_dyncf_A_const_76; var arg_2699 any; var root_2700 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_2701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2700, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2702 lang.IFn; if linked_2701 == nil { ifn_2702 = lang.IFn_Cast(root_2700) } else { ifn_2702 = nil }; var arg_2703 any = c__4; if linked_2701 == nil { arg_2699 = ifn_2702.Invoke_O__O(arg_2703) } else { arg_2699 = linked_2701.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2700, arg_2703) }; if linked_2696 == nil { tmp12 = ifn_2697.Invoke_O_O__O(arg_2698, arg_2699) } else { tmp12 = linked_2696.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2695, arg_2698, arg_2699) }; arg_2620 = tmp11.Invoke_O__O(tmp12); if linked_2618 == nil { cs__7 = ifn_2619.Invoke_O__O(arg_2620) } else { cs__7 = linked_2618.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2617, arg_2620) }
//line :482:1
	var fs__8 any; var tmp13 any; var root_2704 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_2705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2704, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2706 lang.IFn









	if linked_2705 == nil { ifn_2706 = lang.IFn_Cast(root_2704) } else { ifn_2706 = nil }; var arg_2707 any = c__4; if linked_2705 == nil { tmp13 = ifn_2706.Invoke_O__O(arg_2707) } else { tmp13 = linked_2705.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2704, arg_2707) }; if jrt.J2g_Truth(tmp13) { fs__8 = nil } else {
		var root_2708 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2708, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2710 lang.IFn; if linked_2709 == nil { ifn_2710 = lang.IFn_Cast(root_2708) } else { ifn_2710 = nil }; var arg_2711 any; var iter__1927001039__auto____8 any; var fnbody__2785 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A_New(); var tmp14 *jrt.Class; var fncls__2784 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A_fn_class; if fncls__2784 == nil { var fncls__2784d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A_fn_class = fncls__2784d; tmp14 = fncls__2784d } else { tmp14 = fncls__2784 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2785, tmp14, nil); var tmp15 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp16 any; var root_2786 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2786, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2788 lang.IFn; if linked_2787 == nil { ifn_2788 = lang.IFn_Cast(root_2786) } else { ifn_2788 = nil }; var arg_2789 any = A_arbace_j2g_dyncf_A_const_72; var arg_2790 any; var root_2791 any = A_arbace_j2g_dyncf_A_const_190.GetRawRoot__O(); var linked_2792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2791, aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A_fn_class); var ifn_2793 lang.IFn; if linked_2792 == nil { ifn_2793 = lang.IFn_Cast(root_2791) } else { ifn_2793 = nil }; var arg_2794 any = c__4; if linked_2792 == nil { arg_2790 = ifn_2793.Invoke_O__O(arg_2794) } else { arg_2790 = linked_2792.(*aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A).Invoke_O_O__O(root_2791, arg_2794) }; if linked_2787 == nil { tmp16 = ifn_2788.Invoke_O_O__O(arg_2789, arg_2790) } else { tmp16 = linked_2787.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2786, arg_2789, arg_2790) }; arg_2711 = tmp15.Invoke_O__O(tmp16); if linked_2709 == nil { fs__8 = ifn_2710.Invoke_O__O(arg_2711) } else { fs__8 = linked_2709.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2708, arg_2711) } }
//line :482:1
	var e__9 any; var G__292000229__9_ any = lang.PersistentArrayMap_EMPTY.Ref(); var G__292000229__10_ any; var tmp17 any; var root_2795 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2795, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2797 lang.IFn













	if linked_2796 == nil { ifn_2797 = lang.IFn_Cast(root_2795) } else { ifn_2797 = nil }; var arg_2798 any = ms__6; if linked_2796 == nil { tmp17 = ifn_2797.Invoke_O__O(arg_2798) } else { tmp17 = linked_2796.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2795, arg_2798) }
//line :495:1
	if jrt.J2g_Truth(tmp17) {
		var root_2799 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_2800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2799, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2801 lang.IFn; if linked_2800 == nil { ifn_2801 = lang.IFn_Cast(root_2799) } else { ifn_2801 = nil }; var arg_2802 any = G__292000229__9_; var arg_2803 any = A_arbace_j2g_dyncf_A_const_108; var arg_2804 any = ms__6; if linked_2800 == nil { G__292000229__10_ = ifn_2801.Invoke_O_O_O__O(arg_2802, arg_2803, arg_2804) } else { G__292000229__10_ = linked_2800.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2799, arg_2802, arg_2803, arg_2804) } } else {
//line :495:1
			G__292000229__10_ = G__292000229__9_ }
//line :482:1
	var G__292000229__11_ any; var tmp18 any; var root_2805 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2807 lang.IFn














	if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any = cs__7; if linked_2806 == nil { tmp18 = ifn_2807.Invoke_O__O(arg_2808) } else { tmp18 = linked_2806.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2805, arg_2808) }
//line :495:1
	if jrt.J2g_Truth(tmp18) {

		var root_2809 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_2810 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2809, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2811 lang.IFn; if linked_2810 == nil { ifn_2811 = lang.IFn_Cast(root_2809) } else { ifn_2811 = nil }; var arg_2812 any = G__292000229__10_; var arg_2813 any = A_arbace_j2g_dyncf_A_const_431; var arg_2814 any = cs__7; if linked_2810 == nil { G__292000229__11_ = ifn_2811.Invoke_O_O_O__O(arg_2812, arg_2813, arg_2814) } else { G__292000229__11_ = linked_2810.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2809, arg_2812, arg_2813, arg_2814) } } else {
//line :495:1
			G__292000229__11_ = G__292000229__10_ }; var tmp19 any; var root_2815 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2817 lang.IFn


	if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any = fs__8; if linked_2816 == nil { tmp19 = ifn_2817.Invoke_O__O(arg_2818) } else { tmp19 = linked_2816.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2815, arg_2818) }
//line :495:1
	if jrt.J2g_Truth(tmp19) {


		var root_2819 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_2820 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2819, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2821 lang.IFn; if linked_2820 == nil { ifn_2821 = lang.IFn_Cast(root_2819) } else { ifn_2821 = nil }; var arg_2822 any = G__292000229__11_; var arg_2823 any = A_arbace_j2g_dyncf_A_const_432; var arg_2824 any = fs__8; if linked_2820 == nil { e__9 = ifn_2821.Invoke_O_O_O__O(arg_2822, arg_2823, arg_2824) } else { e__9 = linked_2820.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2819, arg_2822, arg_2823, arg_2824) } } else {
//line :495:1
			e__9 = G__292000229__11_ }
//line :482:1
	var tmp20 any; var root_2825 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2827 lang.IFn
















	if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any = e__9; if linked_2826 == nil { tmp20 = ifn_2827.Invoke_O__O(arg_2828) } else { tmp20 = linked_2826.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2825, arg_2828) }
//line :482:1
	if jrt.J2g_Truth(tmp20) { var root_2829 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2831 lang.IFn; if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any = lang.Tuple_Create_O_O__IPersistentVector(c__4, e__9); var arg_2833 any; var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__292000156); var tmp22 any; var root_2834 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2834, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2836 lang.IFn; if linked_2835 == nil { ifn_2836 = lang.IFn_Cast(root_2834) } else { ifn_2836 = nil }; var arg_2837 any = s__292000157__3; if linked_2835 == nil { tmp22 = ifn_2836.Invoke_O__O(arg_2837) } else { tmp22 = linked_2835.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2834, arg_2837) }; arg_2833 = tmp21.Invoke_O__O(tmp22); if linked_2830 == nil { return ifn_2831.Invoke_O_O__O(arg_2832, arg_2833) } else { return linked_2830.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2829, arg_2832, arg_2833) } } else { var tmp23 any; var root_2838 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2838, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2840 lang.IFn; if linked_2839 == nil { ifn_2840 = lang.IFn_Cast(root_2838) } else { ifn_2840 = nil }; var arg_2841 any = s__292000157__3; if linked_2839 == nil { tmp23 = ifn_2840.Invoke_O__O(arg_2841) } else { tmp23 = linked_2839.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2838, arg_2841) }; s__292000157__1 = tmp23; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :482:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :482:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A) Ctor_O_I_O(c__b__292000159 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000159 = c__b__292000159; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :482:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A) Invoke_O__O(self any) any { { var i__292000158__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000158__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000158__1)); var prot_QMARK___3 any; var fnbody__2135 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A_New(); var tmp2 *jrt.Class; var fncls__2134 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A_fn_class
																	if fncls__2134 == nil { var fncls__2134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A_fn_class = fncls__2134d; tmp2 = fncls__2134d } else { tmp2 = fncls__2134 }; prot_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2135, tmp2, nil)
//line :482:1
	var ms__4 any; var root_2136 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2138 lang.IFn


	if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any; var iter__1927001039__auto____4 any; var fnbody__2233 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A_New_O(prot_QMARK___3); var tmp3 *jrt.Class; var fncls__2232 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A_fn_class; if fncls__2232 == nil { var fncls__2232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__2233); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A_fn_class = fncls__2232d; tmp3 = fncls__2232d } else { tmp3 = fncls__2232 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2233, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp5 any; var root_2234 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any; var root_2239 any = A_arbace_j2g_dyncf_A_const_429.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = A_arbace_j2g_dyncf_A_const_72; var arg_2243 any = A_arbace_j2g_dyncf_A_const_76; if linked_2240 == nil { arg_2237 = ifn_2241.Invoke_O_O__O(arg_2242, arg_2243) } else { arg_2237 = linked_2240.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2239, arg_2242, arg_2243) }; var arg_2238 any; var root_2244 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_2245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2244, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2246 lang.IFn; if linked_2245 == nil { ifn_2246 = lang.IFn_Cast(root_2244) } else { ifn_2246 = nil }; var arg_2247 any = c__2; if linked_2245 == nil { arg_2238 = ifn_2246.Invoke_O__O(arg_2247) } else { arg_2238 = linked_2245.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2244, arg_2247) }; if linked_2235 == nil { tmp5 = ifn_2236.Invoke_O_O__O(arg_2237, arg_2238) } else { tmp5 = linked_2235.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2234, arg_2237, arg_2238) }; arg_2139 = tmp4.Invoke_O__O(tmp5); if linked_2137 == nil { ms__4 = ifn_2138.Invoke_O__O(arg_2139) } else { ms__4 = linked_2137.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2136, arg_2139) }
//line :482:1
	var cs__5 any; var root_2248 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2250 lang.IFn






	if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any; var iter__1927001039__auto____5 any; var fnbody__2325 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A_New_O(prot_QMARK___3); var tmp6 *jrt.Class; var fncls__2324 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A_fn_class; if fncls__2324 == nil { var fncls__2324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, fnbody__2325); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A_fn_class = fncls__2324d; tmp6 = fncls__2324d } else { tmp6 = fncls__2324 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2325, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp8 any; var root_2326 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = A_arbace_j2g_dyncf_A_const_76; var arg_2330 any; var root_2331 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = c__2; if linked_2332 == nil { arg_2330 = ifn_2333.Invoke_O__O(arg_2334) } else { arg_2330 = linked_2332.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2331, arg_2334) }; if linked_2327 == nil { tmp8 = ifn_2328.Invoke_O_O__O(arg_2329, arg_2330) } else { tmp8 = linked_2327.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2326, arg_2329, arg_2330) }; arg_2251 = tmp7.Invoke_O__O(tmp8); if linked_2249 == nil { cs__5 = ifn_2250.Invoke_O__O(arg_2251) } else { cs__5 = linked_2249.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2248, arg_2251) }
//line :482:1
	var fs__6 any; var tmp9 any; var root_2335 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2337 lang.IFn









	if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = c__2; if linked_2336 == nil { tmp9 = ifn_2337.Invoke_O__O(arg_2338) } else { tmp9 = linked_2336.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2335, arg_2338) }; if jrt.J2g_Truth(tmp9) { fs__6 = nil } else {
		var root_2339 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any; var iter__1927001039__auto____6 any; var fnbody__2416 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A_New(); var tmp10 *jrt.Class; var fncls__2415 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A_fn_class; if fncls__2415 == nil { var fncls__2415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A_fn_class = fncls__2415d; tmp10 = fncls__2415d } else { tmp10 = fncls__2415 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2416, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp12 any; var root_2417 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2417, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2419 lang.IFn; if linked_2418 == nil { ifn_2419 = lang.IFn_Cast(root_2417) } else { ifn_2419 = nil }; var arg_2420 any = A_arbace_j2g_dyncf_A_const_72; var arg_2421 any; var root_2422 any = A_arbace_j2g_dyncf_A_const_190.GetRawRoot__O(); var linked_2423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2422, aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A_fn_class); var ifn_2424 lang.IFn; if linked_2423 == nil { ifn_2424 = lang.IFn_Cast(root_2422) } else { ifn_2424 = nil }; var arg_2425 any = c__2; if linked_2423 == nil { arg_2421 = ifn_2424.Invoke_O__O(arg_2425) } else { arg_2421 = linked_2423.(*aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A).Invoke_O_O__O(root_2422, arg_2425) }; if linked_2418 == nil { tmp12 = ifn_2419.Invoke_O_O__O(arg_2420, arg_2421) } else { tmp12 = linked_2418.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2417, arg_2420, arg_2421) }; arg_2342 = tmp11.Invoke_O__O(tmp12); if linked_2340 == nil { fs__6 = ifn_2341.Invoke_O__O(arg_2342) } else { fs__6 = linked_2340.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2339, arg_2342) } }
//line :482:1
	var e__7 any; var G__292000195__7_ any = lang.PersistentArrayMap_EMPTY.Ref(); var G__292000195__8_ any; var tmp13 any; var root_2426 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2428 lang.IFn













	if linked_2427 == nil { ifn_2428 = lang.IFn_Cast(root_2426) } else { ifn_2428 = nil }; var arg_2429 any = ms__4; if linked_2427 == nil { tmp13 = ifn_2428.Invoke_O__O(arg_2429) } else { tmp13 = linked_2427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2426, arg_2429) }
//line :495:1
	if jrt.J2g_Truth(tmp13) {
		var root_2430 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_2431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2430, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2432 lang.IFn; if linked_2431 == nil { ifn_2432 = lang.IFn_Cast(root_2430) } else { ifn_2432 = nil }; var arg_2433 any = G__292000195__7_; var arg_2434 any = A_arbace_j2g_dyncf_A_const_108; var arg_2435 any = ms__4; if linked_2431 == nil { G__292000195__8_ = ifn_2432.Invoke_O_O_O__O(arg_2433, arg_2434, arg_2435) } else { G__292000195__8_ = linked_2431.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2430, arg_2433, arg_2434, arg_2435) } } else {
//line :495:1
			G__292000195__8_ = G__292000195__7_ }
//line :482:1
	var G__292000195__9_ any; var tmp14 any; var root_2436 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2438 lang.IFn














	if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any = cs__5; if linked_2437 == nil { tmp14 = ifn_2438.Invoke_O__O(arg_2439) } else { tmp14 = linked_2437.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2436, arg_2439) }
//line :495:1
	if jrt.J2g_Truth(tmp14) {

		var root_2440 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any = G__292000195__8_; var arg_2444 any = A_arbace_j2g_dyncf_A_const_431; var arg_2445 any = cs__5; if linked_2441 == nil { G__292000195__9_ = ifn_2442.Invoke_O_O_O__O(arg_2443, arg_2444, arg_2445) } else { G__292000195__9_ = linked_2441.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2440, arg_2443, arg_2444, arg_2445) } } else {
//line :495:1
			G__292000195__9_ = G__292000195__8_ }; var tmp15 any; var root_2446 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2448 lang.IFn


	if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any = fs__6; if linked_2447 == nil { tmp15 = ifn_2448.Invoke_O__O(arg_2449) } else { tmp15 = linked_2447.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2446, arg_2449) }
//line :495:1
	if jrt.J2g_Truth(tmp15) {


		var root_2450 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_2451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2450, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2452 lang.IFn; if linked_2451 == nil { ifn_2452 = lang.IFn_Cast(root_2450) } else { ifn_2452 = nil }; var arg_2453 any = G__292000195__9_; var arg_2454 any = A_arbace_j2g_dyncf_A_const_432; var arg_2455 any = fs__6; if linked_2451 == nil { e__7 = ifn_2452.Invoke_O_O_O__O(arg_2453, arg_2454, arg_2455) } else { e__7 = linked_2451.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2450, arg_2453, arg_2454, arg_2455) } } else {
//line :495:1
			e__7 = G__292000195__9_ }
//line :482:1
	var tmp16 any; var root_2456 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2456, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2458 lang.IFn
















	if linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any = e__7; if linked_2457 == nil { tmp16 = ifn_2458.Invoke_O__O(arg_2459) } else { tmp16 = linked_2457.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2456, arg_2459) }
//line :482:1
	if jrt.J2g_Truth(tmp16) { var root_2460 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2460, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2462 lang.IFn; if linked_2461 == nil { ifn_2462 = lang.IFn_Cast(root_2460) } else { ifn_2462 = nil }; var arg_2463 any = t.F_b__292000159; var arg_2464 any = lang.Tuple_Create_O_O__IPersistentVector(c__2, e__7); if linked_2461 == nil { ifn_2462.Invoke_O_O__O(arg_2463, arg_2464) } else { linked_2461.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2460, arg_2463, arg_2464) }; i__292000158__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000158__1); continue L1 } else { i__292000158__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000158__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A) Ctor() {}
//line :483:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A) Invoke_O_O__O(self, x__1 any) any { var fl__2 any; var or__1927000174__auto____2 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(x__1); if jrt.J2g_Truth(or__1927000174__auto____2) { fl__2 = or__1927000174__auto____2 } else { fl__2 = A_arbace_j2g_dyncf_A_const_206 }; var and__1927000168__auto____3 bool; var tmp1 int64; var na_2124 any = fl__2; var na_2125 any = A_arbace_j2g_dyncf_A_const_424.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 =
																					jrt.Long_InstanceOf(na_2124); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_2125) }; tmp2 = tmp3; if tmp2 { var n0_2126 int64 = jrt.NN(jrt.Long_Cast(na_2124)).LongValue__J(); var n1_2127 int64 = jrt.NN(jrt.Long_Cast(na_2125)).LongValue__J(); tmp1 = n0_2126 & n1_2127 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_2124, na_2125) }; and__1927000168__auto____3 = lang.Numbers_IsPos_J__Z_NoInit(tmp1); if and__1927000168__auto____3 { var tmp4 int64; var na_2129 any = fl__2; var na_2130 int64 = 4105; if jrt.Long_InstanceOf(na_2129) { var n0_2131 int64 = jrt.NN(jrt.Long_Cast(na_2129)).LongValue__J(); var n1_2132 int64 = na_2130; tmp4 = n0_2131 & n1_2132 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_2129, na_2130) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp4)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
//line :483:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A) Ctor() {}
//line :483:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A) Invoke_O_O__O(self, x__1 any) any { var fl__2 any; var or__1927000174__auto____2 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(x__1); if jrt.J2g_Truth(or__1927000174__auto____2) { fl__2 = or__1927000174__auto____2 } else { fl__2 = A_arbace_j2g_dyncf_A_const_206 }; var and__1927000168__auto____3 bool; var tmp1 int64; var na_2493 any = fl__2; var na_2494 any = A_arbace_j2g_dyncf_A_const_424.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 =
																			jrt.Long_InstanceOf(na_2493); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_2494) }; tmp2 = tmp3; if tmp2 { var n0_2495 int64 = jrt.NN(jrt.Long_Cast(na_2493)).LongValue__J(); var n1_2496 int64 = jrt.NN(jrt.Long_Cast(na_2494)).LongValue__J(); tmp1 = n0_2495 & n1_2496 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_2493, na_2494) }; and__1927000168__auto____3 = lang.Numbers_IsPos_J__Z_NoInit(tmp1); if and__1927000168__auto____3 { var tmp4 int64; var na_2498 any = fl__2; var na_2499 int64 = 4105; if jrt.Long_InstanceOf(na_2498) { var n0_2500 int64 = jrt.NN(jrt.Long_Cast(na_2498)).LongValue__J(); var n1_2501 int64 = na_2499; tmp4 = n0_2500 & n1_2501 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_2498, na_2499) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp4)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A_New_O(p0 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A{}; t.Ctor_O(p0); return t }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A) Ctor_O(c__prot_QMARK_ any) { t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A) Invoke_O_O__O(self, s__292000166__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2231 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A_New_O_O_O(self, t.F_prot_QMARK_, s__292000166__1); var tmp2 *jrt.Class; var fncls__2230 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A_fn_class; if fncls__2230 == nil { var fncls__2230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, fnbody__2231); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A_fn_class = fncls__2230d; tmp2 = fncls__2230d } else { tmp2 = fncls__2230 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2231, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :485:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A) Ctor_O_O_O(c__iter__292000165, c__prot_QMARK_, c__s__292000166 any) { t.F_iter__292000165 = c__iter__292000165; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_s__292000166 = c__s__292000166 }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A) Invoke_O__O(self any) any { { var s__292000166__1 any; var t_ any = t.F_s__292000166; t.F_s__292000166 = nil; s__292000166__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2140 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2142 lang.IFn; if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = s__292000166__1; if linked_2141 == nil { temp__1927000414__auto____2 = ifn_2142.Invoke_O__O(arg_2143) } else { temp__1927000414__auto____2 = linked_2141.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2140, arg_2143) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000166__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2144 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2146 lang.IFn; if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any = s__292000166__3; if linked_2145 == nil { tmp1 = ifn_2146.Invoke_O__O(arg_2147) } else { tmp1 = linked_2145.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2144, arg_2147) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2148 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = s__292000166__3; if linked_2149 == nil { c__1927001037__auto____4 = ifn_2150.Invoke_O__O(arg_2151) } else { c__1927001037__auto____4 = linked_2149.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2148, arg_2151) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000168__6 any; var root_2152 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2153 == nil { b__292000168__6 = ifn_2154.Invoke_O__O(arg_2155) } else { b__292000168__6 = linked_2153.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2152, arg_2155) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2176 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A_New_O_O_I_O(b__292000168__6, t.F_prot_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2175 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A_fn_class; if fncls__2175 == nil { var fncls__2175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, fnbody__2176); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A_fn_class = fncls__2175d; tmp3 = fncls__2175d } else { tmp3 = fncls__2175 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2176, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2177 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any; var root_2182 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2184 lang.IFn; if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any = b__292000168__6; if linked_2183 == nil { arg_2180 = ifn_2184.Invoke_O__O(arg_2185) } else { arg_2180 = linked_2183.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2182, arg_2185) }; var arg_2181 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000165); var tmp5 any; var root_2186 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = s__292000166__3; if linked_2187 == nil { tmp5 = ifn_2188.Invoke_O__O(arg_2189) } else { tmp5 = linked_2187.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2186, arg_2189) }; arg_2181 = tmp4.Invoke_O__O(tmp5); if linked_2178 == nil { return ifn_2179.Invoke_O_O__O(arg_2180, arg_2181) } else { return linked_2178.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2177, arg_2180, arg_2181) } } else { var root_2190 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any; var root_2195 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = b__292000168__6; if linked_2196 == nil { arg_2193 = ifn_2197.Invoke_O__O(arg_2198) } else { arg_2193 = linked_2196.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2195, arg_2198) }; var arg_2194 any; if linked_2191 == nil { return ifn_2192.Invoke_O_O__O(arg_2193, arg_2194) } else { return linked_2191.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2190, arg_2193, arg_2194) } } } else { var mm__4 any; var root_2199 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = s__292000166__3; if linked_2200 == nil { mm__4 = ifn_2201.Invoke_O__O(arg_2202) } else { mm__4 = linked_2200.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2199, arg_2202) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__4)
																						if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2203 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = Lit_69; var arg_2207 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4); if linked_2204 == nil { and__1927000168__auto____6 = ifn_2205.Invoke_O_O__O(arg_2206, arg_2207) } else { and__1927000168__auto____6 = linked_2204.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2203, arg_2206, arg_2207) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2208 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = Lit_124; var arg_2212 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4); if linked_2209 == nil { and__1927000168__auto____7 = ifn_2210.Invoke_O_O__O(arg_2211, arg_2212) } else { and__1927000168__auto____7 = linked_2209.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2208, arg_2211, arg_2212) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
																							var root_2213 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2213, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2215 lang.IFn; if linked_2214 == nil { ifn_2215 = lang.IFn_Cast(root_2213) } else { ifn_2215 = nil }; var arg_2216 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_2214 == nil { tmp6 = ifn_2215.Invoke_O__O(arg_2216) } else { tmp6 = linked_2214.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2213, arg_2216) } } else {
//line :486:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :485:1
	if jrt.J2g_Truth(tmp6) { var root_2217 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2217, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2219 lang.IFn; if linked_2218 == nil { ifn_2219 = lang.IFn_Cast(root_2217) } else { ifn_2219 = nil }; var arg_2220 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)); var arg_2221 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000165); var tmp8 any; var root_2222 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2222, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2224 lang.IFn; if linked_2223 == nil { ifn_2224 = lang.IFn_Cast(root_2222) } else { ifn_2224 = nil }; var arg_2225 any = s__292000166__3; if linked_2223 == nil { tmp8 = ifn_2224.Invoke_O__O(arg_2225) } else { tmp8 = linked_2223.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2222, arg_2225) }; arg_2221 = tmp7.Invoke_O__O(tmp8); if linked_2218 == nil { return ifn_2219.Invoke_O_O__O(arg_2220, arg_2221) } else { return linked_2218.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2217, arg_2220, arg_2221) } } else { var tmp9 any; var root_2226 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = s__292000166__3; if linked_2227 == nil { tmp9 = ifn_2228.Invoke_O__O(arg_2229) } else { tmp9 = linked_2227.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2226, arg_2229) }; s__292000166__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :485:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A) Ctor_O_O_I_O(c__b__292000168, c__prot_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000168 = c__b__292000168; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A) Invoke_O__O(self any) any { { var i__292000167__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000167__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__2)
																								if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2156 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = Lit_69; var arg_2160 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2); if linked_2157 == nil { and__1927000168__auto____4 = ifn_2158.Invoke_O_O__O(arg_2159, arg_2160) } else { and__1927000168__auto____4 = linked_2157.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2156, arg_2159, arg_2160) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_2161 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2163 lang.IFn; if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any = Lit_124; var arg_2165 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2); if linked_2162 == nil { and__1927000168__auto____5 = ifn_2163.Invoke_O_O__O(arg_2164, arg_2165) } else { and__1927000168__auto____5 = linked_2162.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2161, arg_2164, arg_2165) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
																									var root_2166 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_2167 == nil { tmp2 = ifn_2168.Invoke_O__O(arg_2169) } else { tmp2 = linked_2167.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2166, arg_2169) } } else {
//line :486:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :485:1
	if jrt.J2g_Truth(tmp2) { var root_2170 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2172 lang.IFn; if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any = t.F_b__292000168; var arg_2174 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)); if linked_2171 == nil { ifn_2172.Invoke_O_O__O(arg_2173, arg_2174) } else { linked_2171.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2170, arg_2173, arg_2174) }; i__292000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000167__1); continue L1 } else { i__292000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000167__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :485:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A_New_O(p0 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A{}; t.Ctor_O(p0); return t }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A) Ctor_O(c__prot_QMARK_ any) { t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A) Invoke_O_O__O(self, s__292000200__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2600 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A_New_O_O_O(t.F_prot_QMARK_, self, s__292000200__1); var tmp2 *jrt.Class; var fncls__2599 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A_fn_class; if fncls__2599 == nil { var fncls__2599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, fnbody__2600); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A_fn_class = fncls__2599d; tmp2 = fncls__2599d } else { tmp2 = fncls__2599 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2600, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :485:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A) Ctor_O_O_O(c__prot_QMARK_, c__iter__292000199, c__s__292000200 any) { t.F_prot_QMARK_ = c__prot_QMARK_; t.F_iter__292000199 = c__iter__292000199; t.F_s__292000200 = c__s__292000200 }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A) Invoke_O__O(self any) any { { var s__292000200__1 any; var t_ any = t.F_s__292000200; t.F_s__292000200 = nil; s__292000200__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2509 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2509, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2511 lang.IFn; if linked_2510 == nil { ifn_2511 = lang.IFn_Cast(root_2509) } else { ifn_2511 = nil }; var arg_2512 any = s__292000200__1; if linked_2510 == nil { temp__1927000414__auto____2 = ifn_2511.Invoke_O__O(arg_2512) } else { temp__1927000414__auto____2 = linked_2510.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2509, arg_2512) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000200__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2513 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2513, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2515 lang.IFn; if linked_2514 == nil { ifn_2515 = lang.IFn_Cast(root_2513) } else { ifn_2515 = nil }; var arg_2516 any = s__292000200__3; if linked_2514 == nil { tmp1 = ifn_2515.Invoke_O__O(arg_2516) } else { tmp1 = linked_2514.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2513, arg_2516) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2517 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2517, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2519 lang.IFn; if linked_2518 == nil { ifn_2519 = lang.IFn_Cast(root_2517) } else { ifn_2519 = nil }; var arg_2520 any = s__292000200__3; if linked_2518 == nil { c__1927001037__auto____4 = ifn_2519.Invoke_O__O(arg_2520) } else { c__1927001037__auto____4 = linked_2518.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2517, arg_2520) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000202__6 any; var root_2521 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2523 lang.IFn; if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2522 == nil { b__292000202__6 = ifn_2523.Invoke_O__O(arg_2524) } else { b__292000202__6 = linked_2522.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2521, arg_2524) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2545 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A_New_O_O_I_O(b__292000202__6, t.F_prot_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2544 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A_fn_class; if fncls__2544 == nil { var fncls__2544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, fnbody__2545); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A_fn_class = fncls__2544d; tmp3 = fncls__2544d } else { tmp3 = fncls__2544 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2545, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2546 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2546, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2548 lang.IFn; if linked_2547 == nil { ifn_2548 = lang.IFn_Cast(root_2546) } else { ifn_2548 = nil }; var arg_2549 any; var root_2551 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = b__292000202__6; if linked_2552 == nil { arg_2549 = ifn_2553.Invoke_O__O(arg_2554) } else { arg_2549 = linked_2552.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2551, arg_2554) }; var arg_2550 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000199); var tmp5 any; var root_2555 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = s__292000200__3; if linked_2556 == nil { tmp5 = ifn_2557.Invoke_O__O(arg_2558) } else { tmp5 = linked_2556.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2555, arg_2558) }; arg_2550 = tmp4.Invoke_O__O(tmp5); if linked_2547 == nil { return ifn_2548.Invoke_O_O__O(arg_2549, arg_2550) } else { return linked_2547.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2546, arg_2549, arg_2550) } } else { var root_2559 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any; var root_2564 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2564, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2566 lang.IFn; if linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any = b__292000202__6; if linked_2565 == nil { arg_2562 = ifn_2566.Invoke_O__O(arg_2567) } else { arg_2562 = linked_2565.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2564, arg_2567) }; var arg_2563 any; if linked_2560 == nil { return ifn_2561.Invoke_O_O__O(arg_2562, arg_2563) } else { return linked_2560.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2559, arg_2562, arg_2563) } } } else { var mm__4 any; var root_2568 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = s__292000200__3; if linked_2569 == nil { mm__4 = ifn_2570.Invoke_O__O(arg_2571) } else { mm__4 = linked_2569.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2568, arg_2571) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2572 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = Lit_69; var arg_2576 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4); if linked_2573 == nil { and__1927000168__auto____6 = ifn_2574.Invoke_O_O__O(arg_2575, arg_2576) } else { and__1927000168__auto____6 = linked_2573.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2572, arg_2575, arg_2576) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2577 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2578 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2577, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2579 lang.IFn; if linked_2578 == nil { ifn_2579 = lang.IFn_Cast(root_2577) } else { ifn_2579 = nil }; var arg_2580 any = Lit_124; var arg_2581 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4); if linked_2578 == nil { and__1927000168__auto____7 = ifn_2579.Invoke_O_O__O(arg_2580, arg_2581) } else { and__1927000168__auto____7 = linked_2578.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2577, arg_2580, arg_2581) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
																					var root_2582 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2582, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2584 lang.IFn; if linked_2583 == nil { ifn_2584 = lang.IFn_Cast(root_2582) } else { ifn_2584 = nil }; var arg_2585 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_2583 == nil { tmp6 = ifn_2584.Invoke_O__O(arg_2585) } else { tmp6 = linked_2583.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2582, arg_2585) } } else {
//line :486:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :485:1
	if jrt.J2g_Truth(tmp6) { var root_2586 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2588 lang.IFn; if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)); var arg_2590 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000199); var tmp8 any; var root_2591 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2591, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2593 lang.IFn; if linked_2592 == nil { ifn_2593 = lang.IFn_Cast(root_2591) } else { ifn_2593 = nil }; var arg_2594 any = s__292000200__3; if linked_2592 == nil { tmp8 = ifn_2593.Invoke_O__O(arg_2594) } else { tmp8 = linked_2592.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2591, arg_2594) }; arg_2590 = tmp7.Invoke_O__O(tmp8); if linked_2587 == nil { return ifn_2588.Invoke_O_O__O(arg_2589, arg_2590) } else { return linked_2587.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2586, arg_2589, arg_2590) } } else { var tmp9 any; var root_2595 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2597 lang.IFn; if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any = s__292000200__3; if linked_2596 == nil { tmp9 = ifn_2597.Invoke_O__O(arg_2598) } else { tmp9 = linked_2596.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2595, arg_2598) }; s__292000200__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :485:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A) Ctor_O_O_I_O(c__b__292000202, c__prot_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000202 = c__b__292000202; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :485:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A) Invoke_O__O(self any) any { { var i__292000201__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000201__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000201__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__2)
																						if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2525 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2527 lang.IFn; if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any = Lit_69; var arg_2529 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2); if linked_2526 == nil { and__1927000168__auto____4 = ifn_2527.Invoke_O_O__O(arg_2528, arg_2529) } else { and__1927000168__auto____4 = linked_2526.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2525, arg_2528, arg_2529) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_2530 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2532 lang.IFn; if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any = Lit_124; var arg_2534 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2); if linked_2531 == nil { and__1927000168__auto____5 = ifn_2532.Invoke_O_O__O(arg_2533, arg_2534) } else { and__1927000168__auto____5 = linked_2531.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2530, arg_2533, arg_2534) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
																							var root_2535 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2535, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2537 lang.IFn; if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2538 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_2536 == nil { tmp2 = ifn_2537.Invoke_O__O(arg_2538) } else { tmp2 = linked_2536.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2535, arg_2538) } } else {
//line :486:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :485:1
	if jrt.J2g_Truth(tmp2) { var root_2539 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2541 lang.IFn; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = t.F_b__292000202; var arg_2543 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)); if linked_2540 == nil { ifn_2541.Invoke_O_O__O(arg_2542, arg_2543) } else { linked_2540.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2539, arg_2542, arg_2543) }; i__292000201__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000201__1); continue L1 } else { i__292000201__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000201__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A_New_O(p0 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A{}; t.Ctor_O(p0); return t }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A) Ctor_O(c__prot_QMARK_ any) { t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A) Invoke_O_O__O(self, s__292000176__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2323 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A_New_O_O_O(self, t.F_prot_QMARK_, s__292000176__1); var tmp2 *jrt.Class; var fncls__2322 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A_fn_class; if fncls__2322 == nil { var fncls__2322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, fnbody__2323); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A_fn_class = fncls__2322d; tmp2 = fncls__2322d } else { tmp2 = fncls__2322 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2323, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :489:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A) Ctor_O_O_O(c__iter__292000175, c__prot_QMARK_, c__s__292000176 any) { t.F_iter__292000175 = c__iter__292000175; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_s__292000176 = c__s__292000176 }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A) Invoke_O__O(self any) any { { var s__292000176__1 any; var t_ any = t.F_s__292000176; t.F_s__292000176 = nil; s__292000176__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2252 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2254 lang.IFn; if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = s__292000176__1; if linked_2253 == nil { temp__1927000414__auto____2 = ifn_2254.Invoke_O__O(arg_2255) } else { temp__1927000414__auto____2 = linked_2253.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2252, arg_2255) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000176__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2256 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2256, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2258 lang.IFn; if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any = s__292000176__3; if linked_2257 == nil { tmp1 = ifn_2258.Invoke_O__O(arg_2259) } else { tmp1 = linked_2257.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2256, arg_2259) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2260 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2260, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2262 lang.IFn; if linked_2261 == nil { ifn_2262 = lang.IFn_Cast(root_2260) } else { ifn_2262 = nil }; var arg_2263 any = s__292000176__3; if linked_2261 == nil { c__1927001037__auto____4 = ifn_2262.Invoke_O__O(arg_2263) } else { c__1927001037__auto____4 = linked_2261.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2260, arg_2263) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000178__6 any; var root_2264 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2264, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2266 lang.IFn; if linked_2265 == nil { ifn_2266 = lang.IFn_Cast(root_2264) } else { ifn_2266 = nil }; var arg_2267 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2265 == nil { b__292000178__6 = ifn_2266.Invoke_O__O(arg_2267) } else { b__292000178__6 = linked_2265.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2264, arg_2267) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2278 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A_New_O_O_I_O(b__292000178__6, t.F_prot_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2277 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A_fn_class; if fncls__2277 == nil { var fncls__2277d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, fnbody__2278); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A_fn_class = fncls__2277d; tmp3 = fncls__2277d } else { tmp3 = fncls__2277 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2278, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2279 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2279, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2281 lang.IFn; if linked_2280 == nil { ifn_2281 = lang.IFn_Cast(root_2279) } else { ifn_2281 = nil }; var arg_2282 any; var root_2284 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2286 lang.IFn; if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any = b__292000178__6; if linked_2285 == nil { arg_2282 = ifn_2286.Invoke_O__O(arg_2287) } else { arg_2282 = linked_2285.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2284, arg_2287) }; var arg_2283 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000175); var tmp5 any; var root_2288 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2290 lang.IFn; if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any = s__292000176__3; if linked_2289 == nil { tmp5 = ifn_2290.Invoke_O__O(arg_2291) } else { tmp5 = linked_2289.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2288, arg_2291) }; arg_2283 = tmp4.Invoke_O__O(tmp5); if linked_2280 == nil { return ifn_2281.Invoke_O_O__O(arg_2282, arg_2283) } else { return linked_2280.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2279, arg_2282, arg_2283) } } else { var root_2292 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2294 lang.IFn; if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any; var root_2297 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = b__292000178__6; if linked_2298 == nil { arg_2295 = ifn_2299.Invoke_O__O(arg_2300) } else { arg_2295 = linked_2298.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2297, arg_2300) }; var arg_2296 any; if linked_2293 == nil { return ifn_2294.Invoke_O_O__O(arg_2295, arg_2296) } else { return linked_2293.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2292, arg_2295, arg_2296) } } } else { var mm__4 any; var root_2301 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = s__292000176__3; if linked_2302 == nil { mm__4 = ifn_2303.Invoke_O__O(arg_2304) } else { mm__4 = linked_2302.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2301, arg_2304) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__4)
																						if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)); if and__1927000168__auto____6 { var root_2305 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_2306 == nil { tmp6 = ifn_2307.Invoke_O__O(arg_2308) } else { tmp6 = linked_2306.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2305, arg_2308) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp6 = and__1927000168__auto____5 }
//line :489:1
	if jrt.J2g_Truth(tmp6) { var root_2309 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2311 lang.IFn; if linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)); var arg_2313 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000175); var tmp8 any; var root_2314 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2316 lang.IFn; if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = s__292000176__3; if linked_2315 == nil { tmp8 = ifn_2316.Invoke_O__O(arg_2317) } else { tmp8 = linked_2315.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2314, arg_2317) }; arg_2313 = tmp7.Invoke_O__O(tmp8); if linked_2310 == nil { return ifn_2311.Invoke_O_O__O(arg_2312, arg_2313) } else { return linked_2310.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2309, arg_2312, arg_2313) } } else { var tmp9 any; var root_2318 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = s__292000176__3; if linked_2319 == nil { tmp9 = ifn_2320.Invoke_O__O(arg_2321) } else { tmp9 = linked_2319.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2318, arg_2321) }; s__292000176__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :489:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A) Ctor_O_O_I_O(c__b__292000178, c__prot_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000178 = c__b__292000178; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A) Invoke_O__O(self any) any { { var i__292000177__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000177__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000177__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__2)
																								if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)); if and__1927000168__auto____4 { var root_2268 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2268, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2270 lang.IFn; if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_2269 == nil { tmp2 = ifn_2270.Invoke_O__O(arg_2271) } else { tmp2 = linked_2269.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2268, arg_2271) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp2 = and__1927000168__auto____3 }
//line :489:1
	if jrt.J2g_Truth(tmp2) { var root_2272 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any = t.F_b__292000178; var arg_2276 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)); if linked_2273 == nil { ifn_2274.Invoke_O_O__O(arg_2275, arg_2276) } else { linked_2273.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2272, arg_2275, arg_2276) }; i__292000177__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000177__1); continue L1 } else { i__292000177__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000177__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :489:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A_New_O(p0 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A{}; t.Ctor_O(p0); return t }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A) Ctor_O(c__prot_QMARK_ any) { t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A) Invoke_O_O__O(self, s__292000210__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2692 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A_New_O_O_O(t.F_prot_QMARK_, s__292000210__1, self); var tmp2 *jrt.Class; var fncls__2691 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A_fn_class; if fncls__2691 == nil { var fncls__2691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, fnbody__2692); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A_fn_class = fncls__2691d; tmp2 = fncls__2691d } else { tmp2 = fncls__2691 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2692, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :489:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A) Ctor_O_O_O(c__prot_QMARK_, c__s__292000210, c__iter__292000209 any) { t.F_prot_QMARK_ = c__prot_QMARK_; t.F_s__292000210 = c__s__292000210; t.F_iter__292000209 = c__iter__292000209 }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A) Invoke_O__O(self any) any { { var s__292000210__1 any; var t_ any = t.F_s__292000210; t.F_s__292000210 = nil; s__292000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2621 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any = s__292000210__1; if linked_2622 == nil { temp__1927000414__auto____2 = ifn_2623.Invoke_O__O(arg_2624) } else { temp__1927000414__auto____2 = linked_2622.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2621, arg_2624) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2625 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any = s__292000210__3; if linked_2626 == nil { tmp1 = ifn_2627.Invoke_O__O(arg_2628) } else { tmp1 = linked_2626.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2625, arg_2628) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2629 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = s__292000210__3; if linked_2630 == nil { c__1927001037__auto____4 = ifn_2631.Invoke_O__O(arg_2632) } else { c__1927001037__auto____4 = linked_2630.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2629, arg_2632) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000212__6 any; var root_2633 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2635 lang.IFn; if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2634 == nil { b__292000212__6 = ifn_2635.Invoke_O__O(arg_2636) } else { b__292000212__6 = linked_2634.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2633, arg_2636) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2647 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A_New_O_O_I_O(b__292000212__6, t.F_prot_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2646 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A_fn_class; if fncls__2646 == nil { var fncls__2646d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, fnbody__2647); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A_fn_class = fncls__2646d; tmp3 = fncls__2646d } else { tmp3 = fncls__2646 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2647, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2648 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any; var root_2653 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = b__292000212__6; if linked_2654 == nil { arg_2651 = ifn_2655.Invoke_O__O(arg_2656) } else { arg_2651 = linked_2654.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2653, arg_2656) }; var arg_2652 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000209); var tmp5 any; var root_2657 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = s__292000210__3; if linked_2658 == nil { tmp5 = ifn_2659.Invoke_O__O(arg_2660) } else { tmp5 = linked_2658.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2657, arg_2660) }; arg_2652 = tmp4.Invoke_O__O(tmp5); if linked_2649 == nil { return ifn_2650.Invoke_O_O__O(arg_2651, arg_2652) } else { return linked_2649.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2648, arg_2651, arg_2652) } } else { var root_2661 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2661, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2663 lang.IFn; if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; var arg_2664 any; var root_2666 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2666, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2668 lang.IFn; if linked_2667 == nil { ifn_2668 = lang.IFn_Cast(root_2666) } else { ifn_2668 = nil }; var arg_2669 any = b__292000212__6; if linked_2667 == nil { arg_2664 = ifn_2668.Invoke_O__O(arg_2669) } else { arg_2664 = linked_2667.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2666, arg_2669) }; var arg_2665 any; if linked_2662 == nil { return ifn_2663.Invoke_O_O__O(arg_2664, arg_2665) } else { return linked_2662.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2661, arg_2664, arg_2665) } } } else { var mm__4 any; var root_2670 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = s__292000210__3; if linked_2671 == nil { mm__4 = ifn_2672.Invoke_O__O(arg_2673) } else { mm__4 = linked_2671.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2670, arg_2673) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)); if and__1927000168__auto____6 { var root_2674 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2674, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2676 lang.IFn; if linked_2675 == nil { ifn_2676 = lang.IFn_Cast(root_2674) } else { ifn_2676 = nil }; var arg_2677 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_2675 == nil { tmp6 = ifn_2676.Invoke_O__O(arg_2677) } else { tmp6 = linked_2675.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2674, arg_2677) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp6 = and__1927000168__auto____5 }
//line :489:1
	if jrt.J2g_Truth(tmp6) { var root_2678 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)); var arg_2682 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000209); var tmp8 any; var root_2683 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2683, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2685 lang.IFn; if linked_2684 == nil { ifn_2685 = lang.IFn_Cast(root_2683) } else { ifn_2685 = nil }; var arg_2686 any = s__292000210__3; if linked_2684 == nil { tmp8 = ifn_2685.Invoke_O__O(arg_2686) } else { tmp8 = linked_2684.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2683, arg_2686) }; arg_2682 = tmp7.Invoke_O__O(tmp8); if linked_2679 == nil { return ifn_2680.Invoke_O_O__O(arg_2681, arg_2682) } else { return linked_2679.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2678, arg_2681, arg_2682) } } else { var tmp9 any; var root_2687 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2687, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2689 lang.IFn; if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; var arg_2690 any = s__292000210__3; if linked_2688 == nil { tmp9 = ifn_2689.Invoke_O__O(arg_2690) } else { tmp9 = linked_2688.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2687, arg_2690) }; s__292000210__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :489:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A) Ctor_O_O_I_O(c__b__292000212, c__prot_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000212 = c__b__292000212; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :489:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A) Invoke_O__O(self any) any { { var i__292000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000211__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__2)
																						if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)); if and__1927000168__auto____4 { var root_2637 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_2638 == nil { tmp2 = ifn_2639.Invoke_O__O(arg_2640) } else { tmp2 = linked_2638.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2637, arg_2640) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp2 = and__1927000168__auto____3 }
//line :489:1
	if jrt.J2g_Truth(tmp2) { var root_2641 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2641, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2643 lang.IFn; if linked_2642 == nil { ifn_2643 = lang.IFn_Cast(root_2641) } else { ifn_2643 = nil }; var arg_2644 any = t.F_b__292000212; var arg_2645 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)); if linked_2642 == nil { ifn_2643.Invoke_O_O__O(arg_2644, arg_2645) } else { linked_2642.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2641, arg_2644, arg_2645) }; i__292000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000211__1); continue L1 } else { i__292000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000211__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A{}; t.Ctor(); return t }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A) Ctor() {}
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A) Invoke_O_O__O(self, s__292000186__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2414 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A_New_O_O(self, s__292000186__1); var tmp2 *jrt.Class; var fncls__2413 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A_fn_class; if fncls__2413 == nil { var fncls__2413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, fnbody__2414); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A_fn_class = fncls__2413d; tmp2 = fncls__2413d } else { tmp2 = fncls__2413 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2414, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :493:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A{}; t.Ctor_O_O(p0, p1); return t }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A) Ctor_O_O(c__iter__292000185, c__s__292000186 any) { t.F_iter__292000185 = c__iter__292000185; t.F_s__292000186 = c__s__292000186 }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A) Invoke_O__O(self any) any { { var s__292000186__1 any; var t_ any = t.F_s__292000186; t.F_s__292000186 = nil; s__292000186__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2343 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = s__292000186__1; if linked_2344 == nil { temp__1927000414__auto____2 = ifn_2345.Invoke_O__O(arg_2346) } else { temp__1927000414__auto____2 = linked_2344.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2343, arg_2346) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000186__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2347 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = s__292000186__3; if linked_2348 == nil { tmp1 = ifn_2349.Invoke_O__O(arg_2350) } else { tmp1 = linked_2348.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2347, arg_2350) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2351 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2351, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2353 lang.IFn; if linked_2352 == nil { ifn_2353 = lang.IFn_Cast(root_2351) } else { ifn_2353 = nil }; var arg_2354 any = s__292000186__3; if linked_2352 == nil { c__1927001037__auto____4 = ifn_2353.Invoke_O__O(arg_2354) } else { c__1927001037__auto____4 = linked_2352.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2351, arg_2354) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000188__6 any; var root_2355 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2355, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2357 lang.IFn; if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2356 == nil { b__292000188__6 = ifn_2357.Invoke_O__O(arg_2358) } else { b__292000188__6 = linked_2356.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2355, arg_2358) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2369 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A_New_O_I_O(b__292000188__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2368 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A_fn_class; if fncls__2368 == nil { var fncls__2368d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, fnbody__2369); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A_fn_class = fncls__2368d; tmp3 = fncls__2368d } else { tmp3 = fncls__2368 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2369, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2370 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2372 lang.IFn; if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any; var root_2375 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2375, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2377 lang.IFn; if linked_2376 == nil { ifn_2377 = lang.IFn_Cast(root_2375) } else { ifn_2377 = nil }; var arg_2378 any = b__292000188__6; if linked_2376 == nil { arg_2373 = ifn_2377.Invoke_O__O(arg_2378) } else { arg_2373 = linked_2376.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2375, arg_2378) }; var arg_2374 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000185); var tmp5 any; var root_2379 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2381 lang.IFn; if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = s__292000186__3; if linked_2380 == nil { tmp5 = ifn_2381.Invoke_O__O(arg_2382) } else { tmp5 = linked_2380.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2379, arg_2382) }; arg_2374 = tmp4.Invoke_O__O(tmp5); if linked_2371 == nil { return ifn_2372.Invoke_O_O__O(arg_2373, arg_2374) } else { return linked_2371.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2370, arg_2373, arg_2374) } } else { var root_2383 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2385 lang.IFn; if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any; var root_2388 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = b__292000188__6; if linked_2389 == nil { arg_2386 = ifn_2390.Invoke_O__O(arg_2391) } else { arg_2386 = linked_2389.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2388, arg_2391) }; var arg_2387 any; if linked_2384 == nil { return ifn_2385.Invoke_O_O__O(arg_2386, arg_2387) } else { return linked_2384.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2383, arg_2386, arg_2387) } } } else { var f__4 any; var root_2392 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2392, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2394 lang.IFn; if linked_2393 == nil { ifn_2394 = lang.IFn_Cast(root_2392) } else { ifn_2394 = nil }; var arg_2395 any = s__292000186__3; if linked_2393 == nil { f__4 = ifn_2394.Invoke_O__O(arg_2395) } else { f__4 = linked_2393.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2392, arg_2395) }; var tmp6 any; var root_2396 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_2397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2396, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_2398 lang.IFn; if linked_2397 == nil { ifn_2398 = lang.IFn_Cast(root_2396) } else { ifn_2398 = nil }; var arg_2399 any = f__4; if linked_2397 == nil { tmp6 = ifn_2398.Invoke_O__O(arg_2399) } else { tmp6 = linked_2397.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_2396, arg_2399) }; if jrt.J2g_Truth(tmp6) { var root_2400 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2400, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2402 lang.IFn; if linked_2401 == nil { ifn_2402 = lang.IFn_Cast(root_2400) } else { ifn_2402 = nil }; var arg_2403 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__4)); var arg_2404 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000185); var tmp8 any; var root_2405 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2405, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2407 lang.IFn; if linked_2406 == nil { ifn_2407 = lang.IFn_Cast(root_2405) } else { ifn_2407 = nil }; var arg_2408 any = s__292000186__3; if linked_2406 == nil { tmp8 = ifn_2407.Invoke_O__O(arg_2408) } else { tmp8 = linked_2406.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2405, arg_2408) }; arg_2404 = tmp7.Invoke_O__O(tmp8); if linked_2401 == nil { return ifn_2402.Invoke_O_O__O(arg_2403, arg_2404) } else { return linked_2401.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2400, arg_2403, arg_2404) } } else { var tmp9 any; var root_2409 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2409, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2411 lang.IFn; if linked_2410 == nil { ifn_2411 = lang.IFn_Cast(root_2409) } else { ifn_2411 = nil }; var arg_2412 any = s__292000186__3; if linked_2410 == nil { tmp9 = ifn_2411.Invoke_O__O(arg_2412) } else { tmp9 = linked_2410.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2409, arg_2412) }; s__292000186__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :493:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A) Ctor_O_I_O(c__b__292000188 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000188 = c__b__292000188; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A) Invoke_O__O(self any) any { { var i__292000187__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000187__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000187__1)); var tmp2 any; var root_2359 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any = f__2; if linked_2360 == nil { tmp2 = ifn_2361.Invoke_O__O(arg_2362) } else { tmp2 = linked_2360.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_2359, arg_2362) }; if jrt.J2g_Truth(tmp2) { var root_2363 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any = t.F_b__292000188; var arg_2367 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__2)); if linked_2364 == nil { ifn_2365.Invoke_O_O__O(arg_2366, arg_2367) } else { linked_2364.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2363, arg_2366, arg_2367) }; i__292000187__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000187__1); continue L1 } else { i__292000187__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000187__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :493:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A{}; t.Ctor(); return t }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A) Ctor() {}
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A) Invoke_O_O__O(self, s__292000220__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2783 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A_New_O_O(s__292000220__1, self); var tmp2 *jrt.Class; var fncls__2782 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A_fn_class; if fncls__2782 == nil { var fncls__2782d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, fnbody__2783); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A_fn_class = fncls__2782d; tmp2 = fncls__2782d } else { tmp2 = fncls__2782 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2783, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :493:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A{}; t.Ctor_O_O(p0, p1); return t }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A) Ctor_O_O(c__s__292000220, c__iter__292000219 any) { t.F_s__292000220 = c__s__292000220; t.F_iter__292000219 = c__iter__292000219 }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A) Invoke_O__O(self any) any { { var s__292000220__1 any; var t_ any = t.F_s__292000220; t.F_s__292000220 = nil; s__292000220__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2712 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2712, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2714 lang.IFn; if linked_2713 == nil { ifn_2714 = lang.IFn_Cast(root_2712) } else { ifn_2714 = nil }; var arg_2715 any = s__292000220__1; if linked_2713 == nil { temp__1927000414__auto____2 = ifn_2714.Invoke_O__O(arg_2715) } else { temp__1927000414__auto____2 = linked_2713.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2712, arg_2715) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000220__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2716 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2718 lang.IFn; if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = s__292000220__3; if linked_2717 == nil { tmp1 = ifn_2718.Invoke_O__O(arg_2719) } else { tmp1 = linked_2717.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2716, arg_2719) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2720 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2720, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2722 lang.IFn; if linked_2721 == nil { ifn_2722 = lang.IFn_Cast(root_2720) } else { ifn_2722 = nil }; var arg_2723 any = s__292000220__3; if linked_2721 == nil { c__1927001037__auto____4 = ifn_2722.Invoke_O__O(arg_2723) } else { c__1927001037__auto____4 = linked_2721.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2720, arg_2723) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000222__6 any; var root_2724 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2724, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2726 lang.IFn; if linked_2725 == nil { ifn_2726 = lang.IFn_Cast(root_2724) } else { ifn_2726 = nil }; var arg_2727 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2725 == nil { b__292000222__6 = ifn_2726.Invoke_O__O(arg_2727) } else { b__292000222__6 = linked_2725.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2724, arg_2727) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2738 any = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A_New_O_I_O(b__292000222__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2737 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A_fn_class; if fncls__2737 == nil { var fncls__2737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__2738); A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A_fn_class = fncls__2737d; tmp3 = fncls__2737d } else { tmp3 = fncls__2737 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2738, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2739 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2739, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2741 lang.IFn; if linked_2740 == nil { ifn_2741 = lang.IFn_Cast(root_2739) } else { ifn_2741 = nil }; var arg_2742 any; var root_2744 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2744, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2746 lang.IFn; if linked_2745 == nil { ifn_2746 = lang.IFn_Cast(root_2744) } else { ifn_2746 = nil }; var arg_2747 any = b__292000222__6; if linked_2745 == nil { arg_2742 = ifn_2746.Invoke_O__O(arg_2747) } else { arg_2742 = linked_2745.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2744, arg_2747) }; var arg_2743 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000219); var tmp5 any; var root_2748 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2748, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2750 lang.IFn; if linked_2749 == nil { ifn_2750 = lang.IFn_Cast(root_2748) } else { ifn_2750 = nil }; var arg_2751 any = s__292000220__3; if linked_2749 == nil { tmp5 = ifn_2750.Invoke_O__O(arg_2751) } else { tmp5 = linked_2749.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2748, arg_2751) }; arg_2743 = tmp4.Invoke_O__O(tmp5); if linked_2740 == nil { return ifn_2741.Invoke_O_O__O(arg_2742, arg_2743) } else { return linked_2740.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2739, arg_2742, arg_2743) } } else { var root_2752 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any; var root_2757 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2757, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2759 lang.IFn; if linked_2758 == nil { ifn_2759 = lang.IFn_Cast(root_2757) } else { ifn_2759 = nil }; var arg_2760 any = b__292000222__6; if linked_2758 == nil { arg_2755 = ifn_2759.Invoke_O__O(arg_2760) } else { arg_2755 = linked_2758.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2757, arg_2760) }; var arg_2756 any; if linked_2753 == nil { return ifn_2754.Invoke_O_O__O(arg_2755, arg_2756) } else { return linked_2753.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2752, arg_2755, arg_2756) } } } else { var f__4 any; var root_2761 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2761, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2763 lang.IFn; if linked_2762 == nil { ifn_2763 = lang.IFn_Cast(root_2761) } else { ifn_2763 = nil }; var arg_2764 any = s__292000220__3; if linked_2762 == nil { f__4 = ifn_2763.Invoke_O__O(arg_2764) } else { f__4 = linked_2762.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2761, arg_2764) }; var tmp6 any; var root_2765 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_2766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2765, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_2767 lang.IFn; if linked_2766 == nil { ifn_2767 = lang.IFn_Cast(root_2765) } else { ifn_2767 = nil }; var arg_2768 any = f__4; if linked_2766 == nil { tmp6 = ifn_2767.Invoke_O__O(arg_2768) } else { tmp6 = linked_2766.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_2765, arg_2768) }; if jrt.J2g_Truth(tmp6) { var root_2769 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2769, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2771 lang.IFn; if linked_2770 == nil { ifn_2771 = lang.IFn_Cast(root_2769) } else { ifn_2771 = nil }; var arg_2772 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__4)); var arg_2773 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000219); var tmp8 any; var root_2774 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2774, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2776 lang.IFn; if linked_2775 == nil { ifn_2776 = lang.IFn_Cast(root_2774) } else { ifn_2776 = nil }; var arg_2777 any = s__292000220__3; if linked_2775 == nil { tmp8 = ifn_2776.Invoke_O__O(arg_2777) } else { tmp8 = linked_2775.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2774, arg_2777) }; arg_2773 = tmp7.Invoke_O__O(tmp8); if linked_2770 == nil { return ifn_2771.Invoke_O_O__O(arg_2772, arg_2773) } else { return linked_2770.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2769, arg_2772, arg_2773) } } else { var tmp9 any; var root_2778 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2778, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2780 lang.IFn; if linked_2779 == nil { ifn_2780 = lang.IFn_Cast(root_2778) } else { ifn_2780 = nil }; var arg_2781 any = s__292000220__3; if linked_2779 == nil { tmp9 = ifn_2780.Invoke_O__O(arg_2781) } else { tmp9 = linked_2779.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2778, arg_2781) }; s__292000220__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :493:1
func A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A) Ctor_O_I_O(c__b__292000222 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000222 = c__b__292000222; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :493:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A) Invoke_O__O(self any) any { { var i__292000221__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000221__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000221__1)); var tmp2 any; var root_2728 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_2729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2728, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_2730 lang.IFn; if linked_2729 == nil { ifn_2730 = lang.IFn_Cast(root_2728) } else { ifn_2730 = nil }; var arg_2731 any = f__2; if linked_2729 == nil { tmp2 = ifn_2730.Invoke_O__O(arg_2731) } else { tmp2 = linked_2729.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_2728, arg_2731) }; if jrt.J2g_Truth(tmp2) { var root_2732 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2732, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2734 lang.IFn; if linked_2733 == nil { ifn_2734 = lang.IFn_Cast(root_2732) } else { ifn_2734 = nil }; var arg_2735 any = t.F_b__292000222; var arg_2736 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__2)); if linked_2733 == nil { ifn_2734.Invoke_O_O__O(arg_2735, arg_2736) } else { linked_2733.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2732, arg_2735, arg_2736) }; i__292000221__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000221__1); continue L1 } else { i__292000221__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000221__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_dyncf_generics_text_A_New() *A_arbace_j2g_dyncf_generics_text_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Ctor() {}
//line :502:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Invoke_O_O__O(self, T__0_ any) any { var extendable__2 any; var root_2850 any = A_arbace_j2g_dyncf_A_const_434.GetRawRoot__O(); var linked_2851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2850, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2852 lang.IFn; if





	linked_2851 == nil { ifn_2852 = lang.IFn_Cast(root_2850) } else { ifn_2852 = nil }; var arg_2853 any; var root_2854 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_2855 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2854, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2856 lang.IFn; if linked_2855 == nil { ifn_2856 = lang.IFn_Cast(root_2854) } else { ifn_2856 = nil }; var arg_2857 any = A_arbace_j2g_dyncf_A_const_435.GetRawRoot__O(); var arg_2858 any = A_arbace_j2g_dyncf_A_const_436; if linked_2855 == nil { arg_2853 = ifn_2856.Invoke_O_O__O(arg_2857, arg_2858) } else { arg_2853 = linked_2855.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2854, arg_2857, arg_2858) }; if linked_2851 == nil { extendable__2 = ifn_2852.Invoke_O__O(arg_2853) } else { extendable__2 = linked_2851.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2850, arg_2853) }; var hw_entries__3 any; var root_2859 any = /*line :502:1*/A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2859, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2861 lang.IFn; if











	linked_2860 == nil { ifn_2861 = lang.IFn_Cast(root_2859) } else { ifn_2861 = nil }; var arg_2862 any; var iter__1927001039__auto____3 any; var fnbody__3174 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A_New(); var tmp1 *jrt.Class; var fncls__3173 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A_fn_class; if fncls__3173 == nil { var fncls__3173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A_fn_class = fncls__3173d; tmp1 = fncls__3173d } else { tmp1 = fncls__3173 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3174, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_3175 any = A_arbace_j2g_dyncf_A_const_426.GetRawRoot__O(); var linked_3176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3175, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3177 lang.IFn; if linked_3176 == nil { ifn_3177 = lang.IFn_Cast(root_3175) } else { ifn_3177 = nil }; var arg_3178 any; var root_3179 any = A_arbace_j2g_dyncf_A_const_427.GetRawRoot__O(); var linked_3180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3179, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_3181 lang.IFn; if linked_3180 == nil { ifn_3181 = lang.IFn_Cast(root_3179) } else { ifn_3181 = nil }; var arg_3182 any = A_arbace_j2g_dyncf_A_const_435.GetRawRoot__O(); if linked_3180 == nil { arg_3178 = ifn_3181.Invoke_O__O(arg_3182) } else { arg_3178 = linked_3180.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_3179, arg_3182) }; if linked_3176 == nil { tmp3 = ifn_3177.Invoke_O__O(arg_3178) } else { tmp3 = linked_3176.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3175, arg_3178) }; arg_2862 = tmp2.Invoke_O__O(tmp3); if linked_2860 == nil { hw_entries__3 = ifn_2861.Invoke_O__O(arg_2862) } else { hw_entries__3 = linked_2860.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2859, arg_2862) }; var entries__4 any; var iter__1927001039__auto____4 any; var fnbody__3744 any = /*line :502:1*/A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A_New_O(extendable__2); var tmp4 *jrt.Class; var fncls__3743 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A_fn_class; if




















	fncls__3743 == nil { var fncls__3743d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__3744); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A_fn_class = fncls__3743d; tmp4 = fncls__3743d } else { tmp4 = fncls__3743 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3744, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp6 any; var root_4729 any = A_arbace_j2g_dyncf_A_const_426.GetRawRoot__O(); var linked_4730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4729, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4731 lang.IFn; if linked_4730 == nil { ifn_4731 = lang.IFn_Cast(root_4729) } else { ifn_4731 = nil }; var arg_4732 any = T__0_; if linked_4730 == nil { tmp6 = ifn_4731.Invoke_O__O(arg_4732) } else { tmp6 = linked_4730.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4729, arg_4732) }; entries__4 = tmp5.Invoke_O__O(tmp6); var consts__5 any; var iter__1927001039__auto____5 any; var fnbody__4116 any = /*line :502:1*/A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A_New(); var tmp7 *jrt.Class; var fncls__4115 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A_fn_class; if












































	fncls__4115 == nil { var fncls__4115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A_fn_class = fncls__4115d; tmp7 = fncls__4115d } else { tmp7 = fncls__4115 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4116, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp9 any; var root_4733 any = A_arbace_j2g_dyncf_A_const_426.GetRawRoot__O(); var linked_4734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4733, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4735 lang.IFn; if linked_4734 == nil { ifn_4735 = lang.IFn_Cast(root_4733) } else { ifn_4735 = nil }; var arg_4736 any = T__0_; if linked_4734 == nil { tmp9 = ifn_4735.Invoke_O__O(arg_4736) } else { tmp9 = linked_4734.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4733, arg_4736) }; consts__5 = tmp8.Invoke_O__O(tmp9); var tset__6 any; var root_4117 any = /*line :502:1*/A_arbace_j2g_dyncf_A_const_434.GetRawRoot__O(); var linked_4118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4117, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_4119 lang.IFn; if




























































	linked_4118 == nil { ifn_4119 = lang.IFn_Cast(root_4117) } else { ifn_4119 = nil }; var arg_4120 any = T__0_; if linked_4118 == nil { tset__6 = ifn_4119.Invoke_O__O(arg_4120) } else { tset__6 = linked_4118.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_4117, arg_4120) }; var edge_consts__7 any; var iter__1927001039__auto____7 any; var fnbody__4452 any = /*line :502:1*/A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A_New_O(tset__6); var tmp10 *jrt.Class; var fncls__4451 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A_fn_class; if





























































	fncls__4451 == nil { var fncls__4451d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__4452); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A_fn_class = fncls__4451d; tmp10 = fncls__4451d } else { tmp10 = fncls__4451 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4452, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp12 any; var root_4737 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_4738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4737, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_4739 lang.IFn; if linked_4738 == nil { ifn_4739 = lang.IFn_Cast(root_4737) } else { ifn_4739 = nil }; var arg_4740 any = A_arbace_j2g_dyncf_A_const_473.GetRawRoot__O(); var tmp13 *lang.Keyword = A_arbace_j2g_dyncf_A_const_474; var arg_4741 any = tmp13.Invoke_O__O(A_arbace_j2g_dyncf_A_const_475.Get__O()); if linked_4738 == nil { tmp12 = ifn_4739.Invoke_O_O__O(arg_4740, arg_4741) } else { tmp12 = linked_4738.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_4737, arg_4740, arg_4741) }; edge_consts__7 = tmp11.Invoke_O__O(tmp12); var consts__8 any; var root_4453 any = /*line :502:1*/A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_4454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4453, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_4455 lang.IFn; if









































































	linked_4454 == nil { ifn_4455 = lang.IFn_Cast(root_4453) } else { ifn_4455 = nil }; var arg_4456 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var arg_4457 any; var root_4458 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_4459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4458, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4460 lang.IFn; if linked_4459 == nil { ifn_4460 = lang.IFn_Cast(root_4458) } else { ifn_4460 = nil }; var arg_4461 any = consts__5; var arg_4462 any = edge_consts__7; if linked_4459 == nil { arg_4457 = ifn_4460.Invoke_O_O__O(arg_4461, arg_4462) } else { arg_4457 = linked_4459.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4458, arg_4461, arg_4462) }; if linked_4454 == nil { consts__8 = ifn_4455.Invoke_O_O__O(arg_4456, arg_4457) } else { consts__8 = linked_4454.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_4453, arg_4456, arg_4457) }; var protected__9 any; var root_4463 any = /*line :502:1*/A_arbace_j2g_dyncf_A_const_470.GetRawRoot__O(); var linked_4464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4463, A_arbace_j2g_dyncf_protected_members_A_fn_class); var ifn_4465 lang.IFn; if














































































	linked_4464 == nil { ifn_4465 = lang.IFn_Cast(root_4463) } else { ifn_4465 = nil }; var arg_4466 any = T__0_; if linked_4464 == nil { protected__9 = ifn_4465.Invoke_O__O(arg_4466) } else { protected__9 = linked_4464.(*A_arbace_j2g_dyncf_protected_members_A).Invoke_O_O__O(root_4463, arg_4466) }; var root_4742 any =
	A_arbace_j2g_dyncf_A_const_39.GetRawRoot__O(); var linked_4743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4742, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4744 lang.IFn; if linked_4743 == nil { ifn_4744 = lang.IFn_Cast(root_4742) } else { ifn_4744 = nil }; var arg_4745 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_476, nil, A_arbace_j2g_dyncf_A_const_477, nil, A_arbace_j2g_dyncf_A_const_478, jrt.Boolean_FALSE.Ref()); if linked_4743 == nil { ifn_4744.Invoke_O__O(arg_4745) } else { linked_4743.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4742, arg_4745) }; var tmp14 any; tmp26 := /*line :502:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
















































































		{ var tmp15 *jrt.RefArray = jrt.ConstRefArray("[0,9,s92:;; Written by j2g --program (arbace.j2g.dyncf/generics-text): the generic signatures of the\ns93:;; classes of the world, for the Java forms' analysis (doc/go/CLASSFORMS-REPL.md), and under\ns44:;; :consts their public constants' values.\n{ns11:\n :consts {ns15:}\n :protected {ns3:}}\n", []*jrt.Class{jrt.String_class}); var tmp16 any; var root_4467 any = A_arbace_j2g_dyncf_A_const_471.GetRawRoot__O(); var linked_4468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4467, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_4469 lang.IFn


			if linked_4468 == nil { ifn_4469 = lang.IFn_Cast(root_4467) } else { ifn_4469 = nil }; var arg_4470 any = Lit_44; var arg_4471 any; var iter__1927001039__auto____21 any; var fnbody__4549 any = A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A_New(); var tmp17 *jrt.Class; var fncls__4548 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A_fn_class; if fncls__4548 == nil { var fncls__4548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A_fn_class = fncls__4548d; tmp17 = fncls__4548d } else { tmp17 = fncls__4548 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4549, tmp17, nil); var tmp18 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____21); var tmp19 any; var root_4550 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_4551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4550, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_4552 lang.IFn; if linked_4551 == nil { ifn_4552 = lang.IFn_Cast(root_4550) } else { ifn_4552 = nil }; var arg_4553 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var arg_4554 any; var root_4555 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_4556 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4555, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4557 lang.IFn; if linked_4556 == nil { ifn_4557 = lang.IFn_Cast(root_4555) } else { ifn_4557 = nil }; var arg_4558 any = entries__4; var arg_4559 any = hw_entries__3; if linked_4556 == nil { arg_4554 = ifn_4557.Invoke_O_O__O(arg_4558, arg_4559) } else { arg_4554 = linked_4556.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4555, arg_4558, arg_4559) }; if linked_4551 == nil { tmp19 = ifn_4552.Invoke_O_O__O(arg_4553, arg_4554) } else { tmp19 = linked_4551.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_4550, arg_4553, arg_4554) }; arg_4471 = tmp18.Invoke_O__O(tmp19); if linked_4468 == nil { tmp16 = ifn_4469.Invoke_O_O__O(arg_4470, arg_4471) } else { tmp16 = linked_4468.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_4467, arg_4470, arg_4471) }
//line :583:1
			var tmp20 any = tmp16; var tmp21 any; var root_4560 any = A_arbace_j2g_dyncf_A_const_471.GetRawRoot__O(); var linked_4561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4560, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_4562 lang.IFn




			if linked_4561 == nil { ifn_4562 = lang.IFn_Cast(root_4560) } else { ifn_4562 = nil }; var arg_4563 any = Lit_46; var arg_4564 any; var iter__1927001039__auto____21_2 any; var fnbody__4642 any = A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A_New(); var tmp22 *jrt.Class; var fncls__4641 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A_fn_class; if fncls__4641 == nil { var fncls__4641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A_fn_class = fncls__4641d; tmp22 = fncls__4641d } else { tmp22 = fncls__4641 }; iter__1927001039__auto____21_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4642, tmp22, nil); arg_4564 = lang.IFn_Cast(iter__1927001039__auto____21_2).Invoke_O__O(consts__8); if linked_4561 == nil { tmp21 = ifn_4562.Invoke_O_O__O(arg_4563, arg_4564) } else { tmp21 = linked_4561.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_4560, arg_4563, arg_4564) }
//line :583:1
			var tmp23 any = tmp21; var tmp24 any; var root_4643 any = A_arbace_j2g_dyncf_A_const_471.GetRawRoot__O(); var linked_4644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4643, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_4645 lang.IFn






			if linked_4644 == nil { ifn_4645 = lang.IFn_Cast(root_4643) } else { ifn_4645 = nil }; var arg_4646 any = Lit_46; var arg_4647 any; var iter__1927001039__auto____21_3 any; var fnbody__4725 any = A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A_New(); var tmp25 *jrt.Class; var fncls__4724 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A_fn_class; if fncls__4724 == nil { var fncls__4724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A_fn_class = fncls__4724d; tmp25 = fncls__4724d } else { tmp25 = fncls__4724 }; iter__1927001039__auto____21_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4725, tmp25, nil); arg_4647 = lang.IFn_Cast(iter__1927001039__auto____21_3).Invoke_O__O(protected__9); if linked_4644 == nil { tmp24 = ifn_4645.Invoke_O_O__O(arg_4646, arg_4647) } else { tmp24 = linked_4644.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_4643, arg_4646, arg_4647) }
//line :583:1
			tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp20, nil, tmp23, nil, tmp24, nil)).Ref() }
//line :502:1
		return nil }(); var root_4726 any = A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_4727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4726, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4728 lang.IFn; if















































































	linked_4727 == nil { ifn_4728 = lang.IFn_Cast(root_4726) } else { ifn_4728 = nil }; if linked_4727 == nil { ifn_4728.Invoke__O() } else { linked_4727.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4726) }; if /*line :502:1*/ tmp26 != nil { panic(tmp26) }; return tmp14 }











func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A{}; t.Ctor(); return t }
//line :514:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A) Ctor() {}
//line :514:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A) Invoke_O_O__O(self, s__292000234__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3172 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A_New_O_O(self, s__292000234__1); var tmp2 *jrt.Class; var fncls__3171 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A_fn_class; if fncls__3171 == nil { var fncls__3171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__3172); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A_fn_class = fncls__3171d; tmp2 = fncls__3171d } else { tmp2 = fncls__3171 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3172, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :514:1
func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A{}; t.Ctor_O_O(p0, p1); return t }
//line :514:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A) Ctor_O_O(c__iter__292000233, c__s__292000234 any) { t.F_iter__292000233 = c__iter__292000233; t.F_s__292000234 = c__s__292000234 }
//line :514:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A) Invoke_O__O(self any) any { { var s__292000234__1 any; var t_ any = t.F_s__292000234; t.F_s__292000234 = nil; s__292000234__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2863 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2863, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2865 lang.IFn; if linked_2864 == nil { ifn_2865 = lang.IFn_Cast(root_2863) } else { ifn_2865 = nil }; var arg_2866 any = s__292000234__1; if linked_2864 == nil { temp__1927000414__auto____2 = ifn_2865.Invoke_O__O(arg_2866) } else { temp__1927000414__auto____2 = linked_2864.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2863, arg_2866) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000234__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2867 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2869 lang.IFn; if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any = s__292000234__3; if linked_2868 == nil { tmp1 = ifn_2869.Invoke_O__O(arg_2870) } else { tmp1 = linked_2868.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2867, arg_2870) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2871 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2871, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2873 lang.IFn; if linked_2872 == nil { ifn_2873 = lang.IFn_Cast(root_2871) } else { ifn_2873 = nil }; var arg_2874 any = s__292000234__3; if linked_2872 == nil { c__1927001037__auto____4 = ifn_2873.Invoke_O__O(arg_2874) } else { c__1927001037__auto____4 = linked_2872.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2871, arg_2874) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000236__6 any; var root_2875 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2875, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2877 lang.IFn; if linked_2876 == nil { ifn_2877 = lang.IFn_Cast(root_2875) } else { ifn_2877 = nil }; var arg_2878 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2876 == nil { b__292000236__6 = ifn_2877.Invoke_O__O(arg_2878) } else { b__292000236__6 = linked_2876.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2875, arg_2878) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3006 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A_New_O_I_O(b__292000236__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3005 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A_fn_class; if fncls__3005 == nil { var fncls__3005d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__3006); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A_fn_class = fncls__3005d; tmp3 = fncls__3005d } else { tmp3 = fncls__3005 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3006, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3007 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3007, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3009 lang.IFn; if linked_3008 == nil { ifn_3009 = lang.IFn_Cast(root_3007) } else { ifn_3009 = nil }; var arg_3010 any; var root_3012 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3012, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3014 lang.IFn; if linked_3013 == nil { ifn_3014 = lang.IFn_Cast(root_3012) } else { ifn_3014 = nil }; var arg_3015 any = b__292000236__6; if linked_3013 == nil { arg_3010 = ifn_3014.Invoke_O__O(arg_3015) } else { arg_3010 = linked_3013.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3012, arg_3015) }; var arg_3011 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000233); var tmp5 any; var root_3016 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3016, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3018 lang.IFn; if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any = s__292000234__3; if linked_3017 == nil { tmp5 = ifn_3018.Invoke_O__O(arg_3019) } else { tmp5 = linked_3017.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3016, arg_3019) }; arg_3011 = tmp4.Invoke_O__O(tmp5); if linked_3008 == nil { return ifn_3009.Invoke_O_O__O(arg_3010, arg_3011) } else { return linked_3008.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3007, arg_3010, arg_3011) } } else { var root_3020 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3020, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3022 lang.IFn; if linked_3021 == nil { ifn_3022 = lang.IFn_Cast(root_3020) } else { ifn_3022 = nil }; var arg_3023 any; var root_3025 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3025, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3027 lang.IFn; if linked_3026 == nil { ifn_3027 = lang.IFn_Cast(root_3025) } else { ifn_3027 = nil }; var arg_3028 any = b__292000236__6; if linked_3026 == nil { arg_3023 = ifn_3027.Invoke_O__O(arg_3028) } else { arg_3023 = linked_3026.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3025, arg_3028) }; var arg_3024 any; if linked_3021 == nil { return ifn_3022.Invoke_O_O__O(arg_3023, arg_3024) } else { return linked_3021.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3020, arg_3023, arg_3024) } } } else { var n__4 any; var root_3029 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3029, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3031 lang.IFn; if linked_3030 == nil { ifn_3031 = lang.IFn_Cast(root_3029) } else { ifn_3031 = nil }; var arg_3032 any = s__292000234__3; if linked_3030 == nil { n__4 = ifn_3031.Invoke_O__O(arg_3032) } else { n__4 = linked_3030.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3029, arg_3032) }; var tmp6 any; var and__1927000168__auto____5 any; var root_3033 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_3034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3033, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_3035 lang.IFn
														if linked_3034 == nil { ifn_3035 = lang.IFn_Cast(root_3033) } else { ifn_3035 = nil }; var arg_3036 any = n__4; if linked_3034 == nil { and__1927000168__auto____5 = ifn_3035.Invoke_O__O(arg_3036) } else { and__1927000168__auto____5 = linked_3034.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_3033, arg_3036) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_3037 any = A_arbace_j2g_dyncf_A_const_437.GetRawRoot__O(); var linked_3038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3037, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_3039 lang.IFn; if linked_3038 == nil { ifn_3039 = lang.IFn_Cast(root_3037) } else { ifn_3039 = nil }; var arg_3040 any = n__4; if linked_3038 == nil { tmp6 = ifn_3039.Invoke_O__O(arg_3040) } else { tmp6 = linked_3038.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_3037, arg_3040) } } else { tmp6 = and__1927000168__auto____5 }
//line :514:1
	if jrt.J2g_Truth(tmp6) { var g__5 any; var tmp7 *lang.Compiler_AOTFn; var fnbody__3042 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A_New_O(n__4); var tmp8 *jrt.Class
		var fncls__3041 /*line :514:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A_fn_class

		if fncls__3041 == nil { var fncls__3041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__3042); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A_fn_class = fncls__3041d; tmp8 = fncls__3041d } else { tmp8 = fncls__3041 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3042, tmp8, nil); g__5 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O()
//line :514:1
		var tmp9 any
		var and__1927000168__auto____6 any = g__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_3043 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3043, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3045 lang.IFn; if linked_3044 == nil { ifn_3045 = lang.IFn_Cast(root_3043) } else { ifn_3045 = nil }; var arg_3046 any = A_arbace_j2g_dyncf_A_const_439.Invoke_O__O(g__5); if linked_3044 == nil { tmp9 = ifn_3045.Invoke_O__O(arg_3046) } else { tmp9 = linked_3044.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3043, arg_3046) } } else { tmp9 = and__1927000168__auto____6 }
//line :514:1
		if jrt.J2g_Truth(tmp9) { var root_3047 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3047, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3049 lang.IFn; if linked_3048 == nil { ifn_3049 = lang.IFn_Cast(root_3047) } else { ifn_3049 = nil }; var arg_3050 any; var tmp10 any; var root_3052 any = A_arbace_j2g_dyncf_A_const_440.GetRawRoot__O(); var linked_3053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3052, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_3054 lang.IFn



			if linked_3053 == nil { ifn_3054 = lang.IFn_Cast(root_3052) } else { ifn_3054 = nil }; var arg_3055 any; var tmp11 any = A_arbace_j2g_dyncf_A_const_439; var tmp12 any; var root_3056 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3056, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3058 lang.IFn
			if linked_3057 == nil { ifn_3058 = lang.IFn_Cast(root_3056) } else { ifn_3058 = nil }; var arg_3059 any = A_arbace_j2g_dyncf_A_const_439.Invoke_O__O(g__5); if linked_3057 == nil { tmp12 = ifn_3058.Invoke_O__O(arg_3059) } else { tmp12 = linked_3057.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3056, arg_3059) }
//line :518:1
			var tmp13 any = tmp12; var tmp14 any = A_arbace_j2g_dyncf_A_const_441; var tmp15 any; var root_3060 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3060, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3062 lang.IFn
			if linked_3061 == nil { ifn_3062 = lang.IFn_Cast(root_3060) } else { ifn_3062 = nil }; var arg_3063 any; var root_3064 any = A_arbace_j2g_dyncf_A_const_442.GetRawRoot__O(); var linked_3065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3064, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3066 lang.IFn; if linked_3065 == nil { ifn_3066 = lang.IFn_Cast(root_3064) } else { ifn_3066 = nil }; var arg_3067 any = A_arbace_j2g_dyncf_A_const_443.GetRawRoot__O(); var arg_3068 any = A_arbace_j2g_dyncf_A_const_441.Invoke_O__O(g__5); if linked_3065 == nil { arg_3063 = ifn_3066.Invoke_O_O__O(arg_3067, arg_3068) } else { arg_3063 = linked_3065.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3064, arg_3067, arg_3068) }; if linked_3061 == nil { tmp15 = ifn_3062.Invoke_O__O(arg_3063) } else { tmp15 = linked_3061.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3060, arg_3063) }
//line :518:1
			var tmp16 any = tmp15; var tmp17 any = A_arbace_j2g_dyncf_A_const_108; var tmp18 any; var root_3069 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3069, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3071 lang.IFn

			if linked_3070 == nil { ifn_3071 = lang.IFn_Cast(root_3069) } else { ifn_3071 = nil }; var arg_3072 any; var iter__1927001039__auto____6 any; var fnbody__3158 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A_New(); var tmp19 *jrt.Class; var fncls__3157 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A_fn_class; if fncls__3157 == nil { var fncls__3157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A_fn_class = fncls__3157d; tmp19 = fncls__3157d } else { tmp19 = fncls__3157 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3158, tmp19, nil); arg_3072 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__5)); if linked_3070 == nil { tmp18 = ifn_3071.Invoke_O__O(arg_3072) } else { tmp18 = linked_3070.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3069, arg_3072) }
//line :518:1
			arg_3055 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp14, tmp16, tmp17, tmp18)); if linked_3053 == nil { tmp10 = ifn_3054.Invoke_O__O(arg_3055) } else { tmp10 = linked_3053.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_3052, arg_3055) }
//line :514:1
			arg_3050 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp10); var arg_3051 any; var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__292000233); var tmp21 any; var root_3159 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3159, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3161 lang.IFn; if linked_3160 == nil { ifn_3161 = lang.IFn_Cast(root_3159) } else { ifn_3161 = nil }; var arg_3162 any = s__292000234__3; if linked_3160 == nil { tmp21 = ifn_3161.Invoke_O__O(arg_3162) } else { tmp21 = linked_3160.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3159, arg_3162) }; arg_3051 = tmp20.Invoke_O__O(tmp21); if linked_3048 == nil { return ifn_3049.Invoke_O_O__O(arg_3050, arg_3051) } else { return linked_3048.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3047, arg_3050, arg_3051) } } else { var tmp22 any; var root_3163 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3163, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3165 lang.IFn; if linked_3164 == nil { ifn_3165 = lang.IFn_Cast(root_3163) } else { ifn_3165 = nil }; var arg_3166 any = s__292000234__3; if linked_3164 == nil { tmp22 = ifn_3165.Invoke_O__O(arg_3166) } else { tmp22 = linked_3164.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3163, arg_3166) }; s__292000234__1 = tmp22; continue L1 } } else { var tmp23 any; var root_3167 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3167, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3169 lang.IFn; if linked_3168 == nil { ifn_3169 = lang.IFn_Cast(root_3167) } else { ifn_3169 = nil }; var arg_3170 any = s__292000234__3; if linked_3168 == nil { tmp23 = ifn_3169.Invoke_O__O(arg_3170) } else { tmp23 = linked_3168.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3167, arg_3170) }; s__292000234__1 = tmp23; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :514:1
func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :514:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A) Ctor_O_I_O(c__b__292000236 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000236 = c__b__292000236; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :514:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A) Invoke_O__O(self any) any { { var i__292000235__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000235__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000235__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2879 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_2880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2879, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2881 lang.IFn
																if linked_2880 == nil { ifn_2881 = lang.IFn_Cast(root_2879) } else { ifn_2881 = nil }; var arg_2882 any = n__2; if linked_2880 == nil { and__1927000168__auto____3 = ifn_2881.Invoke_O__O(arg_2882) } else { and__1927000168__auto____3 = linked_2880.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2879, arg_2882) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2883 any = A_arbace_j2g_dyncf_A_const_437.GetRawRoot__O(); var linked_2884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2883, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_2885 lang.IFn; if linked_2884 == nil { ifn_2885 = lang.IFn_Cast(root_2883) } else { ifn_2885 = nil }; var arg_2886 any = n__2; if linked_2884 == nil { tmp2 = ifn_2885.Invoke_O__O(arg_2886) } else { tmp2 = linked_2884.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_2883, arg_2886) } } else { tmp2 = and__1927000168__auto____3 }
//line :514:1
	if jrt.J2g_Truth(tmp2) { var g__3 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__2888 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A_New_O(n__2); var tmp4 *jrt.Class
		var fncls__2887 /*line :514:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A_fn_class

		if fncls__2887 == nil { var fncls__2887d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__2888); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A_fn_class = fncls__2887d; tmp4 = fncls__2887d } else { tmp4 = fncls__2887 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2888, tmp4, nil); g__3 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()
//line :514:1
		var tmp5 any
		var and__1927000168__auto____4 any = g__3

		if jrt.J2g_Truth(and__1927000168__auto____4) { var root_2889 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2891 lang.IFn; if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = A_arbace_j2g_dyncf_A_const_439.Invoke_O__O(g__3); if linked_2890 == nil { tmp5 = ifn_2891.Invoke_O__O(arg_2892) } else { tmp5 = linked_2890.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2889, arg_2892) } } else { tmp5 = and__1927000168__auto____4 }
//line :514:1
		if jrt.J2g_Truth(tmp5) { var root_2893 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2893, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2895 lang.IFn; if linked_2894 == nil { ifn_2895 = lang.IFn_Cast(root_2893) } else { ifn_2895 = nil }; var arg_2896 any = t.F_b__292000236; var arg_2897 any; var tmp6 any; var root_2898 any = A_arbace_j2g_dyncf_A_const_440.GetRawRoot__O(); var linked_2899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2898, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_2900 lang.IFn



			if linked_2899 == nil { ifn_2900 = lang.IFn_Cast(root_2898) } else { ifn_2900 = nil }; var arg_2901 any; var tmp7 any = A_arbace_j2g_dyncf_A_const_439; var tmp8 any; var root_2902 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2902, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2904 lang.IFn
			if linked_2903 == nil { ifn_2904 = lang.IFn_Cast(root_2902) } else { ifn_2904 = nil }; var arg_2905 any = A_arbace_j2g_dyncf_A_const_439.Invoke_O__O(g__3); if linked_2903 == nil { tmp8 = ifn_2904.Invoke_O__O(arg_2905) } else { tmp8 = linked_2903.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2902, arg_2905) }
//line :518:1
			var tmp9 any = tmp8; var tmp10 any = A_arbace_j2g_dyncf_A_const_441; var tmp11 any; var root_2906 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2906, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2908 lang.IFn
			if linked_2907 == nil { ifn_2908 = lang.IFn_Cast(root_2906) } else { ifn_2908 = nil }; var arg_2909 any; var root_2910 any = A_arbace_j2g_dyncf_A_const_442.GetRawRoot__O(); var linked_2911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2910, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2912 lang.IFn; if linked_2911 == nil { ifn_2912 = lang.IFn_Cast(root_2910) } else { ifn_2912 = nil }; var arg_2913 any = A_arbace_j2g_dyncf_A_const_443.GetRawRoot__O(); var arg_2914 any = A_arbace_j2g_dyncf_A_const_441.Invoke_O__O(g__3); if linked_2911 == nil { arg_2909 = ifn_2912.Invoke_O_O__O(arg_2913, arg_2914) } else { arg_2909 = linked_2911.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2910, arg_2913, arg_2914) }; if linked_2907 == nil { tmp11 = ifn_2908.Invoke_O__O(arg_2909) } else { tmp11 = linked_2907.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2906, arg_2909) }
//line :518:1
			var tmp12 any = tmp11; var tmp13 any = A_arbace_j2g_dyncf_A_const_108; var tmp14 any; var root_2915 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_2916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2915, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2917 lang.IFn

			if linked_2916 == nil { ifn_2917 = lang.IFn_Cast(root_2915) } else { ifn_2917 = nil }; var arg_2918 any; var iter__1927001039__auto____4 any; var fnbody__3004 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A_New(); var tmp15 *jrt.Class; var fncls__3003 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A_fn_class; if fncls__3003 == nil { var fncls__3003d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A_fn_class = fncls__3003d; tmp15 = fncls__3003d } else { tmp15 = fncls__3003 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3004, tmp15, nil); arg_2918 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__3)); if linked_2916 == nil { tmp14 = ifn_2917.Invoke_O__O(arg_2918) } else { tmp14 = linked_2916.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2915, arg_2918) }
//line :518:1
			arg_2901 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, tmp10, tmp12, tmp13, tmp14)); if linked_2899 == nil { tmp6 = ifn_2900.Invoke_O__O(arg_2901) } else { tmp6 = linked_2899.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_2898, arg_2901) }
//line :514:1
			arg_2897 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp6); if linked_2894 == nil { ifn_2895.Invoke_O_O__O(arg_2896, arg_2897) } else { linked_2894.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2893, arg_2896, arg_2897) }; i__292000235__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000235__1); continue L1 } else { i__292000235__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000235__1); continue L1 } } else { i__292000235__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000235__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A{}; t.Ctor_O(p0); return t }
//line :516:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :516:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_438; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :516:1
func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A{}; t.Ctor_O(p0); return t }
//line :516:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :516:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_438; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }



func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A{}; t.Ctor(); return t }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A) Ctor() {}
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A) Invoke_O_O__O(self, s__292000243__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3002 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A_New_O_O(self, s__292000243__1); var tmp2 *jrt.Class; var fncls__3001 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A_fn_class; if fncls__3001 == nil { var fncls__3001d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__3002); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A_fn_class = fncls__3001d; tmp2 = fncls__3001d } else { tmp2 = fncls__3001 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3002, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :520:1
func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A{}; t.Ctor_O_O(p0, p1); return t }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A) Ctor_O_O(c__iter__292000242, c__s__292000243 any) { t.F_iter__292000242 = c__iter__292000242; t.F_s__292000243 = c__s__292000243 }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A) Invoke_O__O(self any) any { { var s__292000243__1 any; var t_ any = t.F_s__292000243; t.F_s__292000243 = nil; s__292000243__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2919 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2919, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2921 lang.IFn; if linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any = s__292000243__1; if linked_2920 == nil { temp__1927000414__auto____2 = ifn_2921.Invoke_O__O(arg_2922) } else { temp__1927000414__auto____2 = linked_2920.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2919, arg_2922) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000243__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2923 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2923, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2925 lang.IFn; if linked_2924 == nil { ifn_2925 = lang.IFn_Cast(root_2923) } else { ifn_2925 = nil }; var arg_2926 any = s__292000243__3; if linked_2924 == nil { tmp1 = ifn_2925.Invoke_O__O(arg_2926) } else { tmp1 = linked_2924.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2923, arg_2926) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2927 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2927, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2929 lang.IFn; if linked_2928 == nil { ifn_2929 = lang.IFn_Cast(root_2927) } else { ifn_2929 = nil }; var arg_2930 any = s__292000243__3; if linked_2928 == nil { c__1927001037__auto____4 = ifn_2929.Invoke_O__O(arg_2930) } else { c__1927001037__auto____4 = linked_2928.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2927, arg_2930) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000245__6 any; var root_2931 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2931, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2933 lang.IFn; if linked_2932 == nil { ifn_2933 = lang.IFn_Cast(root_2931) } else { ifn_2933 = nil }; var arg_2934 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2932 == nil { b__292000245__6 = ifn_2933.Invoke_O__O(arg_2934) } else { b__292000245__6 = linked_2932.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2931, arg_2934) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2951 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A_New_O_I_O(b__292000245__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2950 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A_fn_class; if fncls__2950 == nil { var fncls__2950d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__2951); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A_fn_class = fncls__2950d; tmp3 = fncls__2950d } else { tmp3 = fncls__2950 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2951, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2952 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2952, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2954 lang.IFn; if linked_2953 == nil { ifn_2954 = lang.IFn_Cast(root_2952) } else { ifn_2954 = nil }; var arg_2955 any; var root_2957 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2957, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2959 lang.IFn; if linked_2958 == nil { ifn_2959 = lang.IFn_Cast(root_2957) } else { ifn_2959 = nil }; var arg_2960 any = b__292000245__6; if linked_2958 == nil { arg_2955 = ifn_2959.Invoke_O__O(arg_2960) } else { arg_2955 = linked_2958.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2957, arg_2960) }; var arg_2956 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000242); var tmp5 any; var root_2961 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2961, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2963 lang.IFn; if linked_2962 == nil { ifn_2963 = lang.IFn_Cast(root_2961) } else { ifn_2963 = nil }; var arg_2964 any = s__292000243__3; if linked_2962 == nil { tmp5 = ifn_2963.Invoke_O__O(arg_2964) } else { tmp5 = linked_2962.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2961, arg_2964) }; arg_2956 = tmp4.Invoke_O__O(tmp5); if linked_2953 == nil { return ifn_2954.Invoke_O_O__O(arg_2955, arg_2956) } else { return linked_2953.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2952, arg_2955, arg_2956) } } else { var root_2965 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2965, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2967 lang.IFn; if linked_2966 == nil { ifn_2967 = lang.IFn_Cast(root_2965) } else { ifn_2967 = nil }; var arg_2968 any; var root_2970 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2970, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2972 lang.IFn; if linked_2971 == nil { ifn_2972 = lang.IFn_Cast(root_2970) } else { ifn_2972 = nil }; var arg_2973 any = b__292000245__6; if linked_2971 == nil { arg_2968 = ifn_2972.Invoke_O__O(arg_2973) } else { arg_2968 = linked_2971.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2970, arg_2973) }; var arg_2969 any; if linked_2966 == nil { return ifn_2967.Invoke_O_O__O(arg_2968, arg_2969) } else { return linked_2966.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2965, arg_2968, arg_2969) } } } else { var mm__4 any; var root_2974 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2974, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2976 lang.IFn; if linked_2975 == nil { ifn_2976 = lang.IFn_Cast(root_2974) } else { ifn_2976 = nil }; var arg_2977 any = s__292000243__3; if linked_2975 == nil { mm__4 = ifn_2976.Invoke_O__O(arg_2977) } else { mm__4 = linked_2975.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2974, arg_2977) }; var tmp6 int64; var na_2978 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { na_2978 = or__1927000174__auto____5 } else { na_2978 = A_arbace_j2g_dyncf_A_const_206 }; var na_2979 int64 = 4098; if jrt.Long_InstanceOf(na_2978) { var n0_2980 int64 = jrt.NN(jrt.Long_Cast(na_2978)).LongValue__J(); var n1_2981 int64 = na_2979; tmp6 = n0_2980 & n1_2981 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_2978, na_2979) }
//line :520:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_2983 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2983, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2985 lang.IFn; if linked_2984 == nil { ifn_2985 = lang.IFn_Cast(root_2983) } else { ifn_2985 = nil }; var arg_2986 any; var root_2988 any = A_arbace_j2g_dyncf_A_const_444.GetRawRoot__O(); var linked_2989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2988, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2990 lang.IFn

		if linked_2989 == nil { ifn_2990 = lang.IFn_Cast(root_2988) } else { ifn_2990 = nil }; var arg_2991 any = mm__4; var arg_2992 any = A_arbace_j2g_dyncf_A_const_446; if linked_2989 == nil { arg_2986 = ifn_2990.Invoke_O_O__O(arg_2991, arg_2992) } else { arg_2986 = linked_2989.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2988, arg_2991, arg_2992) }
//line :520:1
		var arg_2987 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000242); var tmp8 any; var root_2993 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2993, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2995 lang.IFn; if linked_2994 == nil { ifn_2995 = lang.IFn_Cast(root_2993) } else { ifn_2995 = nil }; var arg_2996 any = s__292000243__3; if linked_2994 == nil { tmp8 = ifn_2995.Invoke_O__O(arg_2996) } else { tmp8 = linked_2994.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2993, arg_2996) }; arg_2987 = tmp7.Invoke_O__O(tmp8); if linked_2984 == nil { return ifn_2985.Invoke_O_O__O(arg_2986, arg_2987) } else { return linked_2984.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2983, arg_2986, arg_2987) } } else { var tmp9 any; var root_2997 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2999 lang.IFn; if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any = s__292000243__3; if linked_2998 == nil { tmp9 = ifn_2999.Invoke_O__O(arg_3000) } else { tmp9 = linked_2998.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2997, arg_3000) }; s__292000243__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :520:1
func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A) Ctor_O_I_O(c__b__292000245 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000245 = c__b__292000245; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A) Invoke_O__O(self any) any { { var i__292000244__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000244__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000244__1)); var tmp2 int64; var na_2935 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { na_2935 = or__1927000174__auto____3 } else { na_2935 = A_arbace_j2g_dyncf_A_const_206 }; var na_2936 int64 = 4098; if jrt.Long_InstanceOf(na_2935) { var n0_2937 int64 = jrt.NN(jrt.Long_Cast(na_2935)).LongValue__J(); var n1_2938 int64 = na_2936; tmp2 = n0_2937 & n1_2938 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_2935, na_2936) }
//line :520:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_2940 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2940, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2942 lang.IFn; if linked_2941 == nil { ifn_2942 = lang.IFn_Cast(root_2940) } else { ifn_2942 = nil }; var arg_2943 any = t.F_b__292000245; var arg_2944 any; var root_2945 any = A_arbace_j2g_dyncf_A_const_444.GetRawRoot__O(); var linked_2946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2945, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2947 lang.IFn

		if linked_2946 == nil { ifn_2947 = lang.IFn_Cast(root_2945) } else { ifn_2947 = nil }; var arg_2948 any = mm__2; var arg_2949 any = A_arbace_j2g_dyncf_A_const_445; if linked_2946 == nil { arg_2944 = ifn_2947.Invoke_O_O__O(arg_2948, arg_2949) } else { arg_2944 = linked_2946.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2945, arg_2948, arg_2949) }
//line :520:1
		if linked_2941 == nil { ifn_2942.Invoke_O_O__O(arg_2943, arg_2944) } else { linked_2941.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2940, arg_2943, arg_2944) }; i__292000244__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000244__1); continue L1 } else { i__292000244__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000244__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :520:1
func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A{}; t.Ctor(); return t }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A) Ctor() {}
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A) Invoke_O_O__O(self, s__292000256__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3156 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A_New_O_O(self, s__292000256__1); var tmp2 *jrt.Class; var fncls__3155 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A_fn_class; if fncls__3155 == nil { var fncls__3155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__3156); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A_fn_class = fncls__3155d; tmp2 = fncls__3155d } else { tmp2 = fncls__3155 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3156, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :520:1
func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A{}; t.Ctor_O_O(p0, p1); return t }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A) Ctor_O_O(c__iter__292000255, c__s__292000256 any) { t.F_iter__292000255 = c__iter__292000255; t.F_s__292000256 = c__s__292000256 }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A) Invoke_O__O(self any) any { { var s__292000256__1 any; var t_ any = t.F_s__292000256; t.F_s__292000256 = nil; s__292000256__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3073 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3073, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3075 lang.IFn; if linked_3074 == nil { ifn_3075 = lang.IFn_Cast(root_3073) } else { ifn_3075 = nil }; var arg_3076 any = s__292000256__1; if linked_3074 == nil { temp__1927000414__auto____2 = ifn_3075.Invoke_O__O(arg_3076) } else { temp__1927000414__auto____2 = linked_3074.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3073, arg_3076) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000256__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3077 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3079 lang.IFn; if linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = s__292000256__3; if linked_3078 == nil { tmp1 = ifn_3079.Invoke_O__O(arg_3080) } else { tmp1 = linked_3078.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3077, arg_3080) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3081 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = s__292000256__3; if linked_3082 == nil { c__1927001037__auto____4 = ifn_3083.Invoke_O__O(arg_3084) } else { c__1927001037__auto____4 = linked_3082.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3081, arg_3084) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000258__6 any; var root_3085 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3085, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3087 lang.IFn; if linked_3086 == nil { ifn_3087 = lang.IFn_Cast(root_3085) } else { ifn_3087 = nil }; var arg_3088 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3086 == nil { b__292000258__6 = ifn_3087.Invoke_O__O(arg_3088) } else { b__292000258__6 = linked_3086.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3085, arg_3088) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3105 any = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A_New_O_I_O(b__292000258__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3104 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A_fn_class; if fncls__3104 == nil { var fncls__3104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__3105); A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A_fn_class = fncls__3104d; tmp3 = fncls__3104d } else { tmp3 = fncls__3104 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3105, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3106 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3106, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3108 lang.IFn; if linked_3107 == nil { ifn_3108 = lang.IFn_Cast(root_3106) } else { ifn_3108 = nil }; var arg_3109 any; var root_3111 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3111, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3113 lang.IFn; if linked_3112 == nil { ifn_3113 = lang.IFn_Cast(root_3111) } else { ifn_3113 = nil }; var arg_3114 any = b__292000258__6; if linked_3112 == nil { arg_3109 = ifn_3113.Invoke_O__O(arg_3114) } else { arg_3109 = linked_3112.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3111, arg_3114) }; var arg_3110 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000255); var tmp5 any; var root_3115 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3115, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3117 lang.IFn; if linked_3116 == nil { ifn_3117 = lang.IFn_Cast(root_3115) } else { ifn_3117 = nil }; var arg_3118 any = s__292000256__3; if linked_3116 == nil { tmp5 = ifn_3117.Invoke_O__O(arg_3118) } else { tmp5 = linked_3116.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3115, arg_3118) }; arg_3110 = tmp4.Invoke_O__O(tmp5); if linked_3107 == nil { return ifn_3108.Invoke_O_O__O(arg_3109, arg_3110) } else { return linked_3107.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3106, arg_3109, arg_3110) } } else { var root_3119 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3119, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3121 lang.IFn; if linked_3120 == nil { ifn_3121 = lang.IFn_Cast(root_3119) } else { ifn_3121 = nil }; var arg_3122 any; var root_3124 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3124, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3126 lang.IFn; if linked_3125 == nil { ifn_3126 = lang.IFn_Cast(root_3124) } else { ifn_3126 = nil }; var arg_3127 any = b__292000258__6; if linked_3125 == nil { arg_3122 = ifn_3126.Invoke_O__O(arg_3127) } else { arg_3122 = linked_3125.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3124, arg_3127) }; var arg_3123 any; if linked_3120 == nil { return ifn_3121.Invoke_O_O__O(arg_3122, arg_3123) } else { return linked_3120.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3119, arg_3122, arg_3123) } } } else { var mm__4 any; var root_3128 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3128, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3130 lang.IFn; if linked_3129 == nil { ifn_3130 = lang.IFn_Cast(root_3128) } else { ifn_3130 = nil }; var arg_3131 any = s__292000256__3; if linked_3129 == nil { mm__4 = ifn_3130.Invoke_O__O(arg_3131) } else { mm__4 = linked_3129.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3128, arg_3131) }; var tmp6 int64; var na_3132 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { na_3132 = or__1927000174__auto____5 } else { na_3132 = A_arbace_j2g_dyncf_A_const_206 }; var na_3133 int64 = 4098; if jrt.Long_InstanceOf(na_3132) { var n0_3134 int64 = jrt.NN(jrt.Long_Cast(na_3132)).LongValue__J(); var n1_3135 int64 = na_3133; tmp6 = n0_3134 & n1_3135 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3132, na_3133) }
//line :520:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3137 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3137, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3139 lang.IFn; if linked_3138 == nil { ifn_3139 = lang.IFn_Cast(root_3137) } else { ifn_3139 = nil }; var arg_3140 any; var root_3142 any = A_arbace_j2g_dyncf_A_const_444.GetRawRoot__O(); var linked_3143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3142, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3144 lang.IFn

		if linked_3143 == nil { ifn_3144 = lang.IFn_Cast(root_3142) } else { ifn_3144 = nil }; var arg_3145 any = mm__4; var arg_3146 any = A_arbace_j2g_dyncf_A_const_448; if linked_3143 == nil { arg_3140 = ifn_3144.Invoke_O_O__O(arg_3145, arg_3146) } else { arg_3140 = linked_3143.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3142, arg_3145, arg_3146) }
//line :520:1
		var arg_3141 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000255); var tmp8 any; var root_3147 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3147, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3149 lang.IFn; if linked_3148 == nil { ifn_3149 = lang.IFn_Cast(root_3147) } else { ifn_3149 = nil }; var arg_3150 any = s__292000256__3; if linked_3148 == nil { tmp8 = ifn_3149.Invoke_O__O(arg_3150) } else { tmp8 = linked_3148.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3147, arg_3150) }; arg_3141 = tmp7.Invoke_O__O(tmp8); if linked_3138 == nil { return ifn_3139.Invoke_O_O__O(arg_3140, arg_3141) } else { return linked_3138.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3137, arg_3140, arg_3141) } } else { var tmp9 any; var root_3151 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3151, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3153 lang.IFn; if linked_3152 == nil { ifn_3153 = lang.IFn_Cast(root_3151) } else { ifn_3153 = nil }; var arg_3154 any = s__292000256__3; if linked_3152 == nil { tmp9 = ifn_3153.Invoke_O__O(arg_3154) } else { tmp9 = linked_3152.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3151, arg_3154) }; s__292000256__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :520:1
func A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A) Ctor_O_I_O(c__b__292000258 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000258 = c__b__292000258; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :520:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A) Invoke_O__O(self any) any { { var i__292000257__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000257__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000257__1)); var tmp2 int64; var na_3089 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { na_3089 = or__1927000174__auto____3 } else { na_3089 = A_arbace_j2g_dyncf_A_const_206 }; var na_3090 int64 = 4098; if jrt.Long_InstanceOf(na_3089) { var n0_3091 int64 = jrt.NN(jrt.Long_Cast(na_3089)).LongValue__J(); var n1_3092 int64 = na_3090; tmp2 = n0_3091 & n1_3092 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_3089, na_3090) }
//line :520:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_3094 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3094, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3096 lang.IFn; if linked_3095 == nil { ifn_3096 = lang.IFn_Cast(root_3094) } else { ifn_3096 = nil }; var arg_3097 any = t.F_b__292000258; var arg_3098 any; var root_3099 any = A_arbace_j2g_dyncf_A_const_444.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3101 lang.IFn

		if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any = mm__2; var arg_3103 any = A_arbace_j2g_dyncf_A_const_447; if linked_3100 == nil { arg_3098 = ifn_3101.Invoke_O_O__O(arg_3102, arg_3103) } else { arg_3098 = linked_3100.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3099, arg_3102, arg_3103) }
//line :520:1
		if linked_3095 == nil { ifn_3096.Invoke_O_O__O(arg_3097, arg_3098) } else { linked_3095.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3094, arg_3097, arg_3098) }; i__292000257__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000257__1); continue L1 } else { i__292000257__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000257__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A{}; t.Ctor_O(p0); return t }
//line :523:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A) Ctor_O(c__extendable any) { t.F_extendable = c__extendable }
//line :523:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A) Invoke_O_O__O(self, s__292000268__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3742 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A_New_O_O_O(t.F_extendable, self, s__292000268__1); var tmp2 *jrt.Class; var fncls__3741 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A_fn_class; if fncls__3741 == nil { var fncls__3741d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__3742); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A_fn_class = fncls__3741d; tmp2 = fncls__3741d } else { tmp2 = fncls__3741 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3742, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :523:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :523:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A) Ctor_O_O_O(c__extendable, c__iter__292000267, c__s__292000268 any) { t.F_extendable = c__extendable; t.F_iter__292000267 = c__iter__292000267; t.F_s__292000268 = c__s__292000268 }
//line :523:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A) Invoke_O__O(self any) any { { var s__292000268__1 any; var t_ any = t.F_s__292000268; t.F_s__292000268 = nil; s__292000268__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3183 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3183, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3185 lang.IFn; if linked_3184 == nil { ifn_3185 = lang.IFn_Cast(root_3183) } else { ifn_3185 = nil }; var arg_3186 any = s__292000268__1; if linked_3184 == nil { temp__1927000414__auto____2 = ifn_3185.Invoke_O__O(arg_3186) } else { temp__1927000414__auto____2 = linked_3184.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3183, arg_3186) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000268__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3187 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3187, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3189 lang.IFn; if linked_3188 == nil { ifn_3189 = lang.IFn_Cast(root_3187) } else { ifn_3189 = nil }; var arg_3190 any = s__292000268__3; if linked_3188 == nil { tmp1 = ifn_3189.Invoke_O__O(arg_3190) } else { tmp1 = linked_3188.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3187, arg_3190) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3191 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3191, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3193 lang.IFn; if linked_3192 == nil { ifn_3193 = lang.IFn_Cast(root_3191) } else { ifn_3193 = nil }; var arg_3194 any = s__292000268__3; if linked_3192 == nil { c__1927001037__auto____4 = ifn_3193.Invoke_O__O(arg_3194) } else { c__1927001037__auto____4 = linked_3192.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3191, arg_3194) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000270__6 any; var root_3195 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3195, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3197 lang.IFn; if linked_3196 == nil { ifn_3197 = lang.IFn_Cast(root_3195) } else { ifn_3197 = nil }; var arg_3198 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3196 == nil { b__292000270__6 = ifn_3197.Invoke_O__O(arg_3198) } else { b__292000270__6 = linked_3196.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3195, arg_3198) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3449 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A_New_O_I_O_O(t.F_extendable, size__1927001038__auto____5, b__292000270__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3448 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A_fn_class; if fncls__3448 == nil { var fncls__3448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__3449); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A_fn_class = fncls__3448d; tmp3 = fncls__3448d } else { tmp3 = fncls__3448 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3449, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3450 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3450, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3452 lang.IFn; if linked_3451 == nil { ifn_3452 = lang.IFn_Cast(root_3450) } else { ifn_3452 = nil }; var arg_3453 any; var root_3455 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3457 lang.IFn; if linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any = b__292000270__6; if linked_3456 == nil { arg_3453 = ifn_3457.Invoke_O__O(arg_3458) } else { arg_3453 = linked_3456.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3455, arg_3458) }; var arg_3454 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000267); var tmp5 any; var root_3459 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3459, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3461 lang.IFn; if linked_3460 == nil { ifn_3461 = lang.IFn_Cast(root_3459) } else { ifn_3461 = nil }; var arg_3462 any = s__292000268__3; if linked_3460 == nil { tmp5 = ifn_3461.Invoke_O__O(arg_3462) } else { tmp5 = linked_3460.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3459, arg_3462) }; arg_3454 = tmp4.Invoke_O__O(tmp5); if linked_3451 == nil { return ifn_3452.Invoke_O_O__O(arg_3453, arg_3454) } else { return linked_3451.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3450, arg_3453, arg_3454) } } else { var root_3463 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3463, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3465 lang.IFn; if linked_3464 == nil { ifn_3465 = lang.IFn_Cast(root_3463) } else { ifn_3465 = nil }; var arg_3466 any; var root_3468 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3468, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3470 lang.IFn; if linked_3469 == nil { ifn_3470 = lang.IFn_Cast(root_3468) } else { ifn_3470 = nil }; var arg_3471 any = b__292000270__6; if linked_3469 == nil { arg_3466 = ifn_3470.Invoke_O__O(arg_3471) } else { arg_3466 = linked_3469.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3468, arg_3471) }; var arg_3467 any; if linked_3464 == nil { return ifn_3465.Invoke_O_O__O(arg_3466, arg_3467) } else { return linked_3464.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3463, arg_3466, arg_3467) } } } else { var n__4 any; var root_3472 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3472, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3474 lang.IFn; if linked_3473 == nil { ifn_3474 = lang.IFn_Cast(root_3472) } else { ifn_3474 = nil }; var arg_3475 any = s__292000268__3; if linked_3473 == nil { n__4 = ifn_3474.Invoke_O__O(arg_3475) } else { n__4 = linked_3473.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3472, arg_3475) }; var d__5 any; var root_3476 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_3477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3476, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3478 lang.IFn
														if linked_3477 == nil { ifn_3478 = lang.IFn_Cast(root_3476) } else { ifn_3478 = nil }; var arg_3479 any = n__4; if linked_3477 == nil { d__5 = ifn_3478.Invoke_O__O(arg_3479) } else { d__5 = linked_3477.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3476, arg_3479) }
//line :523:1
	var tmp6 any
	var and__1927000168__auto____6 any = d__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_3480 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3480, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3482 lang.IFn; if linked_3481 == nil { ifn_3482 = lang.IFn_Cast(root_3480) } else { ifn_3482 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_457); var arg_3483 any = tmp7.Invoke_O__O(A_arbace_j2g_dyncf_A_const_450.Invoke_O__O(d__5)); if linked_3481 == nil { and__1927000168__auto____7 = ifn_3482.Invoke_O__O(arg_3483) } else { and__1927000168__auto____7 = linked_3481.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3480, arg_3483) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var or__1927000174__auto____8 any; var root_3484 any = A_arbace_j2g_dyncf_A_const_451.GetRawRoot__O(); var linked_3485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3484, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_3486 lang.IFn
		if linked_3485 == nil { ifn_3486 = lang.IFn_Cast(root_3484) } else { ifn_3486 = nil }; var arg_3487 any = n__4; if linked_3485 == nil { or__1927000174__auto____8 = ifn_3486.Invoke_O__O(arg_3487) } else { or__1927000174__auto____8 = linked_3485.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_3484, arg_3487) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__4) } } else {
//line :527:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }
//line :523:1
	if jrt.J2g_Truth(tmp6) { var g__6 any; var tmp8 *lang.Compiler_AOTFn; var fnbody__3489 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A_New_O(n__4); var tmp9 *jrt.Class
		var fncls__3488 /*line :523:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A_fn_class





		if fncls__3488 == nil { var fncls__3488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__3489); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A_fn_class = fncls__3488d; tmp9 = fncls__3488d } else { tmp9 = fncls__3488 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3489, tmp9, nil); g__6 = Up_Compiler_AOTFn_IFn(tmp8).Invoke__O()
//line :523:1
		if jrt.J2g_Truth(g__6) { var generic_QMARK___7 any; var root_3490 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3490, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3492 lang.IFn







			if linked_3491 == nil { ifn_3492 = lang.IFn_Cast(root_3490) } else { ifn_3492 = nil }; var arg_3493 any = A_arbace_j2g_dyncf_A_const_439.Invoke_O__O(g__6); if linked_3491 == nil { generic_QMARK___7 = ifn_3492.Invoke_O__O(arg_3493) } else { generic_QMARK___7 = linked_3491.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3490, arg_3493) }
//line :523:1
			var supers__8 any; var root_3494 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3494, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3496 lang.IFn








			if linked_3495 == nil { ifn_3496 = lang.IFn_Cast(root_3494) } else { ifn_3496 = nil }; var arg_3497 any; var root_3498 any = A_arbace_j2g_dyncf_A_const_442.GetRawRoot__O(); var linked_3499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3498, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3500 lang.IFn; if linked_3499 == nil { ifn_3500 = lang.IFn_Cast(root_3498) } else { ifn_3500 = nil }; var arg_3501 any = A_arbace_j2g_dyncf_A_const_443.GetRawRoot__O(); var arg_3502 any = A_arbace_j2g_dyncf_A_const_441.Invoke_O__O(g__6); if linked_3499 == nil { arg_3497 = ifn_3500.Invoke_O_O__O(arg_3501, arg_3502) } else { arg_3497 = linked_3499.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3498, arg_3501, arg_3502) }; if linked_3495 == nil { supers__8 = ifn_3496.Invoke_O__O(arg_3497) } else { supers__8 = linked_3495.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3494, arg_3497) }
//line :523:1
			var abstract_QMARK___9 any; var and__1927000168__auto____9 any; var root_3503 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3503, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3505 lang.IFn









			if linked_3504 == nil { ifn_3505 = lang.IFn_Cast(root_3503) } else { ifn_3505 = nil }; var arg_3506 any; var root_3507 any = A_arbace_j2g_dyncf_A_const_451.GetRawRoot__O(); var linked_3508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3507, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_3509 lang.IFn; if linked_3508 == nil { ifn_3509 = lang.IFn_Cast(root_3507) } else { ifn_3509 = nil }; var arg_3510 any = n__4; if linked_3508 == nil { arg_3506 = ifn_3509.Invoke_O__O(arg_3510) } else { arg_3506 = linked_3508.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_3507, arg_3510) }; if linked_3504 == nil { and__1927000168__auto____9 = ifn_3505.Invoke_O__O(arg_3506) } else { and__1927000168__auto____9 = linked_3504.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3503, arg_3506) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp10 int64; var na_3511 any; var or__1927000174__auto____10 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(d__5); if jrt.J2g_Truth(or__1927000174__auto____10) { na_3511 = or__1927000174__auto____10 } else { na_3511 = A_arbace_j2g_dyncf_A_const_206 }; var na_3512 int64 = 1024; if jrt.Long_InstanceOf(na_3511) { var n0_3513 int64 = jrt.NN(jrt.Long_Cast(na_3511)).LongValue__J(); var n1_3514 int64 = na_3512; tmp10 = n0_3513 & n1_3514 } else { tmp10 = lang.Numbers_And_O_J__J_NoInit(na_3511, na_3512) }; abstract_QMARK___9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp10)).Ref() } else { abstract_QMARK___9 = and__1927000168__auto____9 }
//line :523:1
			var tmp11 any
			var or__1927000174__auto____10_2 any = generic_QMARK___7









			if jrt.J2g_Truth(or__1927000174__auto____10_2) { tmp11 = or__1927000174__auto____10_2 } else { var or__1927000174__auto____11 any = abstract_QMARK___9; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp11 = or__1927000174__auto____11 } else { var root_3516 any = A_arbace_j2g_dyncf_A_const_452.GetRawRoot__O(); var linked_3517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3516, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3518 lang.IFn; if linked_3517 == nil { ifn_3518 = lang.IFn_Cast(root_3516) } else { ifn_3518 = nil }; var arg_3519 any; var root_3521 any = A_arbace_j2g_dyncf_A_const_453.GetRawRoot__O(); var linked_3522 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3521, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_3523 lang.IFn; if linked_3522 == nil { ifn_3523 = lang.IFn_Cast(root_3521) } else { ifn_3523 = nil }; var arg_3524 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var arg_3525 any = A_arbace_j2g_dyncf_A_const_454; if linked_3522 == nil { arg_3519 = ifn_3523.Invoke_O_O__O(arg_3524, arg_3525) } else { arg_3519 = linked_3522.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_3521, arg_3524, arg_3525) }; var arg_3520 any = supers__8; if linked_3517 == nil { tmp11 = ifn_3518.Invoke_O_O__O(arg_3519, arg_3520) } else { tmp11 = linked_3517.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3516, arg_3519, arg_3520) } } }
//line :523:1
			if jrt.J2g_Truth(tmp11) { var root_3526 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3526, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3528 lang.IFn; if linked_3527 == nil { ifn_3528 = lang.IFn_Cast(root_3526) } else { ifn_3528 = nil }; var arg_3529 any; var tmp12 any; var root_3531 any = A_arbace_j2g_dyncf_A_const_440.GetRawRoot__O(); var linked_3532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3531, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_3533 lang.IFn











				if linked_3532 == nil { ifn_3533 = lang.IFn_Cast(root_3531) } else { ifn_3533 = nil }; var arg_3534 any; var G__292000300__10_ any; var tmp13 any = A_arbace_j2g_dyncf_A_const_439; var tmp14 any; var root_3535 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3535, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3537 lang.IFn
				if linked_3536 == nil { ifn_3537 = lang.IFn_Cast(root_3535) } else { ifn_3537 = nil }; var arg_3538 any = A_arbace_j2g_dyncf_A_const_439.Invoke_O__O(g__6); if linked_3536 == nil { tmp14 = ifn_3537.Invoke_O__O(arg_3538) } else { tmp14 = linked_3536.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3535, arg_3538) }
//line :535:1
				G__292000300__10_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, A_arbace_j2g_dyncf_A_const_441, supers__8)); var G__292000300__11_ any
				if jrt.J2g_Truth(abstract_QMARK___9) {
					var root_3539 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_3540 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3539, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3541 lang.IFn; if linked_3540 == nil { ifn_3541 = lang.IFn_Cast(root_3539) } else { ifn_3541 = nil }; var arg_3542 any = G__292000300__10_; var arg_3543 any = A_arbace_j2g_dyncf_A_const_431; var arg_3544 any; var root_3545 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3545, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3547 lang.IFn; if linked_3546 == nil { ifn_3547 = lang.IFn_Cast(root_3545) } else { ifn_3547 = nil }; var arg_3548 any; var iter__1927001039__auto____11 any; var fnbody__3628 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A_New(); var tmp15 *jrt.Class; var fncls__3627 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A_fn_class; if fncls__3627 == nil { var fncls__3627d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A_fn_class = fncls__3627d; tmp15 = fncls__3627d } else { tmp15 = fncls__3627 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3628, tmp15, nil); arg_3548 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(d__5)); if linked_3546 == nil { arg_3544 = ifn_3547.Invoke_O__O(arg_3548) } else { arg_3544 = linked_3546.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3545, arg_3548) }; if linked_3540 == nil { G__292000300__11_ = ifn_3541.Invoke_O_O_O__O(arg_3542, arg_3543, arg_3544) } else { G__292000300__11_ = linked_3540.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3539, arg_3542, arg_3543, arg_3544) } } else {
//line :536:1
						G__292000300__11_ = G__292000300__10_ }; if jrt.J2g_Truth(generic_QMARK___7) {




							var root_3629 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_3630 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3629, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3631 lang.IFn; if linked_3630 == nil { ifn_3631 = lang.IFn_Cast(root_3629) } else { ifn_3631 = nil }; var arg_3632 any = G__292000300__11_; var arg_3633 any = A_arbace_j2g_dyncf_A_const_108; var arg_3634 any; var root_3635 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3635, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3637 lang.IFn; if linked_3636 == nil { ifn_3637 = lang.IFn_Cast(root_3635) } else { ifn_3637 = nil }; var arg_3638 any; var iter__1927001039__auto____12 any; var fnbody__3724 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A_New(); var tmp16 *jrt.Class; var fncls__3723 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A_fn_class; if fncls__3723 == nil { var fncls__3723d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A_fn_class = fncls__3723d; tmp16 = fncls__3723d } else { tmp16 = fncls__3723 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3724, tmp16, nil); arg_3638 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__6)); if linked_3636 == nil { arg_3634 = ifn_3637.Invoke_O__O(arg_3638) } else { arg_3634 = linked_3636.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3635, arg_3638) }; if linked_3630 == nil { arg_3534 = ifn_3631.Invoke_O_O_O__O(arg_3632, arg_3633, arg_3634) } else { arg_3534 = linked_3630.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3629, arg_3632, arg_3633, arg_3634) } } else {
//line :536:1
								arg_3534 = G__292000300__11_ }
//line :535:1
				if linked_3532 == nil { tmp12 = ifn_3533.Invoke_O__O(arg_3534) } else { tmp12 = linked_3532.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_3531, arg_3534) }
//line :523:1
				arg_3529 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp12); var arg_3530 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__292000267); var tmp18 any; var root_3725 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3725, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3727 lang.IFn; if linked_3726 == nil { ifn_3727 = lang.IFn_Cast(root_3725) } else { ifn_3727 = nil }; var arg_3728 any = s__292000268__3; if linked_3726 == nil { tmp18 = ifn_3727.Invoke_O__O(arg_3728) } else { tmp18 = linked_3726.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3725, arg_3728) }; arg_3530 = tmp17.Invoke_O__O(tmp18); if linked_3527 == nil { return ifn_3528.Invoke_O_O__O(arg_3529, arg_3530) } else { return linked_3527.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3526, arg_3529, arg_3530) } } else { var tmp19 any; var root_3729 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3729, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3731 lang.IFn; if linked_3730 == nil { ifn_3731 = lang.IFn_Cast(root_3729) } else { ifn_3731 = nil }; var arg_3732 any = s__292000268__3; if linked_3730 == nil { tmp19 = ifn_3731.Invoke_O__O(arg_3732) } else { tmp19 = linked_3730.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3729, arg_3732) }; s__292000268__1 = tmp19; continue L1 } } else { var tmp20 any; var root_3733 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3733, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3735 lang.IFn; if linked_3734 == nil { ifn_3735 = lang.IFn_Cast(root_3733) } else { ifn_3735 = nil }; var arg_3736 any = s__292000268__3; if linked_3734 == nil { tmp20 = ifn_3735.Invoke_O__O(arg_3736) } else { tmp20 = linked_3734.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3733, arg_3736) }; s__292000268__1 = tmp20; continue L1 } } else { var tmp21 any; var root_3737 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3737, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3739 lang.IFn; if linked_3738 == nil { ifn_3739 = lang.IFn_Cast(root_3737) } else { ifn_3739 = nil }; var arg_3740 any = s__292000268__3; if linked_3738 == nil { tmp21 = ifn_3739.Invoke_O__O(arg_3740) } else { tmp21 = linked_3738.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3737, arg_3740) }; s__292000268__1 = tmp21; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :523:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :523:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A) Ctor_O_I_O_O(c__extendable any, c__size__1927001038__auto__ int32, c__b__292000270, c__c__1927001037__auto__ any) { t.F_extendable = c__extendable; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__292000270 = c__b__292000270; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :523:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A) Invoke_O__O(self any) any { { var i__292000269__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000269__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000269__1)); var d__3 any; var root_3199 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_3200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3199, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3201 lang.IFn
																if linked_3200 == nil { ifn_3201 = lang.IFn_Cast(root_3199) } else { ifn_3201 = nil }; var arg_3202 any = n__2; if linked_3200 == nil { d__3 = ifn_3201.Invoke_O__O(arg_3202) } else { d__3 = linked_3200.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3199, arg_3202) }
//line :523:1
	var tmp2 any
	var and__1927000168__auto____4 any = d__3


	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_3203 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3203, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3205 lang.IFn; if linked_3204 == nil { ifn_3205 = lang.IFn_Cast(root_3203) } else { ifn_3205 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_449); var arg_3206 any = tmp3.Invoke_O__O(A_arbace_j2g_dyncf_A_const_450.Invoke_O__O(d__3)); if linked_3204 == nil { and__1927000168__auto____5 = ifn_3205.Invoke_O__O(arg_3206) } else { and__1927000168__auto____5 = linked_3204.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3203, arg_3206) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_3207 any = A_arbace_j2g_dyncf_A_const_451.GetRawRoot__O(); var linked_3208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3207, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_3209 lang.IFn
		if linked_3208 == nil { ifn_3209 = lang.IFn_Cast(root_3207) } else { ifn_3209 = nil }; var arg_3210 any = n__2; if linked_3208 == nil { or__1927000174__auto____6 = ifn_3209.Invoke_O__O(arg_3210) } else { or__1927000174__auto____6 = linked_3208.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_3207, arg_3210) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__2) } } else {
//line :527:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :523:1
	if jrt.J2g_Truth(tmp2) { var g__4 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__3212 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A_New_O(n__2); var tmp5 *jrt.Class
		var fncls__3211 /*line :523:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A_fn_class





		if fncls__3211 == nil { var fncls__3211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__3212); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A_fn_class = fncls__3211d; tmp5 = fncls__3211d } else { tmp5 = fncls__3211 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3212, tmp5, nil); g__4 = Up_Compiler_AOTFn_IFn(tmp4).Invoke__O()
//line :523:1
		if jrt.J2g_Truth(g__4) { var generic_QMARK___5 any; var root_3213 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3215 lang.IFn







			if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = A_arbace_j2g_dyncf_A_const_439.Invoke_O__O(g__4); if linked_3214 == nil { generic_QMARK___5 = ifn_3215.Invoke_O__O(arg_3216) } else { generic_QMARK___5 = linked_3214.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3213, arg_3216) }
//line :523:1
			var supers__6 any; var root_3217 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3217, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3219 lang.IFn








			if linked_3218 == nil { ifn_3219 = lang.IFn_Cast(root_3217) } else { ifn_3219 = nil }; var arg_3220 any; var root_3221 any = A_arbace_j2g_dyncf_A_const_442.GetRawRoot__O(); var linked_3222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3221, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3223 lang.IFn; if linked_3222 == nil { ifn_3223 = lang.IFn_Cast(root_3221) } else { ifn_3223 = nil }; var arg_3224 any = A_arbace_j2g_dyncf_A_const_443.GetRawRoot__O(); var arg_3225 any = A_arbace_j2g_dyncf_A_const_441.Invoke_O__O(g__4); if linked_3222 == nil { arg_3220 = ifn_3223.Invoke_O_O__O(arg_3224, arg_3225) } else { arg_3220 = linked_3222.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3221, arg_3224, arg_3225) }; if linked_3218 == nil { supers__6 = ifn_3219.Invoke_O__O(arg_3220) } else { supers__6 = linked_3218.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3217, arg_3220) }
//line :523:1
			var abstract_QMARK___7 any; var and__1927000168__auto____7 any; var root_3226 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3226, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3228 lang.IFn









			if linked_3227 == nil { ifn_3228 = lang.IFn_Cast(root_3226) } else { ifn_3228 = nil }; var arg_3229 any; var root_3230 any = A_arbace_j2g_dyncf_A_const_451.GetRawRoot__O(); var linked_3231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3230, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_3232 lang.IFn; if linked_3231 == nil { ifn_3232 = lang.IFn_Cast(root_3230) } else { ifn_3232 = nil }; var arg_3233 any = n__2; if linked_3231 == nil { arg_3229 = ifn_3232.Invoke_O__O(arg_3233) } else { arg_3229 = linked_3231.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_3230, arg_3233) }; if linked_3227 == nil { and__1927000168__auto____7 = ifn_3228.Invoke_O__O(arg_3229) } else { and__1927000168__auto____7 = linked_3227.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3226, arg_3229) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp6 int64; var na_3234 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(d__3); if jrt.J2g_Truth(or__1927000174__auto____8) { na_3234 = or__1927000174__auto____8 } else { na_3234 = A_arbace_j2g_dyncf_A_const_206 }; var na_3235 int64 = 1024; if jrt.Long_InstanceOf(na_3234) { var n0_3236 int64 = jrt.NN(jrt.Long_Cast(na_3234)).LongValue__J(); var n1_3237 int64 = na_3235; tmp6 = n0_3236 & n1_3237 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3234, na_3235) }; abstract_QMARK___7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp6)).Ref() } else { abstract_QMARK___7 = and__1927000168__auto____7 }
//line :523:1
			var tmp7 any
			var or__1927000174__auto____8_2 any = generic_QMARK___5









			if jrt.J2g_Truth(or__1927000174__auto____8_2) { tmp7 = or__1927000174__auto____8_2 } else { var or__1927000174__auto____9 any = abstract_QMARK___7; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { var root_3239 any = A_arbace_j2g_dyncf_A_const_452.GetRawRoot__O(); var linked_3240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3239, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3241 lang.IFn; if linked_3240 == nil { ifn_3241 = lang.IFn_Cast(root_3239) } else { ifn_3241 = nil }; var arg_3242 any; var root_3244 any = A_arbace_j2g_dyncf_A_const_453.GetRawRoot__O(); var linked_3245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3244, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_3246 lang.IFn; if linked_3245 == nil { ifn_3246 = lang.IFn_Cast(root_3244) } else { ifn_3246 = nil }; var arg_3247 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var arg_3248 any = A_arbace_j2g_dyncf_A_const_454; if linked_3245 == nil { arg_3242 = ifn_3246.Invoke_O_O__O(arg_3247, arg_3248) } else { arg_3242 = linked_3245.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_3244, arg_3247, arg_3248) }; var arg_3243 any = supers__6; if linked_3240 == nil { tmp7 = ifn_3241.Invoke_O_O__O(arg_3242, arg_3243) } else { tmp7 = linked_3240.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3239, arg_3242, arg_3243) } } }
//line :523:1
			if jrt.J2g_Truth(tmp7) { var root_3249 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3249, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3251 lang.IFn; if linked_3250 == nil { ifn_3251 = lang.IFn_Cast(root_3249) } else { ifn_3251 = nil }; var arg_3252 any = t.F_b__292000270; var arg_3253 any; var tmp8 any; var root_3254 any = A_arbace_j2g_dyncf_A_const_440.GetRawRoot__O(); var linked_3255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3254, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_3256 lang.IFn











				if linked_3255 == nil { ifn_3256 = lang.IFn_Cast(root_3254) } else { ifn_3256 = nil }; var arg_3257 any; var G__292000276__8_ any; var tmp9 any = A_arbace_j2g_dyncf_A_const_439; var tmp10 any; var root_3258 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3258, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3260 lang.IFn
				if linked_3259 == nil { ifn_3260 = lang.IFn_Cast(root_3258) } else { ifn_3260 = nil }; var arg_3261 any = A_arbace_j2g_dyncf_A_const_439.Invoke_O__O(g__4); if linked_3259 == nil { tmp10 = ifn_3260.Invoke_O__O(arg_3261) } else { tmp10 = linked_3259.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3258, arg_3261) }
//line :535:1
				G__292000276__8_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, A_arbace_j2g_dyncf_A_const_441, supers__6)); var G__292000276__9_ any
				if jrt.J2g_Truth(abstract_QMARK___7) {
					var root_3262 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_3263 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3262, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3264 lang.IFn; if linked_3263 == nil { ifn_3264 = lang.IFn_Cast(root_3262) } else { ifn_3264 = nil }; var arg_3265 any = G__292000276__8_; var arg_3266 any = A_arbace_j2g_dyncf_A_const_431; var arg_3267 any; var root_3268 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3268, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3270 lang.IFn; if linked_3269 == nil { ifn_3270 = lang.IFn_Cast(root_3268) } else { ifn_3270 = nil }; var arg_3271 any; var iter__1927001039__auto____9 any; var fnbody__3351 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A_New(); var tmp11 *jrt.Class; var fncls__3350 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A_fn_class; if fncls__3350 == nil { var fncls__3350d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A_fn_class = fncls__3350d; tmp11 = fncls__3350d } else { tmp11 = fncls__3350 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3351, tmp11, nil); arg_3271 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(d__3)); if linked_3269 == nil { arg_3267 = ifn_3270.Invoke_O__O(arg_3271) } else { arg_3267 = linked_3269.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3268, arg_3271) }; if linked_3263 == nil { G__292000276__9_ = ifn_3264.Invoke_O_O_O__O(arg_3265, arg_3266, arg_3267) } else { G__292000276__9_ = linked_3263.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3262, arg_3265, arg_3266, arg_3267) } } else {
//line :536:1
						G__292000276__9_ = G__292000276__8_ }; if jrt.J2g_Truth(generic_QMARK___5) {




							var root_3352 any = A_arbace_j2g_dyncf_A_const_430.GetRawRoot__O(); var linked_3353 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3352, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3354 lang.IFn; if linked_3353 == nil { ifn_3354 = lang.IFn_Cast(root_3352) } else { ifn_3354 = nil }; var arg_3355 any = G__292000276__9_; var arg_3356 any = A_arbace_j2g_dyncf_A_const_108; var arg_3357 any; var root_3358 any = A_arbace_j2g_dyncf_A_const_428.GetRawRoot__O(); var linked_3359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3358, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3360 lang.IFn; if linked_3359 == nil { ifn_3360 = lang.IFn_Cast(root_3358) } else { ifn_3360 = nil }; var arg_3361 any; var iter__1927001039__auto____10 any; var fnbody__3447 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A_New(); var tmp12 *jrt.Class; var fncls__3446 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A_fn_class; if fncls__3446 == nil { var fncls__3446d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A_fn_class = fncls__3446d; tmp12 = fncls__3446d } else { tmp12 = fncls__3446 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3447, tmp12, nil); arg_3361 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__4)); if linked_3359 == nil { arg_3357 = ifn_3360.Invoke_O__O(arg_3361) } else { arg_3357 = linked_3359.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3358, arg_3361) }; if linked_3353 == nil { arg_3257 = ifn_3354.Invoke_O_O_O__O(arg_3355, arg_3356, arg_3357) } else { arg_3257 = linked_3353.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3352, arg_3355, arg_3356, arg_3357) } } else {
//line :536:1
								arg_3257 = G__292000276__9_ }
//line :535:1
				if linked_3255 == nil { tmp8 = ifn_3256.Invoke_O__O(arg_3257) } else { tmp8 = linked_3255.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_3254, arg_3257) }
//line :523:1
				arg_3253 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp8); if linked_3250 == nil { ifn_3251.Invoke_O_O__O(arg_3252, arg_3253) } else { linked_3250.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3249, arg_3252, arg_3253) }; i__292000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000269__1); continue L1 } else { i__292000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000269__1); continue L1 } } else { i__292000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000269__1); continue L1 } } else { i__292000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000269__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A{}; t.Ctor_O(p0); return t }
//line :529:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :529:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_438; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :529:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A{}; t.Ctor_O(p0); return t }
//line :529:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :529:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_438; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A) Ctor() {}
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A) Invoke_O_O__O(self, s__292000278__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3349 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A_New_O_O(self, s__292000278__1); var tmp2 *jrt.Class; var fncls__3348 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A_fn_class; if fncls__3348 == nil { var fncls__3348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__3349); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A_fn_class = fncls__3348d; tmp2 = fncls__3348d } else { tmp2 = fncls__3348 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3349, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :537:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A{}; t.Ctor_O_O(p0, p1); return t }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A) Ctor_O_O(c__iter__292000277, c__s__292000278 any) { t.F_iter__292000277 = c__iter__292000277; t.F_s__292000278 = c__s__292000278 }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A) Invoke_O__O(self any) any { { var s__292000278__1 any; var t_ any = t.F_s__292000278; t.F_s__292000278 = nil; s__292000278__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3272 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3272, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3274 lang.IFn; if linked_3273 == nil { ifn_3274 = lang.IFn_Cast(root_3272) } else { ifn_3274 = nil }; var arg_3275 any = s__292000278__1; if linked_3273 == nil { temp__1927000414__auto____2 = ifn_3274.Invoke_O__O(arg_3275) } else { temp__1927000414__auto____2 = linked_3273.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3272, arg_3275) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000278__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3276 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3276, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3278 lang.IFn; if linked_3277 == nil { ifn_3278 = lang.IFn_Cast(root_3276) } else { ifn_3278 = nil }; var arg_3279 any = s__292000278__3; if linked_3277 == nil { tmp1 = ifn_3278.Invoke_O__O(arg_3279) } else { tmp1 = linked_3277.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3276, arg_3279) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3280 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3280, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3282 lang.IFn; if linked_3281 == nil { ifn_3282 = lang.IFn_Cast(root_3280) } else { ifn_3282 = nil }; var arg_3283 any = s__292000278__3; if linked_3281 == nil { c__1927001037__auto____4 = ifn_3282.Invoke_O__O(arg_3283) } else { c__1927001037__auto____4 = linked_3281.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3280, arg_3283) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000280__6 any; var root_3284 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3284, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3286 lang.IFn; if linked_3285 == nil { ifn_3286 = lang.IFn_Cast(root_3284) } else { ifn_3286 = nil }; var arg_3287 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3285 == nil { b__292000280__6 = ifn_3286.Invoke_O__O(arg_3287) } else { b__292000280__6 = linked_3285.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3284, arg_3287) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3299 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A_New_I_O_O(size__1927001038__auto____5, b__292000280__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3298 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A_fn_class; if fncls__3298 == nil { var fncls__3298d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__3299); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A_fn_class = fncls__3298d; tmp3 = fncls__3298d } else { tmp3 = fncls__3298 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3299, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3300 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3300, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3302 lang.IFn; if linked_3301 == nil { ifn_3302 = lang.IFn_Cast(root_3300) } else { ifn_3302 = nil }; var arg_3303 any; var root_3305 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3305, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3307 lang.IFn; if linked_3306 == nil { ifn_3307 = lang.IFn_Cast(root_3305) } else { ifn_3307 = nil }; var arg_3308 any = b__292000280__6; if linked_3306 == nil { arg_3303 = ifn_3307.Invoke_O__O(arg_3308) } else { arg_3303 = linked_3306.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3305, arg_3308) }; var arg_3304 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000277); var tmp5 any; var root_3309 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3309, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3311 lang.IFn; if linked_3310 == nil { ifn_3311 = lang.IFn_Cast(root_3309) } else { ifn_3311 = nil }; var arg_3312 any = s__292000278__3; if linked_3310 == nil { tmp5 = ifn_3311.Invoke_O__O(arg_3312) } else { tmp5 = linked_3310.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3309, arg_3312) }; arg_3304 = tmp4.Invoke_O__O(tmp5); if linked_3301 == nil { return ifn_3302.Invoke_O_O__O(arg_3303, arg_3304) } else { return linked_3301.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3300, arg_3303, arg_3304) } } else { var root_3313 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3313, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3315 lang.IFn; if linked_3314 == nil { ifn_3315 = lang.IFn_Cast(root_3313) } else { ifn_3315 = nil }; var arg_3316 any; var root_3318 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3318, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3320 lang.IFn; if linked_3319 == nil { ifn_3320 = lang.IFn_Cast(root_3318) } else { ifn_3320 = nil }; var arg_3321 any = b__292000280__6; if linked_3319 == nil { arg_3316 = ifn_3320.Invoke_O__O(arg_3321) } else { arg_3316 = linked_3319.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3318, arg_3321) }; var arg_3317 any; if linked_3314 == nil { return ifn_3315.Invoke_O_O__O(arg_3316, arg_3317) } else { return linked_3314.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3313, arg_3316, arg_3317) } } } else { var mm__4 any; var root_3322 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3322, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3324 lang.IFn; if linked_3323 == nil { ifn_3324 = lang.IFn_Cast(root_3322) } else { ifn_3324 = nil }; var arg_3325 any = s__292000278__3; if linked_3323 == nil { mm__4 = ifn_3324.Invoke_O__O(arg_3325) } else { mm__4 = linked_3323.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3322, arg_3325) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)) { var tmp6 int64; var na_3326 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_3326 = or__1927000174__auto____5 } else { na_3326 = A_arbace_j2g_dyncf_A_const_206 }; var na_3327 int64 = 4098; if jrt.Long_InstanceOf(na_3326) { var n0_3328 int64 = jrt.NN(jrt.Long_Cast(na_3326)).LongValue__J(); var n1_3329 int64 = na_3327; tmp6 = n0_3328 & n1_3329 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3326, na_3327) }
//line :537:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3331 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3331, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3333 lang.IFn; if linked_3332 == nil { ifn_3333 = lang.IFn_Cast(root_3331) } else { ifn_3333 = nil }; var arg_3334 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)); var arg_3335 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000277); var tmp8 any; var root_3336 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3336, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3338 lang.IFn; if linked_3337 == nil { ifn_3338 = lang.IFn_Cast(root_3336) } else { ifn_3338 = nil }; var arg_3339 any = s__292000278__3; if linked_3337 == nil { tmp8 = ifn_3338.Invoke_O__O(arg_3339) } else { tmp8 = linked_3337.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3336, arg_3339) }; arg_3335 = tmp7.Invoke_O__O(tmp8); if linked_3332 == nil { return ifn_3333.Invoke_O_O__O(arg_3334, arg_3335) } else { return linked_3332.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3331, arg_3334, arg_3335) } } else { var tmp9 any; var root_3340 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3340, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3342 lang.IFn; if linked_3341 == nil { ifn_3342 = lang.IFn_Cast(root_3340) } else { ifn_3342 = nil }; var arg_3343 any = s__292000278__3; if linked_3341 == nil { tmp9 = ifn_3342.Invoke_O__O(arg_3343) } else { tmp9 = linked_3341.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3340, arg_3343) }; s__292000278__1 = tmp9; continue L1 } } else { var tmp10 any; var root_3344 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3344, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3346 lang.IFn; if linked_3345 == nil { ifn_3346 = lang.IFn_Cast(root_3344) } else { ifn_3346 = nil }; var arg_3347 any = s__292000278__3; if linked_3345 == nil { tmp10 = ifn_3346.Invoke_O__O(arg_3347) } else { tmp10 = linked_3345.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3344, arg_3347) }; s__292000278__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :537:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__292000280, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__292000280 = c__b__292000280; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A) Invoke_O__O(self any) any { { var i__292000279__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000279__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000279__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)) { var tmp2 int64; var na_3288 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_3288 = or__1927000174__auto____3 } else { na_3288 = A_arbace_j2g_dyncf_A_const_206 }; var na_3289 int64 = 4098; if jrt.Long_InstanceOf(na_3288) { var n0_3290 int64 = jrt.NN(jrt.Long_Cast(na_3288)).LongValue__J(); var n1_3291 int64 = na_3289; tmp2 = n0_3290 & n1_3291 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_3288, na_3289) }
//line :537:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_3293 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3293, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3295 lang.IFn; if linked_3294 == nil { ifn_3295 = lang.IFn_Cast(root_3293) } else { ifn_3295 = nil }; var arg_3296 any = t.F_b__292000280; var arg_3297 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)); if linked_3294 == nil { ifn_3295.Invoke_O_O__O(arg_3296, arg_3297) } else { linked_3294.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3293, arg_3296, arg_3297) }; i__292000279__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000279__1); continue L1 } else { i__292000279__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000279__1); continue L1 } } else { i__292000279__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000279__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :537:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A) Ctor() {}
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A) Invoke_O_O__O(self, s__292000302__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3626 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A_New_O_O(self, s__292000302__1); var tmp2 *jrt.Class; var fncls__3625 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A_fn_class; if fncls__3625 == nil { var fncls__3625d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__3626); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A_fn_class = fncls__3625d; tmp2 = fncls__3625d } else { tmp2 = fncls__3625 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3626, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :537:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A) Ctor_O_O(c__iter__292000301, c__s__292000302 any) { t.F_iter__292000301 = c__iter__292000301; t.F_s__292000302 = c__s__292000302 }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A) Invoke_O__O(self any) any { { var s__292000302__1 any; var t_ any = t.F_s__292000302; t.F_s__292000302 = nil; s__292000302__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3549 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3549, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3551 lang.IFn; if linked_3550 == nil { ifn_3551 = lang.IFn_Cast(root_3549) } else { ifn_3551 = nil }; var arg_3552 any = s__292000302__1; if linked_3550 == nil { temp__1927000414__auto____2 = ifn_3551.Invoke_O__O(arg_3552) } else { temp__1927000414__auto____2 = linked_3550.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3549, arg_3552) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000302__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3553 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3553, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3555 lang.IFn; if linked_3554 == nil { ifn_3555 = lang.IFn_Cast(root_3553) } else { ifn_3555 = nil }; var arg_3556 any = s__292000302__3; if linked_3554 == nil { tmp1 = ifn_3555.Invoke_O__O(arg_3556) } else { tmp1 = linked_3554.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3553, arg_3556) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3557 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3557, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any = s__292000302__3; if linked_3558 == nil { c__1927001037__auto____4 = ifn_3559.Invoke_O__O(arg_3560) } else { c__1927001037__auto____4 = linked_3558.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3557, arg_3560) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000304__6 any; var root_3561 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3561, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3563 lang.IFn; if linked_3562 == nil { ifn_3563 = lang.IFn_Cast(root_3561) } else { ifn_3563 = nil }; var arg_3564 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3562 == nil { b__292000304__6 = ifn_3563.Invoke_O__O(arg_3564) } else { b__292000304__6 = linked_3562.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3561, arg_3564) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3576 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A_New_O_I_O(b__292000304__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3575 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A_fn_class; if fncls__3575 == nil { var fncls__3575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__3576); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A_fn_class = fncls__3575d; tmp3 = fncls__3575d } else { tmp3 = fncls__3575 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3576, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3577 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3577, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3579 lang.IFn; if linked_3578 == nil { ifn_3579 = lang.IFn_Cast(root_3577) } else { ifn_3579 = nil }; var arg_3580 any; var root_3582 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3582, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3584 lang.IFn; if linked_3583 == nil { ifn_3584 = lang.IFn_Cast(root_3582) } else { ifn_3584 = nil }; var arg_3585 any = b__292000304__6; if linked_3583 == nil { arg_3580 = ifn_3584.Invoke_O__O(arg_3585) } else { arg_3580 = linked_3583.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3582, arg_3585) }; var arg_3581 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000301); var tmp5 any; var root_3586 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3586, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3588 lang.IFn; if linked_3587 == nil { ifn_3588 = lang.IFn_Cast(root_3586) } else { ifn_3588 = nil }; var arg_3589 any = s__292000302__3; if linked_3587 == nil { tmp5 = ifn_3588.Invoke_O__O(arg_3589) } else { tmp5 = linked_3587.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3586, arg_3589) }; arg_3581 = tmp4.Invoke_O__O(tmp5); if linked_3578 == nil { return ifn_3579.Invoke_O_O__O(arg_3580, arg_3581) } else { return linked_3578.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3577, arg_3580, arg_3581) } } else { var root_3590 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3590, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3592 lang.IFn; if linked_3591 == nil { ifn_3592 = lang.IFn_Cast(root_3590) } else { ifn_3592 = nil }; var arg_3593 any; var root_3595 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3595, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3597 lang.IFn; if linked_3596 == nil { ifn_3597 = lang.IFn_Cast(root_3595) } else { ifn_3597 = nil }; var arg_3598 any = b__292000304__6; if linked_3596 == nil { arg_3593 = ifn_3597.Invoke_O__O(arg_3598) } else { arg_3593 = linked_3596.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3595, arg_3598) }; var arg_3594 any; if linked_3591 == nil { return ifn_3592.Invoke_O_O__O(arg_3593, arg_3594) } else { return linked_3591.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3590, arg_3593, arg_3594) } } } else { var mm__4 any; var root_3599 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3599, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3601 lang.IFn; if linked_3600 == nil { ifn_3601 = lang.IFn_Cast(root_3599) } else { ifn_3601 = nil }; var arg_3602 any = s__292000302__3; if linked_3600 == nil { mm__4 = ifn_3601.Invoke_O__O(arg_3602) } else { mm__4 = linked_3600.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3599, arg_3602) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)) { var tmp6 int64; var na_3603 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_3603 = or__1927000174__auto____5 } else { na_3603 = A_arbace_j2g_dyncf_A_const_206 }; var na_3604 int64 = 4098; if jrt.Long_InstanceOf(na_3603) { var n0_3605 int64 = jrt.NN(jrt.Long_Cast(na_3603)).LongValue__J(); var n1_3606 int64 = na_3604; tmp6 = n0_3605 & n1_3606 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3603, na_3604) }
//line :537:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3608 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3610 lang.IFn; if linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)); var arg_3612 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000301); var tmp8 any; var root_3613 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3613, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3615 lang.IFn; if linked_3614 == nil { ifn_3615 = lang.IFn_Cast(root_3613) } else { ifn_3615 = nil }; var arg_3616 any = s__292000302__3; if linked_3614 == nil { tmp8 = ifn_3615.Invoke_O__O(arg_3616) } else { tmp8 = linked_3614.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3613, arg_3616) }; arg_3612 = tmp7.Invoke_O__O(tmp8); if linked_3609 == nil { return ifn_3610.Invoke_O_O__O(arg_3611, arg_3612) } else { return linked_3609.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3608, arg_3611, arg_3612) } } else { var tmp9 any; var root_3617 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3617, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3619 lang.IFn; if linked_3618 == nil { ifn_3619 = lang.IFn_Cast(root_3617) } else { ifn_3619 = nil }; var arg_3620 any = s__292000302__3; if linked_3618 == nil { tmp9 = ifn_3619.Invoke_O__O(arg_3620) } else { tmp9 = linked_3618.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3617, arg_3620) }; s__292000302__1 = tmp9; continue L1 } } else { var tmp10 any; var root_3621 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3621, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3623 lang.IFn; if linked_3622 == nil { ifn_3623 = lang.IFn_Cast(root_3621) } else { ifn_3623 = nil }; var arg_3624 any = s__292000302__3; if linked_3622 == nil { tmp10 = ifn_3623.Invoke_O__O(arg_3624) } else { tmp10 = linked_3622.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3621, arg_3624) }; s__292000302__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :537:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A) Ctor_O_I_O(c__b__292000304 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000304 = c__b__292000304; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :537:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A) Invoke_O__O(self any) any { { var i__292000303__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000303__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000303__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_69, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)) { var tmp2 int64; var na_3565 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_3565 = or__1927000174__auto____3 } else { na_3565 = A_arbace_j2g_dyncf_A_const_206 }; var na_3566 int64 = 4098; if jrt.Long_InstanceOf(na_3565) { var n0_3567 int64 = jrt.NN(jrt.Long_Cast(na_3565)).LongValue__J(); var n1_3568 int64 = na_3566; tmp2 = n0_3567 & n1_3568 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_3565, na_3566) }
//line :537:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_3570 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3570, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3572 lang.IFn; if linked_3571 == nil { ifn_3572 = lang.IFn_Cast(root_3570) } else { ifn_3572 = nil }; var arg_3573 any = t.F_b__292000304; var arg_3574 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)); if linked_3571 == nil { ifn_3572.Invoke_O_O__O(arg_3573, arg_3574) } else { linked_3571.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3570, arg_3573, arg_3574) }; i__292000303__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000303__1); continue L1 } else { i__292000303__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000303__1); continue L1 } } else { i__292000303__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000303__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A{}; t.Ctor(); return t }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A) Ctor() {}
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A) Invoke_O_O__O(self, s__292000288__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3445 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A_New_O_O(self, s__292000288__1); var tmp2 *jrt.Class; var fncls__3444 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A_fn_class; if fncls__3444 == nil { var fncls__3444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__3445); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A_fn_class = fncls__3444d; tmp2 = fncls__3444d } else { tmp2 = fncls__3444 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3445, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :541:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A{}; t.Ctor_O_O(p0, p1); return t }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A) Ctor_O_O(c__iter__292000287, c__s__292000288 any) { t.F_iter__292000287 = c__iter__292000287; t.F_s__292000288 = c__s__292000288 }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A) Invoke_O__O(self any) any { { var s__292000288__1 any; var t_ any = t.F_s__292000288; t.F_s__292000288 = nil; s__292000288__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3362 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3362, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3364 lang.IFn; if linked_3363 == nil { ifn_3364 = lang.IFn_Cast(root_3362) } else { ifn_3364 = nil }; var arg_3365 any = s__292000288__1; if linked_3363 == nil { temp__1927000414__auto____2 = ifn_3364.Invoke_O__O(arg_3365) } else { temp__1927000414__auto____2 = linked_3363.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3362, arg_3365) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000288__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3366 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3366, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3368 lang.IFn; if linked_3367 == nil { ifn_3368 = lang.IFn_Cast(root_3366) } else { ifn_3368 = nil }; var arg_3369 any = s__292000288__3; if linked_3367 == nil { tmp1 = ifn_3368.Invoke_O__O(arg_3369) } else { tmp1 = linked_3367.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3366, arg_3369) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3370 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3370, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3372 lang.IFn; if linked_3371 == nil { ifn_3372 = lang.IFn_Cast(root_3370) } else { ifn_3372 = nil }; var arg_3373 any = s__292000288__3; if linked_3371 == nil { c__1927001037__auto____4 = ifn_3372.Invoke_O__O(arg_3373) } else { c__1927001037__auto____4 = linked_3371.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3370, arg_3373) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000290__6 any; var root_3374 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3374, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3376 lang.IFn; if linked_3375 == nil { ifn_3376 = lang.IFn_Cast(root_3374) } else { ifn_3376 = nil }; var arg_3377 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3375 == nil { b__292000290__6 = ifn_3376.Invoke_O__O(arg_3377) } else { b__292000290__6 = linked_3375.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3374, arg_3377) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3394 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A_New_O_I_O(b__292000290__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3393 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A_fn_class; if fncls__3393 == nil { var fncls__3393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__3394); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A_fn_class = fncls__3393d; tmp3 = fncls__3393d } else { tmp3 = fncls__3393 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3394, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3395 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3397 lang.IFn; if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any; var root_3400 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3400, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3402 lang.IFn; if linked_3401 == nil { ifn_3402 = lang.IFn_Cast(root_3400) } else { ifn_3402 = nil }; var arg_3403 any = b__292000290__6; if linked_3401 == nil { arg_3398 = ifn_3402.Invoke_O__O(arg_3403) } else { arg_3398 = linked_3401.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3400, arg_3403) }; var arg_3399 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000287); var tmp5 any; var root_3404 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3404, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3406 lang.IFn; if linked_3405 == nil { ifn_3406 = lang.IFn_Cast(root_3404) } else { ifn_3406 = nil }; var arg_3407 any = s__292000288__3; if linked_3405 == nil { tmp5 = ifn_3406.Invoke_O__O(arg_3407) } else { tmp5 = linked_3405.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3404, arg_3407) }; arg_3399 = tmp4.Invoke_O__O(tmp5); if linked_3396 == nil { return ifn_3397.Invoke_O_O__O(arg_3398, arg_3399) } else { return linked_3396.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3395, arg_3398, arg_3399) } } else { var root_3408 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3408, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3410 lang.IFn; if linked_3409 == nil { ifn_3410 = lang.IFn_Cast(root_3408) } else { ifn_3410 = nil }; var arg_3411 any; var root_3413 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3413, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3415 lang.IFn; if linked_3414 == nil { ifn_3415 = lang.IFn_Cast(root_3413) } else { ifn_3415 = nil }; var arg_3416 any = b__292000290__6; if linked_3414 == nil { arg_3411 = ifn_3415.Invoke_O__O(arg_3416) } else { arg_3411 = linked_3414.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3413, arg_3416) }; var arg_3412 any; if linked_3409 == nil { return ifn_3410.Invoke_O_O__O(arg_3411, arg_3412) } else { return linked_3409.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3408, arg_3411, arg_3412) } } } else { var mm__4 any; var root_3417 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3417, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3419 lang.IFn; if linked_3418 == nil { ifn_3419 = lang.IFn_Cast(root_3417) } else { ifn_3419 = nil }; var arg_3420 any = s__292000288__3; if linked_3418 == nil { mm__4 = ifn_3419.Invoke_O__O(arg_3420) } else { mm__4 = linked_3418.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3417, arg_3420) }; var tmp6 int64; var na_3421 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { na_3421 = or__1927000174__auto____5 } else { na_3421 = A_arbace_j2g_dyncf_A_const_206 }; var na_3422 int64 = 4098; if jrt.Long_InstanceOf(na_3421) { var n0_3423 int64 = jrt.NN(jrt.Long_Cast(na_3421)).LongValue__J(); var n1_3424 int64 = na_3422; tmp6 = n0_3423 & n1_3424 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3421, na_3422) }
//line :541:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3426 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3426, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3428 lang.IFn; if linked_3427 == nil { ifn_3428 = lang.IFn_Cast(root_3426) } else { ifn_3428 = nil }; var arg_3429 any; var root_3431 any = A_arbace_j2g_dyncf_A_const_444.GetRawRoot__O(); var linked_3432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3431, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3433 lang.IFn

		if linked_3432 == nil { ifn_3433 = lang.IFn_Cast(root_3431) } else { ifn_3433 = nil }; var arg_3434 any = mm__4; var arg_3435 any = A_arbace_j2g_dyncf_A_const_456; if linked_3432 == nil { arg_3429 = ifn_3433.Invoke_O_O__O(arg_3434, arg_3435) } else { arg_3429 = linked_3432.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3431, arg_3434, arg_3435) }
//line :541:1
		var arg_3430 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000287); var tmp8 any; var root_3436 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3436, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3438 lang.IFn; if linked_3437 == nil { ifn_3438 = lang.IFn_Cast(root_3436) } else { ifn_3438 = nil }; var arg_3439 any = s__292000288__3; if linked_3437 == nil { tmp8 = ifn_3438.Invoke_O__O(arg_3439) } else { tmp8 = linked_3437.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3436, arg_3439) }; arg_3430 = tmp7.Invoke_O__O(tmp8); if linked_3427 == nil { return ifn_3428.Invoke_O_O__O(arg_3429, arg_3430) } else { return linked_3427.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3426, arg_3429, arg_3430) } } else { var tmp9 any; var root_3440 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3440, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3442 lang.IFn; if linked_3441 == nil { ifn_3442 = lang.IFn_Cast(root_3440) } else { ifn_3442 = nil }; var arg_3443 any = s__292000288__3; if linked_3441 == nil { tmp9 = ifn_3442.Invoke_O__O(arg_3443) } else { tmp9 = linked_3441.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3440, arg_3443) }; s__292000288__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :541:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A) Ctor_O_I_O(c__b__292000290 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000290 = c__b__292000290; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A) Invoke_O__O(self any) any { { var i__292000289__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000289__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000289__1)); var tmp2 int64; var na_3378 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { na_3378 = or__1927000174__auto____3 } else { na_3378 = A_arbace_j2g_dyncf_A_const_206 }; var na_3379 int64 = 4098; if jrt.Long_InstanceOf(na_3378) { var n0_3380 int64 = jrt.NN(jrt.Long_Cast(na_3378)).LongValue__J(); var n1_3381 int64 = na_3379; tmp2 = n0_3380 & n1_3381 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_3378, na_3379) }
//line :541:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_3383 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3383, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3385 lang.IFn; if linked_3384 == nil { ifn_3385 = lang.IFn_Cast(root_3383) } else { ifn_3385 = nil }; var arg_3386 any = t.F_b__292000290; var arg_3387 any; var root_3388 any = A_arbace_j2g_dyncf_A_const_444.GetRawRoot__O(); var linked_3389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3388, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3390 lang.IFn

		if linked_3389 == nil { ifn_3390 = lang.IFn_Cast(root_3388) } else { ifn_3390 = nil }; var arg_3391 any = mm__2; var arg_3392 any = A_arbace_j2g_dyncf_A_const_455; if linked_3389 == nil { arg_3387 = ifn_3390.Invoke_O_O__O(arg_3391, arg_3392) } else { arg_3387 = linked_3389.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3388, arg_3391, arg_3392) }
//line :541:1
		if linked_3384 == nil { ifn_3385.Invoke_O_O__O(arg_3386, arg_3387) } else { linked_3384.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3383, arg_3386, arg_3387) }; i__292000289__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000289__1); continue L1 } else { i__292000289__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000289__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :541:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A{}; t.Ctor(); return t }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A) Ctor() {}
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A) Invoke_O_O__O(self, s__292000312__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3722 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A_New_O_O(self, s__292000312__1); var tmp2 *jrt.Class; var fncls__3721 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A_fn_class; if fncls__3721 == nil { var fncls__3721d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__3722); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A_fn_class = fncls__3721d; tmp2 = fncls__3721d } else { tmp2 = fncls__3721 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3722, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :541:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A{}; t.Ctor_O_O(p0, p1); return t }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A) Ctor_O_O(c__iter__292000311, c__s__292000312 any) { t.F_iter__292000311 = c__iter__292000311; t.F_s__292000312 = c__s__292000312 }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A) Invoke_O__O(self any) any { { var s__292000312__1 any; var t_ any = t.F_s__292000312; t.F_s__292000312 = nil; s__292000312__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3639 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3639, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3641 lang.IFn; if linked_3640 == nil { ifn_3641 = lang.IFn_Cast(root_3639) } else { ifn_3641 = nil }; var arg_3642 any = s__292000312__1; if linked_3640 == nil { temp__1927000414__auto____2 = ifn_3641.Invoke_O__O(arg_3642) } else { temp__1927000414__auto____2 = linked_3640.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3639, arg_3642) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000312__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3643 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3645 lang.IFn; if linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any = s__292000312__3; if linked_3644 == nil { tmp1 = ifn_3645.Invoke_O__O(arg_3646) } else { tmp1 = linked_3644.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3643, arg_3646) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3647 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3647, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3649 lang.IFn; if linked_3648 == nil { ifn_3649 = lang.IFn_Cast(root_3647) } else { ifn_3649 = nil }; var arg_3650 any = s__292000312__3; if linked_3648 == nil { c__1927001037__auto____4 = ifn_3649.Invoke_O__O(arg_3650) } else { c__1927001037__auto____4 = linked_3648.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3647, arg_3650) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000314__6 any; var root_3651 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3651, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3653 lang.IFn; if linked_3652 == nil { ifn_3653 = lang.IFn_Cast(root_3651) } else { ifn_3653 = nil }; var arg_3654 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3652 == nil { b__292000314__6 = ifn_3653.Invoke_O__O(arg_3654) } else { b__292000314__6 = linked_3652.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3651, arg_3654) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3671 any = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A_New_O_I_O(b__292000314__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3670 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A_fn_class; if fncls__3670 == nil { var fncls__3670d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__3671); A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A_fn_class = fncls__3670d; tmp3 = fncls__3670d } else { tmp3 = fncls__3670 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3671, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3672 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3672, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3674 lang.IFn; if linked_3673 == nil { ifn_3674 = lang.IFn_Cast(root_3672) } else { ifn_3674 = nil }; var arg_3675 any; var root_3677 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3677, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3679 lang.IFn; if linked_3678 == nil { ifn_3679 = lang.IFn_Cast(root_3677) } else { ifn_3679 = nil }; var arg_3680 any = b__292000314__6; if linked_3678 == nil { arg_3675 = ifn_3679.Invoke_O__O(arg_3680) } else { arg_3675 = linked_3678.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3677, arg_3680) }; var arg_3676 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000311); var tmp5 any; var root_3681 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3681, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3683 lang.IFn; if linked_3682 == nil { ifn_3683 = lang.IFn_Cast(root_3681) } else { ifn_3683 = nil }; var arg_3684 any = s__292000312__3; if linked_3682 == nil { tmp5 = ifn_3683.Invoke_O__O(arg_3684) } else { tmp5 = linked_3682.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3681, arg_3684) }; arg_3676 = tmp4.Invoke_O__O(tmp5); if linked_3673 == nil { return ifn_3674.Invoke_O_O__O(arg_3675, arg_3676) } else { return linked_3673.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3672, arg_3675, arg_3676) } } else { var root_3685 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3685, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3687 lang.IFn; if linked_3686 == nil { ifn_3687 = lang.IFn_Cast(root_3685) } else { ifn_3687 = nil }; var arg_3688 any; var root_3690 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3690, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3692 lang.IFn; if linked_3691 == nil { ifn_3692 = lang.IFn_Cast(root_3690) } else { ifn_3692 = nil }; var arg_3693 any = b__292000314__6; if linked_3691 == nil { arg_3688 = ifn_3692.Invoke_O__O(arg_3693) } else { arg_3688 = linked_3691.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3690, arg_3693) }; var arg_3689 any; if linked_3686 == nil { return ifn_3687.Invoke_O_O__O(arg_3688, arg_3689) } else { return linked_3686.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3685, arg_3688, arg_3689) } } } else { var mm__4 any; var root_3694 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3694, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3696 lang.IFn; if linked_3695 == nil { ifn_3696 = lang.IFn_Cast(root_3694) } else { ifn_3696 = nil }; var arg_3697 any = s__292000312__3; if linked_3695 == nil { mm__4 = ifn_3696.Invoke_O__O(arg_3697) } else { mm__4 = linked_3695.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3694, arg_3697) }; var tmp6 int64; var na_3698 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { na_3698 = or__1927000174__auto____5 } else { na_3698 = A_arbace_j2g_dyncf_A_const_206 }; var na_3699 int64 = 4098; if jrt.Long_InstanceOf(na_3698) { var n0_3700 int64 = jrt.NN(jrt.Long_Cast(na_3698)).LongValue__J(); var n1_3701 int64 = na_3699; tmp6 = n0_3700 & n1_3701 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3698, na_3699) }
//line :541:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3703 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3703, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3705 lang.IFn; if linked_3704 == nil { ifn_3705 = lang.IFn_Cast(root_3703) } else { ifn_3705 = nil }; var arg_3706 any; var root_3708 any = A_arbace_j2g_dyncf_A_const_444.GetRawRoot__O(); var linked_3709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3708, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3710 lang.IFn

		if linked_3709 == nil { ifn_3710 = lang.IFn_Cast(root_3708) } else { ifn_3710 = nil }; var arg_3711 any = mm__4; var arg_3712 any = A_arbace_j2g_dyncf_A_const_459; if linked_3709 == nil { arg_3706 = ifn_3710.Invoke_O_O__O(arg_3711, arg_3712) } else { arg_3706 = linked_3709.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3708, arg_3711, arg_3712) }
//line :541:1
		var arg_3707 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000311); var tmp8 any; var root_3713 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3713, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3715 lang.IFn; if linked_3714 == nil { ifn_3715 = lang.IFn_Cast(root_3713) } else { ifn_3715 = nil }; var arg_3716 any = s__292000312__3; if linked_3714 == nil { tmp8 = ifn_3715.Invoke_O__O(arg_3716) } else { tmp8 = linked_3714.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3713, arg_3716) }; arg_3707 = tmp7.Invoke_O__O(tmp8); if linked_3704 == nil { return ifn_3705.Invoke_O_O__O(arg_3706, arg_3707) } else { return linked_3704.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3703, arg_3706, arg_3707) } } else { var tmp9 any; var root_3717 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3717, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3719 lang.IFn; if linked_3718 == nil { ifn_3719 = lang.IFn_Cast(root_3717) } else { ifn_3719 = nil }; var arg_3720 any = s__292000312__3; if linked_3718 == nil { tmp9 = ifn_3719.Invoke_O__O(arg_3720) } else { tmp9 = linked_3718.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3717, arg_3720) }; s__292000312__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :541:1
func A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A) Ctor_O_I_O(c__b__292000314 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000314 = c__b__292000314; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :541:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A) Invoke_O__O(self any) any { { var i__292000313__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000313__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000313__1)); var tmp2 int64; var na_3655 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(mm__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { na_3655 = or__1927000174__auto____3 } else { na_3655 = A_arbace_j2g_dyncf_A_const_206 }; var na_3656 int64 = 4098; if jrt.Long_InstanceOf(na_3655) { var n0_3657 int64 = jrt.NN(jrt.Long_Cast(na_3655)).LongValue__J(); var n1_3658 int64 = na_3656; tmp2 = n0_3657 & n1_3658 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_3655, na_3656) }
//line :541:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_3660 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3660, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3662 lang.IFn; if linked_3661 == nil { ifn_3662 = lang.IFn_Cast(root_3660) } else { ifn_3662 = nil }; var arg_3663 any = t.F_b__292000314; var arg_3664 any; var root_3665 any = A_arbace_j2g_dyncf_A_const_444.GetRawRoot__O(); var linked_3666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3665, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3667 lang.IFn

		if linked_3666 == nil { ifn_3667 = lang.IFn_Cast(root_3665) } else { ifn_3667 = nil }; var arg_3668 any = mm__2; var arg_3669 any = A_arbace_j2g_dyncf_A_const_458; if linked_3666 == nil { arg_3664 = ifn_3667.Invoke_O_O__O(arg_3668, arg_3669) } else { arg_3664 = linked_3666.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3665, arg_3668, arg_3669) }
//line :541:1
		if linked_3661 == nil { ifn_3662.Invoke_O_O__O(arg_3663, arg_3664) } else { linked_3661.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3660, arg_3663, arg_3664) }; i__292000313__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000313__1); continue L1 } else { i__292000313__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000313__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A{}; t.Ctor(); return t }
//line :547:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A) Ctor() {}
//line :547:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A) Invoke_O_O__O(self, s__292000324__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4114 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A_New_O_O(self, s__292000324__1); var tmp2 *jrt.Class; var fncls__4113 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A_fn_class; if fncls__4113 == nil { var fncls__4113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__4114); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A_fn_class = fncls__4113d; tmp2 = fncls__4113d } else { tmp2 = fncls__4113 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4114, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :547:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A{}; t.Ctor_O_O(p0, p1); return t }
//line :547:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A) Ctor_O_O(c__iter__292000323, c__s__292000324 any) { t.F_iter__292000323 = c__iter__292000323; t.F_s__292000324 = c__s__292000324 }
//line :547:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A) Invoke_O__O(self any) any { { var s__292000324__1 any; var t_ any = t.F_s__292000324; t.F_s__292000324 = nil; s__292000324__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3745 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3745, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3747 lang.IFn; if linked_3746 == nil { ifn_3747 = lang.IFn_Cast(root_3745) } else { ifn_3747 = nil }; var arg_3748 any = s__292000324__1; if linked_3746 == nil { temp__1927000414__auto____2 = ifn_3747.Invoke_O__O(arg_3748) } else { temp__1927000414__auto____2 = linked_3746.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3745, arg_3748) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000324__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3749 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3749, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3751 lang.IFn; if linked_3750 == nil { ifn_3751 = lang.IFn_Cast(root_3749) } else { ifn_3751 = nil }; var arg_3752 any = s__292000324__3; if linked_3750 == nil { tmp1 = ifn_3751.Invoke_O__O(arg_3752) } else { tmp1 = linked_3750.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3749, arg_3752) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3753 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3753, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3755 lang.IFn; if linked_3754 == nil { ifn_3755 = lang.IFn_Cast(root_3753) } else { ifn_3755 = nil }; var arg_3756 any = s__292000324__3; if linked_3754 == nil { c__1927001037__auto____4 = ifn_3755.Invoke_O__O(arg_3756) } else { c__1927001037__auto____4 = linked_3754.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3753, arg_3756) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000326__6 any; var root_3757 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3757, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3759 lang.IFn; if linked_3758 == nil { ifn_3759 = lang.IFn_Cast(root_3757) } else { ifn_3759 = nil }; var arg_3760 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3758 == nil { b__292000326__6 = ifn_3759.Invoke_O__O(arg_3760) } else { b__292000326__6 = linked_3758.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3757, arg_3760) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3918 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A_New_O_I_O(b__292000326__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3917 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A_fn_class; if fncls__3917 == nil { var fncls__3917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__3918); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A_fn_class = fncls__3917d; tmp3 = fncls__3917d } else { tmp3 = fncls__3917 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3918, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3919 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3919, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3921 lang.IFn; if linked_3920 == nil { ifn_3921 = lang.IFn_Cast(root_3919) } else { ifn_3921 = nil }; var arg_3922 any; var root_3924 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3924, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3926 lang.IFn; if linked_3925 == nil { ifn_3926 = lang.IFn_Cast(root_3924) } else { ifn_3926 = nil }; var arg_3927 any = b__292000326__6; if linked_3925 == nil { arg_3922 = ifn_3926.Invoke_O__O(arg_3927) } else { arg_3922 = linked_3925.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3924, arg_3927) }; var arg_3923 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000323); var tmp5 any; var root_3928 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3928, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3930 lang.IFn; if linked_3929 == nil { ifn_3930 = lang.IFn_Cast(root_3928) } else { ifn_3930 = nil }; var arg_3931 any = s__292000324__3; if linked_3929 == nil { tmp5 = ifn_3930.Invoke_O__O(arg_3931) } else { tmp5 = linked_3929.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3928, arg_3931) }; arg_3923 = tmp4.Invoke_O__O(tmp5); if linked_3920 == nil { return ifn_3921.Invoke_O_O__O(arg_3922, arg_3923) } else { return linked_3920.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3919, arg_3922, arg_3923) } } else { var root_3932 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3932, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3934 lang.IFn; if linked_3933 == nil { ifn_3934 = lang.IFn_Cast(root_3932) } else { ifn_3934 = nil }; var arg_3935 any; var root_3937 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3937, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3939 lang.IFn; if linked_3938 == nil { ifn_3939 = lang.IFn_Cast(root_3937) } else { ifn_3939 = nil }; var arg_3940 any = b__292000326__6; if linked_3938 == nil { arg_3935 = ifn_3939.Invoke_O__O(arg_3940) } else { arg_3935 = linked_3938.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3937, arg_3940) }; var arg_3936 any; if linked_3933 == nil { return ifn_3934.Invoke_O_O__O(arg_3935, arg_3936) } else { return linked_3933.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3932, arg_3935, arg_3936) } } } else { var n__4 any; var root_3941 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3941, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3943 lang.IFn; if linked_3942 == nil { ifn_3943 = lang.IFn_Cast(root_3941) } else { ifn_3943 = nil }; var arg_3944 any = s__292000324__3; if linked_3942 == nil { n__4 = ifn_3943.Invoke_O__O(arg_3944) } else { n__4 = linked_3942.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3941, arg_3944) }; var d__5 any; var root_3945 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_3946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3945, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3947 lang.IFn
														if linked_3946 == nil { ifn_3947 = lang.IFn_Cast(root_3945) } else { ifn_3947 = nil }; var arg_3948 any = n__4; if linked_3946 == nil { d__5 = ifn_3947.Invoke_O__O(arg_3948) } else { d__5 = linked_3946.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3945, arg_3948) }
//line :547:1
	var tmp6 any
	var and__1927000168__auto____6 any = d__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_3949 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3949, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3951 lang.IFn; if linked_3950 == nil { ifn_3951 = lang.IFn_Cast(root_3949) } else { ifn_3951 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_467); var arg_3952 any = tmp7.Invoke_O__O(A_arbace_j2g_dyncf_A_const_450.Invoke_O__O(d__5)); if linked_3950 == nil { and__1927000168__auto____7 = ifn_3951.Invoke_O__O(arg_3952) } else { and__1927000168__auto____7 = linked_3950.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3949, arg_3952) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
		var tmp8 int64; var na_3953 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(d__5); if jrt.J2g_Truth(or__1927000174__auto____8) { na_3953 = or__1927000174__auto____8 } else { na_3953 = A_arbace_j2g_dyncf_A_const_206 }; var na_3954 int64 = 1; if jrt.Long_InstanceOf(na_3953) { var n0_3955 int64 = jrt.NN(jrt.Long_Cast(na_3953)).LongValue__J(); var n1_3956 int64 = na_3954; tmp8 = n0_3955 & n1_3956 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_3953, na_3954) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp8)).Ref() } else {
//line :549:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }
//line :547:1
	if jrt.J2g_Truth(tmp6) { var cs__6 any; var root_3958 any = A_arbace_j2g_dyncf_A_const_461.GetRawRoot__O(); var linked_3959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3958, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3960 lang.IFn



		if linked_3959 == nil { ifn_3960 = lang.IFn_Cast(root_3958) } else { ifn_3960 = nil }; var arg_3961 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_462.GetRawRoot__O()).Invoke__O(); var arg_3962 any; var iter__1927001039__auto____6 any; var fnbody__4091 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A_New(); var tmp9 *jrt.Class; var fncls__4090 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A_fn_class
		if fncls__4090 == nil { var fncls__4090d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A_fn_class = fncls__4090d; tmp9 = fncls__4090d } else { tmp9 = fncls__4090 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4091, tmp9, nil); arg_3962 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(A_arbace_j2g_dyncf_A_const_432.Invoke_O__O(d__5))
//line :551:1
		if linked_3959 == nil { cs__6 = ifn_3960.Invoke_O_O__O(arg_3961, arg_3962) } else { cs__6 = linked_3959.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3958, arg_3961, arg_3962) }
//line :547:1
		var tmp10 any; var root_4092 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4092, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4094 lang.IFn











		if linked_4093 == nil { ifn_4094 = lang.IFn_Cast(root_4092) } else { ifn_4094 = nil }; var arg_4095 any = cs__6; if linked_4093 == nil { tmp10 = ifn_4094.Invoke_O__O(arg_4095) } else { tmp10 = linked_4093.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4092, arg_4095) }
//line :547:1
		if jrt.J2g_Truth(tmp10) { var root_4096 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4096, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4098 lang.IFn; if linked_4097 == nil { ifn_4098 = lang.IFn_Cast(root_4096) } else { ifn_4098 = nil }; var arg_4099 any = lang.Tuple_Create_O_O__IPersistentVector(n__4, cs__6); var arg_4100 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__292000323); var tmp12 any; var root_4101 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4101, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4103 lang.IFn; if linked_4102 == nil { ifn_4103 = lang.IFn_Cast(root_4101) } else { ifn_4103 = nil }; var arg_4104 any = s__292000324__3; if linked_4102 == nil { tmp12 = ifn_4103.Invoke_O__O(arg_4104) } else { tmp12 = linked_4102.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4101, arg_4104) }; arg_4100 = tmp11.Invoke_O__O(tmp12); if linked_4097 == nil { return ifn_4098.Invoke_O_O__O(arg_4099, arg_4100) } else { return linked_4097.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4096, arg_4099, arg_4100) } } else { var tmp13 any; var root_4105 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4105, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4107 lang.IFn; if linked_4106 == nil { ifn_4107 = lang.IFn_Cast(root_4105) } else { ifn_4107 = nil }; var arg_4108 any = s__292000324__3; if linked_4106 == nil { tmp13 = ifn_4107.Invoke_O__O(arg_4108) } else { tmp13 = linked_4106.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4105, arg_4108) }; s__292000324__1 = tmp13; continue L1 } } else { var tmp14 any; var root_4109 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4109, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4111 lang.IFn; if linked_4110 == nil { ifn_4111 = lang.IFn_Cast(root_4109) } else { ifn_4111 = nil }; var arg_4112 any = s__292000324__3; if linked_4110 == nil { tmp14 = ifn_4111.Invoke_O__O(arg_4112) } else { tmp14 = linked_4110.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4109, arg_4112) }; s__292000324__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :547:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :547:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A) Ctor_O_I_O(c__b__292000326 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000326 = c__b__292000326; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :547:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A) Invoke_O__O(self any) any { { var i__292000325__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000325__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000325__1)); var d__3 any; var root_3761 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_3762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3761, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3763 lang.IFn
																if linked_3762 == nil { ifn_3763 = lang.IFn_Cast(root_3761) } else { ifn_3763 = nil }; var arg_3764 any = n__2; if linked_3762 == nil { d__3 = ifn_3763.Invoke_O__O(arg_3764) } else { d__3 = linked_3762.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3761, arg_3764) }
//line :547:1
	var tmp2 any
	var and__1927000168__auto____4 any = d__3
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_3765 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3765, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3767 lang.IFn; if linked_3766 == nil { ifn_3767 = lang.IFn_Cast(root_3765) } else { ifn_3767 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_460); var arg_3768 any = tmp3.Invoke_O__O(A_arbace_j2g_dyncf_A_const_450.Invoke_O__O(d__3)); if linked_3766 == nil { and__1927000168__auto____5 = ifn_3767.Invoke_O__O(arg_3768) } else { and__1927000168__auto____5 = linked_3766.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3765, arg_3768) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
		var tmp4 int64; var na_3769 any; var or__1927000174__auto____6 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(d__3); if jrt.J2g_Truth(or__1927000174__auto____6) { na_3769 = or__1927000174__auto____6 } else { na_3769 = A_arbace_j2g_dyncf_A_const_206 }; var na_3770 int64 = 1; if jrt.Long_InstanceOf(na_3769) { var n0_3771 int64 = jrt.NN(jrt.Long_Cast(na_3769)).LongValue__J(); var n1_3772 int64 = na_3770; tmp4 = n0_3771 & n1_3772 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_3769, na_3770) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp4)).Ref() } else {
//line :549:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :547:1
	if jrt.J2g_Truth(tmp2) { var cs__4 any; var root_3774 any = A_arbace_j2g_dyncf_A_const_461.GetRawRoot__O(); var linked_3775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3774, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3776 lang.IFn



		if linked_3775 == nil { ifn_3776 = lang.IFn_Cast(root_3774) } else { ifn_3776 = nil }; var arg_3777 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_462.GetRawRoot__O()).Invoke__O(); var arg_3778 any; var iter__1927001039__auto____4 any; var fnbody__3907 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A_New(); var tmp5 *jrt.Class; var fncls__3906 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A_fn_class
		if fncls__3906 == nil { var fncls__3906d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A_fn_class = fncls__3906d; tmp5 = fncls__3906d } else { tmp5 = fncls__3906 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3907, tmp5, nil); arg_3778 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_j2g_dyncf_A_const_432.Invoke_O__O(d__3))
//line :551:1
		if linked_3775 == nil { cs__4 = ifn_3776.Invoke_O_O__O(arg_3777, arg_3778) } else { cs__4 = linked_3775.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3774, arg_3777, arg_3778) }
//line :547:1
		var tmp6 any; var root_3908 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3908, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3910 lang.IFn











		if linked_3909 == nil { ifn_3910 = lang.IFn_Cast(root_3908) } else { ifn_3910 = nil }; var arg_3911 any = cs__4; if linked_3909 == nil { tmp6 = ifn_3910.Invoke_O__O(arg_3911) } else { tmp6 = linked_3909.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3908, arg_3911) }
//line :547:1
		if jrt.J2g_Truth(tmp6) { var root_3912 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3912, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3914 lang.IFn; if linked_3913 == nil { ifn_3914 = lang.IFn_Cast(root_3912) } else { ifn_3914 = nil }; var arg_3915 any = t.F_b__292000326; var arg_3916 any = lang.Tuple_Create_O_O__IPersistentVector(n__2, cs__4); if linked_3913 == nil { ifn_3914.Invoke_O_O__O(arg_3915, arg_3916) } else { linked_3913.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3912, arg_3915, arg_3916) }; i__292000325__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000325__1); continue L1 } else { i__292000325__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000325__1); continue L1 } } else { i__292000325__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000325__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A{}; t.Ctor(); return t }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A) Ctor() {}
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A) Invoke_O_O__O(self, s__292000331__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3905 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A_New_O_O(self, s__292000331__1); var tmp2 *jrt.Class; var fncls__3904 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A_fn_class; if fncls__3904 == nil { var fncls__3904d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__3905); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A_fn_class = fncls__3904d; tmp2 = fncls__3904d } else { tmp2 = fncls__3904 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3905, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :552:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A{}; t.Ctor_O_O(p0, p1); return t }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A) Ctor_O_O(c__iter__292000330, c__s__292000331 any) { t.F_iter__292000330 = c__iter__292000330; t.F_s__292000331 = c__s__292000331 }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A) Invoke_O__O(self any) any { { var s__292000331__1 any; var t_ any = t.F_s__292000331; t.F_s__292000331 = nil; s__292000331__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3782 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3782, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3784 lang.IFn; if linked_3783 == nil { ifn_3784 = lang.IFn_Cast(root_3782) } else { ifn_3784 = nil }; var arg_3785 any = s__292000331__1; if linked_3783 == nil { temp__1927000414__auto____2 = ifn_3784.Invoke_O__O(arg_3785) } else { temp__1927000414__auto____2 = linked_3783.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3782, arg_3785) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000331__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3786 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3786, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3788 lang.IFn; if linked_3787 == nil { ifn_3788 = lang.IFn_Cast(root_3786) } else { ifn_3788 = nil }; var arg_3789 any = s__292000331__3; if linked_3787 == nil { tmp1 = ifn_3788.Invoke_O__O(arg_3789) } else { tmp1 = linked_3787.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3786, arg_3789) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3790 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3790, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3792 lang.IFn; if linked_3791 == nil { ifn_3792 = lang.IFn_Cast(root_3790) } else { ifn_3792 = nil }; var arg_3793 any = s__292000331__3; if linked_3791 == nil { c__1927001037__auto____4 = ifn_3792.Invoke_O__O(arg_3793) } else { c__1927001037__auto____4 = linked_3791.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3790, arg_3793) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000333__6 any; var root_3794 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3794, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3796 lang.IFn; if linked_3795 == nil { ifn_3796 = lang.IFn_Cast(root_3794) } else { ifn_3796 = nil }; var arg_3797 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3795 == nil { b__292000333__6 = ifn_3796.Invoke_O__O(arg_3797) } else { b__292000333__6 = linked_3795.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3794, arg_3797) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3832 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A_New_O_I_O(b__292000333__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3831 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A_fn_class; if fncls__3831 == nil { var fncls__3831d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__3832); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A_fn_class = fncls__3831d; tmp3 = fncls__3831d } else { tmp3 = fncls__3831 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3832, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3833 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3833, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3835 lang.IFn; if linked_3834 == nil { ifn_3835 = lang.IFn_Cast(root_3833) } else { ifn_3835 = nil }; var arg_3836 any; var root_3838 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3838, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3840 lang.IFn; if linked_3839 == nil { ifn_3840 = lang.IFn_Cast(root_3838) } else { ifn_3840 = nil }; var arg_3841 any = b__292000333__6; if linked_3839 == nil { arg_3836 = ifn_3840.Invoke_O__O(arg_3841) } else { arg_3836 = linked_3839.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3838, arg_3841) }; var arg_3837 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000330); var tmp5 any; var root_3842 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3842, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3844 lang.IFn; if linked_3843 == nil { ifn_3844 = lang.IFn_Cast(root_3842) } else { ifn_3844 = nil }; var arg_3845 any = s__292000331__3; if linked_3843 == nil { tmp5 = ifn_3844.Invoke_O__O(arg_3845) } else { tmp5 = linked_3843.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3842, arg_3845) }; arg_3837 = tmp4.Invoke_O__O(tmp5); if linked_3834 == nil { return ifn_3835.Invoke_O_O__O(arg_3836, arg_3837) } else { return linked_3834.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3833, arg_3836, arg_3837) } } else { var root_3846 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3846, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3848 lang.IFn; if linked_3847 == nil { ifn_3848 = lang.IFn_Cast(root_3846) } else { ifn_3848 = nil }; var arg_3849 any; var root_3851 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3851, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3853 lang.IFn; if linked_3852 == nil { ifn_3853 = lang.IFn_Cast(root_3851) } else { ifn_3853 = nil }; var arg_3854 any = b__292000333__6; if linked_3852 == nil { arg_3849 = ifn_3853.Invoke_O__O(arg_3854) } else { arg_3849 = linked_3852.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3851, arg_3854) }; var arg_3850 any; if linked_3847 == nil { return ifn_3848.Invoke_O_O__O(arg_3849, arg_3850) } else { return linked_3847.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3846, arg_3849, arg_3850) } } } else { var f__4 any; var root_3855 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3855, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3857 lang.IFn; if linked_3856 == nil { ifn_3857 = lang.IFn_Cast(root_3855) } else { ifn_3857 = nil }; var arg_3858 any = s__292000331__3; if linked_3856 == nil { f__4 = ifn_3857.Invoke_O__O(arg_3858) } else { f__4 = linked_3856.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3855, arg_3858) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_206 }
//line :552:1
	var tmp6 any; var and__1927000168__auto____6 bool; var tmp7 int64
	var na_3859 any = fl__5; var na_3860 int64 = 24
	if jrt.Long_InstanceOf(na_3859) { var n0_3861 int64 = jrt.NN(jrt.Long_Cast(na_3859)).LongValue__J(); var n1_3862 int64 = na_3860; tmp7 = n0_3861 & n1_3862 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_3859, na_3860) }; and__1927000168__auto____6 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool; var tmp8 int64; var na_3864 any = fl__5; var na_3865 int64 = 5; if jrt.Long_InstanceOf(na_3864) { var n0_3866 int64 = jrt.NN(jrt.Long_Cast(na_3864)).LongValue__J(); var n1_3867 int64 = na_3865; tmp8 = n0_3866 & n1_3867 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_3864, na_3865) }; and__1927000168__auto____7 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____7 { var or__1927000174__auto____8 any; var root_3869 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3869, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3871 lang.IFn
		if linked_3870 == nil { ifn_3871 = lang.IFn_Cast(root_3869) } else { ifn_3871 = nil }; var arg_3872 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_3870 == nil { or__1927000174__auto____8 = ifn_3871.Invoke_O__O(arg_3872) } else { or__1927000174__auto____8 = linked_3870.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3869, arg_3872) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_463.GetRawRoot__O())).Ref() } } else {
//line :554:1
			tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }
//line :552:1
	if jrt.J2g_Truth(tmp6) { var v__6 any; var tmp9 *lang.Compiler_AOTFn; var fnbody__3878 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A_New_O(f__4); var tmp10 *jrt.Class
		var fncls__3877 /*line :552:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A_fn_class



		if fncls__3877 == nil { var fncls__3877d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__3878); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A_fn_class = fncls__3877d; tmp10 = fncls__3877d } else { tmp10 = fncls__3877 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3878, tmp10, nil); v__6 = Up_Compiler_AOTFn_IFn(tmp9).Invoke__O()
//line :552:1
		var tmp11 any; var root_3879 any = A_arbace_j2g_dyncf_A_const_465.GetRawRoot__O(); var linked_3880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3879, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3881 lang.IFn




		if linked_3880 == nil { ifn_3881 = lang.IFn_Cast(root_3879) } else { ifn_3881 = nil }; var arg_3882 any = v__6; if linked_3880 == nil { tmp11 = ifn_3881.Invoke_O__O(arg_3882) } else { tmp11 = linked_3880.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3879, arg_3882) }
//line :552:1
		if jrt.J2g_Truth(tmp11) { var root_3883 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3883, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3885 lang.IFn; if linked_3884 == nil { ifn_3885 = lang.IFn_Cast(root_3883) } else { ifn_3885 = nil }; var arg_3886 any; var tmp12 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp13 any; var tmp14 any; var root_3888 any = A_arbace_j2g_dyncf_A_const_466.GetRawRoot__O(); var linked_3889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3888, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_3890 lang.IFn





			if linked_3889 == nil { ifn_3890 = lang.IFn_Cast(root_3888) } else { ifn_3890 = nil }; var arg_3891 any = v__6; if linked_3889 == nil { tmp14 = ifn_3890.Invoke_O__O(arg_3891) } else { tmp14 = linked_3889.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_3888, arg_3891) }; if jrt.J2g_Truth(tmp14) { tmp13 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp13 = v__6 }
//line :552:1
			arg_3886 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); var arg_3887 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__292000330); var tmp16 any; var root_3892 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3892, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3894 lang.IFn; if linked_3893 == nil { ifn_3894 = lang.IFn_Cast(root_3892) } else { ifn_3894 = nil }; var arg_3895 any = s__292000331__3; if linked_3893 == nil { tmp16 = ifn_3894.Invoke_O__O(arg_3895) } else { tmp16 = linked_3893.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3892, arg_3895) }; arg_3887 = tmp15.Invoke_O__O(tmp16); if linked_3884 == nil { return ifn_3885.Invoke_O_O__O(arg_3886, arg_3887) } else { return linked_3884.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3883, arg_3886, arg_3887) } } else { var tmp17 any; var root_3896 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3896, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3898 lang.IFn; if linked_3897 == nil { ifn_3898 = lang.IFn_Cast(root_3896) } else { ifn_3898 = nil }; var arg_3899 any = s__292000331__3; if linked_3897 == nil { tmp17 = ifn_3898.Invoke_O__O(arg_3899) } else { tmp17 = linked_3897.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3896, arg_3899) }; s__292000331__1 = tmp17; continue L1 } } else { var tmp18 any; var root_3900 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3900, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3902 lang.IFn; if linked_3901 == nil { ifn_3902 = lang.IFn_Cast(root_3900) } else { ifn_3902 = nil }; var arg_3903 any = s__292000331__3; if linked_3901 == nil { tmp18 = ifn_3902.Invoke_O__O(arg_3903) } else { tmp18 = linked_3901.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3900, arg_3903) }; s__292000331__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :552:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A) Ctor_O_I_O(c__b__292000333 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000333 = c__b__292000333; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A) Invoke_O__O(self any) any { { var i__292000332__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000332__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000332__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_206 }
//line :552:1
	var tmp2 any; var and__1927000168__auto____4 bool; var tmp3 int64
	var na_3798 any = fl__3; var na_3799 int64 = 24
	if jrt.Long_InstanceOf(na_3798) { var n0_3800 int64 = jrt.NN(jrt.Long_Cast(na_3798)).LongValue__J(); var n1_3801 int64 = na_3799; tmp3 = n0_3800 & n1_3801 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_3798, na_3799) }; and__1927000168__auto____4 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool; var tmp4 int64; var na_3803 any = fl__3; var na_3804 int64 = 5; if jrt.Long_InstanceOf(na_3803) { var n0_3805 int64 = jrt.NN(jrt.Long_Cast(na_3803)).LongValue__J(); var n1_3806 int64 = na_3804; tmp4 = n0_3805 & n1_3806 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_3803, na_3804) }; and__1927000168__auto____5 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____5 { var or__1927000174__auto____6 any; var root_3808 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3808, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3810 lang.IFn
		if linked_3809 == nil { ifn_3810 = lang.IFn_Cast(root_3808) } else { ifn_3810 = nil }; var arg_3811 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_3809 == nil { or__1927000174__auto____6 = ifn_3810.Invoke_O__O(arg_3811) } else { or__1927000174__auto____6 = linked_3809.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3808, arg_3811) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_463.GetRawRoot__O())).Ref() } } else {
//line :554:1
			tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }
//line :552:1
	if jrt.J2g_Truth(tmp2) { var v__4 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__3817 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A_New_O(f__2); var tmp6 *jrt.Class
		var fncls__3816 /*line :552:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A_fn_class



		if fncls__3816 == nil { var fncls__3816d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__3817); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A_fn_class = fncls__3816d; tmp6 = fncls__3816d } else { tmp6 = fncls__3816 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3817, tmp6, nil); v__4 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :552:1
		var tmp7 any; var root_3818 any = A_arbace_j2g_dyncf_A_const_465.GetRawRoot__O(); var linked_3819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3818, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3820 lang.IFn




		if linked_3819 == nil { ifn_3820 = lang.IFn_Cast(root_3818) } else { ifn_3820 = nil }; var arg_3821 any = v__4; if linked_3819 == nil { tmp7 = ifn_3820.Invoke_O__O(arg_3821) } else { tmp7 = linked_3819.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3818, arg_3821) }
//line :552:1
		if jrt.J2g_Truth(tmp7) { var root_3822 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3822, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3824 lang.IFn; if linked_3823 == nil { ifn_3824 = lang.IFn_Cast(root_3822) } else { ifn_3824 = nil }; var arg_3825 any = t.F_b__292000333; var arg_3826 any; var tmp8 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp9 any; var tmp10 any; var root_3827 any = A_arbace_j2g_dyncf_A_const_466.GetRawRoot__O(); var linked_3828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3827, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_3829 lang.IFn





			if linked_3828 == nil { ifn_3829 = lang.IFn_Cast(root_3827) } else { ifn_3829 = nil }; var arg_3830 any = v__4; if linked_3828 == nil { tmp10 = ifn_3829.Invoke_O__O(arg_3830) } else { tmp10 = linked_3828.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_3827, arg_3830) }; if jrt.J2g_Truth(tmp10) { tmp9 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp9 = v__4 }
//line :552:1
			arg_3826 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); if linked_3823 == nil { ifn_3824.Invoke_O_O__O(arg_3825, arg_3826) } else { linked_3823.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3822, arg_3825, arg_3826) }; i__292000332__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000332__1); continue L1 } else { i__292000332__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000332__1); continue L1 } } else { i__292000332__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000332__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :552:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A{}; t.Ctor(); return t }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A) Ctor() {}
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A) Invoke_O_O__O(self, s__292000346__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4089 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A_New_O_O(self, s__292000346__1); var tmp2 *jrt.Class; var fncls__4088 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A_fn_class; if fncls__4088 == nil { var fncls__4088d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__4089); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A_fn_class = fncls__4088d; tmp2 = fncls__4088d } else { tmp2 = fncls__4088 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4089, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :552:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A{}; t.Ctor_O_O(p0, p1); return t }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A) Ctor_O_O(c__iter__292000345, c__s__292000346 any) { t.F_iter__292000345 = c__iter__292000345; t.F_s__292000346 = c__s__292000346 }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A) Invoke_O__O(self any) any { { var s__292000346__1 any; var t_ any = t.F_s__292000346; t.F_s__292000346 = nil; s__292000346__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3966 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3966, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3968 lang.IFn; if linked_3967 == nil { ifn_3968 = lang.IFn_Cast(root_3966) } else { ifn_3968 = nil }; var arg_3969 any = s__292000346__1; if linked_3967 == nil { temp__1927000414__auto____2 = ifn_3968.Invoke_O__O(arg_3969) } else { temp__1927000414__auto____2 = linked_3967.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3966, arg_3969) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000346__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3970 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3970, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3972 lang.IFn; if linked_3971 == nil { ifn_3972 = lang.IFn_Cast(root_3970) } else { ifn_3972 = nil }; var arg_3973 any = s__292000346__3; if linked_3971 == nil { tmp1 = ifn_3972.Invoke_O__O(arg_3973) } else { tmp1 = linked_3971.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3970, arg_3973) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3974 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3974, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3976 lang.IFn; if linked_3975 == nil { ifn_3976 = lang.IFn_Cast(root_3974) } else { ifn_3976 = nil }; var arg_3977 any = s__292000346__3; if linked_3975 == nil { c__1927001037__auto____4 = ifn_3976.Invoke_O__O(arg_3977) } else { c__1927001037__auto____4 = linked_3975.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3974, arg_3977) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000348__6 any; var root_3978 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3978, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3980 lang.IFn; if linked_3979 == nil { ifn_3980 = lang.IFn_Cast(root_3978) } else { ifn_3980 = nil }; var arg_3981 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3979 == nil { b__292000348__6 = ifn_3980.Invoke_O__O(arg_3981) } else { b__292000348__6 = linked_3979.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3978, arg_3981) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4016 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A_New_O_I_O(b__292000348__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4015 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A_fn_class; if fncls__4015 == nil { var fncls__4015d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__4016); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A_fn_class = fncls__4015d; tmp3 = fncls__4015d } else { tmp3 = fncls__4015 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4016, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4017 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4017, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4019 lang.IFn; if linked_4018 == nil { ifn_4019 = lang.IFn_Cast(root_4017) } else { ifn_4019 = nil }; var arg_4020 any; var root_4022 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4022, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4024 lang.IFn; if linked_4023 == nil { ifn_4024 = lang.IFn_Cast(root_4022) } else { ifn_4024 = nil }; var arg_4025 any = b__292000348__6; if linked_4023 == nil { arg_4020 = ifn_4024.Invoke_O__O(arg_4025) } else { arg_4020 = linked_4023.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4022, arg_4025) }; var arg_4021 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000345); var tmp5 any; var root_4026 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4026, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4028 lang.IFn; if linked_4027 == nil { ifn_4028 = lang.IFn_Cast(root_4026) } else { ifn_4028 = nil }; var arg_4029 any = s__292000346__3; if linked_4027 == nil { tmp5 = ifn_4028.Invoke_O__O(arg_4029) } else { tmp5 = linked_4027.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4026, arg_4029) }; arg_4021 = tmp4.Invoke_O__O(tmp5); if linked_4018 == nil { return ifn_4019.Invoke_O_O__O(arg_4020, arg_4021) } else { return linked_4018.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4017, arg_4020, arg_4021) } } else { var root_4030 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4030, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4032 lang.IFn; if linked_4031 == nil { ifn_4032 = lang.IFn_Cast(root_4030) } else { ifn_4032 = nil }; var arg_4033 any; var root_4035 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4035, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4037 lang.IFn; if linked_4036 == nil { ifn_4037 = lang.IFn_Cast(root_4035) } else { ifn_4037 = nil }; var arg_4038 any = b__292000348__6; if linked_4036 == nil { arg_4033 = ifn_4037.Invoke_O__O(arg_4038) } else { arg_4033 = linked_4036.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4035, arg_4038) }; var arg_4034 any; if linked_4031 == nil { return ifn_4032.Invoke_O_O__O(arg_4033, arg_4034) } else { return linked_4031.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4030, arg_4033, arg_4034) } } } else { var f__4 any; var root_4039 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4039, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4041 lang.IFn; if linked_4040 == nil { ifn_4041 = lang.IFn_Cast(root_4039) } else { ifn_4041 = nil }; var arg_4042 any = s__292000346__3; if linked_4040 == nil { f__4 = ifn_4041.Invoke_O__O(arg_4042) } else { f__4 = linked_4040.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4039, arg_4042) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_206 }
//line :552:1
	var tmp6 any; var and__1927000168__auto____6 bool; var tmp7 int64
	var na_4043 any = fl__5; var na_4044 int64 = 24
	if jrt.Long_InstanceOf(na_4043) { var n0_4045 int64 = jrt.NN(jrt.Long_Cast(na_4043)).LongValue__J(); var n1_4046 int64 = na_4044; tmp7 = n0_4045 & n1_4046 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_4043, na_4044) }; and__1927000168__auto____6 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool; var tmp8 int64; var na_4048 any = fl__5; var na_4049 int64 = 5; if jrt.Long_InstanceOf(na_4048) { var n0_4050 int64 = jrt.NN(jrt.Long_Cast(na_4048)).LongValue__J(); var n1_4051 int64 = na_4049; tmp8 = n0_4050 & n1_4051 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_4048, na_4049) }; and__1927000168__auto____7 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____7 { var or__1927000174__auto____8 any; var root_4053 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_4054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4053, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_4055 lang.IFn
		if linked_4054 == nil { ifn_4055 = lang.IFn_Cast(root_4053) } else { ifn_4055 = nil }; var arg_4056 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_4054 == nil { or__1927000174__auto____8 = ifn_4055.Invoke_O__O(arg_4056) } else { or__1927000174__auto____8 = linked_4054.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_4053, arg_4056) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_463.GetRawRoot__O())).Ref() } } else {
//line :554:1
			tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }
//line :552:1
	if jrt.J2g_Truth(tmp6) { var v__6 any; var tmp9 *lang.Compiler_AOTFn; var fnbody__4062 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A_New_O(f__4); var tmp10 *jrt.Class
		var fncls__4061 /*line :552:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A_fn_class



		if fncls__4061 == nil { var fncls__4061d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__4062); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A_fn_class = fncls__4061d; tmp10 = fncls__4061d } else { tmp10 = fncls__4061 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4062, tmp10, nil); v__6 = Up_Compiler_AOTFn_IFn(tmp9).Invoke__O()
//line :552:1
		var tmp11 any; var root_4063 any = A_arbace_j2g_dyncf_A_const_465.GetRawRoot__O(); var linked_4064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4063, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_4065 lang.IFn




		if linked_4064 == nil { ifn_4065 = lang.IFn_Cast(root_4063) } else { ifn_4065 = nil }; var arg_4066 any = v__6; if linked_4064 == nil { tmp11 = ifn_4065.Invoke_O__O(arg_4066) } else { tmp11 = linked_4064.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_4063, arg_4066) }
//line :552:1
		if jrt.J2g_Truth(tmp11) { var root_4067 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4067, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4069 lang.IFn; if linked_4068 == nil { ifn_4069 = lang.IFn_Cast(root_4067) } else { ifn_4069 = nil }; var arg_4070 any; var tmp12 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp13 any; var tmp14 any; var root_4072 any = A_arbace_j2g_dyncf_A_const_466.GetRawRoot__O(); var linked_4073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4072, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_4074 lang.IFn





			if linked_4073 == nil { ifn_4074 = lang.IFn_Cast(root_4072) } else { ifn_4074 = nil }; var arg_4075 any = v__6; if linked_4073 == nil { tmp14 = ifn_4074.Invoke_O__O(arg_4075) } else { tmp14 = linked_4073.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_4072, arg_4075) }; if jrt.J2g_Truth(tmp14) { tmp13 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp13 = v__6 }
//line :552:1
			arg_4070 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); var arg_4071 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__292000345); var tmp16 any; var root_4076 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4076, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4078 lang.IFn; if linked_4077 == nil { ifn_4078 = lang.IFn_Cast(root_4076) } else { ifn_4078 = nil }; var arg_4079 any = s__292000346__3; if linked_4077 == nil { tmp16 = ifn_4078.Invoke_O__O(arg_4079) } else { tmp16 = linked_4077.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4076, arg_4079) }; arg_4071 = tmp15.Invoke_O__O(tmp16); if linked_4068 == nil { return ifn_4069.Invoke_O_O__O(arg_4070, arg_4071) } else { return linked_4068.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4067, arg_4070, arg_4071) } } else { var tmp17 any; var root_4080 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4080, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4082 lang.IFn; if linked_4081 == nil { ifn_4082 = lang.IFn_Cast(root_4080) } else { ifn_4082 = nil }; var arg_4083 any = s__292000346__3; if linked_4081 == nil { tmp17 = ifn_4082.Invoke_O__O(arg_4083) } else { tmp17 = linked_4081.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4080, arg_4083) }; s__292000346__1 = tmp17; continue L1 } } else { var tmp18 any; var root_4084 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4084, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4086 lang.IFn; if linked_4085 == nil { ifn_4086 = lang.IFn_Cast(root_4084) } else { ifn_4086 = nil }; var arg_4087 any = s__292000346__3; if linked_4085 == nil { tmp18 = ifn_4086.Invoke_O__O(arg_4087) } else { tmp18 = linked_4085.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4084, arg_4087) }; s__292000346__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :552:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A) Ctor_O_I_O(c__b__292000348 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000348 = c__b__292000348; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :552:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A) Invoke_O__O(self any) any { { var i__292000347__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000347__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000347__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_206 }
//line :552:1
	var tmp2 any; var and__1927000168__auto____4 bool; var tmp3 int64
	var na_3982 any = fl__3; var na_3983 int64 = 24
	if jrt.Long_InstanceOf(na_3982) { var n0_3984 int64 = jrt.NN(jrt.Long_Cast(na_3982)).LongValue__J(); var n1_3985 int64 = na_3983; tmp3 = n0_3984 & n1_3985 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_3982, na_3983) }; and__1927000168__auto____4 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool; var tmp4 int64; var na_3987 any = fl__3; var na_3988 int64 = 5; if jrt.Long_InstanceOf(na_3987) { var n0_3989 int64 = jrt.NN(jrt.Long_Cast(na_3987)).LongValue__J(); var n1_3990 int64 = na_3988; tmp4 = n0_3989 & n1_3990 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_3987, na_3988) }; and__1927000168__auto____5 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____5 { var or__1927000174__auto____6 any; var root_3992 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3992, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3994 lang.IFn
		if linked_3993 == nil { ifn_3994 = lang.IFn_Cast(root_3992) } else { ifn_3994 = nil }; var arg_3995 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_3993 == nil { or__1927000174__auto____6 = ifn_3994.Invoke_O__O(arg_3995) } else { or__1927000174__auto____6 = linked_3993.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3992, arg_3995) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_463.GetRawRoot__O())).Ref() } } else {
//line :554:1
			tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }
//line :552:1
	if jrt.J2g_Truth(tmp2) { var v__4 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__4001 any = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A_New_O(f__2); var tmp6 *jrt.Class
		var fncls__4000 /*line :552:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A_fn_class



		if fncls__4000 == nil { var fncls__4000d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__4001); A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A_fn_class = fncls__4000d; tmp6 = fncls__4000d } else { tmp6 = fncls__4000 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4001, tmp6, nil); v__4 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :552:1
		var tmp7 any; var root_4002 any = A_arbace_j2g_dyncf_A_const_465.GetRawRoot__O(); var linked_4003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4002, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_4004 lang.IFn




		if linked_4003 == nil { ifn_4004 = lang.IFn_Cast(root_4002) } else { ifn_4004 = nil }; var arg_4005 any = v__4; if linked_4003 == nil { tmp7 = ifn_4004.Invoke_O__O(arg_4005) } else { tmp7 = linked_4003.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_4002, arg_4005) }
//line :552:1
		if jrt.J2g_Truth(tmp7) { var root_4006 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4006, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4008 lang.IFn; if linked_4007 == nil { ifn_4008 = lang.IFn_Cast(root_4006) } else { ifn_4008 = nil }; var arg_4009 any = t.F_b__292000348; var arg_4010 any; var tmp8 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp9 any; var tmp10 any; var root_4011 any = A_arbace_j2g_dyncf_A_const_466.GetRawRoot__O(); var linked_4012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4011, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_4013 lang.IFn





			if linked_4012 == nil { ifn_4013 = lang.IFn_Cast(root_4011) } else { ifn_4013 = nil }; var arg_4014 any = v__4; if linked_4012 == nil { tmp10 = ifn_4013.Invoke_O__O(arg_4014) } else { tmp10 = linked_4012.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_4011, arg_4014) }; if jrt.J2g_Truth(tmp10) { tmp9 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp9 = v__4 }
//line :552:1
			arg_4010 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); if linked_4007 == nil { ifn_4008.Invoke_O_O__O(arg_4009, arg_4010) } else { linked_4007.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4006, arg_4009, arg_4010) }; i__292000347__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000347__1); continue L1 } else { i__292000347__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000347__1); continue L1 } } else { i__292000347__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000347__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A{}; t.Ctor_O(p0); return t }
//line :556:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :556:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3812 any = A_arbace_j2g_dyncf_A_const_464.GetRawRoot__O(); var linked_3813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3812, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_3814 lang.IFn; if linked_3813 == nil { ifn_3814 = lang.IFn_Cast(root_3812) } else { ifn_3814 = nil }; var arg_3815 any; var t_ any = t.F_f; t.F_f = nil; arg_3815 = t_; if linked_3813 == nil { tmp1 = ifn_3814.Invoke_O__O(arg_3815) } else { tmp1 = linked_3813.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_3812, arg_3815) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :556:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A{}; t.Ctor_O(p0); return t }
//line :556:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :556:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3873 any = A_arbace_j2g_dyncf_A_const_464.GetRawRoot__O(); var linked_3874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3873, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_3875 lang.IFn; if linked_3874 == nil { ifn_3875 = lang.IFn_Cast(root_3873) } else { ifn_3875 = nil }; var arg_3876 any; var t_ any = t.F_f; t.F_f = nil; arg_3876 = t_; if linked_3874 == nil { tmp1 = ifn_3875.Invoke_O__O(arg_3876) } else { tmp1 = linked_3874.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_3873, arg_3876) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :556:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A{}; t.Ctor_O(p0); return t }
//line :556:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :556:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3996 any = A_arbace_j2g_dyncf_A_const_464.GetRawRoot__O(); var linked_3997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3996, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_3998 lang.IFn; if linked_3997 == nil { ifn_3998 = lang.IFn_Cast(root_3996) } else { ifn_3998 = nil }; var arg_3999 any; var t_ any = t.F_f; t.F_f = nil; arg_3999 = t_; if linked_3997 == nil { tmp1 = ifn_3998.Invoke_O__O(arg_3999) } else { tmp1 = linked_3997.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_3996, arg_3999) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :556:1
func A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A{}; t.Ctor_O(p0); return t }
//line :556:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :556:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4057 any = A_arbace_j2g_dyncf_A_const_464.GetRawRoot__O(); var linked_4058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4057, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_4059 lang.IFn; if linked_4058 == nil { ifn_4059 = lang.IFn_Cast(root_4057) } else { ifn_4059 = nil }; var arg_4060 any; var t_ any = t.F_f; t.F_f = nil; arg_4060 = t_; if linked_4058 == nil { tmp1 = ifn_4059.Invoke_O__O(arg_4060) } else { tmp1 = linked_4058.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_4057, arg_4060) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A{}; t.Ctor_O(p0); return t }
//line :564:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A) Ctor_O(c__tset any) { t.F_tset = c__tset }
//line :564:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A) Invoke_O_O__O(self, s__292000362__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4450 any = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A_New_O_O_O(t.F_tset, self, s__292000362__1); var tmp2 *jrt.Class; var fncls__4449 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A_fn_class; if fncls__4449 == nil { var fncls__4449d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__4450); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A_fn_class = fncls__4449d; tmp2 = fncls__4449d } else { tmp2 = fncls__4449 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4450, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :564:1
func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :564:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A) Ctor_O_O_O(c__tset, c__iter__292000361, c__s__292000362 any) { t.F_tset = c__tset; t.F_iter__292000361 = c__iter__292000361; t.F_s__292000362 = c__s__292000362 }
//line :564:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A) Invoke_O__O(self any) any { { var s__292000362__1 any; var t_ any = t.F_s__292000362; t.F_s__292000362 = nil; s__292000362__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4121 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4121, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4123 lang.IFn; if linked_4122 == nil { ifn_4123 = lang.IFn_Cast(root_4121) } else { ifn_4123 = nil }; var arg_4124 any = s__292000362__1; if linked_4122 == nil { temp__1927000414__auto____2 = ifn_4123.Invoke_O__O(arg_4124) } else { temp__1927000414__auto____2 = linked_4122.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4121, arg_4124) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000362__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4125 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4125, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4127 lang.IFn; if linked_4126 == nil { ifn_4127 = lang.IFn_Cast(root_4125) } else { ifn_4127 = nil }; var arg_4128 any = s__292000362__3; if linked_4126 == nil { tmp1 = ifn_4127.Invoke_O__O(arg_4128) } else { tmp1 = linked_4126.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4125, arg_4128) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4129 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4129, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4131 lang.IFn; if linked_4130 == nil { ifn_4131 = lang.IFn_Cast(root_4129) } else { ifn_4131 = nil }; var arg_4132 any = s__292000362__3; if linked_4130 == nil { c__1927001037__auto____4 = ifn_4131.Invoke_O__O(arg_4132) } else { c__1927001037__auto____4 = linked_4130.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4129, arg_4132) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000364__6 any; var root_4133 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4133, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4135 lang.IFn; if linked_4134 == nil { ifn_4135 = lang.IFn_Cast(root_4133) } else { ifn_4135 = nil }; var arg_4136 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4134 == nil { b__292000364__6 = ifn_4135.Invoke_O__O(arg_4136) } else { b__292000364__6 = linked_4134.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4133, arg_4136) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4274 any = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A_New_O_O_I_O(b__292000364__6, t.F_tset, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4273 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A_fn_class; if fncls__4273 == nil { var fncls__4273d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__4274); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A_fn_class = fncls__4273d; tmp3 = fncls__4273d } else { tmp3 = fncls__4273 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4274, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4275 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4275, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4277 lang.IFn; if linked_4276 == nil { ifn_4277 = lang.IFn_Cast(root_4275) } else { ifn_4277 = nil }; var arg_4278 any; var root_4280 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4280, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4282 lang.IFn; if linked_4281 == nil { ifn_4282 = lang.IFn_Cast(root_4280) } else { ifn_4282 = nil }; var arg_4283 any = b__292000364__6; if linked_4281 == nil { arg_4278 = ifn_4282.Invoke_O__O(arg_4283) } else { arg_4278 = linked_4281.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4280, arg_4283) }; var arg_4279 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000361); var tmp5 any; var root_4284 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4284, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4286 lang.IFn; if linked_4285 == nil { ifn_4286 = lang.IFn_Cast(root_4284) } else { ifn_4286 = nil }; var arg_4287 any = s__292000362__3; if linked_4285 == nil { tmp5 = ifn_4286.Invoke_O__O(arg_4287) } else { tmp5 = linked_4285.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4284, arg_4287) }; arg_4279 = tmp4.Invoke_O__O(tmp5); if linked_4276 == nil { return ifn_4277.Invoke_O_O__O(arg_4278, arg_4279) } else { return linked_4276.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4275, arg_4278, arg_4279) } } else { var root_4288 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4288, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4290 lang.IFn; if linked_4289 == nil { ifn_4290 = lang.IFn_Cast(root_4288) } else { ifn_4290 = nil }; var arg_4291 any; var root_4293 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4293, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4295 lang.IFn; if linked_4294 == nil { ifn_4295 = lang.IFn_Cast(root_4293) } else { ifn_4295 = nil }; var arg_4296 any = b__292000364__6; if linked_4294 == nil { arg_4291 = ifn_4295.Invoke_O__O(arg_4296) } else { arg_4291 = linked_4294.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4293, arg_4296) }; var arg_4292 any; if linked_4289 == nil { return ifn_4290.Invoke_O_O__O(arg_4291, arg_4292) } else { return linked_4289.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4288, arg_4291, arg_4292) } } } else { var vec__292000382__4 any; var root_4297 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4297, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4299 lang.IFn; if linked_4298 == nil { ifn_4299 = lang.IFn_Cast(root_4297) } else { ifn_4299 = nil }; var arg_4300 any = s__292000362__3; if linked_4298 == nil { vec__292000382__4 = ifn_4299.Invoke_O__O(arg_4300) } else { vec__292000382__4 = linked_4298.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4297, arg_4300) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000382__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000382__4, lang.RT_IntCast_J__I_NoInit(1), nil); var i__7 any = A_arbace_j2g_dyncf_A_const_468.Invoke_O__O(facets__6); var tmp6 any
														var and__1927000168__auto____8 any = i__7
														if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_4301 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_4302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4301, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4303 lang.IFn; if linked_4302 == nil { ifn_4303 = lang.IFn_Cast(root_4301) } else { ifn_4303 = nil }; var arg_4304 any = lang.IFn_Cast(t.F_tset).Invoke_O__O(n__5); if linked_4302 == nil { and__1927000168__auto____9 = ifn_4303.Invoke_O__O(arg_4304) } else { and__1927000168__auto____9 = linked_4302.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4301, arg_4304) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp7 int64; var na_4305 any; var or__1927000174__auto____10 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(i__7); if jrt.J2g_Truth(or__1927000174__auto____10) { na_4305 = or__1927000174__auto____10 } else { na_4305 = A_arbace_j2g_dyncf_A_const_206 }; var na_4306 int64 = 1; if jrt.Long_InstanceOf(na_4305) { var n0_4307 int64 = jrt.NN(jrt.Long_Cast(na_4305)).LongValue__J(); var n1_4308 int64 = na_4306; tmp7 = n0_4307 & n1_4308 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_4305, na_4306) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp7)).Ref() } else { tmp6 = and__1927000168__auto____9 } } else { tmp6 = and__1927000168__auto____8 }
//line :564:1
	if jrt.J2g_Truth(tmp6) { var cs__8 any; var root_4310 any = A_arbace_j2g_dyncf_A_const_461.GetRawRoot__O(); var linked_4311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4310, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_4312 lang.IFn


		if linked_4311 == nil { ifn_4312 = lang.IFn_Cast(root_4310) } else { ifn_4312 = nil }; var arg_4313 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_462.GetRawRoot__O()).Invoke__O(); var arg_4314 any; var iter__1927001039__auto____8 any; var fnbody__4427 any = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A_New(); var tmp8 *jrt.Class; var fncls__4426 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A_fn_class
		if fncls__4426 == nil { var fncls__4426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A_fn_class = fncls__4426d; tmp8 = fncls__4426d } else { tmp8 = fncls__4426 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4427, tmp8, nil); arg_4314 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(A_arbace_j2g_dyncf_A_const_432.Invoke_O__O(i__7))
//line :567:1
		if linked_4311 == nil { cs__8 = ifn_4312.Invoke_O_O__O(arg_4313, arg_4314) } else { cs__8 = linked_4311.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_4310, arg_4313, arg_4314) }
//line :564:1
		var tmp9 any; var root_4428 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4428, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4430 lang.IFn









		if linked_4429 == nil { ifn_4430 = lang.IFn_Cast(root_4428) } else { ifn_4430 = nil }; var arg_4431 any = cs__8; if linked_4429 == nil { tmp9 = ifn_4430.Invoke_O__O(arg_4431) } else { tmp9 = linked_4429.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4428, arg_4431) }
//line :564:1
		if jrt.J2g_Truth(tmp9) { var root_4432 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4432, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4434 lang.IFn; if linked_4433 == nil { ifn_4434 = lang.IFn_Cast(root_4432) } else { ifn_4434 = nil }; var arg_4435 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, cs__8); var arg_4436 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__292000361); var tmp11 any; var root_4437 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4437, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4439 lang.IFn; if linked_4438 == nil { ifn_4439 = lang.IFn_Cast(root_4437) } else { ifn_4439 = nil }; var arg_4440 any = s__292000362__3; if linked_4438 == nil { tmp11 = ifn_4439.Invoke_O__O(arg_4440) } else { tmp11 = linked_4438.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4437, arg_4440) }; arg_4436 = tmp10.Invoke_O__O(tmp11); if linked_4433 == nil { return ifn_4434.Invoke_O_O__O(arg_4435, arg_4436) } else { return linked_4433.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4432, arg_4435, arg_4436) } } else { var tmp12 any; var root_4441 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4441, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4443 lang.IFn; if linked_4442 == nil { ifn_4443 = lang.IFn_Cast(root_4441) } else { ifn_4443 = nil }; var arg_4444 any = s__292000362__3; if linked_4442 == nil { tmp12 = ifn_4443.Invoke_O__O(arg_4444) } else { tmp12 = linked_4442.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4441, arg_4444) }; s__292000362__1 = tmp12; continue L1 } } else { var tmp13 any; var root_4445 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4445, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4447 lang.IFn; if linked_4446 == nil { ifn_4447 = lang.IFn_Cast(root_4445) } else { ifn_4447 = nil }; var arg_4448 any = s__292000362__3; if linked_4446 == nil { tmp13 = ifn_4447.Invoke_O__O(arg_4448) } else { tmp13 = linked_4446.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4445, arg_4448) }; s__292000362__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :564:1
func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :564:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A) Ctor_O_O_I_O(c__b__292000364, c__tset any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000364 = c__b__292000364; t.F_tset = c__tset; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :564:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A) Invoke_O__O(self any) any { { var i__292000363__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000363__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000368__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000363__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000368__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000368__2, lang.RT_IntCast_J__I_NoInit(1), nil); var i__5 any = A_arbace_j2g_dyncf_A_const_468.Invoke_O__O(facets__4); var tmp2 any
																var and__1927000168__auto____6 any = i__5
																if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_4137 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_4138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4137, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4139 lang.IFn; if linked_4138 == nil { ifn_4139 = lang.IFn_Cast(root_4137) } else { ifn_4139 = nil }; var arg_4140 any = lang.IFn_Cast(t.F_tset).Invoke_O__O(n__3); if linked_4138 == nil { and__1927000168__auto____7 = ifn_4139.Invoke_O__O(arg_4140) } else { and__1927000168__auto____7 = linked_4138.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4137, arg_4140) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp3 int64; var na_4141 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(i__5); if jrt.J2g_Truth(or__1927000174__auto____8) { na_4141 = or__1927000174__auto____8 } else { na_4141 = A_arbace_j2g_dyncf_A_const_206 }; var na_4142 int64 = 1; if jrt.Long_InstanceOf(na_4141) { var n0_4143 int64 = jrt.NN(jrt.Long_Cast(na_4141)).LongValue__J(); var n1_4144 int64 = na_4142; tmp3 = n0_4143 & n1_4144 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_4141, na_4142) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp3)).Ref() } else { tmp2 = and__1927000168__auto____7 } } else { tmp2 = and__1927000168__auto____6 }
//line :564:1
	if jrt.J2g_Truth(tmp2) { var cs__6 any; var root_4146 any = A_arbace_j2g_dyncf_A_const_461.GetRawRoot__O(); var linked_4147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4146, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_4148 lang.IFn


		if linked_4147 == nil { ifn_4148 = lang.IFn_Cast(root_4146) } else { ifn_4148 = nil }; var arg_4149 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_462.GetRawRoot__O()).Invoke__O(); var arg_4150 any; var iter__1927001039__auto____6 any; var fnbody__4263 any = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A_New(); var tmp4 *jrt.Class; var fncls__4262 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A_fn_class
		if fncls__4262 == nil { var fncls__4262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A_fn_class = fncls__4262d; tmp4 = fncls__4262d } else { tmp4 = fncls__4262 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4263, tmp4, nil); arg_4150 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(A_arbace_j2g_dyncf_A_const_432.Invoke_O__O(i__5))
//line :567:1
		if linked_4147 == nil { cs__6 = ifn_4148.Invoke_O_O__O(arg_4149, arg_4150) } else { cs__6 = linked_4147.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_4146, arg_4149, arg_4150) }
//line :564:1
		var tmp5 any; var root_4264 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4264, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4266 lang.IFn









		if linked_4265 == nil { ifn_4266 = lang.IFn_Cast(root_4264) } else { ifn_4266 = nil }; var arg_4267 any = cs__6; if linked_4265 == nil { tmp5 = ifn_4266.Invoke_O__O(arg_4267) } else { tmp5 = linked_4265.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4264, arg_4267) }
//line :564:1
		if jrt.J2g_Truth(tmp5) { var root_4268 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4268, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4270 lang.IFn; if linked_4269 == nil { ifn_4270 = lang.IFn_Cast(root_4268) } else { ifn_4270 = nil }; var arg_4271 any = t.F_b__292000364; var arg_4272 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, cs__6); if linked_4269 == nil { ifn_4270.Invoke_O_O__O(arg_4271, arg_4272) } else { linked_4269.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4268, arg_4271, arg_4272) }; i__292000363__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000363__1); continue L1 } else { i__292000363__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000363__1); continue L1 } } else { i__292000363__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000363__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A{}; t.Ctor(); return t }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A) Ctor() {}
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A) Invoke_O_O__O(self, s__292000372__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4261 any = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A_New_O_O(self, s__292000372__1); var tmp2 *jrt.Class; var fncls__4260 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A_fn_class; if fncls__4260 == nil { var fncls__4260d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__4261); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A_fn_class = fncls__4260d; tmp2 = fncls__4260d } else { tmp2 = fncls__4260 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4261, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :568:1
func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A{}; t.Ctor_O_O(p0, p1); return t }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A) Ctor_O_O(c__iter__292000371, c__s__292000372 any) { t.F_iter__292000371 = c__iter__292000371; t.F_s__292000372 = c__s__292000372 }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A) Invoke_O__O(self any) any { { var s__292000372__1 any; var t_ any = t.F_s__292000372; t.F_s__292000372 = nil; s__292000372__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4154 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4154, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4156 lang.IFn; if linked_4155 == nil { ifn_4156 = lang.IFn_Cast(root_4154) } else { ifn_4156 = nil }; var arg_4157 any = s__292000372__1; if linked_4155 == nil { temp__1927000414__auto____2 = ifn_4156.Invoke_O__O(arg_4157) } else { temp__1927000414__auto____2 = linked_4155.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4154, arg_4157) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000372__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4158 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4158, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4160 lang.IFn; if linked_4159 == nil { ifn_4160 = lang.IFn_Cast(root_4158) } else { ifn_4160 = nil }; var arg_4161 any = s__292000372__3; if linked_4159 == nil { tmp1 = ifn_4160.Invoke_O__O(arg_4161) } else { tmp1 = linked_4159.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4158, arg_4161) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4162 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4162, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4164 lang.IFn; if linked_4163 == nil { ifn_4164 = lang.IFn_Cast(root_4162) } else { ifn_4164 = nil }; var arg_4165 any = s__292000372__3; if linked_4163 == nil { c__1927001037__auto____4 = ifn_4164.Invoke_O__O(arg_4165) } else { c__1927001037__auto____4 = linked_4163.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4162, arg_4165) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000374__6 any; var root_4166 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4166, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4168 lang.IFn; if linked_4167 == nil { ifn_4168 = lang.IFn_Cast(root_4166) } else { ifn_4168 = nil }; var arg_4169 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4167 == nil { b__292000374__6 = ifn_4168.Invoke_O__O(arg_4169) } else { b__292000374__6 = linked_4167.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4166, arg_4169) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4198 any = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A_New_O_I_O(b__292000374__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4197 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A_fn_class; if fncls__4197 == nil { var fncls__4197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__4198); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A_fn_class = fncls__4197d; tmp3 = fncls__4197d } else { tmp3 = fncls__4197 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4198, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4199 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4199, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4201 lang.IFn; if linked_4200 == nil { ifn_4201 = lang.IFn_Cast(root_4199) } else { ifn_4201 = nil }; var arg_4202 any; var root_4204 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4204, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4206 lang.IFn; if linked_4205 == nil { ifn_4206 = lang.IFn_Cast(root_4204) } else { ifn_4206 = nil }; var arg_4207 any = b__292000374__6; if linked_4205 == nil { arg_4202 = ifn_4206.Invoke_O__O(arg_4207) } else { arg_4202 = linked_4205.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4204, arg_4207) }; var arg_4203 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000371); var tmp5 any; var root_4208 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4208, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4210 lang.IFn; if linked_4209 == nil { ifn_4210 = lang.IFn_Cast(root_4208) } else { ifn_4210 = nil }; var arg_4211 any = s__292000372__3; if linked_4209 == nil { tmp5 = ifn_4210.Invoke_O__O(arg_4211) } else { tmp5 = linked_4209.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4208, arg_4211) }; arg_4203 = tmp4.Invoke_O__O(tmp5); if linked_4200 == nil { return ifn_4201.Invoke_O_O__O(arg_4202, arg_4203) } else { return linked_4200.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4199, arg_4202, arg_4203) } } else { var root_4212 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4212, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4214 lang.IFn; if linked_4213 == nil { ifn_4214 = lang.IFn_Cast(root_4212) } else { ifn_4214 = nil }; var arg_4215 any; var root_4217 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4217, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4219 lang.IFn; if linked_4218 == nil { ifn_4219 = lang.IFn_Cast(root_4217) } else { ifn_4219 = nil }; var arg_4220 any = b__292000374__6; if linked_4218 == nil { arg_4215 = ifn_4219.Invoke_O__O(arg_4220) } else { arg_4215 = linked_4218.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4217, arg_4220) }; var arg_4216 any; if linked_4213 == nil { return ifn_4214.Invoke_O_O__O(arg_4215, arg_4216) } else { return linked_4213.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4212, arg_4215, arg_4216) } } } else { var f__4 any; var root_4221 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4221, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4223 lang.IFn; if linked_4222 == nil { ifn_4223 = lang.IFn_Cast(root_4221) } else { ifn_4223 = nil }; var arg_4224 any = s__292000372__3; if linked_4222 == nil { f__4 = ifn_4223.Invoke_O__O(arg_4224) } else { f__4 = linked_4222.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4221, arg_4224) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_206 }
//line :568:1
	var v__6 any = A_arbace_j2g_dyncf_A_const_469.Invoke_O__O(f__4); var tmp6 any; var and__1927000168__auto____7 bool; var tmp7 int64
	var na_4225 any = fl__5; var na_4226 int64 = 24
	if jrt.Long_InstanceOf(na_4225) { var n0_4227 int64 = jrt.NN(jrt.Long_Cast(na_4225)).LongValue__J(); var n1_4228 int64 = na_4226; tmp7 = n0_4227 & n1_4228 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_4225, na_4226) }; and__1927000168__auto____7 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp8 int64; var na_4230 any = fl__5; var na_4231 int64 = 5; if jrt.Long_InstanceOf(na_4230) { var n0_4232 int64 = jrt.NN(jrt.Long_Cast(na_4230)).LongValue__J(); var n1_4233 int64 = na_4231; tmp8 = n0_4232 & n1_4233 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_4230, na_4231) }; and__1927000168__auto____8 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var or__1927000174__auto____9 any; var root_4235 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_4236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4235, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_4237 lang.IFn
		if linked_4236 == nil { ifn_4237 = lang.IFn_Cast(root_4235) } else { ifn_4237 = nil }; var arg_4238 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_4236 == nil { or__1927000174__auto____9 = ifn_4237.Invoke_O__O(arg_4238) } else { or__1927000174__auto____9 = linked_4236.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_4235, arg_4238) }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____9 = or__1927000174__auto____9 } else { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_463.GetRawRoot__O())).Ref() }
//line :570:1
		if jrt.J2g_Truth(and__1927000168__auto____9) {

			var root_4239 any = A_arbace_j2g_dyncf_A_const_465.GetRawRoot__O(); var linked_4240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4239, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_4241 lang.IFn; if linked_4240 == nil { ifn_4241 = lang.IFn_Cast(root_4239) } else { ifn_4241 = nil }; var arg_4242 any = v__6; if linked_4240 == nil { tmp6 = ifn_4241.Invoke_O__O(arg_4242) } else { tmp6 = linked_4240.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_4239, arg_4242) } } else {
//line :570:1
				tmp6 = and__1927000168__auto____9 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :568:1
	if jrt.J2g_Truth(tmp6) { var root_4243 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4243, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4245 lang.IFn; if linked_4244 == nil { ifn_4245 = lang.IFn_Cast(root_4243) } else { ifn_4245 = nil }; var arg_4246 any; var tmp9 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp10 any; var tmp11 any; var root_4248 any = A_arbace_j2g_dyncf_A_const_466.GetRawRoot__O(); var linked_4249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4248, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_4250 lang.IFn




		if linked_4249 == nil { ifn_4250 = lang.IFn_Cast(root_4248) } else { ifn_4250 = nil }; var arg_4251 any = v__6; if linked_4249 == nil { tmp11 = ifn_4250.Invoke_O__O(arg_4251) } else { tmp11 = linked_4249.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_4248, arg_4251) }; if jrt.J2g_Truth(tmp11) { tmp10 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp10 = v__6 }
//line :568:1
		arg_4246 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10); var arg_4247 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__292000371); var tmp13 any; var root_4252 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4252, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4254 lang.IFn; if linked_4253 == nil { ifn_4254 = lang.IFn_Cast(root_4252) } else { ifn_4254 = nil }; var arg_4255 any = s__292000372__3; if linked_4253 == nil { tmp13 = ifn_4254.Invoke_O__O(arg_4255) } else { tmp13 = linked_4253.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4252, arg_4255) }; arg_4247 = tmp12.Invoke_O__O(tmp13); if linked_4244 == nil { return ifn_4245.Invoke_O_O__O(arg_4246, arg_4247) } else { return linked_4244.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4243, arg_4246, arg_4247) } } else { var tmp14 any; var root_4256 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4256, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4258 lang.IFn; if linked_4257 == nil { ifn_4258 = lang.IFn_Cast(root_4256) } else { ifn_4258 = nil }; var arg_4259 any = s__292000372__3; if linked_4257 == nil { tmp14 = ifn_4258.Invoke_O__O(arg_4259) } else { tmp14 = linked_4257.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4256, arg_4259) }; s__292000372__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :568:1
func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A) Ctor_O_I_O(c__b__292000374 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000374 = c__b__292000374; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A) Invoke_O__O(self any) any { { var i__292000373__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000373__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000373__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_206 }
//line :568:1
	var v__4 any = A_arbace_j2g_dyncf_A_const_469.Invoke_O__O(f__2); var tmp2 any; var and__1927000168__auto____5 bool; var tmp3 int64
	var na_4170 any = fl__3; var na_4171 int64 = 24
	if jrt.Long_InstanceOf(na_4170) { var n0_4172 int64 = jrt.NN(jrt.Long_Cast(na_4170)).LongValue__J(); var n1_4173 int64 = na_4171; tmp3 = n0_4172 & n1_4173 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_4170, na_4171) }; and__1927000168__auto____5 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool; var tmp4 int64; var na_4175 any = fl__3; var na_4176 int64 = 5; if jrt.Long_InstanceOf(na_4175) { var n0_4177 int64 = jrt.NN(jrt.Long_Cast(na_4175)).LongValue__J(); var n1_4178 int64 = na_4176; tmp4 = n0_4177 & n1_4178 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_4175, na_4176) }; and__1927000168__auto____6 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____6 { var and__1927000168__auto____7 any; var or__1927000174__auto____7 any; var root_4180 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_4181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4180, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_4182 lang.IFn
		if linked_4181 == nil { ifn_4182 = lang.IFn_Cast(root_4180) } else { ifn_4182 = nil }; var arg_4183 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_4181 == nil { or__1927000174__auto____7 = ifn_4182.Invoke_O__O(arg_4183) } else { or__1927000174__auto____7 = linked_4181.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_4180, arg_4183) }; if jrt.J2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7 = or__1927000174__auto____7 } else { and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_463.GetRawRoot__O())).Ref() }
//line :570:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {

			var root_4184 any = A_arbace_j2g_dyncf_A_const_465.GetRawRoot__O(); var linked_4185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4184, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_4186 lang.IFn; if linked_4185 == nil { ifn_4186 = lang.IFn_Cast(root_4184) } else { ifn_4186 = nil }; var arg_4187 any = v__4; if linked_4185 == nil { tmp2 = ifn_4186.Invoke_O__O(arg_4187) } else { tmp2 = linked_4185.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_4184, arg_4187) } } else {
//line :570:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :568:1
	if jrt.J2g_Truth(tmp2) { var root_4188 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4188, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4190 lang.IFn; if linked_4189 == nil { ifn_4190 = lang.IFn_Cast(root_4188) } else { ifn_4190 = nil }; var arg_4191 any = t.F_b__292000374; var arg_4192 any; var tmp5 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp6 any; var tmp7 any; var root_4193 any = A_arbace_j2g_dyncf_A_const_466.GetRawRoot__O(); var linked_4194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4193, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_4195 lang.IFn




		if linked_4194 == nil { ifn_4195 = lang.IFn_Cast(root_4193) } else { ifn_4195 = nil }; var arg_4196 any = v__4; if linked_4194 == nil { tmp7 = ifn_4195.Invoke_O__O(arg_4196) } else { tmp7 = linked_4194.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_4193, arg_4196) }; if jrt.J2g_Truth(tmp7) { tmp6 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp6 = v__4 }
//line :568:1
		arg_4192 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6); if linked_4189 == nil { ifn_4190.Invoke_O_O__O(arg_4191, arg_4192) } else { linked_4189.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4188, arg_4191, arg_4192) }; i__292000373__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000373__1); continue L1 } else { i__292000373__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000373__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :568:1
func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A{}; t.Ctor(); return t }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A) Ctor() {}
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A) Invoke_O_O__O(self, s__292000386__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4425 any = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A_New_O_O(self, s__292000386__1); var tmp2 *jrt.Class; var fncls__4424 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A_fn_class; if fncls__4424 == nil { var fncls__4424d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__4425); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A_fn_class = fncls__4424d; tmp2 = fncls__4424d } else { tmp2 = fncls__4424 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4425, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :568:1
func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A{}; t.Ctor_O_O(p0, p1); return t }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A) Ctor_O_O(c__iter__292000385, c__s__292000386 any) { t.F_iter__292000385 = c__iter__292000385; t.F_s__292000386 = c__s__292000386 }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A) Invoke_O__O(self any) any { { var s__292000386__1 any; var t_ any = t.F_s__292000386; t.F_s__292000386 = nil; s__292000386__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4318 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4318, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4320 lang.IFn; if linked_4319 == nil { ifn_4320 = lang.IFn_Cast(root_4318) } else { ifn_4320 = nil }; var arg_4321 any = s__292000386__1; if linked_4319 == nil { temp__1927000414__auto____2 = ifn_4320.Invoke_O__O(arg_4321) } else { temp__1927000414__auto____2 = linked_4319.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4318, arg_4321) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000386__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4322 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4322, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4324 lang.IFn; if linked_4323 == nil { ifn_4324 = lang.IFn_Cast(root_4322) } else { ifn_4324 = nil }; var arg_4325 any = s__292000386__3; if linked_4323 == nil { tmp1 = ifn_4324.Invoke_O__O(arg_4325) } else { tmp1 = linked_4323.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4322, arg_4325) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4326 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4326, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4328 lang.IFn; if linked_4327 == nil { ifn_4328 = lang.IFn_Cast(root_4326) } else { ifn_4328 = nil }; var arg_4329 any = s__292000386__3; if linked_4327 == nil { c__1927001037__auto____4 = ifn_4328.Invoke_O__O(arg_4329) } else { c__1927001037__auto____4 = linked_4327.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4326, arg_4329) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000388__6 any; var root_4330 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4330, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4332 lang.IFn; if linked_4331 == nil { ifn_4332 = lang.IFn_Cast(root_4330) } else { ifn_4332 = nil }; var arg_4333 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4331 == nil { b__292000388__6 = ifn_4332.Invoke_O__O(arg_4333) } else { b__292000388__6 = linked_4331.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4330, arg_4333) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4362 any = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A_New_O_I_O(b__292000388__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4361 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A_fn_class; if fncls__4361 == nil { var fncls__4361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__4362); A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A_fn_class = fncls__4361d; tmp3 = fncls__4361d } else { tmp3 = fncls__4361 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4362, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4363 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4363, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4365 lang.IFn; if linked_4364 == nil { ifn_4365 = lang.IFn_Cast(root_4363) } else { ifn_4365 = nil }; var arg_4366 any; var root_4368 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4368, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4370 lang.IFn; if linked_4369 == nil { ifn_4370 = lang.IFn_Cast(root_4368) } else { ifn_4370 = nil }; var arg_4371 any = b__292000388__6; if linked_4369 == nil { arg_4366 = ifn_4370.Invoke_O__O(arg_4371) } else { arg_4366 = linked_4369.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4368, arg_4371) }; var arg_4367 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000385); var tmp5 any; var root_4372 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4372, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4374 lang.IFn; if linked_4373 == nil { ifn_4374 = lang.IFn_Cast(root_4372) } else { ifn_4374 = nil }; var arg_4375 any = s__292000386__3; if linked_4373 == nil { tmp5 = ifn_4374.Invoke_O__O(arg_4375) } else { tmp5 = linked_4373.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4372, arg_4375) }; arg_4367 = tmp4.Invoke_O__O(tmp5); if linked_4364 == nil { return ifn_4365.Invoke_O_O__O(arg_4366, arg_4367) } else { return linked_4364.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4363, arg_4366, arg_4367) } } else { var root_4376 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4376, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4378 lang.IFn; if linked_4377 == nil { ifn_4378 = lang.IFn_Cast(root_4376) } else { ifn_4378 = nil }; var arg_4379 any; var root_4381 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4381, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4383 lang.IFn; if linked_4382 == nil { ifn_4383 = lang.IFn_Cast(root_4381) } else { ifn_4383 = nil }; var arg_4384 any = b__292000388__6; if linked_4382 == nil { arg_4379 = ifn_4383.Invoke_O__O(arg_4384) } else { arg_4379 = linked_4382.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4381, arg_4384) }; var arg_4380 any; if linked_4377 == nil { return ifn_4378.Invoke_O_O__O(arg_4379, arg_4380) } else { return linked_4377.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4376, arg_4379, arg_4380) } } } else { var f__4 any; var root_4385 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4385, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4387 lang.IFn; if linked_4386 == nil { ifn_4387 = lang.IFn_Cast(root_4385) } else { ifn_4387 = nil }; var arg_4388 any = s__292000386__3; if linked_4386 == nil { f__4 = ifn_4387.Invoke_O__O(arg_4388) } else { f__4 = linked_4386.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4385, arg_4388) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_206 }
//line :568:1
	var v__6 any = A_arbace_j2g_dyncf_A_const_469.Invoke_O__O(f__4); var tmp6 any; var and__1927000168__auto____7 bool; var tmp7 int64
	var na_4389 any = fl__5; var na_4390 int64 = 24
	if jrt.Long_InstanceOf(na_4389) { var n0_4391 int64 = jrt.NN(jrt.Long_Cast(na_4389)).LongValue__J(); var n1_4392 int64 = na_4390; tmp7 = n0_4391 & n1_4392 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_4389, na_4390) }; and__1927000168__auto____7 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp8 int64; var na_4394 any = fl__5; var na_4395 int64 = 5; if jrt.Long_InstanceOf(na_4394) { var n0_4396 int64 = jrt.NN(jrt.Long_Cast(na_4394)).LongValue__J(); var n1_4397 int64 = na_4395; tmp8 = n0_4396 & n1_4397 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_4394, na_4395) }; and__1927000168__auto____8 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var or__1927000174__auto____9 any; var root_4399 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_4400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4399, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_4401 lang.IFn
		if linked_4400 == nil { ifn_4401 = lang.IFn_Cast(root_4399) } else { ifn_4401 = nil }; var arg_4402 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_4400 == nil { or__1927000174__auto____9 = ifn_4401.Invoke_O__O(arg_4402) } else { or__1927000174__auto____9 = linked_4400.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_4399, arg_4402) }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____9 = or__1927000174__auto____9 } else { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_463.GetRawRoot__O())).Ref() }
//line :570:1
		if jrt.J2g_Truth(and__1927000168__auto____9) {

			var root_4403 any = A_arbace_j2g_dyncf_A_const_465.GetRawRoot__O(); var linked_4404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4403, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_4405 lang.IFn; if linked_4404 == nil { ifn_4405 = lang.IFn_Cast(root_4403) } else { ifn_4405 = nil }; var arg_4406 any = v__6; if linked_4404 == nil { tmp6 = ifn_4405.Invoke_O__O(arg_4406) } else { tmp6 = linked_4404.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_4403, arg_4406) } } else {
//line :570:1
				tmp6 = and__1927000168__auto____9 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :568:1
	if jrt.J2g_Truth(tmp6) { var root_4407 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4407, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4409 lang.IFn; if linked_4408 == nil { ifn_4409 = lang.IFn_Cast(root_4407) } else { ifn_4409 = nil }; var arg_4410 any; var tmp9 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp10 any; var tmp11 any; var root_4412 any = A_arbace_j2g_dyncf_A_const_466.GetRawRoot__O(); var linked_4413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4412, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_4414 lang.IFn




		if linked_4413 == nil { ifn_4414 = lang.IFn_Cast(root_4412) } else { ifn_4414 = nil }; var arg_4415 any = v__6; if linked_4413 == nil { tmp11 = ifn_4414.Invoke_O__O(arg_4415) } else { tmp11 = linked_4413.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_4412, arg_4415) }; if jrt.J2g_Truth(tmp11) { tmp10 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp10 = v__6 }
//line :568:1
		arg_4410 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10); var arg_4411 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__292000385); var tmp13 any; var root_4416 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4416, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4418 lang.IFn; if linked_4417 == nil { ifn_4418 = lang.IFn_Cast(root_4416) } else { ifn_4418 = nil }; var arg_4419 any = s__292000386__3; if linked_4417 == nil { tmp13 = ifn_4418.Invoke_O__O(arg_4419) } else { tmp13 = linked_4417.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4416, arg_4419) }; arg_4411 = tmp12.Invoke_O__O(tmp13); if linked_4408 == nil { return ifn_4409.Invoke_O_O__O(arg_4410, arg_4411) } else { return linked_4408.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4407, arg_4410, arg_4411) } } else { var tmp14 any; var root_4420 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4420, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4422 lang.IFn; if linked_4421 == nil { ifn_4422 = lang.IFn_Cast(root_4420) } else { ifn_4422 = nil }; var arg_4423 any = s__292000386__3; if linked_4421 == nil { tmp14 = ifn_4422.Invoke_O__O(arg_4423) } else { tmp14 = linked_4421.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4420, arg_4423) }; s__292000386__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :568:1
func A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A) Ctor_O_I_O(c__b__292000388 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000388 = c__b__292000388; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :568:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A) Invoke_O__O(self any) any { { var i__292000387__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000387__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000387__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_205.Invoke_O__O(f__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_206 }
//line :568:1
	var v__4 any = A_arbace_j2g_dyncf_A_const_469.Invoke_O__O(f__2); var tmp2 any; var and__1927000168__auto____5 bool; var tmp3 int64
	var na_4334 any = fl__3; var na_4335 int64 = 24
	if jrt.Long_InstanceOf(na_4334) { var n0_4336 int64 = jrt.NN(jrt.Long_Cast(na_4334)).LongValue__J(); var n1_4337 int64 = na_4335; tmp3 = n0_4336 & n1_4337 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_4334, na_4335) }; and__1927000168__auto____5 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool; var tmp4 int64; var na_4339 any = fl__3; var na_4340 int64 = 5; if jrt.Long_InstanceOf(na_4339) { var n0_4341 int64 = jrt.NN(jrt.Long_Cast(na_4339)).LongValue__J(); var n1_4342 int64 = na_4340; tmp4 = n0_4341 & n1_4342 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_4339, na_4340) }; and__1927000168__auto____6 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____6 { var and__1927000168__auto____7 any; var or__1927000174__auto____7 any; var root_4344 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_4345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4344, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_4346 lang.IFn
		if linked_4345 == nil { ifn_4346 = lang.IFn_Cast(root_4344) } else { ifn_4346 = nil }; var arg_4347 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_4345 == nil { or__1927000174__auto____7 = ifn_4346.Invoke_O__O(arg_4347) } else { or__1927000174__auto____7 = linked_4345.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_4344, arg_4347) }; if jrt.J2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7 = or__1927000174__auto____7 } else { and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_463.GetRawRoot__O())).Ref() }
//line :570:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {

			var root_4348 any = A_arbace_j2g_dyncf_A_const_465.GetRawRoot__O(); var linked_4349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4348, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_4350 lang.IFn; if linked_4349 == nil { ifn_4350 = lang.IFn_Cast(root_4348) } else { ifn_4350 = nil }; var arg_4351 any = v__4; if linked_4349 == nil { tmp2 = ifn_4350.Invoke_O__O(arg_4351) } else { tmp2 = linked_4349.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_4348, arg_4351) } } else {
//line :570:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :568:1
	if jrt.J2g_Truth(tmp2) { var root_4352 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4352, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4354 lang.IFn; if linked_4353 == nil { ifn_4354 = lang.IFn_Cast(root_4352) } else { ifn_4354 = nil }; var arg_4355 any = t.F_b__292000388; var arg_4356 any; var tmp5 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp6 any; var tmp7 any; var root_4357 any = A_arbace_j2g_dyncf_A_const_466.GetRawRoot__O(); var linked_4358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4357, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_4359 lang.IFn




		if linked_4358 == nil { ifn_4359 = lang.IFn_Cast(root_4357) } else { ifn_4359 = nil }; var arg_4360 any = v__4; if linked_4358 == nil { tmp7 = ifn_4359.Invoke_O__O(arg_4360) } else { tmp7 = linked_4358.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_4357, arg_4360) }; if jrt.J2g_Truth(tmp7) { tmp6 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp6 = v__4 }
//line :568:1
		arg_4356 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6); if linked_4353 == nil { ifn_4354.Invoke_O_O__O(arg_4355, arg_4356) } else { linked_4353.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4352, arg_4355, arg_4356) }; i__292000387__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000387__1); continue L1 } else { i__292000387__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000387__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A{}; t.Ctor(); return t }
//line :586:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A) Ctor() {}
//line :586:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A) Invoke_O_O__O(self, s__292000398__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4547 any = A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A_New_O_O(self, s__292000398__1); var tmp2 *jrt.Class; var fncls__4546 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A_fn_class; if fncls__4546 == nil { var fncls__4546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__4547); A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A_fn_class = fncls__4546d; tmp2 = fncls__4546d } else { tmp2 = fncls__4546 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4547, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :586:1
func A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A{}; t.Ctor_O_O(p0, p1); return t }
//line :586:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A) Ctor_O_O(c__iter__292000397, c__s__292000398 any) { t.F_iter__292000397 = c__iter__292000397; t.F_s__292000398 = c__s__292000398 }
//line :586:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A) Invoke_O__O(self any) any { { var s__292000398__1 any; var t_ any = t.F_s__292000398; t.F_s__292000398 = nil; s__292000398__1 = t_; for { var temp__1927000414__auto____2 any; var root_4472 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4472, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4474 lang.IFn; if linked_4473 == nil { ifn_4474 = lang.IFn_Cast(root_4472) } else { ifn_4474 = nil }; var arg_4475 any = s__292000398__1; if linked_4473 == nil { temp__1927000414__auto____2 = ifn_4474.Invoke_O__O(arg_4475) } else { temp__1927000414__auto____2 = linked_4473.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4472, arg_4475) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000398__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4476 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4476, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4478 lang.IFn; if linked_4477 == nil { ifn_4478 = lang.IFn_Cast(root_4476) } else { ifn_4478 = nil }; var arg_4479 any = s__292000398__3; if linked_4477 == nil { tmp1 = ifn_4478.Invoke_O__O(arg_4479) } else { tmp1 = linked_4477.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4476, arg_4479) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4480 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4480, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4482 lang.IFn; if linked_4481 == nil { ifn_4482 = lang.IFn_Cast(root_4480) } else { ifn_4482 = nil }; var arg_4483 any = s__292000398__3; if linked_4481 == nil { c__1927001037__auto____4 = ifn_4482.Invoke_O__O(arg_4483) } else { c__1927001037__auto____4 = linked_4481.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4480, arg_4483) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000400__6 any; var root_4484 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4484, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4486 lang.IFn; if linked_4485 == nil { ifn_4486 = lang.IFn_Cast(root_4484) } else { ifn_4486 = nil }; var arg_4487 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4485 == nil { b__292000400__6 = ifn_4486.Invoke_O__O(arg_4487) } else { b__292000400__6 = linked_4485.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4484, arg_4487) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4502 any = A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A_New_O_I_O(b__292000400__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4501 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A_fn_class; if fncls__4501 == nil { var fncls__4501d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, fnbody__4502); A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A_fn_class = fncls__4501d; tmp3 = fncls__4501d } else { tmp3 = fncls__4501 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4502, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4503 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4503, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4505 lang.IFn; if linked_4504 == nil { ifn_4505 = lang.IFn_Cast(root_4503) } else { ifn_4505 = nil }; var arg_4506 any; var root_4508 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4508, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4510 lang.IFn; if linked_4509 == nil { ifn_4510 = lang.IFn_Cast(root_4508) } else { ifn_4510 = nil }; var arg_4511 any = b__292000400__6; if linked_4509 == nil { arg_4506 = ifn_4510.Invoke_O__O(arg_4511) } else { arg_4506 = linked_4509.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4508, arg_4511) }; var arg_4507 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000397); var tmp5 any; var root_4512 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4512, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4514 lang.IFn; if linked_4513 == nil { ifn_4514 = lang.IFn_Cast(root_4512) } else { ifn_4514 = nil }; var arg_4515 any = s__292000398__3; if linked_4513 == nil { tmp5 = ifn_4514.Invoke_O__O(arg_4515) } else { tmp5 = linked_4513.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4512, arg_4515) }; arg_4507 = tmp4.Invoke_O__O(tmp5); if linked_4504 == nil { return ifn_4505.Invoke_O_O__O(arg_4506, arg_4507) } else { return linked_4504.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4503, arg_4506, arg_4507) } } else { var root_4516 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4516, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4518 lang.IFn; if linked_4517 == nil { ifn_4518 = lang.IFn_Cast(root_4516) } else { ifn_4518 = nil }; var arg_4519 any; var root_4521 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4521, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4523 lang.IFn; if linked_4522 == nil { ifn_4523 = lang.IFn_Cast(root_4521) } else { ifn_4523 = nil }; var arg_4524 any = b__292000400__6; if linked_4522 == nil { arg_4519 = ifn_4523.Invoke_O__O(arg_4524) } else { arg_4519 = linked_4522.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4521, arg_4524) }; var arg_4520 any; if linked_4517 == nil { return ifn_4518.Invoke_O_O__O(arg_4519, arg_4520) } else { return linked_4517.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4516, arg_4519, arg_4520) } } } else { var vec__292000408__4 any; var root_4525 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4525, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4527 lang.IFn; if linked_4526 == nil { ifn_4527 = lang.IFn_Cast(root_4525) } else { ifn_4527 = nil }; var arg_4528 any = s__292000398__3; if linked_4526 == nil { vec__292000408__4 = ifn_4527.Invoke_O__O(arg_4528) } else { vec__292000408__4 = linked_4526.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4525, arg_4528) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000408__4, lang.RT_IntCast_J__I_NoInit(0), nil); var g__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000408__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4529 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4529, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4531 lang.IFn; if linked_4530 == nil { ifn_4531 = lang.IFn_Cast(root_4529) } else { ifn_4531 = nil }; var arg_4532 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(g__6))).Ref(); var arg_4533 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000397); var tmp7 any; var root_4542 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4542, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4544 lang.IFn; if linked_4543 == nil { ifn_4544 = lang.IFn_Cast(root_4542) } else { ifn_4544 = nil }; var arg_4545 any = s__292000398__3; if linked_4543 == nil { tmp7 = ifn_4544.Invoke_O__O(arg_4545) } else { tmp7 = linked_4543.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4542, arg_4545) }; arg_4533 = tmp6.Invoke_O__O(tmp7); if linked_4530 == nil { return ifn_4531.Invoke_O_O__O(arg_4532, arg_4533) } else { return linked_4530.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4529, arg_4532, arg_4533) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :586:1
func A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :586:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A) Ctor_O_I_O(c__b__292000400 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000400 = c__b__292000400; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :586:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A) Invoke_O__O(self any) any { { var i__292000399__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000399__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000404__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000399__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000404__2, lang.RT_IntCast_J__I_NoInit(0), nil); var g__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000404__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4488 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4488, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4490 lang.IFn; if linked_4489 == nil { ifn_4490 = lang.IFn_Cast(root_4488) } else { ifn_4490 = nil }; var arg_4491 any = t.F_b__292000400; var arg_4492 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(g__4))).Ref(); if linked_4489 == nil { ifn_4490.Invoke_O_O__O(arg_4491, arg_4492) } else { linked_4489.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4488, arg_4491, arg_4492) }; i__292000399__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000399__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A{}; t.Ctor(); return t }
//line :588:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A) Ctor() {}
//line :588:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A) Invoke_O_O__O(self, s__292000414__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4640 any = A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A_New_O_O(self, s__292000414__1); var tmp2 *jrt.Class; var fncls__4639 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A_fn_class; if fncls__4639 == nil { var fncls__4639d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, fnbody__4640); A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A_fn_class = fncls__4639d; tmp2 = fncls__4639d } else { tmp2 = fncls__4639 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4640, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :588:1
func A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A{}; t.Ctor_O_O(p0, p1); return t }
//line :588:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A) Ctor_O_O(c__iter__292000413, c__s__292000414 any) { t.F_iter__292000413 = c__iter__292000413; t.F_s__292000414 = c__s__292000414 }
//line :588:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A) Invoke_O__O(self any) any { { var s__292000414__1 any; var t_ any = t.F_s__292000414; t.F_s__292000414 = nil; s__292000414__1 = t_; for { var temp__1927000414__auto____2 any; var root_4565 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4565, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4567 lang.IFn; if linked_4566 == nil { ifn_4567 = lang.IFn_Cast(root_4565) } else { ifn_4567 = nil }; var arg_4568 any = s__292000414__1; if linked_4566 == nil { temp__1927000414__auto____2 = ifn_4567.Invoke_O__O(arg_4568) } else { temp__1927000414__auto____2 = linked_4566.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4565, arg_4568) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000414__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4569 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4569, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4571 lang.IFn; if linked_4570 == nil { ifn_4571 = lang.IFn_Cast(root_4569) } else { ifn_4571 = nil }; var arg_4572 any = s__292000414__3; if linked_4570 == nil { tmp1 = ifn_4571.Invoke_O__O(arg_4572) } else { tmp1 = linked_4570.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4569, arg_4572) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4573 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4573, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4575 lang.IFn; if linked_4574 == nil { ifn_4575 = lang.IFn_Cast(root_4573) } else { ifn_4575 = nil }; var arg_4576 any = s__292000414__3; if linked_4574 == nil { c__1927001037__auto____4 = ifn_4575.Invoke_O__O(arg_4576) } else { c__1927001037__auto____4 = linked_4574.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4573, arg_4576) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000416__6 any; var root_4577 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4577, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4579 lang.IFn; if linked_4578 == nil { ifn_4579 = lang.IFn_Cast(root_4577) } else { ifn_4579 = nil }; var arg_4580 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4578 == nil { b__292000416__6 = ifn_4579.Invoke_O__O(arg_4580) } else { b__292000416__6 = linked_4578.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4577, arg_4580) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4595 any = A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A_New_O_I_O(b__292000416__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4594 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A_fn_class; if fncls__4594 == nil { var fncls__4594d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__4595); A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A_fn_class = fncls__4594d; tmp3 = fncls__4594d } else { tmp3 = fncls__4594 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4595, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4596 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4596, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4598 lang.IFn; if linked_4597 == nil { ifn_4598 = lang.IFn_Cast(root_4596) } else { ifn_4598 = nil }; var arg_4599 any; var root_4601 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4601, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4603 lang.IFn; if linked_4602 == nil { ifn_4603 = lang.IFn_Cast(root_4601) } else { ifn_4603 = nil }; var arg_4604 any = b__292000416__6; if linked_4602 == nil { arg_4599 = ifn_4603.Invoke_O__O(arg_4604) } else { arg_4599 = linked_4602.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4601, arg_4604) }; var arg_4600 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000413); var tmp5 any; var root_4605 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4605, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4607 lang.IFn; if linked_4606 == nil { ifn_4607 = lang.IFn_Cast(root_4605) } else { ifn_4607 = nil }; var arg_4608 any = s__292000414__3; if linked_4606 == nil { tmp5 = ifn_4607.Invoke_O__O(arg_4608) } else { tmp5 = linked_4606.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4605, arg_4608) }; arg_4600 = tmp4.Invoke_O__O(tmp5); if linked_4597 == nil { return ifn_4598.Invoke_O_O__O(arg_4599, arg_4600) } else { return linked_4597.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4596, arg_4599, arg_4600) } } else { var root_4609 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4609, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4611 lang.IFn; if linked_4610 == nil { ifn_4611 = lang.IFn_Cast(root_4609) } else { ifn_4611 = nil }; var arg_4612 any; var root_4614 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4614, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4616 lang.IFn; if linked_4615 == nil { ifn_4616 = lang.IFn_Cast(root_4614) } else { ifn_4616 = nil }; var arg_4617 any = b__292000416__6; if linked_4615 == nil { arg_4612 = ifn_4616.Invoke_O__O(arg_4617) } else { arg_4612 = linked_4615.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4614, arg_4617) }; var arg_4613 any; if linked_4610 == nil { return ifn_4611.Invoke_O_O__O(arg_4612, arg_4613) } else { return linked_4610.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4609, arg_4612, arg_4613) } } } else { var vec__292000424__4 any; var root_4618 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4618, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4620 lang.IFn; if linked_4619 == nil { ifn_4620 = lang.IFn_Cast(root_4618) } else { ifn_4620 = nil }; var arg_4621 any = s__292000414__3; if linked_4619 == nil { vec__292000424__4 = ifn_4620.Invoke_O__O(arg_4621) } else { vec__292000424__4 = linked_4619.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4618, arg_4621) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000424__4, lang.RT_IntCast_J__I_NoInit(0), nil); var cs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000424__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4622 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4622, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4624 lang.IFn; if linked_4623 == nil { ifn_4624 = lang.IFn_Cast(root_4622) } else { ifn_4624 = nil }; var arg_4625 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(cs__6))).Ref(); var arg_4626 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000413); var tmp7 any; var root_4635 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4635, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4637 lang.IFn; if linked_4636 == nil { ifn_4637 = lang.IFn_Cast(root_4635) } else { ifn_4637 = nil }; var arg_4638 any = s__292000414__3; if linked_4636 == nil { tmp7 = ifn_4637.Invoke_O__O(arg_4638) } else { tmp7 = linked_4636.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4635, arg_4638) }; arg_4626 = tmp6.Invoke_O__O(tmp7); if linked_4623 == nil { return ifn_4624.Invoke_O_O__O(arg_4625, arg_4626) } else { return linked_4623.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4622, arg_4625, arg_4626) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :588:1
func A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :588:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A) Ctor_O_I_O(c__b__292000416 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000416 = c__b__292000416; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :588:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A) Invoke_O__O(self any) any { { var i__292000415__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000415__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000420__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000415__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000420__2, lang.RT_IntCast_J__I_NoInit(0), nil); var cs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000420__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4581 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4581, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4583 lang.IFn; if linked_4582 == nil { ifn_4583 = lang.IFn_Cast(root_4581) } else { ifn_4583 = nil }; var arg_4584 any = t.F_b__292000416; var arg_4585 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(cs__4))).Ref(); if linked_4582 == nil { ifn_4583.Invoke_O_O__O(arg_4584, arg_4585) } else { linked_4582.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4581, arg_4584, arg_4585) }; i__292000415__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000415__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A{}; t.Ctor(); return t }
//line :590:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A) Ctor() {}
//line :590:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A) Invoke_O_O__O(self, s__292000430__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4723 any = A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A_New_O_O(s__292000430__1, self); var tmp2 *jrt.Class; var fncls__4722 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A_fn_class; if fncls__4722 == nil { var fncls__4722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__4723); A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A_fn_class = fncls__4722d; tmp2 = fncls__4722d } else { tmp2 = fncls__4722 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4723, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :590:1
func A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A{}; t.Ctor_O_O(p0, p1); return t }
//line :590:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A) Ctor_O_O(c__s__292000430, c__iter__292000429 any) { t.F_s__292000430 = c__s__292000430; t.F_iter__292000429 = c__iter__292000429 }
//line :590:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A) Invoke_O__O(self any) any { { var s__292000430__1 any; var t_ any = t.F_s__292000430; t.F_s__292000430 = nil; s__292000430__1 = t_; for { var temp__1927000414__auto____2 any; var root_4648 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4648, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4650 lang.IFn; if linked_4649 == nil { ifn_4650 = lang.IFn_Cast(root_4648) } else { ifn_4650 = nil }; var arg_4651 any = s__292000430__1; if linked_4649 == nil { temp__1927000414__auto____2 = ifn_4650.Invoke_O__O(arg_4651) } else { temp__1927000414__auto____2 = linked_4649.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4648, arg_4651) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000430__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4652 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4652, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4654 lang.IFn; if linked_4653 == nil { ifn_4654 = lang.IFn_Cast(root_4652) } else { ifn_4654 = nil }; var arg_4655 any = s__292000430__3; if linked_4653 == nil { tmp1 = ifn_4654.Invoke_O__O(arg_4655) } else { tmp1 = linked_4653.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4652, arg_4655) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4656 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4656, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4658 lang.IFn; if linked_4657 == nil { ifn_4658 = lang.IFn_Cast(root_4656) } else { ifn_4658 = nil }; var arg_4659 any = s__292000430__3; if linked_4657 == nil { c__1927001037__auto____4 = ifn_4658.Invoke_O__O(arg_4659) } else { c__1927001037__auto____4 = linked_4657.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4656, arg_4659) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000432__6 any; var root_4660 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4660, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4662 lang.IFn; if linked_4661 == nil { ifn_4662 = lang.IFn_Cast(root_4660) } else { ifn_4662 = nil }; var arg_4663 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4661 == nil { b__292000432__6 = ifn_4662.Invoke_O__O(arg_4663) } else { b__292000432__6 = linked_4661.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4660, arg_4663) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4678 any = A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A_New_O_I_O(b__292000432__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4677 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A_fn_class; if fncls__4677 == nil { var fncls__4677d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, fnbody__4678); A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A_fn_class = fncls__4677d; tmp3 = fncls__4677d } else { tmp3 = fncls__4677 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4678, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4679 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4679, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4681 lang.IFn; if linked_4680 == nil { ifn_4681 = lang.IFn_Cast(root_4679) } else { ifn_4681 = nil }; var arg_4682 any; var root_4684 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4684, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4686 lang.IFn; if linked_4685 == nil { ifn_4686 = lang.IFn_Cast(root_4684) } else { ifn_4686 = nil }; var arg_4687 any = b__292000432__6; if linked_4685 == nil { arg_4682 = ifn_4686.Invoke_O__O(arg_4687) } else { arg_4682 = linked_4685.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4684, arg_4687) }; var arg_4683 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000429); var tmp5 any; var root_4688 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4688, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4690 lang.IFn; if linked_4689 == nil { ifn_4690 = lang.IFn_Cast(root_4688) } else { ifn_4690 = nil }; var arg_4691 any = s__292000430__3; if linked_4689 == nil { tmp5 = ifn_4690.Invoke_O__O(arg_4691) } else { tmp5 = linked_4689.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4688, arg_4691) }; arg_4683 = tmp4.Invoke_O__O(tmp5); if linked_4680 == nil { return ifn_4681.Invoke_O_O__O(arg_4682, arg_4683) } else { return linked_4680.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4679, arg_4682, arg_4683) } } else { var root_4692 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4692, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4694 lang.IFn; if linked_4693 == nil { ifn_4694 = lang.IFn_Cast(root_4692) } else { ifn_4694 = nil }; var arg_4695 any; var root_4697 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4697, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4699 lang.IFn; if linked_4698 == nil { ifn_4699 = lang.IFn_Cast(root_4697) } else { ifn_4699 = nil }; var arg_4700 any = b__292000432__6; if linked_4698 == nil { arg_4695 = ifn_4699.Invoke_O__O(arg_4700) } else { arg_4695 = linked_4698.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4697, arg_4700) }; var arg_4696 any; if linked_4693 == nil { return ifn_4694.Invoke_O_O__O(arg_4695, arg_4696) } else { return linked_4693.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4692, arg_4695, arg_4696) } } } else { var vec__292000440__4 any; var root_4701 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4701, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4703 lang.IFn; if linked_4702 == nil { ifn_4703 = lang.IFn_Cast(root_4701) } else { ifn_4703 = nil }; var arg_4704 any = s__292000430__3; if linked_4702 == nil { vec__292000440__4 = ifn_4703.Invoke_O__O(arg_4704) } else { vec__292000440__4 = linked_4702.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4701, arg_4704) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000440__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ms__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000440__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4705 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4705, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4707 lang.IFn; if linked_4706 == nil { ifn_4707 = lang.IFn_Cast(root_4705) } else { ifn_4707 = nil }; var arg_4708 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(ms__6))).Ref(); var arg_4709 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000429); var tmp7 any; var root_4718 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4718, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4720 lang.IFn; if linked_4719 == nil { ifn_4720 = lang.IFn_Cast(root_4718) } else { ifn_4720 = nil }; var arg_4721 any = s__292000430__3; if linked_4719 == nil { tmp7 = ifn_4720.Invoke_O__O(arg_4721) } else { tmp7 = linked_4719.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4718, arg_4721) }; arg_4709 = tmp6.Invoke_O__O(tmp7); if linked_4706 == nil { return ifn_4707.Invoke_O_O__O(arg_4708, arg_4709) } else { return linked_4706.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4705, arg_4708, arg_4709) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :590:1
func A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :590:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A) Ctor_O_I_O(c__b__292000432 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000432 = c__b__292000432; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :590:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A) Invoke_O__O(self any) any { { var i__292000431__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000431__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000436__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000431__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000436__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ms__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000436__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4664 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4664, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4666 lang.IFn; if linked_4665 == nil { ifn_4666 = lang.IFn_Cast(root_4664) } else { ifn_4666 = nil }; var arg_4667 any = t.F_b__292000432; var arg_4668 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_472.GetRawRoot__O()).Invoke_O__O(ms__4))).Ref(); if linked_4665 == nil { ifn_4666.Invoke_O_O__O(arg_4667, arg_4668) } else { linked_4665.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4664, arg_4667, arg_4668) }; i__292000431__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000431__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































































































































































































































































































































































































































type A_arbace_j2g_dyncf_A struct{ jrt.Object }

var A_arbace_j2g_dyncf_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyncf_A_const_0 *lang.Var

var A_arbace_j2g_dyncf_A_const_1 any

var A_arbace_j2g_dyncf_A_const_2 any

var A_arbace_j2g_dyncf_A_const_3 any

var A_arbace_j2g_dyncf_A_const_4 any

var A_arbace_j2g_dyncf_A_const_5 any

var A_arbace_j2g_dyncf_A_const_6 any

var A_arbace_j2g_dyncf_A_const_7 any

var A_arbace_j2g_dyncf_A_const_8 any

var A_arbace_j2g_dyncf_A_const_9 any

var A_arbace_j2g_dyncf_A_const_10 any

var A_arbace_j2g_dyncf_A_const_11 any

var A_arbace_j2g_dyncf_A_const_12 *lang.Var

var A_arbace_j2g_dyncf_A_const_13 any

var A_arbace_j2g_dyncf_A_const_14 *lang.Var

var A_arbace_j2g_dyncf_A_const_15 *lang.Var

var A_arbace_j2g_dyncf_A_const_16 *lang.Var

var A_arbace_j2g_dyncf_A_const_17 *lang.Var

var A_arbace_j2g_dyncf_A_const_18 any

var A_arbace_j2g_dyncf_A_const_19 *lang.Var

var A_arbace_j2g_dyncf_A_const_20 *lang.Var

var A_arbace_j2g_dyncf_A_const_21 *lang.Var

var A_arbace_j2g_dyncf_A_const_22 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_23 *lang.Var

var A_arbace_j2g_dyncf_A_const_24 *lang.Var

var A_arbace_j2g_dyncf_A_const_25 *lang.Var

var A_arbace_j2g_dyncf_A_const_26 *lang.Var

var A_arbace_j2g_dyncf_A_const_27 *lang.Var

var A_arbace_j2g_dyncf_A_const_28 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_29 any

var A_arbace_j2g_dyncf_A_const_30 *lang.Var

var A_arbace_j2g_dyncf_A_const_31 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_32 any

var A_arbace_j2g_dyncf_A_const_33 *lang.Var

var A_arbace_j2g_dyncf_A_const_34 any

var A_arbace_j2g_dyncf_A_const_35 any

var A_arbace_j2g_dyncf_A_const_36 *lang.Var

var A_arbace_j2g_dyncf_A_const_37 *lang.Var

var A_arbace_j2g_dyncf_A_const_38 any

var A_arbace_j2g_dyncf_A_const_39 *lang.Var

var A_arbace_j2g_dyncf_A_const_40 *lang.Var

var A_arbace_j2g_dyncf_A_const_41 *lang.Var

var A_arbace_j2g_dyncf_A_const_42 any

var A_arbace_j2g_dyncf_A_const_43 any

var A_arbace_j2g_dyncf_A_const_44 *lang.Var

var A_arbace_j2g_dyncf_A_const_45 any

var A_arbace_j2g_dyncf_A_const_46 any

var A_arbace_j2g_dyncf_A_const_47 any

var A_arbace_j2g_dyncf_A_const_48 any

var A_arbace_j2g_dyncf_A_const_49 any

var A_arbace_j2g_dyncf_A_const_50 *lang.Var

var A_arbace_j2g_dyncf_A_const_51 *lang.Var

var A_arbace_j2g_dyncf_A_const_52 any

var A_arbace_j2g_dyncf_A_const_53 *lang.Var

var A_arbace_j2g_dyncf_A_const_54 any

var A_arbace_j2g_dyncf_A_const_55 any

var A_arbace_j2g_dyncf_A_const_56 any

var A_arbace_j2g_dyncf_A_const_57 any

var A_arbace_j2g_dyncf_A_const_58 any

var A_arbace_j2g_dyncf_A_const_59 any

var A_arbace_j2g_dyncf_A_const_60 any

var A_arbace_j2g_dyncf_A_const_61 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_62 any

var A_arbace_j2g_dyncf_A_const_63 any

var A_arbace_j2g_dyncf_A_const_64 any

var A_arbace_j2g_dyncf_A_const_65 *lang.Var

var A_arbace_j2g_dyncf_A_const_66 any

var A_arbace_j2g_dyncf_A_const_67 any

var A_arbace_j2g_dyncf_A_const_68 *lang.Var

var A_arbace_j2g_dyncf_A_const_69 *lang.Var

var A_arbace_j2g_dyncf_A_const_70 *lang.Var

var A_arbace_j2g_dyncf_A_const_71 *lang.Var

var A_arbace_j2g_dyncf_A_const_72 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_73 *lang.Var

var A_arbace_j2g_dyncf_A_const_74 *lang.Var

var A_arbace_j2g_dyncf_A_const_75 *lang.Var

var A_arbace_j2g_dyncf_A_const_76 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_77 *lang.Var

var A_arbace_j2g_dyncf_A_const_78 *lang.Var

var A_arbace_j2g_dyncf_A_const_79 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_80 *lang.Var

var A_arbace_j2g_dyncf_A_const_81 *lang.Var

var A_arbace_j2g_dyncf_A_const_82 *lang.Var

var A_arbace_j2g_dyncf_A_const_83 *lang.Var

var A_arbace_j2g_dyncf_A_const_84 *lang.Var

var A_arbace_j2g_dyncf_A_const_85 any

var A_arbace_j2g_dyncf_A_const_86 any

var A_arbace_j2g_dyncf_A_const_87 any

var A_arbace_j2g_dyncf_A_const_88 any

var A_arbace_j2g_dyncf_A_const_89 any

var A_arbace_j2g_dyncf_A_const_90 any

var A_arbace_j2g_dyncf_A_const_91 any

var A_arbace_j2g_dyncf_A_const_92 any

var A_arbace_j2g_dyncf_A_const_93 *lang.Var

var A_arbace_j2g_dyncf_A_const_94 *lang.Var

var A_arbace_j2g_dyncf_A_const_95 any

var A_arbace_j2g_dyncf_A_const_96 any

var A_arbace_j2g_dyncf_A_const_97 any

var A_arbace_j2g_dyncf_A_const_98 any

var A_arbace_j2g_dyncf_A_const_99 any

var A_arbace_j2g_dyncf_A_const_100 *lang.Var

var A_arbace_j2g_dyncf_A_const_101 *lang.Var

var A_arbace_j2g_dyncf_A_const_102 *lang.Var

var A_arbace_j2g_dyncf_A_const_103 *lang.Var

var A_arbace_j2g_dyncf_A_const_104 *lang.Var

var A_arbace_j2g_dyncf_A_const_105 any

var A_arbace_j2g_dyncf_A_const_106 *lang.Var

var A_arbace_j2g_dyncf_A_const_107 *lang.Var

var A_arbace_j2g_dyncf_A_const_108 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_109 *lang.Var

var A_arbace_j2g_dyncf_A_const_110 any

var A_arbace_j2g_dyncf_A_const_111 any

var A_arbace_j2g_dyncf_A_const_112 any

var A_arbace_j2g_dyncf_A_const_113 any

var A_arbace_j2g_dyncf_A_const_114 *lang.Var

var A_arbace_j2g_dyncf_A_const_115 any

var A_arbace_j2g_dyncf_A_const_116 any

var A_arbace_j2g_dyncf_A_const_117 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_118 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_119 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_120 any

var A_arbace_j2g_dyncf_A_const_121 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_122 any

var A_arbace_j2g_dyncf_A_const_123 any

var A_arbace_j2g_dyncf_A_const_124 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_125 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_126 any

var A_arbace_j2g_dyncf_A_const_127 any

var A_arbace_j2g_dyncf_A_const_128 any

var A_arbace_j2g_dyncf_A_const_129 any

var A_arbace_j2g_dyncf_A_const_130 any

var A_arbace_j2g_dyncf_A_const_131 any

var A_arbace_j2g_dyncf_A_const_132 any

var A_arbace_j2g_dyncf_A_const_133 any

var A_arbace_j2g_dyncf_A_const_134 any

var A_arbace_j2g_dyncf_A_const_135 any

var A_arbace_j2g_dyncf_A_const_136 any

var A_arbace_j2g_dyncf_A_const_137 any

var A_arbace_j2g_dyncf_A_const_138 any

var A_arbace_j2g_dyncf_A_const_139 any

var A_arbace_j2g_dyncf_A_const_140 any

var A_arbace_j2g_dyncf_A_const_141 any

var A_arbace_j2g_dyncf_A_const_142 any

var A_arbace_j2g_dyncf_A_const_143 any

var A_arbace_j2g_dyncf_A_const_144 *lang.Var

var A_arbace_j2g_dyncf_A_const_145 *lang.Var

var A_arbace_j2g_dyncf_A_const_146 any

var A_arbace_j2g_dyncf_A_const_147 any

var A_arbace_j2g_dyncf_A_const_148 any

var A_arbace_j2g_dyncf_A_const_149 any

var A_arbace_j2g_dyncf_A_const_150 *lang.Var

var A_arbace_j2g_dyncf_A_const_151 *lang.Var

var A_arbace_j2g_dyncf_A_const_152 *lang.Var

var A_arbace_j2g_dyncf_A_const_153 *lang.Var

var A_arbace_j2g_dyncf_A_const_154 *lang.Var

var A_arbace_j2g_dyncf_A_const_155 *lang.Var

var A_arbace_j2g_dyncf_A_const_156 any

var A_arbace_j2g_dyncf_A_const_157 *lang.Var

var A_arbace_j2g_dyncf_A_const_158 *lang.Var

var A_arbace_j2g_dyncf_A_const_159 any

var A_arbace_j2g_dyncf_A_const_160 any

var A_arbace_j2g_dyncf_A_const_161 any

var A_arbace_j2g_dyncf_A_const_162 any

var A_arbace_j2g_dyncf_A_const_163 any

var A_arbace_j2g_dyncf_A_const_164 any

var A_arbace_j2g_dyncf_A_const_165 any

var A_arbace_j2g_dyncf_A_const_166 any

var A_arbace_j2g_dyncf_A_const_167 any

var A_arbace_j2g_dyncf_A_const_168 *lang.Var

var A_arbace_j2g_dyncf_A_const_169 any

var A_arbace_j2g_dyncf_A_const_170 any

var A_arbace_j2g_dyncf_A_const_171 any

var A_arbace_j2g_dyncf_A_const_172 any

var A_arbace_j2g_dyncf_A_const_173 any

var A_arbace_j2g_dyncf_A_const_174 *lang.Var

var A_arbace_j2g_dyncf_A_const_175 any

var A_arbace_j2g_dyncf_A_const_176 any

var A_arbace_j2g_dyncf_A_const_177 any

var A_arbace_j2g_dyncf_A_const_178 any

var A_arbace_j2g_dyncf_A_const_179 any

var A_arbace_j2g_dyncf_A_const_180 any

var A_arbace_j2g_dyncf_A_const_181 any

var A_arbace_j2g_dyncf_A_const_182 any

var A_arbace_j2g_dyncf_A_const_183 any

var A_arbace_j2g_dyncf_A_const_184 any

var A_arbace_j2g_dyncf_A_const_185 any

var A_arbace_j2g_dyncf_A_const_186 any

var A_arbace_j2g_dyncf_A_const_187 any

var A_arbace_j2g_dyncf_A_const_188 any

var A_arbace_j2g_dyncf_A_const_189 any

var A_arbace_j2g_dyncf_A_const_190 *lang.Var

var A_arbace_j2g_dyncf_A_const_191 *lang.Var

var A_arbace_j2g_dyncf_A_const_192 *lang.Var

var A_arbace_j2g_dyncf_A_const_193 *lang.Var

var A_arbace_j2g_dyncf_A_const_194 *lang.Var

var A_arbace_j2g_dyncf_A_const_195 any

var A_arbace_j2g_dyncf_A_const_196 any

var A_arbace_j2g_dyncf_A_const_197 any

var A_arbace_j2g_dyncf_A_const_198 any

var A_arbace_j2g_dyncf_A_const_199 any

var A_arbace_j2g_dyncf_A_const_200 any

var A_arbace_j2g_dyncf_A_const_201 *lang.Var

var A_arbace_j2g_dyncf_A_const_202 *lang.Var

var A_arbace_j2g_dyncf_A_const_203 any

var A_arbace_j2g_dyncf_A_const_204 *lang.Var

var A_arbace_j2g_dyncf_A_const_205 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_206 any

var A_arbace_j2g_dyncf_A_const_207 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_208 any

var A_arbace_j2g_dyncf_A_const_209 *lang.Var

var A_arbace_j2g_dyncf_A_const_210 *lang.Var

var A_arbace_j2g_dyncf_A_const_211 *lang.Var

var A_arbace_j2g_dyncf_A_const_212 any

var A_arbace_j2g_dyncf_A_const_213 any

var A_arbace_j2g_dyncf_A_const_214 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_215 any

var A_arbace_j2g_dyncf_A_const_216 any

var A_arbace_j2g_dyncf_A_const_217 any

var A_arbace_j2g_dyncf_A_const_218 any

var A_arbace_j2g_dyncf_A_const_219 any

var A_arbace_j2g_dyncf_A_const_220 any

var A_arbace_j2g_dyncf_A_const_221 any

var A_arbace_j2g_dyncf_A_const_222 any

var A_arbace_j2g_dyncf_A_const_223 any

var A_arbace_j2g_dyncf_A_const_224 any

var A_arbace_j2g_dyncf_A_const_225 any

var A_arbace_j2g_dyncf_A_const_226 any

var A_arbace_j2g_dyncf_A_const_227 any

var A_arbace_j2g_dyncf_A_const_228 any

var A_arbace_j2g_dyncf_A_const_229 any

var A_arbace_j2g_dyncf_A_const_230 *lang.Var

var A_arbace_j2g_dyncf_A_const_231 any

var A_arbace_j2g_dyncf_A_const_232 any

var A_arbace_j2g_dyncf_A_const_233 *lang.Var

var A_arbace_j2g_dyncf_A_const_234 any

var A_arbace_j2g_dyncf_A_const_235 any

var A_arbace_j2g_dyncf_A_const_236 any

var A_arbace_j2g_dyncf_A_const_237 any

var A_arbace_j2g_dyncf_A_const_238 any

var A_arbace_j2g_dyncf_A_const_239 any

var A_arbace_j2g_dyncf_A_const_240 any

var A_arbace_j2g_dyncf_A_const_241 any

var A_arbace_j2g_dyncf_A_const_242 any

var A_arbace_j2g_dyncf_A_const_243 any

var A_arbace_j2g_dyncf_A_const_244 any

var A_arbace_j2g_dyncf_A_const_245 any

var A_arbace_j2g_dyncf_A_const_246 any

var A_arbace_j2g_dyncf_A_const_247 any

var A_arbace_j2g_dyncf_A_const_248 *lang.Var

var A_arbace_j2g_dyncf_A_const_249 any

var A_arbace_j2g_dyncf_A_const_250 any

var A_arbace_j2g_dyncf_A_const_251 any

var A_arbace_j2g_dyncf_A_const_252 any

var A_arbace_j2g_dyncf_A_const_253 any

var A_arbace_j2g_dyncf_A_const_254 any

var A_arbace_j2g_dyncf_A_const_255 *lang.Var

var A_arbace_j2g_dyncf_A_const_256 any

var A_arbace_j2g_dyncf_A_const_257 any

var A_arbace_j2g_dyncf_A_const_258 any

var A_arbace_j2g_dyncf_A_const_259 any

var A_arbace_j2g_dyncf_A_const_260 any

var A_arbace_j2g_dyncf_A_const_261 any

var A_arbace_j2g_dyncf_A_const_262 any

var A_arbace_j2g_dyncf_A_const_263 any

var A_arbace_j2g_dyncf_A_const_264 any

var A_arbace_j2g_dyncf_A_const_265 any

var A_arbace_j2g_dyncf_A_const_266 any

var A_arbace_j2g_dyncf_A_const_267 any

var A_arbace_j2g_dyncf_A_const_268 any

var A_arbace_j2g_dyncf_A_const_269 any

var A_arbace_j2g_dyncf_A_const_270 any

var A_arbace_j2g_dyncf_A_const_271 any

var A_arbace_j2g_dyncf_A_const_272 any

var A_arbace_j2g_dyncf_A_const_273 any

var A_arbace_j2g_dyncf_A_const_274 any

var A_arbace_j2g_dyncf_A_const_275 any

var A_arbace_j2g_dyncf_A_const_276 any

var A_arbace_j2g_dyncf_A_const_277 any

var A_arbace_j2g_dyncf_A_const_278 any

var A_arbace_j2g_dyncf_A_const_279 any

var A_arbace_j2g_dyncf_A_const_280 any

var A_arbace_j2g_dyncf_A_const_281 any

var A_arbace_j2g_dyncf_A_const_282 any

var A_arbace_j2g_dyncf_A_const_283 any

var A_arbace_j2g_dyncf_A_const_284 any

var A_arbace_j2g_dyncf_A_const_285 any

var A_arbace_j2g_dyncf_A_const_286 any

var A_arbace_j2g_dyncf_A_const_287 any

var A_arbace_j2g_dyncf_A_const_288 any

var A_arbace_j2g_dyncf_A_const_289 any

var A_arbace_j2g_dyncf_A_const_290 any

var A_arbace_j2g_dyncf_A_const_291 any

var A_arbace_j2g_dyncf_A_const_292 any

var A_arbace_j2g_dyncf_A_const_293 any

var A_arbace_j2g_dyncf_A_const_294 any

var A_arbace_j2g_dyncf_A_const_295 any

var A_arbace_j2g_dyncf_A_const_296 any

var A_arbace_j2g_dyncf_A_const_297 any

var A_arbace_j2g_dyncf_A_const_298 any

var A_arbace_j2g_dyncf_A_const_299 any

var A_arbace_j2g_dyncf_A_const_300 any

var A_arbace_j2g_dyncf_A_const_301 any

var A_arbace_j2g_dyncf_A_const_302 any

var A_arbace_j2g_dyncf_A_const_303 any

var A_arbace_j2g_dyncf_A_const_304 any

var A_arbace_j2g_dyncf_A_const_305 any

var A_arbace_j2g_dyncf_A_const_306 any

var A_arbace_j2g_dyncf_A_const_307 any

var A_arbace_j2g_dyncf_A_const_308 any

var A_arbace_j2g_dyncf_A_const_309 any

var A_arbace_j2g_dyncf_A_const_310 any

var A_arbace_j2g_dyncf_A_const_311 any

var A_arbace_j2g_dyncf_A_const_312 any

var A_arbace_j2g_dyncf_A_const_313 any

var A_arbace_j2g_dyncf_A_const_314 any

var A_arbace_j2g_dyncf_A_const_315 any

var A_arbace_j2g_dyncf_A_const_316 any

var A_arbace_j2g_dyncf_A_const_317 any

var A_arbace_j2g_dyncf_A_const_318 any

var A_arbace_j2g_dyncf_A_const_319 any

var A_arbace_j2g_dyncf_A_const_320 any

var A_arbace_j2g_dyncf_A_const_321 any

var A_arbace_j2g_dyncf_A_const_322 any

var A_arbace_j2g_dyncf_A_const_323 any

var A_arbace_j2g_dyncf_A_const_324 any

var A_arbace_j2g_dyncf_A_const_325 any

var A_arbace_j2g_dyncf_A_const_326 any

var A_arbace_j2g_dyncf_A_const_327 any

var A_arbace_j2g_dyncf_A_const_328 any

var A_arbace_j2g_dyncf_A_const_329 any

var A_arbace_j2g_dyncf_A_const_330 any

var A_arbace_j2g_dyncf_A_const_331 any

var A_arbace_j2g_dyncf_A_const_332 any

var A_arbace_j2g_dyncf_A_const_333 any

var A_arbace_j2g_dyncf_A_const_334 any

var A_arbace_j2g_dyncf_A_const_335 any

var A_arbace_j2g_dyncf_A_const_336 any

var A_arbace_j2g_dyncf_A_const_337 any

var A_arbace_j2g_dyncf_A_const_338 any

var A_arbace_j2g_dyncf_A_const_339 any

var A_arbace_j2g_dyncf_A_const_340 any

var A_arbace_j2g_dyncf_A_const_341 any

var A_arbace_j2g_dyncf_A_const_342 any

var A_arbace_j2g_dyncf_A_const_343 any

var A_arbace_j2g_dyncf_A_const_344 any

var A_arbace_j2g_dyncf_A_const_345 any

var A_arbace_j2g_dyncf_A_const_346 any

var A_arbace_j2g_dyncf_A_const_347 any

var A_arbace_j2g_dyncf_A_const_348 any

var A_arbace_j2g_dyncf_A_const_349 any

var A_arbace_j2g_dyncf_A_const_350 any

var A_arbace_j2g_dyncf_A_const_351 any

var A_arbace_j2g_dyncf_A_const_352 any

var A_arbace_j2g_dyncf_A_const_353 any

var A_arbace_j2g_dyncf_A_const_354 any

var A_arbace_j2g_dyncf_A_const_355 any

var A_arbace_j2g_dyncf_A_const_356 any

var A_arbace_j2g_dyncf_A_const_357 any

var A_arbace_j2g_dyncf_A_const_358 any

var A_arbace_j2g_dyncf_A_const_359 any

var A_arbace_j2g_dyncf_A_const_360 any

var A_arbace_j2g_dyncf_A_const_361 any

var A_arbace_j2g_dyncf_A_const_362 any

var A_arbace_j2g_dyncf_A_const_363 any

var A_arbace_j2g_dyncf_A_const_364 any

var A_arbace_j2g_dyncf_A_const_365 any

var A_arbace_j2g_dyncf_A_const_366 any

var A_arbace_j2g_dyncf_A_const_367 any

var A_arbace_j2g_dyncf_A_const_368 any

var A_arbace_j2g_dyncf_A_const_369 any

var A_arbace_j2g_dyncf_A_const_370 any

var A_arbace_j2g_dyncf_A_const_371 any

var A_arbace_j2g_dyncf_A_const_372 any

var A_arbace_j2g_dyncf_A_const_373 any

var A_arbace_j2g_dyncf_A_const_374 any

var A_arbace_j2g_dyncf_A_const_375 any

var A_arbace_j2g_dyncf_A_const_376 any

var A_arbace_j2g_dyncf_A_const_377 any

var A_arbace_j2g_dyncf_A_const_378 any

var A_arbace_j2g_dyncf_A_const_379 any

var A_arbace_j2g_dyncf_A_const_380 any

var A_arbace_j2g_dyncf_A_const_381 any

var A_arbace_j2g_dyncf_A_const_382 any

var A_arbace_j2g_dyncf_A_const_383 any

var A_arbace_j2g_dyncf_A_const_384 any

var A_arbace_j2g_dyncf_A_const_385 any

var A_arbace_j2g_dyncf_A_const_386 any

var A_arbace_j2g_dyncf_A_const_387 any

var A_arbace_j2g_dyncf_A_const_388 any

var A_arbace_j2g_dyncf_A_const_389 any

var A_arbace_j2g_dyncf_A_const_390 any

var A_arbace_j2g_dyncf_A_const_391 any

var A_arbace_j2g_dyncf_A_const_392 any

var A_arbace_j2g_dyncf_A_const_393 any

var A_arbace_j2g_dyncf_A_const_394 any

var A_arbace_j2g_dyncf_A_const_395 any

var A_arbace_j2g_dyncf_A_const_396 any

var A_arbace_j2g_dyncf_A_const_397 any

var A_arbace_j2g_dyncf_A_const_398 any

var A_arbace_j2g_dyncf_A_const_399 any

var A_arbace_j2g_dyncf_A_const_400 any

var A_arbace_j2g_dyncf_A_const_401 any

var A_arbace_j2g_dyncf_A_const_402 any

var A_arbace_j2g_dyncf_A_const_403 any

var A_arbace_j2g_dyncf_A_const_404 any

var A_arbace_j2g_dyncf_A_const_405 any

var A_arbace_j2g_dyncf_A_const_406 any

var A_arbace_j2g_dyncf_A_const_407 any

var A_arbace_j2g_dyncf_A_const_408 any

var A_arbace_j2g_dyncf_A_const_409 any

var A_arbace_j2g_dyncf_A_const_410 any

var A_arbace_j2g_dyncf_A_const_411 any

var A_arbace_j2g_dyncf_A_const_412 any

var A_arbace_j2g_dyncf_A_const_413 any

var A_arbace_j2g_dyncf_A_const_414 any

var A_arbace_j2g_dyncf_A_const_415 any

var A_arbace_j2g_dyncf_A_const_416 any

var A_arbace_j2g_dyncf_A_const_417 any

var A_arbace_j2g_dyncf_A_const_418 any

var A_arbace_j2g_dyncf_A_const_419 any

var A_arbace_j2g_dyncf_A_const_420 *lang.Var

var A_arbace_j2g_dyncf_A_const_421 *lang.Var

var A_arbace_j2g_dyncf_A_const_422 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_423 *lang.Var

var A_arbace_j2g_dyncf_A_const_424 *lang.Var

var A_arbace_j2g_dyncf_A_const_425 *lang.Var

var A_arbace_j2g_dyncf_A_const_426 *lang.Var

var A_arbace_j2g_dyncf_A_const_427 *lang.Var

var A_arbace_j2g_dyncf_A_const_428 *lang.Var

var A_arbace_j2g_dyncf_A_const_429 *lang.Var

var A_arbace_j2g_dyncf_A_const_430 *lang.Var

var A_arbace_j2g_dyncf_A_const_431 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_432 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_433 *lang.Var

var A_arbace_j2g_dyncf_A_const_434 *lang.Var

var A_arbace_j2g_dyncf_A_const_435 *lang.Var

var A_arbace_j2g_dyncf_A_const_436 any

var A_arbace_j2g_dyncf_A_const_437 *lang.Var

var A_arbace_j2g_dyncf_A_const_438 *lang.Var

var A_arbace_j2g_dyncf_A_const_439 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_440 *lang.Var

var A_arbace_j2g_dyncf_A_const_441 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_442 *lang.Var

var A_arbace_j2g_dyncf_A_const_443 *lang.Var

var A_arbace_j2g_dyncf_A_const_444 *lang.Var

var A_arbace_j2g_dyncf_A_const_445 any

var A_arbace_j2g_dyncf_A_const_446 any

var A_arbace_j2g_dyncf_A_const_447 any

var A_arbace_j2g_dyncf_A_const_448 any

var A_arbace_j2g_dyncf_A_const_449 any

var A_arbace_j2g_dyncf_A_const_450 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_451 *lang.Var

var A_arbace_j2g_dyncf_A_const_452 *lang.Var

var A_arbace_j2g_dyncf_A_const_453 *lang.Var

var A_arbace_j2g_dyncf_A_const_454 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_455 any

var A_arbace_j2g_dyncf_A_const_456 any

var A_arbace_j2g_dyncf_A_const_457 any

var A_arbace_j2g_dyncf_A_const_458 any

var A_arbace_j2g_dyncf_A_const_459 any

var A_arbace_j2g_dyncf_A_const_460 any

var A_arbace_j2g_dyncf_A_const_461 *lang.Var

var A_arbace_j2g_dyncf_A_const_462 *lang.Var

var A_arbace_j2g_dyncf_A_const_463 *lang.Var

var A_arbace_j2g_dyncf_A_const_464 *lang.Var

var A_arbace_j2g_dyncf_A_const_465 *lang.Var

var A_arbace_j2g_dyncf_A_const_466 *lang.Var

var A_arbace_j2g_dyncf_A_const_467 any

var A_arbace_j2g_dyncf_A_const_468 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_469 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_470 *lang.Var

var A_arbace_j2g_dyncf_A_const_471 *lang.Var

var A_arbace_j2g_dyncf_A_const_472 *lang.Var

var A_arbace_j2g_dyncf_A_const_473 *lang.Var

var A_arbace_j2g_dyncf_A_const_474 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_475 *lang.Var

var A_arbace_j2g_dyncf_A_const_476 *lang.Var

var A_arbace_j2g_dyncf_A_const_477 *lang.Var

var A_arbace_j2g_dyncf_A_const_478 *lang.Var

var A_arbace_j2g_dyncf_A_init jrt.ClassInit

func A_arbace_j2g_dyncf_A_Init() { if !A_arbace_j2g_dyncf_A_init.Done() { A_arbace_j2g_dyncf_A_init.Run(A_arbace_j2g_dyncf_A_clinit) } }

func A_arbace_j2g_dyncf_A_clinit() { A_arbace_j2g_dyncf_A_clinit_p0(); A_arbace_j2g_dyncf_A_clinit_p1(); A_arbace_j2g_dyncf_A_clinit_p2(); A_arbace_j2g_dyncf_A_clinit_p3(); A_arbace_j2g_dyncf_A_clinit_p4(); A_arbace_j2g_dyncf_A_clinit_p5(); A_arbace_j2g_dyncf_A_clinit_p6(); A_arbace_j2g_dyncf_A_clinit_p7(); A_arbace_j2g_dyncf_A_clinit_p8(); A_arbace_j2g_dyncf_A_clinit_p9(); A_arbace_j2g_dyncf_A_clinit_p10(); A_arbace_j2g_dyncf_A_clinit_p11(); A_arbace_j2g_dyncf_A_clinit_p12(); A_arbace_j2g_dyncf_A_clinit_p13(); A_arbace_j2g_dyncf_A_clinit_p14(); A_arbace_j2g_dyncf_A_clinit_p15(); A_arbace_j2g_dyncf_A_clinit_p16(); A_arbace_j2g_dyncf_A_clinit_p17(); A_arbace_j2g_dyncf_A_clinit_p18(); A_arbace_j2g_dyncf_A_clinit_p19(); A_arbace_j2g_dyncf_A_clinit_p20(); A_arbace_j2g_dyncf_A_clinit_p21(); A_arbace_j2g_dyncf_A_clinit_p22(); A_arbace_j2g_dyncf_A_clinit_p23(); A_arbace_j2g_dyncf_A_clinit_p24(); A_arbace_j2g_dyncf_A_clinit_p25(); A_arbace_j2g_dyncf_A_clinit_p26(); A_arbace_j2g_dyncf_A_clinit_p27(); A_arbace_j2g_dyncf_A_clinit_p28(); A_arbace_j2g_dyncf_A_clinit_p29(); A_arbace_j2g_dyncf_A_clinit_p30(); A_arbace_j2g_dyncf_A_clinit_p31(); A_arbace_j2g_dyncf_A_clinit_p32(); A_arbace_j2g_dyncf_A_clinit_p33() }

func A_arbace_j2g_dyncf_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyncf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 733); A_arbace_j2g_dyncf_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[254]); A_arbace_j2g_dyncf_A_const_1 = A_arbace_j2g_dyncf_A_const_pool.A[255]; A_arbace_j2g_dyncf_A_const_2 = A_arbace_j2g_dyncf_A_const_pool.A[256]; A_arbace_j2g_dyncf_A_const_3 = A_arbace_j2g_dyncf_A_const_pool.A[257]; A_arbace_j2g_dyncf_A_const_4 = A_arbace_j2g_dyncf_A_const_pool.A[258]; A_arbace_j2g_dyncf_A_const_5 = A_arbace_j2g_dyncf_A_const_pool.A[259]; A_arbace_j2g_dyncf_A_const_6 = A_arbace_j2g_dyncf_A_const_pool.A[260]; A_arbace_j2g_dyncf_A_const_7 = A_arbace_j2g_dyncf_A_const_pool.A[261]; A_arbace_j2g_dyncf_A_const_8 = A_arbace_j2g_dyncf_A_const_pool.A[262]; A_arbace_j2g_dyncf_A_const_9 = A_arbace_j2g_dyncf_A_const_pool.A[263]; A_arbace_j2g_dyncf_A_const_10 = A_arbace_j2g_dyncf_A_const_pool.A[264]; A_arbace_j2g_dyncf_A_const_11 = A_arbace_j2g_dyncf_A_const_pool.A[265]; A_arbace_j2g_dyncf_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[266]); A_arbace_j2g_dyncf_A_const_13 = A_arbace_j2g_dyncf_A_const_pool.A[267] }

func A_arbace_j2g_dyncf_A_clinit_p1() { A_arbace_j2g_dyncf_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[268]); A_arbace_j2g_dyncf_A_const_15 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[269]); A_arbace_j2g_dyncf_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[270]); A_arbace_j2g_dyncf_A_const_17 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[271]); A_arbace_j2g_dyncf_A_const_18 = A_arbace_j2g_dyncf_A_const_pool.A[272]; A_arbace_j2g_dyncf_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[273]); A_arbace_j2g_dyncf_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[274]); A_arbace_j2g_dyncf_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[275]); A_arbace_j2g_dyncf_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[276]); A_arbace_j2g_dyncf_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[277]); A_arbace_j2g_dyncf_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[278]); A_arbace_j2g_dyncf_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[279]) }

func A_arbace_j2g_dyncf_A_clinit_p2() { A_arbace_j2g_dyncf_A_const_26 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[280]); A_arbace_j2g_dyncf_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[281]); A_arbace_j2g_dyncf_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[282]); A_arbace_j2g_dyncf_A_const_29 = A_arbace_j2g_dyncf_A_const_pool.A[283]; A_arbace_j2g_dyncf_A_const_30 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[284]); A_arbace_j2g_dyncf_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[285]); A_arbace_j2g_dyncf_A_const_32 = A_arbace_j2g_dyncf_A_const_pool.A[286]; A_arbace_j2g_dyncf_A_const_33 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[287]); A_arbace_j2g_dyncf_A_const_34 = A_arbace_j2g_dyncf_A_const_pool.A[288]; A_arbace_j2g_dyncf_A_const_35 = A_arbace_j2g_dyncf_A_const_pool.A[289]; A_arbace_j2g_dyncf_A_const_36 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[290]); A_arbace_j2g_dyncf_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[291]); A_arbace_j2g_dyncf_A_const_38 = A_arbace_j2g_dyncf_A_const_pool.A[292] }

func A_arbace_j2g_dyncf_A_clinit_p3() { A_arbace_j2g_dyncf_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[293]); A_arbace_j2g_dyncf_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[294]); A_arbace_j2g_dyncf_A_const_41 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[295]); A_arbace_j2g_dyncf_A_const_42 = A_arbace_j2g_dyncf_A_const_pool.A[296]; A_arbace_j2g_dyncf_A_const_43 = A_arbace_j2g_dyncf_A_const_pool.A[297]; A_arbace_j2g_dyncf_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[298]); A_arbace_j2g_dyncf_A_const_45 = A_arbace_j2g_dyncf_A_const_pool.A[299]; A_arbace_j2g_dyncf_A_const_46 = A_arbace_j2g_dyncf_A_const_pool.A[300]; A_arbace_j2g_dyncf_A_const_47 = A_arbace_j2g_dyncf_A_const_pool.A[301]; A_arbace_j2g_dyncf_A_const_48 = A_arbace_j2g_dyncf_A_const_pool.A[302]; A_arbace_j2g_dyncf_A_const_49 = A_arbace_j2g_dyncf_A_const_pool.A[303]; A_arbace_j2g_dyncf_A_const_50 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[304]); A_arbace_j2g_dyncf_A_const_51 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[305]); A_arbace_j2g_dyncf_A_const_52 = A_arbace_j2g_dyncf_A_const_pool.A[306] }

func A_arbace_j2g_dyncf_A_clinit_p4() { A_arbace_j2g_dyncf_A_const_53 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[307]); A_arbace_j2g_dyncf_A_const_54 = A_arbace_j2g_dyncf_A_const_pool.A[308]; A_arbace_j2g_dyncf_A_const_55 = A_arbace_j2g_dyncf_A_const_pool.A[309]; A_arbace_j2g_dyncf_A_const_56 = A_arbace_j2g_dyncf_A_const_pool.A[310]; A_arbace_j2g_dyncf_A_const_57 = A_arbace_j2g_dyncf_A_const_pool.A[311]; A_arbace_j2g_dyncf_A_const_58 = A_arbace_j2g_dyncf_A_const_pool.A[312]; A_arbace_j2g_dyncf_A_const_59 = A_arbace_j2g_dyncf_A_const_pool.A[313]; A_arbace_j2g_dyncf_A_const_60 = A_arbace_j2g_dyncf_A_const_pool.A[314]; A_arbace_j2g_dyncf_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[315]); A_arbace_j2g_dyncf_A_const_62 = A_arbace_j2g_dyncf_A_const_pool.A[316]; A_arbace_j2g_dyncf_A_const_63 = A_arbace_j2g_dyncf_A_const_pool.A[317]; A_arbace_j2g_dyncf_A_const_64 = A_arbace_j2g_dyncf_A_const_pool.A[318]; A_arbace_j2g_dyncf_A_const_65 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[319]); A_arbace_j2g_dyncf_A_const_66 = A_arbace_j2g_dyncf_A_const_pool.A[320]; A_arbace_j2g_dyncf_A_const_67 = A_arbace_j2g_dyncf_A_const_pool.A[321] }

func A_arbace_j2g_dyncf_A_clinit_p5() { A_arbace_j2g_dyncf_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[322]); A_arbace_j2g_dyncf_A_const_69 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[323]); A_arbace_j2g_dyncf_A_const_70 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[324]); A_arbace_j2g_dyncf_A_const_71 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[325]); A_arbace_j2g_dyncf_A_const_72 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[326]); A_arbace_j2g_dyncf_A_const_73 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[327]); A_arbace_j2g_dyncf_A_const_74 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[328]); A_arbace_j2g_dyncf_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[329]); A_arbace_j2g_dyncf_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[330]); A_arbace_j2g_dyncf_A_const_77 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[331]); A_arbace_j2g_dyncf_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[332]); A_arbace_j2g_dyncf_A_const_79 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[333]) }

func A_arbace_j2g_dyncf_A_clinit_p6() { A_arbace_j2g_dyncf_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[334]); A_arbace_j2g_dyncf_A_const_81 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[335]); A_arbace_j2g_dyncf_A_const_82 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[336]); A_arbace_j2g_dyncf_A_const_83 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[337]); A_arbace_j2g_dyncf_A_const_84 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[338]); A_arbace_j2g_dyncf_A_const_85 = A_arbace_j2g_dyncf_A_const_pool.A[339]; A_arbace_j2g_dyncf_A_const_86 = A_arbace_j2g_dyncf_A_const_pool.A[340]; A_arbace_j2g_dyncf_A_const_87 = A_arbace_j2g_dyncf_A_const_pool.A[341]; A_arbace_j2g_dyncf_A_const_88 = A_arbace_j2g_dyncf_A_const_pool.A[342]; A_arbace_j2g_dyncf_A_const_89 = A_arbace_j2g_dyncf_A_const_pool.A[343]; A_arbace_j2g_dyncf_A_const_90 = A_arbace_j2g_dyncf_A_const_pool.A[344]; A_arbace_j2g_dyncf_A_const_91 = A_arbace_j2g_dyncf_A_const_pool.A[345]; A_arbace_j2g_dyncf_A_const_92 = A_arbace_j2g_dyncf_A_const_pool.A[346]; A_arbace_j2g_dyncf_A_const_93 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[347]) }

func A_arbace_j2g_dyncf_A_clinit_p7() { A_arbace_j2g_dyncf_A_const_94 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[348]); A_arbace_j2g_dyncf_A_const_95 = A_arbace_j2g_dyncf_A_const_pool.A[349]; A_arbace_j2g_dyncf_A_const_96 = A_arbace_j2g_dyncf_A_const_pool.A[350]; A_arbace_j2g_dyncf_A_const_97 = A_arbace_j2g_dyncf_A_const_pool.A[351]; A_arbace_j2g_dyncf_A_const_98 = A_arbace_j2g_dyncf_A_const_pool.A[352]; A_arbace_j2g_dyncf_A_const_99 = A_arbace_j2g_dyncf_A_const_pool.A[353]; A_arbace_j2g_dyncf_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[354]); A_arbace_j2g_dyncf_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[355]); A_arbace_j2g_dyncf_A_const_102 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[356]); A_arbace_j2g_dyncf_A_const_103 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[357]); A_arbace_j2g_dyncf_A_const_104 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[358]); A_arbace_j2g_dyncf_A_const_105 = A_arbace_j2g_dyncf_A_const_pool.A[359]; A_arbace_j2g_dyncf_A_const_106 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[360]) }

func A_arbace_j2g_dyncf_A_clinit_p8() { A_arbace_j2g_dyncf_A_const_107 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[361]); A_arbace_j2g_dyncf_A_const_108 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[362]); A_arbace_j2g_dyncf_A_const_109 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[363]); A_arbace_j2g_dyncf_A_const_110 = A_arbace_j2g_dyncf_A_const_pool.A[364]; A_arbace_j2g_dyncf_A_const_111 = A_arbace_j2g_dyncf_A_const_pool.A[365]; A_arbace_j2g_dyncf_A_const_112 = A_arbace_j2g_dyncf_A_const_pool.A[366]; A_arbace_j2g_dyncf_A_const_113 = A_arbace_j2g_dyncf_A_const_pool.A[367]; A_arbace_j2g_dyncf_A_const_114 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[368]); A_arbace_j2g_dyncf_A_const_115 = A_arbace_j2g_dyncf_A_const_pool.A[369]; A_arbace_j2g_dyncf_A_const_116 = A_arbace_j2g_dyncf_A_const_pool.A[370]; A_arbace_j2g_dyncf_A_const_117 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[371]); A_arbace_j2g_dyncf_A_const_118 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[372]); A_arbace_j2g_dyncf_A_const_119 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[373]) }

func A_arbace_j2g_dyncf_A_clinit_p9() { A_arbace_j2g_dyncf_A_const_120 = A_arbace_j2g_dyncf_A_const_pool.A[374]; A_arbace_j2g_dyncf_A_const_121 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[375]); A_arbace_j2g_dyncf_A_const_122 = A_arbace_j2g_dyncf_A_const_pool.A[376]; A_arbace_j2g_dyncf_A_const_123 = A_arbace_j2g_dyncf_A_const_pool.A[377]; A_arbace_j2g_dyncf_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[378]); A_arbace_j2g_dyncf_A_const_125 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[379]); A_arbace_j2g_dyncf_A_const_126 = A_arbace_j2g_dyncf_A_const_pool.A[380]; A_arbace_j2g_dyncf_A_const_127 = A_arbace_j2g_dyncf_A_const_pool.A[381]; A_arbace_j2g_dyncf_A_const_128 = A_arbace_j2g_dyncf_A_const_pool.A[382]; A_arbace_j2g_dyncf_A_const_129 = A_arbace_j2g_dyncf_A_const_pool.A[383]; A_arbace_j2g_dyncf_A_const_130 = A_arbace_j2g_dyncf_A_const_pool.A[384]; A_arbace_j2g_dyncf_A_const_131 = A_arbace_j2g_dyncf_A_const_pool.A[385]; A_arbace_j2g_dyncf_A_const_132 = A_arbace_j2g_dyncf_A_const_pool.A[386]; A_arbace_j2g_dyncf_A_const_133 = A_arbace_j2g_dyncf_A_const_pool.A[387]; A_arbace_j2g_dyncf_A_const_134 = A_arbace_j2g_dyncf_A_const_pool.A[388] }

func A_arbace_j2g_dyncf_A_clinit_p10() { A_arbace_j2g_dyncf_A_const_135 = A_arbace_j2g_dyncf_A_const_pool.A[389]; A_arbace_j2g_dyncf_A_const_136 = A_arbace_j2g_dyncf_A_const_pool.A[390]; A_arbace_j2g_dyncf_A_const_137 = A_arbace_j2g_dyncf_A_const_pool.A[391]; A_arbace_j2g_dyncf_A_const_138 = A_arbace_j2g_dyncf_A_const_pool.A[392]; A_arbace_j2g_dyncf_A_const_139 = A_arbace_j2g_dyncf_A_const_pool.A[393]; A_arbace_j2g_dyncf_A_const_140 = A_arbace_j2g_dyncf_A_const_pool.A[394]; A_arbace_j2g_dyncf_A_const_141 = A_arbace_j2g_dyncf_A_const_pool.A[395]; A_arbace_j2g_dyncf_A_const_142 = A_arbace_j2g_dyncf_A_const_pool.A[396]; A_arbace_j2g_dyncf_A_const_143 = A_arbace_j2g_dyncf_A_const_pool.A[397]; A_arbace_j2g_dyncf_A_const_144 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[398]); A_arbace_j2g_dyncf_A_const_145 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[399]); A_arbace_j2g_dyncf_A_const_146 = A_arbace_j2g_dyncf_A_const_pool.A[400]; A_arbace_j2g_dyncf_A_const_147 = A_arbace_j2g_dyncf_A_const_pool.A[401]; A_arbace_j2g_dyncf_A_const_148 = A_arbace_j2g_dyncf_A_const_pool.A[402]; A_arbace_j2g_dyncf_A_const_149 = A_arbace_j2g_dyncf_A_const_pool.A[403] }

func A_arbace_j2g_dyncf_A_clinit_p11() { A_arbace_j2g_dyncf_A_const_150 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[404]); A_arbace_j2g_dyncf_A_const_151 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[405]); A_arbace_j2g_dyncf_A_const_152 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[406]); A_arbace_j2g_dyncf_A_const_153 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[407]); A_arbace_j2g_dyncf_A_const_154 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[408]); A_arbace_j2g_dyncf_A_const_155 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[409]); A_arbace_j2g_dyncf_A_const_156 = A_arbace_j2g_dyncf_A_const_pool.A[410]; A_arbace_j2g_dyncf_A_const_157 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[411]); A_arbace_j2g_dyncf_A_const_158 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[412]); A_arbace_j2g_dyncf_A_const_159 = A_arbace_j2g_dyncf_A_const_pool.A[413]; A_arbace_j2g_dyncf_A_const_160 = A_arbace_j2g_dyncf_A_const_pool.A[414]; A_arbace_j2g_dyncf_A_const_161 = A_arbace_j2g_dyncf_A_const_pool.A[415]; A_arbace_j2g_dyncf_A_const_162 = A_arbace_j2g_dyncf_A_const_pool.A[416] }

func A_arbace_j2g_dyncf_A_clinit_p12() { A_arbace_j2g_dyncf_A_const_163 = A_arbace_j2g_dyncf_A_const_pool.A[417]; A_arbace_j2g_dyncf_A_const_164 = A_arbace_j2g_dyncf_A_const_pool.A[418]; A_arbace_j2g_dyncf_A_const_165 = A_arbace_j2g_dyncf_A_const_pool.A[419]; A_arbace_j2g_dyncf_A_const_166 = A_arbace_j2g_dyncf_A_const_pool.A[420]; A_arbace_j2g_dyncf_A_const_167 = A_arbace_j2g_dyncf_A_const_pool.A[421]; A_arbace_j2g_dyncf_A_const_168 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[422]); A_arbace_j2g_dyncf_A_const_169 = A_arbace_j2g_dyncf_A_const_pool.A[423]; A_arbace_j2g_dyncf_A_const_170 = A_arbace_j2g_dyncf_A_const_pool.A[424]; A_arbace_j2g_dyncf_A_const_171 = A_arbace_j2g_dyncf_A_const_pool.A[425]; A_arbace_j2g_dyncf_A_const_172 = A_arbace_j2g_dyncf_A_const_pool.A[426]; A_arbace_j2g_dyncf_A_const_173 = A_arbace_j2g_dyncf_A_const_pool.A[427]; A_arbace_j2g_dyncf_A_const_174 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[428]); A_arbace_j2g_dyncf_A_const_175 = A_arbace_j2g_dyncf_A_const_pool.A[429]; A_arbace_j2g_dyncf_A_const_176 = A_arbace_j2g_dyncf_A_const_pool.A[430]; A_arbace_j2g_dyncf_A_const_177 = A_arbace_j2g_dyncf_A_const_pool.A[431] }

func A_arbace_j2g_dyncf_A_clinit_p13() { A_arbace_j2g_dyncf_A_const_178 = A_arbace_j2g_dyncf_A_const_pool.A[432]; A_arbace_j2g_dyncf_A_const_179 = A_arbace_j2g_dyncf_A_const_pool.A[433]; A_arbace_j2g_dyncf_A_const_180 = A_arbace_j2g_dyncf_A_const_pool.A[434]; A_arbace_j2g_dyncf_A_const_181 = A_arbace_j2g_dyncf_A_const_pool.A[435]; A_arbace_j2g_dyncf_A_const_182 = A_arbace_j2g_dyncf_A_const_pool.A[436]; A_arbace_j2g_dyncf_A_const_183 = A_arbace_j2g_dyncf_A_const_pool.A[437]; A_arbace_j2g_dyncf_A_const_184 = A_arbace_j2g_dyncf_A_const_pool.A[438]; A_arbace_j2g_dyncf_A_const_185 = A_arbace_j2g_dyncf_A_const_pool.A[439]; A_arbace_j2g_dyncf_A_const_186 = A_arbace_j2g_dyncf_A_const_pool.A[440]; A_arbace_j2g_dyncf_A_const_187 = A_arbace_j2g_dyncf_A_const_pool.A[441]; A_arbace_j2g_dyncf_A_const_188 = A_arbace_j2g_dyncf_A_const_pool.A[442]; A_arbace_j2g_dyncf_A_const_189 = A_arbace_j2g_dyncf_A_const_pool.A[443]; A_arbace_j2g_dyncf_A_const_190 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[444]); A_arbace_j2g_dyncf_A_const_191 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[445]); A_arbace_j2g_dyncf_A_const_192 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[446]) }

func A_arbace_j2g_dyncf_A_clinit_p14() { A_arbace_j2g_dyncf_A_const_193 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[447]); A_arbace_j2g_dyncf_A_const_194 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[448]); A_arbace_j2g_dyncf_A_const_195 = A_arbace_j2g_dyncf_A_const_pool.A[449]; A_arbace_j2g_dyncf_A_const_196 = A_arbace_j2g_dyncf_A_const_pool.A[450]; A_arbace_j2g_dyncf_A_const_197 = A_arbace_j2g_dyncf_A_const_pool.A[451]; A_arbace_j2g_dyncf_A_const_198 = A_arbace_j2g_dyncf_A_const_pool.A[452]; A_arbace_j2g_dyncf_A_const_199 = A_arbace_j2g_dyncf_A_const_pool.A[453]; A_arbace_j2g_dyncf_A_const_200 = A_arbace_j2g_dyncf_A_const_pool.A[454]; A_arbace_j2g_dyncf_A_const_201 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[455]); A_arbace_j2g_dyncf_A_const_202 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[456]); A_arbace_j2g_dyncf_A_const_203 = A_arbace_j2g_dyncf_A_const_pool.A[457]; A_arbace_j2g_dyncf_A_const_204 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[458]); A_arbace_j2g_dyncf_A_const_205 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[459]); A_arbace_j2g_dyncf_A_const_206 = A_arbace_j2g_dyncf_A_const_pool.A[460] }

func A_arbace_j2g_dyncf_A_clinit_p15() { A_arbace_j2g_dyncf_A_const_207 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[461]); A_arbace_j2g_dyncf_A_const_208 = A_arbace_j2g_dyncf_A_const_pool.A[462]; A_arbace_j2g_dyncf_A_const_209 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[463]); A_arbace_j2g_dyncf_A_const_210 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[464]); A_arbace_j2g_dyncf_A_const_211 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[465]); A_arbace_j2g_dyncf_A_const_212 = A_arbace_j2g_dyncf_A_const_pool.A[466]; A_arbace_j2g_dyncf_A_const_213 = A_arbace_j2g_dyncf_A_const_pool.A[467]; A_arbace_j2g_dyncf_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[468]); A_arbace_j2g_dyncf_A_const_215 = A_arbace_j2g_dyncf_A_const_pool.A[469]; A_arbace_j2g_dyncf_A_const_216 = A_arbace_j2g_dyncf_A_const_pool.A[470]; A_arbace_j2g_dyncf_A_const_217 = A_arbace_j2g_dyncf_A_const_pool.A[471]; A_arbace_j2g_dyncf_A_const_218 = A_arbace_j2g_dyncf_A_const_pool.A[472]; A_arbace_j2g_dyncf_A_const_219 = A_arbace_j2g_dyncf_A_const_pool.A[473]; A_arbace_j2g_dyncf_A_const_220 = A_arbace_j2g_dyncf_A_const_pool.A[474] }

func A_arbace_j2g_dyncf_A_clinit_p16() { A_arbace_j2g_dyncf_A_const_221 = A_arbace_j2g_dyncf_A_const_pool.A[475]; A_arbace_j2g_dyncf_A_const_222 = A_arbace_j2g_dyncf_A_const_pool.A[476]; A_arbace_j2g_dyncf_A_const_223 = A_arbace_j2g_dyncf_A_const_pool.A[477]; A_arbace_j2g_dyncf_A_const_224 = A_arbace_j2g_dyncf_A_const_pool.A[478]; A_arbace_j2g_dyncf_A_const_225 = A_arbace_j2g_dyncf_A_const_pool.A[479]; A_arbace_j2g_dyncf_A_const_226 = A_arbace_j2g_dyncf_A_const_pool.A[480]; A_arbace_j2g_dyncf_A_const_227 = A_arbace_j2g_dyncf_A_const_pool.A[481]; A_arbace_j2g_dyncf_A_const_228 = A_arbace_j2g_dyncf_A_const_pool.A[482]; A_arbace_j2g_dyncf_A_const_229 = A_arbace_j2g_dyncf_A_const_pool.A[483]; A_arbace_j2g_dyncf_A_const_230 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[484]); A_arbace_j2g_dyncf_A_const_231 = A_arbace_j2g_dyncf_A_const_pool.A[485]; A_arbace_j2g_dyncf_A_const_232 = A_arbace_j2g_dyncf_A_const_pool.A[486]; A_arbace_j2g_dyncf_A_const_233 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[487]); A_arbace_j2g_dyncf_A_const_234 = A_arbace_j2g_dyncf_A_const_pool.A[488]; A_arbace_j2g_dyncf_A_const_235 = A_arbace_j2g_dyncf_A_const_pool.A[489] }

func A_arbace_j2g_dyncf_A_clinit_p17() { A_arbace_j2g_dyncf_A_const_236 = A_arbace_j2g_dyncf_A_const_pool.A[490]; A_arbace_j2g_dyncf_A_const_237 = A_arbace_j2g_dyncf_A_const_pool.A[491]; A_arbace_j2g_dyncf_A_const_238 = A_arbace_j2g_dyncf_A_const_pool.A[492]; A_arbace_j2g_dyncf_A_const_239 = A_arbace_j2g_dyncf_A_const_pool.A[493]; A_arbace_j2g_dyncf_A_const_240 = A_arbace_j2g_dyncf_A_const_pool.A[494]; A_arbace_j2g_dyncf_A_const_241 = A_arbace_j2g_dyncf_A_const_pool.A[495]; A_arbace_j2g_dyncf_A_const_242 = A_arbace_j2g_dyncf_A_const_pool.A[496]; A_arbace_j2g_dyncf_A_const_243 = A_arbace_j2g_dyncf_A_const_pool.A[497]; A_arbace_j2g_dyncf_A_const_244 = A_arbace_j2g_dyncf_A_const_pool.A[498]; A_arbace_j2g_dyncf_A_const_245 = A_arbace_j2g_dyncf_A_const_pool.A[499]; A_arbace_j2g_dyncf_A_const_246 = A_arbace_j2g_dyncf_A_const_pool.A[500]; A_arbace_j2g_dyncf_A_const_247 = A_arbace_j2g_dyncf_A_const_pool.A[501]; A_arbace_j2g_dyncf_A_const_248 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[502]); A_arbace_j2g_dyncf_A_const_249 = A_arbace_j2g_dyncf_A_const_pool.A[503]; A_arbace_j2g_dyncf_A_const_250 = A_arbace_j2g_dyncf_A_const_pool.A[504] }

func A_arbace_j2g_dyncf_A_clinit_p18() { A_arbace_j2g_dyncf_A_const_251 = A_arbace_j2g_dyncf_A_const_pool.A[505]; A_arbace_j2g_dyncf_A_const_252 = A_arbace_j2g_dyncf_A_const_pool.A[506]; A_arbace_j2g_dyncf_A_const_253 = A_arbace_j2g_dyncf_A_const_pool.A[507]; A_arbace_j2g_dyncf_A_const_254 = A_arbace_j2g_dyncf_A_const_pool.A[508]; A_arbace_j2g_dyncf_A_const_255 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[509]); A_arbace_j2g_dyncf_A_const_256 = A_arbace_j2g_dyncf_A_const_pool.A[510]; A_arbace_j2g_dyncf_A_const_257 = A_arbace_j2g_dyncf_A_const_pool.A[511]; A_arbace_j2g_dyncf_A_const_258 = A_arbace_j2g_dyncf_A_const_pool.A[512]; A_arbace_j2g_dyncf_A_const_259 = A_arbace_j2g_dyncf_A_const_pool.A[513]; A_arbace_j2g_dyncf_A_const_260 = A_arbace_j2g_dyncf_A_const_pool.A[514]; A_arbace_j2g_dyncf_A_const_261 = A_arbace_j2g_dyncf_A_const_pool.A[515]; A_arbace_j2g_dyncf_A_const_262 = A_arbace_j2g_dyncf_A_const_pool.A[516]; A_arbace_j2g_dyncf_A_const_263 = A_arbace_j2g_dyncf_A_const_pool.A[517]; A_arbace_j2g_dyncf_A_const_264 = A_arbace_j2g_dyncf_A_const_pool.A[518]; A_arbace_j2g_dyncf_A_const_265 = A_arbace_j2g_dyncf_A_const_pool.A[519] }

func A_arbace_j2g_dyncf_A_clinit_p19() { A_arbace_j2g_dyncf_A_const_266 = A_arbace_j2g_dyncf_A_const_pool.A[520]; A_arbace_j2g_dyncf_A_const_267 = A_arbace_j2g_dyncf_A_const_pool.A[521]; A_arbace_j2g_dyncf_A_const_268 = A_arbace_j2g_dyncf_A_const_pool.A[522]; A_arbace_j2g_dyncf_A_const_269 = A_arbace_j2g_dyncf_A_const_pool.A[523]; A_arbace_j2g_dyncf_A_const_270 = A_arbace_j2g_dyncf_A_const_pool.A[524]; A_arbace_j2g_dyncf_A_const_271 = A_arbace_j2g_dyncf_A_const_pool.A[525]; A_arbace_j2g_dyncf_A_const_272 = A_arbace_j2g_dyncf_A_const_pool.A[526]; A_arbace_j2g_dyncf_A_const_273 = A_arbace_j2g_dyncf_A_const_pool.A[527]; A_arbace_j2g_dyncf_A_const_274 = A_arbace_j2g_dyncf_A_const_pool.A[528]; A_arbace_j2g_dyncf_A_const_275 = A_arbace_j2g_dyncf_A_const_pool.A[529]; A_arbace_j2g_dyncf_A_const_276 = A_arbace_j2g_dyncf_A_const_pool.A[530]; A_arbace_j2g_dyncf_A_const_277 = A_arbace_j2g_dyncf_A_const_pool.A[531]; A_arbace_j2g_dyncf_A_const_278 = A_arbace_j2g_dyncf_A_const_pool.A[532]; A_arbace_j2g_dyncf_A_const_279 = A_arbace_j2g_dyncf_A_const_pool.A[533]; A_arbace_j2g_dyncf_A_const_280 = A_arbace_j2g_dyncf_A_const_pool.A[534]; A_arbace_j2g_dyncf_A_const_281 = A_arbace_j2g_dyncf_A_const_pool.A[535] }

func A_arbace_j2g_dyncf_A_clinit_p20() { A_arbace_j2g_dyncf_A_const_282 = A_arbace_j2g_dyncf_A_const_pool.A[536]; A_arbace_j2g_dyncf_A_const_283 = A_arbace_j2g_dyncf_A_const_pool.A[537]; A_arbace_j2g_dyncf_A_const_284 = A_arbace_j2g_dyncf_A_const_pool.A[538]; A_arbace_j2g_dyncf_A_const_285 = A_arbace_j2g_dyncf_A_const_pool.A[539]; A_arbace_j2g_dyncf_A_const_286 = A_arbace_j2g_dyncf_A_const_pool.A[540]; A_arbace_j2g_dyncf_A_const_287 = A_arbace_j2g_dyncf_A_const_pool.A[541]; A_arbace_j2g_dyncf_A_const_288 = A_arbace_j2g_dyncf_A_const_pool.A[542]; A_arbace_j2g_dyncf_A_const_289 = A_arbace_j2g_dyncf_A_const_pool.A[543]; A_arbace_j2g_dyncf_A_const_290 = A_arbace_j2g_dyncf_A_const_pool.A[544]; A_arbace_j2g_dyncf_A_const_291 = A_arbace_j2g_dyncf_A_const_pool.A[545]; A_arbace_j2g_dyncf_A_const_292 = A_arbace_j2g_dyncf_A_const_pool.A[546]; A_arbace_j2g_dyncf_A_const_293 = A_arbace_j2g_dyncf_A_const_pool.A[547]; A_arbace_j2g_dyncf_A_const_294 = A_arbace_j2g_dyncf_A_const_pool.A[548]; A_arbace_j2g_dyncf_A_const_295 = A_arbace_j2g_dyncf_A_const_pool.A[549]; A_arbace_j2g_dyncf_A_const_296 = A_arbace_j2g_dyncf_A_const_pool.A[550]; A_arbace_j2g_dyncf_A_const_297 = A_arbace_j2g_dyncf_A_const_pool.A[551] }

func A_arbace_j2g_dyncf_A_clinit_p21() { A_arbace_j2g_dyncf_A_const_298 = A_arbace_j2g_dyncf_A_const_pool.A[552]; A_arbace_j2g_dyncf_A_const_299 = A_arbace_j2g_dyncf_A_const_pool.A[553]; A_arbace_j2g_dyncf_A_const_300 = A_arbace_j2g_dyncf_A_const_pool.A[554]; A_arbace_j2g_dyncf_A_const_301 = A_arbace_j2g_dyncf_A_const_pool.A[555]; A_arbace_j2g_dyncf_A_const_302 = A_arbace_j2g_dyncf_A_const_pool.A[556]; A_arbace_j2g_dyncf_A_const_303 = A_arbace_j2g_dyncf_A_const_pool.A[557]; A_arbace_j2g_dyncf_A_const_304 = A_arbace_j2g_dyncf_A_const_pool.A[558]; A_arbace_j2g_dyncf_A_const_305 = A_arbace_j2g_dyncf_A_const_pool.A[559]; A_arbace_j2g_dyncf_A_const_306 = A_arbace_j2g_dyncf_A_const_pool.A[560]; A_arbace_j2g_dyncf_A_const_307 = A_arbace_j2g_dyncf_A_const_pool.A[561]; A_arbace_j2g_dyncf_A_const_308 = A_arbace_j2g_dyncf_A_const_pool.A[562]; A_arbace_j2g_dyncf_A_const_309 = A_arbace_j2g_dyncf_A_const_pool.A[563]; A_arbace_j2g_dyncf_A_const_310 = A_arbace_j2g_dyncf_A_const_pool.A[564]; A_arbace_j2g_dyncf_A_const_311 = A_arbace_j2g_dyncf_A_const_pool.A[565]; A_arbace_j2g_dyncf_A_const_312 = A_arbace_j2g_dyncf_A_const_pool.A[566]; A_arbace_j2g_dyncf_A_const_313 = A_arbace_j2g_dyncf_A_const_pool.A[567] }

func A_arbace_j2g_dyncf_A_clinit_p22() { A_arbace_j2g_dyncf_A_const_314 = A_arbace_j2g_dyncf_A_const_pool.A[568]; A_arbace_j2g_dyncf_A_const_315 = A_arbace_j2g_dyncf_A_const_pool.A[569]; A_arbace_j2g_dyncf_A_const_316 = A_arbace_j2g_dyncf_A_const_pool.A[570]; A_arbace_j2g_dyncf_A_const_317 = A_arbace_j2g_dyncf_A_const_pool.A[571]; A_arbace_j2g_dyncf_A_const_318 = A_arbace_j2g_dyncf_A_const_pool.A[572]; A_arbace_j2g_dyncf_A_const_319 = A_arbace_j2g_dyncf_A_const_pool.A[573]; A_arbace_j2g_dyncf_A_const_320 = A_arbace_j2g_dyncf_A_const_pool.A[574]; A_arbace_j2g_dyncf_A_const_321 = A_arbace_j2g_dyncf_A_const_pool.A[575]; A_arbace_j2g_dyncf_A_const_322 = A_arbace_j2g_dyncf_A_const_pool.A[576]; A_arbace_j2g_dyncf_A_const_323 = A_arbace_j2g_dyncf_A_const_pool.A[577]; A_arbace_j2g_dyncf_A_const_324 = A_arbace_j2g_dyncf_A_const_pool.A[578]; A_arbace_j2g_dyncf_A_const_325 = A_arbace_j2g_dyncf_A_const_pool.A[579]; A_arbace_j2g_dyncf_A_const_326 = A_arbace_j2g_dyncf_A_const_pool.A[580]; A_arbace_j2g_dyncf_A_const_327 = A_arbace_j2g_dyncf_A_const_pool.A[581]; A_arbace_j2g_dyncf_A_const_328 = A_arbace_j2g_dyncf_A_const_pool.A[582]; A_arbace_j2g_dyncf_A_const_329 = A_arbace_j2g_dyncf_A_const_pool.A[583] }

func A_arbace_j2g_dyncf_A_clinit_p23() { A_arbace_j2g_dyncf_A_const_330 = A_arbace_j2g_dyncf_A_const_pool.A[584]; A_arbace_j2g_dyncf_A_const_331 = A_arbace_j2g_dyncf_A_const_pool.A[585]; A_arbace_j2g_dyncf_A_const_332 = A_arbace_j2g_dyncf_A_const_pool.A[586]; A_arbace_j2g_dyncf_A_const_333 = A_arbace_j2g_dyncf_A_const_pool.A[587]; A_arbace_j2g_dyncf_A_const_334 = A_arbace_j2g_dyncf_A_const_pool.A[588]; A_arbace_j2g_dyncf_A_const_335 = A_arbace_j2g_dyncf_A_const_pool.A[589]; A_arbace_j2g_dyncf_A_const_336 = A_arbace_j2g_dyncf_A_const_pool.A[590]; A_arbace_j2g_dyncf_A_const_337 = A_arbace_j2g_dyncf_A_const_pool.A[591]; A_arbace_j2g_dyncf_A_const_338 = A_arbace_j2g_dyncf_A_const_pool.A[592]; A_arbace_j2g_dyncf_A_const_339 = A_arbace_j2g_dyncf_A_const_pool.A[593]; A_arbace_j2g_dyncf_A_const_340 = A_arbace_j2g_dyncf_A_const_pool.A[594]; A_arbace_j2g_dyncf_A_const_341 = A_arbace_j2g_dyncf_A_const_pool.A[595]; A_arbace_j2g_dyncf_A_const_342 = A_arbace_j2g_dyncf_A_const_pool.A[596]; A_arbace_j2g_dyncf_A_const_343 = A_arbace_j2g_dyncf_A_const_pool.A[597]; A_arbace_j2g_dyncf_A_const_344 = A_arbace_j2g_dyncf_A_const_pool.A[598]; A_arbace_j2g_dyncf_A_const_345 = A_arbace_j2g_dyncf_A_const_pool.A[599] }

func A_arbace_j2g_dyncf_A_clinit_p24() { A_arbace_j2g_dyncf_A_const_346 = A_arbace_j2g_dyncf_A_const_pool.A[600]; A_arbace_j2g_dyncf_A_const_347 = A_arbace_j2g_dyncf_A_const_pool.A[601]; A_arbace_j2g_dyncf_A_const_348 = A_arbace_j2g_dyncf_A_const_pool.A[602]; A_arbace_j2g_dyncf_A_const_349 = A_arbace_j2g_dyncf_A_const_pool.A[603]; A_arbace_j2g_dyncf_A_const_350 = A_arbace_j2g_dyncf_A_const_pool.A[604]; A_arbace_j2g_dyncf_A_const_351 = A_arbace_j2g_dyncf_A_const_pool.A[605]; A_arbace_j2g_dyncf_A_const_352 = A_arbace_j2g_dyncf_A_const_pool.A[606]; A_arbace_j2g_dyncf_A_const_353 = A_arbace_j2g_dyncf_A_const_pool.A[607]; A_arbace_j2g_dyncf_A_const_354 = A_arbace_j2g_dyncf_A_const_pool.A[608]; A_arbace_j2g_dyncf_A_const_355 = A_arbace_j2g_dyncf_A_const_pool.A[609]; A_arbace_j2g_dyncf_A_const_356 = A_arbace_j2g_dyncf_A_const_pool.A[610]; A_arbace_j2g_dyncf_A_const_357 = A_arbace_j2g_dyncf_A_const_pool.A[611]; A_arbace_j2g_dyncf_A_const_358 = A_arbace_j2g_dyncf_A_const_pool.A[612]; A_arbace_j2g_dyncf_A_const_359 = A_arbace_j2g_dyncf_A_const_pool.A[613]; A_arbace_j2g_dyncf_A_const_360 = A_arbace_j2g_dyncf_A_const_pool.A[614]; A_arbace_j2g_dyncf_A_const_361 = A_arbace_j2g_dyncf_A_const_pool.A[615] }

func A_arbace_j2g_dyncf_A_clinit_p25() { A_arbace_j2g_dyncf_A_const_362 = A_arbace_j2g_dyncf_A_const_pool.A[616]; A_arbace_j2g_dyncf_A_const_363 = A_arbace_j2g_dyncf_A_const_pool.A[617]; A_arbace_j2g_dyncf_A_const_364 = A_arbace_j2g_dyncf_A_const_pool.A[618]; A_arbace_j2g_dyncf_A_const_365 = A_arbace_j2g_dyncf_A_const_pool.A[619]; A_arbace_j2g_dyncf_A_const_366 = A_arbace_j2g_dyncf_A_const_pool.A[620]; A_arbace_j2g_dyncf_A_const_367 = A_arbace_j2g_dyncf_A_const_pool.A[621]; A_arbace_j2g_dyncf_A_const_368 = A_arbace_j2g_dyncf_A_const_pool.A[622]; A_arbace_j2g_dyncf_A_const_369 = A_arbace_j2g_dyncf_A_const_pool.A[623]; A_arbace_j2g_dyncf_A_const_370 = A_arbace_j2g_dyncf_A_const_pool.A[624]; A_arbace_j2g_dyncf_A_const_371 = A_arbace_j2g_dyncf_A_const_pool.A[625]; A_arbace_j2g_dyncf_A_const_372 = A_arbace_j2g_dyncf_A_const_pool.A[626]; A_arbace_j2g_dyncf_A_const_373 = A_arbace_j2g_dyncf_A_const_pool.A[627]; A_arbace_j2g_dyncf_A_const_374 = A_arbace_j2g_dyncf_A_const_pool.A[628]; A_arbace_j2g_dyncf_A_const_375 = A_arbace_j2g_dyncf_A_const_pool.A[629]; A_arbace_j2g_dyncf_A_const_376 = A_arbace_j2g_dyncf_A_const_pool.A[630]; A_arbace_j2g_dyncf_A_const_377 = A_arbace_j2g_dyncf_A_const_pool.A[631] }

func A_arbace_j2g_dyncf_A_clinit_p26() { A_arbace_j2g_dyncf_A_const_378 = A_arbace_j2g_dyncf_A_const_pool.A[632]; A_arbace_j2g_dyncf_A_const_379 = A_arbace_j2g_dyncf_A_const_pool.A[633]; A_arbace_j2g_dyncf_A_const_380 = A_arbace_j2g_dyncf_A_const_pool.A[634]; A_arbace_j2g_dyncf_A_const_381 = A_arbace_j2g_dyncf_A_const_pool.A[635]; A_arbace_j2g_dyncf_A_const_382 = A_arbace_j2g_dyncf_A_const_pool.A[636]; A_arbace_j2g_dyncf_A_const_383 = A_arbace_j2g_dyncf_A_const_pool.A[637]; A_arbace_j2g_dyncf_A_const_384 = A_arbace_j2g_dyncf_A_const_pool.A[638]; A_arbace_j2g_dyncf_A_const_385 = A_arbace_j2g_dyncf_A_const_pool.A[639]; A_arbace_j2g_dyncf_A_const_386 = A_arbace_j2g_dyncf_A_const_pool.A[640]; A_arbace_j2g_dyncf_A_const_387 = A_arbace_j2g_dyncf_A_const_pool.A[641]; A_arbace_j2g_dyncf_A_const_388 = A_arbace_j2g_dyncf_A_const_pool.A[642]; A_arbace_j2g_dyncf_A_const_389 = A_arbace_j2g_dyncf_A_const_pool.A[643]; A_arbace_j2g_dyncf_A_const_390 = A_arbace_j2g_dyncf_A_const_pool.A[644]; A_arbace_j2g_dyncf_A_const_391 = A_arbace_j2g_dyncf_A_const_pool.A[645]; A_arbace_j2g_dyncf_A_const_392 = A_arbace_j2g_dyncf_A_const_pool.A[646]; A_arbace_j2g_dyncf_A_const_393 = A_arbace_j2g_dyncf_A_const_pool.A[647] }

func A_arbace_j2g_dyncf_A_clinit_p27() { A_arbace_j2g_dyncf_A_const_394 = A_arbace_j2g_dyncf_A_const_pool.A[648]; A_arbace_j2g_dyncf_A_const_395 = A_arbace_j2g_dyncf_A_const_pool.A[649]; A_arbace_j2g_dyncf_A_const_396 = A_arbace_j2g_dyncf_A_const_pool.A[650]; A_arbace_j2g_dyncf_A_const_397 = A_arbace_j2g_dyncf_A_const_pool.A[651]; A_arbace_j2g_dyncf_A_const_398 = A_arbace_j2g_dyncf_A_const_pool.A[652]; A_arbace_j2g_dyncf_A_const_399 = A_arbace_j2g_dyncf_A_const_pool.A[653]; A_arbace_j2g_dyncf_A_const_400 = A_arbace_j2g_dyncf_A_const_pool.A[654]; A_arbace_j2g_dyncf_A_const_401 = A_arbace_j2g_dyncf_A_const_pool.A[655]; A_arbace_j2g_dyncf_A_const_402 = A_arbace_j2g_dyncf_A_const_pool.A[656]; A_arbace_j2g_dyncf_A_const_403 = A_arbace_j2g_dyncf_A_const_pool.A[657]; A_arbace_j2g_dyncf_A_const_404 = A_arbace_j2g_dyncf_A_const_pool.A[658]; A_arbace_j2g_dyncf_A_const_405 = A_arbace_j2g_dyncf_A_const_pool.A[659]; A_arbace_j2g_dyncf_A_const_406 = A_arbace_j2g_dyncf_A_const_pool.A[660]; A_arbace_j2g_dyncf_A_const_407 = A_arbace_j2g_dyncf_A_const_pool.A[661]; A_arbace_j2g_dyncf_A_const_408 = A_arbace_j2g_dyncf_A_const_pool.A[662]; A_arbace_j2g_dyncf_A_const_409 = A_arbace_j2g_dyncf_A_const_pool.A[663] }

func A_arbace_j2g_dyncf_A_clinit_p28() { A_arbace_j2g_dyncf_A_const_410 = A_arbace_j2g_dyncf_A_const_pool.A[664]; A_arbace_j2g_dyncf_A_const_411 = A_arbace_j2g_dyncf_A_const_pool.A[665]; A_arbace_j2g_dyncf_A_const_412 = A_arbace_j2g_dyncf_A_const_pool.A[666]; A_arbace_j2g_dyncf_A_const_413 = A_arbace_j2g_dyncf_A_const_pool.A[667]; A_arbace_j2g_dyncf_A_const_414 = A_arbace_j2g_dyncf_A_const_pool.A[668]; A_arbace_j2g_dyncf_A_const_415 = A_arbace_j2g_dyncf_A_const_pool.A[669]; A_arbace_j2g_dyncf_A_const_416 = A_arbace_j2g_dyncf_A_const_pool.A[670]; A_arbace_j2g_dyncf_A_const_417 = A_arbace_j2g_dyncf_A_const_pool.A[671]; A_arbace_j2g_dyncf_A_const_418 = A_arbace_j2g_dyncf_A_const_pool.A[672]; A_arbace_j2g_dyncf_A_const_419 = A_arbace_j2g_dyncf_A_const_pool.A[673]; A_arbace_j2g_dyncf_A_const_420 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[674]); A_arbace_j2g_dyncf_A_const_421 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[675]); A_arbace_j2g_dyncf_A_const_422 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[676]); A_arbace_j2g_dyncf_A_const_423 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[677]) }

func A_arbace_j2g_dyncf_A_clinit_p29() { A_arbace_j2g_dyncf_A_const_424 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[678]); A_arbace_j2g_dyncf_A_const_425 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[679]); A_arbace_j2g_dyncf_A_const_426 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[680]); A_arbace_j2g_dyncf_A_const_427 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[681]); A_arbace_j2g_dyncf_A_const_428 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[682]); A_arbace_j2g_dyncf_A_const_429 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[683]); A_arbace_j2g_dyncf_A_const_430 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[684]); A_arbace_j2g_dyncf_A_const_431 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[685]); A_arbace_j2g_dyncf_A_const_432 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[686]); A_arbace_j2g_dyncf_A_const_433 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[687]); A_arbace_j2g_dyncf_A_const_434 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[688]); A_arbace_j2g_dyncf_A_const_435 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[689]) }

func A_arbace_j2g_dyncf_A_clinit_p30() { A_arbace_j2g_dyncf_A_const_436 = A_arbace_j2g_dyncf_A_const_pool.A[690]; A_arbace_j2g_dyncf_A_const_437 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[691]); A_arbace_j2g_dyncf_A_const_438 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[692]); A_arbace_j2g_dyncf_A_const_439 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[693]); A_arbace_j2g_dyncf_A_const_440 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[694]); A_arbace_j2g_dyncf_A_const_441 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[695]); A_arbace_j2g_dyncf_A_const_442 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[696]); A_arbace_j2g_dyncf_A_const_443 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[697]); A_arbace_j2g_dyncf_A_const_444 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[698]); A_arbace_j2g_dyncf_A_const_445 = A_arbace_j2g_dyncf_A_const_pool.A[699]; A_arbace_j2g_dyncf_A_const_446 = A_arbace_j2g_dyncf_A_const_pool.A[700]; A_arbace_j2g_dyncf_A_const_447 = A_arbace_j2g_dyncf_A_const_pool.A[701]; A_arbace_j2g_dyncf_A_const_448 = A_arbace_j2g_dyncf_A_const_pool.A[702] }

func A_arbace_j2g_dyncf_A_clinit_p31() { A_arbace_j2g_dyncf_A_const_449 = A_arbace_j2g_dyncf_A_const_pool.A[703]; A_arbace_j2g_dyncf_A_const_450 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[704]); A_arbace_j2g_dyncf_A_const_451 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[705]); A_arbace_j2g_dyncf_A_const_452 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[706]); A_arbace_j2g_dyncf_A_const_453 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[707]); A_arbace_j2g_dyncf_A_const_454 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[708]); A_arbace_j2g_dyncf_A_const_455 = A_arbace_j2g_dyncf_A_const_pool.A[709]; A_arbace_j2g_dyncf_A_const_456 = A_arbace_j2g_dyncf_A_const_pool.A[710]; A_arbace_j2g_dyncf_A_const_457 = A_arbace_j2g_dyncf_A_const_pool.A[711]; A_arbace_j2g_dyncf_A_const_458 = A_arbace_j2g_dyncf_A_const_pool.A[712]; A_arbace_j2g_dyncf_A_const_459 = A_arbace_j2g_dyncf_A_const_pool.A[713]; A_arbace_j2g_dyncf_A_const_460 = A_arbace_j2g_dyncf_A_const_pool.A[714]; A_arbace_j2g_dyncf_A_const_461 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[715]) }

func A_arbace_j2g_dyncf_A_clinit_p32() { A_arbace_j2g_dyncf_A_const_462 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[716]); A_arbace_j2g_dyncf_A_const_463 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[717]); A_arbace_j2g_dyncf_A_const_464 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[718]); A_arbace_j2g_dyncf_A_const_465 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[719]); A_arbace_j2g_dyncf_A_const_466 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[720]); A_arbace_j2g_dyncf_A_const_467 = A_arbace_j2g_dyncf_A_const_pool.A[721]; A_arbace_j2g_dyncf_A_const_468 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[722]); A_arbace_j2g_dyncf_A_const_469 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[723]); A_arbace_j2g_dyncf_A_const_470 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[724]); A_arbace_j2g_dyncf_A_const_471 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[725]); A_arbace_j2g_dyncf_A_const_472 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[726]); A_arbace_j2g_dyncf_A_const_473 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[727]) }

func A_arbace_j2g_dyncf_A_clinit_p33() { A_arbace_j2g_dyncf_A_const_474 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[728]); A_arbace_j2g_dyncf_A_const_475 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[729]); A_arbace_j2g_dyncf_A_const_476 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[730]); A_arbace_j2g_dyncf_A_const_477 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[731]); A_arbace_j2g_dyncf_A_const_478 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[732]) }

func A_arbace_j2g_dyncf_A_New() *A_arbace_j2g_dyncf_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_A_class }

func (t *A_arbace_j2g_dyncf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_A); return ok }

func A_arbace_j2g_dyncf_A_Cast(x any) *A_arbace_j2g_dyncf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_A_class)) }; return v }



type A_arbace_j2g_dyncf_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000004_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000004_A_New() *A_arbace_j2g_dyncf_eval292000004_A { t := &A_arbace_j2g_dyncf_eval292000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000004_A_class }

func (t *A_arbace_j2g_dyncf_eval292000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); return ok }

func A_arbace_j2g_dyncf_eval292000004_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000004_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000008_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000008_A_New() *A_arbace_j2g_dyncf_eval292000008_A { t := &A_arbace_j2g_dyncf_eval292000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000008_A_class }

func (t *A_arbace_j2g_dyncf_eval292000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); return ok }

func A_arbace_j2g_dyncf_eval292000008_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000008_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000008_fn__292000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_from_object_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_from_object_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A struct{ j2g_header uint64; F_iter__292000233, F_s__292000234 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A struct{ j2g_header uint64; F_b__292000236 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_fn__292000240_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A struct{ j2g_header uint64; F_iter__292000242, F_s__292000243 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A struct{ j2g_header uint64; F_b__292000245 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000239_iter__292000242__292000246_fn__292000247_fn__292000248_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_fn__292000253_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A struct{ j2g_header uint64; F_iter__292000255, F_s__292000256 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A struct{ j2g_header uint64; F_b__292000258 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000233__292000237_fn__292000238_iter__292000255__292000259_fn__292000260_fn__292000261_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A struct{ j2g_header uint64; F_extendable any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A struct{ j2g_header uint64; F_extendable, F_iter__292000267, F_s__292000268 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A struct{ j2g_header uint64; F_extendable any; F_size__1927001038__auto__ int32; F_b__292000270, F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_fn__292000274_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A struct{ j2g_header uint64; F_iter__292000277, F_s__292000278 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__292000280, F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000277__292000281_fn__292000282_fn__292000283_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A struct{ j2g_header uint64; F_iter__292000287, F_s__292000288 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A struct{ j2g_header uint64; F_b__292000290 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000273_iter__292000287__292000291_fn__292000292_fn__292000293_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_fn__292000298_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A struct{ j2g_header uint64; F_iter__292000301, F_s__292000302 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A struct{ j2g_header uint64; F_b__292000304 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000301__292000305_fn__292000306_fn__292000307_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A struct{ j2g_header uint64; F_iter__292000311, F_s__292000312 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A struct{ j2g_header uint64; F_b__292000314 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000267__292000271_fn__292000272_iter__292000311__292000315_fn__292000316_fn__292000317_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A struct{ j2g_header uint64; F_iter__292000323, F_s__292000324 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A struct{ j2g_header uint64; F_b__292000326 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A struct{ j2g_header uint64; F_iter__292000330, F_s__292000331 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A struct{ j2g_header uint64; F_b__292000333 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000336_fn__292000337_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_fn__292000329_iter__292000330__292000334_fn__292000335_fn__292000340_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A struct{ j2g_header uint64; F_iter__292000345, F_s__292000346 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A struct{ j2g_header uint64; F_b__292000348 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000351_fn__292000352_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000323__292000327_fn__292000328_iter__292000345__292000349_fn__292000350_fn__292000355_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A struct{ j2g_header uint64; F_tset any }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A struct{ j2g_header uint64; F_tset, F_iter__292000361, F_s__292000362 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A struct{ j2g_header uint64; F_b__292000364, F_tset any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A struct{ j2g_header uint64; F_iter__292000371, F_s__292000372 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A struct{ j2g_header uint64; F_b__292000374 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_fn__292000367_iter__292000371__292000375_fn__292000376_fn__292000377_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A struct{ j2g_header uint64; F_iter__292000385, F_s__292000386 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A struct{ j2g_header uint64; F_b__292000388 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000361__292000365_fn__292000366_iter__292000385__292000389_fn__292000390_fn__292000391_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A struct{ j2g_header uint64; F_iter__292000397, F_s__292000398 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A struct{ j2g_header uint64; F_b__292000400 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000397__292000401_fn__292000402_fn__292000403_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A struct{ j2g_header uint64; F_iter__292000413, F_s__292000414 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A struct{ j2g_header uint64; F_b__292000416 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000413__292000417_fn__292000418_fn__292000419_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A struct{ j2g_header uint64; F_s__292000430, F_iter__292000429 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A struct{ j2g_header uint64; F_b__292000432 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000429__292000433_fn__292000434_fn__292000435_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_chain_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A struct{ j2g_header uint64; F_s__292000140, F_iter__292000139 any }

var A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A struct{ j2g_header uint64; F_iter__292000141, F_s__292000142 any }

var A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A struct{ j2g_header uint64; F_b__292000144 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_chain_iter__292000139__292000145_fn__292000146_iter__292000141__292000147_fn__292000148_fn__292000149_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_field_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A struct{ j2g_header uint64; F_iter__292000156, F_s__292000157 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A struct{ j2g_header uint64; F_b__292000159 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A struct{ j2g_header uint64; F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A struct{ j2g_header uint64; F_iter__292000165, F_prot_QMARK_, F_s__292000166 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A struct{ j2g_header uint64; F_b__292000168, F_prot_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000165__292000169_fn__292000170_fn__292000171_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A struct{ j2g_header uint64; F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A struct{ j2g_header uint64; F_iter__292000175, F_prot_QMARK_, F_s__292000176 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A struct{ j2g_header uint64; F_b__292000178, F_prot_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000175__292000179_fn__292000180_fn__292000181_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A struct{ j2g_header uint64; F_iter__292000185, F_s__292000186 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A struct{ j2g_header uint64; F_b__292000188 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_iter__292000185__292000189_fn__292000190_fn__292000191_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_fn__292000162_prot_QMARK___292000163_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A struct{ j2g_header uint64; F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A struct{ j2g_header uint64; F_prot_QMARK_, F_iter__292000199, F_s__292000200 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A struct{ j2g_header uint64; F_b__292000202, F_prot_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000199__292000203_fn__292000204_fn__292000205_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A struct{ j2g_header uint64; F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A struct{ j2g_header uint64; F_prot_QMARK_, F_s__292000210, F_iter__292000209 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A struct{ j2g_header uint64; F_b__292000212, F_prot_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000209__292000213_fn__292000214_fn__292000215_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A struct{ j2g_header uint64; F_s__292000220, F_iter__292000219 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A struct{ j2g_header uint64; F_b__292000222 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_iter__292000219__292000223_fn__292000224_fn__292000225_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000156__292000160_fn__292000161_prot_QMARK___292000197_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_serial_init_body_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_serial_init_body_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_serial_init_body_fn__292000100_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A struct{ j2g_header uint64; F_recv any }

var A_arbace_j2g_dyncf_serial_init_body_on_t__292000095_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_fn__292000135_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_fn__292000135_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000017, F_s__292000018 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A struct{ j2g_header uint64; F_b__292000020, F_recv, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000043, F_s__292000044 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A struct{ j2g_header uint64; F_recv, F_b__292000046, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A struct{ j2g_header uint64; F_recv, F_seen any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A struct{ j2g_header uint64; F_recv, F_iter__292000077, F_seen, F_s__292000078 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A struct{ j2g_header uint64; F_recv, F_seen, F_c any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A struct{ j2g_header uint64; F_recv, F_s__292000080, F_seen, F_iter__292000079, F_c any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A struct{ j2g_header uint64; F_recv, F_seen any; F_size__1927001038__auto__ int32; F_b__292000082, F_c__1927001037__auto__, F_c any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A struct{ j2g_header uint64; F_iter__292000103, F_s__292000104 any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A struct{ j2g_header uint64; F_b__292000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A struct{ j2g_header uint64; F_iter__292000113, F_s__292000114 any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A struct{ j2g_header uint64; F_b__292000116 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A struct{ j2g_header uint64; F_iter__292000123, F_s__292000124 any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A struct{ j2g_header uint64; F_b__292000126 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000123__292000127_fn__292000128_fn__292000129_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_tag_A_fn_class *jrt.Class
