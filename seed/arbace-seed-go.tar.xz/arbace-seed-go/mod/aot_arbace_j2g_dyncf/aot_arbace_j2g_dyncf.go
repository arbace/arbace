//line aot_arbace_j2g_dyncf.ae:1
package aot_arbace_j2g_dyncf

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_dyn"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/aot_arbace_walk"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_New() *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyncf_A_const_11); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_1, A_arbace_j2g_dyncf_A_const_2, A_arbace_j2g_dyncf_A_const_3, A_arbace_j2g_dyncf_A_const_4, A_arbace_j2g_dyncf_A_const_5, A_arbace_j2g_dyncf_A_const_6, A_arbace_j2g_dyncf_A_const_7, A_arbace_j2g_dyncf_A_const_8, A_arbace_j2g_dyncf_A_const_9); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_New() *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000008_fn__292000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_12.GetRawRoot__O()); var tmp2 any; var root_23 any = A_arbace_j2g_dyncf_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = A_arbace_j2g_dyncf_A_const_14; if linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_23, arg_26) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(), A_arbace_j2g_dyncf_A_const_16) }



















func A_arbace_j2g_dyncf_enabled_QMARK__A_New() *A_arbace_j2g_dyncf_enabled_QMARK__A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_enabled_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_27 any = A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = A_arbace_j2g_dyncf_A_const_18.GetRawRoot__O(); if linked_28 == nil { return ifn_29.Invoke_O__O(arg_30) } else { return linked_28.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_27, arg_30)
	} }
func A_arbace_j2g_dyncf_tag_A_New() *A_arbace_j2g_dyncf_tag_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_tag_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_dyncf_tag_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_dyncf_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_31 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = sym__0; var arg_35 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyncf_A_const_20, type__1)); if linked_32 == nil { return ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { return linked_32.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) } }

func A_arbace_j2g_dyncf_native_name_A_New() *A_arbace_j2g_dyncf_native_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_native_name_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_j2g_dyncf_native_name_A) Ctor() {}
//line :28:1
func (t *A_arbace_j2g_dyncf_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var root_36 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_56, nil, Lit_57); var tmp2 any; var root_40 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_j2g_dyncf_A_const_18.GetRawRoot__O(); if linked_41 == nil { tmp2 = ifn_42.Invoke_O__O(arg_43) } else { tmp2 = linked_41.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_40, arg_43) }; var tmp3 any = tmp2; var tmp4 any; var root_44 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = mname__0; var arg_48 any = desc__1; if linked_45 == nil { tmp4 = ifn_46.Invoke_O_O__O(arg_47, arg_48) } else { tmp4 = linked_45.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_44, arg_47, arg_48) }; arg_39 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref(); if linked_37 == nil { return ifn_38.Invoke_O__O(arg_39) } else { return linked_37.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_36, arg_39)
	}
}







func A_arbace_j2g_dyncf_sub_name_A_New() *A_arbace_j2g_dyncf_sub_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_name_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_77, nil); var tmp2 any; var root_49 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = n__0; if linked_50 == nil { tmp2 = ifn_51.Invoke_O__O(arg_52) } else { tmp2 = linked_50.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_49, arg_52) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyncf_from_object_A_New() *A_arbace_j2g_dyncf_from_object_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_from_object_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_j2g_dyncf_from_object_A) Ctor() {}
//line :41:1
func (t *A_arbace_j2g_dyncf_from_object_A) Invoke_O_O_O__O(self, d__0, x__1 any) any {


	var tmp1 any; var root_53 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = d__0; if linked_54 == nil { tmp1 = ifn_55.Invoke_O__O(arg_56) } else { tmp1 = linked_54.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_53, arg_56) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_27; var tmp4 any; var root_57 any = A_arbace_j2g_dyncf_A_const_28.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = A_arbace_j2g_dyncf_A_const_29; var arg_61 any = d__0; if linked_58 == nil { tmp4 = ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { tmp4 = linked_58.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_57, arg_60, arg_61) }; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_30; var tmp8 any; var root_62 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_64 lang.IFn
		if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_31.GetRawRoot__O()).Invoke_O__O(d__0))).Ref(); if linked_63 == nil { tmp8 = ifn_64.Invoke_O__O(arg_65) } else { tmp8 = linked_63.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_62, arg_65) }
//line :44:1
		return tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O__O(tmp7, tmp8, x__1)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_29) { return x__1 } else { if A_arbace_j2g_dyncf_A_const_26 != nil {


			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_32; var tmp12 any = A_arbace_j2g_dyncf_A_const_33; var tmp13 any; var root_66 any = A_arbace_j2g_dyncf_A_const_28.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = A_arbace_j2g_dyncf_A_const_29; var arg_70 any = d__0; if linked_67 == nil { tmp13 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { tmp13 = linked_67.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }; return tmp9.Invoke_O_O__O(tmp10.Invoke_O_O_O__O(tmp11, tmp12, tmp13), x__1) } else {
//line :44:1
				return nil
			}
		}
		}
}
func A_arbace_j2g_dyncf_sub_forms_A_New() *A_arbace_j2g_dyncf_sub_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_71 any = A_arbace_j2g_dyncf_A_const_34.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_73 lang.IFn; if


	linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = n__0; if linked_72 == nil { g__2 = ifn_73.Invoke_O__O(arg_74) } else { g__2 = linked_72.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_71, arg_74) }; var recv__3 any; var tmp1 lang.IFn = /*line :49:1*/lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_36; var tmp3 any; var root_78 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_80 lang.IFn; if



	linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = g__2; if linked_79 == nil { tmp3 = ifn_80.Invoke_O__O(arg_81) } else { tmp3 = linked_79.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_78, arg_81) }; recv__3 = tmp1.Invoke_O_O__O(tmp2, tmp3); var root_82 any =
	A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_39, A_arbace_j2g_dyncf_A_const_40); if linked_83 == nil { ifn_84.Invoke_O__O(arg_85) } else { linked_83.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_82, arg_85) }; var tmp4 any; tmp50 := /*line :49:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyncf_A_const_41; var tmp7 any; var root_91 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_93 lang.IFn





		if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_92 == nil { tmp7 = ifn_93.Invoke_O__O(arg_94) } else { tmp7 = linked_92.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_91, arg_94) }
//line :49:1
		var tmp8 any = tmp7; var tmp9 any; var root_95 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_97 lang.IFn





		if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var tmp10 any; var root_100 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = A_arbace_j2g_dyncf_A_const_43; var arg_104 any = A_arbace_j2g_dyncf_A_const_44; if linked_101 == nil { tmp10 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp10 = linked_101.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; var tmp11 any = tmp10; var tmp12 any; var root_105 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_j2g_dyncf_A_const_45; var arg_109 any = A_arbace_j2g_dyncf_A_const_46; if linked_106 == nil { tmp12 = ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { tmp12 = linked_106.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) }; arg_98 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12); var arg_99 any = A_arbace_j2g_dyncf_A_const_47; if linked_96 == nil { tmp9 = ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { tmp9 = linked_96.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }
//line :49:1
		var tmp13 any = tmp9; var tmp14 any; var tmp15 any; var or__1927000174__auto____6 any; var root_110 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_112 lang.IFn






		if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = n__0; if linked_111 == nil { or__1927000174__auto____6 = ifn_112.Invoke_O__O(arg_113) } else { or__1927000174__auto____6 = linked_111.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_110, arg_113) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp15 = or__1927000174__auto____6 } else { var root_114 any = A_arbace_j2g_dyncf_A_const_49.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = n__0; if linked_115 == nil { tmp15 = ifn_116.Invoke_O__O(arg_117) } else { tmp15 = linked_115.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_114, arg_117) } }; if jrt.J2g_Truth(tmp15) { tmp14 = A_arbace_j2g_dyncf_A_const_50 } else {

			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp17 any; var root_118 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_j2g_dyncf_A_const_29; var arg_122 any = n__0; var arg_123 any = Lit_60; if linked_119 == nil { tmp17 = ifn_120.Invoke_O_O_O__O(arg_121, arg_122, arg_123) } else { tmp17 = linked_119.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_118, arg_121, arg_122, arg_123) }; tmp14 = tmp16.Invoke_O__O(tmp17) }
//line :49:1
		var tmp18 any = tmp14; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyncf_A_const_52; var tmp21 any = A_arbace_j2g_dyncf_A_const_56; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_57; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyncf_A_const_58; var tmp26 any; var root_124 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_126 lang.IFn









		if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = g__2; if linked_125 == nil { tmp26 = ifn_126.Invoke_O__O(arg_127) } else { tmp26 = linked_125.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_124, arg_127) }
//line :49:1
		var tmp27 any = tmp5.Invoke_O_O_O_O_O__O(tmp6, tmp8, tmp13, tmp18, tmp19.Invoke_O_O_O_O_O__O(tmp20, lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp22.Invoke_O_O__O(tmp23, tmp24.Invoke_O_O_O_O__O(tmp25, tmp26, A_arbace_j2g_dyncf_A_const_59, A_arbace_j2g_dyncf_A_const_60))), A_arbace_j2g_dyncf_A_const_53, A_arbace_j2g_dyncf_A_const_54, A_arbace_j2g_dyncf_A_const_55)); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyncf_A_const_61; var tmp30 any; var root_128 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_130 lang.IFn














		if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any; var root_133 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_134 == nil { arg_131 = ifn_135.Invoke_O__O(arg_136) } else { arg_131 = linked_134.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_133, arg_136) }; var arg_132 any = A_arbace_j2g_dyncf_A_const_62; if linked_129 == nil { tmp30 = ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { tmp30 = linked_129.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_128, arg_131, arg_132) }
//line :49:1
		var tmp31 any = tmp30; var tmp32 any; var root_137 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_139 lang.IFn















		if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_141 any = A_arbace_j2g_dyncf_A_const_64; var arg_142 any = A_arbace_j2g_dyncf_A_const_65; var arg_143 any; var iter__1927001039__auto____6 any; var tmp33 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(recv__3, n__0); var tmp34 *jrt.Class; var fncls__414 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class
		if fncls__414 == nil { var fncls__414d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class = fncls__414d; tmp34 = fncls__414d } else { tmp34 = fncls__414 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var tmp35 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp36 any; var tmp37 any; var root_415 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = n__0; if linked_416 == nil { tmp37 = ifn_417.Invoke_O__O(arg_418) } else { tmp37 = linked_416.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_415, arg_418) }; if jrt.J2g_Truth(tmp37) { var root_419 any = A_arbace_j2g_dyncf_A_const_105.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = n__0; if linked_420 == nil { tmp36 = ifn_421.Invoke_O__O(arg_422) } else { tmp36 = linked_420.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_419, arg_422) } } else { var tmp38 *lang.Keyword = A_arbace_j2g_dyncf_A_const_106; var tmp39 any; var root_423 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = n__0; if linked_424 == nil { tmp39 = ifn_425.Invoke_O__O(arg_426) } else { tmp39 = linked_424.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_423, arg_426) }; tmp36 = tmp38.Invoke_O__O(tmp39) }; arg_143 = tmp35.Invoke_O__O(tmp36)
//line :65:1
		if linked_138 == nil { tmp32 = ifn_139.Invoke_O_O_O_O__O(arg_140, arg_141, arg_142, arg_143) } else { tmp32 = linked_138.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_137, arg_140, arg_141, arg_142, arg_143) }
//line :49:1
		var tmp40 any = tmp28.Invoke_O_O_O__O(tmp29, tmp31, tmp32); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp42 any = A_arbace_j2g_dyncf_A_const_108; var tmp43 any; var root_427 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_429 lang.IFn






























		if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var root_432 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_433 == nil { arg_430 = ifn_434.Invoke_O__O(arg_435) } else { arg_430 = linked_433.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_432, arg_435) }; var arg_431 any = A_arbace_j2g_dyncf_A_const_109; if linked_428 == nil { tmp43 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { tmp43 = linked_428.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }
//line :49:1
		var tmp44 any = tmp43; var tmp45 any; var root_436 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_438 lang.IFn































		if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_440 any = A_arbace_j2g_dyncf_A_const_110; var arg_441 any = A_arbace_j2g_dyncf_A_const_111; var arg_442 any; var iter__1927001039__auto____6_2 any; var tmp46 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(recv__3, n__0); var tmp47 *jrt.Class; var fncls__711 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class
		if fncls__711 == nil { var fncls__711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class = fncls__711d; tmp47 = fncls__711d } else { tmp47 = fncls__711 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil); var tmp48 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6_2); var tmp49 any; var root_712 any = A_arbace_j2g_dyncf_A_const_142.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var arg_716 any; var root_717 any = A_arbace_j2g_dyncf_A_const_143.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = n__0; if linked_718 == nil { arg_716 = ifn_719.Invoke_O__O(arg_720) } else { arg_716 = linked_718.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_717, arg_720) }; if linked_713 == nil { tmp49 = ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { tmp49 = linked_713.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_712, arg_715, arg_716) }; arg_442 = tmp48.Invoke_O__O(tmp49)
//line :81:1
		if linked_437 == nil { tmp45 = ifn_438.Invoke_O_O_O_O__O(arg_439, arg_440, arg_441, arg_442) } else { tmp45 = linked_437.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_436, arg_439, arg_440, arg_441, arg_442) }
//line :49:1
		tmp4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp27, tmp40, tmp41.Invoke_O_O_O__O(tmp42, tmp44, tmp45)) }; return nil }(); var root_75 any = A_arbace_j2g_dyncf_A_const_35.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_77 lang.IFn; if




	linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; if linked_76 == nil { ifn_77.Invoke__O() } else { linked_76.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_75) }; if /*line :49:1*/ tmp50 != nil { panic(tmp50) }; return tmp4 }
















func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Invoke_O_O__O(self, s__292000018__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000018__1); var tmp2 *jrt.Class; var fncls__413 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class; if fncls__413 == nil { var fncls__413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class = fncls__413d; tmp2 = fncls__413d } else { tmp2 = fncls__413 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000017, c__s__292000018 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000017 = c__iter__292000017; t.F_s__292000018 = c__s__292000018 }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Invoke_O__O(self any) any { { var s__292000018__1 any; var t_ any = t.F_s__292000018; t.F_s__292000018 = nil; s__292000018__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_144 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = s__292000018__1; if linked_145 == nil { temp__1927000414__auto____2 = ifn_146.Invoke_O__O(arg_147) } else { temp__1927000414__auto____2 = linked_145.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_144, arg_147) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000018__3 any = temp__1927000414__auto____2; var tmp1 any; var root_148 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = s__292000018__3; if linked_149 == nil { tmp1 = ifn_150.Invoke_O__O(arg_151) } else { tmp1 = linked_149.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_148, arg_151) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_152 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = s__292000018__3; if linked_153 == nil { c__1927001037__auto____4 = ifn_154.Invoke_O__O(arg_155) } else { c__1927001037__auto____4 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_152, arg_155) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000020__6 any; var root_156 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_157 == nil { b__292000020__6 = ifn_158.Invoke_O__O(arg_159) } else { b__292000020__6 = linked_157.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_156, arg_159) }; var tmp2 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(b__292000020__6, t.F_recv, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class = fncls__265d; tmp3 = fncls__265d } else { tmp3 = fncls__265 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_266 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any; var root_271 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = b__292000020__6; if linked_272 == nil { arg_269 = ifn_273.Invoke_O__O(arg_274) } else { arg_269 = linked_272.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_271, arg_274) }; var arg_270 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp5 any; var root_275 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = s__292000018__3; if linked_276 == nil { tmp5 = ifn_277.Invoke_O__O(arg_278) } else { tmp5 = linked_276.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_275, arg_278) }; arg_270 = tmp4.Invoke_O__O(tmp5); if linked_267 == nil { return ifn_268.Invoke_O_O__O(arg_269, arg_270) } else { return linked_267.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_266, arg_269, arg_270) } } else { var root_279 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any; var root_284 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = b__292000020__6; if linked_285 == nil { arg_282 = ifn_286.Invoke_O__O(arg_287) } else { arg_282 = linked_285.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_284, arg_287) }; var arg_283 any; if linked_280 == nil { return ifn_281.Invoke_O_O__O(arg_282, arg_283) } else { return linked_280.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_279, arg_282, arg_283) } } } else { var mm__4 any; var root_288 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = s__292000018__3; if linked_289 == nil { mm__4 = ifn_290.Invoke_O__O(arg_291) } else { mm__4 = linked_289.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_288, arg_291) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_292 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any; var root_296 any = A_arbace_j2g_dyncf_A_const_72.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = mm__4; if linked_297 == nil { arg_295 = ifn_298.Invoke_O__O(arg_299) } else { arg_295 = linked_297.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_296, arg_299) }; if linked_293 == nil { and__1927000168__auto____6 = ifn_294.Invoke_O__O(arg_295) } else { and__1927000168__auto____6 = linked_293.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_292, arg_295) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_300 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4); if linked_301 == nil { tmp6 = ifn_302.Invoke_O__O(arg_303) } else { tmp6 = linked_301.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_300, arg_303) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :66:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_304 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_306 lang.IFn

		if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any; var root_308 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = t.F_n; if linked_309 == nil { arg_307 = ifn_310.Invoke_O__O(arg_311) } else { arg_307 = linked_309.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_308, arg_311) }; if linked_305 == nil { or__1927000174__auto____5 = ifn_306.Invoke_O__O(arg_307) } else { or__1927000174__auto____5 = linked_305.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_304, arg_307) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_312 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any; var root_317 any = A_arbace_j2g_dyncf_A_const_76.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyncf_A_const_77; var arg_320 any = tmp8.Invoke_O__O(A_arbace_j2g_dyncf_A_const_78.Get__O()); var arg_321 any; var root_322 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = t.F_n; if linked_323 == nil { arg_321 = ifn_324.Invoke_O__O(arg_325) } else { arg_321 = linked_323.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_322, arg_325) }; if linked_318 == nil { arg_315 = ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { arg_315 = linked_318.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_317, arg_320, arg_321) }; var arg_316 any; var root_326 any = A_arbace_j2g_dyncf_A_const_79.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4); if linked_327 == nil { arg_316 = ifn_328.Invoke_O__O(arg_329) } else { arg_316 = linked_327.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_326, arg_329) }; if linked_313 == nil { tmp7 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp7 = linked_313.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_312, arg_315, arg_316) } }
//line :66:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_330 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_332 lang.IFn



			if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = t.F_n; if linked_331 == nil { tmp9 = ifn_332.Invoke_O__O(arg_333) } else { tmp9 = linked_331.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_330, arg_333) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4) } else { var root_334 any = A_arbace_j2g_dyncf_A_const_80.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = t.F_n; var arg_338 any = mm__4; if linked_335 == nil { real__5 = ifn_336.Invoke_O_O__O(arg_337, arg_338) } else { real__5 = linked_335.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_334, arg_337, arg_338) } }
//line :66:1
			var vec__292000033__6 any; var root_339 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_341 lang.IFn




			if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4); if linked_340 == nil { vec__292000033__6 = ifn_341.Invoke_O__O(arg_342) } else { vec__292000033__6 = linked_340.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_339, arg_342) }
//line :66:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000036__9 any; var root_343 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_345 lang.IFn; _ = ___8





			if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = real__5; if linked_344 == nil { vec__292000036__9 = ifn_345.Invoke_O__O(arg_346) } else { vec__292000036__9 = linked_344.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_343, arg_346) }
//line :66:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_347 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any; var tmp10 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyncf_A_const_83; var tmp13 any; var root_352 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_354 lang.IFn








				if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = A_arbace_j2g_dyncf_A_const_84; var arg_356 any = A_arbace_j2g_dyncf_A_const_85; if linked_353 == nil { tmp13 = ifn_354.Invoke_O_O__O(arg_355, arg_356) } else { tmp13 = linked_353.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_352, arg_355, arg_356) }
//line :66:1
				var tmp14 any = tmp13; var tmp15 any; var root_357 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_359 lang.IFn








				if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = A_arbace_j2g_dyncf_A_const_86; var arg_361 any = A_arbace_j2g_dyncf_A_const_103; if linked_358 == nil { tmp15 = ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { tmp15 = linked_358.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_357, arg_360, arg_361) }
//line :66:1
				var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyncf_A_const_88; var tmp19 any = A_arbace_j2g_dyncf_A_const_95; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_96, t.F_recv, A_arbace_j2g_dyncf_A_const_97)); var tmp21 any; var root_362 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_364 lang.IFn










				if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_366 any; var root_370 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp23 any; var root_374 any = A_arbace_j2g_dyncf_A_const_79.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = real__5; if linked_375 == nil { tmp23 = ifn_376.Invoke_O__O(arg_377) } else { tmp23 = linked_375.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_374, arg_377) }; arg_373 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_371 == nil { arg_366 = ifn_372.Invoke_O__O(arg_373) } else { arg_366 = linked_371.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_370, arg_373) }; var arg_367 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp25 any; var root_378 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_380 lang.IFn
				if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any; var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp27 any; var root_382 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = t.F_n; if linked_383 == nil { tmp27 = ifn_384.Invoke_O__O(arg_385) } else { tmp27 = linked_383.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_382, arg_385) }; arg_381 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp27)).Ref(); if linked_379 == nil { tmp25 = ifn_380.Invoke_O__O(arg_381) } else { tmp25 = linked_379.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_378, arg_381) }; arg_367 = tmp24.Invoke_O_O__O(tmp25, A_arbace_j2g_dyncf_A_const_89)
//line :77:1
				var arg_368 any = A_arbace_j2g_dyncf_A_const_90; var arg_369 any; var root_386 any = A_arbace_j2g_dyncf_A_const_91.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_388 lang.IFn

				if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var tmp28 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New(); var tmp29 *jrt.Class; var fncls__396 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class; if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class = fncls__396d; tmp29 = fncls__396d } else { tmp29 = fncls__396 }; arg_389 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_390 any = ps__7; if linked_387 == nil { arg_369 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { arg_369 = linked_387.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }
//line :77:1
				if linked_363 == nil { tmp21 = ifn_364.Invoke_O_O_O_O_O__O(arg_365, arg_366, arg_367, arg_368, arg_369) } else { tmp21 = linked_363.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_362, arg_365, arg_366, arg_367, arg_368, arg_369) }
//line :66:1
				arg_350 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp20, tmp21))); var arg_351 any; var tmp30 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp31 any; var root_397 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = s__292000018__3; if linked_398 == nil { tmp31 = ifn_399.Invoke_O__O(arg_400) } else { tmp31 = linked_398.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_397, arg_400) }; arg_351 = tmp30.Invoke_O__O(tmp31); if linked_348 == nil { return ifn_349.Invoke_O_O__O(arg_350, arg_351) } else { return linked_348.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_347, arg_350, arg_351) } } else { var tmp32 any; var root_401 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = s__292000018__3; if linked_402 == nil { tmp32 = ifn_403.Invoke_O__O(arg_404) } else { tmp32 = linked_402.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_401, arg_404) }; s__292000018__1 = tmp32; continue L1 } } else { var tmp33 any; var root_405 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = s__292000018__3; if linked_406 == nil { tmp33 = ifn_407.Invoke_O__O(arg_408) } else { tmp33 = linked_406.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_405, arg_408) }; s__292000018__1 = tmp33; continue L1 } } else { var tmp34 any; var root_409 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = s__292000018__3; if linked_410 == nil { tmp34 = ifn_411.Invoke_O__O(arg_412) } else { tmp34 = linked_410.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_409, arg_412) }; s__292000018__1 = tmp34; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Ctor_O_O_O_I_O(c__b__292000020, c__recv, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000020 = c__b__292000020; t.F_recv = c__recv; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Invoke_O__O(self any) any { { var i__292000019__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000019__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000019__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_160 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_164 any = A_arbace_j2g_dyncf_A_const_72.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = mm__2; if linked_165 == nil { arg_163 = ifn_166.Invoke_O__O(arg_167) } else { arg_163 = linked_165.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_164, arg_167) }; if linked_161 == nil { and__1927000168__auto____4 = ifn_162.Invoke_O__O(arg_163) } else { and__1927000168__auto____4 = linked_161.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_168 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2); if linked_169 == nil { tmp2 = ifn_170.Invoke_O__O(arg_171) } else { tmp2 = linked_169.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_168, arg_171) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :66:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_172 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_174 lang.IFn

		if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any; var root_176 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = t.F_n; if linked_177 == nil { arg_175 = ifn_178.Invoke_O__O(arg_179) } else { arg_175 = linked_177.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_176, arg_179) }; if linked_173 == nil { or__1927000174__auto____3 = ifn_174.Invoke_O__O(arg_175) } else { or__1927000174__auto____3 = linked_173.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_172, arg_175) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_180 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any; var root_185 any = A_arbace_j2g_dyncf_A_const_76.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyncf_A_const_77; var arg_188 any = tmp4.Invoke_O__O(A_arbace_j2g_dyncf_A_const_78.Get__O()); var arg_189 any; var root_190 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = t.F_n; if linked_191 == nil { arg_189 = ifn_192.Invoke_O__O(arg_193) } else { arg_189 = linked_191.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_190, arg_193) }; if linked_186 == nil { arg_183 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { arg_183 = linked_186.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_185, arg_188, arg_189) }; var arg_184 any; var root_194 any = A_arbace_j2g_dyncf_A_const_79.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2); if linked_195 == nil { arg_184 = ifn_196.Invoke_O__O(arg_197) } else { arg_184 = linked_195.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_194, arg_197) }; if linked_181 == nil { tmp3 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { tmp3 = linked_181.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_180, arg_183, arg_184) } }
//line :66:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_198 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_200 lang.IFn



			if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = t.F_n; if linked_199 == nil { tmp5 = ifn_200.Invoke_O__O(arg_201) } else { tmp5 = linked_199.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_198, arg_201) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2) } else { var root_202 any = A_arbace_j2g_dyncf_A_const_80.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = t.F_n; var arg_206 any = mm__2; if linked_203 == nil { real__3 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { real__3 = linked_203.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) } }
//line :66:1
			var vec__292000024__4 any; var root_207 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_209 lang.IFn




			if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2); if linked_208 == nil { vec__292000024__4 = ifn_209.Invoke_O__O(arg_210) } else { vec__292000024__4 = linked_208.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_207, arg_210) }
//line :66:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000027__7 any; var root_211 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_213 lang.IFn; _ = ___6





			if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = real__3; if linked_212 == nil { vec__292000027__7 = ifn_213.Invoke_O__O(arg_214) } else { vec__292000027__7 = linked_212.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_211, arg_214) }
//line :66:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_215 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = t.F_b__292000020; var arg_219 any; var tmp6 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyncf_A_const_83; var tmp9 any; var root_220 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_222 lang.IFn








				if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = A_arbace_j2g_dyncf_A_const_84; var arg_224 any = A_arbace_j2g_dyncf_A_const_85; if linked_221 == nil { tmp9 = ifn_222.Invoke_O_O__O(arg_223, arg_224) } else { tmp9 = linked_221.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_220, arg_223, arg_224) }
//line :66:1
				var tmp10 any = tmp9; var tmp11 any; var root_225 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_227 lang.IFn








				if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = A_arbace_j2g_dyncf_A_const_86; var arg_229 any = A_arbace_j2g_dyncf_A_const_87; if linked_226 == nil { tmp11 = ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { tmp11 = linked_226.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) }
//line :66:1
				var tmp12 any = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyncf_A_const_88; var tmp15 any = A_arbace_j2g_dyncf_A_const_95; var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_96, t.F_recv, A_arbace_j2g_dyncf_A_const_97)); var tmp17 any; var root_230 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_232 lang.IFn










				if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_234 any; var root_238 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp19 any; var root_242 any = A_arbace_j2g_dyncf_A_const_79.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = real__3; if linked_243 == nil { tmp19 = ifn_244.Invoke_O__O(arg_245) } else { tmp19 = linked_243.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_242, arg_245) }; arg_241 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19)).Ref(); if linked_239 == nil { arg_234 = ifn_240.Invoke_O__O(arg_241) } else { arg_234 = linked_239.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_238, arg_241) }; var arg_235 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp21 any; var root_246 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_248 lang.IFn
				if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp23 any; var root_250 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = t.F_n; if linked_251 == nil { tmp23 = ifn_252.Invoke_O__O(arg_253) } else { tmp23 = linked_251.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_250, arg_253) }; arg_249 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_247 == nil { tmp21 = ifn_248.Invoke_O__O(arg_249) } else { tmp21 = linked_247.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_246, arg_249) }; arg_235 = tmp20.Invoke_O_O__O(tmp21, A_arbace_j2g_dyncf_A_const_89)
//line :77:1
				var arg_236 any = A_arbace_j2g_dyncf_A_const_90; var arg_237 any; var root_254 any = A_arbace_j2g_dyncf_A_const_91.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_256 lang.IFn

				if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var tmp24 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New(); var tmp25 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class = fncls__264d; tmp25 = fncls__264d } else { tmp25 = fncls__264 }; arg_257 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var arg_258 any = ps__5; if linked_255 == nil { arg_237 = ifn_256.Invoke_O_O__O(arg_257, arg_258) } else { arg_237 = linked_255.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_254, arg_257, arg_258) }
//line :77:1
				if linked_231 == nil { tmp17 = ifn_232.Invoke_O_O_O_O_O__O(arg_233, arg_234, arg_235, arg_236, arg_237) } else { tmp17 = linked_231.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_230, arg_233, arg_234, arg_235, arg_236, arg_237) }
//line :66:1
				arg_219 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp16, tmp17))); if linked_216 == nil { ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { linked_216.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }; i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_259 any = A_arbace_j2g_dyncf_A_const_92.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = p__2; var arg_263 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_93, A_arbace_j2g_dyncf_A_const_94, i__1); if linked_260 == nil { return ifn_261.Invoke_O_O__O(arg_262, arg_263) } else { return linked_260.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_259, arg_262, arg_263) } }
//line :79:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_391 any = A_arbace_j2g_dyncf_A_const_92.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = p__2; var arg_395 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_93, A_arbace_j2g_dyncf_A_const_94, i__1); if linked_392 == nil { return ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { return linked_392.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) } }


func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Invoke_O_O__O(self, s__292000044__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000044__1); var tmp2 *jrt.Class; var fncls__710 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class; if fncls__710 == nil { var fncls__710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class = fncls__710d; tmp2 = fncls__710d } else { tmp2 = fncls__710 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000043, c__s__292000044 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000043 = c__iter__292000043; t.F_s__292000044 = c__s__292000044 }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Invoke_O__O(self any) any { { var s__292000044__1 any; var t_ any = t.F_s__292000044; t.F_s__292000044 = nil; s__292000044__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_443 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = s__292000044__1; if linked_444 == nil { temp__1927000414__auto____2 = ifn_445.Invoke_O__O(arg_446) } else { temp__1927000414__auto____2 = linked_444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_443, arg_446) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000044__3 any = temp__1927000414__auto____2; var tmp1 any; var root_447 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = s__292000044__3; if linked_448 == nil { tmp1 = ifn_449.Invoke_O__O(arg_450) } else { tmp1 = linked_448.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_447, arg_450) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_451 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = s__292000044__3; if linked_452 == nil { c__1927001037__auto____4 = ifn_453.Invoke_O__O(arg_454) } else { c__1927001037__auto____4 = linked_452.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_451, arg_454) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000046__6 any; var root_455 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_456 == nil { b__292000046__6 = ifn_457.Invoke_O__O(arg_458) } else { b__292000046__6 = linked_456.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_455, arg_458) }; var tmp2 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(t.F_recv, b__292000046__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__565 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class; if fncls__565 == nil { var fncls__565d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class = fncls__565d; tmp3 = fncls__565d } else { tmp3 = fncls__565 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_566 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var root_571 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = b__292000046__6; if linked_572 == nil { arg_569 = ifn_573.Invoke_O__O(arg_574) } else { arg_569 = linked_572.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_571, arg_574) }; var arg_570 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp5 any; var root_575 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = s__292000044__3; if linked_576 == nil { tmp5 = ifn_577.Invoke_O__O(arg_578) } else { tmp5 = linked_576.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_575, arg_578) }; arg_570 = tmp4.Invoke_O__O(tmp5); if linked_567 == nil { return ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { return linked_567.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_566, arg_569, arg_570) } } else { var root_579 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any; var root_584 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = b__292000046__6; if linked_585 == nil { arg_582 = ifn_586.Invoke_O__O(arg_587) } else { arg_582 = linked_585.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_584, arg_587) }; var arg_583 any; if linked_580 == nil { return ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { return linked_580.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_579, arg_582, arg_583) } } } else { var vec__292000063__4 any; var root_588 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = s__292000044__3; if linked_589 == nil { vec__292000063__4 = ifn_590.Invoke_O__O(arg_591) } else { vec__292000063__4 = linked_589.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_588, arg_591) }; var vec__292000066__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(0), nil); var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__292000066__5; var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_592 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_594 lang.IFn; _ = ___9
														if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = desc__7; if linked_593 == nil { tmp6 = ifn_594.Invoke_O__O(arg_595) } else { tmp6 = linked_593.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_592, arg_595) }
//line :82:1
	if jrt.J2g_Truth(tmp6) { var impl__10 any; var root_596 any = A_arbace_j2g_dyncf_A_const_112.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_598 lang.IFn

		if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = t.F_n; var arg_600 any = k__8; if linked_597 == nil { impl__10 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { impl__10 = linked_597.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }
//line :82:1
		var base__11 any; var root_601 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_603 lang.IFn


		if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = name__6; var arg_605 any = desc__7; if linked_602 == nil { base__11 = ifn_603.Invoke_O_O__O(arg_604, arg_605) } else { base__11 = linked_602.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_601, arg_604, arg_605) }
//line :82:1
		var vec__292000069__12 any; var root_606 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_608 lang.IFn



		if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = desc__7; if linked_607 == nil { vec__292000069__12 = ifn_608.Invoke_O__O(arg_609) } else { vec__292000069__12 = linked_607.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_606, arg_609) }
//line :82:1
		var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(0), nil); var r__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__15 any; var root_610 any = A_arbace_j2g_dyncf_A_const_91.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_612 lang.IFn




		if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var tmp7 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New(); var tmp8 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class; if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class = fncls__620d; tmp8 = fncls__620d } else { tmp8 = fncls__620 }; arg_613 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_614 any = ps__13; if linked_611 == nil { pn__15 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { pn__15 = linked_611.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }
//line :82:1
		var call__16 any; var G__292000074__16_ any = A_arbace_j2g_dyncf_A_const_115.Invoke_O__O(impl__10)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000074__16_) >> 4 & 3 { case 0: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_116) {

		var root_622 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_626 any; var root_629 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = A_arbace_j2g_dyncf_A_const_29; var arg_633 any = A_arbace_j2g_dyncf_A_const_117.Invoke_O__O(impl__10); var arg_634 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_630 == nil { arg_626 = ifn_631.Invoke_O_O_O__O(arg_632, arg_633, arg_634) } else { arg_626 = linked_630.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_629, arg_632, arg_633, arg_634) }; var arg_627 any = A_arbace_j2g_dyncf_A_const_118; var arg_628 any = pn__15; if linked_623 == nil { call__16 = ifn_624.Invoke_O_O_O_O__O(arg_625, arg_626, arg_627, arg_628) } else { call__16 = linked_623.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_622, arg_625, arg_626, arg_627, arg_628) }
//line :88:1
		break L2 }; case 1: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_119) {
			var root_635 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_639 any; var root_643 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_644 == nil { arg_639 = ifn_645.Invoke_O__O(arg_646) } else { arg_639 = linked_644.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_643, arg_646) }; var arg_640 any = A_arbace_j2g_dyncf_A_const_120; var arg_641 any = A_arbace_j2g_dyncf_A_const_121; var arg_642 any = pn__15; if linked_636 == nil { call__16 = ifn_637.Invoke_O_O_O_O_O__O(arg_638, arg_639, arg_640, arg_641, arg_642) } else { call__16 = linked_636.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_635, arg_638, arg_639, arg_640, arg_641, arg_642) }
//line :88:1
			break L2 }; case 2: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_122) {
				var root_647 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_651 any; var root_655 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_656 == nil { arg_651 = ifn_657.Invoke_O__O(arg_658) } else { arg_651 = linked_656.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_655, arg_658) }; var arg_652 any = A_arbace_j2g_dyncf_A_const_120; var arg_653 any = A_arbace_j2g_dyncf_A_const_121; var arg_654 any = pn__15; if linked_648 == nil { call__16 = ifn_649.Invoke_O_O_O_O_O__O(arg_650, arg_651, arg_652, arg_653, arg_654) } else { call__16 = linked_648.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_647, arg_650, arg_651, arg_652, arg_653, arg_654) }
//line :88:1
				break L2 }; case 3: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_123) {


					var root_659 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_663 any; var root_666 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_667 == nil { arg_663 = ifn_668.Invoke_O__O(arg_669) } else { arg_663 = linked_667.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_666, arg_669) }; var arg_664 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp10 any; var root_670 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp12 any; var root_674 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = t.F_n; if linked_675 == nil { tmp12 = ifn_676.Invoke_O__O(arg_677) } else { tmp12 = linked_675.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_674, arg_677) }; arg_673 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); if linked_671 == nil { tmp10 = ifn_672.Invoke_O__O(arg_673) } else { tmp10 = linked_671.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_670, arg_673) }; arg_664 = tmp9.Invoke_O_O__O(tmp10, A_arbace_j2g_dyncf_A_const_124); var arg_665 any = pn__15; if linked_660 == nil { call__16 = ifn_661.Invoke_O_O_O_O__O(arg_662, arg_663, arg_664, arg_665) } else { call__16 = linked_660.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_659, arg_662, arg_663, arg_664, arg_665) }
//line :88:1
					break L2 }; default:}; call__16 = nil}
//line :82:1
		if jrt.J2g_Truth(call__16) { var root_678 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__6, desc__7)).Ref(); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyncf_A_const_125; var tmp16 any; var root_683 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_685 lang.IFn












			if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any; var tmp17 any; var root_688 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = A_arbace_j2g_dyncf_A_const_126; var arg_692 any = A_arbace_j2g_dyncf_A_const_127; if linked_689 == nil { tmp17 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { tmp17 = linked_689.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }; var tmp18 any = tmp17; var tmp19 any; var root_693 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = A_arbace_j2g_dyncf_A_const_128; var arg_697 any = A_arbace_j2g_dyncf_A_const_139; if linked_694 == nil { tmp19 = ifn_695.Invoke_O_O__O(arg_696, arg_697) } else { tmp19 = linked_694.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_693, arg_696, arg_697) }; arg_686 = lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19); var arg_687 any = A_arbace_j2g_dyncf_A_const_140; if linked_684 == nil { tmp16 = ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { tmp16 = linked_684.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }
//line :82:1
			var tmp20 any = tmp16; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyncf_A_const_131; var tmp23 any = A_arbace_j2g_dyncf_A_const_132; var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_133, t.F_recv, A_arbace_j2g_dyncf_A_const_134)); var tmp25 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_75, r__14) {
				tmp25 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_135, call__16, A_arbace_j2g_dyncf_A_const_141) } else {
					var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyncf_A_const_137; tmp25 = tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_138, call__16)) }
//line :82:1
			arg_681 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp24, tmp25))); var arg_682 any; var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp29 any; var root_698 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = s__292000044__3; if linked_699 == nil { tmp29 = ifn_700.Invoke_O__O(arg_701) } else { tmp29 = linked_699.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_698, arg_701) }; arg_682 = tmp28.Invoke_O__O(tmp29); if linked_679 == nil { return ifn_680.Invoke_O_O__O(arg_681, arg_682) } else { return linked_679.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_678, arg_681, arg_682) } } else { var tmp30 any; var root_702 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = s__292000044__3; if linked_703 == nil { tmp30 = ifn_704.Invoke_O__O(arg_705) } else { tmp30 = linked_703.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_702, arg_705) }; s__292000044__1 = tmp30; continue L1 } } else { var tmp31 any; var root_706 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = s__292000044__3; if linked_707 == nil { tmp31 = ifn_708.Invoke_O__O(arg_709) } else { tmp31 = linked_707.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_706, arg_709) }; s__292000044__1 = tmp31; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :82:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Ctor_O_O_O_I_O(c__recv, c__b__292000046, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_b__292000046 = c__b__292000046; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Invoke_O__O(self any) any { { var i__292000045__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000045__1)); var vec__292000053__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__292000053__3; var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_459 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_461 lang.IFn; _ = ___7
																if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = desc__5; if linked_460 == nil { tmp2 = ifn_461.Invoke_O__O(arg_462) } else { tmp2 = linked_460.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_459, arg_462) }
//line :82:1
	if jrt.J2g_Truth(tmp2) { var impl__8 any; var root_463 any = A_arbace_j2g_dyncf_A_const_112.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_465 lang.IFn

		if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = t.F_n; var arg_467 any = k__6; if linked_464 == nil { impl__8 = ifn_465.Invoke_O_O__O(arg_466, arg_467) } else { impl__8 = linked_464.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_463, arg_466, arg_467) }
//line :82:1
		var base__9 any; var root_468 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_470 lang.IFn


		if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = name__4; var arg_472 any = desc__5; if linked_469 == nil { base__9 = ifn_470.Invoke_O_O__O(arg_471, arg_472) } else { base__9 = linked_469.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_468, arg_471, arg_472) }
//line :82:1
		var vec__292000056__10 any; var root_473 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_475 lang.IFn



		if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = desc__5; if linked_474 == nil { vec__292000056__10 = ifn_475.Invoke_O__O(arg_476) } else { vec__292000056__10 = linked_474.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_473, arg_476) }
//line :82:1
		var ps__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_477 any = A_arbace_j2g_dyncf_A_const_91.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_479 lang.IFn




		if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any; var tmp3 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New(); var tmp4 *jrt.Class; var fncls__487 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class; if fncls__487 == nil { var fncls__487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class = fncls__487d; tmp4 = fncls__487d } else { tmp4 = fncls__487 }; arg_480 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_481 any = ps__11; if linked_478 == nil { pn__13 = ifn_479.Invoke_O_O__O(arg_480, arg_481) } else { pn__13 = linked_478.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_477, arg_480, arg_481) }
//line :82:1
		var call__14 any; var G__292000061__14_ any = A_arbace_j2g_dyncf_A_const_115.Invoke_O__O(impl__8)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000061__14_) >> 4 & 3 { case 0: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_116) {

		var root_489 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_493 any; var root_496 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = A_arbace_j2g_dyncf_A_const_29; var arg_500 any = A_arbace_j2g_dyncf_A_const_117.Invoke_O__O(impl__8); var arg_501 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_497 == nil { arg_493 = ifn_498.Invoke_O_O_O__O(arg_499, arg_500, arg_501) } else { arg_493 = linked_497.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_496, arg_499, arg_500, arg_501) }; var arg_494 any = A_arbace_j2g_dyncf_A_const_118; var arg_495 any = pn__13; if linked_490 == nil { call__14 = ifn_491.Invoke_O_O_O_O__O(arg_492, arg_493, arg_494, arg_495) } else { call__14 = linked_490.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_489, arg_492, arg_493, arg_494, arg_495) }
//line :88:1
		break L2 }; case 1: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_119) {
			var root_502 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_506 any; var root_510 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_511 == nil { arg_506 = ifn_512.Invoke_O__O(arg_513) } else { arg_506 = linked_511.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_510, arg_513) }; var arg_507 any = A_arbace_j2g_dyncf_A_const_120; var arg_508 any = A_arbace_j2g_dyncf_A_const_121; var arg_509 any = pn__13; if linked_503 == nil { call__14 = ifn_504.Invoke_O_O_O_O_O__O(arg_505, arg_506, arg_507, arg_508, arg_509) } else { call__14 = linked_503.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_502, arg_505, arg_506, arg_507, arg_508, arg_509) }
//line :88:1
			break L2 }; case 2: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_122) {
				var root_514 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_518 any; var root_522 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_523 == nil { arg_518 = ifn_524.Invoke_O__O(arg_525) } else { arg_518 = linked_523.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_522, arg_525) }; var arg_519 any = A_arbace_j2g_dyncf_A_const_120; var arg_520 any = A_arbace_j2g_dyncf_A_const_121; var arg_521 any = pn__13; if linked_515 == nil { call__14 = ifn_516.Invoke_O_O_O_O_O__O(arg_517, arg_518, arg_519, arg_520, arg_521) } else { call__14 = linked_515.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_514, arg_517, arg_518, arg_519, arg_520, arg_521) }
//line :88:1
				break L2 }; case 3: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_123) {


					var root_526 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_530 any; var root_533 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_534 == nil { arg_530 = ifn_535.Invoke_O__O(arg_536) } else { arg_530 = linked_534.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_533, arg_536) }; var arg_531 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp6 any; var root_537 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp8 any; var root_541 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = t.F_n; if linked_542 == nil { tmp8 = ifn_543.Invoke_O__O(arg_544) } else { tmp8 = linked_542.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_541, arg_544) }; arg_540 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(); if linked_538 == nil { tmp6 = ifn_539.Invoke_O__O(arg_540) } else { tmp6 = linked_538.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_537, arg_540) }; arg_531 = tmp5.Invoke_O_O__O(tmp6, A_arbace_j2g_dyncf_A_const_124); var arg_532 any = pn__13; if linked_527 == nil { call__14 = ifn_528.Invoke_O_O_O_O__O(arg_529, arg_530, arg_531, arg_532) } else { call__14 = linked_527.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_526, arg_529, arg_530, arg_531, arg_532) }
//line :88:1
					break L2 }; default:}; call__14 = nil}
//line :82:1
		if jrt.J2g_Truth(call__14) { var root_545 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = t.F_b__292000046; var arg_549 any; var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__4, desc__5)).Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_125; var tmp12 any; var root_550 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_552 lang.IFn












			if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any; var tmp13 any; var root_555 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = A_arbace_j2g_dyncf_A_const_126; var arg_559 any = A_arbace_j2g_dyncf_A_const_127; if linked_556 == nil { tmp13 = ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { tmp13 = linked_556.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) }; var tmp14 any = tmp13; var tmp15 any; var root_560 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = A_arbace_j2g_dyncf_A_const_128; var arg_564 any = A_arbace_j2g_dyncf_A_const_129; if linked_561 == nil { tmp15 = ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { tmp15 = linked_561.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) }; arg_553 = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); var arg_554 any = A_arbace_j2g_dyncf_A_const_130; if linked_551 == nil { tmp12 = ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { tmp12 = linked_551.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_550, arg_553, arg_554) }
//line :82:1
			var tmp16 any = tmp12; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyncf_A_const_131; var tmp19 any = A_arbace_j2g_dyncf_A_const_132; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_133, t.F_recv, A_arbace_j2g_dyncf_A_const_134)); var tmp21 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_75, r__12) {
				tmp21 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_135, call__14, A_arbace_j2g_dyncf_A_const_136) } else {
					var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_137; tmp21 = tmp22.Invoke_O_O__O(tmp23, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_138, call__14)) }
//line :82:1
			arg_549 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Invoke_O_O_O__O(tmp11, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp20, tmp21))); if linked_546 == nil { ifn_547.Invoke_O_O__O(arg_548, arg_549) } else { linked_546.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_545, arg_548, arg_549) }; i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_482 any = A_arbace_j2g_dyncf_A_const_92.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = p__2; var arg_486 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_113, A_arbace_j2g_dyncf_A_const_114, i__1); if linked_483 == nil { return ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { return linked_483.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_482, arg_485, arg_486) } }
//line :87:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_615 any = A_arbace_j2g_dyncf_A_const_92.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = p__2; var arg_619 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_113, A_arbace_j2g_dyncf_A_const_114, i__1); if linked_616 == nil { return ifn_617.Invoke_O_O__O(arg_618, arg_619) } else { return linked_616.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_615, arg_618, arg_619) } }













func A_arbace_j2g_dyncf_subs_forms_A_New() *A_arbace_j2g_dyncf_subs_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Ctor() {}
//line :101:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Invoke_O_O__O(self, T__0_ any) any { var cs__2 any; var root_721 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_723 lang.IFn; if


	linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = T__0_; if linked_722 == nil { cs__2 = ifn_723.Invoke_O__O(arg_724) } else { cs__2 = linked_722.(*aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_721, arg_724) }; var root_725 any =
	A_arbace_j2g_dyncf_A_const_145.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_147.GetRawRoot__O(), cs__2); var arg_729 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_148; var tmp3 any = A_arbace_j2g_dyncf_A_const_149; var tmp4 any; var root_845 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_847 lang.IFn; if




	linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = A_arbace_j2g_dyncf_A_const_157; var arg_849 any = A_arbace_j2g_dyncf_A_const_158; if linked_846 == nil { tmp4 = ifn_847.Invoke_O_O__O(arg_848, arg_849) } else { tmp4 = linked_846.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_845, arg_848, arg_849) }; var tmp5 any = /*line :105:1*/lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 any = A_arbace_j2g_dyncf_A_const_150; var tmp7 any = A_arbace_j2g_dyncf_A_const_151; var tmp8 any; var root_735 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_737 lang.IFn; if







	linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_739 any = A_arbace_j2g_dyncf_A_const_152; var arg_740 any = A_arbace_j2g_dyncf_A_const_153; var arg_741 any; var iter__1927001039__auto____3 any; var tmp9 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_New(); var tmp10 *jrt.Class; var fncls__844 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class; if
	fncls__844 == nil { var fncls__844d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class = fncls__844d; tmp10 = fncls__844d } else { tmp10 = fncls__844 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_741 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(cs__2); if /*line :113:1*/ linked_736 == nil { tmp8 = ifn_737.Invoke_O_O_O_O__O(arg_738, arg_739, arg_740, arg_741) } else { tmp8 = linked_736.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_735, arg_738, arg_739, arg_740, arg_741) }; arg_729 = /*line :105:1*/lang.Tuple_Create_O__IPersistentVector(tmp1.Invoke_O_O_O_O_O_O_O_O__O(tmp2, tmp3, Lit_78, tmp5, tmp6, tmp7, tmp8, A_arbace_j2g_dyncf_A_const_156)); if linked_726 == nil { return ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { return linked_726.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) } }








func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_New() *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A) Ctor() {}
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A) Invoke_O_O__O(self, s__292000079__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_New_O_O(self, s__292000079__1); var tmp2 *jrt.Class; var fncls__843 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class; if fncls__843 == nil { var fncls__843d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class = fncls__843d; tmp2 = fncls__843d } else { tmp2 = fncls__843 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A) Ctor_O_O(c__iter__292000078, c__s__292000079 any) { t.F_iter__292000078 = c__iter__292000078; t.F_s__292000079 = c__s__292000079 }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A) Invoke_O__O(self any) any { { var s__292000079__1 any; var t_ any = t.F_s__292000079; t.F_s__292000079 = nil; s__292000079__1 = t_; for { var temp__1927000414__auto____2 any; var root_742 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = s__292000079__1; if linked_743 == nil { temp__1927000414__auto____2 = ifn_744.Invoke_O__O(arg_745) } else { temp__1927000414__auto____2 = linked_743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_742, arg_745) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000079__3 any = temp__1927000414__auto____2; var tmp1 any; var root_746 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = s__292000079__3; if linked_747 == nil { tmp1 = ifn_748.Invoke_O__O(arg_749) } else { tmp1 = linked_747.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_746, arg_749) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_750 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = s__292000079__3; if linked_751 == nil { c__1927001037__auto____4 = ifn_752.Invoke_O__O(arg_753) } else { c__1927001037__auto____4 = linked_751.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_750, arg_753) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000081__6 any; var root_754 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_755 == nil { b__292000081__6 = ifn_756.Invoke_O__O(arg_757) } else { b__292000081__6 = linked_755.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_754, arg_757) }; var tmp2 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_New_O_I_O(b__292000081__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__785 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class; if fncls__785 == nil { var fncls__785d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class = fncls__785d; tmp3 = fncls__785d } else { tmp3 = fncls__785 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_786 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any; var root_791 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = b__292000081__6; if linked_792 == nil { arg_789 = ifn_793.Invoke_O__O(arg_794) } else { arg_789 = linked_792.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_791, arg_794) }; var arg_790 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000078); var tmp5 any; var root_795 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = s__292000079__3; if linked_796 == nil { tmp5 = ifn_797.Invoke_O__O(arg_798) } else { tmp5 = linked_796.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_795, arg_798) }; arg_790 = tmp4.Invoke_O__O(tmp5); if linked_787 == nil { return ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { return linked_787.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) } } else { var root_799 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any; var root_804 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = b__292000081__6; if linked_805 == nil { arg_802 = ifn_806.Invoke_O__O(arg_807) } else { arg_802 = linked_805.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_804, arg_807) }; var arg_803 any; if linked_800 == nil { return ifn_801.Invoke_O_O__O(arg_802, arg_803) } else { return linked_800.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_799, arg_802, arg_803) } } } else { var p__4 any; var root_808 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = s__292000079__3; if linked_809 == nil { p__4 = ifn_810.Invoke_O__O(arg_811) } else { p__4 = linked_809.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_808, arg_811) }; var g__5 any; var root_812 any = A_arbace_j2g_dyncf_A_const_34.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = p__4; if linked_813 == nil { g__5 = ifn_814.Invoke_O__O(arg_815) } else { g__5 = linked_813.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_812, arg_815) }; var root_816 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_154; var tmp8 any; var root_821 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_823 lang.IFn
														if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = A_arbace_j2g_dyncf_A_const_29; var arg_825 any = p__4; var arg_826 any = Lit_82; if linked_822 == nil { tmp8 = ifn_823.Invoke_O_O_O__O(arg_824, arg_825, arg_826) } else { tmp8 = linked_822.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_821, arg_824, arg_825, arg_826) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_155; var tmp12 any; var root_827 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_829 lang.IFn
														if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_828 == nil { tmp12 = ifn_829.Invoke_O__O(arg_830) } else { tmp12 = linked_828.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_827, arg_830) }
//line :115:1
	var tmp13 any = tmp12; var tmp14 any; var root_831 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_833 lang.IFn
	if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_832 == nil { tmp14 = ifn_833.Invoke_O__O(arg_834) } else { tmp14 = linked_832.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_831, arg_834) }
//line :115:1
	var tmp15 any = tmp14; var tmp16 any; var root_835 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_837 lang.IFn

	if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_836 == nil { tmp16 = ifn_837.Invoke_O__O(arg_838) } else { tmp16 = linked_836.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_835, arg_838) }
//line :115:1
	arg_819 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp13, tmp15, tmp16))
//line :114:1
	var arg_820 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__292000078); var tmp18 any; var root_839 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any = s__292000079__3; if linked_840 == nil { tmp18 = ifn_841.Invoke_O__O(arg_842) } else { tmp18 = linked_840.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_839, arg_842) }; arg_820 = tmp17.Invoke_O__O(tmp18); if linked_817 == nil { return ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { return linked_817.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A) Ctor_O_I_O(c__b__292000081 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000081 = c__b__292000081; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A) Invoke_O__O(self any) any { { var i__292000080__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000080__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000080__1)); var g__3 any; var root_758 any = A_arbace_j2g_dyncf_A_const_34.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = p__2; if linked_759 == nil { g__3 = ifn_760.Invoke_O__O(arg_761) } else { g__3 = linked_759.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_758, arg_761) }; var root_762 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = t.F_b__292000081; var arg_766 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_154; var tmp4 any; var root_767 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_769 lang.IFn
																if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = A_arbace_j2g_dyncf_A_const_29; var arg_771 any = p__2; var arg_772 any = Lit_82; if linked_768 == nil { tmp4 = ifn_769.Invoke_O_O_O__O(arg_770, arg_771, arg_772) } else { tmp4 = linked_768.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_767, arg_770, arg_771, arg_772) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_155; var tmp8 any; var root_773 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_775 lang.IFn
																if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_774 == nil { tmp8 = ifn_775.Invoke_O__O(arg_776) } else { tmp8 = linked_774.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_773, arg_776) }
//line :115:1
	var tmp9 any = tmp8; var tmp10 any; var root_777 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_779 lang.IFn
	if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_778 == nil { tmp10 = ifn_779.Invoke_O__O(arg_780) } else { tmp10 = linked_778.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_777, arg_780) }
//line :115:1
	var tmp11 any = tmp10; var tmp12 any; var root_781 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_783 lang.IFn

	if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_782 == nil { tmp12 = ifn_783.Invoke_O__O(arg_784) } else { tmp12 = linked_782.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_781, arg_784) }
//line :115:1
	arg_766 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp9, tmp11, tmp12))
//line :114:1
	if linked_763 == nil { ifn_764.Invoke_O_O__O(arg_765, arg_766) } else { linked_763.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_762, arg_765, arg_766) }; i__292000080__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000080__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_forms_A_New() *A_arbace_j2g_dyncf_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_forms_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_j2g_dyncf_forms_A) Ctor() {}
//line :120:1
func (t *A_arbace_j2g_dyncf_forms_A) Invoke_O_O__O(self, T__0_ any) any {


	var root_850 any = A_arbace_j2g_dyncf_A_const_145.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any; var root_855 any = A_arbace_j2g_dyncf_A_const_159.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, A_arbace_j2g_dyncf_subs_forms_A_fn_class); var ifn_857 lang.IFn
	if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = T__0_; if linked_856 == nil { arg_853 = ifn_857.Invoke_O__O(arg_858) } else { arg_853 = linked_856.(*A_arbace_j2g_dyncf_subs_forms_A).Invoke_O_O__O(root_855, arg_858) }
//line :123:1
	var arg_854 any; var tmp1 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_164, Lit_1); var tmp2 any = A_arbace_j2g_dyncf_A_const_160; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyncf_A_const_165; var tmp5 any; var root_859 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_861 lang.IFn














	if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = Lit_2; var arg_863 any = Lit_3; if linked_860 == nil { tmp5 = ifn_861.Invoke_O_O__O(arg_862, arg_863) } else { tmp5 = linked_860.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_859, arg_862, arg_863) }
//line :123:1
	var tmp6 any = tmp5; var tmp7 any; var root_864 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_866 lang.IFn















	if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any; var tmp8 any; var root_869 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = A_arbace_j2g_dyncf_A_const_167; var arg_873 any = A_arbace_j2g_dyncf_A_const_168; if linked_870 == nil { tmp8 = ifn_871.Invoke_O_O__O(arg_872, arg_873) } else { tmp8 = linked_870.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_869, arg_872, arg_873) }; var tmp9 any = tmp8; var tmp10 any; var root_874 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = A_arbace_j2g_dyncf_A_const_169; var arg_878 any = A_arbace_j2g_dyncf_A_const_170; if linked_875 == nil { tmp10 = ifn_876.Invoke_O_O__O(arg_877, arg_878) } else { tmp10 = linked_875.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_874, arg_877, arg_878) }; var tmp11 any = tmp10; var tmp12 any; var root_879 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = A_arbace_j2g_dyncf_A_const_171; var arg_883 any = A_arbace_j2g_dyncf_A_const_172; if linked_880 == nil { tmp12 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { tmp12 = linked_880.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) }; var tmp13 any = tmp12; var tmp14 any; var root_884 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_886 lang.IFn
	if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = A_arbace_j2g_dyncf_A_const_173; var arg_888 any = A_arbace_j2g_dyncf_A_const_174; if linked_885 == nil { tmp14 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { tmp14 = linked_885.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) }
//line :139:1
	var tmp15 any = tmp14; var tmp16 any; var root_889 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_891 lang.IFn
	if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = A_arbace_j2g_dyncf_A_const_175; var arg_893 any = A_arbace_j2g_dyncf_A_const_176; if linked_890 == nil { tmp16 = ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { tmp16 = linked_890.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) }
//line :139:1
	var tmp17 any = tmp16; var tmp18 any; var root_894 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_896 lang.IFn
	if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = A_arbace_j2g_dyncf_A_const_177; var arg_898 any = A_arbace_j2g_dyncf_A_const_178; if linked_895 == nil { tmp18 = ifn_896.Invoke_O_O__O(arg_897, arg_898) } else { tmp18 = linked_895.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_894, arg_897, arg_898) }
//line :139:1
	arg_867 = lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp9, tmp11, tmp13, tmp15, tmp17, tmp18); var arg_868 any = A_arbace_j2g_dyncf_A_const_179; if linked_865 == nil { tmp7 = ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { tmp7 = linked_865.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) }
//line :123:1
	var tmp19 any = tmp3.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, A_arbace_j2g_dyncf_A_const_180); var tmp20 any = A_arbace_j2g_dyncf_A_const_161; var tmp21 any = A_arbace_j2g_dyncf_A_const_162; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_181; var tmp24 any; var root_899 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_901 lang.IFn















































































	if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = Lit_4; var arg_903 any = Lit_5; if linked_900 == nil { tmp24 = ifn_901.Invoke_O_O__O(arg_902, arg_903) } else { tmp24 = linked_900.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_899, arg_902, arg_903) }
//line :123:1
	var tmp25 any = tmp24; var tmp26 any; var root_904 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_906 lang.IFn
















































































	if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any; var tmp27 any; var root_909 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = A_arbace_j2g_dyncf_A_const_182; var arg_913 any = A_arbace_j2g_dyncf_A_const_183; if linked_910 == nil { tmp27 = ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { tmp27 = linked_910.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) }; var tmp28 any = tmp27; var tmp29 any; var root_914 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = A_arbace_j2g_dyncf_A_const_184; var arg_918 any = A_arbace_j2g_dyncf_A_const_185; if linked_915 == nil { tmp29 = ifn_916.Invoke_O_O__O(arg_917, arg_918) } else { tmp29 = linked_915.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_914, arg_917, arg_918) }; arg_907 = lang.Tuple_Create_O_O__IPersistentVector(tmp28, tmp29); var arg_908 any = A_arbace_j2g_dyncf_A_const_186; if linked_905 == nil { tmp26 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { tmp26 = linked_905.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }
//line :123:1
	var tmp30 any = tmp22.Invoke_O_O_O_O__O(tmp23, tmp25, tmp26, A_arbace_j2g_dyncf_A_const_187); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_dyncf_A_const_188; var tmp33 any; var root_919 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_921 lang.IFn























































































	if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = Lit_6; var arg_923 any = Lit_7; if linked_920 == nil { tmp33 = ifn_921.Invoke_O_O__O(arg_922, arg_923) } else { tmp33 = linked_920.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_919, arg_922, arg_923) }
//line :123:1
	var tmp34 any = tmp33; var tmp35 any; var root_924 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_926 lang.IFn
























































































	if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any; var tmp36 any; var root_929 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = A_arbace_j2g_dyncf_A_const_189; var arg_933 any = A_arbace_j2g_dyncf_A_const_190; if linked_930 == nil { tmp36 = ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { tmp36 = linked_930.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_929, arg_932, arg_933) }; arg_927 = lang.Tuple_Create_O__IPersistentVector(tmp36); var arg_928 any = A_arbace_j2g_dyncf_A_const_191; if linked_925 == nil { tmp35 = ifn_926.Invoke_O_O__O(arg_927, arg_928) } else { tmp35 = linked_925.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_924, arg_927, arg_928) }
//line :123:1
	var tmp37 any = tmp31.Invoke_O_O_O_O__O(tmp32, tmp34, tmp35, A_arbace_j2g_dyncf_A_const_192); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp39 any = A_arbace_j2g_dyncf_A_const_193; var tmp40 any; var root_934 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_936 lang.IFn



























































































	if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = Lit_8; var arg_938 any = Lit_9; if linked_935 == nil { tmp40 = ifn_936.Invoke_O_O__O(arg_937, arg_938) } else { tmp40 = linked_935.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_934, arg_937, arg_938) }
//line :123:1
	var tmp41 any = tmp40; var tmp42 any; var root_939 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_941 lang.IFn




























































































	if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = A_arbace_j2g_dyncf_A_const_195; var arg_943 any = A_arbace_j2g_dyncf_A_const_196; if linked_940 == nil { tmp42 = ifn_941.Invoke_O_O__O(arg_942, arg_943) } else { tmp42 = linked_940.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_939, arg_942, arg_943) }
//line :123:1
	var tmp43 any = tmp42; var tmp44 any; var root_944 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_946 lang.IFn




























































































	if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = A_arbace_j2g_dyncf_A_const_197; var arg_948 any = A_arbace_j2g_dyncf_A_const_198; if linked_945 == nil { tmp44 = ifn_946.Invoke_O_O__O(arg_947, arg_948) } else { tmp44 = linked_945.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_944, arg_947, arg_948) }
//line :123:1
	var tmp45 any = tmp44; var tmp46 any; var root_949 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_951 lang.IFn




























































































	if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = A_arbace_j2g_dyncf_A_const_199; var arg_953 any = A_arbace_j2g_dyncf_A_const_200; if linked_950 == nil { tmp46 = ifn_951.Invoke_O_O__O(arg_952, arg_953) } else { tmp46 = linked_950.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_949, arg_952, arg_953) }
//line :123:1
	var tmp47 any = tmp46; var tmp48 any; var root_954 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_956 lang.IFn




























































































	if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = A_arbace_j2g_dyncf_A_const_201; var arg_958 any = A_arbace_j2g_dyncf_A_const_202; if linked_955 == nil { tmp48 = ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { tmp48 = linked_955.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_954, arg_957, arg_958) }
//line :123:1
	var tmp49 any = tmp38.Invoke_O_O_O_O__O(tmp39, tmp41, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp43, tmp45, tmp47, tmp48), A_arbace_j2g_dyncf_A_const_194); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp51 any = A_arbace_j2g_dyncf_A_const_203; var tmp52 any; var root_959 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_961 lang.IFn



































































































	if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = Lit_10; var arg_963 any = Lit_11; if linked_960 == nil { tmp52 = ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { tmp52 = linked_960.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) }
//line :123:1
	var tmp53 any = tmp52; var tmp54 any; var root_964 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_966 lang.IFn




































































































	if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any; var tmp55 any; var root_969 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = A_arbace_j2g_dyncf_A_const_204; var arg_973 any = A_arbace_j2g_dyncf_A_const_205; if linked_970 == nil { tmp55 = ifn_971.Invoke_O_O__O(arg_972, arg_973) } else { tmp55 = linked_970.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_969, arg_972, arg_973) }; var tmp56 any = tmp55; var tmp57 any; var root_974 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = A_arbace_j2g_dyncf_A_const_206; var arg_978 any = A_arbace_j2g_dyncf_A_const_207; if linked_975 == nil { tmp57 = ifn_976.Invoke_O_O__O(arg_977, arg_978) } else { tmp57 = linked_975.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_974, arg_977, arg_978) }; var tmp58 any = tmp57; var tmp59 any; var root_979 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = A_arbace_j2g_dyncf_A_const_208; var arg_983 any = A_arbace_j2g_dyncf_A_const_209; if linked_980 == nil { tmp59 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { tmp59 = linked_980.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }; var tmp60 any = tmp59; var tmp61 any; var root_984 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = A_arbace_j2g_dyncf_A_const_210; var arg_988 any = A_arbace_j2g_dyncf_A_const_211; if linked_985 == nil { tmp61 = ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { tmp61 = linked_985.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }; arg_967 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp56, tmp58, tmp60, tmp61); var arg_968 any = A_arbace_j2g_dyncf_A_const_212; if linked_965 == nil { tmp54 = ifn_966.Invoke_O_O__O(arg_967, arg_968) } else { tmp54 = linked_965.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_964, arg_967, arg_968) }
//line :123:1
	var tmp62 any = tmp50.Invoke_O_O_O_O__O(tmp51, tmp53, tmp54, A_arbace_j2g_dyncf_A_const_213); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyncf_A_const_214; var tmp65 any; var root_989 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_991 lang.IFn











































































































	if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = Lit_12; var arg_993 any = Lit_13; if linked_990 == nil { tmp65 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { tmp65 = linked_990.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }
//line :123:1
	var tmp66 any = tmp65; var tmp67 any; var root_994 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_996 lang.IFn












































































































	if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = A_arbace_j2g_dyncf_A_const_216; var arg_998 any = A_arbace_j2g_dyncf_A_const_217; if linked_995 == nil { tmp67 = ifn_996.Invoke_O_O__O(arg_997, arg_998) } else { tmp67 = linked_995.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_994, arg_997, arg_998) }
//line :123:1
	var tmp68 any = tmp67; var tmp69 any; var root_999 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1001 lang.IFn












































































































	if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = A_arbace_j2g_dyncf_A_const_218; var arg_1003 any = A_arbace_j2g_dyncf_A_const_219; if linked_1000 == nil { tmp69 = ifn_1001.Invoke_O_O__O(arg_1002, arg_1003) } else { tmp69 = linked_1000.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_999, arg_1002, arg_1003) }
//line :123:1
	var tmp70 any = tmp69; var tmp71 any; var root_1004 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1006 lang.IFn












































































































	if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = A_arbace_j2g_dyncf_A_const_220; var arg_1008 any = A_arbace_j2g_dyncf_A_const_221; if linked_1005 == nil { tmp71 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { tmp71 = linked_1005.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }
//line :123:1
	var tmp72 any = tmp63.Invoke_O_O_O_O__O(tmp64, tmp66, lang.Tuple_Create_O_O_O__IPersistentVector(tmp68, tmp70, tmp71), A_arbace_j2g_dyncf_A_const_215); var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_dyncf_A_const_222; var tmp75 any; var root_1009 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1011 lang.IFn



















































































































	if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = Lit_14; var arg_1013 any = Lit_15; if linked_1010 == nil { tmp75 = ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { tmp75 = linked_1010.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) }
//line :123:1
	var tmp76 any = tmp75; var tmp77 any; var root_1014 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1016 lang.IFn




















































































































	if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = A_arbace_j2g_dyncf_A_const_224; var arg_1018 any = A_arbace_j2g_dyncf_A_const_225; if linked_1015 == nil { tmp77 = ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { tmp77 = linked_1015.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) }
//line :123:1
	var tmp78 any = tmp73.Invoke_O_O_O_O__O(tmp74, tmp76, lang.Tuple_Create_O__IPersistentVector(tmp77), A_arbace_j2g_dyncf_A_const_223); var tmp79 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp80 any = A_arbace_j2g_dyncf_A_const_226; var tmp81 any; var root_1019 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1021 lang.IFn


























































































































	if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = Lit_16; var arg_1023 any = Lit_17; if linked_1020 == nil { tmp81 = ifn_1021.Invoke_O_O__O(arg_1022, arg_1023) } else { tmp81 = linked_1020.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1019, arg_1022, arg_1023) }
//line :123:1
	var tmp82 any = tmp81; var tmp83 any; var root_1024 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1026 lang.IFn



























































































































	if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = A_arbace_j2g_dyncf_A_const_228; var arg_1028 any = A_arbace_j2g_dyncf_A_const_229; if linked_1025 == nil { tmp83 = ifn_1026.Invoke_O_O__O(arg_1027, arg_1028) } else { tmp83 = linked_1025.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1024, arg_1027, arg_1028) }
//line :123:1
	var tmp84 any = tmp83; var tmp85 any; var root_1029 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1031 lang.IFn



























































































































	if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = A_arbace_j2g_dyncf_A_const_230; var arg_1033 any = A_arbace_j2g_dyncf_A_const_231; if linked_1030 == nil { tmp85 = ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { tmp85 = linked_1030.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) }
//line :123:1
	var tmp86 any = tmp79.Invoke_O_O_O_O__O(tmp80, tmp82, lang.Tuple_Create_O_O__IPersistentVector(tmp84, tmp85), A_arbace_j2g_dyncf_A_const_227); var tmp87 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp88 any = A_arbace_j2g_dyncf_A_const_232; var tmp89 any; var root_1034 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1036 lang.IFn































































































































	if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = Lit_18; var arg_1038 any = Lit_19; if linked_1035 == nil { tmp89 = ifn_1036.Invoke_O_O__O(arg_1037, arg_1038) } else { tmp89 = linked_1035.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1034, arg_1037, arg_1038) }
//line :123:1
	var tmp90 any = tmp89; var tmp91 any; var root_1039 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1041 lang.IFn
































































































































	if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any; var tmp92 any; var root_1044 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = A_arbace_j2g_dyncf_A_const_233; var arg_1048 any = A_arbace_j2g_dyncf_A_const_234; if linked_1045 == nil { tmp92 = ifn_1046.Invoke_O_O__O(arg_1047, arg_1048) } else { tmp92 = linked_1045.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1044, arg_1047, arg_1048) }; arg_1042 = lang.Tuple_Create_O__IPersistentVector(tmp92); var arg_1043 any = A_arbace_j2g_dyncf_A_const_235; if linked_1040 == nil { tmp91 = ifn_1041.Invoke_O_O__O(arg_1042, arg_1043) } else { tmp91 = linked_1040.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1039, arg_1042, arg_1043) }
//line :123:1
	var tmp93 any = tmp87.Invoke_O_O_O_O__O(tmp88, tmp90, tmp91, A_arbace_j2g_dyncf_A_const_236); var tmp94 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp95 any = A_arbace_j2g_dyncf_A_const_237; var tmp96 any; var root_1049 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1051 lang.IFn




































































































































	if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = Lit_20; var arg_1053 any = Lit_21; if linked_1050 == nil { tmp96 = ifn_1051.Invoke_O_O__O(arg_1052, arg_1053) } else { tmp96 = linked_1050.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1049, arg_1052, arg_1053) }
//line :123:1
	var tmp97 any = tmp96; var tmp98 any; var root_1054 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1056 lang.IFn





































































































































	if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = A_arbace_j2g_dyncf_A_const_239; var arg_1058 any = A_arbace_j2g_dyncf_A_const_240; if linked_1055 == nil { tmp98 = ifn_1056.Invoke_O_O__O(arg_1057, arg_1058) } else { tmp98 = linked_1055.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1054, arg_1057, arg_1058) }
//line :123:1
	var tmp99 any = tmp98; var tmp100 any; var root_1059 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1061 lang.IFn





































































































































	if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = A_arbace_j2g_dyncf_A_const_241; var arg_1063 any = A_arbace_j2g_dyncf_A_const_242; if linked_1060 == nil { tmp100 = ifn_1061.Invoke_O_O__O(arg_1062, arg_1063) } else { tmp100 = linked_1060.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1059, arg_1062, arg_1063) }
//line :123:1
	var tmp101 any = tmp100; var tmp102 any; var root_1064 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1066 lang.IFn





































































































































	if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = A_arbace_j2g_dyncf_A_const_243; var arg_1068 any = A_arbace_j2g_dyncf_A_const_244; if linked_1065 == nil { tmp102 = ifn_1066.Invoke_O_O__O(arg_1067, arg_1068) } else { tmp102 = linked_1065.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1064, arg_1067, arg_1068) }
//line :123:1
	var tmp103 any = tmp102; var tmp104 any; var root_1069 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1071 lang.IFn





































































































































	if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = A_arbace_j2g_dyncf_A_const_245; var arg_1073 any = A_arbace_j2g_dyncf_A_const_246; if linked_1070 == nil { tmp104 = ifn_1071.Invoke_O_O__O(arg_1072, arg_1073) } else { tmp104 = linked_1070.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1069, arg_1072, arg_1073) }
//line :123:1
	var tmp105 any = tmp104; var tmp106 any; var root_1074 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1076 lang.IFn






































































































































	if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = A_arbace_j2g_dyncf_A_const_247; var arg_1078 any = A_arbace_j2g_dyncf_A_const_248; if linked_1075 == nil { tmp106 = ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { tmp106 = linked_1075.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) }
//line :123:1
	var tmp107 any = tmp106; var tmp108 any; var root_1079 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1081 lang.IFn






































































































































	if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = A_arbace_j2g_dyncf_A_const_249; var arg_1083 any = A_arbace_j2g_dyncf_A_const_250; if linked_1080 == nil { tmp108 = ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { tmp108 = linked_1080.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) }
//line :123:1
	var tmp109 any = tmp94.Invoke_O_O_O_O__O(tmp95, tmp97, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp99, tmp101, tmp103, tmp105, tmp107, tmp108), A_arbace_j2g_dyncf_A_const_238); var tmp110 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp111 any = A_arbace_j2g_dyncf_A_const_251; var tmp112 any; var root_1084 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1086 lang.IFn






































































































































































	if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = Lit_22; var arg_1088 any = Lit_23; if linked_1085 == nil { tmp112 = ifn_1086.Invoke_O_O__O(arg_1087, arg_1088) } else { tmp112 = linked_1085.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1084, arg_1087, arg_1088) }
//line :123:1
	var tmp113 any = tmp112; var tmp114 any; var root_1089 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1091 lang.IFn







































































































































































	if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = A_arbace_j2g_dyncf_A_const_253; var arg_1093 any = A_arbace_j2g_dyncf_A_const_254; if linked_1090 == nil { tmp114 = ifn_1091.Invoke_O_O__O(arg_1092, arg_1093) } else { tmp114 = linked_1090.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1089, arg_1092, arg_1093) }
//line :123:1
	var tmp115 any = tmp114; var tmp116 any; var root_1094 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1096 lang.IFn







































































































































































	if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = A_arbace_j2g_dyncf_A_const_255; var arg_1098 any = A_arbace_j2g_dyncf_A_const_256; if linked_1095 == nil { tmp116 = ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { tmp116 = linked_1095.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) }
//line :123:1
	var tmp117 any = tmp116; var tmp118 any; var root_1099 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1101 lang.IFn







































































































































































	if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = A_arbace_j2g_dyncf_A_const_257; var arg_1103 any = A_arbace_j2g_dyncf_A_const_258; if linked_1100 == nil { tmp118 = ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { tmp118 = linked_1100.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103) }
//line :123:1
	var tmp119 any = tmp118; var tmp120 any; var root_1104 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1106 lang.IFn







































































































































































	if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = A_arbace_j2g_dyncf_A_const_259; var arg_1108 any = A_arbace_j2g_dyncf_A_const_260; if linked_1105 == nil { tmp120 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { tmp120 = linked_1105.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) }
//line :123:1
	var tmp121 any = tmp110.Invoke_O_O_O_O__O(tmp111, tmp113, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp115, tmp117, tmp119, tmp120), A_arbace_j2g_dyncf_A_const_252); var tmp122 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp123 any = A_arbace_j2g_dyncf_A_const_261; var tmp124 any; var root_1109 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1111 lang.IFn













































































































































































	if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = Lit_24; var arg_1113 any = Lit_25; if linked_1110 == nil { tmp124 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { tmp124 = linked_1110.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }
//line :123:1
	var tmp125 any = tmp124; var tmp126 any; var root_1114 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1116 lang.IFn














































































































































































	if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = A_arbace_j2g_dyncf_A_const_263; var arg_1118 any = A_arbace_j2g_dyncf_A_const_264; if linked_1115 == nil { tmp126 = ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { tmp126 = linked_1115.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) }
//line :123:1
	var tmp127 any = tmp126; var tmp128 any; var root_1119 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1121 lang.IFn














































































































































































	if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = A_arbace_j2g_dyncf_A_const_265; var arg_1123 any = A_arbace_j2g_dyncf_A_const_266; if linked_1120 == nil { tmp128 = ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { tmp128 = linked_1120.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) }
//line :123:1
	var tmp129 any = tmp128; var tmp130 any; var root_1124 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1126 lang.IFn














































































































































































	if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = A_arbace_j2g_dyncf_A_const_267; var arg_1128 any = A_arbace_j2g_dyncf_A_const_268; if linked_1125 == nil { tmp130 = ifn_1126.Invoke_O_O__O(arg_1127, arg_1128) } else { tmp130 = linked_1125.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1124, arg_1127, arg_1128) }
//line :123:1
	var tmp131 any = tmp130; var tmp132 any; var root_1129 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1131 lang.IFn














































































































































































	if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = A_arbace_j2g_dyncf_A_const_269; var arg_1133 any = A_arbace_j2g_dyncf_A_const_270; if linked_1130 == nil { tmp132 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { tmp132 = linked_1130.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }
//line :123:1
	var tmp133 any = tmp132; var tmp134 any; var root_1134 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1136 lang.IFn














































































































































































	if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = A_arbace_j2g_dyncf_A_const_271; var arg_1138 any = A_arbace_j2g_dyncf_A_const_272; if linked_1135 == nil { tmp134 = ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { tmp134 = linked_1135.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }
//line :123:1
	var tmp135 any = tmp122.Invoke_O_O_O_O__O(tmp123, tmp125, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp127, tmp129, tmp131, tmp133, tmp134), A_arbace_j2g_dyncf_A_const_262); var tmp136 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp137 any = A_arbace_j2g_dyncf_A_const_273; var tmp138 any; var root_1139 any = A_arbace_j2g_dyncf_A_const_166.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1141 lang.IFn






















































































































































































	if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = Lit_26; var arg_1143 any = Lit_27; if linked_1140 == nil { tmp138 = ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { tmp138 = linked_1140.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) }
//line :123:1
	var tmp139 any = tmp138; var tmp140 any; var root_1144 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1146 lang.IFn























































































































































































	if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = A_arbace_j2g_dyncf_A_const_274; var arg_1148 any = A_arbace_j2g_dyncf_A_const_275; if linked_1145 == nil { tmp140 = ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { tmp140 = linked_1145.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) }
//line :123:1
	var tmp141 any = tmp140; var tmp142 any; var root_1149 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1151 lang.IFn























































































































































































	if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = A_arbace_j2g_dyncf_A_const_276; var arg_1153 any = A_arbace_j2g_dyncf_A_const_277; if linked_1150 == nil { tmp142 = ifn_1151.Invoke_O_O__O(arg_1152, arg_1153) } else { tmp142 = linked_1150.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1149, arg_1152, arg_1153) }
//line :123:1
	var tmp143 any = tmp142; var tmp144 any; var root_1154 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1156 lang.IFn























































































































































































	if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = A_arbace_j2g_dyncf_A_const_278; var arg_1158 any = A_arbace_j2g_dyncf_A_const_279; if linked_1155 == nil { tmp144 = ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { tmp144 = linked_1155.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) }
//line :123:1
	var tmp145 any = tmp144; var tmp146 any; var root_1159 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1161 lang.IFn























































































































































































	if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = A_arbace_j2g_dyncf_A_const_280; var arg_1163 any = A_arbace_j2g_dyncf_A_const_281; if linked_1160 == nil { tmp146 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { tmp146 = linked_1160.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }
//line :123:1
	var tmp147 any = tmp146; var tmp148 any; var root_1164 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1166 lang.IFn
























































































































































































	if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = A_arbace_j2g_dyncf_A_const_282; var arg_1168 any = A_arbace_j2g_dyncf_A_const_283; if linked_1165 == nil { tmp148 = ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { tmp148 = linked_1165.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) }
//line :123:1
	var tmp149 any = tmp148; var tmp150 any; var root_1169 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1171 lang.IFn
























































































































































































	if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = A_arbace_j2g_dyncf_A_const_284; var arg_1173 any = A_arbace_j2g_dyncf_A_const_285; if linked_1170 == nil { tmp150 = ifn_1171.Invoke_O_O__O(arg_1172, arg_1173) } else { tmp150 = linked_1170.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1169, arg_1172, arg_1173) }
//line :123:1
	var tmp151 any = tmp150; var tmp152 any; var root_1174 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1176 lang.IFn
























































































































































































	if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = A_arbace_j2g_dyncf_A_const_286; var arg_1178 any = A_arbace_j2g_dyncf_A_const_287; if linked_1175 == nil { tmp152 = ifn_1176.Invoke_O_O__O(arg_1177, arg_1178) } else { tmp152 = linked_1175.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1174, arg_1177, arg_1178) }
//line :123:1
	arg_854 = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp19, tmp20, tmp21, tmp30, tmp37, tmp49, tmp62, tmp72, tmp78, tmp86, tmp93, tmp109, tmp121, tmp135, tmp136.Invoke_O_O_O_O__O(tmp137, tmp139, lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp141, tmp143, tmp145, tmp147, tmp149, tmp151, tmp152)), A_arbace_j2g_dyncf_A_const_288), A_arbace_j2g_dyncf_A_const_163)); if linked_851 == nil { return ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { return linked_851.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_850, arg_853, arg_854)
	}
}













































































































































































































func A_arbace_j2g_dyncf_strip_anns_A_New() *A_arbace_j2g_dyncf_strip_anns_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Ctor() {}
//line :331:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Invoke_O_O__O(self, x__0 any) any {
	var root_1179 any = A_arbace_j2g_dyncf_A_const_289.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_walk.A_arbace_walk_postwalk_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any; var tmp1 any = A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_New(); var tmp2 *jrt.Class; var fncls__1193 *jrt.Class = A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class; if fncls__1193 == nil { var fncls__1193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class = fncls__1193d; tmp2 = fncls__1193d } else { tmp2 = fncls__1193 }; arg_1182 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1183 any = x__0; if linked_1180 == nil { return ifn_1181.Invoke_O_O__O(arg_1182, arg_1183) } else { return linked_1180.(*aot_arbace_walk.A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_1179, arg_1182, arg_1183) } }
//line :332:1
func A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_New() *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_fn__292000090_A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A) Ctor() {}
//line :332:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A) Invoke_O_O__O(self, y__1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_1184 any = A_arbace_j2g_dyncf_A_const_290.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = y__1; if linked_1185 == nil { and__1927000168__auto____2 = ifn_1186.Invoke_O__O(arg_1187) } else { and__1927000168__auto____2 = linked_1185.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1184, arg_1187) }; if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = A_arbace_j2g_dyncf_A_const_291.Invoke_O__O(y__1) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_1188 any = A_arbace_j2g_dyncf_A_const_292.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = y__1; var arg_1192 any = A_arbace_j2g_dyncf_A_const_291; if linked_1189 == nil { return ifn_1190.Invoke_O_O__O(arg_1191, arg_1192) } else { return linked_1189.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1188, arg_1191, arg_1192) } } else { return y__1 } }

func A_arbace_j2g_dyncf_generics_text_A_New() *A_arbace_j2g_dyncf_generics_text_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Ctor() {}
//line :334:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Invoke_O_O__O(self, T__0_ any) any { var extendable__2 any; var root_1194 any = A_arbace_j2g_dyncf_A_const_293.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1196 lang.IFn; if





	linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any; var root_1198 any = A_arbace_j2g_dyncf_A_const_145.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = A_arbace_j2g_dyncf_A_const_294.GetRawRoot__O(); var arg_1202 any = A_arbace_j2g_dyncf_A_const_295; if linked_1199 == nil { arg_1197 = ifn_1200.Invoke_O_O__O(arg_1201, arg_1202) } else { arg_1197 = linked_1199.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1198, arg_1201, arg_1202) }; if linked_1195 == nil { extendable__2 = ifn_1196.Invoke_O__O(arg_1197) } else { extendable__2 = linked_1195.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1194, arg_1197) }; var entries__3 any; var iter__1927001039__auto____3 any; var tmp1 any = /*line :334:1*/A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_New_O(extendable__2); var tmp2 *jrt.Class; var fncls__1747 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class; if






	fncls__1747 == nil { var fncls__1747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class = fncls__1747d; tmp2 = fncls__1747d } else { tmp2 = fncls__1747 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1831 any = A_arbace_j2g_dyncf_A_const_321.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1833 lang.IFn; if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any = T__0_; if linked_1832 == nil { tmp4 = ifn_1833.Invoke_O__O(arg_1834) } else { tmp4 = linked_1832.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1831, arg_1834) }; entries__3 = tmp3.Invoke_O__O(tmp4); var root_1835 any =




















	A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_1836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1835, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1837 lang.IFn; if linked_1836 == nil { ifn_1837 = lang.IFn_Cast(root_1835) } else { ifn_1837 = nil }; var arg_1838 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_38.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_322, nil, A_arbace_j2g_dyncf_A_const_323, nil, A_arbace_j2g_dyncf_A_const_324, jrt.Boolean_FALSE.Ref()); if linked_1836 == nil { ifn_1837.Invoke_O__O(arg_1838) } else { linked_1836.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1835, arg_1838) }; var tmp5 any; tmp10 := /*line :334:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




























		{ var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, Lit_32, nil, Lit_33); var tmp7 any; var root_1748 any = A_arbace_j2g_dyncf_A_const_319.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1750 lang.IFn

			if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = Lit_34; var arg_1752 any; var iter__1927001039__auto____10 any; var tmp8 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_New(); var tmp9 *jrt.Class; var fncls__1827 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class; if fncls__1827 == nil { var fncls__1827d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class = fncls__1827d; tmp9 = fncls__1827d } else { tmp9 = fncls__1827 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_1752 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(entries__3); if linked_1749 == nil { tmp7 = ifn_1750.Invoke_O_O__O(arg_1751, arg_1752) } else { tmp7 = linked_1749.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1748, arg_1751, arg_1752) }
//line :363:1
			tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, nil, tmp7, nil)).Ref() }
//line :334:1
		return nil }(); var root_1828 any = A_arbace_j2g_dyncf_A_const_35.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1830 lang.IFn; if



























	linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; if linked_1829 == nil { ifn_1830.Invoke__O() } else { linked_1829.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1828) }; if /*line :334:1*/ tmp10 != nil { panic(tmp10) }; return tmp5 }






func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A{}; t.Ctor_O(p0); return t }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A) Ctor_O(c__extendable any) { t.F_extendable = c__extendable }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A) Invoke_O_O__O(self, s__292000094__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_New_O_O_O(self, s__292000094__1, t.F_extendable); var tmp2 *jrt.Class; var fncls__1746 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class; if fncls__1746 == nil { var fncls__1746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class = fncls__1746d; tmp2 = fncls__1746d } else { tmp2 = fncls__1746 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :341:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A) Ctor_O_O_O(c__iter__292000093, c__s__292000094, c__extendable any) { t.F_iter__292000093 = c__iter__292000093; t.F_s__292000094 = c__s__292000094; t.F_extendable = c__extendable }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A) Invoke_O__O(self any) any { { var s__292000094__1 any; var t_ any = t.F_s__292000094; t.F_s__292000094 = nil; s__292000094__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1203 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = s__292000094__1; if linked_1204 == nil { temp__1927000414__auto____2 = ifn_1205.Invoke_O__O(arg_1206) } else { temp__1927000414__auto____2 = linked_1204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1203, arg_1206) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000094__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1207 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = s__292000094__3; if linked_1208 == nil { tmp1 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp1 = linked_1208.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1207, arg_1210) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1211 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = s__292000094__3; if linked_1212 == nil { c__1927001037__auto____4 = ifn_1213.Invoke_O__O(arg_1214) } else { c__1927001037__auto____4 = linked_1212.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1211, arg_1214) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000096__6 any; var root_1215 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1216 == nil { b__292000096__6 = ifn_1217.Invoke_O__O(arg_1218) } else { b__292000096__6 = linked_1216.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1215, arg_1218) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_New_O_O_I_O(b__292000096__6, t.F_extendable, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1461 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class; if fncls__1461 == nil { var fncls__1461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class = fncls__1461d; tmp3 = fncls__1461d } else { tmp3 = fncls__1461 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1462 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any; var root_1467 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = b__292000096__6; if linked_1468 == nil { arg_1465 = ifn_1469.Invoke_O__O(arg_1470) } else { arg_1465 = linked_1468.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1467, arg_1470) }; var arg_1466 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000093); var tmp5 any; var root_1471 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = s__292000094__3; if linked_1472 == nil { tmp5 = ifn_1473.Invoke_O__O(arg_1474) } else { tmp5 = linked_1472.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1471, arg_1474) }; arg_1466 = tmp4.Invoke_O__O(tmp5); if linked_1463 == nil { return ifn_1464.Invoke_O_O__O(arg_1465, arg_1466) } else { return linked_1463.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1462, arg_1465, arg_1466) } } else { var root_1475 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any; var root_1480 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = b__292000096__6; if linked_1481 == nil { arg_1478 = ifn_1482.Invoke_O__O(arg_1483) } else { arg_1478 = linked_1481.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1480, arg_1483) }; var arg_1479 any; if linked_1476 == nil { return ifn_1477.Invoke_O_O__O(arg_1478, arg_1479) } else { return linked_1476.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1475, arg_1478, arg_1479) } } } else { var n__4 any; var root_1484 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = s__292000094__3; if linked_1485 == nil { n__4 = ifn_1486.Invoke_O__O(arg_1487) } else { n__4 = linked_1485.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1484, arg_1487) }; var d__5 any; var root_1488 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1490 lang.IFn
														if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = n__4; if linked_1489 == nil { d__5 = ifn_1490.Invoke_O__O(arg_1491) } else { d__5 = linked_1489.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1488, arg_1491) }
//line :341:1
	var tmp6 any
	var and__1927000168__auto____6 any = d__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1492 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_316); var arg_1495 any = tmp7.Invoke_O__O(A_arbace_j2g_dyncf_A_const_297.Invoke_O__O(d__5)); if linked_1493 == nil { and__1927000168__auto____7 = ifn_1494.Invoke_O__O(arg_1495) } else { and__1927000168__auto____7 = linked_1493.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1492, arg_1495) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var or__1927000174__auto____8 any; var root_1496 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1498 lang.IFn
		if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = n__4; if linked_1497 == nil { or__1927000174__auto____8 = ifn_1498.Invoke_O__O(arg_1499) } else { or__1927000174__auto____8 = linked_1497.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1496, arg_1499) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__4) } } else {
//line :345:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }
//line :341:1
	if jrt.J2g_Truth(tmp6) { var g__6 any; var tmp8 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_New_O(n__4); var tmp9 *jrt.Class
		var fncls__1500 /*line :341:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class





		if fncls__1500 == nil { var fncls__1500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class = fncls__1500d; tmp9 = fncls__1500d } else { tmp9 = fncls__1500 }; g__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()
//line :341:1
		if jrt.J2g_Truth(g__6) { var generic_QMARK___7 any; var root_1501 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1503 lang.IFn







			if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = A_arbace_j2g_dyncf_A_const_300.Invoke_O__O(g__6); if linked_1502 == nil { generic_QMARK___7 = ifn_1503.Invoke_O__O(arg_1504) } else { generic_QMARK___7 = linked_1502.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1501, arg_1504) }
//line :341:1
			var supers__8 any; var root_1505 any = A_arbace_j2g_dyncf_A_const_301.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1507 lang.IFn








			if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any; var root_1509 any = A_arbace_j2g_dyncf_A_const_302.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var arg_1513 any = A_arbace_j2g_dyncf_A_const_304.Invoke_O__O(g__6); if linked_1510 == nil { arg_1508 = ifn_1511.Invoke_O_O__O(arg_1512, arg_1513) } else { arg_1508 = linked_1510.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1509, arg_1512, arg_1513) }; if linked_1506 == nil { supers__8 = ifn_1507.Invoke_O__O(arg_1508) } else { supers__8 = linked_1506.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1505, arg_1508) }
//line :341:1
			var abstract_QMARK___9 any; var and__1927000168__auto____9 any; var root_1514 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1516 lang.IFn









			if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any; var root_1518 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = n__4; if linked_1519 == nil { arg_1517 = ifn_1520.Invoke_O__O(arg_1521) } else { arg_1517 = linked_1519.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1518, arg_1521) }; if linked_1515 == nil { and__1927000168__auto____9 = ifn_1516.Invoke_O__O(arg_1517) } else { and__1927000168__auto____9 = linked_1515.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1514, arg_1517) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp10 int64; var na_1522 any; var or__1927000174__auto____10 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(d__5); if jrt.J2g_Truth(or__1927000174__auto____10) { na_1522 = or__1927000174__auto____10 } else { na_1522 = A_arbace_j2g_dyncf_A_const_306 }; var na_1523 int64 = 1024; if jrt.Long_InstanceOf(na_1522) { var n0_1524 int64 = jrt.NN(jrt.Long_Cast(na_1522)).LongValue__J(); var n1_1525 int64 = na_1523; tmp10 = n0_1524 & n1_1525 } else { tmp10 = lang.Numbers_And_O_J__J_NoInit(na_1522, na_1523) }; abstract_QMARK___9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp10)).Ref() } else { abstract_QMARK___9 = and__1927000168__auto____9 }
//line :341:1
			var tmp11 any
			var or__1927000174__auto____10_2 any = generic_QMARK___7









			if jrt.J2g_Truth(or__1927000174__auto____10_2) { tmp11 = or__1927000174__auto____10_2 } else { var or__1927000174__auto____11 any = abstract_QMARK___9; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp11 = or__1927000174__auto____11 } else { var root_1527 any = A_arbace_j2g_dyncf_A_const_307.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any; var root_1532 any = A_arbace_j2g_dyncf_A_const_308.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var arg_1536 any = A_arbace_j2g_dyncf_A_const_309; if linked_1533 == nil { arg_1530 = ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { arg_1530 = linked_1533.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) }; var arg_1531 any = supers__8; if linked_1528 == nil { tmp11 = ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { tmp11 = linked_1528.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) } } }
//line :341:1
			if jrt.J2g_Truth(tmp11) { var root_1537 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any; var tmp12 any; var root_1542 any = A_arbace_j2g_dyncf_A_const_310.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_1544 lang.IFn











				if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any; var G__292000126__10_ any; var tmp13 any = A_arbace_j2g_dyncf_A_const_300; var tmp14 any; var root_1546 any = A_arbace_j2g_dyncf_A_const_301.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1548 lang.IFn
				if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = A_arbace_j2g_dyncf_A_const_300.Invoke_O__O(g__6); if linked_1547 == nil { tmp14 = ifn_1548.Invoke_O__O(arg_1549) } else { tmp14 = linked_1547.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1546, arg_1549) }
//line :353:1
				G__292000126__10_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, A_arbace_j2g_dyncf_A_const_304, supers__8)); var G__292000126__11_ any
				if jrt.J2g_Truth(abstract_QMARK___9) {
					var root_1550 any = A_arbace_j2g_dyncf_A_const_311.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = G__292000126__10_; var arg_1554 any = A_arbace_j2g_dyncf_A_const_312; var arg_1555 any; var root_1556 any = A_arbace_j2g_dyncf_A_const_301.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any; var iter__1927001039__auto____11 any; var tmp15 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_New(); var tmp16 *jrt.Class; var fncls__1636 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class; if fncls__1636 == nil { var fncls__1636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class = fncls__1636d; tmp16 = fncls__1636d } else { tmp16 = fncls__1636 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); arg_1559 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_j2g_dyncf_A_const_106.Invoke_O__O(d__5)); if linked_1557 == nil { arg_1555 = ifn_1558.Invoke_O__O(arg_1559) } else { arg_1555 = linked_1557.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1556, arg_1559) }; if linked_1551 == nil { G__292000126__11_ = ifn_1552.Invoke_O_O_O__O(arg_1553, arg_1554, arg_1555) } else { G__292000126__11_ = linked_1551.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1550, arg_1553, arg_1554, arg_1555) } } else {
//line :354:1
						G__292000126__11_ = G__292000126__10_ }; if jrt.J2g_Truth(generic_QMARK___7) {




							var root_1637 any = A_arbace_j2g_dyncf_A_const_311.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = G__292000126__11_; var arg_1641 any = A_arbace_j2g_dyncf_A_const_106; var arg_1642 any; var root_1643 any = A_arbace_j2g_dyncf_A_const_301.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any; var iter__1927001039__auto____12 any; var tmp17 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_New(); var tmp18 *jrt.Class; var fncls__1729 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class; if fncls__1729 == nil { var fncls__1729d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class = fncls__1729d; tmp18 = fncls__1729d } else { tmp18 = fncls__1729 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); arg_1646 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_j2g_dyncf_A_const_106.Invoke_O__O(g__6)); if linked_1644 == nil { arg_1642 = ifn_1645.Invoke_O__O(arg_1646) } else { arg_1642 = linked_1644.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1643, arg_1646) }; if linked_1638 == nil { arg_1545 = ifn_1639.Invoke_O_O_O__O(arg_1640, arg_1641, arg_1642) } else { arg_1545 = linked_1638.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1637, arg_1640, arg_1641, arg_1642) } } else {
//line :354:1
								arg_1545 = G__292000126__11_ }
//line :353:1
				if linked_1543 == nil { tmp12 = ifn_1544.Invoke_O__O(arg_1545) } else { tmp12 = linked_1543.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_1542, arg_1545) }
//line :341:1
				arg_1540 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp12); var arg_1541 any; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__292000093); var tmp20 any; var root_1730 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = s__292000094__3; if linked_1731 == nil { tmp20 = ifn_1732.Invoke_O__O(arg_1733) } else { tmp20 = linked_1731.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1730, arg_1733) }; arg_1541 = tmp19.Invoke_O__O(tmp20); if linked_1538 == nil { return ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { return linked_1538.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) } } else { var tmp21 any; var root_1734 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = s__292000094__3; if linked_1735 == nil { tmp21 = ifn_1736.Invoke_O__O(arg_1737) } else { tmp21 = linked_1735.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1734, arg_1737) }; s__292000094__1 = tmp21; continue L1 } } else { var tmp22 any; var root_1738 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = s__292000094__3; if linked_1739 == nil { tmp22 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp22 = linked_1739.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1738, arg_1741) }; s__292000094__1 = tmp22; continue L1 } } else { var tmp23 any; var root_1742 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = s__292000094__3; if linked_1743 == nil { tmp23 = ifn_1744.Invoke_O__O(arg_1745) } else { tmp23 = linked_1743.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1742, arg_1745) }; s__292000094__1 = tmp23; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :341:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A) Ctor_O_O_I_O(c__b__292000096, c__extendable any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000096 = c__b__292000096; t.F_extendable = c__extendable; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A) Invoke_O__O(self any) any { { var i__292000095__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000095__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000095__1)); var d__3 any; var root_1219 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1221 lang.IFn
																if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = n__2; if linked_1220 == nil { d__3 = ifn_1221.Invoke_O__O(arg_1222) } else { d__3 = linked_1220.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1219, arg_1222) }
//line :341:1
	var tmp2 any
	var and__1927000168__auto____4 any = d__3


	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1223 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_296); var arg_1226 any = tmp3.Invoke_O__O(A_arbace_j2g_dyncf_A_const_297.Invoke_O__O(d__3)); if linked_1224 == nil { and__1927000168__auto____5 = ifn_1225.Invoke_O__O(arg_1226) } else { and__1927000168__auto____5 = linked_1224.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1223, arg_1226) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1227 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1229 lang.IFn
		if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = n__2; if linked_1228 == nil { or__1927000174__auto____6 = ifn_1229.Invoke_O__O(arg_1230) } else { or__1927000174__auto____6 = linked_1228.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1227, arg_1230) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__2) } } else {
//line :345:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :341:1
	if jrt.J2g_Truth(tmp2) { var g__4 any; var tmp4 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_New_O(n__2); var tmp5 *jrt.Class
		var fncls__1231 /*line :341:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class





		if fncls__1231 == nil { var fncls__1231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class = fncls__1231d; tmp5 = fncls__1231d } else { tmp5 = fncls__1231 }; g__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :341:1
		if jrt.J2g_Truth(g__4) { var generic_QMARK___5 any; var root_1232 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1234 lang.IFn







			if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = A_arbace_j2g_dyncf_A_const_300.Invoke_O__O(g__4); if linked_1233 == nil { generic_QMARK___5 = ifn_1234.Invoke_O__O(arg_1235) } else { generic_QMARK___5 = linked_1233.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1232, arg_1235) }
//line :341:1
			var supers__6 any; var root_1236 any = A_arbace_j2g_dyncf_A_const_301.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1238 lang.IFn








			if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any; var root_1240 any = A_arbace_j2g_dyncf_A_const_302.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var arg_1244 any = A_arbace_j2g_dyncf_A_const_304.Invoke_O__O(g__4); if linked_1241 == nil { arg_1239 = ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { arg_1239 = linked_1241.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) }; if linked_1237 == nil { supers__6 = ifn_1238.Invoke_O__O(arg_1239) } else { supers__6 = linked_1237.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1236, arg_1239) }
//line :341:1
			var abstract_QMARK___7 any; var and__1927000168__auto____7 any; var root_1245 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1247 lang.IFn









			if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any; var root_1249 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = n__2; if linked_1250 == nil { arg_1248 = ifn_1251.Invoke_O__O(arg_1252) } else { arg_1248 = linked_1250.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1249, arg_1252) }; if linked_1246 == nil { and__1927000168__auto____7 = ifn_1247.Invoke_O__O(arg_1248) } else { and__1927000168__auto____7 = linked_1246.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1245, arg_1248) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp6 int64; var na_1253 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(d__3); if jrt.J2g_Truth(or__1927000174__auto____8) { na_1253 = or__1927000174__auto____8 } else { na_1253 = A_arbace_j2g_dyncf_A_const_306 }; var na_1254 int64 = 1024; if jrt.Long_InstanceOf(na_1253) { var n0_1255 int64 = jrt.NN(jrt.Long_Cast(na_1253)).LongValue__J(); var n1_1256 int64 = na_1254; tmp6 = n0_1255 & n1_1256 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1253, na_1254) }; abstract_QMARK___7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp6)).Ref() } else { abstract_QMARK___7 = and__1927000168__auto____7 }
//line :341:1
			var tmp7 any
			var or__1927000174__auto____8_2 any = generic_QMARK___5









			if jrt.J2g_Truth(or__1927000174__auto____8_2) { tmp7 = or__1927000174__auto____8_2 } else { var or__1927000174__auto____9 any = abstract_QMARK___7; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { var root_1258 any = A_arbace_j2g_dyncf_A_const_307.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any; var root_1263 any = A_arbace_j2g_dyncf_A_const_308.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var arg_1267 any = A_arbace_j2g_dyncf_A_const_309; if linked_1264 == nil { arg_1261 = ifn_1265.Invoke_O_O__O(arg_1266, arg_1267) } else { arg_1261 = linked_1264.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1263, arg_1266, arg_1267) }; var arg_1262 any = supers__6; if linked_1259 == nil { tmp7 = ifn_1260.Invoke_O_O__O(arg_1261, arg_1262) } else { tmp7 = linked_1259.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1258, arg_1261, arg_1262) } } }
//line :341:1
			if jrt.J2g_Truth(tmp7) { var root_1268 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = t.F_b__292000096; var arg_1272 any; var tmp8 any; var root_1273 any = A_arbace_j2g_dyncf_A_const_310.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_1275 lang.IFn











				if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any; var G__292000102__8_ any; var tmp9 any = A_arbace_j2g_dyncf_A_const_300; var tmp10 any; var root_1277 any = A_arbace_j2g_dyncf_A_const_301.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1279 lang.IFn
				if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = A_arbace_j2g_dyncf_A_const_300.Invoke_O__O(g__4); if linked_1278 == nil { tmp10 = ifn_1279.Invoke_O__O(arg_1280) } else { tmp10 = linked_1278.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1277, arg_1280) }
//line :353:1
				G__292000102__8_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, A_arbace_j2g_dyncf_A_const_304, supers__6)); var G__292000102__9_ any
				if jrt.J2g_Truth(abstract_QMARK___7) {
					var root_1281 any = A_arbace_j2g_dyncf_A_const_311.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = G__292000102__8_; var arg_1285 any = A_arbace_j2g_dyncf_A_const_312; var arg_1286 any; var root_1287 any = A_arbace_j2g_dyncf_A_const_301.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any; var iter__1927001039__auto____9 any; var tmp11 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_New(); var tmp12 *jrt.Class; var fncls__1367 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class; if fncls__1367 == nil { var fncls__1367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class = fncls__1367d; tmp12 = fncls__1367d } else { tmp12 = fncls__1367 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1290 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_j2g_dyncf_A_const_106.Invoke_O__O(d__3)); if linked_1288 == nil { arg_1286 = ifn_1289.Invoke_O__O(arg_1290) } else { arg_1286 = linked_1288.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1287, arg_1290) }; if linked_1282 == nil { G__292000102__9_ = ifn_1283.Invoke_O_O_O__O(arg_1284, arg_1285, arg_1286) } else { G__292000102__9_ = linked_1282.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1281, arg_1284, arg_1285, arg_1286) } } else {
//line :354:1
						G__292000102__9_ = G__292000102__8_ }; if jrt.J2g_Truth(generic_QMARK___5) {




							var root_1368 any = A_arbace_j2g_dyncf_A_const_311.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = G__292000102__9_; var arg_1372 any = A_arbace_j2g_dyncf_A_const_106; var arg_1373 any; var root_1374 any = A_arbace_j2g_dyncf_A_const_301.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any; var iter__1927001039__auto____10 any; var tmp13 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_New(); var tmp14 *jrt.Class; var fncls__1460 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class; if fncls__1460 == nil { var fncls__1460d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class = fncls__1460d; tmp14 = fncls__1460d } else { tmp14 = fncls__1460 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); arg_1377 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_j2g_dyncf_A_const_106.Invoke_O__O(g__4)); if linked_1375 == nil { arg_1373 = ifn_1376.Invoke_O__O(arg_1377) } else { arg_1373 = linked_1375.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1374, arg_1377) }; if linked_1369 == nil { arg_1276 = ifn_1370.Invoke_O_O_O__O(arg_1371, arg_1372, arg_1373) } else { arg_1276 = linked_1369.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1368, arg_1371, arg_1372, arg_1373) } } else {
//line :354:1
								arg_1276 = G__292000102__9_ }
//line :353:1
				if linked_1274 == nil { tmp8 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp8 = linked_1274.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_1273, arg_1276) }
//line :341:1
				arg_1272 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp8); if linked_1269 == nil { ifn_1270.Invoke_O_O__O(arg_1271, arg_1272) } else { linked_1269.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1268, arg_1271, arg_1272) }; i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A{}; t.Ctor_O(p0); return t }
//line :347:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :347:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_299; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :347:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A{}; t.Ctor_O(p0); return t }
//line :347:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :347:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_299; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A) Ctor() {}
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A) Invoke_O_O__O(self, s__292000104__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_New_O_O(self, s__292000104__1); var tmp2 *jrt.Class; var fncls__1366 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class; if fncls__1366 == nil { var fncls__1366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class = fncls__1366d; tmp2 = fncls__1366d } else { tmp2 = fncls__1366 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A{}; t.Ctor_O_O(p0, p1); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A) Ctor_O_O(c__iter__292000103, c__s__292000104 any) { t.F_iter__292000103 = c__iter__292000103; t.F_s__292000104 = c__s__292000104 }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A) Invoke_O__O(self any) any { { var s__292000104__1 any; var t_ any = t.F_s__292000104; t.F_s__292000104 = nil; s__292000104__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1291 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = s__292000104__1; if linked_1292 == nil { temp__1927000414__auto____2 = ifn_1293.Invoke_O__O(arg_1294) } else { temp__1927000414__auto____2 = linked_1292.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1291, arg_1294) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1295 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = s__292000104__3; if linked_1296 == nil { tmp1 = ifn_1297.Invoke_O__O(arg_1298) } else { tmp1 = linked_1296.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1295, arg_1298) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1299 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = s__292000104__3; if linked_1300 == nil { c__1927001037__auto____4 = ifn_1301.Invoke_O__O(arg_1302) } else { c__1927001037__auto____4 = linked_1300.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1299, arg_1302) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000106__6 any; var root_1303 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1304 == nil { b__292000106__6 = ifn_1305.Invoke_O__O(arg_1306) } else { b__292000106__6 = linked_1304.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1303, arg_1306) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_New_O_I_O(b__292000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1317 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class; if fncls__1317 == nil { var fncls__1317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class = fncls__1317d; tmp3 = fncls__1317d } else { tmp3 = fncls__1317 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1318 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any; var root_1323 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = b__292000106__6; if linked_1324 == nil { arg_1321 = ifn_1325.Invoke_O__O(arg_1326) } else { arg_1321 = linked_1324.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1323, arg_1326) }; var arg_1322 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000103); var tmp5 any; var root_1327 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = s__292000104__3; if linked_1328 == nil { tmp5 = ifn_1329.Invoke_O__O(arg_1330) } else { tmp5 = linked_1328.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1327, arg_1330) }; arg_1322 = tmp4.Invoke_O__O(tmp5); if linked_1319 == nil { return ifn_1320.Invoke_O_O__O(arg_1321, arg_1322) } else { return linked_1319.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1318, arg_1321, arg_1322) } } else { var root_1331 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any; var root_1336 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = b__292000106__6; if linked_1337 == nil { arg_1334 = ifn_1338.Invoke_O__O(arg_1339) } else { arg_1334 = linked_1337.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1336, arg_1339) }; var arg_1335 any; if linked_1332 == nil { return ifn_1333.Invoke_O_O__O(arg_1334, arg_1335) } else { return linked_1332.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1331, arg_1334, arg_1335) } } } else { var mm__4 any; var root_1340 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = s__292000104__3; if linked_1341 == nil { mm__4 = ifn_1342.Invoke_O__O(arg_1343) } else { mm__4 = linked_1341.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1340, arg_1343) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__4)) { var tmp6 int64; var na_1344 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_1344 = or__1927000174__auto____5 } else { na_1344 = A_arbace_j2g_dyncf_A_const_306 }; var na_1345 int64 = 4098; if jrt.Long_InstanceOf(na_1344) { var n0_1346 int64 = jrt.NN(jrt.Long_Cast(na_1344)).LongValue__J(); var n1_1347 int64 = na_1345; tmp6 = n0_1346 & n1_1347 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1344, na_1345) }
//line :355:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1349 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__4)); var arg_1353 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000103); var tmp8 any; var root_1354 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1356 lang.IFn; if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = s__292000104__3; if linked_1355 == nil { tmp8 = ifn_1356.Invoke_O__O(arg_1357) } else { tmp8 = linked_1355.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1354, arg_1357) }; arg_1353 = tmp7.Invoke_O__O(tmp8); if linked_1350 == nil { return ifn_1351.Invoke_O_O__O(arg_1352, arg_1353) } else { return linked_1350.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1349, arg_1352, arg_1353) } } else { var tmp9 any; var root_1358 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = s__292000104__3; if linked_1359 == nil { tmp9 = ifn_1360.Invoke_O__O(arg_1361) } else { tmp9 = linked_1359.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1358, arg_1361) }; s__292000104__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1362 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = s__292000104__3; if linked_1363 == nil { tmp10 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp10 = linked_1363.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1362, arg_1365) }; s__292000104__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A) Ctor_O_I_O(c__b__292000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000106 = c__b__292000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A) Invoke_O__O(self any) any { { var i__292000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000105__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__2)) { var tmp2 int64; var na_1307 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_1307 = or__1927000174__auto____3 } else { na_1307 = A_arbace_j2g_dyncf_A_const_306 }; var na_1308 int64 = 4098; if jrt.Long_InstanceOf(na_1307) { var n0_1309 int64 = jrt.NN(jrt.Long_Cast(na_1307)).LongValue__J(); var n1_1310 int64 = na_1308; tmp2 = n0_1309 & n1_1310 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1307, na_1308) }
//line :355:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1312 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = t.F_b__292000106; var arg_1316 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__2)); if linked_1313 == nil { ifn_1314.Invoke_O_O__O(arg_1315, arg_1316) } else { linked_1313.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1312, arg_1315, arg_1316) }; i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } else { i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } } else { i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A) Ctor() {}
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A) Invoke_O_O__O(self, s__292000128__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_New_O_O(self, s__292000128__1); var tmp2 *jrt.Class; var fncls__1635 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class; if fncls__1635 == nil { var fncls__1635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class = fncls__1635d; tmp2 = fncls__1635d } else { tmp2 = fncls__1635 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A{}; t.Ctor_O_O(p0, p1); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A) Ctor_O_O(c__iter__292000127, c__s__292000128 any) { t.F_iter__292000127 = c__iter__292000127; t.F_s__292000128 = c__s__292000128 }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A) Invoke_O__O(self any) any { { var s__292000128__1 any; var t_ any = t.F_s__292000128; t.F_s__292000128 = nil; s__292000128__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1560 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = s__292000128__1; if linked_1561 == nil { temp__1927000414__auto____2 = ifn_1562.Invoke_O__O(arg_1563) } else { temp__1927000414__auto____2 = linked_1561.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1560, arg_1563) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000128__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1564 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = s__292000128__3; if linked_1565 == nil { tmp1 = ifn_1566.Invoke_O__O(arg_1567) } else { tmp1 = linked_1565.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1564, arg_1567) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1568 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = s__292000128__3; if linked_1569 == nil { c__1927001037__auto____4 = ifn_1570.Invoke_O__O(arg_1571) } else { c__1927001037__auto____4 = linked_1569.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1568, arg_1571) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000130__6 any; var root_1572 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1573 == nil { b__292000130__6 = ifn_1574.Invoke_O__O(arg_1575) } else { b__292000130__6 = linked_1573.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1572, arg_1575) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_New_O_I_O(b__292000130__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1586 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class; if fncls__1586 == nil { var fncls__1586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class = fncls__1586d; tmp3 = fncls__1586d } else { tmp3 = fncls__1586 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1587 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any; var root_1592 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = b__292000130__6; if linked_1593 == nil { arg_1590 = ifn_1594.Invoke_O__O(arg_1595) } else { arg_1590 = linked_1593.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1592, arg_1595) }; var arg_1591 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000127); var tmp5 any; var root_1596 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = s__292000128__3; if linked_1597 == nil { tmp5 = ifn_1598.Invoke_O__O(arg_1599) } else { tmp5 = linked_1597.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1596, arg_1599) }; arg_1591 = tmp4.Invoke_O__O(tmp5); if linked_1588 == nil { return ifn_1589.Invoke_O_O__O(arg_1590, arg_1591) } else { return linked_1588.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1587, arg_1590, arg_1591) } } else { var root_1600 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1602 lang.IFn; if linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any; var root_1605 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = b__292000130__6; if linked_1606 == nil { arg_1603 = ifn_1607.Invoke_O__O(arg_1608) } else { arg_1603 = linked_1606.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1605, arg_1608) }; var arg_1604 any; if linked_1601 == nil { return ifn_1602.Invoke_O_O__O(arg_1603, arg_1604) } else { return linked_1601.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1600, arg_1603, arg_1604) } } } else { var mm__4 any; var root_1609 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = s__292000128__3; if linked_1610 == nil { mm__4 = ifn_1611.Invoke_O__O(arg_1612) } else { mm__4 = linked_1610.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1609, arg_1612) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__4)) { var tmp6 int64; var na_1613 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_1613 = or__1927000174__auto____5 } else { na_1613 = A_arbace_j2g_dyncf_A_const_306 }; var na_1614 int64 = 4098; if jrt.Long_InstanceOf(na_1613) { var n0_1615 int64 = jrt.NN(jrt.Long_Cast(na_1613)).LongValue__J(); var n1_1616 int64 = na_1614; tmp6 = n0_1615 & n1_1616 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1613, na_1614) }
//line :355:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1618 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__4)); var arg_1622 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000127); var tmp8 any; var root_1623 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = s__292000128__3; if linked_1624 == nil { tmp8 = ifn_1625.Invoke_O__O(arg_1626) } else { tmp8 = linked_1624.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1623, arg_1626) }; arg_1622 = tmp7.Invoke_O__O(tmp8); if linked_1619 == nil { return ifn_1620.Invoke_O_O__O(arg_1621, arg_1622) } else { return linked_1619.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1618, arg_1621, arg_1622) } } else { var tmp9 any; var root_1627 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = s__292000128__3; if linked_1628 == nil { tmp9 = ifn_1629.Invoke_O__O(arg_1630) } else { tmp9 = linked_1628.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1627, arg_1630) }; s__292000128__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1631 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = s__292000128__3; if linked_1632 == nil { tmp10 = ifn_1633.Invoke_O__O(arg_1634) } else { tmp10 = linked_1632.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1631, arg_1634) }; s__292000128__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A) Ctor_O_I_O(c__b__292000130 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000130 = c__b__292000130; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A) Invoke_O__O(self any) any { { var i__292000129__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000129__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000129__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__2)) { var tmp2 int64; var na_1576 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_1576 = or__1927000174__auto____3 } else { na_1576 = A_arbace_j2g_dyncf_A_const_306 }; var na_1577 int64 = 4098; if jrt.Long_InstanceOf(na_1576) { var n0_1578 int64 = jrt.NN(jrt.Long_Cast(na_1576)).LongValue__J(); var n1_1579 int64 = na_1577; tmp2 = n0_1578 & n1_1579 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1576, na_1577) }
//line :355:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1581 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = t.F_b__292000130; var arg_1585 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__2)); if linked_1582 == nil { ifn_1583.Invoke_O_O__O(arg_1584, arg_1585) } else { linked_1582.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1581, arg_1584, arg_1585) }; i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } else { i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } } else { i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A) Ctor() {}
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A) Invoke_O_O__O(self, s__292000114__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_New_O_O(self, s__292000114__1); var tmp2 *jrt.Class; var fncls__1459 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class; if fncls__1459 == nil { var fncls__1459d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class = fncls__1459d; tmp2 = fncls__1459d } else { tmp2 = fncls__1459 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A) Ctor_O_O(c__iter__292000113, c__s__292000114 any) { t.F_iter__292000113 = c__iter__292000113; t.F_s__292000114 = c__s__292000114 }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A) Invoke_O__O(self any) any { { var s__292000114__1 any; var t_ any = t.F_s__292000114; t.F_s__292000114 = nil; s__292000114__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1378 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = s__292000114__1; if linked_1379 == nil { temp__1927000414__auto____2 = ifn_1380.Invoke_O__O(arg_1381) } else { temp__1927000414__auto____2 = linked_1379.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1378, arg_1381) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000114__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1382 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = s__292000114__3; if linked_1383 == nil { tmp1 = ifn_1384.Invoke_O__O(arg_1385) } else { tmp1 = linked_1383.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1382, arg_1385) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1386 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = s__292000114__3; if linked_1387 == nil { c__1927001037__auto____4 = ifn_1388.Invoke_O__O(arg_1389) } else { c__1927001037__auto____4 = linked_1387.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1386, arg_1389) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000116__6 any; var root_1390 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1391 == nil { b__292000116__6 = ifn_1392.Invoke_O__O(arg_1393) } else { b__292000116__6 = linked_1391.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1390, arg_1393) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_New_O_I_O(b__292000116__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1409 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class; if fncls__1409 == nil { var fncls__1409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class = fncls__1409d; tmp3 = fncls__1409d } else { tmp3 = fncls__1409 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1410 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any; var root_1415 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = b__292000116__6; if linked_1416 == nil { arg_1413 = ifn_1417.Invoke_O__O(arg_1418) } else { arg_1413 = linked_1416.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1415, arg_1418) }; var arg_1414 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000113); var tmp5 any; var root_1419 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = s__292000114__3; if linked_1420 == nil { tmp5 = ifn_1421.Invoke_O__O(arg_1422) } else { tmp5 = linked_1420.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1419, arg_1422) }; arg_1414 = tmp4.Invoke_O__O(tmp5); if linked_1411 == nil { return ifn_1412.Invoke_O_O__O(arg_1413, arg_1414) } else { return linked_1411.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1410, arg_1413, arg_1414) } } else { var root_1423 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any; var root_1428 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = b__292000116__6; if linked_1429 == nil { arg_1426 = ifn_1430.Invoke_O__O(arg_1431) } else { arg_1426 = linked_1429.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1428, arg_1431) }; var arg_1427 any; if linked_1424 == nil { return ifn_1425.Invoke_O_O__O(arg_1426, arg_1427) } else { return linked_1424.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1423, arg_1426, arg_1427) } } } else { var mm__4 any; var root_1432 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = s__292000114__3; if linked_1433 == nil { mm__4 = ifn_1434.Invoke_O__O(arg_1435) } else { mm__4 = linked_1433.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1432, arg_1435) }; var tmp6 int64; var na_1436 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { na_1436 = or__1927000174__auto____5 } else { na_1436 = A_arbace_j2g_dyncf_A_const_306 }; var na_1437 int64 = 4098; if jrt.Long_InstanceOf(na_1436) { var n0_1438 int64 = jrt.NN(jrt.Long_Cast(na_1436)).LongValue__J(); var n1_1439 int64 = na_1437; tmp6 = n0_1438 & n1_1439 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1436, na_1437) }
//line :359:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1441 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any; var root_1446 any = A_arbace_j2g_dyncf_A_const_313.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1448 lang.IFn

		if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = mm__4; var arg_1450 any = A_arbace_j2g_dyncf_A_const_315; if linked_1447 == nil { arg_1444 = ifn_1448.Invoke_O_O__O(arg_1449, arg_1450) } else { arg_1444 = linked_1447.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1446, arg_1449, arg_1450) }
//line :359:1
		var arg_1445 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000113); var tmp8 any; var root_1451 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = s__292000114__3; if linked_1452 == nil { tmp8 = ifn_1453.Invoke_O__O(arg_1454) } else { tmp8 = linked_1452.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1451, arg_1454) }; arg_1445 = tmp7.Invoke_O__O(tmp8); if linked_1442 == nil { return ifn_1443.Invoke_O_O__O(arg_1444, arg_1445) } else { return linked_1442.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1441, arg_1444, arg_1445) } } else { var tmp9 any; var root_1455 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = s__292000114__3; if linked_1456 == nil { tmp9 = ifn_1457.Invoke_O__O(arg_1458) } else { tmp9 = linked_1456.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1455, arg_1458) }; s__292000114__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A) Ctor_O_I_O(c__b__292000116 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000116 = c__b__292000116; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A) Invoke_O__O(self any) any { { var i__292000115__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000115__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000115__1)); var tmp2 int64; var na_1394 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { na_1394 = or__1927000174__auto____3 } else { na_1394 = A_arbace_j2g_dyncf_A_const_306 }; var na_1395 int64 = 4098; if jrt.Long_InstanceOf(na_1394) { var n0_1396 int64 = jrt.NN(jrt.Long_Cast(na_1394)).LongValue__J(); var n1_1397 int64 = na_1395; tmp2 = n0_1396 & n1_1397 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1394, na_1395) }
//line :359:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1399 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = t.F_b__292000116; var arg_1403 any; var root_1404 any = A_arbace_j2g_dyncf_A_const_313.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1406 lang.IFn

		if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = mm__2; var arg_1408 any = A_arbace_j2g_dyncf_A_const_314; if linked_1405 == nil { arg_1403 = ifn_1406.Invoke_O_O__O(arg_1407, arg_1408) } else { arg_1403 = linked_1405.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1404, arg_1407, arg_1408) }
//line :359:1
		if linked_1400 == nil { ifn_1401.Invoke_O_O__O(arg_1402, arg_1403) } else { linked_1400.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1399, arg_1402, arg_1403) }; i__292000115__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000115__1); continue L1 } else { i__292000115__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000115__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A) Ctor() {}
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A) Invoke_O_O__O(self, s__292000138__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_New_O_O(self, s__292000138__1); var tmp2 *jrt.Class; var fncls__1728 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class; if fncls__1728 == nil { var fncls__1728d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class = fncls__1728d; tmp2 = fncls__1728d } else { tmp2 = fncls__1728 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A) Ctor_O_O(c__iter__292000137, c__s__292000138 any) { t.F_iter__292000137 = c__iter__292000137; t.F_s__292000138 = c__s__292000138 }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A) Invoke_O__O(self any) any { { var s__292000138__1 any; var t_ any = t.F_s__292000138; t.F_s__292000138 = nil; s__292000138__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1647 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = s__292000138__1; if linked_1648 == nil { temp__1927000414__auto____2 = ifn_1649.Invoke_O__O(arg_1650) } else { temp__1927000414__auto____2 = linked_1648.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1647, arg_1650) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000138__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1651 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1653 lang.IFn; if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any = s__292000138__3; if linked_1652 == nil { tmp1 = ifn_1653.Invoke_O__O(arg_1654) } else { tmp1 = linked_1652.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1651, arg_1654) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1655 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1657 lang.IFn; if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any = s__292000138__3; if linked_1656 == nil { c__1927001037__auto____4 = ifn_1657.Invoke_O__O(arg_1658) } else { c__1927001037__auto____4 = linked_1656.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1655, arg_1658) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000140__6 any; var root_1659 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1659, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1661 lang.IFn; if linked_1660 == nil { ifn_1661 = lang.IFn_Cast(root_1659) } else { ifn_1661 = nil }; var arg_1662 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1660 == nil { b__292000140__6 = ifn_1661.Invoke_O__O(arg_1662) } else { b__292000140__6 = linked_1660.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1659, arg_1662) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_New_O_I_O(b__292000140__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1678 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class; if fncls__1678 == nil { var fncls__1678d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class = fncls__1678d; tmp3 = fncls__1678d } else { tmp3 = fncls__1678 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1679 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1681 lang.IFn; if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any; var root_1684 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = b__292000140__6; if linked_1685 == nil { arg_1682 = ifn_1686.Invoke_O__O(arg_1687) } else { arg_1682 = linked_1685.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1684, arg_1687) }; var arg_1683 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000137); var tmp5 any; var root_1688 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = s__292000138__3; if linked_1689 == nil { tmp5 = ifn_1690.Invoke_O__O(arg_1691) } else { tmp5 = linked_1689.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1688, arg_1691) }; arg_1683 = tmp4.Invoke_O__O(tmp5); if linked_1680 == nil { return ifn_1681.Invoke_O_O__O(arg_1682, arg_1683) } else { return linked_1680.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1679, arg_1682, arg_1683) } } else { var root_1692 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any; var root_1697 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = b__292000140__6; if linked_1698 == nil { arg_1695 = ifn_1699.Invoke_O__O(arg_1700) } else { arg_1695 = linked_1698.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1697, arg_1700) }; var arg_1696 any; if linked_1693 == nil { return ifn_1694.Invoke_O_O__O(arg_1695, arg_1696) } else { return linked_1693.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1692, arg_1695, arg_1696) } } } else { var mm__4 any; var root_1701 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = s__292000138__3; if linked_1702 == nil { mm__4 = ifn_1703.Invoke_O__O(arg_1704) } else { mm__4 = linked_1702.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1701, arg_1704) }; var tmp6 int64; var na_1705 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { na_1705 = or__1927000174__auto____5 } else { na_1705 = A_arbace_j2g_dyncf_A_const_306 }; var na_1706 int64 = 4098; if jrt.Long_InstanceOf(na_1705) { var n0_1707 int64 = jrt.NN(jrt.Long_Cast(na_1705)).LongValue__J(); var n1_1708 int64 = na_1706; tmp6 = n0_1707 & n1_1708 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1705, na_1706) }
//line :359:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1710 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any; var root_1715 any = A_arbace_j2g_dyncf_A_const_313.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1717 lang.IFn

		if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = mm__4; var arg_1719 any = A_arbace_j2g_dyncf_A_const_318; if linked_1716 == nil { arg_1713 = ifn_1717.Invoke_O_O__O(arg_1718, arg_1719) } else { arg_1713 = linked_1716.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1715, arg_1718, arg_1719) }
//line :359:1
		var arg_1714 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000137); var tmp8 any; var root_1720 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = s__292000138__3; if linked_1721 == nil { tmp8 = ifn_1722.Invoke_O__O(arg_1723) } else { tmp8 = linked_1721.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1720, arg_1723) }; arg_1714 = tmp7.Invoke_O__O(tmp8); if linked_1711 == nil { return ifn_1712.Invoke_O_O__O(arg_1713, arg_1714) } else { return linked_1711.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1710, arg_1713, arg_1714) } } else { var tmp9 any; var root_1724 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = s__292000138__3; if linked_1725 == nil { tmp9 = ifn_1726.Invoke_O__O(arg_1727) } else { tmp9 = linked_1725.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1724, arg_1727) }; s__292000138__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A) Ctor_O_I_O(c__b__292000140 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000140 = c__b__292000140; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A) Invoke_O__O(self any) any { { var i__292000139__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000139__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000139__1)); var tmp2 int64; var na_1663 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_305.Invoke_O__O(mm__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { na_1663 = or__1927000174__auto____3 } else { na_1663 = A_arbace_j2g_dyncf_A_const_306 }; var na_1664 int64 = 4098; if jrt.Long_InstanceOf(na_1663) { var n0_1665 int64 = jrt.NN(jrt.Long_Cast(na_1663)).LongValue__J(); var n1_1666 int64 = na_1664; tmp2 = n0_1665 & n1_1666 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1663, na_1664) }
//line :359:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1668 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = t.F_b__292000140; var arg_1672 any; var root_1673 any = A_arbace_j2g_dyncf_A_const_313.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1675 lang.IFn

		if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = mm__2; var arg_1677 any = A_arbace_j2g_dyncf_A_const_317; if linked_1674 == nil { arg_1672 = ifn_1675.Invoke_O_O__O(arg_1676, arg_1677) } else { arg_1672 = linked_1674.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1673, arg_1676, arg_1677) }
//line :359:1
		if linked_1669 == nil { ifn_1670.Invoke_O_O__O(arg_1671, arg_1672) } else { linked_1669.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1668, arg_1671, arg_1672) }; i__292000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000139__1); continue L1 } else { i__292000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000139__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A{}; t.Ctor(); return t }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A) Ctor() {}
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A) Invoke_O_O__O(self, s__292000150__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_New_O_O(s__292000150__1, self); var tmp2 *jrt.Class; var fncls__1826 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class; if fncls__1826 == nil { var fncls__1826d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class = fncls__1826d; tmp2 = fncls__1826d } else { tmp2 = fncls__1826 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :365:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A) Ctor_O_O(c__s__292000150, c__iter__292000149 any) { t.F_s__292000150 = c__s__292000150; t.F_iter__292000149 = c__iter__292000149 }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A) Invoke_O__O(self any) any { { var s__292000150__1 any; var t_ any = t.F_s__292000150; t.F_s__292000150 = nil; s__292000150__1 = t_; for { var temp__1927000414__auto____2 any; var root_1753 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = s__292000150__1; if linked_1754 == nil { temp__1927000414__auto____2 = ifn_1755.Invoke_O__O(arg_1756) } else { temp__1927000414__auto____2 = linked_1754.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1753, arg_1756) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000150__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1757 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = s__292000150__3; if linked_1758 == nil { tmp1 = ifn_1759.Invoke_O__O(arg_1760) } else { tmp1 = linked_1758.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1757, arg_1760) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1761 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1763 lang.IFn; if linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var arg_1764 any = s__292000150__3; if linked_1762 == nil { c__1927001037__auto____4 = ifn_1763.Invoke_O__O(arg_1764) } else { c__1927001037__auto____4 = linked_1762.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1761, arg_1764) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000152__6 any; var root_1765 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1766 == nil { b__292000152__6 = ifn_1767.Invoke_O__O(arg_1768) } else { b__292000152__6 = linked_1766.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1765, arg_1768) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_New_O_I_O(b__292000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1782 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class; if fncls__1782 == nil { var fncls__1782d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class = fncls__1782d; tmp3 = fncls__1782d } else { tmp3 = fncls__1782 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1783 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any; var root_1788 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = b__292000152__6; if linked_1789 == nil { arg_1786 = ifn_1790.Invoke_O__O(arg_1791) } else { arg_1786 = linked_1789.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1788, arg_1791) }; var arg_1787 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000149); var tmp5 any; var root_1792 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = s__292000150__3; if linked_1793 == nil { tmp5 = ifn_1794.Invoke_O__O(arg_1795) } else { tmp5 = linked_1793.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1792, arg_1795) }; arg_1787 = tmp4.Invoke_O__O(tmp5); if linked_1784 == nil { return ifn_1785.Invoke_O_O__O(arg_1786, arg_1787) } else { return linked_1784.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1783, arg_1786, arg_1787) } } else { var root_1796 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any; var root_1801 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = b__292000152__6; if linked_1802 == nil { arg_1799 = ifn_1803.Invoke_O__O(arg_1804) } else { arg_1799 = linked_1802.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1801, arg_1804) }; var arg_1800 any; if linked_1797 == nil { return ifn_1798.Invoke_O_O__O(arg_1799, arg_1800) } else { return linked_1797.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1796, arg_1799, arg_1800) } } } else { var vec__292000160__4 any; var root_1805 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = s__292000150__3; if linked_1806 == nil { vec__292000160__4 = ifn_1807.Invoke_O__O(arg_1808) } else { vec__292000160__4 = linked_1806.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1805, arg_1808) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000160__4, lang.RT_IntCast_J__I_NoInit(0), nil); var g__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000160__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1809 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_320.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_320.GetRawRoot__O()).Invoke_O__O(g__6))).Ref(); var arg_1813 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000149); var tmp7 any; var root_1822 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = s__292000150__3; if linked_1823 == nil { tmp7 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp7 = linked_1823.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1822, arg_1825) }; arg_1813 = tmp6.Invoke_O__O(tmp7); if linked_1810 == nil { return ifn_1811.Invoke_O_O__O(arg_1812, arg_1813) } else { return linked_1810.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1809, arg_1812, arg_1813) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :365:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A) Ctor_O_I_O(c__b__292000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000152 = c__b__292000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A) Invoke_O__O(self any) any { { var i__292000151__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000156__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000151__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000156__2, lang.RT_IntCast_J__I_NoInit(0), nil); var g__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000156__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1769 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = t.F_b__292000152; var arg_1773 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_320.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_320.GetRawRoot__O()).Invoke_O__O(g__4))).Ref(); if linked_1770 == nil { ifn_1771.Invoke_O_O__O(arg_1772, arg_1773) } else { linked_1770.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1769, arg_1772, arg_1773) }; i__292000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000151__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































































































type A_arbace_j2g_dyncf_A struct{ jrt.Object }

var A_arbace_j2g_dyncf_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyncf_A_const_0 *lang.Var

var A_arbace_j2g_dyncf_A_const_1 any

var A_arbace_j2g_dyncf_A_const_2 any

var A_arbace_j2g_dyncf_A_const_3 any

var A_arbace_j2g_dyncf_A_const_4 any

var A_arbace_j2g_dyncf_A_const_5 any

var A_arbace_j2g_dyncf_A_const_6 any

var A_arbace_j2g_dyncf_A_const_7 any

var A_arbace_j2g_dyncf_A_const_8 any

var A_arbace_j2g_dyncf_A_const_9 any

var A_arbace_j2g_dyncf_A_const_10 *lang.Var

var A_arbace_j2g_dyncf_A_const_11 any

var A_arbace_j2g_dyncf_A_const_12 *lang.Var

var A_arbace_j2g_dyncf_A_const_13 *lang.Var

var A_arbace_j2g_dyncf_A_const_14 *lang.Var

var A_arbace_j2g_dyncf_A_const_15 *lang.Var

var A_arbace_j2g_dyncf_A_const_16 any

var A_arbace_j2g_dyncf_A_const_17 *lang.Var

var A_arbace_j2g_dyncf_A_const_18 *lang.Var

var A_arbace_j2g_dyncf_A_const_19 *lang.Var

var A_arbace_j2g_dyncf_A_const_20 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_21 *lang.Var

var A_arbace_j2g_dyncf_A_const_22 *lang.Var

var A_arbace_j2g_dyncf_A_const_23 *lang.Var

var A_arbace_j2g_dyncf_A_const_24 *lang.Var

var A_arbace_j2g_dyncf_A_const_25 *lang.Var

var A_arbace_j2g_dyncf_A_const_26 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_27 any

var A_arbace_j2g_dyncf_A_const_28 *lang.Var

var A_arbace_j2g_dyncf_A_const_29 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_30 any

var A_arbace_j2g_dyncf_A_const_31 *lang.Var

var A_arbace_j2g_dyncf_A_const_32 any

var A_arbace_j2g_dyncf_A_const_33 any

var A_arbace_j2g_dyncf_A_const_34 *lang.Var

var A_arbace_j2g_dyncf_A_const_35 *lang.Var

var A_arbace_j2g_dyncf_A_const_36 any

var A_arbace_j2g_dyncf_A_const_37 *lang.Var

var A_arbace_j2g_dyncf_A_const_38 *lang.Var

var A_arbace_j2g_dyncf_A_const_39 *lang.Var

var A_arbace_j2g_dyncf_A_const_40 any

var A_arbace_j2g_dyncf_A_const_41 any

var A_arbace_j2g_dyncf_A_const_42 *lang.Var

var A_arbace_j2g_dyncf_A_const_43 any

var A_arbace_j2g_dyncf_A_const_44 any

var A_arbace_j2g_dyncf_A_const_45 any

var A_arbace_j2g_dyncf_A_const_46 any

var A_arbace_j2g_dyncf_A_const_47 any

var A_arbace_j2g_dyncf_A_const_48 *lang.Var

var A_arbace_j2g_dyncf_A_const_49 *lang.Var

var A_arbace_j2g_dyncf_A_const_50 any

var A_arbace_j2g_dyncf_A_const_51 *lang.Var

var A_arbace_j2g_dyncf_A_const_52 any

var A_arbace_j2g_dyncf_A_const_53 any

var A_arbace_j2g_dyncf_A_const_54 any

var A_arbace_j2g_dyncf_A_const_55 any

var A_arbace_j2g_dyncf_A_const_56 any

var A_arbace_j2g_dyncf_A_const_57 any

var A_arbace_j2g_dyncf_A_const_58 any

var A_arbace_j2g_dyncf_A_const_59 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_60 any

var A_arbace_j2g_dyncf_A_const_61 any

var A_arbace_j2g_dyncf_A_const_62 any

var A_arbace_j2g_dyncf_A_const_63 *lang.Var

var A_arbace_j2g_dyncf_A_const_64 any

var A_arbace_j2g_dyncf_A_const_65 any

var A_arbace_j2g_dyncf_A_const_66 *lang.Var

var A_arbace_j2g_dyncf_A_const_67 *lang.Var

var A_arbace_j2g_dyncf_A_const_68 *lang.Var

var A_arbace_j2g_dyncf_A_const_69 *lang.Var

var A_arbace_j2g_dyncf_A_const_70 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_71 *lang.Var

var A_arbace_j2g_dyncf_A_const_72 *lang.Var

var A_arbace_j2g_dyncf_A_const_73 *lang.Var

var A_arbace_j2g_dyncf_A_const_74 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_75 *lang.Var

var A_arbace_j2g_dyncf_A_const_76 *lang.Var

var A_arbace_j2g_dyncf_A_const_77 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_78 *lang.Var

var A_arbace_j2g_dyncf_A_const_79 *lang.Var

var A_arbace_j2g_dyncf_A_const_80 *lang.Var

var A_arbace_j2g_dyncf_A_const_81 *lang.Var

var A_arbace_j2g_dyncf_A_const_82 *lang.Var

var A_arbace_j2g_dyncf_A_const_83 any

var A_arbace_j2g_dyncf_A_const_84 any

var A_arbace_j2g_dyncf_A_const_85 any

var A_arbace_j2g_dyncf_A_const_86 any

var A_arbace_j2g_dyncf_A_const_87 any

var A_arbace_j2g_dyncf_A_const_88 any

var A_arbace_j2g_dyncf_A_const_89 any

var A_arbace_j2g_dyncf_A_const_90 any

var A_arbace_j2g_dyncf_A_const_91 *lang.Var

var A_arbace_j2g_dyncf_A_const_92 *lang.Var

var A_arbace_j2g_dyncf_A_const_93 any

var A_arbace_j2g_dyncf_A_const_94 any

var A_arbace_j2g_dyncf_A_const_95 any

var A_arbace_j2g_dyncf_A_const_96 any

var A_arbace_j2g_dyncf_A_const_97 any

var A_arbace_j2g_dyncf_A_const_98 *lang.Var

var A_arbace_j2g_dyncf_A_const_99 *lang.Var

var A_arbace_j2g_dyncf_A_const_100 *lang.Var

var A_arbace_j2g_dyncf_A_const_101 *lang.Var

var A_arbace_j2g_dyncf_A_const_102 *lang.Var

var A_arbace_j2g_dyncf_A_const_103 any

var A_arbace_j2g_dyncf_A_const_104 *lang.Var

var A_arbace_j2g_dyncf_A_const_105 *lang.Var

var A_arbace_j2g_dyncf_A_const_106 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_107 *lang.Var

var A_arbace_j2g_dyncf_A_const_108 any

var A_arbace_j2g_dyncf_A_const_109 any

var A_arbace_j2g_dyncf_A_const_110 any

var A_arbace_j2g_dyncf_A_const_111 any

var A_arbace_j2g_dyncf_A_const_112 *lang.Var

var A_arbace_j2g_dyncf_A_const_113 any

var A_arbace_j2g_dyncf_A_const_114 any

var A_arbace_j2g_dyncf_A_const_115 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_116 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_117 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_118 any

var A_arbace_j2g_dyncf_A_const_119 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_120 any

var A_arbace_j2g_dyncf_A_const_121 any

var A_arbace_j2g_dyncf_A_const_122 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_123 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_124 any

var A_arbace_j2g_dyncf_A_const_125 any

var A_arbace_j2g_dyncf_A_const_126 any

var A_arbace_j2g_dyncf_A_const_127 any

var A_arbace_j2g_dyncf_A_const_128 any

var A_arbace_j2g_dyncf_A_const_129 any

var A_arbace_j2g_dyncf_A_const_130 any

var A_arbace_j2g_dyncf_A_const_131 any

var A_arbace_j2g_dyncf_A_const_132 any

var A_arbace_j2g_dyncf_A_const_133 any

var A_arbace_j2g_dyncf_A_const_134 any

var A_arbace_j2g_dyncf_A_const_135 any

var A_arbace_j2g_dyncf_A_const_136 any

var A_arbace_j2g_dyncf_A_const_137 any

var A_arbace_j2g_dyncf_A_const_138 any

var A_arbace_j2g_dyncf_A_const_139 any

var A_arbace_j2g_dyncf_A_const_140 any

var A_arbace_j2g_dyncf_A_const_141 any

var A_arbace_j2g_dyncf_A_const_142 *lang.Var

var A_arbace_j2g_dyncf_A_const_143 *lang.Var

var A_arbace_j2g_dyncf_A_const_144 *lang.Var

var A_arbace_j2g_dyncf_A_const_145 *lang.Var

var A_arbace_j2g_dyncf_A_const_146 *lang.Var

var A_arbace_j2g_dyncf_A_const_147 *lang.Var

var A_arbace_j2g_dyncf_A_const_148 any

var A_arbace_j2g_dyncf_A_const_149 any

var A_arbace_j2g_dyncf_A_const_150 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_151 any

var A_arbace_j2g_dyncf_A_const_152 any

var A_arbace_j2g_dyncf_A_const_153 any

var A_arbace_j2g_dyncf_A_const_154 any

var A_arbace_j2g_dyncf_A_const_155 any

var A_arbace_j2g_dyncf_A_const_156 any

var A_arbace_j2g_dyncf_A_const_157 any

var A_arbace_j2g_dyncf_A_const_158 any

var A_arbace_j2g_dyncf_A_const_159 *lang.Var

var A_arbace_j2g_dyncf_A_const_160 any

var A_arbace_j2g_dyncf_A_const_161 any

var A_arbace_j2g_dyncf_A_const_162 any

var A_arbace_j2g_dyncf_A_const_163 any

var A_arbace_j2g_dyncf_A_const_164 any

var A_arbace_j2g_dyncf_A_const_165 any

var A_arbace_j2g_dyncf_A_const_166 *lang.Var

var A_arbace_j2g_dyncf_A_const_167 any

var A_arbace_j2g_dyncf_A_const_168 any

var A_arbace_j2g_dyncf_A_const_169 any

var A_arbace_j2g_dyncf_A_const_170 any

var A_arbace_j2g_dyncf_A_const_171 any

var A_arbace_j2g_dyncf_A_const_172 any

var A_arbace_j2g_dyncf_A_const_173 any

var A_arbace_j2g_dyncf_A_const_174 any

var A_arbace_j2g_dyncf_A_const_175 any

var A_arbace_j2g_dyncf_A_const_176 any

var A_arbace_j2g_dyncf_A_const_177 any

var A_arbace_j2g_dyncf_A_const_178 any

var A_arbace_j2g_dyncf_A_const_179 any

var A_arbace_j2g_dyncf_A_const_180 any

var A_arbace_j2g_dyncf_A_const_181 any

var A_arbace_j2g_dyncf_A_const_182 any

var A_arbace_j2g_dyncf_A_const_183 any

var A_arbace_j2g_dyncf_A_const_184 any

var A_arbace_j2g_dyncf_A_const_185 any

var A_arbace_j2g_dyncf_A_const_186 any

var A_arbace_j2g_dyncf_A_const_187 any

var A_arbace_j2g_dyncf_A_const_188 any

var A_arbace_j2g_dyncf_A_const_189 any

var A_arbace_j2g_dyncf_A_const_190 any

var A_arbace_j2g_dyncf_A_const_191 any

var A_arbace_j2g_dyncf_A_const_192 any

var A_arbace_j2g_dyncf_A_const_193 any

var A_arbace_j2g_dyncf_A_const_194 any

var A_arbace_j2g_dyncf_A_const_195 any

var A_arbace_j2g_dyncf_A_const_196 any

var A_arbace_j2g_dyncf_A_const_197 any

var A_arbace_j2g_dyncf_A_const_198 any

var A_arbace_j2g_dyncf_A_const_199 any

var A_arbace_j2g_dyncf_A_const_200 any

var A_arbace_j2g_dyncf_A_const_201 any

var A_arbace_j2g_dyncf_A_const_202 any

var A_arbace_j2g_dyncf_A_const_203 any

var A_arbace_j2g_dyncf_A_const_204 any

var A_arbace_j2g_dyncf_A_const_205 any

var A_arbace_j2g_dyncf_A_const_206 any

var A_arbace_j2g_dyncf_A_const_207 any

var A_arbace_j2g_dyncf_A_const_208 any

var A_arbace_j2g_dyncf_A_const_209 any

var A_arbace_j2g_dyncf_A_const_210 any

var A_arbace_j2g_dyncf_A_const_211 any

var A_arbace_j2g_dyncf_A_const_212 any

var A_arbace_j2g_dyncf_A_const_213 any

var A_arbace_j2g_dyncf_A_const_214 any

var A_arbace_j2g_dyncf_A_const_215 any

var A_arbace_j2g_dyncf_A_const_216 any

var A_arbace_j2g_dyncf_A_const_217 any

var A_arbace_j2g_dyncf_A_const_218 any

var A_arbace_j2g_dyncf_A_const_219 any

var A_arbace_j2g_dyncf_A_const_220 any

var A_arbace_j2g_dyncf_A_const_221 any

var A_arbace_j2g_dyncf_A_const_222 any

var A_arbace_j2g_dyncf_A_const_223 any

var A_arbace_j2g_dyncf_A_const_224 any

var A_arbace_j2g_dyncf_A_const_225 any

var A_arbace_j2g_dyncf_A_const_226 any

var A_arbace_j2g_dyncf_A_const_227 any

var A_arbace_j2g_dyncf_A_const_228 any

var A_arbace_j2g_dyncf_A_const_229 any

var A_arbace_j2g_dyncf_A_const_230 any

var A_arbace_j2g_dyncf_A_const_231 any

var A_arbace_j2g_dyncf_A_const_232 any

var A_arbace_j2g_dyncf_A_const_233 any

var A_arbace_j2g_dyncf_A_const_234 any

var A_arbace_j2g_dyncf_A_const_235 any

var A_arbace_j2g_dyncf_A_const_236 any

var A_arbace_j2g_dyncf_A_const_237 any

var A_arbace_j2g_dyncf_A_const_238 any

var A_arbace_j2g_dyncf_A_const_239 any

var A_arbace_j2g_dyncf_A_const_240 any

var A_arbace_j2g_dyncf_A_const_241 any

var A_arbace_j2g_dyncf_A_const_242 any

var A_arbace_j2g_dyncf_A_const_243 any

var A_arbace_j2g_dyncf_A_const_244 any

var A_arbace_j2g_dyncf_A_const_245 any

var A_arbace_j2g_dyncf_A_const_246 any

var A_arbace_j2g_dyncf_A_const_247 any

var A_arbace_j2g_dyncf_A_const_248 any

var A_arbace_j2g_dyncf_A_const_249 any

var A_arbace_j2g_dyncf_A_const_250 any

var A_arbace_j2g_dyncf_A_const_251 any

var A_arbace_j2g_dyncf_A_const_252 any

var A_arbace_j2g_dyncf_A_const_253 any

var A_arbace_j2g_dyncf_A_const_254 any

var A_arbace_j2g_dyncf_A_const_255 any

var A_arbace_j2g_dyncf_A_const_256 any

var A_arbace_j2g_dyncf_A_const_257 any

var A_arbace_j2g_dyncf_A_const_258 any

var A_arbace_j2g_dyncf_A_const_259 any

var A_arbace_j2g_dyncf_A_const_260 any

var A_arbace_j2g_dyncf_A_const_261 any

var A_arbace_j2g_dyncf_A_const_262 any

var A_arbace_j2g_dyncf_A_const_263 any

var A_arbace_j2g_dyncf_A_const_264 any

var A_arbace_j2g_dyncf_A_const_265 any

var A_arbace_j2g_dyncf_A_const_266 any

var A_arbace_j2g_dyncf_A_const_267 any

var A_arbace_j2g_dyncf_A_const_268 any

var A_arbace_j2g_dyncf_A_const_269 any

var A_arbace_j2g_dyncf_A_const_270 any

var A_arbace_j2g_dyncf_A_const_271 any

var A_arbace_j2g_dyncf_A_const_272 any

var A_arbace_j2g_dyncf_A_const_273 any

var A_arbace_j2g_dyncf_A_const_274 any

var A_arbace_j2g_dyncf_A_const_275 any

var A_arbace_j2g_dyncf_A_const_276 any

var A_arbace_j2g_dyncf_A_const_277 any

var A_arbace_j2g_dyncf_A_const_278 any

var A_arbace_j2g_dyncf_A_const_279 any

var A_arbace_j2g_dyncf_A_const_280 any

var A_arbace_j2g_dyncf_A_const_281 any

var A_arbace_j2g_dyncf_A_const_282 any

var A_arbace_j2g_dyncf_A_const_283 any

var A_arbace_j2g_dyncf_A_const_284 any

var A_arbace_j2g_dyncf_A_const_285 any

var A_arbace_j2g_dyncf_A_const_286 any

var A_arbace_j2g_dyncf_A_const_287 any

var A_arbace_j2g_dyncf_A_const_288 any

var A_arbace_j2g_dyncf_A_const_289 *lang.Var

var A_arbace_j2g_dyncf_A_const_290 *lang.Var

var A_arbace_j2g_dyncf_A_const_291 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_292 *lang.Var

var A_arbace_j2g_dyncf_A_const_293 *lang.Var

var A_arbace_j2g_dyncf_A_const_294 *lang.Var

var A_arbace_j2g_dyncf_A_const_295 any

var A_arbace_j2g_dyncf_A_const_296 any

var A_arbace_j2g_dyncf_A_const_297 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_298 *lang.Var

var A_arbace_j2g_dyncf_A_const_299 *lang.Var

var A_arbace_j2g_dyncf_A_const_300 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_301 *lang.Var

var A_arbace_j2g_dyncf_A_const_302 *lang.Var

var A_arbace_j2g_dyncf_A_const_303 *lang.Var

var A_arbace_j2g_dyncf_A_const_304 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_305 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_306 any

var A_arbace_j2g_dyncf_A_const_307 *lang.Var

var A_arbace_j2g_dyncf_A_const_308 *lang.Var

var A_arbace_j2g_dyncf_A_const_309 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_310 *lang.Var

var A_arbace_j2g_dyncf_A_const_311 *lang.Var

var A_arbace_j2g_dyncf_A_const_312 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_313 *lang.Var

var A_arbace_j2g_dyncf_A_const_314 any

var A_arbace_j2g_dyncf_A_const_315 any

var A_arbace_j2g_dyncf_A_const_316 any

var A_arbace_j2g_dyncf_A_const_317 any

var A_arbace_j2g_dyncf_A_const_318 any

var A_arbace_j2g_dyncf_A_const_319 *lang.Var

var A_arbace_j2g_dyncf_A_const_320 *lang.Var

var A_arbace_j2g_dyncf_A_const_321 *lang.Var

var A_arbace_j2g_dyncf_A_const_322 *lang.Var

var A_arbace_j2g_dyncf_A_const_323 *lang.Var

var A_arbace_j2g_dyncf_A_const_324 *lang.Var

var A_arbace_j2g_dyncf_A_init jrt.ClassInit

func A_arbace_j2g_dyncf_A_Init() { if !A_arbace_j2g_dyncf_A_init.Done() { A_arbace_j2g_dyncf_A_init.Run(A_arbace_j2g_dyncf_A_clinit) } }

func A_arbace_j2g_dyncf_A_clinit() { A_arbace_j2g_dyncf_A_clinit_p0(); A_arbace_j2g_dyncf_A_clinit_p1(); A_arbace_j2g_dyncf_A_clinit_p2(); A_arbace_j2g_dyncf_A_clinit_p3(); A_arbace_j2g_dyncf_A_clinit_p4(); A_arbace_j2g_dyncf_A_clinit_p5(); A_arbace_j2g_dyncf_A_clinit_p6(); A_arbace_j2g_dyncf_A_clinit_p7(); A_arbace_j2g_dyncf_A_clinit_p8(); A_arbace_j2g_dyncf_A_clinit_p9(); A_arbace_j2g_dyncf_A_clinit_p10(); A_arbace_j2g_dyncf_A_clinit_p11(); A_arbace_j2g_dyncf_A_clinit_p12(); A_arbace_j2g_dyncf_A_clinit_p13(); A_arbace_j2g_dyncf_A_clinit_p14(); A_arbace_j2g_dyncf_A_clinit_p15(); A_arbace_j2g_dyncf_A_clinit_p16(); A_arbace_j2g_dyncf_A_clinit_p17(); A_arbace_j2g_dyncf_A_clinit_p18(); A_arbace_j2g_dyncf_A_clinit_p19(); A_arbace_j2g_dyncf_A_clinit_p20(); A_arbace_j2g_dyncf_A_clinit_p21(); A_arbace_j2g_dyncf_A_clinit_p22() }

func A_arbace_j2g_dyncf_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyncf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 554); A_arbace_j2g_dyncf_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[229]); A_arbace_j2g_dyncf_A_const_1 = A_arbace_j2g_dyncf_A_const_pool.A[230]; A_arbace_j2g_dyncf_A_const_2 = A_arbace_j2g_dyncf_A_const_pool.A[231]; A_arbace_j2g_dyncf_A_const_3 = A_arbace_j2g_dyncf_A_const_pool.A[232]; A_arbace_j2g_dyncf_A_const_4 = A_arbace_j2g_dyncf_A_const_pool.A[233]; A_arbace_j2g_dyncf_A_const_5 = A_arbace_j2g_dyncf_A_const_pool.A[234]; A_arbace_j2g_dyncf_A_const_6 = A_arbace_j2g_dyncf_A_const_pool.A[235]; A_arbace_j2g_dyncf_A_const_7 = A_arbace_j2g_dyncf_A_const_pool.A[236]; A_arbace_j2g_dyncf_A_const_8 = A_arbace_j2g_dyncf_A_const_pool.A[237]; A_arbace_j2g_dyncf_A_const_9 = A_arbace_j2g_dyncf_A_const_pool.A[238]; A_arbace_j2g_dyncf_A_const_10 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[239]); A_arbace_j2g_dyncf_A_const_11 = A_arbace_j2g_dyncf_A_const_pool.A[240]; A_arbace_j2g_dyncf_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[241]) }

func A_arbace_j2g_dyncf_A_clinit_p1() { A_arbace_j2g_dyncf_A_const_13 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[242]); A_arbace_j2g_dyncf_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[243]); A_arbace_j2g_dyncf_A_const_15 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[244]); A_arbace_j2g_dyncf_A_const_16 = A_arbace_j2g_dyncf_A_const_pool.A[245]; A_arbace_j2g_dyncf_A_const_17 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[246]); A_arbace_j2g_dyncf_A_const_18 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[247]); A_arbace_j2g_dyncf_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[248]); A_arbace_j2g_dyncf_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[249]); A_arbace_j2g_dyncf_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[250]); A_arbace_j2g_dyncf_A_const_22 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[251]); A_arbace_j2g_dyncf_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[252]); A_arbace_j2g_dyncf_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[253]) }

func A_arbace_j2g_dyncf_A_clinit_p2() { A_arbace_j2g_dyncf_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[254]); A_arbace_j2g_dyncf_A_const_26 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[255]); A_arbace_j2g_dyncf_A_const_27 = A_arbace_j2g_dyncf_A_const_pool.A[256]; A_arbace_j2g_dyncf_A_const_28 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[257]); A_arbace_j2g_dyncf_A_const_29 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[258]); A_arbace_j2g_dyncf_A_const_30 = A_arbace_j2g_dyncf_A_const_pool.A[259]; A_arbace_j2g_dyncf_A_const_31 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[260]); A_arbace_j2g_dyncf_A_const_32 = A_arbace_j2g_dyncf_A_const_pool.A[261]; A_arbace_j2g_dyncf_A_const_33 = A_arbace_j2g_dyncf_A_const_pool.A[262]; A_arbace_j2g_dyncf_A_const_34 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[263]); A_arbace_j2g_dyncf_A_const_35 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[264]); A_arbace_j2g_dyncf_A_const_36 = A_arbace_j2g_dyncf_A_const_pool.A[265]; A_arbace_j2g_dyncf_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[266]) }

func A_arbace_j2g_dyncf_A_clinit_p3() { A_arbace_j2g_dyncf_A_const_38 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[267]); A_arbace_j2g_dyncf_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[268]); A_arbace_j2g_dyncf_A_const_40 = A_arbace_j2g_dyncf_A_const_pool.A[269]; A_arbace_j2g_dyncf_A_const_41 = A_arbace_j2g_dyncf_A_const_pool.A[270]; A_arbace_j2g_dyncf_A_const_42 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[271]); A_arbace_j2g_dyncf_A_const_43 = A_arbace_j2g_dyncf_A_const_pool.A[272]; A_arbace_j2g_dyncf_A_const_44 = A_arbace_j2g_dyncf_A_const_pool.A[273]; A_arbace_j2g_dyncf_A_const_45 = A_arbace_j2g_dyncf_A_const_pool.A[274]; A_arbace_j2g_dyncf_A_const_46 = A_arbace_j2g_dyncf_A_const_pool.A[275]; A_arbace_j2g_dyncf_A_const_47 = A_arbace_j2g_dyncf_A_const_pool.A[276]; A_arbace_j2g_dyncf_A_const_48 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[277]); A_arbace_j2g_dyncf_A_const_49 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[278]); A_arbace_j2g_dyncf_A_const_50 = A_arbace_j2g_dyncf_A_const_pool.A[279]; A_arbace_j2g_dyncf_A_const_51 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[280]) }

func A_arbace_j2g_dyncf_A_clinit_p4() { A_arbace_j2g_dyncf_A_const_52 = A_arbace_j2g_dyncf_A_const_pool.A[281]; A_arbace_j2g_dyncf_A_const_53 = A_arbace_j2g_dyncf_A_const_pool.A[282]; A_arbace_j2g_dyncf_A_const_54 = A_arbace_j2g_dyncf_A_const_pool.A[283]; A_arbace_j2g_dyncf_A_const_55 = A_arbace_j2g_dyncf_A_const_pool.A[284]; A_arbace_j2g_dyncf_A_const_56 = A_arbace_j2g_dyncf_A_const_pool.A[285]; A_arbace_j2g_dyncf_A_const_57 = A_arbace_j2g_dyncf_A_const_pool.A[286]; A_arbace_j2g_dyncf_A_const_58 = A_arbace_j2g_dyncf_A_const_pool.A[287]; A_arbace_j2g_dyncf_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[288]); A_arbace_j2g_dyncf_A_const_60 = A_arbace_j2g_dyncf_A_const_pool.A[289]; A_arbace_j2g_dyncf_A_const_61 = A_arbace_j2g_dyncf_A_const_pool.A[290]; A_arbace_j2g_dyncf_A_const_62 = A_arbace_j2g_dyncf_A_const_pool.A[291]; A_arbace_j2g_dyncf_A_const_63 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[292]); A_arbace_j2g_dyncf_A_const_64 = A_arbace_j2g_dyncf_A_const_pool.A[293]; A_arbace_j2g_dyncf_A_const_65 = A_arbace_j2g_dyncf_A_const_pool.A[294]; A_arbace_j2g_dyncf_A_const_66 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[295]) }

func A_arbace_j2g_dyncf_A_clinit_p5() { A_arbace_j2g_dyncf_A_const_67 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[296]); A_arbace_j2g_dyncf_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[297]); A_arbace_j2g_dyncf_A_const_69 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[298]); A_arbace_j2g_dyncf_A_const_70 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[299]); A_arbace_j2g_dyncf_A_const_71 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[300]); A_arbace_j2g_dyncf_A_const_72 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[301]); A_arbace_j2g_dyncf_A_const_73 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[302]); A_arbace_j2g_dyncf_A_const_74 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[303]); A_arbace_j2g_dyncf_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[304]); A_arbace_j2g_dyncf_A_const_76 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[305]); A_arbace_j2g_dyncf_A_const_77 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[306]); A_arbace_j2g_dyncf_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[307]) }

func A_arbace_j2g_dyncf_A_clinit_p6() { A_arbace_j2g_dyncf_A_const_79 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[308]); A_arbace_j2g_dyncf_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[309]); A_arbace_j2g_dyncf_A_const_81 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[310]); A_arbace_j2g_dyncf_A_const_82 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[311]); A_arbace_j2g_dyncf_A_const_83 = A_arbace_j2g_dyncf_A_const_pool.A[312]; A_arbace_j2g_dyncf_A_const_84 = A_arbace_j2g_dyncf_A_const_pool.A[313]; A_arbace_j2g_dyncf_A_const_85 = A_arbace_j2g_dyncf_A_const_pool.A[314]; A_arbace_j2g_dyncf_A_const_86 = A_arbace_j2g_dyncf_A_const_pool.A[315]; A_arbace_j2g_dyncf_A_const_87 = A_arbace_j2g_dyncf_A_const_pool.A[316]; A_arbace_j2g_dyncf_A_const_88 = A_arbace_j2g_dyncf_A_const_pool.A[317]; A_arbace_j2g_dyncf_A_const_89 = A_arbace_j2g_dyncf_A_const_pool.A[318]; A_arbace_j2g_dyncf_A_const_90 = A_arbace_j2g_dyncf_A_const_pool.A[319]; A_arbace_j2g_dyncf_A_const_91 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[320]); A_arbace_j2g_dyncf_A_const_92 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[321]) }

func A_arbace_j2g_dyncf_A_clinit_p7() { A_arbace_j2g_dyncf_A_const_93 = A_arbace_j2g_dyncf_A_const_pool.A[322]; A_arbace_j2g_dyncf_A_const_94 = A_arbace_j2g_dyncf_A_const_pool.A[323]; A_arbace_j2g_dyncf_A_const_95 = A_arbace_j2g_dyncf_A_const_pool.A[324]; A_arbace_j2g_dyncf_A_const_96 = A_arbace_j2g_dyncf_A_const_pool.A[325]; A_arbace_j2g_dyncf_A_const_97 = A_arbace_j2g_dyncf_A_const_pool.A[326]; A_arbace_j2g_dyncf_A_const_98 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[327]); A_arbace_j2g_dyncf_A_const_99 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[328]); A_arbace_j2g_dyncf_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[329]); A_arbace_j2g_dyncf_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[330]); A_arbace_j2g_dyncf_A_const_102 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[331]); A_arbace_j2g_dyncf_A_const_103 = A_arbace_j2g_dyncf_A_const_pool.A[332]; A_arbace_j2g_dyncf_A_const_104 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[333]); A_arbace_j2g_dyncf_A_const_105 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[334]) }

func A_arbace_j2g_dyncf_A_clinit_p8() { A_arbace_j2g_dyncf_A_const_106 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[335]); A_arbace_j2g_dyncf_A_const_107 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[336]); A_arbace_j2g_dyncf_A_const_108 = A_arbace_j2g_dyncf_A_const_pool.A[337]; A_arbace_j2g_dyncf_A_const_109 = A_arbace_j2g_dyncf_A_const_pool.A[338]; A_arbace_j2g_dyncf_A_const_110 = A_arbace_j2g_dyncf_A_const_pool.A[339]; A_arbace_j2g_dyncf_A_const_111 = A_arbace_j2g_dyncf_A_const_pool.A[340]; A_arbace_j2g_dyncf_A_const_112 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[341]); A_arbace_j2g_dyncf_A_const_113 = A_arbace_j2g_dyncf_A_const_pool.A[342]; A_arbace_j2g_dyncf_A_const_114 = A_arbace_j2g_dyncf_A_const_pool.A[343]; A_arbace_j2g_dyncf_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[344]); A_arbace_j2g_dyncf_A_const_116 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[345]); A_arbace_j2g_dyncf_A_const_117 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[346]); A_arbace_j2g_dyncf_A_const_118 = A_arbace_j2g_dyncf_A_const_pool.A[347] }

func A_arbace_j2g_dyncf_A_clinit_p9() { A_arbace_j2g_dyncf_A_const_119 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[348]); A_arbace_j2g_dyncf_A_const_120 = A_arbace_j2g_dyncf_A_const_pool.A[349]; A_arbace_j2g_dyncf_A_const_121 = A_arbace_j2g_dyncf_A_const_pool.A[350]; A_arbace_j2g_dyncf_A_const_122 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[351]); A_arbace_j2g_dyncf_A_const_123 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[352]); A_arbace_j2g_dyncf_A_const_124 = A_arbace_j2g_dyncf_A_const_pool.A[353]; A_arbace_j2g_dyncf_A_const_125 = A_arbace_j2g_dyncf_A_const_pool.A[354]; A_arbace_j2g_dyncf_A_const_126 = A_arbace_j2g_dyncf_A_const_pool.A[355]; A_arbace_j2g_dyncf_A_const_127 = A_arbace_j2g_dyncf_A_const_pool.A[356]; A_arbace_j2g_dyncf_A_const_128 = A_arbace_j2g_dyncf_A_const_pool.A[357]; A_arbace_j2g_dyncf_A_const_129 = A_arbace_j2g_dyncf_A_const_pool.A[358]; A_arbace_j2g_dyncf_A_const_130 = A_arbace_j2g_dyncf_A_const_pool.A[359]; A_arbace_j2g_dyncf_A_const_131 = A_arbace_j2g_dyncf_A_const_pool.A[360]; A_arbace_j2g_dyncf_A_const_132 = A_arbace_j2g_dyncf_A_const_pool.A[361]; A_arbace_j2g_dyncf_A_const_133 = A_arbace_j2g_dyncf_A_const_pool.A[362] }

func A_arbace_j2g_dyncf_A_clinit_p10() { A_arbace_j2g_dyncf_A_const_134 = A_arbace_j2g_dyncf_A_const_pool.A[363]; A_arbace_j2g_dyncf_A_const_135 = A_arbace_j2g_dyncf_A_const_pool.A[364]; A_arbace_j2g_dyncf_A_const_136 = A_arbace_j2g_dyncf_A_const_pool.A[365]; A_arbace_j2g_dyncf_A_const_137 = A_arbace_j2g_dyncf_A_const_pool.A[366]; A_arbace_j2g_dyncf_A_const_138 = A_arbace_j2g_dyncf_A_const_pool.A[367]; A_arbace_j2g_dyncf_A_const_139 = A_arbace_j2g_dyncf_A_const_pool.A[368]; A_arbace_j2g_dyncf_A_const_140 = A_arbace_j2g_dyncf_A_const_pool.A[369]; A_arbace_j2g_dyncf_A_const_141 = A_arbace_j2g_dyncf_A_const_pool.A[370]; A_arbace_j2g_dyncf_A_const_142 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[371]); A_arbace_j2g_dyncf_A_const_143 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[372]); A_arbace_j2g_dyncf_A_const_144 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[373]); A_arbace_j2g_dyncf_A_const_145 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[374]); A_arbace_j2g_dyncf_A_const_146 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[375]); A_arbace_j2g_dyncf_A_const_147 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[376]) }

func A_arbace_j2g_dyncf_A_clinit_p11() { A_arbace_j2g_dyncf_A_const_148 = A_arbace_j2g_dyncf_A_const_pool.A[377]; A_arbace_j2g_dyncf_A_const_149 = A_arbace_j2g_dyncf_A_const_pool.A[378]; A_arbace_j2g_dyncf_A_const_150 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[379]); A_arbace_j2g_dyncf_A_const_151 = A_arbace_j2g_dyncf_A_const_pool.A[380]; A_arbace_j2g_dyncf_A_const_152 = A_arbace_j2g_dyncf_A_const_pool.A[381]; A_arbace_j2g_dyncf_A_const_153 = A_arbace_j2g_dyncf_A_const_pool.A[382]; A_arbace_j2g_dyncf_A_const_154 = A_arbace_j2g_dyncf_A_const_pool.A[383]; A_arbace_j2g_dyncf_A_const_155 = A_arbace_j2g_dyncf_A_const_pool.A[384]; A_arbace_j2g_dyncf_A_const_156 = A_arbace_j2g_dyncf_A_const_pool.A[385]; A_arbace_j2g_dyncf_A_const_157 = A_arbace_j2g_dyncf_A_const_pool.A[386]; A_arbace_j2g_dyncf_A_const_158 = A_arbace_j2g_dyncf_A_const_pool.A[387]; A_arbace_j2g_dyncf_A_const_159 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[388]); A_arbace_j2g_dyncf_A_const_160 = A_arbace_j2g_dyncf_A_const_pool.A[389]; A_arbace_j2g_dyncf_A_const_161 = A_arbace_j2g_dyncf_A_const_pool.A[390]; A_arbace_j2g_dyncf_A_const_162 = A_arbace_j2g_dyncf_A_const_pool.A[391] }

func A_arbace_j2g_dyncf_A_clinit_p12() { A_arbace_j2g_dyncf_A_const_163 = A_arbace_j2g_dyncf_A_const_pool.A[392]; A_arbace_j2g_dyncf_A_const_164 = A_arbace_j2g_dyncf_A_const_pool.A[393]; A_arbace_j2g_dyncf_A_const_165 = A_arbace_j2g_dyncf_A_const_pool.A[394]; A_arbace_j2g_dyncf_A_const_166 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[395]); A_arbace_j2g_dyncf_A_const_167 = A_arbace_j2g_dyncf_A_const_pool.A[396]; A_arbace_j2g_dyncf_A_const_168 = A_arbace_j2g_dyncf_A_const_pool.A[397]; A_arbace_j2g_dyncf_A_const_169 = A_arbace_j2g_dyncf_A_const_pool.A[398]; A_arbace_j2g_dyncf_A_const_170 = A_arbace_j2g_dyncf_A_const_pool.A[399]; A_arbace_j2g_dyncf_A_const_171 = A_arbace_j2g_dyncf_A_const_pool.A[400]; A_arbace_j2g_dyncf_A_const_172 = A_arbace_j2g_dyncf_A_const_pool.A[401]; A_arbace_j2g_dyncf_A_const_173 = A_arbace_j2g_dyncf_A_const_pool.A[402]; A_arbace_j2g_dyncf_A_const_174 = A_arbace_j2g_dyncf_A_const_pool.A[403]; A_arbace_j2g_dyncf_A_const_175 = A_arbace_j2g_dyncf_A_const_pool.A[404]; A_arbace_j2g_dyncf_A_const_176 = A_arbace_j2g_dyncf_A_const_pool.A[405]; A_arbace_j2g_dyncf_A_const_177 = A_arbace_j2g_dyncf_A_const_pool.A[406] }

func A_arbace_j2g_dyncf_A_clinit_p13() { A_arbace_j2g_dyncf_A_const_178 = A_arbace_j2g_dyncf_A_const_pool.A[407]; A_arbace_j2g_dyncf_A_const_179 = A_arbace_j2g_dyncf_A_const_pool.A[408]; A_arbace_j2g_dyncf_A_const_180 = A_arbace_j2g_dyncf_A_const_pool.A[409]; A_arbace_j2g_dyncf_A_const_181 = A_arbace_j2g_dyncf_A_const_pool.A[410]; A_arbace_j2g_dyncf_A_const_182 = A_arbace_j2g_dyncf_A_const_pool.A[411]; A_arbace_j2g_dyncf_A_const_183 = A_arbace_j2g_dyncf_A_const_pool.A[412]; A_arbace_j2g_dyncf_A_const_184 = A_arbace_j2g_dyncf_A_const_pool.A[413]; A_arbace_j2g_dyncf_A_const_185 = A_arbace_j2g_dyncf_A_const_pool.A[414]; A_arbace_j2g_dyncf_A_const_186 = A_arbace_j2g_dyncf_A_const_pool.A[415]; A_arbace_j2g_dyncf_A_const_187 = A_arbace_j2g_dyncf_A_const_pool.A[416]; A_arbace_j2g_dyncf_A_const_188 = A_arbace_j2g_dyncf_A_const_pool.A[417]; A_arbace_j2g_dyncf_A_const_189 = A_arbace_j2g_dyncf_A_const_pool.A[418]; A_arbace_j2g_dyncf_A_const_190 = A_arbace_j2g_dyncf_A_const_pool.A[419]; A_arbace_j2g_dyncf_A_const_191 = A_arbace_j2g_dyncf_A_const_pool.A[420]; A_arbace_j2g_dyncf_A_const_192 = A_arbace_j2g_dyncf_A_const_pool.A[421]; A_arbace_j2g_dyncf_A_const_193 = A_arbace_j2g_dyncf_A_const_pool.A[422] }

func A_arbace_j2g_dyncf_A_clinit_p14() { A_arbace_j2g_dyncf_A_const_194 = A_arbace_j2g_dyncf_A_const_pool.A[423]; A_arbace_j2g_dyncf_A_const_195 = A_arbace_j2g_dyncf_A_const_pool.A[424]; A_arbace_j2g_dyncf_A_const_196 = A_arbace_j2g_dyncf_A_const_pool.A[425]; A_arbace_j2g_dyncf_A_const_197 = A_arbace_j2g_dyncf_A_const_pool.A[426]; A_arbace_j2g_dyncf_A_const_198 = A_arbace_j2g_dyncf_A_const_pool.A[427]; A_arbace_j2g_dyncf_A_const_199 = A_arbace_j2g_dyncf_A_const_pool.A[428]; A_arbace_j2g_dyncf_A_const_200 = A_arbace_j2g_dyncf_A_const_pool.A[429]; A_arbace_j2g_dyncf_A_const_201 = A_arbace_j2g_dyncf_A_const_pool.A[430]; A_arbace_j2g_dyncf_A_const_202 = A_arbace_j2g_dyncf_A_const_pool.A[431]; A_arbace_j2g_dyncf_A_const_203 = A_arbace_j2g_dyncf_A_const_pool.A[432]; A_arbace_j2g_dyncf_A_const_204 = A_arbace_j2g_dyncf_A_const_pool.A[433]; A_arbace_j2g_dyncf_A_const_205 = A_arbace_j2g_dyncf_A_const_pool.A[434]; A_arbace_j2g_dyncf_A_const_206 = A_arbace_j2g_dyncf_A_const_pool.A[435]; A_arbace_j2g_dyncf_A_const_207 = A_arbace_j2g_dyncf_A_const_pool.A[436]; A_arbace_j2g_dyncf_A_const_208 = A_arbace_j2g_dyncf_A_const_pool.A[437]; A_arbace_j2g_dyncf_A_const_209 = A_arbace_j2g_dyncf_A_const_pool.A[438] }

func A_arbace_j2g_dyncf_A_clinit_p15() { A_arbace_j2g_dyncf_A_const_210 = A_arbace_j2g_dyncf_A_const_pool.A[439]; A_arbace_j2g_dyncf_A_const_211 = A_arbace_j2g_dyncf_A_const_pool.A[440]; A_arbace_j2g_dyncf_A_const_212 = A_arbace_j2g_dyncf_A_const_pool.A[441]; A_arbace_j2g_dyncf_A_const_213 = A_arbace_j2g_dyncf_A_const_pool.A[442]; A_arbace_j2g_dyncf_A_const_214 = A_arbace_j2g_dyncf_A_const_pool.A[443]; A_arbace_j2g_dyncf_A_const_215 = A_arbace_j2g_dyncf_A_const_pool.A[444]; A_arbace_j2g_dyncf_A_const_216 = A_arbace_j2g_dyncf_A_const_pool.A[445]; A_arbace_j2g_dyncf_A_const_217 = A_arbace_j2g_dyncf_A_const_pool.A[446]; A_arbace_j2g_dyncf_A_const_218 = A_arbace_j2g_dyncf_A_const_pool.A[447]; A_arbace_j2g_dyncf_A_const_219 = A_arbace_j2g_dyncf_A_const_pool.A[448]; A_arbace_j2g_dyncf_A_const_220 = A_arbace_j2g_dyncf_A_const_pool.A[449]; A_arbace_j2g_dyncf_A_const_221 = A_arbace_j2g_dyncf_A_const_pool.A[450]; A_arbace_j2g_dyncf_A_const_222 = A_arbace_j2g_dyncf_A_const_pool.A[451]; A_arbace_j2g_dyncf_A_const_223 = A_arbace_j2g_dyncf_A_const_pool.A[452]; A_arbace_j2g_dyncf_A_const_224 = A_arbace_j2g_dyncf_A_const_pool.A[453]; A_arbace_j2g_dyncf_A_const_225 = A_arbace_j2g_dyncf_A_const_pool.A[454] }

func A_arbace_j2g_dyncf_A_clinit_p16() { A_arbace_j2g_dyncf_A_const_226 = A_arbace_j2g_dyncf_A_const_pool.A[455]; A_arbace_j2g_dyncf_A_const_227 = A_arbace_j2g_dyncf_A_const_pool.A[456]; A_arbace_j2g_dyncf_A_const_228 = A_arbace_j2g_dyncf_A_const_pool.A[457]; A_arbace_j2g_dyncf_A_const_229 = A_arbace_j2g_dyncf_A_const_pool.A[458]; A_arbace_j2g_dyncf_A_const_230 = A_arbace_j2g_dyncf_A_const_pool.A[459]; A_arbace_j2g_dyncf_A_const_231 = A_arbace_j2g_dyncf_A_const_pool.A[460]; A_arbace_j2g_dyncf_A_const_232 = A_arbace_j2g_dyncf_A_const_pool.A[461]; A_arbace_j2g_dyncf_A_const_233 = A_arbace_j2g_dyncf_A_const_pool.A[462]; A_arbace_j2g_dyncf_A_const_234 = A_arbace_j2g_dyncf_A_const_pool.A[463]; A_arbace_j2g_dyncf_A_const_235 = A_arbace_j2g_dyncf_A_const_pool.A[464]; A_arbace_j2g_dyncf_A_const_236 = A_arbace_j2g_dyncf_A_const_pool.A[465]; A_arbace_j2g_dyncf_A_const_237 = A_arbace_j2g_dyncf_A_const_pool.A[466]; A_arbace_j2g_dyncf_A_const_238 = A_arbace_j2g_dyncf_A_const_pool.A[467]; A_arbace_j2g_dyncf_A_const_239 = A_arbace_j2g_dyncf_A_const_pool.A[468]; A_arbace_j2g_dyncf_A_const_240 = A_arbace_j2g_dyncf_A_const_pool.A[469]; A_arbace_j2g_dyncf_A_const_241 = A_arbace_j2g_dyncf_A_const_pool.A[470] }

func A_arbace_j2g_dyncf_A_clinit_p17() { A_arbace_j2g_dyncf_A_const_242 = A_arbace_j2g_dyncf_A_const_pool.A[471]; A_arbace_j2g_dyncf_A_const_243 = A_arbace_j2g_dyncf_A_const_pool.A[472]; A_arbace_j2g_dyncf_A_const_244 = A_arbace_j2g_dyncf_A_const_pool.A[473]; A_arbace_j2g_dyncf_A_const_245 = A_arbace_j2g_dyncf_A_const_pool.A[474]; A_arbace_j2g_dyncf_A_const_246 = A_arbace_j2g_dyncf_A_const_pool.A[475]; A_arbace_j2g_dyncf_A_const_247 = A_arbace_j2g_dyncf_A_const_pool.A[476]; A_arbace_j2g_dyncf_A_const_248 = A_arbace_j2g_dyncf_A_const_pool.A[477]; A_arbace_j2g_dyncf_A_const_249 = A_arbace_j2g_dyncf_A_const_pool.A[478]; A_arbace_j2g_dyncf_A_const_250 = A_arbace_j2g_dyncf_A_const_pool.A[479]; A_arbace_j2g_dyncf_A_const_251 = A_arbace_j2g_dyncf_A_const_pool.A[480]; A_arbace_j2g_dyncf_A_const_252 = A_arbace_j2g_dyncf_A_const_pool.A[481]; A_arbace_j2g_dyncf_A_const_253 = A_arbace_j2g_dyncf_A_const_pool.A[482]; A_arbace_j2g_dyncf_A_const_254 = A_arbace_j2g_dyncf_A_const_pool.A[483]; A_arbace_j2g_dyncf_A_const_255 = A_arbace_j2g_dyncf_A_const_pool.A[484]; A_arbace_j2g_dyncf_A_const_256 = A_arbace_j2g_dyncf_A_const_pool.A[485]; A_arbace_j2g_dyncf_A_const_257 = A_arbace_j2g_dyncf_A_const_pool.A[486] }

func A_arbace_j2g_dyncf_A_clinit_p18() { A_arbace_j2g_dyncf_A_const_258 = A_arbace_j2g_dyncf_A_const_pool.A[487]; A_arbace_j2g_dyncf_A_const_259 = A_arbace_j2g_dyncf_A_const_pool.A[488]; A_arbace_j2g_dyncf_A_const_260 = A_arbace_j2g_dyncf_A_const_pool.A[489]; A_arbace_j2g_dyncf_A_const_261 = A_arbace_j2g_dyncf_A_const_pool.A[490]; A_arbace_j2g_dyncf_A_const_262 = A_arbace_j2g_dyncf_A_const_pool.A[491]; A_arbace_j2g_dyncf_A_const_263 = A_arbace_j2g_dyncf_A_const_pool.A[492]; A_arbace_j2g_dyncf_A_const_264 = A_arbace_j2g_dyncf_A_const_pool.A[493]; A_arbace_j2g_dyncf_A_const_265 = A_arbace_j2g_dyncf_A_const_pool.A[494]; A_arbace_j2g_dyncf_A_const_266 = A_arbace_j2g_dyncf_A_const_pool.A[495]; A_arbace_j2g_dyncf_A_const_267 = A_arbace_j2g_dyncf_A_const_pool.A[496]; A_arbace_j2g_dyncf_A_const_268 = A_arbace_j2g_dyncf_A_const_pool.A[497]; A_arbace_j2g_dyncf_A_const_269 = A_arbace_j2g_dyncf_A_const_pool.A[498]; A_arbace_j2g_dyncf_A_const_270 = A_arbace_j2g_dyncf_A_const_pool.A[499]; A_arbace_j2g_dyncf_A_const_271 = A_arbace_j2g_dyncf_A_const_pool.A[500]; A_arbace_j2g_dyncf_A_const_272 = A_arbace_j2g_dyncf_A_const_pool.A[501]; A_arbace_j2g_dyncf_A_const_273 = A_arbace_j2g_dyncf_A_const_pool.A[502] }

func A_arbace_j2g_dyncf_A_clinit_p19() { A_arbace_j2g_dyncf_A_const_274 = A_arbace_j2g_dyncf_A_const_pool.A[503]; A_arbace_j2g_dyncf_A_const_275 = A_arbace_j2g_dyncf_A_const_pool.A[504]; A_arbace_j2g_dyncf_A_const_276 = A_arbace_j2g_dyncf_A_const_pool.A[505]; A_arbace_j2g_dyncf_A_const_277 = A_arbace_j2g_dyncf_A_const_pool.A[506]; A_arbace_j2g_dyncf_A_const_278 = A_arbace_j2g_dyncf_A_const_pool.A[507]; A_arbace_j2g_dyncf_A_const_279 = A_arbace_j2g_dyncf_A_const_pool.A[508]; A_arbace_j2g_dyncf_A_const_280 = A_arbace_j2g_dyncf_A_const_pool.A[509]; A_arbace_j2g_dyncf_A_const_281 = A_arbace_j2g_dyncf_A_const_pool.A[510]; A_arbace_j2g_dyncf_A_const_282 = A_arbace_j2g_dyncf_A_const_pool.A[511]; A_arbace_j2g_dyncf_A_const_283 = A_arbace_j2g_dyncf_A_const_pool.A[512]; A_arbace_j2g_dyncf_A_const_284 = A_arbace_j2g_dyncf_A_const_pool.A[513]; A_arbace_j2g_dyncf_A_const_285 = A_arbace_j2g_dyncf_A_const_pool.A[514]; A_arbace_j2g_dyncf_A_const_286 = A_arbace_j2g_dyncf_A_const_pool.A[515]; A_arbace_j2g_dyncf_A_const_287 = A_arbace_j2g_dyncf_A_const_pool.A[516]; A_arbace_j2g_dyncf_A_const_288 = A_arbace_j2g_dyncf_A_const_pool.A[517] }

func A_arbace_j2g_dyncf_A_clinit_p20() { A_arbace_j2g_dyncf_A_const_289 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[518]); A_arbace_j2g_dyncf_A_const_290 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[519]); A_arbace_j2g_dyncf_A_const_291 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[520]); A_arbace_j2g_dyncf_A_const_292 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[521]); A_arbace_j2g_dyncf_A_const_293 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[522]); A_arbace_j2g_dyncf_A_const_294 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[523]); A_arbace_j2g_dyncf_A_const_295 = A_arbace_j2g_dyncf_A_const_pool.A[524]; A_arbace_j2g_dyncf_A_const_296 = A_arbace_j2g_dyncf_A_const_pool.A[525]; A_arbace_j2g_dyncf_A_const_297 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[526]); A_arbace_j2g_dyncf_A_const_298 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[527]); A_arbace_j2g_dyncf_A_const_299 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[528]); A_arbace_j2g_dyncf_A_const_300 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[529]) }

func A_arbace_j2g_dyncf_A_clinit_p21() { A_arbace_j2g_dyncf_A_const_301 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[530]); A_arbace_j2g_dyncf_A_const_302 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[531]); A_arbace_j2g_dyncf_A_const_303 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[532]); A_arbace_j2g_dyncf_A_const_304 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[533]); A_arbace_j2g_dyncf_A_const_305 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[534]); A_arbace_j2g_dyncf_A_const_306 = A_arbace_j2g_dyncf_A_const_pool.A[535]; A_arbace_j2g_dyncf_A_const_307 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[536]); A_arbace_j2g_dyncf_A_const_308 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[537]); A_arbace_j2g_dyncf_A_const_309 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[538]); A_arbace_j2g_dyncf_A_const_310 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[539]); A_arbace_j2g_dyncf_A_const_311 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[540]); A_arbace_j2g_dyncf_A_const_312 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[541]) }

func A_arbace_j2g_dyncf_A_clinit_p22() { A_arbace_j2g_dyncf_A_const_313 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[542]); A_arbace_j2g_dyncf_A_const_314 = A_arbace_j2g_dyncf_A_const_pool.A[543]; A_arbace_j2g_dyncf_A_const_315 = A_arbace_j2g_dyncf_A_const_pool.A[544]; A_arbace_j2g_dyncf_A_const_316 = A_arbace_j2g_dyncf_A_const_pool.A[545]; A_arbace_j2g_dyncf_A_const_317 = A_arbace_j2g_dyncf_A_const_pool.A[546]; A_arbace_j2g_dyncf_A_const_318 = A_arbace_j2g_dyncf_A_const_pool.A[547]; A_arbace_j2g_dyncf_A_const_319 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[548]); A_arbace_j2g_dyncf_A_const_320 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[549]); A_arbace_j2g_dyncf_A_const_321 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[550]); A_arbace_j2g_dyncf_A_const_322 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[551]); A_arbace_j2g_dyncf_A_const_323 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[552]); A_arbace_j2g_dyncf_A_const_324 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[553]) }

func A_arbace_j2g_dyncf_A_New() *A_arbace_j2g_dyncf_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_A_class }

func (t *A_arbace_j2g_dyncf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_A); return ok }

func A_arbace_j2g_dyncf_A_Cast(x any) *A_arbace_j2g_dyncf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_A_class)) }; return v }



type A_arbace_j2g_dyncf_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000004_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000004_A_New() *A_arbace_j2g_dyncf_eval292000004_A { t := &A_arbace_j2g_dyncf_eval292000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000004_A_class }

func (t *A_arbace_j2g_dyncf_eval292000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); return ok }

func A_arbace_j2g_dyncf_eval292000004_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000004_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000008_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000008_A_New() *A_arbace_j2g_dyncf_eval292000008_A { t := &A_arbace_j2g_dyncf_eval292000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000008_A_class }

func (t *A_arbace_j2g_dyncf_eval292000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); return ok }

func A_arbace_j2g_dyncf_eval292000008_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000008_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000008_fn__292000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_from_object_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_from_object_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A struct{ j2g_header uint64; F_extendable any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A struct{ j2g_header uint64; F_iter__292000093, F_s__292000094, F_extendable any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A struct{ j2g_header uint64; F_b__292000096, F_extendable any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A struct{ j2g_header uint64; F_iter__292000103, F_s__292000104 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A struct{ j2g_header uint64; F_b__292000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A struct{ j2g_header uint64; F_iter__292000113, F_s__292000114 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A struct{ j2g_header uint64; F_b__292000116 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A struct{ j2g_header uint64; F_iter__292000127, F_s__292000128 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A struct{ j2g_header uint64; F_b__292000130 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A struct{ j2g_header uint64; F_iter__292000137, F_s__292000138 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A struct{ j2g_header uint64; F_b__292000140 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A struct{ j2g_header uint64; F_s__292000150, F_iter__292000149 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A struct{ j2g_header uint64; F_b__292000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_fn__292000090_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000017, F_s__292000018 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A struct{ j2g_header uint64; F_b__292000020, F_recv, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000043, F_s__292000044 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A struct{ j2g_header uint64; F_recv, F_b__292000046, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A struct{ j2g_header uint64; F_iter__292000078, F_s__292000079 any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A struct{ j2g_header uint64; F_b__292000081 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_tag_A_fn_class *jrt.Class
