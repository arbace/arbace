//line aot_arbace_j2g_dyncf.ae:1
package aot_arbace_j2g_dyncf

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_dyn"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/aot_arbace_walk"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_New() *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyncf_A_const_13); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_1, A_arbace_j2g_dyncf_A_const_2, A_arbace_j2g_dyncf_A_const_3, A_arbace_j2g_dyncf_A_const_4, A_arbace_j2g_dyncf_A_const_5, A_arbace_j2g_dyncf_A_const_6, A_arbace_j2g_dyncf_A_const_7, A_arbace_j2g_dyncf_A_const_8, A_arbace_j2g_dyncf_A_const_9, A_arbace_j2g_dyncf_A_const_10, A_arbace_j2g_dyncf_A_const_11); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_New() *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000008_fn__292000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_14.GetRawRoot__O()); var tmp2 any; var root_25 any = A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_j2g_dyncf_A_const_16; if linked_26 == nil { tmp2 = ifn_27.Invoke_O__O(arg_28) } else { tmp2 = linked_26.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_25, arg_28) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(), A_arbace_j2g_dyncf_A_const_18) }





















func A_arbace_j2g_dyncf_enabled_QMARK__A_New() *A_arbace_j2g_dyncf_enabled_QMARK__A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_enabled_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_29 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_j2g_dyncf_A_const_20.GetRawRoot__O(); if linked_30 == nil { return ifn_31.Invoke_O__O(arg_32) } else { return linked_30.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_29, arg_32)
	} }
func A_arbace_j2g_dyncf_tag_A_New() *A_arbace_j2g_dyncf_tag_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_tag_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_j2g_dyncf_tag_A) Ctor() {}
//line :28:1
func (t *A_arbace_j2g_dyncf_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_33 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = sym__0; var arg_37 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyncf_A_const_22, type__1)); if linked_34 == nil { return ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { return linked_34.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) } }

func A_arbace_j2g_dyncf_native_name_A_New() *A_arbace_j2g_dyncf_native_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_native_name_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_j2g_dyncf_native_name_A) Ctor() {}
//line :30:1
func (t *A_arbace_j2g_dyncf_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var root_38 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_79, nil, Lit_80); var tmp2 any; var root_42 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_j2g_dyncf_A_const_20.GetRawRoot__O(); if linked_43 == nil { tmp2 = ifn_44.Invoke_O__O(arg_45) } else { tmp2 = linked_43.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_42, arg_45) }; var tmp3 any = tmp2; var tmp4 any; var root_46 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = mname__0; var arg_50 any = desc__1; if linked_47 == nil { tmp4 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { tmp4 = linked_47.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; arg_41 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref(); if linked_39 == nil { return ifn_40.Invoke_O__O(arg_41) } else { return linked_39.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_38, arg_41)
	}
}







func A_arbace_j2g_dyncf_sub_name_A_New() *A_arbace_j2g_dyncf_sub_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_name_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Ctor() {}
//line :41:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_100, nil); var tmp2 any; var root_51 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = n__0; if linked_52 == nil { tmp2 = ifn_53.Invoke_O__O(arg_54) } else { tmp2 = linked_52.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_51, arg_54) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyncf_from_object_A_New() *A_arbace_j2g_dyncf_from_object_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_from_object_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_j2g_dyncf_from_object_A) Ctor() {}
//line :43:1
func (t *A_arbace_j2g_dyncf_from_object_A) Invoke_O_O_O__O(self, d__0, x__1 any) any {


	var tmp1 any; var root_55 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = d__0; if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_55, arg_58) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_29; var tmp4 any; var root_59 any = A_arbace_j2g_dyncf_A_const_30.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_j2g_dyncf_A_const_31; var arg_63 any = d__0; if linked_60 == nil { tmp4 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { tmp4 = linked_60.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_32; var tmp8 any; var root_64 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_66 lang.IFn
		if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_33.GetRawRoot__O()).Invoke_O__O(d__0))).Ref(); if linked_65 == nil { tmp8 = ifn_66.Invoke_O__O(arg_67) } else { tmp8 = linked_65.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_64, arg_67) }
//line :46:1
		return tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O__O(tmp7, tmp8, x__1)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_29) { return x__1 } else { if A_arbace_j2g_dyncf_A_const_28 != nil {


			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_34; var tmp12 any = A_arbace_j2g_dyncf_A_const_35; var tmp13 any; var root_68 any = A_arbace_j2g_dyncf_A_const_30.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_j2g_dyncf_A_const_31; var arg_72 any = d__0; if linked_69 == nil { tmp13 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { tmp13 = linked_69.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; return tmp9.Invoke_O_O__O(tmp10.Invoke_O_O_O__O(tmp11, tmp12, tmp13), x__1) } else {
//line :46:1
				return nil
			}
		}
		}
}
func A_arbace_j2g_dyncf_sub_forms_A_New() *A_arbace_j2g_dyncf_sub_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Ctor() {}
//line :51:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_73 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_75 lang.IFn; if


	linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = n__0; if linked_74 == nil { g__2 = ifn_75.Invoke_O__O(arg_76) } else { g__2 = linked_74.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_73, arg_76) }; var recv__3 any; var tmp1 lang.IFn = /*line :51:1*/lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_38; var tmp3 any; var root_80 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_82 lang.IFn; if



	linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = g__2; if linked_81 == nil { tmp3 = ifn_82.Invoke_O__O(arg_83) } else { tmp3 = linked_81.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_80, arg_83) }; recv__3 = tmp1.Invoke_O_O__O(tmp2, tmp3); var root_84 any =
	A_arbace_j2g_dyncf_A_const_39.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_41, A_arbace_j2g_dyncf_A_const_42); if linked_85 == nil { ifn_86.Invoke_O__O(arg_87) } else { linked_85.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_84, arg_87) }; var tmp4 any; tmp50 := /*line :51:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyncf_A_const_43; var tmp7 any; var root_93 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_95 lang.IFn





		if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_82, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_94 == nil { tmp7 = ifn_95.Invoke_O__O(arg_96) } else { tmp7 = linked_94.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_93, arg_96) }
//line :51:1
		var tmp8 any = tmp7; var tmp9 any; var root_97 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_99 lang.IFn





		if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var tmp10 any; var root_102 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = A_arbace_j2g_dyncf_A_const_45; var arg_106 any = A_arbace_j2g_dyncf_A_const_46; if linked_103 == nil { tmp10 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { tmp10 = linked_103.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }; var tmp11 any = tmp10; var tmp12 any; var root_107 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_j2g_dyncf_A_const_47; var arg_111 any = A_arbace_j2g_dyncf_A_const_48; if linked_108 == nil { tmp12 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { tmp12 = linked_108.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }; arg_100 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12); var arg_101 any = A_arbace_j2g_dyncf_A_const_49; if linked_98 == nil { tmp9 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { tmp9 = linked_98.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }
//line :51:1
		var tmp13 any = tmp9; var tmp14 any; var tmp15 any; var or__1927000174__auto____6 any; var root_112 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_114 lang.IFn






		if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = n__0; if linked_113 == nil { or__1927000174__auto____6 = ifn_114.Invoke_O__O(arg_115) } else { or__1927000174__auto____6 = linked_113.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp15 = or__1927000174__auto____6 } else { var root_116 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = n__0; if linked_117 == nil { tmp15 = ifn_118.Invoke_O__O(arg_119) } else { tmp15 = linked_117.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_116, arg_119) } }; if jrt.J2g_Truth(tmp15) { tmp14 = A_arbace_j2g_dyncf_A_const_52 } else {

			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp17 any; var root_120 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = A_arbace_j2g_dyncf_A_const_31; var arg_124 any = n__0; var arg_125 any = Lit_83; if linked_121 == nil { tmp17 = ifn_122.Invoke_O_O_O__O(arg_123, arg_124, arg_125) } else { tmp17 = linked_121.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_120, arg_123, arg_124, arg_125) }; tmp14 = tmp16.Invoke_O__O(tmp17) }
//line :51:1
		var tmp18 any = tmp14; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyncf_A_const_54; var tmp21 any = A_arbace_j2g_dyncf_A_const_58; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_59; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyncf_A_const_60; var tmp26 any; var root_126 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_128 lang.IFn









		if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = g__2; if linked_127 == nil { tmp26 = ifn_128.Invoke_O__O(arg_129) } else { tmp26 = linked_127.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_126, arg_129) }
//line :51:1
		var tmp27 any = tmp5.Invoke_O_O_O_O_O__O(tmp6, tmp8, tmp13, tmp18, tmp19.Invoke_O_O_O_O_O__O(tmp20, lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp22.Invoke_O_O__O(tmp23, tmp24.Invoke_O_O_O_O__O(tmp25, tmp26, A_arbace_j2g_dyncf_A_const_61, A_arbace_j2g_dyncf_A_const_62))), A_arbace_j2g_dyncf_A_const_55, A_arbace_j2g_dyncf_A_const_56, A_arbace_j2g_dyncf_A_const_57)); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyncf_A_const_63; var tmp30 any; var root_130 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_132 lang.IFn














		if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var root_135 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_136 == nil { arg_133 = ifn_137.Invoke_O__O(arg_138) } else { arg_133 = linked_136.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_135, arg_138) }; var arg_134 any = A_arbace_j2g_dyncf_A_const_64; if linked_131 == nil { tmp30 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { tmp30 = linked_131.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }
//line :51:1
		var tmp31 any = tmp30; var tmp32 any; var root_139 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_141 lang.IFn















		if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_143 any = A_arbace_j2g_dyncf_A_const_66; var arg_144 any = A_arbace_j2g_dyncf_A_const_67; var arg_145 any; var iter__1927001039__auto____6 any; var tmp33 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(recv__3, n__0); var tmp34 *jrt.Class; var fncls__416 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class
		if fncls__416 == nil { var fncls__416d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class = fncls__416d; tmp34 = fncls__416d } else { tmp34 = fncls__416 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var tmp35 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp36 any; var tmp37 any; var root_417 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = n__0; if linked_418 == nil { tmp37 = ifn_419.Invoke_O__O(arg_420) } else { tmp37 = linked_418.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_417, arg_420) }; if jrt.J2g_Truth(tmp37) { var root_421 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = n__0; if linked_422 == nil { tmp36 = ifn_423.Invoke_O__O(arg_424) } else { tmp36 = linked_422.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_421, arg_424) } } else { var tmp38 *lang.Keyword = A_arbace_j2g_dyncf_A_const_108; var tmp39 any; var root_425 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = n__0; if linked_426 == nil { tmp39 = ifn_427.Invoke_O__O(arg_428) } else { tmp39 = linked_426.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_425, arg_428) }; tmp36 = tmp38.Invoke_O__O(tmp39) }; arg_145 = tmp35.Invoke_O__O(tmp36)
//line :67:1
		if linked_140 == nil { tmp32 = ifn_141.Invoke_O_O_O_O__O(arg_142, arg_143, arg_144, arg_145) } else { tmp32 = linked_140.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_139, arg_142, arg_143, arg_144, arg_145) }
//line :51:1
		var tmp40 any = tmp28.Invoke_O_O_O__O(tmp29, tmp31, tmp32); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp42 any = A_arbace_j2g_dyncf_A_const_110; var tmp43 any; var root_429 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_431 lang.IFn






























		if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any; var root_434 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_86, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_435 == nil { arg_432 = ifn_436.Invoke_O__O(arg_437) } else { arg_432 = linked_435.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_434, arg_437) }; var arg_433 any = A_arbace_j2g_dyncf_A_const_111; if linked_430 == nil { tmp43 = ifn_431.Invoke_O_O__O(arg_432, arg_433) } else { tmp43 = linked_430.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_429, arg_432, arg_433) }
//line :51:1
		var tmp44 any = tmp43; var tmp45 any; var root_438 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_440 lang.IFn































		if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_442 any = A_arbace_j2g_dyncf_A_const_112; var arg_443 any = A_arbace_j2g_dyncf_A_const_113; var arg_444 any; var iter__1927001039__auto____6_2 any; var tmp46 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(recv__3, n__0); var tmp47 *jrt.Class; var fncls__713 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class
		if fncls__713 == nil { var fncls__713d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class = fncls__713d; tmp47 = fncls__713d } else { tmp47 = fncls__713 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil); var tmp48 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6_2); var tmp49 any; var root_714 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var arg_718 any; var root_719 any = A_arbace_j2g_dyncf_A_const_145.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = n__0; if linked_720 == nil { arg_718 = ifn_721.Invoke_O__O(arg_722) } else { arg_718 = linked_720.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_719, arg_722) }; if linked_715 == nil { tmp49 = ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { tmp49 = linked_715.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_714, arg_717, arg_718) }; arg_444 = tmp48.Invoke_O__O(tmp49)
//line :83:1
		if linked_439 == nil { tmp45 = ifn_440.Invoke_O_O_O_O__O(arg_441, arg_442, arg_443, arg_444) } else { tmp45 = linked_439.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_438, arg_441, arg_442, arg_443, arg_444) }
//line :51:1
		tmp4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp27, tmp40, tmp41.Invoke_O_O_O__O(tmp42, tmp44, tmp45)) }; return nil }(); var root_77 any = A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_79 lang.IFn; if




	linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; if linked_78 == nil { ifn_79.Invoke__O() } else { linked_78.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_77) }; if /*line :51:1*/ tmp50 != nil { panic(tmp50) }; return tmp4 }
















func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :68:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :68:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Invoke_O_O__O(self, s__292000018__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000018__1); var tmp2 *jrt.Class; var fncls__415 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class; if fncls__415 == nil { var fncls__415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class = fncls__415d; tmp2 = fncls__415d } else { tmp2 = fncls__415 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :68:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :68:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000017, c__s__292000018 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000017 = c__iter__292000017; t.F_s__292000018 = c__s__292000018 }
//line :68:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Invoke_O__O(self any) any { { var s__292000018__1 any; var t_ any = t.F_s__292000018; t.F_s__292000018 = nil; s__292000018__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_146 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = s__292000018__1; if linked_147 == nil { temp__1927000414__auto____2 = ifn_148.Invoke_O__O(arg_149) } else { temp__1927000414__auto____2 = linked_147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_146, arg_149) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000018__3 any = temp__1927000414__auto____2; var tmp1 any; var root_150 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = s__292000018__3; if linked_151 == nil { tmp1 = ifn_152.Invoke_O__O(arg_153) } else { tmp1 = linked_151.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_150, arg_153) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_154 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__292000018__3; if linked_155 == nil { c__1927001037__auto____4 = ifn_156.Invoke_O__O(arg_157) } else { c__1927001037__auto____4 = linked_155.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_154, arg_157) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000020__6 any; var root_158 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_159 == nil { b__292000020__6 = ifn_160.Invoke_O__O(arg_161) } else { b__292000020__6 = linked_159.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_158, arg_161) }; var tmp2 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(b__292000020__6, t.F_recv, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__267 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class; if fncls__267 == nil { var fncls__267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class = fncls__267d; tmp3 = fncls__267d } else { tmp3 = fncls__267 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_268 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any; var root_273 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = b__292000020__6; if linked_274 == nil { arg_271 = ifn_275.Invoke_O__O(arg_276) } else { arg_271 = linked_274.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_273, arg_276) }; var arg_272 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp5 any; var root_277 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = s__292000018__3; if linked_278 == nil { tmp5 = ifn_279.Invoke_O__O(arg_280) } else { tmp5 = linked_278.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_277, arg_280) }; arg_272 = tmp4.Invoke_O__O(tmp5); if linked_269 == nil { return ifn_270.Invoke_O_O__O(arg_271, arg_272) } else { return linked_269.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_268, arg_271, arg_272) } } else { var root_281 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any; var root_286 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = b__292000020__6; if linked_287 == nil { arg_284 = ifn_288.Invoke_O__O(arg_289) } else { arg_284 = linked_287.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_286, arg_289) }; var arg_285 any; if linked_282 == nil { return ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { return linked_282.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_281, arg_284, arg_285) } } } else { var mm__4 any; var root_290 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = s__292000018__3; if linked_291 == nil { mm__4 = ifn_292.Invoke_O__O(arg_293) } else { mm__4 = linked_291.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_290, arg_293) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_47, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_294 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any; var root_298 any = A_arbace_j2g_dyncf_A_const_74.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = mm__4; if linked_299 == nil { arg_297 = ifn_300.Invoke_O__O(arg_301) } else { arg_297 = linked_299.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_298, arg_301) }; if linked_295 == nil { and__1927000168__auto____6 = ifn_296.Invoke_O__O(arg_297) } else { and__1927000168__auto____6 = linked_295.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_294, arg_297) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_302 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_303 == nil { tmp6 = ifn_304.Invoke_O__O(arg_305) } else { tmp6 = linked_303.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_302, arg_305) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :68:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_306 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_308 lang.IFn

		if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any; var root_310 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = t.F_n; if linked_311 == nil { arg_309 = ifn_312.Invoke_O__O(arg_313) } else { arg_309 = linked_311.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_310, arg_313) }; if linked_307 == nil { or__1927000174__auto____5 = ifn_308.Invoke_O__O(arg_309) } else { or__1927000174__auto____5 = linked_307.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_306, arg_309) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_314 any = A_arbace_j2g_dyncf_A_const_77.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any; var root_319 any = A_arbace_j2g_dyncf_A_const_78.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyncf_A_const_79; var arg_322 any = tmp8.Invoke_O__O(A_arbace_j2g_dyncf_A_const_80.Get__O()); var arg_323 any; var root_324 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = t.F_n; if linked_325 == nil { arg_323 = ifn_326.Invoke_O__O(arg_327) } else { arg_323 = linked_325.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_324, arg_327) }; if linked_320 == nil { arg_317 = ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { arg_317 = linked_320.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_319, arg_322, arg_323) }; var arg_318 any; var root_328 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_329 == nil { arg_318 = ifn_330.Invoke_O__O(arg_331) } else { arg_318 = linked_329.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_328, arg_331) }; if linked_315 == nil { tmp7 = ifn_316.Invoke_O_O__O(arg_317, arg_318) } else { tmp7 = linked_315.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_314, arg_317, arg_318) } }
//line :68:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_332 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_334 lang.IFn



			if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = t.F_n; if linked_333 == nil { tmp9 = ifn_334.Invoke_O__O(arg_335) } else { tmp9 = linked_333.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_332, arg_335) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4) } else { var root_336 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = t.F_n; var arg_340 any = mm__4; if linked_337 == nil { real__5 = ifn_338.Invoke_O_O__O(arg_339, arg_340) } else { real__5 = linked_337.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_336, arg_339, arg_340) } }
//line :68:1
			var vec__292000033__6 any; var root_341 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_343 lang.IFn




			if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_342 == nil { vec__292000033__6 = ifn_343.Invoke_O__O(arg_344) } else { vec__292000033__6 = linked_342.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_341, arg_344) }
//line :68:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000036__9 any; var root_345 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_347 lang.IFn; _ = ___8





			if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = real__5; if linked_346 == nil { vec__292000036__9 = ifn_347.Invoke_O__O(arg_348) } else { vec__292000036__9 = linked_346.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_345, arg_348) }
//line :68:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_349 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any; var tmp10 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyncf_A_const_85; var tmp13 any; var root_354 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_356 lang.IFn








				if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_j2g_dyncf_A_const_86; var arg_358 any = A_arbace_j2g_dyncf_A_const_87; if linked_355 == nil { tmp13 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { tmp13 = linked_355.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }
//line :68:1
				var tmp14 any = tmp13; var tmp15 any; var root_359 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_361 lang.IFn








				if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = A_arbace_j2g_dyncf_A_const_88; var arg_363 any = A_arbace_j2g_dyncf_A_const_105; if linked_360 == nil { tmp15 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp15 = linked_360.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }
//line :68:1
				var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyncf_A_const_90; var tmp19 any = A_arbace_j2g_dyncf_A_const_97; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_98, t.F_recv, A_arbace_j2g_dyncf_A_const_99)); var tmp21 any; var root_364 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_366 lang.IFn










				if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_368 any; var root_372 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp23 any; var root_376 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = real__5; if linked_377 == nil { tmp23 = ifn_378.Invoke_O__O(arg_379) } else { tmp23 = linked_377.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_376, arg_379) }; arg_375 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_373 == nil { arg_368 = ifn_374.Invoke_O__O(arg_375) } else { arg_368 = linked_373.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_372, arg_375) }; var arg_369 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp25 any; var root_380 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_382 lang.IFn
				if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any; var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_91, nil); var tmp27 any; var root_384 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = t.F_n; if linked_385 == nil { tmp27 = ifn_386.Invoke_O__O(arg_387) } else { tmp27 = linked_385.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_384, arg_387) }; arg_383 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp27)).Ref(); if linked_381 == nil { tmp25 = ifn_382.Invoke_O__O(arg_383) } else { tmp25 = linked_381.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_380, arg_383) }; arg_369 = tmp24.Invoke_O_O__O(tmp25, A_arbace_j2g_dyncf_A_const_91)
//line :79:1
				var arg_370 any = A_arbace_j2g_dyncf_A_const_92; var arg_371 any; var root_388 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_390 lang.IFn

				if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any; var tmp28 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New(); var tmp29 *jrt.Class; var fncls__398 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class; if fncls__398 == nil { var fncls__398d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class = fncls__398d; tmp29 = fncls__398d } else { tmp29 = fncls__398 }; arg_391 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_392 any = ps__7; if linked_389 == nil { arg_371 = ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { arg_371 = linked_389.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_388, arg_391, arg_392) }
//line :79:1
				if linked_365 == nil { tmp21 = ifn_366.Invoke_O_O_O_O_O__O(arg_367, arg_368, arg_369, arg_370, arg_371) } else { tmp21 = linked_365.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_364, arg_367, arg_368, arg_369, arg_370, arg_371) }
//line :68:1
				arg_352 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp20, tmp21))); var arg_353 any; var tmp30 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp31 any; var root_399 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = s__292000018__3; if linked_400 == nil { tmp31 = ifn_401.Invoke_O__O(arg_402) } else { tmp31 = linked_400.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_399, arg_402) }; arg_353 = tmp30.Invoke_O__O(tmp31); if linked_350 == nil { return ifn_351.Invoke_O_O__O(arg_352, arg_353) } else { return linked_350.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_349, arg_352, arg_353) } } else { var tmp32 any; var root_403 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = s__292000018__3; if linked_404 == nil { tmp32 = ifn_405.Invoke_O__O(arg_406) } else { tmp32 = linked_404.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_403, arg_406) }; s__292000018__1 = tmp32; continue L1 } } else { var tmp33 any; var root_407 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = s__292000018__3; if linked_408 == nil { tmp33 = ifn_409.Invoke_O__O(arg_410) } else { tmp33 = linked_408.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_407, arg_410) }; s__292000018__1 = tmp33; continue L1 } } else { var tmp34 any; var root_411 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = s__292000018__3; if linked_412 == nil { tmp34 = ifn_413.Invoke_O__O(arg_414) } else { tmp34 = linked_412.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_411, arg_414) }; s__292000018__1 = tmp34; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :68:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :68:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Ctor_O_O_O_I_O(c__b__292000020, c__recv, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000020 = c__b__292000020; t.F_recv = c__recv; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :68:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Invoke_O__O(self any) any { { var i__292000019__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000019__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000019__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_47, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_162 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any; var root_166 any = A_arbace_j2g_dyncf_A_const_74.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = mm__2; if linked_167 == nil { arg_165 = ifn_168.Invoke_O__O(arg_169) } else { arg_165 = linked_167.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if linked_163 == nil { and__1927000168__auto____4 = ifn_164.Invoke_O__O(arg_165) } else { and__1927000168__auto____4 = linked_163.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_170 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_171 == nil { tmp2 = ifn_172.Invoke_O__O(arg_173) } else { tmp2 = linked_171.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_170, arg_173) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :68:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_174 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_176 lang.IFn

		if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any; var root_178 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = t.F_n; if linked_179 == nil { arg_177 = ifn_180.Invoke_O__O(arg_181) } else { arg_177 = linked_179.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_178, arg_181) }; if linked_175 == nil { or__1927000174__auto____3 = ifn_176.Invoke_O__O(arg_177) } else { or__1927000174__auto____3 = linked_175.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_174, arg_177) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_182 any = A_arbace_j2g_dyncf_A_const_77.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var root_187 any = A_arbace_j2g_dyncf_A_const_78.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyncf_A_const_79; var arg_190 any = tmp4.Invoke_O__O(A_arbace_j2g_dyncf_A_const_80.Get__O()); var arg_191 any; var root_192 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = t.F_n; if linked_193 == nil { arg_191 = ifn_194.Invoke_O__O(arg_195) } else { arg_191 = linked_193.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_192, arg_195) }; if linked_188 == nil { arg_185 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { arg_185 = linked_188.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; var arg_186 any; var root_196 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_197 == nil { arg_186 = ifn_198.Invoke_O__O(arg_199) } else { arg_186 = linked_197.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_196, arg_199) }; if linked_183 == nil { tmp3 = ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { tmp3 = linked_183.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_182, arg_185, arg_186) } }
//line :68:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_200 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_202 lang.IFn



			if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = t.F_n; if linked_201 == nil { tmp5 = ifn_202.Invoke_O__O(arg_203) } else { tmp5 = linked_201.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2) } else { var root_204 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = t.F_n; var arg_208 any = mm__2; if linked_205 == nil { real__3 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { real__3 = linked_205.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } }
//line :68:1
			var vec__292000024__4 any; var root_209 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_211 lang.IFn




			if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_210 == nil { vec__292000024__4 = ifn_211.Invoke_O__O(arg_212) } else { vec__292000024__4 = linked_210.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_209, arg_212) }
//line :68:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000027__7 any; var root_213 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_215 lang.IFn; _ = ___6





			if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = real__3; if linked_214 == nil { vec__292000027__7 = ifn_215.Invoke_O__O(arg_216) } else { vec__292000027__7 = linked_214.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_213, arg_216) }
//line :68:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_217 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = t.F_b__292000020; var arg_221 any; var tmp6 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyncf_A_const_85; var tmp9 any; var root_222 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_224 lang.IFn








				if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = A_arbace_j2g_dyncf_A_const_86; var arg_226 any = A_arbace_j2g_dyncf_A_const_87; if linked_223 == nil { tmp9 = ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { tmp9 = linked_223.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) }
//line :68:1
				var tmp10 any = tmp9; var tmp11 any; var root_227 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_229 lang.IFn








				if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = A_arbace_j2g_dyncf_A_const_88; var arg_231 any = A_arbace_j2g_dyncf_A_const_89; if linked_228 == nil { tmp11 = ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { tmp11 = linked_228.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) }
//line :68:1
				var tmp12 any = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyncf_A_const_90; var tmp15 any = A_arbace_j2g_dyncf_A_const_97; var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_98, t.F_recv, A_arbace_j2g_dyncf_A_const_99)); var tmp17 any; var root_232 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_234 lang.IFn










				if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_236 any; var root_240 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp19 any; var root_244 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = real__3; if linked_245 == nil { tmp19 = ifn_246.Invoke_O__O(arg_247) } else { tmp19 = linked_245.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_244, arg_247) }; arg_243 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19)).Ref(); if linked_241 == nil { arg_236 = ifn_242.Invoke_O__O(arg_243) } else { arg_236 = linked_241.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_240, arg_243) }; var arg_237 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp21 any; var root_248 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_250 lang.IFn
				if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_91, nil); var tmp23 any; var root_252 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = t.F_n; if linked_253 == nil { tmp23 = ifn_254.Invoke_O__O(arg_255) } else { tmp23 = linked_253.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_252, arg_255) }; arg_251 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_249 == nil { tmp21 = ifn_250.Invoke_O__O(arg_251) } else { tmp21 = linked_249.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_248, arg_251) }; arg_237 = tmp20.Invoke_O_O__O(tmp21, A_arbace_j2g_dyncf_A_const_91)
//line :79:1
				var arg_238 any = A_arbace_j2g_dyncf_A_const_92; var arg_239 any; var root_256 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_258 lang.IFn

				if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any; var tmp24 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New(); var tmp25 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class = fncls__266d; tmp25 = fncls__266d } else { tmp25 = fncls__266 }; arg_259 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var arg_260 any = ps__5; if linked_257 == nil { arg_239 = ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { arg_239 = linked_257.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_256, arg_259, arg_260) }
//line :79:1
				if linked_233 == nil { tmp17 = ifn_234.Invoke_O_O_O_O_O__O(arg_235, arg_236, arg_237, arg_238, arg_239) } else { tmp17 = linked_233.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_232, arg_235, arg_236, arg_237, arg_238, arg_239) }
//line :68:1
				arg_221 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp16, tmp17))); if linked_218 == nil { ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { linked_218.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) }; i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Ctor() {}
//line :81:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_261 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = p__2; var arg_265 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_95, A_arbace_j2g_dyncf_A_const_96, i__1); if linked_262 == nil { return ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { return linked_262.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) } }
//line :81:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Ctor() {}
//line :81:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_393 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = p__2; var arg_397 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_95, A_arbace_j2g_dyncf_A_const_96, i__1); if linked_394 == nil { return ifn_395.Invoke_O_O__O(arg_396, arg_397) } else { return linked_394.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_393, arg_396, arg_397) } }


func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :84:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :84:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Invoke_O_O__O(self, s__292000044__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000044__1); var tmp2 *jrt.Class; var fncls__712 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class; if fncls__712 == nil { var fncls__712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class = fncls__712d; tmp2 = fncls__712d } else { tmp2 = fncls__712 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :84:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :84:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000043, c__s__292000044 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000043 = c__iter__292000043; t.F_s__292000044 = c__s__292000044 }
//line :84:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Invoke_O__O(self any) any { { var s__292000044__1 any; var t_ any = t.F_s__292000044; t.F_s__292000044 = nil; s__292000044__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_445 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = s__292000044__1; if linked_446 == nil { temp__1927000414__auto____2 = ifn_447.Invoke_O__O(arg_448) } else { temp__1927000414__auto____2 = linked_446.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_445, arg_448) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000044__3 any = temp__1927000414__auto____2; var tmp1 any; var root_449 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = s__292000044__3; if linked_450 == nil { tmp1 = ifn_451.Invoke_O__O(arg_452) } else { tmp1 = linked_450.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_449, arg_452) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_453 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = s__292000044__3; if linked_454 == nil { c__1927001037__auto____4 = ifn_455.Invoke_O__O(arg_456) } else { c__1927001037__auto____4 = linked_454.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_453, arg_456) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000046__6 any; var root_457 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_458 == nil { b__292000046__6 = ifn_459.Invoke_O__O(arg_460) } else { b__292000046__6 = linked_458.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_457, arg_460) }; var tmp2 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(t.F_recv, b__292000046__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__567 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class; if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class = fncls__567d; tmp3 = fncls__567d } else { tmp3 = fncls__567 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_568 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any; var root_573 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = b__292000046__6; if linked_574 == nil { arg_571 = ifn_575.Invoke_O__O(arg_576) } else { arg_571 = linked_574.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_573, arg_576) }; var arg_572 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp5 any; var root_577 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = s__292000044__3; if linked_578 == nil { tmp5 = ifn_579.Invoke_O__O(arg_580) } else { tmp5 = linked_578.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_577, arg_580) }; arg_572 = tmp4.Invoke_O__O(tmp5); if linked_569 == nil { return ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { return linked_569.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) } } else { var root_581 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any; var root_586 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = b__292000046__6; if linked_587 == nil { arg_584 = ifn_588.Invoke_O__O(arg_589) } else { arg_584 = linked_587.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_586, arg_589) }; var arg_585 any; if linked_582 == nil { return ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { return linked_582.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) } } } else { var vec__292000063__4 any; var root_590 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = s__292000044__3; if linked_591 == nil { vec__292000063__4 = ifn_592.Invoke_O__O(arg_593) } else { vec__292000063__4 = linked_591.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_590, arg_593) }; var vec__292000066__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(0), nil); var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__292000066__5; var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_594 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_596 lang.IFn; _ = ___9
														if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = desc__7; if linked_595 == nil { tmp6 = ifn_596.Invoke_O__O(arg_597) } else { tmp6 = linked_595.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_594, arg_597) }
//line :84:1
	if jrt.J2g_Truth(tmp6) { var impl__10 any; var root_598 any = A_arbace_j2g_dyncf_A_const_114.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_600 lang.IFn

		if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = t.F_n; var arg_602 any = k__8; if linked_599 == nil { impl__10 = ifn_600.Invoke_O_O__O(arg_601, arg_602) } else { impl__10 = linked_599.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_598, arg_601, arg_602) }
//line :84:1
		var base__11 any; var root_603 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_605 lang.IFn


		if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = name__6; var arg_607 any = desc__7; if linked_604 == nil { base__11 = ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { base__11 = linked_604.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) }
//line :84:1
		var vec__292000069__12 any; var root_608 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_610 lang.IFn



		if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = desc__7; if linked_609 == nil { vec__292000069__12 = ifn_610.Invoke_O__O(arg_611) } else { vec__292000069__12 = linked_609.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_608, arg_611) }
//line :84:1
		var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(0), nil); var r__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__15 any; var root_612 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_614 lang.IFn




		if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var tmp7 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New(); var tmp8 *jrt.Class; var fncls__622 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class; if fncls__622 == nil { var fncls__622d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class = fncls__622d; tmp8 = fncls__622d } else { tmp8 = fncls__622 }; arg_615 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_616 any = ps__13; if linked_613 == nil { pn__15 = ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { pn__15 = linked_613.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_612, arg_615, arg_616) }
//line :84:1
		var call__16 any; var G__292000074__16_ any = A_arbace_j2g_dyncf_A_const_117.Invoke_O__O(impl__10)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000074__16_) >> 4 & 3 { case 0: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_118) {

		var root_624 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_628 any; var root_631 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = A_arbace_j2g_dyncf_A_const_31; var arg_635 any = A_arbace_j2g_dyncf_A_const_119.Invoke_O__O(impl__10); var arg_636 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_79, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_632 == nil { arg_628 = ifn_633.Invoke_O_O_O__O(arg_634, arg_635, arg_636) } else { arg_628 = linked_632.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_631, arg_634, arg_635, arg_636) }; var arg_629 any = A_arbace_j2g_dyncf_A_const_120; var arg_630 any = pn__15; if linked_625 == nil { call__16 = ifn_626.Invoke_O_O_O_O__O(arg_627, arg_628, arg_629, arg_630) } else { call__16 = linked_625.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_624, arg_627, arg_628, arg_629, arg_630) }
//line :90:1
		break L2 }; case 1: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_121) {
			var root_637 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_641 any; var root_645 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_646 == nil { arg_641 = ifn_647.Invoke_O__O(arg_648) } else { arg_641 = linked_646.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_645, arg_648) }; var arg_642 any = A_arbace_j2g_dyncf_A_const_122; var arg_643 any = A_arbace_j2g_dyncf_A_const_123; var arg_644 any = pn__15; if linked_638 == nil { call__16 = ifn_639.Invoke_O_O_O_O_O__O(arg_640, arg_641, arg_642, arg_643, arg_644) } else { call__16 = linked_638.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_637, arg_640, arg_641, arg_642, arg_643, arg_644) }
//line :90:1
			break L2 }; case 2: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_124) {
				var root_649 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_653 any; var root_657 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_658 == nil { arg_653 = ifn_659.Invoke_O__O(arg_660) } else { arg_653 = linked_658.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_657, arg_660) }; var arg_654 any = A_arbace_j2g_dyncf_A_const_122; var arg_655 any = A_arbace_j2g_dyncf_A_const_123; var arg_656 any = pn__15; if linked_650 == nil { call__16 = ifn_651.Invoke_O_O_O_O_O__O(arg_652, arg_653, arg_654, arg_655, arg_656) } else { call__16 = linked_650.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_649, arg_652, arg_653, arg_654, arg_655, arg_656) }
//line :90:1
				break L2 }; case 3: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_125) {


					var root_661 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_665 any; var root_668 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_90, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_669 == nil { arg_665 = ifn_670.Invoke_O__O(arg_671) } else { arg_665 = linked_669.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_668, arg_671) }; var arg_666 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp10 any; var root_672 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_91, nil); var tmp12 any; var root_676 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = t.F_n; if linked_677 == nil { tmp12 = ifn_678.Invoke_O__O(arg_679) } else { tmp12 = linked_677.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_676, arg_679) }; arg_675 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); if linked_673 == nil { tmp10 = ifn_674.Invoke_O__O(arg_675) } else { tmp10 = linked_673.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_672, arg_675) }; arg_666 = tmp9.Invoke_O_O__O(tmp10, A_arbace_j2g_dyncf_A_const_126); var arg_667 any = pn__15; if linked_662 == nil { call__16 = ifn_663.Invoke_O_O_O_O__O(arg_664, arg_665, arg_666, arg_667) } else { call__16 = linked_662.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_661, arg_664, arg_665, arg_666, arg_667) }
//line :90:1
					break L2 }; default:}; call__16 = nil}
//line :84:1
		if jrt.J2g_Truth(call__16) { var root_680 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__6, desc__7)).Ref(); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyncf_A_const_127; var tmp16 any; var root_685 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_687 lang.IFn












			if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any; var tmp17 any; var root_690 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = A_arbace_j2g_dyncf_A_const_128; var arg_694 any = A_arbace_j2g_dyncf_A_const_129; if linked_691 == nil { tmp17 = ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { tmp17 = linked_691.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) }; var tmp18 any = tmp17; var tmp19 any; var root_695 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = A_arbace_j2g_dyncf_A_const_130; var arg_699 any = A_arbace_j2g_dyncf_A_const_141; if linked_696 == nil { tmp19 = ifn_697.Invoke_O_O__O(arg_698, arg_699) } else { tmp19 = linked_696.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_695, arg_698, arg_699) }; arg_688 = lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19); var arg_689 any = A_arbace_j2g_dyncf_A_const_142; if linked_686 == nil { tmp16 = ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { tmp16 = linked_686.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_685, arg_688, arg_689) }
//line :84:1
			var tmp20 any = tmp16; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyncf_A_const_133; var tmp23 any = A_arbace_j2g_dyncf_A_const_134; var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_135, t.F_recv, A_arbace_j2g_dyncf_A_const_136)); var tmp25 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_98, r__14) {
				tmp25 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_137, call__16, A_arbace_j2g_dyncf_A_const_143) } else {
					var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyncf_A_const_139; tmp25 = tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_140, call__16)) }
//line :84:1
			arg_683 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp24, tmp25))); var arg_684 any; var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp29 any; var root_700 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = s__292000044__3; if linked_701 == nil { tmp29 = ifn_702.Invoke_O__O(arg_703) } else { tmp29 = linked_701.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_700, arg_703) }; arg_684 = tmp28.Invoke_O__O(tmp29); if linked_681 == nil { return ifn_682.Invoke_O_O__O(arg_683, arg_684) } else { return linked_681.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_680, arg_683, arg_684) } } else { var tmp30 any; var root_704 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = s__292000044__3; if linked_705 == nil { tmp30 = ifn_706.Invoke_O__O(arg_707) } else { tmp30 = linked_705.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_704, arg_707) }; s__292000044__1 = tmp30; continue L1 } } else { var tmp31 any; var root_708 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = s__292000044__3; if linked_709 == nil { tmp31 = ifn_710.Invoke_O__O(arg_711) } else { tmp31 = linked_709.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_708, arg_711) }; s__292000044__1 = tmp31; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :84:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Ctor_O_O_O_I_O(c__recv, c__b__292000046, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_b__292000046 = c__b__292000046; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :84:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Invoke_O__O(self any) any { { var i__292000045__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000045__1)); var vec__292000053__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__292000053__3; var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_461 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_463 lang.IFn; _ = ___7
																if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = desc__5; if linked_462 == nil { tmp2 = ifn_463.Invoke_O__O(arg_464) } else { tmp2 = linked_462.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_461, arg_464) }
//line :84:1
	if jrt.J2g_Truth(tmp2) { var impl__8 any; var root_465 any = A_arbace_j2g_dyncf_A_const_114.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_467 lang.IFn

		if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = t.F_n; var arg_469 any = k__6; if linked_466 == nil { impl__8 = ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { impl__8 = linked_466.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) }
//line :84:1
		var base__9 any; var root_470 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_472 lang.IFn


		if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = name__4; var arg_474 any = desc__5; if linked_471 == nil { base__9 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { base__9 = linked_471.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }
//line :84:1
		var vec__292000056__10 any; var root_475 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_477 lang.IFn



		if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = desc__5; if linked_476 == nil { vec__292000056__10 = ifn_477.Invoke_O__O(arg_478) } else { vec__292000056__10 = linked_476.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_475, arg_478) }
//line :84:1
		var ps__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_479 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_481 lang.IFn




		if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any; var tmp3 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New(); var tmp4 *jrt.Class; var fncls__489 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class; if fncls__489 == nil { var fncls__489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class = fncls__489d; tmp4 = fncls__489d } else { tmp4 = fncls__489 }; arg_482 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_483 any = ps__11; if linked_480 == nil { pn__13 = ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { pn__13 = linked_480.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_479, arg_482, arg_483) }
//line :84:1
		var call__14 any; var G__292000061__14_ any = A_arbace_j2g_dyncf_A_const_117.Invoke_O__O(impl__8)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000061__14_) >> 4 & 3 { case 0: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_118) {

		var root_491 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_495 any; var root_498 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = A_arbace_j2g_dyncf_A_const_31; var arg_502 any = A_arbace_j2g_dyncf_A_const_119.Invoke_O__O(impl__8); var arg_503 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_79, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_499 == nil { arg_495 = ifn_500.Invoke_O_O_O__O(arg_501, arg_502, arg_503) } else { arg_495 = linked_499.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_498, arg_501, arg_502, arg_503) }; var arg_496 any = A_arbace_j2g_dyncf_A_const_120; var arg_497 any = pn__13; if linked_492 == nil { call__14 = ifn_493.Invoke_O_O_O_O__O(arg_494, arg_495, arg_496, arg_497) } else { call__14 = linked_492.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_491, arg_494, arg_495, arg_496, arg_497) }
//line :90:1
		break L2 }; case 1: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_121) {
			var root_504 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_508 any; var root_512 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_513 == nil { arg_508 = ifn_514.Invoke_O__O(arg_515) } else { arg_508 = linked_513.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_512, arg_515) }; var arg_509 any = A_arbace_j2g_dyncf_A_const_122; var arg_510 any = A_arbace_j2g_dyncf_A_const_123; var arg_511 any = pn__13; if linked_505 == nil { call__14 = ifn_506.Invoke_O_O_O_O_O__O(arg_507, arg_508, arg_509, arg_510, arg_511) } else { call__14 = linked_505.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_504, arg_507, arg_508, arg_509, arg_510, arg_511) }
//line :90:1
			break L2 }; case 2: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_124) {
				var root_516 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_520 any; var root_524 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_525 == nil { arg_520 = ifn_526.Invoke_O__O(arg_527) } else { arg_520 = linked_525.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_524, arg_527) }; var arg_521 any = A_arbace_j2g_dyncf_A_const_122; var arg_522 any = A_arbace_j2g_dyncf_A_const_123; var arg_523 any = pn__13; if linked_517 == nil { call__14 = ifn_518.Invoke_O_O_O_O_O__O(arg_519, arg_520, arg_521, arg_522, arg_523) } else { call__14 = linked_517.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_516, arg_519, arg_520, arg_521, arg_522, arg_523) }
//line :90:1
				break L2 }; case 3: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_125) {


					var root_528 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_532 any; var root_535 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_90, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_536 == nil { arg_532 = ifn_537.Invoke_O__O(arg_538) } else { arg_532 = linked_536.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_535, arg_538) }; var arg_533 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp6 any; var root_539 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_91, nil); var tmp8 any; var root_543 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = t.F_n; if linked_544 == nil { tmp8 = ifn_545.Invoke_O__O(arg_546) } else { tmp8 = linked_544.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_543, arg_546) }; arg_542 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(); if linked_540 == nil { tmp6 = ifn_541.Invoke_O__O(arg_542) } else { tmp6 = linked_540.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_539, arg_542) }; arg_533 = tmp5.Invoke_O_O__O(tmp6, A_arbace_j2g_dyncf_A_const_126); var arg_534 any = pn__13; if linked_529 == nil { call__14 = ifn_530.Invoke_O_O_O_O__O(arg_531, arg_532, arg_533, arg_534) } else { call__14 = linked_529.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_528, arg_531, arg_532, arg_533, arg_534) }
//line :90:1
					break L2 }; default:}; call__14 = nil}
//line :84:1
		if jrt.J2g_Truth(call__14) { var root_547 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = t.F_b__292000046; var arg_551 any; var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__4, desc__5)).Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_127; var tmp12 any; var root_552 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_554 lang.IFn












			if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any; var tmp13 any; var root_557 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = A_arbace_j2g_dyncf_A_const_128; var arg_561 any = A_arbace_j2g_dyncf_A_const_129; if linked_558 == nil { tmp13 = ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { tmp13 = linked_558.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) }; var tmp14 any = tmp13; var tmp15 any; var root_562 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = A_arbace_j2g_dyncf_A_const_130; var arg_566 any = A_arbace_j2g_dyncf_A_const_131; if linked_563 == nil { tmp15 = ifn_564.Invoke_O_O__O(arg_565, arg_566) } else { tmp15 = linked_563.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_562, arg_565, arg_566) }; arg_555 = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); var arg_556 any = A_arbace_j2g_dyncf_A_const_132; if linked_553 == nil { tmp12 = ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { tmp12 = linked_553.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) }
//line :84:1
			var tmp16 any = tmp12; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyncf_A_const_133; var tmp19 any = A_arbace_j2g_dyncf_A_const_134; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_135, t.F_recv, A_arbace_j2g_dyncf_A_const_136)); var tmp21 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_98, r__12) {
				tmp21 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_137, call__14, A_arbace_j2g_dyncf_A_const_138) } else {
					var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_139; tmp21 = tmp22.Invoke_O_O__O(tmp23, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_140, call__14)) }
//line :84:1
			arg_551 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Invoke_O_O_O__O(tmp11, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp20, tmp21))); if linked_548 == nil { ifn_549.Invoke_O_O__O(arg_550, arg_551) } else { linked_548.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_547, arg_550, arg_551) }; i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Ctor() {}
//line :89:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_484 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = p__2; var arg_488 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_115, A_arbace_j2g_dyncf_A_const_116, i__1); if linked_485 == nil { return ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { return linked_485.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_484, arg_487, arg_488) } }
//line :89:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Ctor() {}
//line :89:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_617 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = p__2; var arg_621 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_115, A_arbace_j2g_dyncf_A_const_116, i__1); if linked_618 == nil { return ifn_619.Invoke_O_O__O(arg_620, arg_621) } else { return linked_618.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_617, arg_620, arg_621) } }













func A_arbace_j2g_dyncf_subs_forms_A_New() *A_arbace_j2g_dyncf_subs_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Invoke_O_O__O(self, T__0_ any) any { var cs__2 any; var root_723 any = A_arbace_j2g_dyncf_A_const_146.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_725 lang.IFn; if


	linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = T__0_; if linked_724 == nil { cs__2 = ifn_725.Invoke_O__O(arg_726) } else { cs__2 = linked_724.(*aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_723, arg_726) }; var root_727 any =
	A_arbace_j2g_dyncf_A_const_147.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_149.GetRawRoot__O(), cs__2); var arg_731 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_150; var tmp3 any = A_arbace_j2g_dyncf_A_const_151; var tmp4 any; var root_847 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_849 lang.IFn; if




	linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = A_arbace_j2g_dyncf_A_const_159; var arg_851 any = A_arbace_j2g_dyncf_A_const_160; if linked_848 == nil { tmp4 = ifn_849.Invoke_O_O__O(arg_850, arg_851) } else { tmp4 = linked_848.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_847, arg_850, arg_851) }; var tmp5 any = /*line :107:1*/lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 any = A_arbace_j2g_dyncf_A_const_152; var tmp7 any = A_arbace_j2g_dyncf_A_const_153; var tmp8 any; var root_737 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_739 lang.IFn; if







	linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_741 any = A_arbace_j2g_dyncf_A_const_154; var arg_742 any = A_arbace_j2g_dyncf_A_const_155; var arg_743 any; var iter__1927001039__auto____3 any; var tmp9 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_New(); var tmp10 *jrt.Class; var fncls__846 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class; if
	fncls__846 == nil { var fncls__846d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class = fncls__846d; tmp10 = fncls__846d } else { tmp10 = fncls__846 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_743 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(cs__2); if /*line :115:1*/ linked_738 == nil { tmp8 = ifn_739.Invoke_O_O_O_O__O(arg_740, arg_741, arg_742, arg_743) } else { tmp8 = linked_738.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_737, arg_740, arg_741, arg_742, arg_743) }; arg_731 = /*line :107:1*/lang.Tuple_Create_O__IPersistentVector(tmp1.Invoke_O_O_O_O_O_O_O_O__O(tmp2, tmp3, Lit_101, tmp5, tmp6, tmp7, tmp8, A_arbace_j2g_dyncf_A_const_158)); if linked_728 == nil { return ifn_729.Invoke_O_O__O(arg_730, arg_731) } else { return linked_728.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_727, arg_730, arg_731) } }








func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_New() *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A) Invoke_O_O__O(self, s__292000079__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_New_O_O(self, s__292000079__1); var tmp2 *jrt.Class; var fncls__845 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class; if fncls__845 == nil { var fncls__845d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class = fncls__845d; tmp2 = fncls__845d } else { tmp2 = fncls__845 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :116:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A{}; t.Ctor_O_O(p0, p1); return t }
//line :116:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A) Ctor_O_O(c__iter__292000078, c__s__292000079 any) { t.F_iter__292000078 = c__iter__292000078; t.F_s__292000079 = c__s__292000079 }
//line :116:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A) Invoke_O__O(self any) any { { var s__292000079__1 any; var t_ any = t.F_s__292000079; t.F_s__292000079 = nil; s__292000079__1 = t_; for { var temp__1927000414__auto____2 any; var root_744 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = s__292000079__1; if linked_745 == nil { temp__1927000414__auto____2 = ifn_746.Invoke_O__O(arg_747) } else { temp__1927000414__auto____2 = linked_745.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_744, arg_747) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000079__3 any = temp__1927000414__auto____2; var tmp1 any; var root_748 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = s__292000079__3; if linked_749 == nil { tmp1 = ifn_750.Invoke_O__O(arg_751) } else { tmp1 = linked_749.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_748, arg_751) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_752 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = s__292000079__3; if linked_753 == nil { c__1927001037__auto____4 = ifn_754.Invoke_O__O(arg_755) } else { c__1927001037__auto____4 = linked_753.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_752, arg_755) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000081__6 any; var root_756 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_757 == nil { b__292000081__6 = ifn_758.Invoke_O__O(arg_759) } else { b__292000081__6 = linked_757.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_756, arg_759) }; var tmp2 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_New_O_I_O(b__292000081__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__787 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class; if fncls__787 == nil { var fncls__787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class = fncls__787d; tmp3 = fncls__787d } else { tmp3 = fncls__787 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_788 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any; var root_793 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = b__292000081__6; if linked_794 == nil { arg_791 = ifn_795.Invoke_O__O(arg_796) } else { arg_791 = linked_794.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_793, arg_796) }; var arg_792 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000078); var tmp5 any; var root_797 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = s__292000079__3; if linked_798 == nil { tmp5 = ifn_799.Invoke_O__O(arg_800) } else { tmp5 = linked_798.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_797, arg_800) }; arg_792 = tmp4.Invoke_O__O(tmp5); if linked_789 == nil { return ifn_790.Invoke_O_O__O(arg_791, arg_792) } else { return linked_789.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_788, arg_791, arg_792) } } else { var root_801 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any; var root_806 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = b__292000081__6; if linked_807 == nil { arg_804 = ifn_808.Invoke_O__O(arg_809) } else { arg_804 = linked_807.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_806, arg_809) }; var arg_805 any; if linked_802 == nil { return ifn_803.Invoke_O_O__O(arg_804, arg_805) } else { return linked_802.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_801, arg_804, arg_805) } } } else { var p__4 any; var root_810 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = s__292000079__3; if linked_811 == nil { p__4 = ifn_812.Invoke_O__O(arg_813) } else { p__4 = linked_811.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_810, arg_813) }; var g__5 any; var root_814 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = p__4; if linked_815 == nil { g__5 = ifn_816.Invoke_O__O(arg_817) } else { g__5 = linked_815.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_814, arg_817) }; var root_818 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_156; var tmp8 any; var root_823 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_825 lang.IFn
														if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = A_arbace_j2g_dyncf_A_const_31; var arg_827 any = p__4; var arg_828 any = Lit_105; if linked_824 == nil { tmp8 = ifn_825.Invoke_O_O_O__O(arg_826, arg_827, arg_828) } else { tmp8 = linked_824.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_823, arg_826, arg_827, arg_828) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_157; var tmp12 any; var root_829 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_831 lang.IFn
														if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_82, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_830 == nil { tmp12 = ifn_831.Invoke_O__O(arg_832) } else { tmp12 = linked_830.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_829, arg_832) }
//line :117:1
	var tmp13 any = tmp12; var tmp14 any; var root_833 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_835 lang.IFn
	if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_834 == nil { tmp14 = ifn_835.Invoke_O__O(arg_836) } else { tmp14 = linked_834.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_833, arg_836) }
//line :117:1
	var tmp15 any = tmp14; var tmp16 any; var root_837 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_839 lang.IFn

	if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_86, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_838 == nil { tmp16 = ifn_839.Invoke_O__O(arg_840) } else { tmp16 = linked_838.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_837, arg_840) }
//line :117:1
	arg_821 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp13, tmp15, tmp16))
//line :116:1
	var arg_822 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__292000078); var tmp18 any; var root_841 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = s__292000079__3; if linked_842 == nil { tmp18 = ifn_843.Invoke_O__O(arg_844) } else { tmp18 = linked_842.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_841, arg_844) }; arg_822 = tmp17.Invoke_O__O(tmp18); if linked_819 == nil { return ifn_820.Invoke_O_O__O(arg_821, arg_822) } else { return linked_819.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_818, arg_821, arg_822) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :116:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :116:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A) Ctor_O_I_O(c__b__292000081 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000081 = c__b__292000081; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :116:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A) Invoke_O__O(self any) any { { var i__292000080__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000080__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000080__1)); var g__3 any; var root_760 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = p__2; if linked_761 == nil { g__3 = ifn_762.Invoke_O__O(arg_763) } else { g__3 = linked_761.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_760, arg_763) }; var root_764 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = t.F_b__292000081; var arg_768 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_156; var tmp4 any; var root_769 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_771 lang.IFn
																if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = A_arbace_j2g_dyncf_A_const_31; var arg_773 any = p__2; var arg_774 any = Lit_105; if linked_770 == nil { tmp4 = ifn_771.Invoke_O_O_O__O(arg_772, arg_773, arg_774) } else { tmp4 = linked_770.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_769, arg_772, arg_773, arg_774) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_157; var tmp8 any; var root_775 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_777 lang.IFn
																if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_82, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_776 == nil { tmp8 = ifn_777.Invoke_O__O(arg_778) } else { tmp8 = linked_776.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_775, arg_778) }
//line :117:1
	var tmp9 any = tmp8; var tmp10 any; var root_779 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_781 lang.IFn
	if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_780 == nil { tmp10 = ifn_781.Invoke_O__O(arg_782) } else { tmp10 = linked_780.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_779, arg_782) }
//line :117:1
	var tmp11 any = tmp10; var tmp12 any; var root_783 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_785 lang.IFn

	if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_86, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_784 == nil { tmp12 = ifn_785.Invoke_O__O(arg_786) } else { tmp12 = linked_784.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_783, arg_786) }
//line :117:1
	arg_768 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp9, tmp11, tmp12))
//line :116:1
	if linked_765 == nil { ifn_766.Invoke_O_O__O(arg_767, arg_768) } else { linked_765.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_764, arg_767, arg_768) }; i__292000080__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000080__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_forms_A_New() *A_arbace_j2g_dyncf_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_forms_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_j2g_dyncf_forms_A) Ctor() {}
//line :122:1
func (t *A_arbace_j2g_dyncf_forms_A) Invoke_O_O__O(self, T__0_ any) any {


	var root_852 any = A_arbace_j2g_dyncf_A_const_147.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var root_857 any = A_arbace_j2g_dyncf_A_const_161.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, A_arbace_j2g_dyncf_subs_forms_A_fn_class); var ifn_859 lang.IFn
	if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = T__0_; if linked_858 == nil { arg_855 = ifn_859.Invoke_O__O(arg_860) } else { arg_855 = linked_858.(*A_arbace_j2g_dyncf_subs_forms_A).Invoke_O_O__O(root_857, arg_860) }
//line :125:1
	var arg_856 any; var tmp1 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_166, Lit_1); var tmp2 any = A_arbace_j2g_dyncf_A_const_162; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyncf_A_const_167; var tmp5 any; var root_861 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_863 lang.IFn














	if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = Lit_2; var arg_865 any = Lit_3; if linked_862 == nil { tmp5 = ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { tmp5 = linked_862.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_861, arg_864, arg_865) }
//line :125:1
	var tmp6 any = tmp5; var tmp7 any; var root_866 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_868 lang.IFn















	if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var tmp8 any; var root_871 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = A_arbace_j2g_dyncf_A_const_169; var arg_875 any = A_arbace_j2g_dyncf_A_const_170; if linked_872 == nil { tmp8 = ifn_873.Invoke_O_O__O(arg_874, arg_875) } else { tmp8 = linked_872.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_871, arg_874, arg_875) }; var tmp9 any = tmp8; var tmp10 any; var root_876 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = A_arbace_j2g_dyncf_A_const_171; var arg_880 any = A_arbace_j2g_dyncf_A_const_172; if linked_877 == nil { tmp10 = ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { tmp10 = linked_877.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_876, arg_879, arg_880) }; var tmp11 any = tmp10; var tmp12 any; var root_881 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = A_arbace_j2g_dyncf_A_const_173; var arg_885 any = A_arbace_j2g_dyncf_A_const_174; if linked_882 == nil { tmp12 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { tmp12 = linked_882.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }; var tmp13 any = tmp12; var tmp14 any; var root_886 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_888 lang.IFn
	if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = A_arbace_j2g_dyncf_A_const_175; var arg_890 any = A_arbace_j2g_dyncf_A_const_176; if linked_887 == nil { tmp14 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { tmp14 = linked_887.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }
//line :141:1
	var tmp15 any = tmp14; var tmp16 any; var root_891 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_893 lang.IFn
	if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = A_arbace_j2g_dyncf_A_const_177; var arg_895 any = A_arbace_j2g_dyncf_A_const_178; if linked_892 == nil { tmp16 = ifn_893.Invoke_O_O__O(arg_894, arg_895) } else { tmp16 = linked_892.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_891, arg_894, arg_895) }
//line :141:1
	var tmp17 any = tmp16; var tmp18 any; var root_896 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_898 lang.IFn
	if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = A_arbace_j2g_dyncf_A_const_179; var arg_900 any = A_arbace_j2g_dyncf_A_const_180; if linked_897 == nil { tmp18 = ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { tmp18 = linked_897.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) }
//line :141:1
	arg_869 = lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp9, tmp11, tmp13, tmp15, tmp17, tmp18); var arg_870 any = A_arbace_j2g_dyncf_A_const_181; if linked_867 == nil { tmp7 = ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { tmp7 = linked_867.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_866, arg_869, arg_870) }
//line :125:1
	var tmp19 any = tmp3.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, A_arbace_j2g_dyncf_A_const_182); var tmp20 any = A_arbace_j2g_dyncf_A_const_163; var tmp21 any = A_arbace_j2g_dyncf_A_const_164; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_183; var tmp24 any; var root_901 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_903 lang.IFn















































































	if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = Lit_4; var arg_905 any = Lit_5; if linked_902 == nil { tmp24 = ifn_903.Invoke_O_O__O(arg_904, arg_905) } else { tmp24 = linked_902.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_901, arg_904, arg_905) }
//line :125:1
	var tmp25 any = tmp24; var tmp26 any; var root_906 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_908 lang.IFn
















































































	if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any; var tmp27 any; var root_911 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = A_arbace_j2g_dyncf_A_const_184; var arg_915 any = A_arbace_j2g_dyncf_A_const_185; if linked_912 == nil { tmp27 = ifn_913.Invoke_O_O__O(arg_914, arg_915) } else { tmp27 = linked_912.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_911, arg_914, arg_915) }; var tmp28 any = tmp27; var tmp29 any; var root_916 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = A_arbace_j2g_dyncf_A_const_186; var arg_920 any = A_arbace_j2g_dyncf_A_const_187; if linked_917 == nil { tmp29 = ifn_918.Invoke_O_O__O(arg_919, arg_920) } else { tmp29 = linked_917.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_916, arg_919, arg_920) }; arg_909 = lang.Tuple_Create_O_O__IPersistentVector(tmp28, tmp29); var arg_910 any = A_arbace_j2g_dyncf_A_const_188; if linked_907 == nil { tmp26 = ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { tmp26 = linked_907.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_906, arg_909, arg_910) }
//line :125:1
	var tmp30 any = tmp22.Invoke_O_O_O_O__O(tmp23, tmp25, tmp26, A_arbace_j2g_dyncf_A_const_189); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_dyncf_A_const_190; var tmp33 any; var root_921 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_923 lang.IFn























































































	if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = Lit_6; var arg_925 any = Lit_7; if linked_922 == nil { tmp33 = ifn_923.Invoke_O_O__O(arg_924, arg_925) } else { tmp33 = linked_922.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_921, arg_924, arg_925) }
//line :125:1
	var tmp34 any = tmp33; var tmp35 any; var root_926 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_928 lang.IFn
























































































	if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any; var tmp36 any; var root_931 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = A_arbace_j2g_dyncf_A_const_191; var arg_935 any = A_arbace_j2g_dyncf_A_const_192; if linked_932 == nil { tmp36 = ifn_933.Invoke_O_O__O(arg_934, arg_935) } else { tmp36 = linked_932.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_931, arg_934, arg_935) }; arg_929 = lang.Tuple_Create_O__IPersistentVector(tmp36); var arg_930 any = A_arbace_j2g_dyncf_A_const_193; if linked_927 == nil { tmp35 = ifn_928.Invoke_O_O__O(arg_929, arg_930) } else { tmp35 = linked_927.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_926, arg_929, arg_930) }
//line :125:1
	var tmp37 any = tmp31.Invoke_O_O_O_O__O(tmp32, tmp34, tmp35, A_arbace_j2g_dyncf_A_const_194); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp39 any = A_arbace_j2g_dyncf_A_const_195; var tmp40 any; var root_936 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_938 lang.IFn



























































































	if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = Lit_8; var arg_940 any = Lit_9; if linked_937 == nil { tmp40 = ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { tmp40 = linked_937.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }
//line :125:1
	var tmp41 any = tmp40; var tmp42 any; var root_941 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_943 lang.IFn




























































































	if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = A_arbace_j2g_dyncf_A_const_197; var arg_945 any = A_arbace_j2g_dyncf_A_const_198; if linked_942 == nil { tmp42 = ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { tmp42 = linked_942.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) }
//line :125:1
	var tmp43 any = tmp42; var tmp44 any; var root_946 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_948 lang.IFn




























































































	if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = A_arbace_j2g_dyncf_A_const_199; var arg_950 any = A_arbace_j2g_dyncf_A_const_200; if linked_947 == nil { tmp44 = ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { tmp44 = linked_947.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }
//line :125:1
	var tmp45 any = tmp44; var tmp46 any; var root_951 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_953 lang.IFn




























































































	if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = A_arbace_j2g_dyncf_A_const_201; var arg_955 any = A_arbace_j2g_dyncf_A_const_202; if linked_952 == nil { tmp46 = ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { tmp46 = linked_952.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) }
//line :125:1
	var tmp47 any = tmp46; var tmp48 any; var root_956 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_958 lang.IFn




























































































	if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = A_arbace_j2g_dyncf_A_const_203; var arg_960 any = A_arbace_j2g_dyncf_A_const_204; if linked_957 == nil { tmp48 = ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { tmp48 = linked_957.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }
//line :125:1
	var tmp49 any = tmp38.Invoke_O_O_O_O__O(tmp39, tmp41, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp43, tmp45, tmp47, tmp48), A_arbace_j2g_dyncf_A_const_196); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp51 any = A_arbace_j2g_dyncf_A_const_205; var tmp52 any; var root_961 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_963 lang.IFn



































































































	if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = Lit_10; var arg_965 any = Lit_11; if linked_962 == nil { tmp52 = ifn_963.Invoke_O_O__O(arg_964, arg_965) } else { tmp52 = linked_962.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_961, arg_964, arg_965) }
//line :125:1
	var tmp53 any = tmp52; var tmp54 any; var root_966 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_968 lang.IFn




































































































	if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any; var tmp55 any; var root_971 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = A_arbace_j2g_dyncf_A_const_206; var arg_975 any = A_arbace_j2g_dyncf_A_const_207; if linked_972 == nil { tmp55 = ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { tmp55 = linked_972.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) }; var tmp56 any = tmp55; var tmp57 any; var root_976 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = A_arbace_j2g_dyncf_A_const_208; var arg_980 any = A_arbace_j2g_dyncf_A_const_209; if linked_977 == nil { tmp57 = ifn_978.Invoke_O_O__O(arg_979, arg_980) } else { tmp57 = linked_977.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_976, arg_979, arg_980) }; var tmp58 any = tmp57; var tmp59 any; var root_981 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = A_arbace_j2g_dyncf_A_const_210; var arg_985 any = A_arbace_j2g_dyncf_A_const_211; if linked_982 == nil { tmp59 = ifn_983.Invoke_O_O__O(arg_984, arg_985) } else { tmp59 = linked_982.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_981, arg_984, arg_985) }; var tmp60 any = tmp59; var tmp61 any; var root_986 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = A_arbace_j2g_dyncf_A_const_212; var arg_990 any = A_arbace_j2g_dyncf_A_const_213; if linked_987 == nil { tmp61 = ifn_988.Invoke_O_O__O(arg_989, arg_990) } else { tmp61 = linked_987.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_986, arg_989, arg_990) }; arg_969 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp56, tmp58, tmp60, tmp61); var arg_970 any = A_arbace_j2g_dyncf_A_const_214; if linked_967 == nil { tmp54 = ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { tmp54 = linked_967.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_966, arg_969, arg_970) }
//line :125:1
	var tmp62 any = tmp50.Invoke_O_O_O_O__O(tmp51, tmp53, tmp54, A_arbace_j2g_dyncf_A_const_215); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyncf_A_const_216; var tmp65 any; var root_991 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_993 lang.IFn











































































































	if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = Lit_12; var arg_995 any = Lit_13; if linked_992 == nil { tmp65 = ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { tmp65 = linked_992.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) }
//line :125:1
	var tmp66 any = tmp65; var tmp67 any; var root_996 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_998 lang.IFn












































































































	if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = A_arbace_j2g_dyncf_A_const_218; var arg_1000 any = A_arbace_j2g_dyncf_A_const_219; if linked_997 == nil { tmp67 = ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { tmp67 = linked_997.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) }
//line :125:1
	var tmp68 any = tmp67; var tmp69 any; var root_1001 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1003 lang.IFn












































































































	if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = A_arbace_j2g_dyncf_A_const_220; var arg_1005 any = A_arbace_j2g_dyncf_A_const_221; if linked_1002 == nil { tmp69 = ifn_1003.Invoke_O_O__O(arg_1004, arg_1005) } else { tmp69 = linked_1002.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1001, arg_1004, arg_1005) }
//line :125:1
	var tmp70 any = tmp69; var tmp71 any; var root_1006 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1008 lang.IFn












































































































	if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = A_arbace_j2g_dyncf_A_const_222; var arg_1010 any = A_arbace_j2g_dyncf_A_const_223; if linked_1007 == nil { tmp71 = ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { tmp71 = linked_1007.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) }
//line :125:1
	var tmp72 any = tmp63.Invoke_O_O_O_O__O(tmp64, tmp66, lang.Tuple_Create_O_O_O__IPersistentVector(tmp68, tmp70, tmp71), A_arbace_j2g_dyncf_A_const_217); var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_dyncf_A_const_224; var tmp75 any; var root_1011 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1013 lang.IFn



















































































































	if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = Lit_14; var arg_1015 any = Lit_15; if linked_1012 == nil { tmp75 = ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { tmp75 = linked_1012.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) }
//line :125:1
	var tmp76 any = tmp75; var tmp77 any; var root_1016 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1018 lang.IFn




















































































































	if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = A_arbace_j2g_dyncf_A_const_226; var arg_1020 any = A_arbace_j2g_dyncf_A_const_227; if linked_1017 == nil { tmp77 = ifn_1018.Invoke_O_O__O(arg_1019, arg_1020) } else { tmp77 = linked_1017.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1016, arg_1019, arg_1020) }
//line :125:1
	var tmp78 any = tmp73.Invoke_O_O_O_O__O(tmp74, tmp76, lang.Tuple_Create_O__IPersistentVector(tmp77), A_arbace_j2g_dyncf_A_const_225); var tmp79 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp80 any = A_arbace_j2g_dyncf_A_const_228; var tmp81 any; var root_1021 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1023 lang.IFn


























































































































	if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = Lit_16; var arg_1025 any = Lit_17; if linked_1022 == nil { tmp81 = ifn_1023.Invoke_O_O__O(arg_1024, arg_1025) } else { tmp81 = linked_1022.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1021, arg_1024, arg_1025) }
//line :125:1
	var tmp82 any = tmp81; var tmp83 any; var root_1026 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1028 lang.IFn



























































































































	if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = A_arbace_j2g_dyncf_A_const_230; var arg_1030 any = A_arbace_j2g_dyncf_A_const_231; if linked_1027 == nil { tmp83 = ifn_1028.Invoke_O_O__O(arg_1029, arg_1030) } else { tmp83 = linked_1027.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1026, arg_1029, arg_1030) }
//line :125:1
	var tmp84 any = tmp83; var tmp85 any; var root_1031 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1033 lang.IFn



























































































































	if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = A_arbace_j2g_dyncf_A_const_232; var arg_1035 any = A_arbace_j2g_dyncf_A_const_233; if linked_1032 == nil { tmp85 = ifn_1033.Invoke_O_O__O(arg_1034, arg_1035) } else { tmp85 = linked_1032.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1031, arg_1034, arg_1035) }
//line :125:1
	var tmp86 any = tmp79.Invoke_O_O_O_O__O(tmp80, tmp82, lang.Tuple_Create_O_O__IPersistentVector(tmp84, tmp85), A_arbace_j2g_dyncf_A_const_229); var tmp87 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp88 any = A_arbace_j2g_dyncf_A_const_234; var tmp89 any; var root_1036 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1038 lang.IFn































































































































	if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = Lit_18; var arg_1040 any = Lit_19; if linked_1037 == nil { tmp89 = ifn_1038.Invoke_O_O__O(arg_1039, arg_1040) } else { tmp89 = linked_1037.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1036, arg_1039, arg_1040) }
//line :125:1
	var tmp90 any = tmp89; var tmp91 any; var root_1041 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1043 lang.IFn
































































































































	if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any; var tmp92 any; var root_1046 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = A_arbace_j2g_dyncf_A_const_235; var arg_1050 any = A_arbace_j2g_dyncf_A_const_236; if linked_1047 == nil { tmp92 = ifn_1048.Invoke_O_O__O(arg_1049, arg_1050) } else { tmp92 = linked_1047.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1046, arg_1049, arg_1050) }; arg_1044 = lang.Tuple_Create_O__IPersistentVector(tmp92); var arg_1045 any = A_arbace_j2g_dyncf_A_const_237; if linked_1042 == nil { tmp91 = ifn_1043.Invoke_O_O__O(arg_1044, arg_1045) } else { tmp91 = linked_1042.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1041, arg_1044, arg_1045) }
//line :125:1
	var tmp93 any = tmp87.Invoke_O_O_O_O__O(tmp88, tmp90, tmp91, A_arbace_j2g_dyncf_A_const_238); var tmp94 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp95 any = A_arbace_j2g_dyncf_A_const_239; var tmp96 any; var root_1051 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1053 lang.IFn




































































































































	if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = Lit_20; var arg_1055 any = Lit_21; if linked_1052 == nil { tmp96 = ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { tmp96 = linked_1052.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) }
//line :125:1
	var tmp97 any = tmp96; var tmp98 any; var root_1056 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1058 lang.IFn





































































































































	if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = A_arbace_j2g_dyncf_A_const_241; var arg_1060 any = A_arbace_j2g_dyncf_A_const_242; if linked_1057 == nil { tmp98 = ifn_1058.Invoke_O_O__O(arg_1059, arg_1060) } else { tmp98 = linked_1057.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1056, arg_1059, arg_1060) }
//line :125:1
	var tmp99 any = tmp98; var tmp100 any; var root_1061 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1063 lang.IFn





































































































































	if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = A_arbace_j2g_dyncf_A_const_243; var arg_1065 any = A_arbace_j2g_dyncf_A_const_244; if linked_1062 == nil { tmp100 = ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { tmp100 = linked_1062.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) }
//line :125:1
	var tmp101 any = tmp100; var tmp102 any; var root_1066 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1068 lang.IFn





































































































































	if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = A_arbace_j2g_dyncf_A_const_245; var arg_1070 any = A_arbace_j2g_dyncf_A_const_246; if linked_1067 == nil { tmp102 = ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { tmp102 = linked_1067.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) }
//line :125:1
	var tmp103 any = tmp102; var tmp104 any; var root_1071 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1073 lang.IFn





































































































































	if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = A_arbace_j2g_dyncf_A_const_247; var arg_1075 any = A_arbace_j2g_dyncf_A_const_248; if linked_1072 == nil { tmp104 = ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { tmp104 = linked_1072.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) }
//line :125:1
	var tmp105 any = tmp104; var tmp106 any; var root_1076 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1078 lang.IFn






































































































































	if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = A_arbace_j2g_dyncf_A_const_249; var arg_1080 any = A_arbace_j2g_dyncf_A_const_250; if linked_1077 == nil { tmp106 = ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { tmp106 = linked_1077.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) }
//line :125:1
	var tmp107 any = tmp106; var tmp108 any; var root_1081 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1083 lang.IFn






































































































































	if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = A_arbace_j2g_dyncf_A_const_251; var arg_1085 any = A_arbace_j2g_dyncf_A_const_252; if linked_1082 == nil { tmp108 = ifn_1083.Invoke_O_O__O(arg_1084, arg_1085) } else { tmp108 = linked_1082.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1081, arg_1084, arg_1085) }
//line :125:1
	var tmp109 any = tmp94.Invoke_O_O_O_O__O(tmp95, tmp97, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp99, tmp101, tmp103, tmp105, tmp107, tmp108), A_arbace_j2g_dyncf_A_const_240); var tmp110 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp111 any = A_arbace_j2g_dyncf_A_const_253; var tmp112 any; var root_1086 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1088 lang.IFn






































































































































































	if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = Lit_22; var arg_1090 any = Lit_23; if linked_1087 == nil { tmp112 = ifn_1088.Invoke_O_O__O(arg_1089, arg_1090) } else { tmp112 = linked_1087.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1086, arg_1089, arg_1090) }
//line :125:1
	var tmp113 any = tmp112; var tmp114 any; var root_1091 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1093 lang.IFn







































































































































































	if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = A_arbace_j2g_dyncf_A_const_255; var arg_1095 any = A_arbace_j2g_dyncf_A_const_256; if linked_1092 == nil { tmp114 = ifn_1093.Invoke_O_O__O(arg_1094, arg_1095) } else { tmp114 = linked_1092.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1091, arg_1094, arg_1095) }
//line :125:1
	var tmp115 any = tmp114; var tmp116 any; var root_1096 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1098 lang.IFn







































































































































































	if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = A_arbace_j2g_dyncf_A_const_257; var arg_1100 any = A_arbace_j2g_dyncf_A_const_258; if linked_1097 == nil { tmp116 = ifn_1098.Invoke_O_O__O(arg_1099, arg_1100) } else { tmp116 = linked_1097.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1096, arg_1099, arg_1100) }
//line :125:1
	var tmp117 any = tmp116; var tmp118 any; var root_1101 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1103 lang.IFn







































































































































































	if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = A_arbace_j2g_dyncf_A_const_259; var arg_1105 any = A_arbace_j2g_dyncf_A_const_260; if linked_1102 == nil { tmp118 = ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { tmp118 = linked_1102.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) }
//line :125:1
	var tmp119 any = tmp118; var tmp120 any; var root_1106 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1108 lang.IFn







































































































































































	if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = A_arbace_j2g_dyncf_A_const_261; var arg_1110 any = A_arbace_j2g_dyncf_A_const_262; if linked_1107 == nil { tmp120 = ifn_1108.Invoke_O_O__O(arg_1109, arg_1110) } else { tmp120 = linked_1107.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1106, arg_1109, arg_1110) }
//line :125:1
	var tmp121 any = tmp110.Invoke_O_O_O_O__O(tmp111, tmp113, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp115, tmp117, tmp119, tmp120), A_arbace_j2g_dyncf_A_const_254); var tmp122 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp123 any = A_arbace_j2g_dyncf_A_const_263; var tmp124 any; var root_1111 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1113 lang.IFn













































































































































































	if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = Lit_24; var arg_1115 any = Lit_25; if linked_1112 == nil { tmp124 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { tmp124 = linked_1112.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) }
//line :125:1
	var tmp125 any = tmp124; var tmp126 any; var root_1116 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1118 lang.IFn














































































































































































	if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = A_arbace_j2g_dyncf_A_const_265; var arg_1120 any = A_arbace_j2g_dyncf_A_const_266; if linked_1117 == nil { tmp126 = ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { tmp126 = linked_1117.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) }
//line :125:1
	var tmp127 any = tmp126; var tmp128 any; var root_1121 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1123 lang.IFn














































































































































































	if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = A_arbace_j2g_dyncf_A_const_267; var arg_1125 any = A_arbace_j2g_dyncf_A_const_268; if linked_1122 == nil { tmp128 = ifn_1123.Invoke_O_O__O(arg_1124, arg_1125) } else { tmp128 = linked_1122.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1121, arg_1124, arg_1125) }
//line :125:1
	var tmp129 any = tmp128; var tmp130 any; var root_1126 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1128 lang.IFn














































































































































































	if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any = A_arbace_j2g_dyncf_A_const_269; var arg_1130 any = A_arbace_j2g_dyncf_A_const_270; if linked_1127 == nil { tmp130 = ifn_1128.Invoke_O_O__O(arg_1129, arg_1130) } else { tmp130 = linked_1127.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1126, arg_1129, arg_1130) }
//line :125:1
	var tmp131 any = tmp130; var tmp132 any; var root_1131 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1133 lang.IFn














































































































































































	if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = A_arbace_j2g_dyncf_A_const_271; var arg_1135 any = A_arbace_j2g_dyncf_A_const_272; if linked_1132 == nil { tmp132 = ifn_1133.Invoke_O_O__O(arg_1134, arg_1135) } else { tmp132 = linked_1132.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1131, arg_1134, arg_1135) }
//line :125:1
	var tmp133 any = tmp132; var tmp134 any; var root_1136 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1138 lang.IFn














































































































































































	if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = A_arbace_j2g_dyncf_A_const_273; var arg_1140 any = A_arbace_j2g_dyncf_A_const_274; if linked_1137 == nil { tmp134 = ifn_1138.Invoke_O_O__O(arg_1139, arg_1140) } else { tmp134 = linked_1137.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1136, arg_1139, arg_1140) }
//line :125:1
	var tmp135 any = tmp122.Invoke_O_O_O_O__O(tmp123, tmp125, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp127, tmp129, tmp131, tmp133, tmp134), A_arbace_j2g_dyncf_A_const_264); var tmp136 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp137 any = A_arbace_j2g_dyncf_A_const_275; var tmp138 any; var root_1141 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1143 lang.IFn






















































































































































































	if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = Lit_26; var arg_1145 any = Lit_27; if linked_1142 == nil { tmp138 = ifn_1143.Invoke_O_O__O(arg_1144, arg_1145) } else { tmp138 = linked_1142.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1141, arg_1144, arg_1145) }
//line :125:1
	var tmp139 any = tmp138; var tmp140 any; var root_1146 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1148 lang.IFn























































































































































































	if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = A_arbace_j2g_dyncf_A_const_276; var arg_1150 any = A_arbace_j2g_dyncf_A_const_277; if linked_1147 == nil { tmp140 = ifn_1148.Invoke_O_O__O(arg_1149, arg_1150) } else { tmp140 = linked_1147.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1146, arg_1149, arg_1150) }
//line :125:1
	var tmp141 any = tmp140; var tmp142 any; var root_1151 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1153 lang.IFn























































































































































































	if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = A_arbace_j2g_dyncf_A_const_278; var arg_1155 any = A_arbace_j2g_dyncf_A_const_279; if linked_1152 == nil { tmp142 = ifn_1153.Invoke_O_O__O(arg_1154, arg_1155) } else { tmp142 = linked_1152.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1151, arg_1154, arg_1155) }
//line :125:1
	var tmp143 any = tmp142; var tmp144 any; var root_1156 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1158 lang.IFn























































































































































































	if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = A_arbace_j2g_dyncf_A_const_280; var arg_1160 any = A_arbace_j2g_dyncf_A_const_281; if linked_1157 == nil { tmp144 = ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { tmp144 = linked_1157.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) }
//line :125:1
	var tmp145 any = tmp144; var tmp146 any; var root_1161 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1163 lang.IFn























































































































































































	if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = A_arbace_j2g_dyncf_A_const_282; var arg_1165 any = A_arbace_j2g_dyncf_A_const_283; if linked_1162 == nil { tmp146 = ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { tmp146 = linked_1162.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) }
//line :125:1
	var tmp147 any = tmp146; var tmp148 any; var root_1166 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1168 lang.IFn
























































































































































































	if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = A_arbace_j2g_dyncf_A_const_284; var arg_1170 any = A_arbace_j2g_dyncf_A_const_285; if linked_1167 == nil { tmp148 = ifn_1168.Invoke_O_O__O(arg_1169, arg_1170) } else { tmp148 = linked_1167.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1166, arg_1169, arg_1170) }
//line :125:1
	var tmp149 any = tmp148; var tmp150 any; var root_1171 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1173 lang.IFn
























































































































































































	if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = A_arbace_j2g_dyncf_A_const_286; var arg_1175 any = A_arbace_j2g_dyncf_A_const_287; if linked_1172 == nil { tmp150 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { tmp150 = linked_1172.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }
//line :125:1
	var tmp151 any = tmp150; var tmp152 any; var root_1176 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1178 lang.IFn
























































































































































































	if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = A_arbace_j2g_dyncf_A_const_288; var arg_1180 any = A_arbace_j2g_dyncf_A_const_289; if linked_1177 == nil { tmp152 = ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { tmp152 = linked_1177.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) }
//line :125:1
	arg_856 = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp19, tmp20, tmp21, tmp30, tmp37, tmp49, tmp62, tmp72, tmp78, tmp86, tmp93, tmp109, tmp121, tmp135, tmp136.Invoke_O_O_O_O__O(tmp137, tmp139, lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp141, tmp143, tmp145, tmp147, tmp149, tmp151, tmp152)), A_arbace_j2g_dyncf_A_const_290), A_arbace_j2g_dyncf_A_const_165)); if linked_853 == nil { return ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { return linked_853.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_852, arg_855, arg_856)
	}
}













































































































































































































func A_arbace_j2g_dyncf_strip_anns_A_New() *A_arbace_j2g_dyncf_strip_anns_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_A{}; t.Ctor(); return t }
//line :333:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Ctor() {}
//line :333:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Invoke_O_O__O(self, x__0 any) any {
	var root_1181 any = A_arbace_j2g_dyncf_A_const_291.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_walk.A_arbace_walk_postwalk_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any; var tmp1 any = A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_New(); var tmp2 *jrt.Class; var fncls__1195 *jrt.Class = A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class; if fncls__1195 == nil { var fncls__1195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class = fncls__1195d; tmp2 = fncls__1195d } else { tmp2 = fncls__1195 }; arg_1184 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1185 any = x__0; if linked_1182 == nil { return ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { return linked_1182.(*aot_arbace_walk.A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) } }
//line :334:1
func A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_New() *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_fn__292000090_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A) Ctor() {}
//line :334:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A) Invoke_O_O__O(self, y__1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_1186 any = A_arbace_j2g_dyncf_A_const_292.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = y__1; if linked_1187 == nil { and__1927000168__auto____2 = ifn_1188.Invoke_O__O(arg_1189) } else { and__1927000168__auto____2 = linked_1187.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1186, arg_1189) }; if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = A_arbace_j2g_dyncf_A_const_293.Invoke_O__O(y__1) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_1190 any = A_arbace_j2g_dyncf_A_const_294.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = y__1; var arg_1194 any = A_arbace_j2g_dyncf_A_const_293; if linked_1191 == nil { return ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { return linked_1191.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) } } else { return y__1 } }

func A_arbace_j2g_dyncf_generics_text_A_New() *A_arbace_j2g_dyncf_generics_text_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Ctor() {}
//line :336:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Invoke_O_O__O(self, T__0_ any) any { var extendable__2 any; var root_1196 any = A_arbace_j2g_dyncf_A_const_295.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1198 lang.IFn; if





	linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any; var root_1200 any = A_arbace_j2g_dyncf_A_const_147.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = A_arbace_j2g_dyncf_A_const_296.GetRawRoot__O(); var arg_1204 any = A_arbace_j2g_dyncf_A_const_297; if linked_1201 == nil { arg_1199 = ifn_1202.Invoke_O_O__O(arg_1203, arg_1204) } else { arg_1199 = linked_1201.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1200, arg_1203, arg_1204) }; if linked_1197 == nil { extendable__2 = ifn_1198.Invoke_O__O(arg_1199) } else { extendable__2 = linked_1197.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1196, arg_1199) }; var entries__3 any; var iter__1927001039__auto____3 any; var tmp1 any = /*line :336:1*/A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_New_O(extendable__2); var tmp2 *jrt.Class; var fncls__1749 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class; if






	fncls__1749 == nil { var fncls__1749d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class = fncls__1749d; tmp2 = fncls__1749d } else { tmp2 = fncls__1749 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_2609 any = A_arbace_j2g_dyncf_A_const_334.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2609, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2611 lang.IFn; if linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = T__0_; if linked_2610 == nil { tmp4 = ifn_2611.Invoke_O__O(arg_2612) } else { tmp4 = linked_2610.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2609, arg_2612) }; entries__3 = tmp3.Invoke_O__O(tmp4); var consts__4 any; var iter__1927001039__auto____4 any; var tmp5 any = /*line :336:1*/A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_New(); var tmp6 *jrt.Class; var fncls__2108 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class; if






























	fncls__2108 == nil { var fncls__2108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class = fncls__2108d; tmp6 = fncls__2108d } else { tmp6 = fncls__2108 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp8 any; var root_2613 any = A_arbace_j2g_dyncf_A_const_334.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2615 lang.IFn; if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = T__0_; if linked_2614 == nil { tmp8 = ifn_2615.Invoke_O__O(arg_2616) } else { tmp8 = linked_2614.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2613, arg_2616) }; consts__4 = tmp7.Invoke_O__O(tmp8); var tset__5 any; var root_2109 any = /*line :336:1*/A_arbace_j2g_dyncf_A_const_295.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2111 lang.IFn; if














































	linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any = T__0_; if linked_2110 == nil { tset__5 = ifn_2111.Invoke_O__O(arg_2112) } else { tset__5 = linked_2110.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2109, arg_2112) }; var edge_consts__6 any; var iter__1927001039__auto____6 any; var tmp9 any = /*line :336:1*/A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A_New_O(tset__5); var tmp10 *jrt.Class; var fncls__2435 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A_fn_class; if















































	fncls__2435 == nil { var fncls__2435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A_fn_class = fncls__2435d; tmp10 = fncls__2435d } else { tmp10 = fncls__2435 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp12 any; var root_2617 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2619 lang.IFn; if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any = A_arbace_j2g_dyncf_A_const_335.GetRawRoot__O(); var tmp13 *lang.Keyword = A_arbace_j2g_dyncf_A_const_336; var arg_2621 any = tmp13.Invoke_O__O(A_arbace_j2g_dyncf_A_const_337.Get__O()); if linked_2618 == nil { tmp12 = ifn_2619.Invoke_O_O__O(arg_2620, arg_2621) } else { tmp12 = linked_2618.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2617, arg_2620, arg_2621) }; edge_consts__6 = tmp11.Invoke_O__O(tmp12); var consts__7 any; var root_2436 any = /*line :336:1*/A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2438 lang.IFn; if



























































	linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var arg_2440 any; var root_2441 any = A_arbace_j2g_dyncf_A_const_147.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = consts__4; var arg_2445 any = edge_consts__6; if linked_2442 == nil { arg_2440 = ifn_2443.Invoke_O_O__O(arg_2444, arg_2445) } else { arg_2440 = linked_2442.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2441, arg_2444, arg_2445) }; if linked_2437 == nil { consts__7 = ifn_2438.Invoke_O_O__O(arg_2439, arg_2440) } else { consts__7 = linked_2437.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2436, arg_2439, arg_2440) }; var root_2622 any =
	A_arbace_j2g_dyncf_A_const_39.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_338, nil, A_arbace_j2g_dyncf_A_const_339, nil, A_arbace_j2g_dyncf_A_const_340, jrt.Boolean_FALSE.Ref()); if linked_2623 == nil { ifn_2624.Invoke_O__O(arg_2625) } else { linked_2623.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2622, arg_2625) }; var tmp14 any; tmp23 := /*line :336:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





























































		{ var tmp15 *jrt.RefArray = jrt.ConstRefArray("[0,7,s92:;; Written by j2g --program (arbace.j2g.dyncf/generics-text): the generic signatures of the\ns93:;; classes of the world, for the Java forms' analysis (doc/go/CLASSFORMS-REPL.md), and under\ns44:;; :consts their public constants' values.\n{ns11:\n :consts {ns3:}}\n", []*jrt.Class{jrt.String_class}); var tmp16 any; var root_2446 any = A_arbace_j2g_dyncf_A_const_332.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2448 lang.IFn


			if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any = Lit_33; var arg_2450 any; var iter__1927001039__auto____17 any; var tmp17 any = A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A_New(); var tmp18 *jrt.Class; var fncls__2525 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A_fn_class; if fncls__2525 == nil { var fncls__2525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A_fn_class = fncls__2525d; tmp18 = fncls__2525d } else { tmp18 = fncls__2525 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); arg_2450 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(entries__3); if linked_2447 == nil { tmp16 = ifn_2448.Invoke_O_O__O(arg_2449, arg_2450) } else { tmp16 = linked_2447.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2446, arg_2449, arg_2450) }
//line :398:1
			var tmp19 any = tmp16; var tmp20 any; var root_2526 any = A_arbace_j2g_dyncf_A_const_332.GetRawRoot__O(); var linked_2527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2526, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2528 lang.IFn




			if linked_2527 == nil { ifn_2528 = lang.IFn_Cast(root_2526) } else { ifn_2528 = nil }; var arg_2529 any = Lit_35; var arg_2530 any; var iter__1927001039__auto____17_2 any; var tmp21 any = A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A_New(); var tmp22 *jrt.Class; var fncls__2605 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A_fn_class; if fncls__2605 == nil { var fncls__2605d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A_fn_class = fncls__2605d; tmp22 = fncls__2605d } else { tmp22 = fncls__2605 }; iter__1927001039__auto____17_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_2530 = lang.IFn_Cast(iter__1927001039__auto____17_2).Invoke_O__O(consts__7); if linked_2527 == nil { tmp20 = ifn_2528.Invoke_O_O__O(arg_2529, arg_2530) } else { tmp20 = linked_2527.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2526, arg_2529, arg_2530) }
//line :398:1
			tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp19, nil, tmp20, nil)).Ref() }
//line :336:1
		return nil }(); var root_2606 any = A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_2607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2606, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2608 lang.IFn; if




























































	linked_2607 == nil { ifn_2608 = lang.IFn_Cast(root_2606) } else { ifn_2608 = nil }; if linked_2607 == nil { ifn_2608.Invoke__O() } else { linked_2607.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2606) }; if /*line :336:1*/ tmp23 != nil { panic(tmp23) }; return tmp14 }






func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A{}; t.Ctor_O(p0); return t }
//line :343:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A) Ctor_O(c__extendable any) { t.F_extendable = c__extendable }
//line :343:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A) Invoke_O_O__O(self, s__292000094__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_New_O_O_O(self, s__292000094__1, t.F_extendable); var tmp2 *jrt.Class; var fncls__1748 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class; if fncls__1748 == nil { var fncls__1748d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class = fncls__1748d; tmp2 = fncls__1748d } else { tmp2 = fncls__1748 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :343:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :343:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A) Ctor_O_O_O(c__iter__292000093, c__s__292000094, c__extendable any) { t.F_iter__292000093 = c__iter__292000093; t.F_s__292000094 = c__s__292000094; t.F_extendable = c__extendable }
//line :343:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A) Invoke_O__O(self any) any { { var s__292000094__1 any; var t_ any = t.F_s__292000094; t.F_s__292000094 = nil; s__292000094__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1205 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = s__292000094__1; if linked_1206 == nil { temp__1927000414__auto____2 = ifn_1207.Invoke_O__O(arg_1208) } else { temp__1927000414__auto____2 = linked_1206.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1205, arg_1208) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000094__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1209 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = s__292000094__3; if linked_1210 == nil { tmp1 = ifn_1211.Invoke_O__O(arg_1212) } else { tmp1 = linked_1210.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1209, arg_1212) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1213 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = s__292000094__3; if linked_1214 == nil { c__1927001037__auto____4 = ifn_1215.Invoke_O__O(arg_1216) } else { c__1927001037__auto____4 = linked_1214.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1213, arg_1216) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000096__6 any; var root_1217 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1218 == nil { b__292000096__6 = ifn_1219.Invoke_O__O(arg_1220) } else { b__292000096__6 = linked_1218.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1217, arg_1220) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_New_O_O_I_O(b__292000096__6, t.F_extendable, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1463 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class; if fncls__1463 == nil { var fncls__1463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class = fncls__1463d; tmp3 = fncls__1463d } else { tmp3 = fncls__1463 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1464 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any; var root_1469 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = b__292000096__6; if linked_1470 == nil { arg_1467 = ifn_1471.Invoke_O__O(arg_1472) } else { arg_1467 = linked_1470.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1469, arg_1472) }; var arg_1468 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000093); var tmp5 any; var root_1473 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = s__292000094__3; if linked_1474 == nil { tmp5 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp5 = linked_1474.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1473, arg_1476) }; arg_1468 = tmp4.Invoke_O__O(tmp5); if linked_1465 == nil { return ifn_1466.Invoke_O_O__O(arg_1467, arg_1468) } else { return linked_1465.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1464, arg_1467, arg_1468) } } else { var root_1477 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any; var root_1482 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = b__292000096__6; if linked_1483 == nil { arg_1480 = ifn_1484.Invoke_O__O(arg_1485) } else { arg_1480 = linked_1483.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1482, arg_1485) }; var arg_1481 any; if linked_1478 == nil { return ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { return linked_1478.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) } } } else { var n__4 any; var root_1486 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = s__292000094__3; if linked_1487 == nil { n__4 = ifn_1488.Invoke_O__O(arg_1489) } else { n__4 = linked_1487.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1486, arg_1489) }; var d__5 any; var root_1490 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1492 lang.IFn
														if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = n__4; if linked_1491 == nil { d__5 = ifn_1492.Invoke_O__O(arg_1493) } else { d__5 = linked_1491.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1490, arg_1493) }
//line :343:1
	var tmp6 any
	var and__1927000168__auto____6 any = d__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1494 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_318); var arg_1497 any = tmp7.Invoke_O__O(A_arbace_j2g_dyncf_A_const_299.Invoke_O__O(d__5)); if linked_1495 == nil { and__1927000168__auto____7 = ifn_1496.Invoke_O__O(arg_1497) } else { and__1927000168__auto____7 = linked_1495.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1494, arg_1497) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var or__1927000174__auto____8 any; var root_1498 any = A_arbace_j2g_dyncf_A_const_300.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1500 lang.IFn
		if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = n__4; if linked_1499 == nil { or__1927000174__auto____8 = ifn_1500.Invoke_O__O(arg_1501) } else { or__1927000174__auto____8 = linked_1499.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1498, arg_1501) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__4) } } else {
//line :347:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }
//line :343:1
	if jrt.J2g_Truth(tmp6) { var g__6 any; var tmp8 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_New_O(n__4); var tmp9 *jrt.Class
		var fncls__1502 /*line :343:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class





		if fncls__1502 == nil { var fncls__1502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class = fncls__1502d; tmp9 = fncls__1502d } else { tmp9 = fncls__1502 }; g__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()
//line :343:1
		if jrt.J2g_Truth(g__6) { var generic_QMARK___7 any; var root_1503 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1505 lang.IFn







			if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(g__6); if linked_1504 == nil { generic_QMARK___7 = ifn_1505.Invoke_O__O(arg_1506) } else { generic_QMARK___7 = linked_1504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1503, arg_1506) }
//line :343:1
			var supers__8 any; var root_1507 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1509 lang.IFn








			if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any; var root_1511 any = A_arbace_j2g_dyncf_A_const_304.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = A_arbace_j2g_dyncf_A_const_305.GetRawRoot__O(); var arg_1515 any = A_arbace_j2g_dyncf_A_const_306.Invoke_O__O(g__6); if linked_1512 == nil { arg_1510 = ifn_1513.Invoke_O_O__O(arg_1514, arg_1515) } else { arg_1510 = linked_1512.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1511, arg_1514, arg_1515) }; if linked_1508 == nil { supers__8 = ifn_1509.Invoke_O__O(arg_1510) } else { supers__8 = linked_1508.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1507, arg_1510) }
//line :343:1
			var abstract_QMARK___9 any; var and__1927000168__auto____9 any; var root_1516 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1518 lang.IFn









			if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any; var root_1520 any = A_arbace_j2g_dyncf_A_const_300.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = n__4; if linked_1521 == nil { arg_1519 = ifn_1522.Invoke_O__O(arg_1523) } else { arg_1519 = linked_1521.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1520, arg_1523) }; if linked_1517 == nil { and__1927000168__auto____9 = ifn_1518.Invoke_O__O(arg_1519) } else { and__1927000168__auto____9 = linked_1517.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1516, arg_1519) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp10 int64; var na_1524 any; var or__1927000174__auto____10 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(d__5); if jrt.J2g_Truth(or__1927000174__auto____10) { na_1524 = or__1927000174__auto____10 } else { na_1524 = A_arbace_j2g_dyncf_A_const_308 }; var na_1525 int64 = 1024; if jrt.Long_InstanceOf(na_1524) { var n0_1526 int64 = jrt.NN(jrt.Long_Cast(na_1524)).LongValue__J(); var n1_1527 int64 = na_1525; tmp10 = n0_1526 & n1_1527 } else { tmp10 = lang.Numbers_And_O_J__J_NoInit(na_1524, na_1525) }; abstract_QMARK___9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp10)).Ref() } else { abstract_QMARK___9 = and__1927000168__auto____9 }
//line :343:1
			var tmp11 any
			var or__1927000174__auto____10_2 any = generic_QMARK___7









			if jrt.J2g_Truth(or__1927000174__auto____10_2) { tmp11 = or__1927000174__auto____10_2 } else { var or__1927000174__auto____11 any = abstract_QMARK___9; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp11 = or__1927000174__auto____11 } else { var root_1529 any = A_arbace_j2g_dyncf_A_const_309.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any; var root_1534 any = A_arbace_j2g_dyncf_A_const_310.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var arg_1538 any = A_arbace_j2g_dyncf_A_const_311; if linked_1535 == nil { arg_1532 = ifn_1536.Invoke_O_O__O(arg_1537, arg_1538) } else { arg_1532 = linked_1535.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1534, arg_1537, arg_1538) }; var arg_1533 any = supers__8; if linked_1530 == nil { tmp11 = ifn_1531.Invoke_O_O__O(arg_1532, arg_1533) } else { tmp11 = linked_1530.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1529, arg_1532, arg_1533) } } }
//line :343:1
			if jrt.J2g_Truth(tmp11) { var root_1539 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any; var tmp12 any; var root_1544 any = A_arbace_j2g_dyncf_A_const_312.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_1546 lang.IFn











				if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any; var G__292000126__10_ any; var tmp13 any = A_arbace_j2g_dyncf_A_const_302; var tmp14 any; var root_1548 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1550 lang.IFn
				if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(g__6); if linked_1549 == nil { tmp14 = ifn_1550.Invoke_O__O(arg_1551) } else { tmp14 = linked_1549.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1548, arg_1551) }
//line :355:1
				G__292000126__10_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, A_arbace_j2g_dyncf_A_const_306, supers__8)); var G__292000126__11_ any
				if jrt.J2g_Truth(abstract_QMARK___9) {
					var root_1552 any = A_arbace_j2g_dyncf_A_const_313.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = G__292000126__10_; var arg_1556 any = A_arbace_j2g_dyncf_A_const_314; var arg_1557 any; var root_1558 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any; var iter__1927001039__auto____11 any; var tmp15 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_New(); var tmp16 *jrt.Class; var fncls__1638 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class; if fncls__1638 == nil { var fncls__1638d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class = fncls__1638d; tmp16 = fncls__1638d } else { tmp16 = fncls__1638 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); arg_1561 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(d__5)); if linked_1559 == nil { arg_1557 = ifn_1560.Invoke_O__O(arg_1561) } else { arg_1557 = linked_1559.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1558, arg_1561) }; if linked_1553 == nil { G__292000126__11_ = ifn_1554.Invoke_O_O_O__O(arg_1555, arg_1556, arg_1557) } else { G__292000126__11_ = linked_1553.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1552, arg_1555, arg_1556, arg_1557) } } else {
//line :356:1
						G__292000126__11_ = G__292000126__10_ }; if jrt.J2g_Truth(generic_QMARK___7) {




							var root_1639 any = A_arbace_j2g_dyncf_A_const_313.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = G__292000126__11_; var arg_1643 any = A_arbace_j2g_dyncf_A_const_108; var arg_1644 any; var root_1645 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any; var iter__1927001039__auto____12 any; var tmp17 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_New(); var tmp18 *jrt.Class; var fncls__1731 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class; if fncls__1731 == nil { var fncls__1731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class = fncls__1731d; tmp18 = fncls__1731d } else { tmp18 = fncls__1731 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); arg_1648 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__6)); if linked_1646 == nil { arg_1644 = ifn_1647.Invoke_O__O(arg_1648) } else { arg_1644 = linked_1646.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1645, arg_1648) }; if linked_1640 == nil { arg_1547 = ifn_1641.Invoke_O_O_O__O(arg_1642, arg_1643, arg_1644) } else { arg_1547 = linked_1640.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1639, arg_1642, arg_1643, arg_1644) } } else {
//line :356:1
								arg_1547 = G__292000126__11_ }
//line :355:1
				if linked_1545 == nil { tmp12 = ifn_1546.Invoke_O__O(arg_1547) } else { tmp12 = linked_1545.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_1544, arg_1547) }
//line :343:1
				arg_1542 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp12); var arg_1543 any; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__292000093); var tmp20 any; var root_1732 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = s__292000094__3; if linked_1733 == nil { tmp20 = ifn_1734.Invoke_O__O(arg_1735) } else { tmp20 = linked_1733.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1732, arg_1735) }; arg_1543 = tmp19.Invoke_O__O(tmp20); if linked_1540 == nil { return ifn_1541.Invoke_O_O__O(arg_1542, arg_1543) } else { return linked_1540.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1539, arg_1542, arg_1543) } } else { var tmp21 any; var root_1736 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = s__292000094__3; if linked_1737 == nil { tmp21 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp21 = linked_1737.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1736, arg_1739) }; s__292000094__1 = tmp21; continue L1 } } else { var tmp22 any; var root_1740 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = s__292000094__3; if linked_1741 == nil { tmp22 = ifn_1742.Invoke_O__O(arg_1743) } else { tmp22 = linked_1741.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1740, arg_1743) }; s__292000094__1 = tmp22; continue L1 } } else { var tmp23 any; var root_1744 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = s__292000094__3; if linked_1745 == nil { tmp23 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp23 = linked_1745.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1744, arg_1747) }; s__292000094__1 = tmp23; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :343:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :343:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A) Ctor_O_O_I_O(c__b__292000096, c__extendable any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000096 = c__b__292000096; t.F_extendable = c__extendable; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :343:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A) Invoke_O__O(self any) any { { var i__292000095__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000095__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000095__1)); var d__3 any; var root_1221 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1223 lang.IFn
																if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = n__2; if linked_1222 == nil { d__3 = ifn_1223.Invoke_O__O(arg_1224) } else { d__3 = linked_1222.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1221, arg_1224) }
//line :343:1
	var tmp2 any
	var and__1927000168__auto____4 any = d__3


	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1225 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_298); var arg_1228 any = tmp3.Invoke_O__O(A_arbace_j2g_dyncf_A_const_299.Invoke_O__O(d__3)); if linked_1226 == nil { and__1927000168__auto____5 = ifn_1227.Invoke_O__O(arg_1228) } else { and__1927000168__auto____5 = linked_1226.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1225, arg_1228) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1229 any = A_arbace_j2g_dyncf_A_const_300.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1231 lang.IFn
		if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = n__2; if linked_1230 == nil { or__1927000174__auto____6 = ifn_1231.Invoke_O__O(arg_1232) } else { or__1927000174__auto____6 = linked_1230.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1229, arg_1232) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__2) } } else {
//line :347:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :343:1
	if jrt.J2g_Truth(tmp2) { var g__4 any; var tmp4 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_New_O(n__2); var tmp5 *jrt.Class
		var fncls__1233 /*line :343:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class





		if fncls__1233 == nil { var fncls__1233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class = fncls__1233d; tmp5 = fncls__1233d } else { tmp5 = fncls__1233 }; g__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :343:1
		if jrt.J2g_Truth(g__4) { var generic_QMARK___5 any; var root_1234 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1236 lang.IFn







			if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(g__4); if linked_1235 == nil { generic_QMARK___5 = ifn_1236.Invoke_O__O(arg_1237) } else { generic_QMARK___5 = linked_1235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1234, arg_1237) }
//line :343:1
			var supers__6 any; var root_1238 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1240 lang.IFn








			if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any; var root_1242 any = A_arbace_j2g_dyncf_A_const_304.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = A_arbace_j2g_dyncf_A_const_305.GetRawRoot__O(); var arg_1246 any = A_arbace_j2g_dyncf_A_const_306.Invoke_O__O(g__4); if linked_1243 == nil { arg_1241 = ifn_1244.Invoke_O_O__O(arg_1245, arg_1246) } else { arg_1241 = linked_1243.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1242, arg_1245, arg_1246) }; if linked_1239 == nil { supers__6 = ifn_1240.Invoke_O__O(arg_1241) } else { supers__6 = linked_1239.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1238, arg_1241) }
//line :343:1
			var abstract_QMARK___7 any; var and__1927000168__auto____7 any; var root_1247 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1249 lang.IFn









			if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any; var root_1251 any = A_arbace_j2g_dyncf_A_const_300.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = n__2; if linked_1252 == nil { arg_1250 = ifn_1253.Invoke_O__O(arg_1254) } else { arg_1250 = linked_1252.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1251, arg_1254) }; if linked_1248 == nil { and__1927000168__auto____7 = ifn_1249.Invoke_O__O(arg_1250) } else { and__1927000168__auto____7 = linked_1248.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1247, arg_1250) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp6 int64; var na_1255 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(d__3); if jrt.J2g_Truth(or__1927000174__auto____8) { na_1255 = or__1927000174__auto____8 } else { na_1255 = A_arbace_j2g_dyncf_A_const_308 }; var na_1256 int64 = 1024; if jrt.Long_InstanceOf(na_1255) { var n0_1257 int64 = jrt.NN(jrt.Long_Cast(na_1255)).LongValue__J(); var n1_1258 int64 = na_1256; tmp6 = n0_1257 & n1_1258 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1255, na_1256) }; abstract_QMARK___7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp6)).Ref() } else { abstract_QMARK___7 = and__1927000168__auto____7 }
//line :343:1
			var tmp7 any
			var or__1927000174__auto____8_2 any = generic_QMARK___5









			if jrt.J2g_Truth(or__1927000174__auto____8_2) { tmp7 = or__1927000174__auto____8_2 } else { var or__1927000174__auto____9 any = abstract_QMARK___7; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { var root_1260 any = A_arbace_j2g_dyncf_A_const_309.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any; var root_1265 any = A_arbace_j2g_dyncf_A_const_310.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var arg_1269 any = A_arbace_j2g_dyncf_A_const_311; if linked_1266 == nil { arg_1263 = ifn_1267.Invoke_O_O__O(arg_1268, arg_1269) } else { arg_1263 = linked_1266.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1265, arg_1268, arg_1269) }; var arg_1264 any = supers__6; if linked_1261 == nil { tmp7 = ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { tmp7 = linked_1261.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) } } }
//line :343:1
			if jrt.J2g_Truth(tmp7) { var root_1270 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1272 lang.IFn; if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = t.F_b__292000096; var arg_1274 any; var tmp8 any; var root_1275 any = A_arbace_j2g_dyncf_A_const_312.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_1277 lang.IFn











				if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any; var G__292000102__8_ any; var tmp9 any = A_arbace_j2g_dyncf_A_const_302; var tmp10 any; var root_1279 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1281 lang.IFn
				if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(g__4); if linked_1280 == nil { tmp10 = ifn_1281.Invoke_O__O(arg_1282) } else { tmp10 = linked_1280.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1279, arg_1282) }
//line :355:1
				G__292000102__8_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, A_arbace_j2g_dyncf_A_const_306, supers__6)); var G__292000102__9_ any
				if jrt.J2g_Truth(abstract_QMARK___7) {
					var root_1283 any = A_arbace_j2g_dyncf_A_const_313.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = G__292000102__8_; var arg_1287 any = A_arbace_j2g_dyncf_A_const_314; var arg_1288 any; var root_1289 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any; var iter__1927001039__auto____9 any; var tmp11 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_New(); var tmp12 *jrt.Class; var fncls__1369 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class; if fncls__1369 == nil { var fncls__1369d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class = fncls__1369d; tmp12 = fncls__1369d } else { tmp12 = fncls__1369 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1292 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(d__3)); if linked_1290 == nil { arg_1288 = ifn_1291.Invoke_O__O(arg_1292) } else { arg_1288 = linked_1290.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1289, arg_1292) }; if linked_1284 == nil { G__292000102__9_ = ifn_1285.Invoke_O_O_O__O(arg_1286, arg_1287, arg_1288) } else { G__292000102__9_ = linked_1284.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1283, arg_1286, arg_1287, arg_1288) } } else {
//line :356:1
						G__292000102__9_ = G__292000102__8_ }; if jrt.J2g_Truth(generic_QMARK___5) {




							var root_1370 any = A_arbace_j2g_dyncf_A_const_313.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = G__292000102__9_; var arg_1374 any = A_arbace_j2g_dyncf_A_const_108; var arg_1375 any; var root_1376 any = A_arbace_j2g_dyncf_A_const_303.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any; var iter__1927001039__auto____10 any; var tmp13 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_New(); var tmp14 *jrt.Class; var fncls__1462 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class; if fncls__1462 == nil { var fncls__1462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class = fncls__1462d; tmp14 = fncls__1462d } else { tmp14 = fncls__1462 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); arg_1379 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__4)); if linked_1377 == nil { arg_1375 = ifn_1378.Invoke_O__O(arg_1379) } else { arg_1375 = linked_1377.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1376, arg_1379) }; if linked_1371 == nil { arg_1278 = ifn_1372.Invoke_O_O_O__O(arg_1373, arg_1374, arg_1375) } else { arg_1278 = linked_1371.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1370, arg_1373, arg_1374, arg_1375) } } else {
//line :356:1
								arg_1278 = G__292000102__9_ }
//line :355:1
				if linked_1276 == nil { tmp8 = ifn_1277.Invoke_O__O(arg_1278) } else { tmp8 = linked_1276.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_1275, arg_1278) }
//line :343:1
				arg_1274 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp8); if linked_1271 == nil { ifn_1272.Invoke_O_O__O(arg_1273, arg_1274) } else { linked_1271.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1270, arg_1273, arg_1274) }; i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A{}; t.Ctor_O(p0); return t }
//line :349:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_301; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :349:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A{}; t.Ctor_O(p0); return t }
//line :349:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_301; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A) Ctor() {}
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A) Invoke_O_O__O(self, s__292000104__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_New_O_O(self, s__292000104__1); var tmp2 *jrt.Class; var fncls__1368 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class; if fncls__1368 == nil { var fncls__1368d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class = fncls__1368d; tmp2 = fncls__1368d } else { tmp2 = fncls__1368 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :357:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A{}; t.Ctor_O_O(p0, p1); return t }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A) Ctor_O_O(c__iter__292000103, c__s__292000104 any) { t.F_iter__292000103 = c__iter__292000103; t.F_s__292000104 = c__s__292000104 }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A) Invoke_O__O(self any) any { { var s__292000104__1 any; var t_ any = t.F_s__292000104; t.F_s__292000104 = nil; s__292000104__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1293 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = s__292000104__1; if linked_1294 == nil { temp__1927000414__auto____2 = ifn_1295.Invoke_O__O(arg_1296) } else { temp__1927000414__auto____2 = linked_1294.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1293, arg_1296) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1297 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = s__292000104__3; if linked_1298 == nil { tmp1 = ifn_1299.Invoke_O__O(arg_1300) } else { tmp1 = linked_1298.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1297, arg_1300) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1301 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = s__292000104__3; if linked_1302 == nil { c__1927001037__auto____4 = ifn_1303.Invoke_O__O(arg_1304) } else { c__1927001037__auto____4 = linked_1302.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1301, arg_1304) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000106__6 any; var root_1305 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1306 == nil { b__292000106__6 = ifn_1307.Invoke_O__O(arg_1308) } else { b__292000106__6 = linked_1306.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1305, arg_1308) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_New_O_I_O(b__292000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1319 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class; if fncls__1319 == nil { var fncls__1319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class = fncls__1319d; tmp3 = fncls__1319d } else { tmp3 = fncls__1319 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1320 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any; var root_1325 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = b__292000106__6; if linked_1326 == nil { arg_1323 = ifn_1327.Invoke_O__O(arg_1328) } else { arg_1323 = linked_1326.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1325, arg_1328) }; var arg_1324 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000103); var tmp5 any; var root_1329 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = s__292000104__3; if linked_1330 == nil { tmp5 = ifn_1331.Invoke_O__O(arg_1332) } else { tmp5 = linked_1330.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1329, arg_1332) }; arg_1324 = tmp4.Invoke_O__O(tmp5); if linked_1321 == nil { return ifn_1322.Invoke_O_O__O(arg_1323, arg_1324) } else { return linked_1321.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1320, arg_1323, arg_1324) } } else { var root_1333 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any; var root_1338 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = b__292000106__6; if linked_1339 == nil { arg_1336 = ifn_1340.Invoke_O__O(arg_1341) } else { arg_1336 = linked_1339.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1338, arg_1341) }; var arg_1337 any; if linked_1334 == nil { return ifn_1335.Invoke_O_O__O(arg_1336, arg_1337) } else { return linked_1334.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1333, arg_1336, arg_1337) } } } else { var mm__4 any; var root_1342 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = s__292000104__3; if linked_1343 == nil { mm__4 = ifn_1344.Invoke_O__O(arg_1345) } else { mm__4 = linked_1343.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1342, arg_1345) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_47, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)) { var tmp6 int64; var na_1346 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_1346 = or__1927000174__auto____5 } else { na_1346 = A_arbace_j2g_dyncf_A_const_308 }; var na_1347 int64 = 4098; if jrt.Long_InstanceOf(na_1346) { var n0_1348 int64 = jrt.NN(jrt.Long_Cast(na_1346)).LongValue__J(); var n1_1349 int64 = na_1347; tmp6 = n0_1348 & n1_1349 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1346, na_1347) }
//line :357:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1351 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__4)); var arg_1355 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000103); var tmp8 any; var root_1356 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = s__292000104__3; if linked_1357 == nil { tmp8 = ifn_1358.Invoke_O__O(arg_1359) } else { tmp8 = linked_1357.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1356, arg_1359) }; arg_1355 = tmp7.Invoke_O__O(tmp8); if linked_1352 == nil { return ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { return linked_1352.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) } } else { var tmp9 any; var root_1360 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = s__292000104__3; if linked_1361 == nil { tmp9 = ifn_1362.Invoke_O__O(arg_1363) } else { tmp9 = linked_1361.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1360, arg_1363) }; s__292000104__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1364 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = s__292000104__3; if linked_1365 == nil { tmp10 = ifn_1366.Invoke_O__O(arg_1367) } else { tmp10 = linked_1365.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1364, arg_1367) }; s__292000104__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :357:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A) Ctor_O_I_O(c__b__292000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000106 = c__b__292000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A) Invoke_O__O(self any) any { { var i__292000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000105__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_47, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)) { var tmp2 int64; var na_1309 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_1309 = or__1927000174__auto____3 } else { na_1309 = A_arbace_j2g_dyncf_A_const_308 }; var na_1310 int64 = 4098; if jrt.Long_InstanceOf(na_1309) { var n0_1311 int64 = jrt.NN(jrt.Long_Cast(na_1309)).LongValue__J(); var n1_1312 int64 = na_1310; tmp2 = n0_1311 & n1_1312 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1309, na_1310) }
//line :357:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1314 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = t.F_b__292000106; var arg_1318 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__2)); if linked_1315 == nil { ifn_1316.Invoke_O_O__O(arg_1317, arg_1318) } else { linked_1315.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1314, arg_1317, arg_1318) }; i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } else { i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } } else { i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :357:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A) Ctor() {}
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A) Invoke_O_O__O(self, s__292000128__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_New_O_O(self, s__292000128__1); var tmp2 *jrt.Class; var fncls__1637 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class; if fncls__1637 == nil { var fncls__1637d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class = fncls__1637d; tmp2 = fncls__1637d } else { tmp2 = fncls__1637 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :357:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A{}; t.Ctor_O_O(p0, p1); return t }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A) Ctor_O_O(c__iter__292000127, c__s__292000128 any) { t.F_iter__292000127 = c__iter__292000127; t.F_s__292000128 = c__s__292000128 }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A) Invoke_O__O(self any) any { { var s__292000128__1 any; var t_ any = t.F_s__292000128; t.F_s__292000128 = nil; s__292000128__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1562 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = s__292000128__1; if linked_1563 == nil { temp__1927000414__auto____2 = ifn_1564.Invoke_O__O(arg_1565) } else { temp__1927000414__auto____2 = linked_1563.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1562, arg_1565) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000128__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1566 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = s__292000128__3; if linked_1567 == nil { tmp1 = ifn_1568.Invoke_O__O(arg_1569) } else { tmp1 = linked_1567.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1566, arg_1569) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1570 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = s__292000128__3; if linked_1571 == nil { c__1927001037__auto____4 = ifn_1572.Invoke_O__O(arg_1573) } else { c__1927001037__auto____4 = linked_1571.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1570, arg_1573) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000130__6 any; var root_1574 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1575 == nil { b__292000130__6 = ifn_1576.Invoke_O__O(arg_1577) } else { b__292000130__6 = linked_1575.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1574, arg_1577) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_New_O_I_O(b__292000130__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1588 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class; if fncls__1588 == nil { var fncls__1588d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class = fncls__1588d; tmp3 = fncls__1588d } else { tmp3 = fncls__1588 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1589 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any; var root_1594 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1596 lang.IFn; if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = b__292000130__6; if linked_1595 == nil { arg_1592 = ifn_1596.Invoke_O__O(arg_1597) } else { arg_1592 = linked_1595.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1594, arg_1597) }; var arg_1593 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000127); var tmp5 any; var root_1598 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = s__292000128__3; if linked_1599 == nil { tmp5 = ifn_1600.Invoke_O__O(arg_1601) } else { tmp5 = linked_1599.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1598, arg_1601) }; arg_1593 = tmp4.Invoke_O__O(tmp5); if linked_1590 == nil { return ifn_1591.Invoke_O_O__O(arg_1592, arg_1593) } else { return linked_1590.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1589, arg_1592, arg_1593) } } else { var root_1602 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any; var root_1607 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = b__292000130__6; if linked_1608 == nil { arg_1605 = ifn_1609.Invoke_O__O(arg_1610) } else { arg_1605 = linked_1608.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1607, arg_1610) }; var arg_1606 any; if linked_1603 == nil { return ifn_1604.Invoke_O_O__O(arg_1605, arg_1606) } else { return linked_1603.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1602, arg_1605, arg_1606) } } } else { var mm__4 any; var root_1611 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = s__292000128__3; if linked_1612 == nil { mm__4 = ifn_1613.Invoke_O__O(arg_1614) } else { mm__4 = linked_1612.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1611, arg_1614) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_47, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)) { var tmp6 int64; var na_1615 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_1615 = or__1927000174__auto____5 } else { na_1615 = A_arbace_j2g_dyncf_A_const_308 }; var na_1616 int64 = 4098; if jrt.Long_InstanceOf(na_1615) { var n0_1617 int64 = jrt.NN(jrt.Long_Cast(na_1615)).LongValue__J(); var n1_1618 int64 = na_1616; tmp6 = n0_1617 & n1_1618 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1615, na_1616) }
//line :357:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1620 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__4)); var arg_1624 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000127); var tmp8 any; var root_1625 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = s__292000128__3; if linked_1626 == nil { tmp8 = ifn_1627.Invoke_O__O(arg_1628) } else { tmp8 = linked_1626.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1625, arg_1628) }; arg_1624 = tmp7.Invoke_O__O(tmp8); if linked_1621 == nil { return ifn_1622.Invoke_O_O__O(arg_1623, arg_1624) } else { return linked_1621.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1620, arg_1623, arg_1624) } } else { var tmp9 any; var root_1629 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = s__292000128__3; if linked_1630 == nil { tmp9 = ifn_1631.Invoke_O__O(arg_1632) } else { tmp9 = linked_1630.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1629, arg_1632) }; s__292000128__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1633 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = s__292000128__3; if linked_1634 == nil { tmp10 = ifn_1635.Invoke_O__O(arg_1636) } else { tmp10 = linked_1634.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1633, arg_1636) }; s__292000128__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :357:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A) Ctor_O_I_O(c__b__292000130 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000130 = c__b__292000130; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :357:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A) Invoke_O__O(self any) any { { var i__292000129__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000129__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000129__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_47, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)) { var tmp2 int64; var na_1578 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_1578 = or__1927000174__auto____3 } else { na_1578 = A_arbace_j2g_dyncf_A_const_308 }; var na_1579 int64 = 4098; if jrt.Long_InstanceOf(na_1578) { var n0_1580 int64 = jrt.NN(jrt.Long_Cast(na_1578)).LongValue__J(); var n1_1581 int64 = na_1579; tmp2 = n0_1580 & n1_1581 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1578, na_1579) }
//line :357:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1583 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = t.F_b__292000130; var arg_1587 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__2)); if linked_1584 == nil { ifn_1585.Invoke_O_O__O(arg_1586, arg_1587) } else { linked_1584.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1583, arg_1586, arg_1587) }; i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } else { i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } } else { i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A{}; t.Ctor(); return t }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A) Ctor() {}
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A) Invoke_O_O__O(self, s__292000114__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_New_O_O(self, s__292000114__1); var tmp2 *jrt.Class; var fncls__1461 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class; if fncls__1461 == nil { var fncls__1461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class = fncls__1461d; tmp2 = fncls__1461d } else { tmp2 = fncls__1461 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :361:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A) Ctor_O_O(c__iter__292000113, c__s__292000114 any) { t.F_iter__292000113 = c__iter__292000113; t.F_s__292000114 = c__s__292000114 }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A) Invoke_O__O(self any) any { { var s__292000114__1 any; var t_ any = t.F_s__292000114; t.F_s__292000114 = nil; s__292000114__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1380 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = s__292000114__1; if linked_1381 == nil { temp__1927000414__auto____2 = ifn_1382.Invoke_O__O(arg_1383) } else { temp__1927000414__auto____2 = linked_1381.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1380, arg_1383) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000114__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1384 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = s__292000114__3; if linked_1385 == nil { tmp1 = ifn_1386.Invoke_O__O(arg_1387) } else { tmp1 = linked_1385.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1384, arg_1387) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1388 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = s__292000114__3; if linked_1389 == nil { c__1927001037__auto____4 = ifn_1390.Invoke_O__O(arg_1391) } else { c__1927001037__auto____4 = linked_1389.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1388, arg_1391) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000116__6 any; var root_1392 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1393 == nil { b__292000116__6 = ifn_1394.Invoke_O__O(arg_1395) } else { b__292000116__6 = linked_1393.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1392, arg_1395) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_New_O_I_O(b__292000116__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1411 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class; if fncls__1411 == nil { var fncls__1411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class = fncls__1411d; tmp3 = fncls__1411d } else { tmp3 = fncls__1411 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1412 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any; var root_1417 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = b__292000116__6; if linked_1418 == nil { arg_1415 = ifn_1419.Invoke_O__O(arg_1420) } else { arg_1415 = linked_1418.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1417, arg_1420) }; var arg_1416 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000113); var tmp5 any; var root_1421 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = s__292000114__3; if linked_1422 == nil { tmp5 = ifn_1423.Invoke_O__O(arg_1424) } else { tmp5 = linked_1422.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1421, arg_1424) }; arg_1416 = tmp4.Invoke_O__O(tmp5); if linked_1413 == nil { return ifn_1414.Invoke_O_O__O(arg_1415, arg_1416) } else { return linked_1413.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1412, arg_1415, arg_1416) } } else { var root_1425 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any; var root_1430 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = b__292000116__6; if linked_1431 == nil { arg_1428 = ifn_1432.Invoke_O__O(arg_1433) } else { arg_1428 = linked_1431.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1430, arg_1433) }; var arg_1429 any; if linked_1426 == nil { return ifn_1427.Invoke_O_O__O(arg_1428, arg_1429) } else { return linked_1426.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1425, arg_1428, arg_1429) } } } else { var mm__4 any; var root_1434 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = s__292000114__3; if linked_1435 == nil { mm__4 = ifn_1436.Invoke_O__O(arg_1437) } else { mm__4 = linked_1435.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1434, arg_1437) }; var tmp6 int64; var na_1438 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { na_1438 = or__1927000174__auto____5 } else { na_1438 = A_arbace_j2g_dyncf_A_const_308 }; var na_1439 int64 = 4098; if jrt.Long_InstanceOf(na_1438) { var n0_1440 int64 = jrt.NN(jrt.Long_Cast(na_1438)).LongValue__J(); var n1_1441 int64 = na_1439; tmp6 = n0_1440 & n1_1441 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1438, na_1439) }
//line :361:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1443 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any; var root_1448 any = A_arbace_j2g_dyncf_A_const_315.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1450 lang.IFn

		if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = mm__4; var arg_1452 any = A_arbace_j2g_dyncf_A_const_317; if linked_1449 == nil { arg_1446 = ifn_1450.Invoke_O_O__O(arg_1451, arg_1452) } else { arg_1446 = linked_1449.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1448, arg_1451, arg_1452) }
//line :361:1
		var arg_1447 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000113); var tmp8 any; var root_1453 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = s__292000114__3; if linked_1454 == nil { tmp8 = ifn_1455.Invoke_O__O(arg_1456) } else { tmp8 = linked_1454.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1453, arg_1456) }; arg_1447 = tmp7.Invoke_O__O(tmp8); if linked_1444 == nil { return ifn_1445.Invoke_O_O__O(arg_1446, arg_1447) } else { return linked_1444.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1443, arg_1446, arg_1447) } } else { var tmp9 any; var root_1457 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = s__292000114__3; if linked_1458 == nil { tmp9 = ifn_1459.Invoke_O__O(arg_1460) } else { tmp9 = linked_1458.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1457, arg_1460) }; s__292000114__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :361:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A) Ctor_O_I_O(c__b__292000116 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000116 = c__b__292000116; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A) Invoke_O__O(self any) any { { var i__292000115__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000115__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000115__1)); var tmp2 int64; var na_1396 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { na_1396 = or__1927000174__auto____3 } else { na_1396 = A_arbace_j2g_dyncf_A_const_308 }; var na_1397 int64 = 4098; if jrt.Long_InstanceOf(na_1396) { var n0_1398 int64 = jrt.NN(jrt.Long_Cast(na_1396)).LongValue__J(); var n1_1399 int64 = na_1397; tmp2 = n0_1398 & n1_1399 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1396, na_1397) }
//line :361:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1401 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = t.F_b__292000116; var arg_1405 any; var root_1406 any = A_arbace_j2g_dyncf_A_const_315.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1408 lang.IFn

		if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = mm__2; var arg_1410 any = A_arbace_j2g_dyncf_A_const_316; if linked_1407 == nil { arg_1405 = ifn_1408.Invoke_O_O__O(arg_1409, arg_1410) } else { arg_1405 = linked_1407.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1406, arg_1409, arg_1410) }
//line :361:1
		if linked_1402 == nil { ifn_1403.Invoke_O_O__O(arg_1404, arg_1405) } else { linked_1402.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1401, arg_1404, arg_1405) }; i__292000115__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000115__1); continue L1 } else { i__292000115__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000115__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :361:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A{}; t.Ctor(); return t }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A) Ctor() {}
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A) Invoke_O_O__O(self, s__292000138__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_New_O_O(self, s__292000138__1); var tmp2 *jrt.Class; var fncls__1730 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class; if fncls__1730 == nil { var fncls__1730d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class = fncls__1730d; tmp2 = fncls__1730d } else { tmp2 = fncls__1730 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :361:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A) Ctor_O_O(c__iter__292000137, c__s__292000138 any) { t.F_iter__292000137 = c__iter__292000137; t.F_s__292000138 = c__s__292000138 }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A) Invoke_O__O(self any) any { { var s__292000138__1 any; var t_ any = t.F_s__292000138; t.F_s__292000138 = nil; s__292000138__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1649 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = s__292000138__1; if linked_1650 == nil { temp__1927000414__auto____2 = ifn_1651.Invoke_O__O(arg_1652) } else { temp__1927000414__auto____2 = linked_1650.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1649, arg_1652) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000138__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1653 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = s__292000138__3; if linked_1654 == nil { tmp1 = ifn_1655.Invoke_O__O(arg_1656) } else { tmp1 = linked_1654.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1653, arg_1656) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1657 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = s__292000138__3; if linked_1658 == nil { c__1927001037__auto____4 = ifn_1659.Invoke_O__O(arg_1660) } else { c__1927001037__auto____4 = linked_1658.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1657, arg_1660) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000140__6 any; var root_1661 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1663 lang.IFn; if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1662 == nil { b__292000140__6 = ifn_1663.Invoke_O__O(arg_1664) } else { b__292000140__6 = linked_1662.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1661, arg_1664) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_New_O_I_O(b__292000140__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1680 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class; if fncls__1680 == nil { var fncls__1680d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class = fncls__1680d; tmp3 = fncls__1680d } else { tmp3 = fncls__1680 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1681 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any; var root_1686 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = b__292000140__6; if linked_1687 == nil { arg_1684 = ifn_1688.Invoke_O__O(arg_1689) } else { arg_1684 = linked_1687.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1686, arg_1689) }; var arg_1685 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000137); var tmp5 any; var root_1690 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = s__292000138__3; if linked_1691 == nil { tmp5 = ifn_1692.Invoke_O__O(arg_1693) } else { tmp5 = linked_1691.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1690, arg_1693) }; arg_1685 = tmp4.Invoke_O__O(tmp5); if linked_1682 == nil { return ifn_1683.Invoke_O_O__O(arg_1684, arg_1685) } else { return linked_1682.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1681, arg_1684, arg_1685) } } else { var root_1694 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1694, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any; var root_1699 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = b__292000140__6; if linked_1700 == nil { arg_1697 = ifn_1701.Invoke_O__O(arg_1702) } else { arg_1697 = linked_1700.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1699, arg_1702) }; var arg_1698 any; if linked_1695 == nil { return ifn_1696.Invoke_O_O__O(arg_1697, arg_1698) } else { return linked_1695.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1694, arg_1697, arg_1698) } } } else { var mm__4 any; var root_1703 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = s__292000138__3; if linked_1704 == nil { mm__4 = ifn_1705.Invoke_O__O(arg_1706) } else { mm__4 = linked_1704.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1703, arg_1706) }; var tmp6 int64; var na_1707 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { na_1707 = or__1927000174__auto____5 } else { na_1707 = A_arbace_j2g_dyncf_A_const_308 }; var na_1708 int64 = 4098; if jrt.Long_InstanceOf(na_1707) { var n0_1709 int64 = jrt.NN(jrt.Long_Cast(na_1707)).LongValue__J(); var n1_1710 int64 = na_1708; tmp6 = n0_1709 & n1_1710 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1707, na_1708) }
//line :361:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1712 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any; var root_1717 any = A_arbace_j2g_dyncf_A_const_315.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1719 lang.IFn

		if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = mm__4; var arg_1721 any = A_arbace_j2g_dyncf_A_const_320; if linked_1718 == nil { arg_1715 = ifn_1719.Invoke_O_O__O(arg_1720, arg_1721) } else { arg_1715 = linked_1718.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1717, arg_1720, arg_1721) }
//line :361:1
		var arg_1716 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000137); var tmp8 any; var root_1722 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1724 lang.IFn; if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = s__292000138__3; if linked_1723 == nil { tmp8 = ifn_1724.Invoke_O__O(arg_1725) } else { tmp8 = linked_1723.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1722, arg_1725) }; arg_1716 = tmp7.Invoke_O__O(tmp8); if linked_1713 == nil { return ifn_1714.Invoke_O_O__O(arg_1715, arg_1716) } else { return linked_1713.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1712, arg_1715, arg_1716) } } else { var tmp9 any; var root_1726 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = s__292000138__3; if linked_1727 == nil { tmp9 = ifn_1728.Invoke_O__O(arg_1729) } else { tmp9 = linked_1727.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1726, arg_1729) }; s__292000138__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :361:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A) Ctor_O_I_O(c__b__292000140 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000140 = c__b__292000140; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :361:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A) Invoke_O__O(self any) any { { var i__292000139__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000139__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000139__1)); var tmp2 int64; var na_1665 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(mm__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { na_1665 = or__1927000174__auto____3 } else { na_1665 = A_arbace_j2g_dyncf_A_const_308 }; var na_1666 int64 = 4098; if jrt.Long_InstanceOf(na_1665) { var n0_1667 int64 = jrt.NN(jrt.Long_Cast(na_1665)).LongValue__J(); var n1_1668 int64 = na_1666; tmp2 = n0_1667 & n1_1668 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1665, na_1666) }
//line :361:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1670 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1672 lang.IFn; if linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = t.F_b__292000140; var arg_1674 any; var root_1675 any = A_arbace_j2g_dyncf_A_const_315.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1677 lang.IFn

		if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = mm__2; var arg_1679 any = A_arbace_j2g_dyncf_A_const_319; if linked_1676 == nil { arg_1674 = ifn_1677.Invoke_O_O__O(arg_1678, arg_1679) } else { arg_1674 = linked_1676.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1675, arg_1678, arg_1679) }
//line :361:1
		if linked_1671 == nil { ifn_1672.Invoke_O_O__O(arg_1673, arg_1674) } else { linked_1671.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1670, arg_1673, arg_1674) }; i__292000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000139__1); continue L1 } else { i__292000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000139__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A) Ctor() {}
//line :367:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A) Invoke_O_O__O(self, s__292000150__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_New_O_O(s__292000150__1, self); var tmp2 *jrt.Class; var fncls__2107 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class; if fncls__2107 == nil { var fncls__2107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class = fncls__2107d; tmp2 = fncls__2107d } else { tmp2 = fncls__2107 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :367:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :367:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A) Ctor_O_O(c__s__292000150, c__iter__292000149 any) { t.F_s__292000150 = c__s__292000150; t.F_iter__292000149 = c__iter__292000149 }
//line :367:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A) Invoke_O__O(self any) any { { var s__292000150__1 any; var t_ any = t.F_s__292000150; t.F_s__292000150 = nil; s__292000150__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1750 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = s__292000150__1; if linked_1751 == nil { temp__1927000414__auto____2 = ifn_1752.Invoke_O__O(arg_1753) } else { temp__1927000414__auto____2 = linked_1751.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1750, arg_1753) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000150__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1754 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = s__292000150__3; if linked_1755 == nil { tmp1 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp1 = linked_1755.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1754, arg_1757) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1758 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = s__292000150__3; if linked_1759 == nil { c__1927001037__auto____4 = ifn_1760.Invoke_O__O(arg_1761) } else { c__1927001037__auto____4 = linked_1759.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1758, arg_1761) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000152__6 any; var root_1762 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1763 == nil { b__292000152__6 = ifn_1764.Invoke_O__O(arg_1765) } else { b__292000152__6 = linked_1763.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1762, arg_1765) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_New_O_I_O(b__292000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1917 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class; if fncls__1917 == nil { var fncls__1917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class = fncls__1917d; tmp3 = fncls__1917d } else { tmp3 = fncls__1917 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1918 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any; var root_1923 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = b__292000152__6; if linked_1924 == nil { arg_1921 = ifn_1925.Invoke_O__O(arg_1926) } else { arg_1921 = linked_1924.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1923, arg_1926) }; var arg_1922 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000149); var tmp5 any; var root_1927 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = s__292000150__3; if linked_1928 == nil { tmp5 = ifn_1929.Invoke_O__O(arg_1930) } else { tmp5 = linked_1928.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1927, arg_1930) }; arg_1922 = tmp4.Invoke_O__O(tmp5); if linked_1919 == nil { return ifn_1920.Invoke_O_O__O(arg_1921, arg_1922) } else { return linked_1919.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1918, arg_1921, arg_1922) } } else { var root_1931 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1931, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1933 lang.IFn; if linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any; var root_1936 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1938 lang.IFn; if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = b__292000152__6; if linked_1937 == nil { arg_1934 = ifn_1938.Invoke_O__O(arg_1939) } else { arg_1934 = linked_1937.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1936, arg_1939) }; var arg_1935 any; if linked_1932 == nil { return ifn_1933.Invoke_O_O__O(arg_1934, arg_1935) } else { return linked_1932.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1931, arg_1934, arg_1935) } } } else { var n__4 any; var root_1940 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1942 lang.IFn; if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = s__292000150__3; if linked_1941 == nil { n__4 = ifn_1942.Invoke_O__O(arg_1943) } else { n__4 = linked_1941.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1940, arg_1943) }; var d__5 any; var root_1944 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1946 lang.IFn
														if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = n__4; if linked_1945 == nil { d__5 = ifn_1946.Invoke_O__O(arg_1947) } else { d__5 = linked_1945.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1944, arg_1947) }
//line :367:1
	var tmp6 any
	var and__1927000168__auto____6 any = d__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1948 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_329); var arg_1951 any = tmp7.Invoke_O__O(A_arbace_j2g_dyncf_A_const_299.Invoke_O__O(d__5)); if linked_1949 == nil { and__1927000168__auto____7 = ifn_1950.Invoke_O__O(arg_1951) } else { and__1927000168__auto____7 = linked_1949.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1948, arg_1951) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
		var tmp8 int64; var na_1952 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(d__5); if jrt.J2g_Truth(or__1927000174__auto____8) { na_1952 = or__1927000174__auto____8 } else { na_1952 = A_arbace_j2g_dyncf_A_const_308 }; var na_1953 int64 = 1; if jrt.Long_InstanceOf(na_1952) { var n0_1954 int64 = jrt.NN(jrt.Long_Cast(na_1952)).LongValue__J(); var n1_1955 int64 = na_1953; tmp8 = n0_1954 & n1_1955 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_1952, na_1953) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp8)).Ref() } else {
//line :369:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }
//line :367:1
	if jrt.J2g_Truth(tmp6) { var cs__6 any; var root_1957 any = A_arbace_j2g_dyncf_A_const_322.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1959 lang.IFn



		if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_323.GetRawRoot__O()).Invoke__O(); var arg_1961 any; var iter__1927001039__auto____6 any; var tmp9 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A_New(); var tmp10 *jrt.Class; var fncls__2085 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A_fn_class
		if fncls__2085 == nil { var fncls__2085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A_fn_class = fncls__2085d; tmp10 = fncls__2085d } else { tmp10 = fncls__2085 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_1961 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(A_arbace_j2g_dyncf_A_const_328.Invoke_O__O(d__5))
//line :371:1
		if linked_1958 == nil { cs__6 = ifn_1959.Invoke_O_O__O(arg_1960, arg_1961) } else { cs__6 = linked_1958.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1957, arg_1960, arg_1961) }
//line :367:1
		var tmp11 any; var root_2086 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2088 lang.IFn











		if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any = cs__6; if linked_2087 == nil { tmp11 = ifn_2088.Invoke_O__O(arg_2089) } else { tmp11 = linked_2087.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2086, arg_2089) }
//line :367:1
		if jrt.J2g_Truth(tmp11) { var root_2090 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = lang.Tuple_Create_O_O__IPersistentVector(n__4, cs__6); var arg_2094 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__292000149); var tmp13 any; var root_2095 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any = s__292000150__3; if linked_2096 == nil { tmp13 = ifn_2097.Invoke_O__O(arg_2098) } else { tmp13 = linked_2096.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2095, arg_2098) }; arg_2094 = tmp12.Invoke_O__O(tmp13); if linked_2091 == nil { return ifn_2092.Invoke_O_O__O(arg_2093, arg_2094) } else { return linked_2091.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2090, arg_2093, arg_2094) } } else { var tmp14 any; var root_2099 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = s__292000150__3; if linked_2100 == nil { tmp14 = ifn_2101.Invoke_O__O(arg_2102) } else { tmp14 = linked_2100.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2099, arg_2102) }; s__292000150__1 = tmp14; continue L1 } } else { var tmp15 any; var root_2103 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = s__292000150__3; if linked_2104 == nil { tmp15 = ifn_2105.Invoke_O__O(arg_2106) } else { tmp15 = linked_2104.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2103, arg_2106) }; s__292000150__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :367:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :367:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A) Ctor_O_I_O(c__b__292000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000152 = c__b__292000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :367:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A) Invoke_O__O(self any) any { { var i__292000151__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000151__1)); var d__3 any; var root_1766 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1768 lang.IFn
																if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = n__2; if linked_1767 == nil { d__3 = ifn_1768.Invoke_O__O(arg_1769) } else { d__3 = linked_1767.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1766, arg_1769) }
//line :367:1
	var tmp2 any
	var and__1927000168__auto____4 any = d__3
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1770 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_321); var arg_1773 any = tmp3.Invoke_O__O(A_arbace_j2g_dyncf_A_const_299.Invoke_O__O(d__3)); if linked_1771 == nil { and__1927000168__auto____5 = ifn_1772.Invoke_O__O(arg_1773) } else { and__1927000168__auto____5 = linked_1771.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1770, arg_1773) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
		var tmp4 int64; var na_1774 any; var or__1927000174__auto____6 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(d__3); if jrt.J2g_Truth(or__1927000174__auto____6) { na_1774 = or__1927000174__auto____6 } else { na_1774 = A_arbace_j2g_dyncf_A_const_308 }; var na_1775 int64 = 1; if jrt.Long_InstanceOf(na_1774) { var n0_1776 int64 = jrt.NN(jrt.Long_Cast(na_1774)).LongValue__J(); var n1_1777 int64 = na_1775; tmp4 = n0_1776 & n1_1777 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_1774, na_1775) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp4)).Ref() } else {
//line :369:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :367:1
	if jrt.J2g_Truth(tmp2) { var cs__4 any; var root_1779 any = A_arbace_j2g_dyncf_A_const_322.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1781 lang.IFn



		if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_323.GetRawRoot__O()).Invoke__O(); var arg_1783 any; var iter__1927001039__auto____4 any; var tmp5 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A_New(); var tmp6 *jrt.Class; var fncls__1907 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A_fn_class
		if fncls__1907 == nil { var fncls__1907d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A_fn_class = fncls__1907d; tmp6 = fncls__1907d } else { tmp6 = fncls__1907 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); arg_1783 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_j2g_dyncf_A_const_328.Invoke_O__O(d__3))
//line :371:1
		if linked_1780 == nil { cs__4 = ifn_1781.Invoke_O_O__O(arg_1782, arg_1783) } else { cs__4 = linked_1780.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1779, arg_1782, arg_1783) }
//line :367:1
		var tmp7 any; var root_1908 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1908, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1910 lang.IFn











		if linked_1909 == nil { ifn_1910 = lang.IFn_Cast(root_1908) } else { ifn_1910 = nil }; var arg_1911 any = cs__4; if linked_1909 == nil { tmp7 = ifn_1910.Invoke_O__O(arg_1911) } else { tmp7 = linked_1909.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1908, arg_1911) }
//line :367:1
		if jrt.J2g_Truth(tmp7) { var root_1912 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1912, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1914 lang.IFn; if linked_1913 == nil { ifn_1914 = lang.IFn_Cast(root_1912) } else { ifn_1914 = nil }; var arg_1915 any = t.F_b__292000152; var arg_1916 any = lang.Tuple_Create_O_O__IPersistentVector(n__2, cs__4); if linked_1913 == nil { ifn_1914.Invoke_O_O__O(arg_1915, arg_1916) } else { linked_1913.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1912, arg_1915, arg_1916) }; i__292000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000151__1); continue L1 } else { i__292000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000151__1); continue L1 } } else { i__292000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000151__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A) Ctor() {}
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A) Invoke_O_O__O(self, s__292000157__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A_New_O_O(self, s__292000157__1); var tmp2 *jrt.Class; var fncls__1906 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A_fn_class; if fncls__1906 == nil { var fncls__1906d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A_fn_class = fncls__1906d; tmp2 = fncls__1906d } else { tmp2 = fncls__1906 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :372:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A{}; t.Ctor_O_O(p0, p1); return t }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A) Ctor_O_O(c__iter__292000156, c__s__292000157 any) { t.F_iter__292000156 = c__iter__292000156; t.F_s__292000157 = c__s__292000157 }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A) Invoke_O__O(self any) any { { var s__292000157__1 any; var t_ any = t.F_s__292000157; t.F_s__292000157 = nil; s__292000157__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1787 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = s__292000157__1; if linked_1788 == nil { temp__1927000414__auto____2 = ifn_1789.Invoke_O__O(arg_1790) } else { temp__1927000414__auto____2 = linked_1788.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1787, arg_1790) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000157__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1791 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = s__292000157__3; if linked_1792 == nil { tmp1 = ifn_1793.Invoke_O__O(arg_1794) } else { tmp1 = linked_1792.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1791, arg_1794) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1795 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any = s__292000157__3; if linked_1796 == nil { c__1927001037__auto____4 = ifn_1797.Invoke_O__O(arg_1798) } else { c__1927001037__auto____4 = linked_1796.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1795, arg_1798) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000159__6 any; var root_1799 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1800 == nil { b__292000159__6 = ifn_1801.Invoke_O__O(arg_1802) } else { b__292000159__6 = linked_1800.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1799, arg_1802) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A_New_O_I_O(b__292000159__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1835 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class; if fncls__1835 == nil { var fncls__1835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class = fncls__1835d; tmp3 = fncls__1835d } else { tmp3 = fncls__1835 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1836 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any; var root_1841 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = b__292000159__6; if linked_1842 == nil { arg_1839 = ifn_1843.Invoke_O__O(arg_1844) } else { arg_1839 = linked_1842.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1841, arg_1844) }; var arg_1840 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000156); var tmp5 any; var root_1845 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = s__292000157__3; if linked_1846 == nil { tmp5 = ifn_1847.Invoke_O__O(arg_1848) } else { tmp5 = linked_1846.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1845, arg_1848) }; arg_1840 = tmp4.Invoke_O__O(tmp5); if linked_1837 == nil { return ifn_1838.Invoke_O_O__O(arg_1839, arg_1840) } else { return linked_1837.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1836, arg_1839, arg_1840) } } else { var root_1849 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1851 lang.IFn; if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any; var root_1854 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1856 lang.IFn; if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = b__292000159__6; if linked_1855 == nil { arg_1852 = ifn_1856.Invoke_O__O(arg_1857) } else { arg_1852 = linked_1855.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1854, arg_1857) }; var arg_1853 any; if linked_1850 == nil { return ifn_1851.Invoke_O_O__O(arg_1852, arg_1853) } else { return linked_1850.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1849, arg_1852, arg_1853) } } } else { var f__4 any; var root_1858 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1860 lang.IFn; if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any = s__292000157__3; if linked_1859 == nil { f__4 = ifn_1860.Invoke_O__O(arg_1861) } else { f__4 = linked_1859.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1858, arg_1861) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(f__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_308 }
//line :372:1
	var tmp6 any; var and__1927000168__auto____6 bool; var tmp7 int64
	var na_1862 any = fl__5; var na_1863 int64 = 24
	if jrt.Long_InstanceOf(na_1862) { var n0_1864 int64 = jrt.NN(jrt.Long_Cast(na_1862)).LongValue__J(); var n1_1865 int64 = na_1863; tmp7 = n0_1864 & n1_1865 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_1862, na_1863) }; and__1927000168__auto____6 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool; var tmp8 int64; var na_1867 any = fl__5; var na_1868 int64 = 5; if jrt.Long_InstanceOf(na_1867) { var n0_1869 int64 = jrt.NN(jrt.Long_Cast(na_1867)).LongValue__J(); var n1_1870 int64 = na_1868; tmp8 = n0_1869 & n1_1870 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_1867, na_1868) }; and__1927000168__auto____7 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____7 { var or__1927000174__auto____8 any; var root_1872 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1874 lang.IFn
		if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_1873 == nil { or__1927000174__auto____8 = ifn_1874.Invoke_O__O(arg_1875) } else { or__1927000174__auto____8 = linked_1873.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1872, arg_1875) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_324.GetRawRoot__O())).Ref() } } else {
//line :374:1
			tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }
//line :372:1
	if jrt.J2g_Truth(tmp6) { var v__6 any; var tmp9 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A_New_O(f__4); var tmp10 *jrt.Class
		var fncls__1880 /*line :372:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A_fn_class



		if fncls__1880 == nil { var fncls__1880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A_fn_class = fncls__1880d; tmp10 = fncls__1880d } else { tmp10 = fncls__1880 }; v__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :372:1
		var tmp11 any; var root_1881 any = A_arbace_j2g_dyncf_A_const_326.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1883 lang.IFn




		if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = v__6; if linked_1882 == nil { tmp11 = ifn_1883.Invoke_O__O(arg_1884) } else { tmp11 = linked_1882.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1881, arg_1884) }
//line :372:1
		if jrt.J2g_Truth(tmp11) { var root_1885 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any; var tmp12 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp13 any; var tmp14 any; var root_1890 any = A_arbace_j2g_dyncf_A_const_327.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_1892 lang.IFn





			if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = v__6; if linked_1891 == nil { tmp14 = ifn_1892.Invoke_O__O(arg_1893) } else { tmp14 = linked_1891.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_1890, arg_1893) }; if jrt.J2g_Truth(tmp14) { tmp13 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp13 = v__6 }
//line :372:1
			arg_1888 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); var arg_1889 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__292000156); var tmp16 any; var root_1894 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1896 lang.IFn; if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any = s__292000157__3; if linked_1895 == nil { tmp16 = ifn_1896.Invoke_O__O(arg_1897) } else { tmp16 = linked_1895.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1894, arg_1897) }; arg_1889 = tmp15.Invoke_O__O(tmp16); if linked_1886 == nil { return ifn_1887.Invoke_O_O__O(arg_1888, arg_1889) } else { return linked_1886.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1885, arg_1888, arg_1889) } } else { var tmp17 any; var root_1898 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1900 lang.IFn; if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = s__292000157__3; if linked_1899 == nil { tmp17 = ifn_1900.Invoke_O__O(arg_1901) } else { tmp17 = linked_1899.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1898, arg_1901) }; s__292000157__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1902 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1904 lang.IFn; if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = s__292000157__3; if linked_1903 == nil { tmp18 = ifn_1904.Invoke_O__O(arg_1905) } else { tmp18 = linked_1903.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1902, arg_1905) }; s__292000157__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :372:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A) Ctor_O_I_O(c__b__292000159 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000159 = c__b__292000159; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A) Invoke_O__O(self any) any { { var i__292000158__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000158__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000158__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(f__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_308 }
//line :372:1
	var tmp2 any; var and__1927000168__auto____4 bool; var tmp3 int64
	var na_1803 any = fl__3; var na_1804 int64 = 24
	if jrt.Long_InstanceOf(na_1803) { var n0_1805 int64 = jrt.NN(jrt.Long_Cast(na_1803)).LongValue__J(); var n1_1806 int64 = na_1804; tmp3 = n0_1805 & n1_1806 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_1803, na_1804) }; and__1927000168__auto____4 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool; var tmp4 int64; var na_1808 any = fl__3; var na_1809 int64 = 5; if jrt.Long_InstanceOf(na_1808) { var n0_1810 int64 = jrt.NN(jrt.Long_Cast(na_1808)).LongValue__J(); var n1_1811 int64 = na_1809; tmp4 = n0_1810 & n1_1811 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_1808, na_1809) }; and__1927000168__auto____5 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____5 { var or__1927000174__auto____6 any; var root_1813 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1815 lang.IFn
		if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_1814 == nil { or__1927000174__auto____6 = ifn_1815.Invoke_O__O(arg_1816) } else { or__1927000174__auto____6 = linked_1814.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1813, arg_1816) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_324.GetRawRoot__O())).Ref() } } else {
//line :374:1
			tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }
//line :372:1
	if jrt.J2g_Truth(tmp2) { var v__4 any; var tmp5 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A_New_O(f__2); var tmp6 *jrt.Class
		var fncls__1821 /*line :372:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A_fn_class



		if fncls__1821 == nil { var fncls__1821d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A_fn_class = fncls__1821d; tmp6 = fncls__1821d } else { tmp6 = fncls__1821 }; v__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :372:1
		var tmp7 any; var root_1822 any = A_arbace_j2g_dyncf_A_const_326.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1824 lang.IFn




		if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = v__4; if linked_1823 == nil { tmp7 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp7 = linked_1823.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1822, arg_1825) }
//line :372:1
		if jrt.J2g_Truth(tmp7) { var root_1826 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = t.F_b__292000159; var arg_1830 any; var tmp8 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp9 any; var tmp10 any; var root_1831 any = A_arbace_j2g_dyncf_A_const_327.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_1833 lang.IFn





			if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any = v__4; if linked_1832 == nil { tmp10 = ifn_1833.Invoke_O__O(arg_1834) } else { tmp10 = linked_1832.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_1831, arg_1834) }; if jrt.J2g_Truth(tmp10) { tmp9 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp9 = v__4 }
//line :372:1
			arg_1830 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); if linked_1827 == nil { ifn_1828.Invoke_O_O__O(arg_1829, arg_1830) } else { linked_1827.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1826, arg_1829, arg_1830) }; i__292000158__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000158__1); continue L1 } else { i__292000158__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000158__1); continue L1 } } else { i__292000158__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000158__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :372:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A) Ctor() {}
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A) Invoke_O_O__O(self, s__292000172__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A_New_O_O(self, s__292000172__1); var tmp2 *jrt.Class; var fncls__2084 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A_fn_class; if fncls__2084 == nil { var fncls__2084d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A_fn_class = fncls__2084d; tmp2 = fncls__2084d } else { tmp2 = fncls__2084 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :372:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A) Ctor_O_O(c__iter__292000171, c__s__292000172 any) { t.F_iter__292000171 = c__iter__292000171; t.F_s__292000172 = c__s__292000172 }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A) Invoke_O__O(self any) any { { var s__292000172__1 any; var t_ any = t.F_s__292000172; t.F_s__292000172 = nil; s__292000172__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1965 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1965, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1967 lang.IFn; if linked_1966 == nil { ifn_1967 = lang.IFn_Cast(root_1965) } else { ifn_1967 = nil }; var arg_1968 any = s__292000172__1; if linked_1966 == nil { temp__1927000414__auto____2 = ifn_1967.Invoke_O__O(arg_1968) } else { temp__1927000414__auto____2 = linked_1966.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1965, arg_1968) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000172__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1969 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = s__292000172__3; if linked_1970 == nil { tmp1 = ifn_1971.Invoke_O__O(arg_1972) } else { tmp1 = linked_1970.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1969, arg_1972) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1973 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1973, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1975 lang.IFn; if linked_1974 == nil { ifn_1975 = lang.IFn_Cast(root_1973) } else { ifn_1975 = nil }; var arg_1976 any = s__292000172__3; if linked_1974 == nil { c__1927001037__auto____4 = ifn_1975.Invoke_O__O(arg_1976) } else { c__1927001037__auto____4 = linked_1974.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1973, arg_1976) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000174__6 any; var root_1977 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1977, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1979 lang.IFn; if linked_1978 == nil { ifn_1979 = lang.IFn_Cast(root_1977) } else { ifn_1979 = nil }; var arg_1980 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1978 == nil { b__292000174__6 = ifn_1979.Invoke_O__O(arg_1980) } else { b__292000174__6 = linked_1978.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1977, arg_1980) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A_New_O_I_O(b__292000174__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2013 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A_fn_class; if fncls__2013 == nil { var fncls__2013d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A_fn_class = fncls__2013d; tmp3 = fncls__2013d } else { tmp3 = fncls__2013 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2014 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any; var root_2019 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any = b__292000174__6; if linked_2020 == nil { arg_2017 = ifn_2021.Invoke_O__O(arg_2022) } else { arg_2017 = linked_2020.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2019, arg_2022) }; var arg_2018 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000171); var tmp5 any; var root_2023 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2023, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2025 lang.IFn; if linked_2024 == nil { ifn_2025 = lang.IFn_Cast(root_2023) } else { ifn_2025 = nil }; var arg_2026 any = s__292000172__3; if linked_2024 == nil { tmp5 = ifn_2025.Invoke_O__O(arg_2026) } else { tmp5 = linked_2024.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2023, arg_2026) }; arg_2018 = tmp4.Invoke_O__O(tmp5); if linked_2015 == nil { return ifn_2016.Invoke_O_O__O(arg_2017, arg_2018) } else { return linked_2015.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2014, arg_2017, arg_2018) } } else { var root_2027 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any; var root_2032 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = b__292000174__6; if linked_2033 == nil { arg_2030 = ifn_2034.Invoke_O__O(arg_2035) } else { arg_2030 = linked_2033.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2032, arg_2035) }; var arg_2031 any; if linked_2028 == nil { return ifn_2029.Invoke_O_O__O(arg_2030, arg_2031) } else { return linked_2028.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2027, arg_2030, arg_2031) } } } else { var f__4 any; var root_2036 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = s__292000172__3; if linked_2037 == nil { f__4 = ifn_2038.Invoke_O__O(arg_2039) } else { f__4 = linked_2037.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2036, arg_2039) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(f__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_308 }
//line :372:1
	var tmp6 any; var and__1927000168__auto____6 bool; var tmp7 int64
	var na_2040 any = fl__5; var na_2041 int64 = 24
	if jrt.Long_InstanceOf(na_2040) { var n0_2042 int64 = jrt.NN(jrt.Long_Cast(na_2040)).LongValue__J(); var n1_2043 int64 = na_2041; tmp7 = n0_2042 & n1_2043 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_2040, na_2041) }; and__1927000168__auto____6 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool; var tmp8 int64; var na_2045 any = fl__5; var na_2046 int64 = 5; if jrt.Long_InstanceOf(na_2045) { var n0_2047 int64 = jrt.NN(jrt.Long_Cast(na_2045)).LongValue__J(); var n1_2048 int64 = na_2046; tmp8 = n0_2047 & n1_2048 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_2045, na_2046) }; and__1927000168__auto____7 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____7 { var or__1927000174__auto____8 any; var root_2050 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2050, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_2052 lang.IFn
		if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_2051 == nil { or__1927000174__auto____8 = ifn_2052.Invoke_O__O(arg_2053) } else { or__1927000174__auto____8 = linked_2051.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_2050, arg_2053) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_324.GetRawRoot__O())).Ref() } } else {
//line :374:1
			tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }
//line :372:1
	if jrt.J2g_Truth(tmp6) { var v__6 any; var tmp9 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A_New_O(f__4); var tmp10 *jrt.Class
		var fncls__2058 /*line :372:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A_fn_class



		if fncls__2058 == nil { var fncls__2058d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A_fn_class = fncls__2058d; tmp10 = fncls__2058d } else { tmp10 = fncls__2058 }; v__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :372:1
		var tmp11 any; var root_2059 any = A_arbace_j2g_dyncf_A_const_326.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2061 lang.IFn




		if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = v__6; if linked_2060 == nil { tmp11 = ifn_2061.Invoke_O__O(arg_2062) } else { tmp11 = linked_2060.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2059, arg_2062) }
//line :372:1
		if jrt.J2g_Truth(tmp11) { var root_2063 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any; var tmp12 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp13 any; var tmp14 any; var root_2068 any = A_arbace_j2g_dyncf_A_const_327.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_2070 lang.IFn





			if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = v__6; if linked_2069 == nil { tmp14 = ifn_2070.Invoke_O__O(arg_2071) } else { tmp14 = linked_2069.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_2068, arg_2071) }; if jrt.J2g_Truth(tmp14) { tmp13 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp13 = v__6 }
//line :372:1
			arg_2066 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); var arg_2067 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__292000171); var tmp16 any; var root_2072 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2074 lang.IFn; if linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any = s__292000172__3; if linked_2073 == nil { tmp16 = ifn_2074.Invoke_O__O(arg_2075) } else { tmp16 = linked_2073.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2072, arg_2075) }; arg_2067 = tmp15.Invoke_O__O(tmp16); if linked_2064 == nil { return ifn_2065.Invoke_O_O__O(arg_2066, arg_2067) } else { return linked_2064.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2063, arg_2066, arg_2067) } } else { var tmp17 any; var root_2076 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = s__292000172__3; if linked_2077 == nil { tmp17 = ifn_2078.Invoke_O__O(arg_2079) } else { tmp17 = linked_2077.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2076, arg_2079) }; s__292000172__1 = tmp17; continue L1 } } else { var tmp18 any; var root_2080 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2080, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2082 lang.IFn; if linked_2081 == nil { ifn_2082 = lang.IFn_Cast(root_2080) } else { ifn_2082 = nil }; var arg_2083 any = s__292000172__3; if linked_2081 == nil { tmp18 = ifn_2082.Invoke_O__O(arg_2083) } else { tmp18 = linked_2081.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2080, arg_2083) }; s__292000172__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :372:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A) Ctor_O_I_O(c__b__292000174 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000174 = c__b__292000174; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :372:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A) Invoke_O__O(self any) any { { var i__292000173__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000173__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000173__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(f__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_308 }
//line :372:1
	var tmp2 any; var and__1927000168__auto____4 bool; var tmp3 int64
	var na_1981 any = fl__3; var na_1982 int64 = 24
	if jrt.Long_InstanceOf(na_1981) { var n0_1983 int64 = jrt.NN(jrt.Long_Cast(na_1981)).LongValue__J(); var n1_1984 int64 = na_1982; tmp3 = n0_1983 & n1_1984 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_1981, na_1982) }; and__1927000168__auto____4 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool; var tmp4 int64; var na_1986 any = fl__3; var na_1987 int64 = 5; if jrt.Long_InstanceOf(na_1986) { var n0_1988 int64 = jrt.NN(jrt.Long_Cast(na_1986)).LongValue__J(); var n1_1989 int64 = na_1987; tmp4 = n0_1988 & n1_1989 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_1986, na_1987) }; and__1927000168__auto____5 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____5 { var or__1927000174__auto____6 any; var root_1991 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1993 lang.IFn
		if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_1992 == nil { or__1927000174__auto____6 = ifn_1993.Invoke_O__O(arg_1994) } else { or__1927000174__auto____6 = linked_1992.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1991, arg_1994) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_324.GetRawRoot__O())).Ref() } } else {
//line :374:1
			tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }
//line :372:1
	if jrt.J2g_Truth(tmp2) { var v__4 any; var tmp5 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A_New_O(f__2); var tmp6 *jrt.Class
		var fncls__1999 /*line :372:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A_fn_class



		if fncls__1999 == nil { var fncls__1999d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A_fn_class = fncls__1999d; tmp6 = fncls__1999d } else { tmp6 = fncls__1999 }; v__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :372:1
		var tmp7 any; var root_2000 any = A_arbace_j2g_dyncf_A_const_326.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2002 lang.IFn




		if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = v__4; if linked_2001 == nil { tmp7 = ifn_2002.Invoke_O__O(arg_2003) } else { tmp7 = linked_2001.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2000, arg_2003) }
//line :372:1
		if jrt.J2g_Truth(tmp7) { var root_2004 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = t.F_b__292000174; var arg_2008 any; var tmp8 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp9 any; var tmp10 any; var root_2009 any = A_arbace_j2g_dyncf_A_const_327.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_2011 lang.IFn





			if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = v__4; if linked_2010 == nil { tmp10 = ifn_2011.Invoke_O__O(arg_2012) } else { tmp10 = linked_2010.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_2009, arg_2012) }; if jrt.J2g_Truth(tmp10) { tmp9 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp9 = v__4 }
//line :372:1
			arg_2008 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); if linked_2005 == nil { ifn_2006.Invoke_O_O__O(arg_2007, arg_2008) } else { linked_2005.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2004, arg_2007, arg_2008) }; i__292000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000173__1); continue L1 } else { i__292000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000173__1); continue L1 } } else { i__292000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000173__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A{}; t.Ctor_O(p0); return t }
//line :376:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :376:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1817 any = A_arbace_j2g_dyncf_A_const_325.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any; var t_ any = t.F_f; t.F_f = nil; arg_1820 = t_; if linked_1818 == nil { tmp1 = ifn_1819.Invoke_O__O(arg_1820) } else { tmp1 = linked_1818.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_1817, arg_1820) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :376:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A{}; t.Ctor_O(p0); return t }
//line :376:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :376:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1876 any = A_arbace_j2g_dyncf_A_const_325.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any; var t_ any = t.F_f; t.F_f = nil; arg_1879 = t_; if linked_1877 == nil { tmp1 = ifn_1878.Invoke_O__O(arg_1879) } else { tmp1 = linked_1877.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_1876, arg_1879) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :376:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A{}; t.Ctor_O(p0); return t }
//line :376:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :376:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1995 any = A_arbace_j2g_dyncf_A_const_325.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_1997 lang.IFn; if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any; var t_ any = t.F_f; t.F_f = nil; arg_1998 = t_; if linked_1996 == nil { tmp1 = ifn_1997.Invoke_O__O(arg_1998) } else { tmp1 = linked_1996.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_1995, arg_1998) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :376:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A{}; t.Ctor_O(p0); return t }
//line :376:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :376:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2054 any = A_arbace_j2g_dyncf_A_const_325.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any; var t_ any = t.F_f; t.F_f = nil; arg_2057 = t_; if linked_2055 == nil { tmp1 = ifn_2056.Invoke_O__O(arg_2057) } else { tmp1 = linked_2055.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_2054, arg_2057) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A{}; t.Ctor_O(p0); return t }
//line :384:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A) Ctor_O(c__tset any) { t.F_tset = c__tset }
//line :384:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A) Invoke_O_O__O(self, s__292000188__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A_New_O_O_O(t.F_tset, self, s__292000188__1); var tmp2 *jrt.Class; var fncls__2434 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A_fn_class; if fncls__2434 == nil { var fncls__2434d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A_fn_class = fncls__2434d; tmp2 = fncls__2434d } else { tmp2 = fncls__2434 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :384:1
func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :384:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A) Ctor_O_O_O(c__tset, c__iter__292000187, c__s__292000188 any) { t.F_tset = c__tset; t.F_iter__292000187 = c__iter__292000187; t.F_s__292000188 = c__s__292000188 }
//line :384:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A) Invoke_O__O(self any) any { { var s__292000188__1 any; var t_ any = t.F_s__292000188; t.F_s__292000188 = nil; s__292000188__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2113 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any = s__292000188__1; if linked_2114 == nil { temp__1927000414__auto____2 = ifn_2115.Invoke_O__O(arg_2116) } else { temp__1927000414__auto____2 = linked_2114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2113, arg_2116) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000188__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2117 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any = s__292000188__3; if linked_2118 == nil { tmp1 = ifn_2119.Invoke_O__O(arg_2120) } else { tmp1 = linked_2118.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2117, arg_2120) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2121 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any = s__292000188__3; if linked_2122 == nil { c__1927001037__auto____4 = ifn_2123.Invoke_O__O(arg_2124) } else { c__1927001037__auto____4 = linked_2122.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2121, arg_2124) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000190__6 any; var root_2125 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2126 == nil { b__292000190__6 = ifn_2127.Invoke_O__O(arg_2128) } else { b__292000190__6 = linked_2126.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2125, arg_2128) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A_New_O_O_I_O(t.F_tset, b__292000190__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2262 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A_fn_class; if fncls__2262 == nil { var fncls__2262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A_fn_class = fncls__2262d; tmp3 = fncls__2262d } else { tmp3 = fncls__2262 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2263 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2263, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2265 lang.IFn; if linked_2264 == nil { ifn_2265 = lang.IFn_Cast(root_2263) } else { ifn_2265 = nil }; var arg_2266 any; var root_2268 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2268, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2270 lang.IFn; if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any = b__292000190__6; if linked_2269 == nil { arg_2266 = ifn_2270.Invoke_O__O(arg_2271) } else { arg_2266 = linked_2269.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2268, arg_2271) }; var arg_2267 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000187); var tmp5 any; var root_2272 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any = s__292000188__3; if linked_2273 == nil { tmp5 = ifn_2274.Invoke_O__O(arg_2275) } else { tmp5 = linked_2273.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2272, arg_2275) }; arg_2267 = tmp4.Invoke_O__O(tmp5); if linked_2264 == nil { return ifn_2265.Invoke_O_O__O(arg_2266, arg_2267) } else { return linked_2264.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2263, arg_2266, arg_2267) } } else { var root_2276 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2276, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2278 lang.IFn; if linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any; var root_2281 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = b__292000190__6; if linked_2282 == nil { arg_2279 = ifn_2283.Invoke_O__O(arg_2284) } else { arg_2279 = linked_2282.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2281, arg_2284) }; var arg_2280 any; if linked_2277 == nil { return ifn_2278.Invoke_O_O__O(arg_2279, arg_2280) } else { return linked_2277.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2276, arg_2279, arg_2280) } } } else { var vec__292000208__4 any; var root_2285 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = s__292000188__3; if linked_2286 == nil { vec__292000208__4 = ifn_2287.Invoke_O__O(arg_2288) } else { vec__292000208__4 = linked_2286.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2285, arg_2288) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000208__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000208__4, lang.RT_IntCast_J__I_NoInit(1), nil); var i__7 any = A_arbace_j2g_dyncf_A_const_330.Invoke_O__O(facets__6); var tmp6 any
														var and__1927000168__auto____8 any = i__7
														if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_2289 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = lang.IFn_Cast(t.F_tset).Invoke_O__O(n__5); if linked_2290 == nil { and__1927000168__auto____9 = ifn_2291.Invoke_O__O(arg_2292) } else { and__1927000168__auto____9 = linked_2290.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2289, arg_2292) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp7 int64; var na_2293 any; var or__1927000174__auto____10 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(i__7); if jrt.J2g_Truth(or__1927000174__auto____10) { na_2293 = or__1927000174__auto____10 } else { na_2293 = A_arbace_j2g_dyncf_A_const_308 }; var na_2294 int64 = 1; if jrt.Long_InstanceOf(na_2293) { var n0_2295 int64 = jrt.NN(jrt.Long_Cast(na_2293)).LongValue__J(); var n1_2296 int64 = na_2294; tmp7 = n0_2295 & n1_2296 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_2293, na_2294) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp7)).Ref() } else { tmp6 = and__1927000168__auto____9 } } else { tmp6 = and__1927000168__auto____8 }
//line :384:1
	if jrt.J2g_Truth(tmp6) { var cs__8 any; var root_2298 any = A_arbace_j2g_dyncf_A_const_322.GetRawRoot__O(); var linked_2299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2298, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2300 lang.IFn


		if linked_2299 == nil { ifn_2300 = lang.IFn_Cast(root_2298) } else { ifn_2300 = nil }; var arg_2301 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_323.GetRawRoot__O()).Invoke__O(); var arg_2302 any; var iter__1927001039__auto____8 any; var tmp8 any = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A_New(); var tmp9 *jrt.Class; var fncls__2412 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A_fn_class
		if fncls__2412 == nil { var fncls__2412d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A_fn_class = fncls__2412d; tmp9 = fncls__2412d } else { tmp9 = fncls__2412 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_2302 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(A_arbace_j2g_dyncf_A_const_328.Invoke_O__O(i__7))
//line :387:1
		if linked_2299 == nil { cs__8 = ifn_2300.Invoke_O_O__O(arg_2301, arg_2302) } else { cs__8 = linked_2299.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2298, arg_2301, arg_2302) }
//line :384:1
		var tmp10 any; var root_2413 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2413, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2415 lang.IFn









		if linked_2414 == nil { ifn_2415 = lang.IFn_Cast(root_2413) } else { ifn_2415 = nil }; var arg_2416 any = cs__8; if linked_2414 == nil { tmp10 = ifn_2415.Invoke_O__O(arg_2416) } else { tmp10 = linked_2414.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2413, arg_2416) }
//line :384:1
		if jrt.J2g_Truth(tmp10) { var root_2417 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2417, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2419 lang.IFn; if linked_2418 == nil { ifn_2419 = lang.IFn_Cast(root_2417) } else { ifn_2419 = nil }; var arg_2420 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, cs__8); var arg_2421 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__292000187); var tmp12 any; var root_2422 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2422, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2424 lang.IFn; if linked_2423 == nil { ifn_2424 = lang.IFn_Cast(root_2422) } else { ifn_2424 = nil }; var arg_2425 any = s__292000188__3; if linked_2423 == nil { tmp12 = ifn_2424.Invoke_O__O(arg_2425) } else { tmp12 = linked_2423.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2422, arg_2425) }; arg_2421 = tmp11.Invoke_O__O(tmp12); if linked_2418 == nil { return ifn_2419.Invoke_O_O__O(arg_2420, arg_2421) } else { return linked_2418.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2417, arg_2420, arg_2421) } } else { var tmp13 any; var root_2426 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2426, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2428 lang.IFn; if linked_2427 == nil { ifn_2428 = lang.IFn_Cast(root_2426) } else { ifn_2428 = nil }; var arg_2429 any = s__292000188__3; if linked_2427 == nil { tmp13 = ifn_2428.Invoke_O__O(arg_2429) } else { tmp13 = linked_2427.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2426, arg_2429) }; s__292000188__1 = tmp13; continue L1 } } else { var tmp14 any; var root_2430 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2430, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2432 lang.IFn; if linked_2431 == nil { ifn_2432 = lang.IFn_Cast(root_2430) } else { ifn_2432 = nil }; var arg_2433 any = s__292000188__3; if linked_2431 == nil { tmp14 = ifn_2432.Invoke_O__O(arg_2433) } else { tmp14 = linked_2431.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2430, arg_2433) }; s__292000188__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :384:1
func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :384:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A) Ctor_O_O_I_O(c__tset, c__b__292000190 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tset = c__tset; t.F_b__292000190 = c__b__292000190; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :384:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A) Invoke_O__O(self any) any { { var i__292000189__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000189__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000194__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000189__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000194__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000194__2, lang.RT_IntCast_J__I_NoInit(1), nil); var i__5 any = A_arbace_j2g_dyncf_A_const_330.Invoke_O__O(facets__4); var tmp2 any
																var and__1927000168__auto____6 any = i__5
																if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2129 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = lang.IFn_Cast(t.F_tset).Invoke_O__O(n__3); if linked_2130 == nil { and__1927000168__auto____7 = ifn_2131.Invoke_O__O(arg_2132) } else { and__1927000168__auto____7 = linked_2130.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2129, arg_2132) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp3 int64; var na_2133 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(i__5); if jrt.J2g_Truth(or__1927000174__auto____8) { na_2133 = or__1927000174__auto____8 } else { na_2133 = A_arbace_j2g_dyncf_A_const_308 }; var na_2134 int64 = 1; if jrt.Long_InstanceOf(na_2133) { var n0_2135 int64 = jrt.NN(jrt.Long_Cast(na_2133)).LongValue__J(); var n1_2136 int64 = na_2134; tmp3 = n0_2135 & n1_2136 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_2133, na_2134) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp3)).Ref() } else { tmp2 = and__1927000168__auto____7 } } else { tmp2 = and__1927000168__auto____6 }
//line :384:1
	if jrt.J2g_Truth(tmp2) { var cs__6 any; var root_2138 any = A_arbace_j2g_dyncf_A_const_322.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2140 lang.IFn


		if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_323.GetRawRoot__O()).Invoke__O(); var arg_2142 any; var iter__1927001039__auto____6 any; var tmp4 any = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A_New(); var tmp5 *jrt.Class; var fncls__2252 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A_fn_class
		if fncls__2252 == nil { var fncls__2252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A_fn_class = fncls__2252d; tmp5 = fncls__2252d } else { tmp5 = fncls__2252 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_2142 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(A_arbace_j2g_dyncf_A_const_328.Invoke_O__O(i__5))
//line :387:1
		if linked_2139 == nil { cs__6 = ifn_2140.Invoke_O_O__O(arg_2141, arg_2142) } else { cs__6 = linked_2139.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2138, arg_2141, arg_2142) }
//line :384:1
		var tmp6 any; var root_2253 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2255 lang.IFn









		if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = cs__6; if linked_2254 == nil { tmp6 = ifn_2255.Invoke_O__O(arg_2256) } else { tmp6 = linked_2254.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2253, arg_2256) }
//line :384:1
		if jrt.J2g_Truth(tmp6) { var root_2257 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = t.F_b__292000190; var arg_2261 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, cs__6); if linked_2258 == nil { ifn_2259.Invoke_O_O__O(arg_2260, arg_2261) } else { linked_2258.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2257, arg_2260, arg_2261) }; i__292000189__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000189__1); continue L1 } else { i__292000189__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000189__1); continue L1 } } else { i__292000189__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000189__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A) Ctor() {}
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A) Invoke_O_O__O(self, s__292000198__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A_New_O_O(self, s__292000198__1); var tmp2 *jrt.Class; var fncls__2251 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A_fn_class; if fncls__2251 == nil { var fncls__2251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A_fn_class = fncls__2251d; tmp2 = fncls__2251d } else { tmp2 = fncls__2251 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :388:1
func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A{}; t.Ctor_O_O(p0, p1); return t }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A) Ctor_O_O(c__iter__292000197, c__s__292000198 any) { t.F_iter__292000197 = c__iter__292000197; t.F_s__292000198 = c__s__292000198 }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A) Invoke_O__O(self any) any { { var s__292000198__1 any; var t_ any = t.F_s__292000198; t.F_s__292000198 = nil; s__292000198__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2146 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2148 lang.IFn; if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any = s__292000198__1; if linked_2147 == nil { temp__1927000414__auto____2 = ifn_2148.Invoke_O__O(arg_2149) } else { temp__1927000414__auto____2 = linked_2147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2146, arg_2149) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000198__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2150 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2152 lang.IFn; if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any = s__292000198__3; if linked_2151 == nil { tmp1 = ifn_2152.Invoke_O__O(arg_2153) } else { tmp1 = linked_2151.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2150, arg_2153) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2154 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2154, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2156 lang.IFn; if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any = s__292000198__3; if linked_2155 == nil { c__1927001037__auto____4 = ifn_2156.Invoke_O__O(arg_2157) } else { c__1927001037__auto____4 = linked_2155.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2154, arg_2157) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000200__6 any; var root_2158 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2158, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2160 lang.IFn; if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2159 == nil { b__292000200__6 = ifn_2160.Invoke_O__O(arg_2161) } else { b__292000200__6 = linked_2159.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2158, arg_2161) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A_New_O_I_O(b__292000200__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2189 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A_fn_class; if fncls__2189 == nil { var fncls__2189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A_fn_class = fncls__2189d; tmp3 = fncls__2189d } else { tmp3 = fncls__2189 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2190 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any; var root_2195 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = b__292000200__6; if linked_2196 == nil { arg_2193 = ifn_2197.Invoke_O__O(arg_2198) } else { arg_2193 = linked_2196.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2195, arg_2198) }; var arg_2194 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000197); var tmp5 any; var root_2199 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = s__292000198__3; if linked_2200 == nil { tmp5 = ifn_2201.Invoke_O__O(arg_2202) } else { tmp5 = linked_2200.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2199, arg_2202) }; arg_2194 = tmp4.Invoke_O__O(tmp5); if linked_2191 == nil { return ifn_2192.Invoke_O_O__O(arg_2193, arg_2194) } else { return linked_2191.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2190, arg_2193, arg_2194) } } else { var root_2203 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any; var root_2208 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = b__292000200__6; if linked_2209 == nil { arg_2206 = ifn_2210.Invoke_O__O(arg_2211) } else { arg_2206 = linked_2209.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2208, arg_2211) }; var arg_2207 any; if linked_2204 == nil { return ifn_2205.Invoke_O_O__O(arg_2206, arg_2207) } else { return linked_2204.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2203, arg_2206, arg_2207) } } } else { var f__4 any; var root_2212 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = s__292000198__3; if linked_2213 == nil { f__4 = ifn_2214.Invoke_O__O(arg_2215) } else { f__4 = linked_2213.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2212, arg_2215) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(f__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_308 }
//line :388:1
	var v__6 any = A_arbace_j2g_dyncf_A_const_331.Invoke_O__O(f__4); var tmp6 any; var and__1927000168__auto____7 bool; var tmp7 int64
	var na_2216 any = fl__5; var na_2217 int64 = 24
	if jrt.Long_InstanceOf(na_2216) { var n0_2218 int64 = jrt.NN(jrt.Long_Cast(na_2216)).LongValue__J(); var n1_2219 int64 = na_2217; tmp7 = n0_2218 & n1_2219 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_2216, na_2217) }; and__1927000168__auto____7 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp8 int64; var na_2221 any = fl__5; var na_2222 int64 = 5; if jrt.Long_InstanceOf(na_2221) { var n0_2223 int64 = jrt.NN(jrt.Long_Cast(na_2221)).LongValue__J(); var n1_2224 int64 = na_2222; tmp8 = n0_2223 & n1_2224 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_2221, na_2222) }; and__1927000168__auto____8 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var or__1927000174__auto____9 any; var root_2226 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_2228 lang.IFn
		if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_2227 == nil { or__1927000174__auto____9 = ifn_2228.Invoke_O__O(arg_2229) } else { or__1927000174__auto____9 = linked_2227.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_2226, arg_2229) }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____9 = or__1927000174__auto____9 } else { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_324.GetRawRoot__O())).Ref() }
//line :390:1
		if jrt.J2g_Truth(and__1927000168__auto____9) {

			var root_2230 any = A_arbace_j2g_dyncf_A_const_326.GetRawRoot__O(); var linked_2231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2230, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2232 lang.IFn; if linked_2231 == nil { ifn_2232 = lang.IFn_Cast(root_2230) } else { ifn_2232 = nil }; var arg_2233 any = v__6; if linked_2231 == nil { tmp6 = ifn_2232.Invoke_O__O(arg_2233) } else { tmp6 = linked_2231.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2230, arg_2233) } } else {
//line :390:1
				tmp6 = and__1927000168__auto____9 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :388:1
	if jrt.J2g_Truth(tmp6) { var root_2234 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any; var tmp9 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp10 any; var tmp11 any; var root_2239 any = A_arbace_j2g_dyncf_A_const_327.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_2241 lang.IFn




		if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = v__6; if linked_2240 == nil { tmp11 = ifn_2241.Invoke_O__O(arg_2242) } else { tmp11 = linked_2240.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_2239, arg_2242) }; if jrt.J2g_Truth(tmp11) { tmp10 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp10 = v__6 }
//line :388:1
		arg_2237 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10); var arg_2238 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__292000197); var tmp13 any; var root_2243 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = s__292000198__3; if linked_2244 == nil { tmp13 = ifn_2245.Invoke_O__O(arg_2246) } else { tmp13 = linked_2244.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2243, arg_2246) }; arg_2238 = tmp12.Invoke_O__O(tmp13); if linked_2235 == nil { return ifn_2236.Invoke_O_O__O(arg_2237, arg_2238) } else { return linked_2235.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2234, arg_2237, arg_2238) } } else { var tmp14 any; var root_2247 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any = s__292000198__3; if linked_2248 == nil { tmp14 = ifn_2249.Invoke_O__O(arg_2250) } else { tmp14 = linked_2248.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2247, arg_2250) }; s__292000198__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :388:1
func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A) Ctor_O_I_O(c__b__292000200 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000200 = c__b__292000200; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A) Invoke_O__O(self any) any { { var i__292000199__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000199__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000199__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(f__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_308 }
//line :388:1
	var v__4 any = A_arbace_j2g_dyncf_A_const_331.Invoke_O__O(f__2); var tmp2 any; var and__1927000168__auto____5 bool; var tmp3 int64
	var na_2162 any = fl__3; var na_2163 int64 = 24
	if jrt.Long_InstanceOf(na_2162) { var n0_2164 int64 = jrt.NN(jrt.Long_Cast(na_2162)).LongValue__J(); var n1_2165 int64 = na_2163; tmp3 = n0_2164 & n1_2165 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_2162, na_2163) }; and__1927000168__auto____5 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool; var tmp4 int64; var na_2167 any = fl__3; var na_2168 int64 = 5; if jrt.Long_InstanceOf(na_2167) { var n0_2169 int64 = jrt.NN(jrt.Long_Cast(na_2167)).LongValue__J(); var n1_2170 int64 = na_2168; tmp4 = n0_2169 & n1_2170 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_2167, na_2168) }; and__1927000168__auto____6 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____6 { var and__1927000168__auto____7 any; var or__1927000174__auto____7 any; var root_2172 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_2174 lang.IFn
		if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_2173 == nil { or__1927000174__auto____7 = ifn_2174.Invoke_O__O(arg_2175) } else { or__1927000174__auto____7 = linked_2173.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_2172, arg_2175) }; if jrt.J2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7 = or__1927000174__auto____7 } else { and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_324.GetRawRoot__O())).Ref() }
//line :390:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {

			var root_2176 any = A_arbace_j2g_dyncf_A_const_326.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2176, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2178 lang.IFn; if linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any = v__4; if linked_2177 == nil { tmp2 = ifn_2178.Invoke_O__O(arg_2179) } else { tmp2 = linked_2177.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2176, arg_2179) } } else {
//line :390:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :388:1
	if jrt.J2g_Truth(tmp2) { var root_2180 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2180, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2182 lang.IFn; if linked_2181 == nil { ifn_2182 = lang.IFn_Cast(root_2180) } else { ifn_2182 = nil }; var arg_2183 any = t.F_b__292000200; var arg_2184 any; var tmp5 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp6 any; var tmp7 any; var root_2185 any = A_arbace_j2g_dyncf_A_const_327.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_2187 lang.IFn




		if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any = v__4; if linked_2186 == nil { tmp7 = ifn_2187.Invoke_O__O(arg_2188) } else { tmp7 = linked_2186.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_2185, arg_2188) }; if jrt.J2g_Truth(tmp7) { tmp6 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp6 = v__4 }
//line :388:1
		arg_2184 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6); if linked_2181 == nil { ifn_2182.Invoke_O_O__O(arg_2183, arg_2184) } else { linked_2181.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2180, arg_2183, arg_2184) }; i__292000199__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000199__1); continue L1 } else { i__292000199__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000199__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :388:1
func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A) Ctor() {}
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A) Invoke_O_O__O(self, s__292000212__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A_New_O_O(self, s__292000212__1); var tmp2 *jrt.Class; var fncls__2411 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A_fn_class; if fncls__2411 == nil { var fncls__2411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A_fn_class = fncls__2411d; tmp2 = fncls__2411d } else { tmp2 = fncls__2411 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :388:1
func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A{}; t.Ctor_O_O(p0, p1); return t }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A) Ctor_O_O(c__iter__292000211, c__s__292000212 any) { t.F_iter__292000211 = c__iter__292000211; t.F_s__292000212 = c__s__292000212 }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A) Invoke_O__O(self any) any { { var s__292000212__1 any; var t_ any = t.F_s__292000212; t.F_s__292000212 = nil; s__292000212__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2306 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = s__292000212__1; if linked_2307 == nil { temp__1927000414__auto____2 = ifn_2308.Invoke_O__O(arg_2309) } else { temp__1927000414__auto____2 = linked_2307.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2306, arg_2309) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000212__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2310 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2310, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2312 lang.IFn; if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any = s__292000212__3; if linked_2311 == nil { tmp1 = ifn_2312.Invoke_O__O(arg_2313) } else { tmp1 = linked_2311.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2310, arg_2313) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2314 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2316 lang.IFn; if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = s__292000212__3; if linked_2315 == nil { c__1927001037__auto____4 = ifn_2316.Invoke_O__O(arg_2317) } else { c__1927001037__auto____4 = linked_2315.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2314, arg_2317) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000214__6 any; var root_2318 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2319 == nil { b__292000214__6 = ifn_2320.Invoke_O__O(arg_2321) } else { b__292000214__6 = linked_2319.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2318, arg_2321) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A_New_O_I_O(b__292000214__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2349 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A_fn_class; if fncls__2349 == nil { var fncls__2349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A_fn_class = fncls__2349d; tmp3 = fncls__2349d } else { tmp3 = fncls__2349 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2350 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2350, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2352 lang.IFn; if linked_2351 == nil { ifn_2352 = lang.IFn_Cast(root_2350) } else { ifn_2352 = nil }; var arg_2353 any; var root_2355 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2355, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2357 lang.IFn; if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any = b__292000214__6; if linked_2356 == nil { arg_2353 = ifn_2357.Invoke_O__O(arg_2358) } else { arg_2353 = linked_2356.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2355, arg_2358) }; var arg_2354 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000211); var tmp5 any; var root_2359 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any = s__292000212__3; if linked_2360 == nil { tmp5 = ifn_2361.Invoke_O__O(arg_2362) } else { tmp5 = linked_2360.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2359, arg_2362) }; arg_2354 = tmp4.Invoke_O__O(tmp5); if linked_2351 == nil { return ifn_2352.Invoke_O_O__O(arg_2353, arg_2354) } else { return linked_2351.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2350, arg_2353, arg_2354) } } else { var root_2363 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any; var root_2368 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = b__292000214__6; if linked_2369 == nil { arg_2366 = ifn_2370.Invoke_O__O(arg_2371) } else { arg_2366 = linked_2369.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2368, arg_2371) }; var arg_2367 any; if linked_2364 == nil { return ifn_2365.Invoke_O_O__O(arg_2366, arg_2367) } else { return linked_2364.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2363, arg_2366, arg_2367) } } } else { var f__4 any; var root_2372 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = s__292000212__3; if linked_2373 == nil { f__4 = ifn_2374.Invoke_O__O(arg_2375) } else { f__4 = linked_2373.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2372, arg_2375) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(f__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_308 }
//line :388:1
	var v__6 any = A_arbace_j2g_dyncf_A_const_331.Invoke_O__O(f__4); var tmp6 any; var and__1927000168__auto____7 bool; var tmp7 int64
	var na_2376 any = fl__5; var na_2377 int64 = 24
	if jrt.Long_InstanceOf(na_2376) { var n0_2378 int64 = jrt.NN(jrt.Long_Cast(na_2376)).LongValue__J(); var n1_2379 int64 = na_2377; tmp7 = n0_2378 & n1_2379 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_2376, na_2377) }; and__1927000168__auto____7 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp8 int64; var na_2381 any = fl__5; var na_2382 int64 = 5; if jrt.Long_InstanceOf(na_2381) { var n0_2383 int64 = jrt.NN(jrt.Long_Cast(na_2381)).LongValue__J(); var n1_2384 int64 = na_2382; tmp8 = n0_2383 & n1_2384 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_2381, na_2382) }; and__1927000168__auto____8 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var or__1927000174__auto____9 any; var root_2386 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_2387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2386, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_2388 lang.IFn
		if linked_2387 == nil { ifn_2388 = lang.IFn_Cast(root_2386) } else { ifn_2388 = nil }; var arg_2389 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_2387 == nil { or__1927000174__auto____9 = ifn_2388.Invoke_O__O(arg_2389) } else { or__1927000174__auto____9 = linked_2387.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_2386, arg_2389) }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____9 = or__1927000174__auto____9 } else { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_324.GetRawRoot__O())).Ref() }
//line :390:1
		if jrt.J2g_Truth(and__1927000168__auto____9) {

			var root_2390 any = A_arbace_j2g_dyncf_A_const_326.GetRawRoot__O(); var linked_2391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2390, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2392 lang.IFn; if linked_2391 == nil { ifn_2392 = lang.IFn_Cast(root_2390) } else { ifn_2392 = nil }; var arg_2393 any = v__6; if linked_2391 == nil { tmp6 = ifn_2392.Invoke_O__O(arg_2393) } else { tmp6 = linked_2391.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2390, arg_2393) } } else {
//line :390:1
				tmp6 = and__1927000168__auto____9 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :388:1
	if jrt.J2g_Truth(tmp6) { var root_2394 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2396 lang.IFn; if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any; var tmp9 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp10 any; var tmp11 any; var root_2399 any = A_arbace_j2g_dyncf_A_const_327.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_2401 lang.IFn




		if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = v__6; if linked_2400 == nil { tmp11 = ifn_2401.Invoke_O__O(arg_2402) } else { tmp11 = linked_2400.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_2399, arg_2402) }; if jrt.J2g_Truth(tmp11) { tmp10 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp10 = v__6 }
//line :388:1
		arg_2397 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10); var arg_2398 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__292000211); var tmp13 any; var root_2403 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = s__292000212__3; if linked_2404 == nil { tmp13 = ifn_2405.Invoke_O__O(arg_2406) } else { tmp13 = linked_2404.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2403, arg_2406) }; arg_2398 = tmp12.Invoke_O__O(tmp13); if linked_2395 == nil { return ifn_2396.Invoke_O_O__O(arg_2397, arg_2398) } else { return linked_2395.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2394, arg_2397, arg_2398) } } else { var tmp14 any; var root_2407 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = s__292000212__3; if linked_2408 == nil { tmp14 = ifn_2409.Invoke_O__O(arg_2410) } else { tmp14 = linked_2408.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2407, arg_2410) }; s__292000212__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :388:1
func A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A) Ctor_O_I_O(c__b__292000214 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000214 = c__b__292000214; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :388:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A) Invoke_O__O(self any) any { { var i__292000213__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000213__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000213__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_307.Invoke_O__O(f__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_308 }
//line :388:1
	var v__4 any = A_arbace_j2g_dyncf_A_const_331.Invoke_O__O(f__2); var tmp2 any; var and__1927000168__auto____5 bool; var tmp3 int64
	var na_2322 any = fl__3; var na_2323 int64 = 24
	if jrt.Long_InstanceOf(na_2322) { var n0_2324 int64 = jrt.NN(jrt.Long_Cast(na_2322)).LongValue__J(); var n1_2325 int64 = na_2323; tmp3 = n0_2324 & n1_2325 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_2322, na_2323) }; and__1927000168__auto____5 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool; var tmp4 int64; var na_2327 any = fl__3; var na_2328 int64 = 5; if jrt.Long_InstanceOf(na_2327) { var n0_2329 int64 = jrt.NN(jrt.Long_Cast(na_2327)).LongValue__J(); var n1_2330 int64 = na_2328; tmp4 = n0_2329 & n1_2330 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_2327, na_2328) }; and__1927000168__auto____6 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____6 { var and__1927000168__auto____7 any; var or__1927000174__auto____7 any; var root_2332 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_2334 lang.IFn
		if linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_2333 == nil { or__1927000174__auto____7 = ifn_2334.Invoke_O__O(arg_2335) } else { or__1927000174__auto____7 = linked_2333.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_2332, arg_2335) }; if jrt.J2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7 = or__1927000174__auto____7 } else { and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_324.GetRawRoot__O())).Ref() }
//line :390:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {

			var root_2336 any = A_arbace_j2g_dyncf_A_const_326.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2338 lang.IFn; if linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2339 any = v__4; if linked_2337 == nil { tmp2 = ifn_2338.Invoke_O__O(arg_2339) } else { tmp2 = linked_2337.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2336, arg_2339) } } else {
//line :390:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :388:1
	if jrt.J2g_Truth(tmp2) { var root_2340 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2340, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2342 lang.IFn; if linked_2341 == nil { ifn_2342 = lang.IFn_Cast(root_2340) } else { ifn_2342 = nil }; var arg_2343 any = t.F_b__292000214; var arg_2344 any; var tmp5 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp6 any; var tmp7 any; var root_2345 any = A_arbace_j2g_dyncf_A_const_327.GetRawRoot__O(); var linked_2346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2345, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_2347 lang.IFn




		if linked_2346 == nil { ifn_2347 = lang.IFn_Cast(root_2345) } else { ifn_2347 = nil }; var arg_2348 any = v__4; if linked_2346 == nil { tmp7 = ifn_2347.Invoke_O__O(arg_2348) } else { tmp7 = linked_2346.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_2345, arg_2348) }; if jrt.J2g_Truth(tmp7) { tmp6 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp6 = v__4 }
//line :388:1
		arg_2344 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6); if linked_2341 == nil { ifn_2342.Invoke_O_O__O(arg_2343, arg_2344) } else { linked_2341.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2340, arg_2343, arg_2344) }; i__292000213__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000213__1); continue L1 } else { i__292000213__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000213__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A{}; t.Ctor(); return t }
//line :401:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A) Ctor() {}
//line :401:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A) Invoke_O_O__O(self, s__292000224__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A_New_O_O(self, s__292000224__1); var tmp2 *jrt.Class; var fncls__2524 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A_fn_class; if fncls__2524 == nil { var fncls__2524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A_fn_class = fncls__2524d; tmp2 = fncls__2524d } else { tmp2 = fncls__2524 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :401:1
func A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :401:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A) Ctor_O_O(c__iter__292000223, c__s__292000224 any) { t.F_iter__292000223 = c__iter__292000223; t.F_s__292000224 = c__s__292000224 }
//line :401:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A) Invoke_O__O(self any) any { { var s__292000224__1 any; var t_ any = t.F_s__292000224; t.F_s__292000224 = nil; s__292000224__1 = t_; for { var temp__1927000414__auto____2 any; var root_2451 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = s__292000224__1; if linked_2452 == nil { temp__1927000414__auto____2 = ifn_2453.Invoke_O__O(arg_2454) } else { temp__1927000414__auto____2 = linked_2452.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2451, arg_2454) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000224__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2455 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2455, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2457 lang.IFn; if linked_2456 == nil { ifn_2457 = lang.IFn_Cast(root_2455) } else { ifn_2457 = nil }; var arg_2458 any = s__292000224__3; if linked_2456 == nil { tmp1 = ifn_2457.Invoke_O__O(arg_2458) } else { tmp1 = linked_2456.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2455, arg_2458) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2459 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2461 lang.IFn; if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any = s__292000224__3; if linked_2460 == nil { c__1927001037__auto____4 = ifn_2461.Invoke_O__O(arg_2462) } else { c__1927001037__auto____4 = linked_2460.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2459, arg_2462) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000226__6 any; var root_2463 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2464 == nil { b__292000226__6 = ifn_2465.Invoke_O__O(arg_2466) } else { b__292000226__6 = linked_2464.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2463, arg_2466) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A_New_O_I_O(b__292000226__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2480 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A_fn_class; if fncls__2480 == nil { var fncls__2480d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A_fn_class = fncls__2480d; tmp3 = fncls__2480d } else { tmp3 = fncls__2480 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2481 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any; var root_2486 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2486, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2488 lang.IFn; if linked_2487 == nil { ifn_2488 = lang.IFn_Cast(root_2486) } else { ifn_2488 = nil }; var arg_2489 any = b__292000226__6; if linked_2487 == nil { arg_2484 = ifn_2488.Invoke_O__O(arg_2489) } else { arg_2484 = linked_2487.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2486, arg_2489) }; var arg_2485 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000223); var tmp5 any; var root_2490 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any = s__292000224__3; if linked_2491 == nil { tmp5 = ifn_2492.Invoke_O__O(arg_2493) } else { tmp5 = linked_2491.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2490, arg_2493) }; arg_2485 = tmp4.Invoke_O__O(tmp5); if linked_2482 == nil { return ifn_2483.Invoke_O_O__O(arg_2484, arg_2485) } else { return linked_2482.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2481, arg_2484, arg_2485) } } else { var root_2494 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2496 lang.IFn; if linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any; var root_2499 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2499, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2501 lang.IFn; if linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any = b__292000226__6; if linked_2500 == nil { arg_2497 = ifn_2501.Invoke_O__O(arg_2502) } else { arg_2497 = linked_2500.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2499, arg_2502) }; var arg_2498 any; if linked_2495 == nil { return ifn_2496.Invoke_O_O__O(arg_2497, arg_2498) } else { return linked_2495.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2494, arg_2497, arg_2498) } } } else { var vec__292000234__4 any; var root_2503 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2505 lang.IFn; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any = s__292000224__3; if linked_2504 == nil { vec__292000234__4 = ifn_2505.Invoke_O__O(arg_2506) } else { vec__292000234__4 = linked_2504.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2503, arg_2506) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000234__4, lang.RT_IntCast_J__I_NoInit(0), nil); var g__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000234__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2507 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2509 lang.IFn; if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_76, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_333.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_333.GetRawRoot__O()).Invoke_O__O(g__6))).Ref(); var arg_2511 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000223); var tmp7 any; var root_2520 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2520, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2522 lang.IFn; if linked_2521 == nil { ifn_2522 = lang.IFn_Cast(root_2520) } else { ifn_2522 = nil }; var arg_2523 any = s__292000224__3; if linked_2521 == nil { tmp7 = ifn_2522.Invoke_O__O(arg_2523) } else { tmp7 = linked_2521.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2520, arg_2523) }; arg_2511 = tmp6.Invoke_O__O(tmp7); if linked_2508 == nil { return ifn_2509.Invoke_O_O__O(arg_2510, arg_2511) } else { return linked_2508.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2507, arg_2510, arg_2511) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :401:1
func A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :401:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A) Ctor_O_I_O(c__b__292000226 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000226 = c__b__292000226; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :401:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A) Invoke_O__O(self any) any { { var i__292000225__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000230__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000225__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000230__2, lang.RT_IntCast_J__I_NoInit(0), nil); var g__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000230__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2467 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = t.F_b__292000226; var arg_2471 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_76, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_333.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_333.GetRawRoot__O()).Invoke_O__O(g__4))).Ref(); if linked_2468 == nil { ifn_2469.Invoke_O_O__O(arg_2470, arg_2471) } else { linked_2468.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2467, arg_2470, arg_2471) }; i__292000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000225__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A) Ctor() {}
//line :403:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A) Invoke_O_O__O(self, s__292000240__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A_New_O_O(s__292000240__1, self); var tmp2 *jrt.Class; var fncls__2604 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A_fn_class; if fncls__2604 == nil { var fncls__2604d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A_fn_class = fncls__2604d; tmp2 = fncls__2604d } else { tmp2 = fncls__2604 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :403:1
func A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A{}; t.Ctor_O_O(p0, p1); return t }
//line :403:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A) Ctor_O_O(c__s__292000240, c__iter__292000239 any) { t.F_s__292000240 = c__s__292000240; t.F_iter__292000239 = c__iter__292000239 }
//line :403:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A) Invoke_O__O(self any) any { { var s__292000240__1 any; var t_ any = t.F_s__292000240; t.F_s__292000240 = nil; s__292000240__1 = t_; for { var temp__1927000414__auto____2 any; var root_2531 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = s__292000240__1; if linked_2532 == nil { temp__1927000414__auto____2 = ifn_2533.Invoke_O__O(arg_2534) } else { temp__1927000414__auto____2 = linked_2532.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2531, arg_2534) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000240__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2535 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2535, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2537 lang.IFn; if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2538 any = s__292000240__3; if linked_2536 == nil { tmp1 = ifn_2537.Invoke_O__O(arg_2538) } else { tmp1 = linked_2536.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2535, arg_2538) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2539 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2541 lang.IFn; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = s__292000240__3; if linked_2540 == nil { c__1927001037__auto____4 = ifn_2541.Invoke_O__O(arg_2542) } else { c__1927001037__auto____4 = linked_2540.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2539, arg_2542) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000242__6 any; var root_2543 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2543, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2545 lang.IFn; if linked_2544 == nil { ifn_2545 = lang.IFn_Cast(root_2543) } else { ifn_2545 = nil }; var arg_2546 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2544 == nil { b__292000242__6 = ifn_2545.Invoke_O__O(arg_2546) } else { b__292000242__6 = linked_2544.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2543, arg_2546) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A_New_O_I_O(b__292000242__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2560 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A_fn_class; if fncls__2560 == nil { var fncls__2560d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A_fn_class = fncls__2560d; tmp3 = fncls__2560d } else { tmp3 = fncls__2560 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2561 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2561, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2563 lang.IFn; if linked_2562 == nil { ifn_2563 = lang.IFn_Cast(root_2561) } else { ifn_2563 = nil }; var arg_2564 any; var root_2566 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2566, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2568 lang.IFn; if linked_2567 == nil { ifn_2568 = lang.IFn_Cast(root_2566) } else { ifn_2568 = nil }; var arg_2569 any = b__292000242__6; if linked_2567 == nil { arg_2564 = ifn_2568.Invoke_O__O(arg_2569) } else { arg_2564 = linked_2567.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2566, arg_2569) }; var arg_2565 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000239); var tmp5 any; var root_2570 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2572 lang.IFn; if linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = s__292000240__3; if linked_2571 == nil { tmp5 = ifn_2572.Invoke_O__O(arg_2573) } else { tmp5 = linked_2571.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2570, arg_2573) }; arg_2565 = tmp4.Invoke_O__O(tmp5); if linked_2562 == nil { return ifn_2563.Invoke_O_O__O(arg_2564, arg_2565) } else { return linked_2562.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2561, arg_2564, arg_2565) } } else { var root_2574 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2574, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2576 lang.IFn; if linked_2575 == nil { ifn_2576 = lang.IFn_Cast(root_2574) } else { ifn_2576 = nil }; var arg_2577 any; var root_2579 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2579, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2581 lang.IFn; if linked_2580 == nil { ifn_2581 = lang.IFn_Cast(root_2579) } else { ifn_2581 = nil }; var arg_2582 any = b__292000242__6; if linked_2580 == nil { arg_2577 = ifn_2581.Invoke_O__O(arg_2582) } else { arg_2577 = linked_2580.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2579, arg_2582) }; var arg_2578 any; if linked_2575 == nil { return ifn_2576.Invoke_O_O__O(arg_2577, arg_2578) } else { return linked_2575.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2574, arg_2577, arg_2578) } } } else { var vec__292000250__4 any; var root_2583 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2583, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2585 lang.IFn; if linked_2584 == nil { ifn_2585 = lang.IFn_Cast(root_2583) } else { ifn_2585 = nil }; var arg_2586 any = s__292000240__3; if linked_2584 == nil { vec__292000250__4 = ifn_2585.Invoke_O__O(arg_2586) } else { vec__292000250__4 = linked_2584.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2583, arg_2586) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000250__4, lang.RT_IntCast_J__I_NoInit(0), nil); var cs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000250__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2587 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2587, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2589 lang.IFn; if linked_2588 == nil { ifn_2589 = lang.IFn_Cast(root_2587) } else { ifn_2589 = nil }; var arg_2590 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_76, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_333.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_333.GetRawRoot__O()).Invoke_O__O(cs__6))).Ref(); var arg_2591 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000239); var tmp7 any; var root_2600 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2602 lang.IFn; if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = s__292000240__3; if linked_2601 == nil { tmp7 = ifn_2602.Invoke_O__O(arg_2603) } else { tmp7 = linked_2601.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2600, arg_2603) }; arg_2591 = tmp6.Invoke_O__O(tmp7); if linked_2588 == nil { return ifn_2589.Invoke_O_O__O(arg_2590, arg_2591) } else { return linked_2588.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2587, arg_2590, arg_2591) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :403:1
func A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :403:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A) Ctor_O_I_O(c__b__292000242 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000242 = c__b__292000242; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :403:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A) Invoke_O__O(self any) any { { var i__292000241__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000241__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000246__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000241__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000246__2, lang.RT_IntCast_J__I_NoInit(0), nil); var cs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000246__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2547 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2547, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2549 lang.IFn; if linked_2548 == nil { ifn_2549 = lang.IFn_Cast(root_2547) } else { ifn_2549 = nil }; var arg_2550 any = t.F_b__292000242; var arg_2551 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_76, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_333.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_333.GetRawRoot__O()).Invoke_O__O(cs__4))).Ref(); if linked_2548 == nil { ifn_2549.Invoke_O_O__O(arg_2550, arg_2551) } else { linked_2548.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2547, arg_2550, arg_2551) }; i__292000241__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000241__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



























































































































































































































type A_arbace_j2g_dyncf_A struct{ jrt.Object }

var A_arbace_j2g_dyncf_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyncf_A_const_0 *lang.Var

var A_arbace_j2g_dyncf_A_const_1 any

var A_arbace_j2g_dyncf_A_const_2 any

var A_arbace_j2g_dyncf_A_const_3 any

var A_arbace_j2g_dyncf_A_const_4 any

var A_arbace_j2g_dyncf_A_const_5 any

var A_arbace_j2g_dyncf_A_const_6 any

var A_arbace_j2g_dyncf_A_const_7 any

var A_arbace_j2g_dyncf_A_const_8 any

var A_arbace_j2g_dyncf_A_const_9 any

var A_arbace_j2g_dyncf_A_const_10 any

var A_arbace_j2g_dyncf_A_const_11 any

var A_arbace_j2g_dyncf_A_const_12 *lang.Var

var A_arbace_j2g_dyncf_A_const_13 any

var A_arbace_j2g_dyncf_A_const_14 *lang.Var

var A_arbace_j2g_dyncf_A_const_15 *lang.Var

var A_arbace_j2g_dyncf_A_const_16 *lang.Var

var A_arbace_j2g_dyncf_A_const_17 *lang.Var

var A_arbace_j2g_dyncf_A_const_18 any

var A_arbace_j2g_dyncf_A_const_19 *lang.Var

var A_arbace_j2g_dyncf_A_const_20 *lang.Var

var A_arbace_j2g_dyncf_A_const_21 *lang.Var

var A_arbace_j2g_dyncf_A_const_22 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_23 *lang.Var

var A_arbace_j2g_dyncf_A_const_24 *lang.Var

var A_arbace_j2g_dyncf_A_const_25 *lang.Var

var A_arbace_j2g_dyncf_A_const_26 *lang.Var

var A_arbace_j2g_dyncf_A_const_27 *lang.Var

var A_arbace_j2g_dyncf_A_const_28 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_29 any

var A_arbace_j2g_dyncf_A_const_30 *lang.Var

var A_arbace_j2g_dyncf_A_const_31 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_32 any

var A_arbace_j2g_dyncf_A_const_33 *lang.Var

var A_arbace_j2g_dyncf_A_const_34 any

var A_arbace_j2g_dyncf_A_const_35 any

var A_arbace_j2g_dyncf_A_const_36 *lang.Var

var A_arbace_j2g_dyncf_A_const_37 *lang.Var

var A_arbace_j2g_dyncf_A_const_38 any

var A_arbace_j2g_dyncf_A_const_39 *lang.Var

var A_arbace_j2g_dyncf_A_const_40 *lang.Var

var A_arbace_j2g_dyncf_A_const_41 *lang.Var

var A_arbace_j2g_dyncf_A_const_42 any

var A_arbace_j2g_dyncf_A_const_43 any

var A_arbace_j2g_dyncf_A_const_44 *lang.Var

var A_arbace_j2g_dyncf_A_const_45 any

var A_arbace_j2g_dyncf_A_const_46 any

var A_arbace_j2g_dyncf_A_const_47 any

var A_arbace_j2g_dyncf_A_const_48 any

var A_arbace_j2g_dyncf_A_const_49 any

var A_arbace_j2g_dyncf_A_const_50 *lang.Var

var A_arbace_j2g_dyncf_A_const_51 *lang.Var

var A_arbace_j2g_dyncf_A_const_52 any

var A_arbace_j2g_dyncf_A_const_53 *lang.Var

var A_arbace_j2g_dyncf_A_const_54 any

var A_arbace_j2g_dyncf_A_const_55 any

var A_arbace_j2g_dyncf_A_const_56 any

var A_arbace_j2g_dyncf_A_const_57 any

var A_arbace_j2g_dyncf_A_const_58 any

var A_arbace_j2g_dyncf_A_const_59 any

var A_arbace_j2g_dyncf_A_const_60 any

var A_arbace_j2g_dyncf_A_const_61 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_62 any

var A_arbace_j2g_dyncf_A_const_63 any

var A_arbace_j2g_dyncf_A_const_64 any

var A_arbace_j2g_dyncf_A_const_65 *lang.Var

var A_arbace_j2g_dyncf_A_const_66 any

var A_arbace_j2g_dyncf_A_const_67 any

var A_arbace_j2g_dyncf_A_const_68 *lang.Var

var A_arbace_j2g_dyncf_A_const_69 *lang.Var

var A_arbace_j2g_dyncf_A_const_70 *lang.Var

var A_arbace_j2g_dyncf_A_const_71 *lang.Var

var A_arbace_j2g_dyncf_A_const_72 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_73 *lang.Var

var A_arbace_j2g_dyncf_A_const_74 *lang.Var

var A_arbace_j2g_dyncf_A_const_75 *lang.Var

var A_arbace_j2g_dyncf_A_const_76 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_77 *lang.Var

var A_arbace_j2g_dyncf_A_const_78 *lang.Var

var A_arbace_j2g_dyncf_A_const_79 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_80 *lang.Var

var A_arbace_j2g_dyncf_A_const_81 *lang.Var

var A_arbace_j2g_dyncf_A_const_82 *lang.Var

var A_arbace_j2g_dyncf_A_const_83 *lang.Var

var A_arbace_j2g_dyncf_A_const_84 *lang.Var

var A_arbace_j2g_dyncf_A_const_85 any

var A_arbace_j2g_dyncf_A_const_86 any

var A_arbace_j2g_dyncf_A_const_87 any

var A_arbace_j2g_dyncf_A_const_88 any

var A_arbace_j2g_dyncf_A_const_89 any

var A_arbace_j2g_dyncf_A_const_90 any

var A_arbace_j2g_dyncf_A_const_91 any

var A_arbace_j2g_dyncf_A_const_92 any

var A_arbace_j2g_dyncf_A_const_93 *lang.Var

var A_arbace_j2g_dyncf_A_const_94 *lang.Var

var A_arbace_j2g_dyncf_A_const_95 any

var A_arbace_j2g_dyncf_A_const_96 any

var A_arbace_j2g_dyncf_A_const_97 any

var A_arbace_j2g_dyncf_A_const_98 any

var A_arbace_j2g_dyncf_A_const_99 any

var A_arbace_j2g_dyncf_A_const_100 *lang.Var

var A_arbace_j2g_dyncf_A_const_101 *lang.Var

var A_arbace_j2g_dyncf_A_const_102 *lang.Var

var A_arbace_j2g_dyncf_A_const_103 *lang.Var

var A_arbace_j2g_dyncf_A_const_104 *lang.Var

var A_arbace_j2g_dyncf_A_const_105 any

var A_arbace_j2g_dyncf_A_const_106 *lang.Var

var A_arbace_j2g_dyncf_A_const_107 *lang.Var

var A_arbace_j2g_dyncf_A_const_108 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_109 *lang.Var

var A_arbace_j2g_dyncf_A_const_110 any

var A_arbace_j2g_dyncf_A_const_111 any

var A_arbace_j2g_dyncf_A_const_112 any

var A_arbace_j2g_dyncf_A_const_113 any

var A_arbace_j2g_dyncf_A_const_114 *lang.Var

var A_arbace_j2g_dyncf_A_const_115 any

var A_arbace_j2g_dyncf_A_const_116 any

var A_arbace_j2g_dyncf_A_const_117 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_118 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_119 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_120 any

var A_arbace_j2g_dyncf_A_const_121 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_122 any

var A_arbace_j2g_dyncf_A_const_123 any

var A_arbace_j2g_dyncf_A_const_124 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_125 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_126 any

var A_arbace_j2g_dyncf_A_const_127 any

var A_arbace_j2g_dyncf_A_const_128 any

var A_arbace_j2g_dyncf_A_const_129 any

var A_arbace_j2g_dyncf_A_const_130 any

var A_arbace_j2g_dyncf_A_const_131 any

var A_arbace_j2g_dyncf_A_const_132 any

var A_arbace_j2g_dyncf_A_const_133 any

var A_arbace_j2g_dyncf_A_const_134 any

var A_arbace_j2g_dyncf_A_const_135 any

var A_arbace_j2g_dyncf_A_const_136 any

var A_arbace_j2g_dyncf_A_const_137 any

var A_arbace_j2g_dyncf_A_const_138 any

var A_arbace_j2g_dyncf_A_const_139 any

var A_arbace_j2g_dyncf_A_const_140 any

var A_arbace_j2g_dyncf_A_const_141 any

var A_arbace_j2g_dyncf_A_const_142 any

var A_arbace_j2g_dyncf_A_const_143 any

var A_arbace_j2g_dyncf_A_const_144 *lang.Var

var A_arbace_j2g_dyncf_A_const_145 *lang.Var

var A_arbace_j2g_dyncf_A_const_146 *lang.Var

var A_arbace_j2g_dyncf_A_const_147 *lang.Var

var A_arbace_j2g_dyncf_A_const_148 *lang.Var

var A_arbace_j2g_dyncf_A_const_149 *lang.Var

var A_arbace_j2g_dyncf_A_const_150 any

var A_arbace_j2g_dyncf_A_const_151 any

var A_arbace_j2g_dyncf_A_const_152 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_153 any

var A_arbace_j2g_dyncf_A_const_154 any

var A_arbace_j2g_dyncf_A_const_155 any

var A_arbace_j2g_dyncf_A_const_156 any

var A_arbace_j2g_dyncf_A_const_157 any

var A_arbace_j2g_dyncf_A_const_158 any

var A_arbace_j2g_dyncf_A_const_159 any

var A_arbace_j2g_dyncf_A_const_160 any

var A_arbace_j2g_dyncf_A_const_161 *lang.Var

var A_arbace_j2g_dyncf_A_const_162 any

var A_arbace_j2g_dyncf_A_const_163 any

var A_arbace_j2g_dyncf_A_const_164 any

var A_arbace_j2g_dyncf_A_const_165 any

var A_arbace_j2g_dyncf_A_const_166 any

var A_arbace_j2g_dyncf_A_const_167 any

var A_arbace_j2g_dyncf_A_const_168 *lang.Var

var A_arbace_j2g_dyncf_A_const_169 any

var A_arbace_j2g_dyncf_A_const_170 any

var A_arbace_j2g_dyncf_A_const_171 any

var A_arbace_j2g_dyncf_A_const_172 any

var A_arbace_j2g_dyncf_A_const_173 any

var A_arbace_j2g_dyncf_A_const_174 any

var A_arbace_j2g_dyncf_A_const_175 any

var A_arbace_j2g_dyncf_A_const_176 any

var A_arbace_j2g_dyncf_A_const_177 any

var A_arbace_j2g_dyncf_A_const_178 any

var A_arbace_j2g_dyncf_A_const_179 any

var A_arbace_j2g_dyncf_A_const_180 any

var A_arbace_j2g_dyncf_A_const_181 any

var A_arbace_j2g_dyncf_A_const_182 any

var A_arbace_j2g_dyncf_A_const_183 any

var A_arbace_j2g_dyncf_A_const_184 any

var A_arbace_j2g_dyncf_A_const_185 any

var A_arbace_j2g_dyncf_A_const_186 any

var A_arbace_j2g_dyncf_A_const_187 any

var A_arbace_j2g_dyncf_A_const_188 any

var A_arbace_j2g_dyncf_A_const_189 any

var A_arbace_j2g_dyncf_A_const_190 any

var A_arbace_j2g_dyncf_A_const_191 any

var A_arbace_j2g_dyncf_A_const_192 any

var A_arbace_j2g_dyncf_A_const_193 any

var A_arbace_j2g_dyncf_A_const_194 any

var A_arbace_j2g_dyncf_A_const_195 any

var A_arbace_j2g_dyncf_A_const_196 any

var A_arbace_j2g_dyncf_A_const_197 any

var A_arbace_j2g_dyncf_A_const_198 any

var A_arbace_j2g_dyncf_A_const_199 any

var A_arbace_j2g_dyncf_A_const_200 any

var A_arbace_j2g_dyncf_A_const_201 any

var A_arbace_j2g_dyncf_A_const_202 any

var A_arbace_j2g_dyncf_A_const_203 any

var A_arbace_j2g_dyncf_A_const_204 any

var A_arbace_j2g_dyncf_A_const_205 any

var A_arbace_j2g_dyncf_A_const_206 any

var A_arbace_j2g_dyncf_A_const_207 any

var A_arbace_j2g_dyncf_A_const_208 any

var A_arbace_j2g_dyncf_A_const_209 any

var A_arbace_j2g_dyncf_A_const_210 any

var A_arbace_j2g_dyncf_A_const_211 any

var A_arbace_j2g_dyncf_A_const_212 any

var A_arbace_j2g_dyncf_A_const_213 any

var A_arbace_j2g_dyncf_A_const_214 any

var A_arbace_j2g_dyncf_A_const_215 any

var A_arbace_j2g_dyncf_A_const_216 any

var A_arbace_j2g_dyncf_A_const_217 any

var A_arbace_j2g_dyncf_A_const_218 any

var A_arbace_j2g_dyncf_A_const_219 any

var A_arbace_j2g_dyncf_A_const_220 any

var A_arbace_j2g_dyncf_A_const_221 any

var A_arbace_j2g_dyncf_A_const_222 any

var A_arbace_j2g_dyncf_A_const_223 any

var A_arbace_j2g_dyncf_A_const_224 any

var A_arbace_j2g_dyncf_A_const_225 any

var A_arbace_j2g_dyncf_A_const_226 any

var A_arbace_j2g_dyncf_A_const_227 any

var A_arbace_j2g_dyncf_A_const_228 any

var A_arbace_j2g_dyncf_A_const_229 any

var A_arbace_j2g_dyncf_A_const_230 any

var A_arbace_j2g_dyncf_A_const_231 any

var A_arbace_j2g_dyncf_A_const_232 any

var A_arbace_j2g_dyncf_A_const_233 any

var A_arbace_j2g_dyncf_A_const_234 any

var A_arbace_j2g_dyncf_A_const_235 any

var A_arbace_j2g_dyncf_A_const_236 any

var A_arbace_j2g_dyncf_A_const_237 any

var A_arbace_j2g_dyncf_A_const_238 any

var A_arbace_j2g_dyncf_A_const_239 any

var A_arbace_j2g_dyncf_A_const_240 any

var A_arbace_j2g_dyncf_A_const_241 any

var A_arbace_j2g_dyncf_A_const_242 any

var A_arbace_j2g_dyncf_A_const_243 any

var A_arbace_j2g_dyncf_A_const_244 any

var A_arbace_j2g_dyncf_A_const_245 any

var A_arbace_j2g_dyncf_A_const_246 any

var A_arbace_j2g_dyncf_A_const_247 any

var A_arbace_j2g_dyncf_A_const_248 any

var A_arbace_j2g_dyncf_A_const_249 any

var A_arbace_j2g_dyncf_A_const_250 any

var A_arbace_j2g_dyncf_A_const_251 any

var A_arbace_j2g_dyncf_A_const_252 any

var A_arbace_j2g_dyncf_A_const_253 any

var A_arbace_j2g_dyncf_A_const_254 any

var A_arbace_j2g_dyncf_A_const_255 any

var A_arbace_j2g_dyncf_A_const_256 any

var A_arbace_j2g_dyncf_A_const_257 any

var A_arbace_j2g_dyncf_A_const_258 any

var A_arbace_j2g_dyncf_A_const_259 any

var A_arbace_j2g_dyncf_A_const_260 any

var A_arbace_j2g_dyncf_A_const_261 any

var A_arbace_j2g_dyncf_A_const_262 any

var A_arbace_j2g_dyncf_A_const_263 any

var A_arbace_j2g_dyncf_A_const_264 any

var A_arbace_j2g_dyncf_A_const_265 any

var A_arbace_j2g_dyncf_A_const_266 any

var A_arbace_j2g_dyncf_A_const_267 any

var A_arbace_j2g_dyncf_A_const_268 any

var A_arbace_j2g_dyncf_A_const_269 any

var A_arbace_j2g_dyncf_A_const_270 any

var A_arbace_j2g_dyncf_A_const_271 any

var A_arbace_j2g_dyncf_A_const_272 any

var A_arbace_j2g_dyncf_A_const_273 any

var A_arbace_j2g_dyncf_A_const_274 any

var A_arbace_j2g_dyncf_A_const_275 any

var A_arbace_j2g_dyncf_A_const_276 any

var A_arbace_j2g_dyncf_A_const_277 any

var A_arbace_j2g_dyncf_A_const_278 any

var A_arbace_j2g_dyncf_A_const_279 any

var A_arbace_j2g_dyncf_A_const_280 any

var A_arbace_j2g_dyncf_A_const_281 any

var A_arbace_j2g_dyncf_A_const_282 any

var A_arbace_j2g_dyncf_A_const_283 any

var A_arbace_j2g_dyncf_A_const_284 any

var A_arbace_j2g_dyncf_A_const_285 any

var A_arbace_j2g_dyncf_A_const_286 any

var A_arbace_j2g_dyncf_A_const_287 any

var A_arbace_j2g_dyncf_A_const_288 any

var A_arbace_j2g_dyncf_A_const_289 any

var A_arbace_j2g_dyncf_A_const_290 any

var A_arbace_j2g_dyncf_A_const_291 *lang.Var

var A_arbace_j2g_dyncf_A_const_292 *lang.Var

var A_arbace_j2g_dyncf_A_const_293 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_294 *lang.Var

var A_arbace_j2g_dyncf_A_const_295 *lang.Var

var A_arbace_j2g_dyncf_A_const_296 *lang.Var

var A_arbace_j2g_dyncf_A_const_297 any

var A_arbace_j2g_dyncf_A_const_298 any

var A_arbace_j2g_dyncf_A_const_299 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_300 *lang.Var

var A_arbace_j2g_dyncf_A_const_301 *lang.Var

var A_arbace_j2g_dyncf_A_const_302 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_303 *lang.Var

var A_arbace_j2g_dyncf_A_const_304 *lang.Var

var A_arbace_j2g_dyncf_A_const_305 *lang.Var

var A_arbace_j2g_dyncf_A_const_306 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_307 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_308 any

var A_arbace_j2g_dyncf_A_const_309 *lang.Var

var A_arbace_j2g_dyncf_A_const_310 *lang.Var

var A_arbace_j2g_dyncf_A_const_311 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_312 *lang.Var

var A_arbace_j2g_dyncf_A_const_313 *lang.Var

var A_arbace_j2g_dyncf_A_const_314 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_315 *lang.Var

var A_arbace_j2g_dyncf_A_const_316 any

var A_arbace_j2g_dyncf_A_const_317 any

var A_arbace_j2g_dyncf_A_const_318 any

var A_arbace_j2g_dyncf_A_const_319 any

var A_arbace_j2g_dyncf_A_const_320 any

var A_arbace_j2g_dyncf_A_const_321 any

var A_arbace_j2g_dyncf_A_const_322 *lang.Var

var A_arbace_j2g_dyncf_A_const_323 *lang.Var

var A_arbace_j2g_dyncf_A_const_324 *lang.Var

var A_arbace_j2g_dyncf_A_const_325 *lang.Var

var A_arbace_j2g_dyncf_A_const_326 *lang.Var

var A_arbace_j2g_dyncf_A_const_327 *lang.Var

var A_arbace_j2g_dyncf_A_const_328 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_329 any

var A_arbace_j2g_dyncf_A_const_330 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_331 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_332 *lang.Var

var A_arbace_j2g_dyncf_A_const_333 *lang.Var

var A_arbace_j2g_dyncf_A_const_334 *lang.Var

var A_arbace_j2g_dyncf_A_const_335 *lang.Var

var A_arbace_j2g_dyncf_A_const_336 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_337 *lang.Var

var A_arbace_j2g_dyncf_A_const_338 *lang.Var

var A_arbace_j2g_dyncf_A_const_339 *lang.Var

var A_arbace_j2g_dyncf_A_const_340 *lang.Var

var A_arbace_j2g_dyncf_A_init jrt.ClassInit

func A_arbace_j2g_dyncf_A_Init() { if !A_arbace_j2g_dyncf_A_init.Done() { A_arbace_j2g_dyncf_A_init.Run(A_arbace_j2g_dyncf_A_clinit) } }

func A_arbace_j2g_dyncf_A_clinit() { A_arbace_j2g_dyncf_A_clinit_p0(); A_arbace_j2g_dyncf_A_clinit_p1(); A_arbace_j2g_dyncf_A_clinit_p2(); A_arbace_j2g_dyncf_A_clinit_p3(); A_arbace_j2g_dyncf_A_clinit_p4(); A_arbace_j2g_dyncf_A_clinit_p5(); A_arbace_j2g_dyncf_A_clinit_p6(); A_arbace_j2g_dyncf_A_clinit_p7(); A_arbace_j2g_dyncf_A_clinit_p8(); A_arbace_j2g_dyncf_A_clinit_p9(); A_arbace_j2g_dyncf_A_clinit_p10(); A_arbace_j2g_dyncf_A_clinit_p11(); A_arbace_j2g_dyncf_A_clinit_p12(); A_arbace_j2g_dyncf_A_clinit_p13(); A_arbace_j2g_dyncf_A_clinit_p14(); A_arbace_j2g_dyncf_A_clinit_p15(); A_arbace_j2g_dyncf_A_clinit_p16(); A_arbace_j2g_dyncf_A_clinit_p17(); A_arbace_j2g_dyncf_A_clinit_p18(); A_arbace_j2g_dyncf_A_clinit_p19(); A_arbace_j2g_dyncf_A_clinit_p20(); A_arbace_j2g_dyncf_A_clinit_p21(); A_arbace_j2g_dyncf_A_clinit_p22(); A_arbace_j2g_dyncf_A_clinit_p23(); A_arbace_j2g_dyncf_A_clinit_p24() }

func A_arbace_j2g_dyncf_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyncf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 578); A_arbace_j2g_dyncf_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[237]); A_arbace_j2g_dyncf_A_const_1 = A_arbace_j2g_dyncf_A_const_pool.A[238]; A_arbace_j2g_dyncf_A_const_2 = A_arbace_j2g_dyncf_A_const_pool.A[239]; A_arbace_j2g_dyncf_A_const_3 = A_arbace_j2g_dyncf_A_const_pool.A[240]; A_arbace_j2g_dyncf_A_const_4 = A_arbace_j2g_dyncf_A_const_pool.A[241]; A_arbace_j2g_dyncf_A_const_5 = A_arbace_j2g_dyncf_A_const_pool.A[242]; A_arbace_j2g_dyncf_A_const_6 = A_arbace_j2g_dyncf_A_const_pool.A[243]; A_arbace_j2g_dyncf_A_const_7 = A_arbace_j2g_dyncf_A_const_pool.A[244]; A_arbace_j2g_dyncf_A_const_8 = A_arbace_j2g_dyncf_A_const_pool.A[245]; A_arbace_j2g_dyncf_A_const_9 = A_arbace_j2g_dyncf_A_const_pool.A[246]; A_arbace_j2g_dyncf_A_const_10 = A_arbace_j2g_dyncf_A_const_pool.A[247]; A_arbace_j2g_dyncf_A_const_11 = A_arbace_j2g_dyncf_A_const_pool.A[248]; A_arbace_j2g_dyncf_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[249]); A_arbace_j2g_dyncf_A_const_13 = A_arbace_j2g_dyncf_A_const_pool.A[250] }

func A_arbace_j2g_dyncf_A_clinit_p1() { A_arbace_j2g_dyncf_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[251]); A_arbace_j2g_dyncf_A_const_15 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[252]); A_arbace_j2g_dyncf_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[253]); A_arbace_j2g_dyncf_A_const_17 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[254]); A_arbace_j2g_dyncf_A_const_18 = A_arbace_j2g_dyncf_A_const_pool.A[255]; A_arbace_j2g_dyncf_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[256]); A_arbace_j2g_dyncf_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[257]); A_arbace_j2g_dyncf_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[258]); A_arbace_j2g_dyncf_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[259]); A_arbace_j2g_dyncf_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[260]); A_arbace_j2g_dyncf_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[261]); A_arbace_j2g_dyncf_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[262]) }

func A_arbace_j2g_dyncf_A_clinit_p2() { A_arbace_j2g_dyncf_A_const_26 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[263]); A_arbace_j2g_dyncf_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[264]); A_arbace_j2g_dyncf_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[265]); A_arbace_j2g_dyncf_A_const_29 = A_arbace_j2g_dyncf_A_const_pool.A[266]; A_arbace_j2g_dyncf_A_const_30 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[267]); A_arbace_j2g_dyncf_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[268]); A_arbace_j2g_dyncf_A_const_32 = A_arbace_j2g_dyncf_A_const_pool.A[269]; A_arbace_j2g_dyncf_A_const_33 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[270]); A_arbace_j2g_dyncf_A_const_34 = A_arbace_j2g_dyncf_A_const_pool.A[271]; A_arbace_j2g_dyncf_A_const_35 = A_arbace_j2g_dyncf_A_const_pool.A[272]; A_arbace_j2g_dyncf_A_const_36 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[273]); A_arbace_j2g_dyncf_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[274]); A_arbace_j2g_dyncf_A_const_38 = A_arbace_j2g_dyncf_A_const_pool.A[275] }

func A_arbace_j2g_dyncf_A_clinit_p3() { A_arbace_j2g_dyncf_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[276]); A_arbace_j2g_dyncf_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[277]); A_arbace_j2g_dyncf_A_const_41 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[278]); A_arbace_j2g_dyncf_A_const_42 = A_arbace_j2g_dyncf_A_const_pool.A[279]; A_arbace_j2g_dyncf_A_const_43 = A_arbace_j2g_dyncf_A_const_pool.A[280]; A_arbace_j2g_dyncf_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[281]); A_arbace_j2g_dyncf_A_const_45 = A_arbace_j2g_dyncf_A_const_pool.A[282]; A_arbace_j2g_dyncf_A_const_46 = A_arbace_j2g_dyncf_A_const_pool.A[283]; A_arbace_j2g_dyncf_A_const_47 = A_arbace_j2g_dyncf_A_const_pool.A[284]; A_arbace_j2g_dyncf_A_const_48 = A_arbace_j2g_dyncf_A_const_pool.A[285]; A_arbace_j2g_dyncf_A_const_49 = A_arbace_j2g_dyncf_A_const_pool.A[286]; A_arbace_j2g_dyncf_A_const_50 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[287]); A_arbace_j2g_dyncf_A_const_51 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[288]); A_arbace_j2g_dyncf_A_const_52 = A_arbace_j2g_dyncf_A_const_pool.A[289] }

func A_arbace_j2g_dyncf_A_clinit_p4() { A_arbace_j2g_dyncf_A_const_53 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[290]); A_arbace_j2g_dyncf_A_const_54 = A_arbace_j2g_dyncf_A_const_pool.A[291]; A_arbace_j2g_dyncf_A_const_55 = A_arbace_j2g_dyncf_A_const_pool.A[292]; A_arbace_j2g_dyncf_A_const_56 = A_arbace_j2g_dyncf_A_const_pool.A[293]; A_arbace_j2g_dyncf_A_const_57 = A_arbace_j2g_dyncf_A_const_pool.A[294]; A_arbace_j2g_dyncf_A_const_58 = A_arbace_j2g_dyncf_A_const_pool.A[295]; A_arbace_j2g_dyncf_A_const_59 = A_arbace_j2g_dyncf_A_const_pool.A[296]; A_arbace_j2g_dyncf_A_const_60 = A_arbace_j2g_dyncf_A_const_pool.A[297]; A_arbace_j2g_dyncf_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[298]); A_arbace_j2g_dyncf_A_const_62 = A_arbace_j2g_dyncf_A_const_pool.A[299]; A_arbace_j2g_dyncf_A_const_63 = A_arbace_j2g_dyncf_A_const_pool.A[300]; A_arbace_j2g_dyncf_A_const_64 = A_arbace_j2g_dyncf_A_const_pool.A[301]; A_arbace_j2g_dyncf_A_const_65 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[302]); A_arbace_j2g_dyncf_A_const_66 = A_arbace_j2g_dyncf_A_const_pool.A[303]; A_arbace_j2g_dyncf_A_const_67 = A_arbace_j2g_dyncf_A_const_pool.A[304] }

func A_arbace_j2g_dyncf_A_clinit_p5() { A_arbace_j2g_dyncf_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[305]); A_arbace_j2g_dyncf_A_const_69 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[306]); A_arbace_j2g_dyncf_A_const_70 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[307]); A_arbace_j2g_dyncf_A_const_71 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[308]); A_arbace_j2g_dyncf_A_const_72 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[309]); A_arbace_j2g_dyncf_A_const_73 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[310]); A_arbace_j2g_dyncf_A_const_74 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[311]); A_arbace_j2g_dyncf_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[312]); A_arbace_j2g_dyncf_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[313]); A_arbace_j2g_dyncf_A_const_77 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[314]); A_arbace_j2g_dyncf_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[315]); A_arbace_j2g_dyncf_A_const_79 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[316]) }

func A_arbace_j2g_dyncf_A_clinit_p6() { A_arbace_j2g_dyncf_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[317]); A_arbace_j2g_dyncf_A_const_81 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[318]); A_arbace_j2g_dyncf_A_const_82 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[319]); A_arbace_j2g_dyncf_A_const_83 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[320]); A_arbace_j2g_dyncf_A_const_84 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[321]); A_arbace_j2g_dyncf_A_const_85 = A_arbace_j2g_dyncf_A_const_pool.A[322]; A_arbace_j2g_dyncf_A_const_86 = A_arbace_j2g_dyncf_A_const_pool.A[323]; A_arbace_j2g_dyncf_A_const_87 = A_arbace_j2g_dyncf_A_const_pool.A[324]; A_arbace_j2g_dyncf_A_const_88 = A_arbace_j2g_dyncf_A_const_pool.A[325]; A_arbace_j2g_dyncf_A_const_89 = A_arbace_j2g_dyncf_A_const_pool.A[326]; A_arbace_j2g_dyncf_A_const_90 = A_arbace_j2g_dyncf_A_const_pool.A[327]; A_arbace_j2g_dyncf_A_const_91 = A_arbace_j2g_dyncf_A_const_pool.A[328]; A_arbace_j2g_dyncf_A_const_92 = A_arbace_j2g_dyncf_A_const_pool.A[329]; A_arbace_j2g_dyncf_A_const_93 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[330]) }

func A_arbace_j2g_dyncf_A_clinit_p7() { A_arbace_j2g_dyncf_A_const_94 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[331]); A_arbace_j2g_dyncf_A_const_95 = A_arbace_j2g_dyncf_A_const_pool.A[332]; A_arbace_j2g_dyncf_A_const_96 = A_arbace_j2g_dyncf_A_const_pool.A[333]; A_arbace_j2g_dyncf_A_const_97 = A_arbace_j2g_dyncf_A_const_pool.A[334]; A_arbace_j2g_dyncf_A_const_98 = A_arbace_j2g_dyncf_A_const_pool.A[335]; A_arbace_j2g_dyncf_A_const_99 = A_arbace_j2g_dyncf_A_const_pool.A[336]; A_arbace_j2g_dyncf_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[337]); A_arbace_j2g_dyncf_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[338]); A_arbace_j2g_dyncf_A_const_102 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[339]); A_arbace_j2g_dyncf_A_const_103 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[340]); A_arbace_j2g_dyncf_A_const_104 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[341]); A_arbace_j2g_dyncf_A_const_105 = A_arbace_j2g_dyncf_A_const_pool.A[342]; A_arbace_j2g_dyncf_A_const_106 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[343]) }

func A_arbace_j2g_dyncf_A_clinit_p8() { A_arbace_j2g_dyncf_A_const_107 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[344]); A_arbace_j2g_dyncf_A_const_108 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[345]); A_arbace_j2g_dyncf_A_const_109 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[346]); A_arbace_j2g_dyncf_A_const_110 = A_arbace_j2g_dyncf_A_const_pool.A[347]; A_arbace_j2g_dyncf_A_const_111 = A_arbace_j2g_dyncf_A_const_pool.A[348]; A_arbace_j2g_dyncf_A_const_112 = A_arbace_j2g_dyncf_A_const_pool.A[349]; A_arbace_j2g_dyncf_A_const_113 = A_arbace_j2g_dyncf_A_const_pool.A[350]; A_arbace_j2g_dyncf_A_const_114 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[351]); A_arbace_j2g_dyncf_A_const_115 = A_arbace_j2g_dyncf_A_const_pool.A[352]; A_arbace_j2g_dyncf_A_const_116 = A_arbace_j2g_dyncf_A_const_pool.A[353]; A_arbace_j2g_dyncf_A_const_117 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[354]); A_arbace_j2g_dyncf_A_const_118 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[355]); A_arbace_j2g_dyncf_A_const_119 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[356]) }

func A_arbace_j2g_dyncf_A_clinit_p9() { A_arbace_j2g_dyncf_A_const_120 = A_arbace_j2g_dyncf_A_const_pool.A[357]; A_arbace_j2g_dyncf_A_const_121 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[358]); A_arbace_j2g_dyncf_A_const_122 = A_arbace_j2g_dyncf_A_const_pool.A[359]; A_arbace_j2g_dyncf_A_const_123 = A_arbace_j2g_dyncf_A_const_pool.A[360]; A_arbace_j2g_dyncf_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[361]); A_arbace_j2g_dyncf_A_const_125 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[362]); A_arbace_j2g_dyncf_A_const_126 = A_arbace_j2g_dyncf_A_const_pool.A[363]; A_arbace_j2g_dyncf_A_const_127 = A_arbace_j2g_dyncf_A_const_pool.A[364]; A_arbace_j2g_dyncf_A_const_128 = A_arbace_j2g_dyncf_A_const_pool.A[365]; A_arbace_j2g_dyncf_A_const_129 = A_arbace_j2g_dyncf_A_const_pool.A[366]; A_arbace_j2g_dyncf_A_const_130 = A_arbace_j2g_dyncf_A_const_pool.A[367]; A_arbace_j2g_dyncf_A_const_131 = A_arbace_j2g_dyncf_A_const_pool.A[368]; A_arbace_j2g_dyncf_A_const_132 = A_arbace_j2g_dyncf_A_const_pool.A[369]; A_arbace_j2g_dyncf_A_const_133 = A_arbace_j2g_dyncf_A_const_pool.A[370]; A_arbace_j2g_dyncf_A_const_134 = A_arbace_j2g_dyncf_A_const_pool.A[371] }

func A_arbace_j2g_dyncf_A_clinit_p10() { A_arbace_j2g_dyncf_A_const_135 = A_arbace_j2g_dyncf_A_const_pool.A[372]; A_arbace_j2g_dyncf_A_const_136 = A_arbace_j2g_dyncf_A_const_pool.A[373]; A_arbace_j2g_dyncf_A_const_137 = A_arbace_j2g_dyncf_A_const_pool.A[374]; A_arbace_j2g_dyncf_A_const_138 = A_arbace_j2g_dyncf_A_const_pool.A[375]; A_arbace_j2g_dyncf_A_const_139 = A_arbace_j2g_dyncf_A_const_pool.A[376]; A_arbace_j2g_dyncf_A_const_140 = A_arbace_j2g_dyncf_A_const_pool.A[377]; A_arbace_j2g_dyncf_A_const_141 = A_arbace_j2g_dyncf_A_const_pool.A[378]; A_arbace_j2g_dyncf_A_const_142 = A_arbace_j2g_dyncf_A_const_pool.A[379]; A_arbace_j2g_dyncf_A_const_143 = A_arbace_j2g_dyncf_A_const_pool.A[380]; A_arbace_j2g_dyncf_A_const_144 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[381]); A_arbace_j2g_dyncf_A_const_145 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[382]); A_arbace_j2g_dyncf_A_const_146 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[383]); A_arbace_j2g_dyncf_A_const_147 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[384]); A_arbace_j2g_dyncf_A_const_148 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[385]) }

func A_arbace_j2g_dyncf_A_clinit_p11() { A_arbace_j2g_dyncf_A_const_149 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[386]); A_arbace_j2g_dyncf_A_const_150 = A_arbace_j2g_dyncf_A_const_pool.A[387]; A_arbace_j2g_dyncf_A_const_151 = A_arbace_j2g_dyncf_A_const_pool.A[388]; A_arbace_j2g_dyncf_A_const_152 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[389]); A_arbace_j2g_dyncf_A_const_153 = A_arbace_j2g_dyncf_A_const_pool.A[390]; A_arbace_j2g_dyncf_A_const_154 = A_arbace_j2g_dyncf_A_const_pool.A[391]; A_arbace_j2g_dyncf_A_const_155 = A_arbace_j2g_dyncf_A_const_pool.A[392]; A_arbace_j2g_dyncf_A_const_156 = A_arbace_j2g_dyncf_A_const_pool.A[393]; A_arbace_j2g_dyncf_A_const_157 = A_arbace_j2g_dyncf_A_const_pool.A[394]; A_arbace_j2g_dyncf_A_const_158 = A_arbace_j2g_dyncf_A_const_pool.A[395]; A_arbace_j2g_dyncf_A_const_159 = A_arbace_j2g_dyncf_A_const_pool.A[396]; A_arbace_j2g_dyncf_A_const_160 = A_arbace_j2g_dyncf_A_const_pool.A[397]; A_arbace_j2g_dyncf_A_const_161 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[398]); A_arbace_j2g_dyncf_A_const_162 = A_arbace_j2g_dyncf_A_const_pool.A[399]; A_arbace_j2g_dyncf_A_const_163 = A_arbace_j2g_dyncf_A_const_pool.A[400] }

func A_arbace_j2g_dyncf_A_clinit_p12() { A_arbace_j2g_dyncf_A_const_164 = A_arbace_j2g_dyncf_A_const_pool.A[401]; A_arbace_j2g_dyncf_A_const_165 = A_arbace_j2g_dyncf_A_const_pool.A[402]; A_arbace_j2g_dyncf_A_const_166 = A_arbace_j2g_dyncf_A_const_pool.A[403]; A_arbace_j2g_dyncf_A_const_167 = A_arbace_j2g_dyncf_A_const_pool.A[404]; A_arbace_j2g_dyncf_A_const_168 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[405]); A_arbace_j2g_dyncf_A_const_169 = A_arbace_j2g_dyncf_A_const_pool.A[406]; A_arbace_j2g_dyncf_A_const_170 = A_arbace_j2g_dyncf_A_const_pool.A[407]; A_arbace_j2g_dyncf_A_const_171 = A_arbace_j2g_dyncf_A_const_pool.A[408]; A_arbace_j2g_dyncf_A_const_172 = A_arbace_j2g_dyncf_A_const_pool.A[409]; A_arbace_j2g_dyncf_A_const_173 = A_arbace_j2g_dyncf_A_const_pool.A[410]; A_arbace_j2g_dyncf_A_const_174 = A_arbace_j2g_dyncf_A_const_pool.A[411]; A_arbace_j2g_dyncf_A_const_175 = A_arbace_j2g_dyncf_A_const_pool.A[412]; A_arbace_j2g_dyncf_A_const_176 = A_arbace_j2g_dyncf_A_const_pool.A[413]; A_arbace_j2g_dyncf_A_const_177 = A_arbace_j2g_dyncf_A_const_pool.A[414]; A_arbace_j2g_dyncf_A_const_178 = A_arbace_j2g_dyncf_A_const_pool.A[415] }

func A_arbace_j2g_dyncf_A_clinit_p13() { A_arbace_j2g_dyncf_A_const_179 = A_arbace_j2g_dyncf_A_const_pool.A[416]; A_arbace_j2g_dyncf_A_const_180 = A_arbace_j2g_dyncf_A_const_pool.A[417]; A_arbace_j2g_dyncf_A_const_181 = A_arbace_j2g_dyncf_A_const_pool.A[418]; A_arbace_j2g_dyncf_A_const_182 = A_arbace_j2g_dyncf_A_const_pool.A[419]; A_arbace_j2g_dyncf_A_const_183 = A_arbace_j2g_dyncf_A_const_pool.A[420]; A_arbace_j2g_dyncf_A_const_184 = A_arbace_j2g_dyncf_A_const_pool.A[421]; A_arbace_j2g_dyncf_A_const_185 = A_arbace_j2g_dyncf_A_const_pool.A[422]; A_arbace_j2g_dyncf_A_const_186 = A_arbace_j2g_dyncf_A_const_pool.A[423]; A_arbace_j2g_dyncf_A_const_187 = A_arbace_j2g_dyncf_A_const_pool.A[424]; A_arbace_j2g_dyncf_A_const_188 = A_arbace_j2g_dyncf_A_const_pool.A[425]; A_arbace_j2g_dyncf_A_const_189 = A_arbace_j2g_dyncf_A_const_pool.A[426]; A_arbace_j2g_dyncf_A_const_190 = A_arbace_j2g_dyncf_A_const_pool.A[427]; A_arbace_j2g_dyncf_A_const_191 = A_arbace_j2g_dyncf_A_const_pool.A[428]; A_arbace_j2g_dyncf_A_const_192 = A_arbace_j2g_dyncf_A_const_pool.A[429]; A_arbace_j2g_dyncf_A_const_193 = A_arbace_j2g_dyncf_A_const_pool.A[430]; A_arbace_j2g_dyncf_A_const_194 = A_arbace_j2g_dyncf_A_const_pool.A[431] }

func A_arbace_j2g_dyncf_A_clinit_p14() { A_arbace_j2g_dyncf_A_const_195 = A_arbace_j2g_dyncf_A_const_pool.A[432]; A_arbace_j2g_dyncf_A_const_196 = A_arbace_j2g_dyncf_A_const_pool.A[433]; A_arbace_j2g_dyncf_A_const_197 = A_arbace_j2g_dyncf_A_const_pool.A[434]; A_arbace_j2g_dyncf_A_const_198 = A_arbace_j2g_dyncf_A_const_pool.A[435]; A_arbace_j2g_dyncf_A_const_199 = A_arbace_j2g_dyncf_A_const_pool.A[436]; A_arbace_j2g_dyncf_A_const_200 = A_arbace_j2g_dyncf_A_const_pool.A[437]; A_arbace_j2g_dyncf_A_const_201 = A_arbace_j2g_dyncf_A_const_pool.A[438]; A_arbace_j2g_dyncf_A_const_202 = A_arbace_j2g_dyncf_A_const_pool.A[439]; A_arbace_j2g_dyncf_A_const_203 = A_arbace_j2g_dyncf_A_const_pool.A[440]; A_arbace_j2g_dyncf_A_const_204 = A_arbace_j2g_dyncf_A_const_pool.A[441]; A_arbace_j2g_dyncf_A_const_205 = A_arbace_j2g_dyncf_A_const_pool.A[442]; A_arbace_j2g_dyncf_A_const_206 = A_arbace_j2g_dyncf_A_const_pool.A[443]; A_arbace_j2g_dyncf_A_const_207 = A_arbace_j2g_dyncf_A_const_pool.A[444]; A_arbace_j2g_dyncf_A_const_208 = A_arbace_j2g_dyncf_A_const_pool.A[445]; A_arbace_j2g_dyncf_A_const_209 = A_arbace_j2g_dyncf_A_const_pool.A[446]; A_arbace_j2g_dyncf_A_const_210 = A_arbace_j2g_dyncf_A_const_pool.A[447] }

func A_arbace_j2g_dyncf_A_clinit_p15() { A_arbace_j2g_dyncf_A_const_211 = A_arbace_j2g_dyncf_A_const_pool.A[448]; A_arbace_j2g_dyncf_A_const_212 = A_arbace_j2g_dyncf_A_const_pool.A[449]; A_arbace_j2g_dyncf_A_const_213 = A_arbace_j2g_dyncf_A_const_pool.A[450]; A_arbace_j2g_dyncf_A_const_214 = A_arbace_j2g_dyncf_A_const_pool.A[451]; A_arbace_j2g_dyncf_A_const_215 = A_arbace_j2g_dyncf_A_const_pool.A[452]; A_arbace_j2g_dyncf_A_const_216 = A_arbace_j2g_dyncf_A_const_pool.A[453]; A_arbace_j2g_dyncf_A_const_217 = A_arbace_j2g_dyncf_A_const_pool.A[454]; A_arbace_j2g_dyncf_A_const_218 = A_arbace_j2g_dyncf_A_const_pool.A[455]; A_arbace_j2g_dyncf_A_const_219 = A_arbace_j2g_dyncf_A_const_pool.A[456]; A_arbace_j2g_dyncf_A_const_220 = A_arbace_j2g_dyncf_A_const_pool.A[457]; A_arbace_j2g_dyncf_A_const_221 = A_arbace_j2g_dyncf_A_const_pool.A[458]; A_arbace_j2g_dyncf_A_const_222 = A_arbace_j2g_dyncf_A_const_pool.A[459]; A_arbace_j2g_dyncf_A_const_223 = A_arbace_j2g_dyncf_A_const_pool.A[460]; A_arbace_j2g_dyncf_A_const_224 = A_arbace_j2g_dyncf_A_const_pool.A[461]; A_arbace_j2g_dyncf_A_const_225 = A_arbace_j2g_dyncf_A_const_pool.A[462]; A_arbace_j2g_dyncf_A_const_226 = A_arbace_j2g_dyncf_A_const_pool.A[463] }

func A_arbace_j2g_dyncf_A_clinit_p16() { A_arbace_j2g_dyncf_A_const_227 = A_arbace_j2g_dyncf_A_const_pool.A[464]; A_arbace_j2g_dyncf_A_const_228 = A_arbace_j2g_dyncf_A_const_pool.A[465]; A_arbace_j2g_dyncf_A_const_229 = A_arbace_j2g_dyncf_A_const_pool.A[466]; A_arbace_j2g_dyncf_A_const_230 = A_arbace_j2g_dyncf_A_const_pool.A[467]; A_arbace_j2g_dyncf_A_const_231 = A_arbace_j2g_dyncf_A_const_pool.A[468]; A_arbace_j2g_dyncf_A_const_232 = A_arbace_j2g_dyncf_A_const_pool.A[469]; A_arbace_j2g_dyncf_A_const_233 = A_arbace_j2g_dyncf_A_const_pool.A[470]; A_arbace_j2g_dyncf_A_const_234 = A_arbace_j2g_dyncf_A_const_pool.A[471]; A_arbace_j2g_dyncf_A_const_235 = A_arbace_j2g_dyncf_A_const_pool.A[472]; A_arbace_j2g_dyncf_A_const_236 = A_arbace_j2g_dyncf_A_const_pool.A[473]; A_arbace_j2g_dyncf_A_const_237 = A_arbace_j2g_dyncf_A_const_pool.A[474]; A_arbace_j2g_dyncf_A_const_238 = A_arbace_j2g_dyncf_A_const_pool.A[475]; A_arbace_j2g_dyncf_A_const_239 = A_arbace_j2g_dyncf_A_const_pool.A[476]; A_arbace_j2g_dyncf_A_const_240 = A_arbace_j2g_dyncf_A_const_pool.A[477]; A_arbace_j2g_dyncf_A_const_241 = A_arbace_j2g_dyncf_A_const_pool.A[478]; A_arbace_j2g_dyncf_A_const_242 = A_arbace_j2g_dyncf_A_const_pool.A[479] }

func A_arbace_j2g_dyncf_A_clinit_p17() { A_arbace_j2g_dyncf_A_const_243 = A_arbace_j2g_dyncf_A_const_pool.A[480]; A_arbace_j2g_dyncf_A_const_244 = A_arbace_j2g_dyncf_A_const_pool.A[481]; A_arbace_j2g_dyncf_A_const_245 = A_arbace_j2g_dyncf_A_const_pool.A[482]; A_arbace_j2g_dyncf_A_const_246 = A_arbace_j2g_dyncf_A_const_pool.A[483]; A_arbace_j2g_dyncf_A_const_247 = A_arbace_j2g_dyncf_A_const_pool.A[484]; A_arbace_j2g_dyncf_A_const_248 = A_arbace_j2g_dyncf_A_const_pool.A[485]; A_arbace_j2g_dyncf_A_const_249 = A_arbace_j2g_dyncf_A_const_pool.A[486]; A_arbace_j2g_dyncf_A_const_250 = A_arbace_j2g_dyncf_A_const_pool.A[487]; A_arbace_j2g_dyncf_A_const_251 = A_arbace_j2g_dyncf_A_const_pool.A[488]; A_arbace_j2g_dyncf_A_const_252 = A_arbace_j2g_dyncf_A_const_pool.A[489]; A_arbace_j2g_dyncf_A_const_253 = A_arbace_j2g_dyncf_A_const_pool.A[490]; A_arbace_j2g_dyncf_A_const_254 = A_arbace_j2g_dyncf_A_const_pool.A[491]; A_arbace_j2g_dyncf_A_const_255 = A_arbace_j2g_dyncf_A_const_pool.A[492]; A_arbace_j2g_dyncf_A_const_256 = A_arbace_j2g_dyncf_A_const_pool.A[493]; A_arbace_j2g_dyncf_A_const_257 = A_arbace_j2g_dyncf_A_const_pool.A[494]; A_arbace_j2g_dyncf_A_const_258 = A_arbace_j2g_dyncf_A_const_pool.A[495] }

func A_arbace_j2g_dyncf_A_clinit_p18() { A_arbace_j2g_dyncf_A_const_259 = A_arbace_j2g_dyncf_A_const_pool.A[496]; A_arbace_j2g_dyncf_A_const_260 = A_arbace_j2g_dyncf_A_const_pool.A[497]; A_arbace_j2g_dyncf_A_const_261 = A_arbace_j2g_dyncf_A_const_pool.A[498]; A_arbace_j2g_dyncf_A_const_262 = A_arbace_j2g_dyncf_A_const_pool.A[499]; A_arbace_j2g_dyncf_A_const_263 = A_arbace_j2g_dyncf_A_const_pool.A[500]; A_arbace_j2g_dyncf_A_const_264 = A_arbace_j2g_dyncf_A_const_pool.A[501]; A_arbace_j2g_dyncf_A_const_265 = A_arbace_j2g_dyncf_A_const_pool.A[502]; A_arbace_j2g_dyncf_A_const_266 = A_arbace_j2g_dyncf_A_const_pool.A[503]; A_arbace_j2g_dyncf_A_const_267 = A_arbace_j2g_dyncf_A_const_pool.A[504]; A_arbace_j2g_dyncf_A_const_268 = A_arbace_j2g_dyncf_A_const_pool.A[505]; A_arbace_j2g_dyncf_A_const_269 = A_arbace_j2g_dyncf_A_const_pool.A[506]; A_arbace_j2g_dyncf_A_const_270 = A_arbace_j2g_dyncf_A_const_pool.A[507]; A_arbace_j2g_dyncf_A_const_271 = A_arbace_j2g_dyncf_A_const_pool.A[508]; A_arbace_j2g_dyncf_A_const_272 = A_arbace_j2g_dyncf_A_const_pool.A[509]; A_arbace_j2g_dyncf_A_const_273 = A_arbace_j2g_dyncf_A_const_pool.A[510]; A_arbace_j2g_dyncf_A_const_274 = A_arbace_j2g_dyncf_A_const_pool.A[511] }

func A_arbace_j2g_dyncf_A_clinit_p19() { A_arbace_j2g_dyncf_A_const_275 = A_arbace_j2g_dyncf_A_const_pool.A[512]; A_arbace_j2g_dyncf_A_const_276 = A_arbace_j2g_dyncf_A_const_pool.A[513]; A_arbace_j2g_dyncf_A_const_277 = A_arbace_j2g_dyncf_A_const_pool.A[514]; A_arbace_j2g_dyncf_A_const_278 = A_arbace_j2g_dyncf_A_const_pool.A[515]; A_arbace_j2g_dyncf_A_const_279 = A_arbace_j2g_dyncf_A_const_pool.A[516]; A_arbace_j2g_dyncf_A_const_280 = A_arbace_j2g_dyncf_A_const_pool.A[517]; A_arbace_j2g_dyncf_A_const_281 = A_arbace_j2g_dyncf_A_const_pool.A[518]; A_arbace_j2g_dyncf_A_const_282 = A_arbace_j2g_dyncf_A_const_pool.A[519]; A_arbace_j2g_dyncf_A_const_283 = A_arbace_j2g_dyncf_A_const_pool.A[520]; A_arbace_j2g_dyncf_A_const_284 = A_arbace_j2g_dyncf_A_const_pool.A[521]; A_arbace_j2g_dyncf_A_const_285 = A_arbace_j2g_dyncf_A_const_pool.A[522]; A_arbace_j2g_dyncf_A_const_286 = A_arbace_j2g_dyncf_A_const_pool.A[523]; A_arbace_j2g_dyncf_A_const_287 = A_arbace_j2g_dyncf_A_const_pool.A[524]; A_arbace_j2g_dyncf_A_const_288 = A_arbace_j2g_dyncf_A_const_pool.A[525]; A_arbace_j2g_dyncf_A_const_289 = A_arbace_j2g_dyncf_A_const_pool.A[526]; A_arbace_j2g_dyncf_A_const_290 = A_arbace_j2g_dyncf_A_const_pool.A[527] }

func A_arbace_j2g_dyncf_A_clinit_p20() { A_arbace_j2g_dyncf_A_const_291 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[528]); A_arbace_j2g_dyncf_A_const_292 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[529]); A_arbace_j2g_dyncf_A_const_293 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[530]); A_arbace_j2g_dyncf_A_const_294 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[531]); A_arbace_j2g_dyncf_A_const_295 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[532]); A_arbace_j2g_dyncf_A_const_296 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[533]); A_arbace_j2g_dyncf_A_const_297 = A_arbace_j2g_dyncf_A_const_pool.A[534]; A_arbace_j2g_dyncf_A_const_298 = A_arbace_j2g_dyncf_A_const_pool.A[535]; A_arbace_j2g_dyncf_A_const_299 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[536]); A_arbace_j2g_dyncf_A_const_300 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[537]); A_arbace_j2g_dyncf_A_const_301 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[538]); A_arbace_j2g_dyncf_A_const_302 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[539]) }

func A_arbace_j2g_dyncf_A_clinit_p21() { A_arbace_j2g_dyncf_A_const_303 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[540]); A_arbace_j2g_dyncf_A_const_304 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[541]); A_arbace_j2g_dyncf_A_const_305 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[542]); A_arbace_j2g_dyncf_A_const_306 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[543]); A_arbace_j2g_dyncf_A_const_307 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[544]); A_arbace_j2g_dyncf_A_const_308 = A_arbace_j2g_dyncf_A_const_pool.A[545]; A_arbace_j2g_dyncf_A_const_309 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[546]); A_arbace_j2g_dyncf_A_const_310 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[547]); A_arbace_j2g_dyncf_A_const_311 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[548]); A_arbace_j2g_dyncf_A_const_312 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[549]); A_arbace_j2g_dyncf_A_const_313 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[550]); A_arbace_j2g_dyncf_A_const_314 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[551]) }

func A_arbace_j2g_dyncf_A_clinit_p22() { A_arbace_j2g_dyncf_A_const_315 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[552]); A_arbace_j2g_dyncf_A_const_316 = A_arbace_j2g_dyncf_A_const_pool.A[553]; A_arbace_j2g_dyncf_A_const_317 = A_arbace_j2g_dyncf_A_const_pool.A[554]; A_arbace_j2g_dyncf_A_const_318 = A_arbace_j2g_dyncf_A_const_pool.A[555]; A_arbace_j2g_dyncf_A_const_319 = A_arbace_j2g_dyncf_A_const_pool.A[556]; A_arbace_j2g_dyncf_A_const_320 = A_arbace_j2g_dyncf_A_const_pool.A[557]; A_arbace_j2g_dyncf_A_const_321 = A_arbace_j2g_dyncf_A_const_pool.A[558]; A_arbace_j2g_dyncf_A_const_322 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[559]); A_arbace_j2g_dyncf_A_const_323 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[560]); A_arbace_j2g_dyncf_A_const_324 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[561]); A_arbace_j2g_dyncf_A_const_325 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[562]); A_arbace_j2g_dyncf_A_const_326 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[563]); A_arbace_j2g_dyncf_A_const_327 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[564]) }

func A_arbace_j2g_dyncf_A_clinit_p23() { A_arbace_j2g_dyncf_A_const_328 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[565]); A_arbace_j2g_dyncf_A_const_329 = A_arbace_j2g_dyncf_A_const_pool.A[566]; A_arbace_j2g_dyncf_A_const_330 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[567]); A_arbace_j2g_dyncf_A_const_331 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[568]); A_arbace_j2g_dyncf_A_const_332 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[569]); A_arbace_j2g_dyncf_A_const_333 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[570]); A_arbace_j2g_dyncf_A_const_334 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[571]); A_arbace_j2g_dyncf_A_const_335 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[572]); A_arbace_j2g_dyncf_A_const_336 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[573]); A_arbace_j2g_dyncf_A_const_337 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[574]); A_arbace_j2g_dyncf_A_const_338 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[575]); A_arbace_j2g_dyncf_A_const_339 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[576]) }

func A_arbace_j2g_dyncf_A_clinit_p24() { A_arbace_j2g_dyncf_A_const_340 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[577]) }

func A_arbace_j2g_dyncf_A_New() *A_arbace_j2g_dyncf_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_A_class }

func (t *A_arbace_j2g_dyncf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_A); return ok }

func A_arbace_j2g_dyncf_A_Cast(x any) *A_arbace_j2g_dyncf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_A_class)) }; return v }



type A_arbace_j2g_dyncf_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000004_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000004_A_New() *A_arbace_j2g_dyncf_eval292000004_A { t := &A_arbace_j2g_dyncf_eval292000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000004_A_class }

func (t *A_arbace_j2g_dyncf_eval292000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); return ok }

func A_arbace_j2g_dyncf_eval292000004_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000004_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000008_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000008_A_New() *A_arbace_j2g_dyncf_eval292000008_A { t := &A_arbace_j2g_dyncf_eval292000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000008_A_class }

func (t *A_arbace_j2g_dyncf_eval292000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); return ok }

func A_arbace_j2g_dyncf_eval292000008_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000008_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000008_fn__292000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_from_object_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_from_object_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A struct{ j2g_header uint64; F_extendable any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A struct{ j2g_header uint64; F_iter__292000093, F_s__292000094, F_extendable any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A struct{ j2g_header uint64; F_b__292000096, F_extendable any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A struct{ j2g_header uint64; F_iter__292000103, F_s__292000104 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A struct{ j2g_header uint64; F_b__292000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A struct{ j2g_header uint64; F_iter__292000113, F_s__292000114 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A struct{ j2g_header uint64; F_b__292000116 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A struct{ j2g_header uint64; F_iter__292000127, F_s__292000128 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A struct{ j2g_header uint64; F_b__292000130 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A struct{ j2g_header uint64; F_iter__292000137, F_s__292000138 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A struct{ j2g_header uint64; F_b__292000140 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A struct{ j2g_header uint64; F_s__292000150, F_iter__292000149 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A struct{ j2g_header uint64; F_b__292000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A struct{ j2g_header uint64; F_iter__292000156, F_s__292000157 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A struct{ j2g_header uint64; F_b__292000159 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000162_fn__292000163_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_iter__292000156__292000160_fn__292000161_fn__292000166_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A struct{ j2g_header uint64; F_iter__292000171, F_s__292000172 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A struct{ j2g_header uint64; F_b__292000174 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000177_fn__292000178_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_iter__292000171__292000175_fn__292000176_fn__292000181_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A struct{ j2g_header uint64; F_tset any }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A struct{ j2g_header uint64; F_tset, F_iter__292000187, F_s__292000188 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A struct{ j2g_header uint64; F_tset, F_b__292000190 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A struct{ j2g_header uint64; F_iter__292000197, F_s__292000198 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A struct{ j2g_header uint64; F_b__292000200 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_fn__292000193_iter__292000197__292000201_fn__292000202_fn__292000203_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A struct{ j2g_header uint64; F_iter__292000211, F_s__292000212 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A struct{ j2g_header uint64; F_b__292000214 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000187__292000191_fn__292000192_iter__292000211__292000215_fn__292000216_fn__292000217_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A struct{ j2g_header uint64; F_iter__292000223, F_s__292000224 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A struct{ j2g_header uint64; F_b__292000226 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000223__292000227_fn__292000228_fn__292000229_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A struct{ j2g_header uint64; F_s__292000240, F_iter__292000239 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A struct{ j2g_header uint64; F_b__292000242 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000239__292000243_fn__292000244_fn__292000245_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_fn__292000090_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000017, F_s__292000018 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A struct{ j2g_header uint64; F_b__292000020, F_recv, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000043, F_s__292000044 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A struct{ j2g_header uint64; F_recv, F_b__292000046, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A struct{ j2g_header uint64; F_iter__292000078, F_s__292000079 any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A struct{ j2g_header uint64; F_b__292000081 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_tag_A_fn_class *jrt.Class
