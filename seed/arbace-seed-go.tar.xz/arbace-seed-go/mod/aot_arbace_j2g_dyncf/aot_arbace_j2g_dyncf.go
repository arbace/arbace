//line aot_arbace_j2g_dyncf.ae:1
package aot_arbace_j2g_dyncf

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_code"
	"arbace/aot_arbace_j2g_dyn"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/aot_arbace_walk"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_New() *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyncf_A_const_13); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_1, A_arbace_j2g_dyncf_A_const_2, A_arbace_j2g_dyncf_A_const_3, A_arbace_j2g_dyncf_A_const_4, A_arbace_j2g_dyncf_A_const_5, A_arbace_j2g_dyncf_A_const_6, A_arbace_j2g_dyncf_A_const_7, A_arbace_j2g_dyncf_A_const_8, A_arbace_j2g_dyncf_A_const_9, A_arbace_j2g_dyncf_A_const_10, A_arbace_j2g_dyncf_A_const_11); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_New() *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000008_fn__292000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_14.GetRawRoot__O()); var tmp2 any; var root_25 any = A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_j2g_dyncf_A_const_16; if linked_26 == nil { tmp2 = ifn_27.Invoke_O__O(arg_28) } else { tmp2 = linked_26.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_25, arg_28) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(), A_arbace_j2g_dyncf_A_const_18) }





















func A_arbace_j2g_dyncf_enabled_QMARK__A_New() *A_arbace_j2g_dyncf_enabled_QMARK__A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_enabled_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_29 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_j2g_dyncf_A_const_20.GetRawRoot__O(); if linked_30 == nil { return ifn_31.Invoke_O__O(arg_32) } else { return linked_30.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_29, arg_32)
	} }
func A_arbace_j2g_dyncf_tag_A_New() *A_arbace_j2g_dyncf_tag_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_tag_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_j2g_dyncf_tag_A) Ctor() {}
//line :28:1
func (t *A_arbace_j2g_dyncf_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_33 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = sym__0; var arg_37 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyncf_A_const_22, type__1)); if linked_34 == nil { return ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { return linked_34.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) } }

func A_arbace_j2g_dyncf_native_name_A_New() *A_arbace_j2g_dyncf_native_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_native_name_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_j2g_dyncf_native_name_A) Ctor() {}
//line :30:1
func (t *A_arbace_j2g_dyncf_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var root_38 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_95, nil, Lit_96); var tmp2 any; var root_42 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_j2g_dyncf_A_const_20.GetRawRoot__O(); if linked_43 == nil { tmp2 = ifn_44.Invoke_O__O(arg_45) } else { tmp2 = linked_43.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_42, arg_45) }; var tmp3 any = tmp2; var tmp4 any; var root_46 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = mname__0; var arg_50 any = desc__1; if linked_47 == nil { tmp4 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { tmp4 = linked_47.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; arg_41 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref(); if linked_39 == nil { return ifn_40.Invoke_O__O(arg_41) } else { return linked_39.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_38, arg_41)
	}
}









func A_arbace_j2g_dyncf_sub_name_A_New() *A_arbace_j2g_dyncf_sub_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_name_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Ctor() {}
//line :43:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_152, nil); var tmp2 any; var root_51 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = n__0; if linked_52 == nil { tmp2 = ifn_53.Invoke_O__O(arg_54) } else { tmp2 = linked_52.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_51, arg_54) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyncf_from_object_A_New() *A_arbace_j2g_dyncf_from_object_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_from_object_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_j2g_dyncf_from_object_A) Ctor() {}
//line :45:1
func (t *A_arbace_j2g_dyncf_from_object_A) Invoke_O_O_O__O(self, d__0, x__1 any) any {


	var tmp1 any; var root_55 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = d__0; if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_55, arg_58) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_29; var tmp4 any; var root_59 any = A_arbace_j2g_dyncf_A_const_30.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_j2g_dyncf_A_const_31; var arg_63 any = d__0; if linked_60 == nil { tmp4 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { tmp4 = linked_60.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_32; var tmp8 any; var root_64 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_66 lang.IFn
		if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_33.GetRawRoot__O()).Invoke_O__O(d__0))).Ref(); if linked_65 == nil { tmp8 = ifn_66.Invoke_O__O(arg_67) } else { tmp8 = linked_65.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_64, arg_67) }
//line :48:1
		return tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O__O(tmp7, tmp8, x__1)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_31) { return x__1 } else { if A_arbace_j2g_dyncf_A_const_28 != nil {


			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_34; var tmp12 any = A_arbace_j2g_dyncf_A_const_35; var tmp13 any; var root_68 any = A_arbace_j2g_dyncf_A_const_30.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_j2g_dyncf_A_const_31; var arg_72 any = d__0; if linked_69 == nil { tmp13 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { tmp13 = linked_69.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; return tmp9.Invoke_O_O__O(tmp10.Invoke_O_O_O__O(tmp11, tmp12, tmp13), x__1) } else {
//line :48:1
				return nil
			}
		}
		}
}
func A_arbace_j2g_dyncf_sub_forms_A_New() *A_arbace_j2g_dyncf_sub_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Ctor() {}
//line :53:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_73 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_75 lang.IFn; if


	linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = n__0; if linked_74 == nil { g__2 = ifn_75.Invoke_O__O(arg_76) } else { g__2 = linked_74.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_73, arg_76) }; var recv__3 any; var tmp1 lang.IFn = /*line :53:1*/lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_38; var tmp3 any; var root_80 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_82 lang.IFn; if



	linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = g__2; if linked_81 == nil { tmp3 = ifn_82.Invoke_O__O(arg_83) } else { tmp3 = linked_81.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_80, arg_83) }; recv__3 = tmp1.Invoke_O_O__O(tmp2, tmp3); var root_84 any =
	A_arbace_j2g_dyncf_A_const_39.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_41, A_arbace_j2g_dyncf_A_const_42); if linked_85 == nil { ifn_86.Invoke_O__O(arg_87) } else { linked_85.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_84, arg_87) }; var tmp4 any; tmp57 := /*line :53:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyncf_A_const_43; var tmp7 any; var root_93 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_95 lang.IFn





		if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_128, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_94 == nil { tmp7 = ifn_95.Invoke_O__O(arg_96) } else { tmp7 = linked_94.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_93, arg_96) }
//line :53:1
		var tmp8 any = tmp7; var tmp9 any; var root_97 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_99 lang.IFn





		if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var tmp10 any; var root_102 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = A_arbace_j2g_dyncf_A_const_45; var arg_106 any = A_arbace_j2g_dyncf_A_const_46; if linked_103 == nil { tmp10 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { tmp10 = linked_103.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }; var tmp11 any = tmp10; var tmp12 any; var root_107 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_j2g_dyncf_A_const_47; var arg_111 any = A_arbace_j2g_dyncf_A_const_48; if linked_108 == nil { tmp12 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { tmp12 = linked_108.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }; arg_100 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12); var arg_101 any = A_arbace_j2g_dyncf_A_const_49; if linked_98 == nil { tmp9 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { tmp9 = linked_98.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }
//line :53:1
		var tmp13 any = tmp9; var tmp14 any; var tmp15 any; var or__1927000174__auto____6 any; var root_112 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_114 lang.IFn






		if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = n__0; if linked_113 == nil { or__1927000174__auto____6 = ifn_114.Invoke_O__O(arg_115) } else { or__1927000174__auto____6 = linked_113.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp15 = or__1927000174__auto____6 } else { var root_116 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = n__0; if linked_117 == nil { tmp15 = ifn_118.Invoke_O__O(arg_119) } else { tmp15 = linked_117.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_116, arg_119) } }; if jrt.J2g_Truth(tmp15) { tmp14 = A_arbace_j2g_dyncf_A_const_52 } else {

			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp17 any; var root_120 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = A_arbace_j2g_dyncf_A_const_31; var arg_124 any = n__0; var arg_125 any = Lit_129; if linked_121 == nil { tmp17 = ifn_122.Invoke_O_O_O__O(arg_123, arg_124, arg_125) } else { tmp17 = linked_121.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_120, arg_123, arg_124, arg_125) }; tmp14 = tmp16.Invoke_O__O(tmp17) }
//line :53:1
		var tmp18 any = tmp14; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyncf_A_const_54; var tmp21 any = A_arbace_j2g_dyncf_A_const_58; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_59; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyncf_A_const_60; var tmp26 any; var root_126 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_128 lang.IFn









		if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = g__2; if linked_127 == nil { tmp26 = ifn_128.Invoke_O__O(arg_129) } else { tmp26 = linked_127.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_126, arg_129) }
//line :53:1
		var tmp27 any = tmp5.Invoke_O_O_O_O_O__O(tmp6, tmp8, tmp13, tmp18, tmp19.Invoke_O_O_O_O_O__O(tmp20, lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp22.Invoke_O_O__O(tmp23, tmp24.Invoke_O_O_O_O__O(tmp25, tmp26, A_arbace_j2g_dyncf_A_const_61, A_arbace_j2g_dyncf_A_const_62))), A_arbace_j2g_dyncf_A_const_55, A_arbace_j2g_dyncf_A_const_56, A_arbace_j2g_dyncf_A_const_57)); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyncf_A_const_63; var tmp30 any; var root_130 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_132 lang.IFn














		if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var root_135 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_130, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_136 == nil { arg_133 = ifn_137.Invoke_O__O(arg_138) } else { arg_133 = linked_136.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_135, arg_138) }; var arg_134 any = A_arbace_j2g_dyncf_A_const_64; if linked_131 == nil { tmp30 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { tmp30 = linked_131.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }
//line :53:1
		var tmp31 any = tmp30; var tmp32 any; var root_139 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_141 lang.IFn















		if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_143 any = A_arbace_j2g_dyncf_A_const_66; var arg_144 any = A_arbace_j2g_dyncf_A_const_67; var arg_145 any; var iter__1927001039__auto____6 any; var fnbody__421 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(recv__3, n__0); var tmp33 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class
		if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, fnbody__421); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class = fncls__420d; tmp33 = fncls__420d } else { tmp33 = fncls__420 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__421, tmp33, nil); var tmp34 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp35 any; var tmp36 any; var root_422 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = n__0; if linked_423 == nil { tmp36 = ifn_424.Invoke_O__O(arg_425) } else { tmp36 = linked_423.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(tmp36) { var root_426 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = n__0; if linked_427 == nil { tmp35 = ifn_428.Invoke_O__O(arg_429) } else { tmp35 = linked_427.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_426, arg_429) } } else { var tmp37 *lang.Keyword = A_arbace_j2g_dyncf_A_const_108; var tmp38 any; var root_430 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = n__0; if linked_431 == nil { tmp38 = ifn_432.Invoke_O__O(arg_433) } else { tmp38 = linked_431.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_430, arg_433) }; tmp35 = tmp37.Invoke_O__O(tmp38) }; arg_145 = tmp34.Invoke_O__O(tmp35)
//line :69:1
		if linked_140 == nil { tmp32 = ifn_141.Invoke_O_O_O_O__O(arg_142, arg_143, arg_144, arg_145) } else { tmp32 = linked_140.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_139, arg_142, arg_143, arg_144, arg_145) }
//line :53:1
		var tmp39 any = tmp28.Invoke_O_O_O__O(tmp29, tmp31, tmp32); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_dyncf_A_const_110; var tmp42 any; var root_434 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_436 lang.IFn






























		if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var root_439 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_132, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_440 == nil { arg_437 = ifn_441.Invoke_O__O(arg_442) } else { arg_437 = linked_440.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_439, arg_442) }; var arg_438 any = A_arbace_j2g_dyncf_A_const_111; if linked_435 == nil { tmp42 = ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { tmp42 = linked_435.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) }
//line :53:1
		var tmp43 any = tmp42; var tmp44 any; var root_443 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_445 lang.IFn































		if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_447 any = A_arbace_j2g_dyncf_A_const_112; var arg_448 any = A_arbace_j2g_dyncf_A_const_113; var arg_449 any; var iter__1927001039__auto____6_2 any; var fnbody__723 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(recv__3, n__0); var tmp45 *jrt.Class; var fncls__722 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class
		if fncls__722 == nil { var fncls__722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, fnbody__723); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class = fncls__722d; tmp45 = fncls__722d } else { tmp45 = fncls__722 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__723, tmp45, nil); var tmp46 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6_2); var tmp47 any; var root_724 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var arg_728 any; var root_729 any = A_arbace_j2g_dyncf_A_const_145.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = n__0; if linked_730 == nil { arg_728 = ifn_731.Invoke_O__O(arg_732) } else { arg_728 = linked_730.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_729, arg_732) }; if linked_725 == nil { tmp47 = ifn_726.Invoke_O_O__O(arg_727, arg_728) } else { tmp47 = linked_725.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_724, arg_727, arg_728) }; arg_449 = tmp46.Invoke_O__O(tmp47)
//line :85:1
		if linked_444 == nil { tmp44 = ifn_445.Invoke_O_O_O_O__O(arg_446, arg_447, arg_448, arg_449) } else { tmp44 = linked_444.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_443, arg_446, arg_447, arg_448, arg_449) }
//line :53:1
		var tmp48 any = tmp40.Invoke_O_O_O__O(tmp41, tmp43, tmp44); var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp50 any = A_arbace_j2g_dyncf_A_const_146; var tmp51 any; var root_733 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_735 lang.IFn



















































		if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any; var root_738 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_134, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_739 == nil { arg_736 = ifn_740.Invoke_O__O(arg_741) } else { arg_736 = linked_739.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_738, arg_741) }; var arg_737 any = A_arbace_j2g_dyncf_A_const_147; if linked_734 == nil { tmp51 = ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { tmp51 = linked_734.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_733, arg_736, arg_737) }
//line :53:1
		var tmp52 any = tmp51; var tmp53 any; var root_742 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_744 lang.IFn




















































		if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_746 any = A_arbace_j2g_dyncf_A_const_148; var arg_747 any = A_arbace_j2g_dyncf_A_const_149; var arg_748 any; var seen__6 any; var root_749 any = A_arbace_j2g_dyncf_A_const_150.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_751 lang.IFn
		if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_750 == nil { seen__6 = ifn_751.Invoke_O__O(arg_752) } else { seen__6 = linked_750.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_749, arg_752) }
		var root_753 any = A_arbace_j2g_dyncf_A_const_151.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any; var iter__1927001039__auto____7 any; var fnbody__1055 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_New_O_O(recv__3, seen__6); var tmp54 *jrt.Class; var fncls__1054 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_fn_class
		if fncls__1054 == nil { var fncls__1054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__1055); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_fn_class = fncls__1054d; tmp54 = fncls__1054d } else { tmp54 = fncls__1054 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1055, tmp54, nil); var tmp55 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp56 any; var root_1056 any = A_arbace_j2g_dyncf_A_const_192.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = n__0; if linked_1057 == nil { tmp56 = ifn_1058.Invoke_O__O(arg_1059) } else { tmp56 = linked_1057.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1056, arg_1059) }; arg_756 = tmp55.Invoke_O__O(tmp56)
//line :108:1
		if linked_754 == nil { arg_748 = ifn_755.Invoke_O__O(arg_756) } else { arg_748 = linked_754.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_753, arg_756) }
//line :106:1
		if linked_743 == nil { tmp53 = ifn_744.Invoke_O_O_O_O__O(arg_745, arg_746, arg_747, arg_748) } else { tmp53 = linked_743.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_742, arg_745, arg_746, arg_747, arg_748) }
//line :53:1
		tmp4 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp27, tmp39, tmp48, tmp49.Invoke_O_O_O__O(tmp50, tmp52, tmp53)) }; return nil }(); var root_77 any = A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_79 lang.IFn; if




	linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; if linked_78 == nil { ifn_79.Invoke__O() } else { linked_78.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_77) }; if /*line :53:1*/ tmp57 != nil { panic(tmp57) }; return tmp4 }
















func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Invoke_O_O__O(self, s__292000018__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__419 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000018__1); var tmp2 *jrt.Class; var fncls__418 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class; if fncls__418 == nil { var fncls__418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, fnbody__419); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class = fncls__418d; tmp2 = fncls__418d } else { tmp2 = fncls__418 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__419, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :70:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000017, c__s__292000018 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000017 = c__iter__292000017; t.F_s__292000018 = c__s__292000018 }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Invoke_O__O(self any) any { { var s__292000018__1 any; var t_ any = t.F_s__292000018; t.F_s__292000018 = nil; s__292000018__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_146 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = s__292000018__1; if linked_147 == nil { temp__1927000414__auto____2 = ifn_148.Invoke_O__O(arg_149) } else { temp__1927000414__auto____2 = linked_147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_146, arg_149) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000018__3 any = temp__1927000414__auto____2; var tmp1 any; var root_150 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = s__292000018__3; if linked_151 == nil { tmp1 = ifn_152.Invoke_O__O(arg_153) } else { tmp1 = linked_151.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_150, arg_153) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_154 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__292000018__3; if linked_155 == nil { c__1927001037__auto____4 = ifn_156.Invoke_O__O(arg_157) } else { c__1927001037__auto____4 = linked_155.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_154, arg_157) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000020__6 any; var root_158 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_159 == nil { b__292000020__6 = ifn_160.Invoke_O__O(arg_161) } else { b__292000020__6 = linked_159.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_158, arg_161) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__269 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(b__292000020__6, t.F_recv, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__268 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class; if fncls__268 == nil { var fncls__268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, fnbody__269); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class = fncls__268d; tmp3 = fncls__268d } else { tmp3 = fncls__268 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__269, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_270 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any; var root_275 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = b__292000020__6; if linked_276 == nil { arg_273 = ifn_277.Invoke_O__O(arg_278) } else { arg_273 = linked_276.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_275, arg_278) }; var arg_274 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp5 any; var root_279 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = s__292000018__3; if linked_280 == nil { tmp5 = ifn_281.Invoke_O__O(arg_282) } else { tmp5 = linked_280.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_279, arg_282) }; arg_274 = tmp4.Invoke_O__O(tmp5); if linked_271 == nil { return ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { return linked_271.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) } } else { var root_283 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any; var root_288 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = b__292000020__6; if linked_289 == nil { arg_286 = ifn_290.Invoke_O__O(arg_291) } else { arg_286 = linked_289.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_288, arg_291) }; var arg_287 any; if linked_284 == nil { return ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { return linked_284.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_283, arg_286, arg_287) } } } else { var mm__4 any; var root_292 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = s__292000018__3; if linked_293 == nil { mm__4 = ifn_294.Invoke_O__O(arg_295) } else { mm__4 = linked_293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_292, arg_295) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_296 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any; var root_300 any = A_arbace_j2g_dyncf_A_const_74.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = mm__4; if linked_301 == nil { arg_299 = ifn_302.Invoke_O__O(arg_303) } else { arg_299 = linked_301.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_300, arg_303) }; if linked_297 == nil { and__1927000168__auto____6 = ifn_298.Invoke_O__O(arg_299) } else { and__1927000168__auto____6 = linked_297.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_296, arg_299) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_304 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_305 == nil { tmp6 = ifn_306.Invoke_O__O(arg_307) } else { tmp6 = linked_305.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_304, arg_307) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :70:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_308 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_310 lang.IFn

		if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any; var root_312 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = t.F_n; if linked_313 == nil { arg_311 = ifn_314.Invoke_O__O(arg_315) } else { arg_311 = linked_313.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_312, arg_315) }; if linked_309 == nil { or__1927000174__auto____5 = ifn_310.Invoke_O__O(arg_311) } else { or__1927000174__auto____5 = linked_309.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_316 any = A_arbace_j2g_dyncf_A_const_77.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any; var root_321 any = A_arbace_j2g_dyncf_A_const_78.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyncf_A_const_79; var arg_324 any = tmp8.Invoke_O__O(A_arbace_j2g_dyncf_A_const_80.Get__O()); var arg_325 any; var root_326 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = t.F_n; if linked_327 == nil { arg_325 = ifn_328.Invoke_O__O(arg_329) } else { arg_325 = linked_327.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_326, arg_329) }; if linked_322 == nil { arg_319 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { arg_319 = linked_322.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_321, arg_324, arg_325) }; var arg_320 any; var root_330 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_331 == nil { arg_320 = ifn_332.Invoke_O__O(arg_333) } else { arg_320 = linked_331.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_330, arg_333) }; if linked_317 == nil { tmp7 = ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { tmp7 = linked_317.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_316, arg_319, arg_320) } }
//line :70:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_334 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_336 lang.IFn



			if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = t.F_n; if linked_335 == nil { tmp9 = ifn_336.Invoke_O__O(arg_337) } else { tmp9 = linked_335.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4) } else { var root_338 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = t.F_n; var arg_342 any = mm__4; if linked_339 == nil { real__5 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { real__5 = linked_339.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) } }
//line :70:1
			var vec__292000033__6 any; var root_343 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_345 lang.IFn




			if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_344 == nil { vec__292000033__6 = ifn_345.Invoke_O__O(arg_346) } else { vec__292000033__6 = linked_344.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_343, arg_346) }
//line :70:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000036__9 any; var root_347 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_349 lang.IFn; _ = ___8





			if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = real__5; if linked_348 == nil { vec__292000036__9 = ifn_349.Invoke_O__O(arg_350) } else { vec__292000036__9 = linked_348.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_347, arg_350) }
//line :70:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_351 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any; var tmp10 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyncf_A_const_85; var tmp13 any; var root_356 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_358 lang.IFn








				if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = A_arbace_j2g_dyncf_A_const_86; var arg_360 any = A_arbace_j2g_dyncf_A_const_87; if linked_357 == nil { tmp13 = ifn_358.Invoke_O_O__O(arg_359, arg_360) } else { tmp13 = linked_357.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_356, arg_359, arg_360) }
//line :70:1
				var tmp14 any = tmp13; var tmp15 any; var root_361 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_363 lang.IFn








				if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = A_arbace_j2g_dyncf_A_const_88; var arg_365 any = A_arbace_j2g_dyncf_A_const_105; if linked_362 == nil { tmp15 = ifn_363.Invoke_O_O__O(arg_364, arg_365) } else { tmp15 = linked_362.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_361, arg_364, arg_365) }
//line :70:1
				var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyncf_A_const_90; var tmp19 any = A_arbace_j2g_dyncf_A_const_97; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_98, t.F_recv, A_arbace_j2g_dyncf_A_const_99)); var tmp21 any; var root_366 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_368 lang.IFn










				if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_370 any; var root_374 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil); var tmp23 any; var root_378 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = real__5; if linked_379 == nil { tmp23 = ifn_380.Invoke_O__O(arg_381) } else { tmp23 = linked_379.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_378, arg_381) }; arg_377 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_375 == nil { arg_370 = ifn_376.Invoke_O__O(arg_377) } else { arg_370 = linked_375.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_374, arg_377) }; var arg_371 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp25 any; var root_382 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_384 lang.IFn
				if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any; var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp27 any; var root_386 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = t.F_n; if linked_387 == nil { tmp27 = ifn_388.Invoke_O__O(arg_389) } else { tmp27 = linked_387.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_386, arg_389) }; arg_385 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp27)).Ref(); if linked_383 == nil { tmp25 = ifn_384.Invoke_O__O(arg_385) } else { tmp25 = linked_383.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_382, arg_385) }; arg_371 = tmp24.Invoke_O_O__O(tmp25, A_arbace_j2g_dyncf_A_const_91)
//line :81:1
				var arg_372 any = A_arbace_j2g_dyncf_A_const_92; var arg_373 any; var root_390 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_392 lang.IFn

				if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any; var fnbody__401 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New(); var tmp28 *jrt.Class; var fncls__400 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class; if fncls__400 == nil { var fncls__400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, nil); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class = fncls__400d; tmp28 = fncls__400d } else { tmp28 = fncls__400 }; arg_393 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__401, tmp28, nil); var arg_394 any = ps__7; if linked_391 == nil { arg_373 = ifn_392.Invoke_O_O__O(arg_393, arg_394) } else { arg_373 = linked_391.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_390, arg_393, arg_394) }
//line :81:1
				if linked_367 == nil { tmp21 = ifn_368.Invoke_O_O_O_O_O__O(arg_369, arg_370, arg_371, arg_372, arg_373) } else { tmp21 = linked_367.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_366, arg_369, arg_370, arg_371, arg_372, arg_373) }
//line :70:1
				arg_354 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp20, tmp21))); var arg_355 any; var tmp29 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp30 any; var root_402 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = s__292000018__3; if linked_403 == nil { tmp30 = ifn_404.Invoke_O__O(arg_405) } else { tmp30 = linked_403.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_402, arg_405) }; arg_355 = tmp29.Invoke_O__O(tmp30); if linked_352 == nil { return ifn_353.Invoke_O_O__O(arg_354, arg_355) } else { return linked_352.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_351, arg_354, arg_355) } } else { var tmp31 any; var root_406 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = s__292000018__3; if linked_407 == nil { tmp31 = ifn_408.Invoke_O__O(arg_409) } else { tmp31 = linked_407.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_406, arg_409) }; s__292000018__1 = tmp31; continue L1 } } else { var tmp32 any; var root_410 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = s__292000018__3; if linked_411 == nil { tmp32 = ifn_412.Invoke_O__O(arg_413) } else { tmp32 = linked_411.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_410, arg_413) }; s__292000018__1 = tmp32; continue L1 } } else { var tmp33 any; var root_414 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = s__292000018__3; if linked_415 == nil { tmp33 = ifn_416.Invoke_O__O(arg_417) } else { tmp33 = linked_415.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_414, arg_417) }; s__292000018__1 = tmp33; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :70:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Ctor_O_O_O_I_O(c__b__292000020, c__recv, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000020 = c__b__292000020; t.F_recv = c__recv; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :70:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Invoke_O__O(self any) any { { var i__292000019__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000019__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000019__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_162 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any; var root_166 any = A_arbace_j2g_dyncf_A_const_74.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = mm__2; if linked_167 == nil { arg_165 = ifn_168.Invoke_O__O(arg_169) } else { arg_165 = linked_167.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if linked_163 == nil { and__1927000168__auto____4 = ifn_164.Invoke_O__O(arg_165) } else { and__1927000168__auto____4 = linked_163.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_170 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_171 == nil { tmp2 = ifn_172.Invoke_O__O(arg_173) } else { tmp2 = linked_171.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_170, arg_173) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :70:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_174 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_176 lang.IFn

		if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any; var root_178 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = t.F_n; if linked_179 == nil { arg_177 = ifn_180.Invoke_O__O(arg_181) } else { arg_177 = linked_179.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_178, arg_181) }; if linked_175 == nil { or__1927000174__auto____3 = ifn_176.Invoke_O__O(arg_177) } else { or__1927000174__auto____3 = linked_175.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_174, arg_177) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_182 any = A_arbace_j2g_dyncf_A_const_77.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var root_187 any = A_arbace_j2g_dyncf_A_const_78.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyncf_A_const_79; var arg_190 any = tmp4.Invoke_O__O(A_arbace_j2g_dyncf_A_const_80.Get__O()); var arg_191 any; var root_192 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = t.F_n; if linked_193 == nil { arg_191 = ifn_194.Invoke_O__O(arg_195) } else { arg_191 = linked_193.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_192, arg_195) }; if linked_188 == nil { arg_185 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { arg_185 = linked_188.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; var arg_186 any; var root_196 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_197 == nil { arg_186 = ifn_198.Invoke_O__O(arg_199) } else { arg_186 = linked_197.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_196, arg_199) }; if linked_183 == nil { tmp3 = ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { tmp3 = linked_183.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_182, arg_185, arg_186) } }
//line :70:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_200 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_202 lang.IFn



			if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = t.F_n; if linked_201 == nil { tmp5 = ifn_202.Invoke_O__O(arg_203) } else { tmp5 = linked_201.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2) } else { var root_204 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = t.F_n; var arg_208 any = mm__2; if linked_205 == nil { real__3 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { real__3 = linked_205.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } }
//line :70:1
			var vec__292000024__4 any; var root_209 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_211 lang.IFn




			if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_210 == nil { vec__292000024__4 = ifn_211.Invoke_O__O(arg_212) } else { vec__292000024__4 = linked_210.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_209, arg_212) }
//line :70:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000027__7 any; var root_213 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_215 lang.IFn; _ = ___6





			if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = real__3; if linked_214 == nil { vec__292000027__7 = ifn_215.Invoke_O__O(arg_216) } else { vec__292000027__7 = linked_214.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_213, arg_216) }
//line :70:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_217 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = t.F_b__292000020; var arg_221 any; var tmp6 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyncf_A_const_85; var tmp9 any; var root_222 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_224 lang.IFn








				if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = A_arbace_j2g_dyncf_A_const_86; var arg_226 any = A_arbace_j2g_dyncf_A_const_87; if linked_223 == nil { tmp9 = ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { tmp9 = linked_223.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) }
//line :70:1
				var tmp10 any = tmp9; var tmp11 any; var root_227 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_229 lang.IFn








				if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = A_arbace_j2g_dyncf_A_const_88; var arg_231 any = A_arbace_j2g_dyncf_A_const_89; if linked_228 == nil { tmp11 = ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { tmp11 = linked_228.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) }
//line :70:1
				var tmp12 any = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyncf_A_const_90; var tmp15 any = A_arbace_j2g_dyncf_A_const_97; var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_98, t.F_recv, A_arbace_j2g_dyncf_A_const_99)); var tmp17 any; var root_232 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_234 lang.IFn










				if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_236 any; var root_240 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil); var tmp19 any; var root_244 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = real__3; if linked_245 == nil { tmp19 = ifn_246.Invoke_O__O(arg_247) } else { tmp19 = linked_245.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_244, arg_247) }; arg_243 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19)).Ref(); if linked_241 == nil { arg_236 = ifn_242.Invoke_O__O(arg_243) } else { arg_236 = linked_241.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_240, arg_243) }; var arg_237 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp21 any; var root_248 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_250 lang.IFn
				if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp23 any; var root_252 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = t.F_n; if linked_253 == nil { tmp23 = ifn_254.Invoke_O__O(arg_255) } else { tmp23 = linked_253.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_252, arg_255) }; arg_251 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_249 == nil { tmp21 = ifn_250.Invoke_O__O(arg_251) } else { tmp21 = linked_249.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_248, arg_251) }; arg_237 = tmp20.Invoke_O_O__O(tmp21, A_arbace_j2g_dyncf_A_const_91)
//line :81:1
				var arg_238 any = A_arbace_j2g_dyncf_A_const_92; var arg_239 any; var root_256 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_258 lang.IFn

				if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any; var fnbody__267 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New(); var tmp24 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, nil); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class = fncls__266d; tmp24 = fncls__266d } else { tmp24 = fncls__266 }; arg_259 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__267, tmp24, nil); var arg_260 any = ps__5; if linked_257 == nil { arg_239 = ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { arg_239 = linked_257.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_256, arg_259, arg_260) }
//line :81:1
				if linked_233 == nil { tmp17 = ifn_234.Invoke_O_O_O_O_O__O(arg_235, arg_236, arg_237, arg_238, arg_239) } else { tmp17 = linked_233.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_232, arg_235, arg_236, arg_237, arg_238, arg_239) }
//line :70:1
				arg_221 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp16, tmp17))); if linked_218 == nil { ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { linked_218.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) }; i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_261 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = p__2; var arg_265 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_95, A_arbace_j2g_dyncf_A_const_96, i__1); if linked_262 == nil { return ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { return linked_262.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) } }
//line :83:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_395 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = p__2; var arg_399 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_95, A_arbace_j2g_dyncf_A_const_96, i__1); if linked_396 == nil { return ifn_397.Invoke_O_O__O(arg_398, arg_399) } else { return linked_396.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_395, arg_398, arg_399) } }


func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Invoke_O_O__O(self, s__292000044__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__721 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000044__1); var tmp2 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, fnbody__721); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class = fncls__720d; tmp2 = fncls__720d } else { tmp2 = fncls__720 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__721, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :86:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000043, c__s__292000044 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000043 = c__iter__292000043; t.F_s__292000044 = c__s__292000044 }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Invoke_O__O(self any) any { { var s__292000044__1 any; var t_ any = t.F_s__292000044; t.F_s__292000044 = nil; s__292000044__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_450 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = s__292000044__1; if linked_451 == nil { temp__1927000414__auto____2 = ifn_452.Invoke_O__O(arg_453) } else { temp__1927000414__auto____2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000044__3 any = temp__1927000414__auto____2; var tmp1 any; var root_454 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = s__292000044__3; if linked_455 == nil { tmp1 = ifn_456.Invoke_O__O(arg_457) } else { tmp1 = linked_455.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_458 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__292000044__3; if linked_459 == nil { c__1927001037__auto____4 = ifn_460.Invoke_O__O(arg_461) } else { c__1927001037__auto____4 = linked_459.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_458, arg_461) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000046__6 any; var root_462 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_463 == nil { b__292000046__6 = ifn_464.Invoke_O__O(arg_465) } else { b__292000046__6 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_462, arg_465) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__574 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(t.F_recv, b__292000046__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__573 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class; if fncls__573 == nil { var fncls__573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, fnbody__574); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class = fncls__573d; tmp3 = fncls__573d } else { tmp3 = fncls__573 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__574, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_575 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var root_580 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = b__292000046__6; if linked_581 == nil { arg_578 = ifn_582.Invoke_O__O(arg_583) } else { arg_578 = linked_581.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_580, arg_583) }; var arg_579 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp5 any; var root_584 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = s__292000044__3; if linked_585 == nil { tmp5 = ifn_586.Invoke_O__O(arg_587) } else { tmp5 = linked_585.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_584, arg_587) }; arg_579 = tmp4.Invoke_O__O(tmp5); if linked_576 == nil { return ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { return linked_576.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_575, arg_578, arg_579) } } else { var root_588 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_593 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = b__292000046__6; if linked_594 == nil { arg_591 = ifn_595.Invoke_O__O(arg_596) } else { arg_591 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_593, arg_596) }; var arg_592 any; if linked_589 == nil { return ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { return linked_589.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) } } } else { var vec__292000063__4 any; var root_597 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = s__292000044__3; if linked_598 == nil { vec__292000063__4 = ifn_599.Invoke_O__O(arg_600) } else { vec__292000063__4 = linked_598.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_597, arg_600) }; var vec__292000066__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(0), nil); var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__292000066__5; var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_601 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_603 lang.IFn; _ = ___9
														if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = desc__7; if linked_602 == nil { tmp6 = ifn_603.Invoke_O__O(arg_604) } else { tmp6 = linked_602.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_601, arg_604) }
//line :86:1
	if jrt.J2g_Truth(tmp6) { var impl__10 any; var root_605 any = A_arbace_j2g_dyncf_A_const_114.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_607 lang.IFn

		if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = t.F_n; var arg_609 any = k__8; if linked_606 == nil { impl__10 = ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { impl__10 = linked_606.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) }
//line :86:1
		var base__11 any; var root_610 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_612 lang.IFn


		if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = name__6; var arg_614 any = desc__7; if linked_611 == nil { base__11 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { base__11 = linked_611.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }
//line :86:1
		var vec__292000069__12 any; var root_615 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_617 lang.IFn



		if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = desc__7; if linked_616 == nil { vec__292000069__12 = ifn_617.Invoke_O__O(arg_618) } else { vec__292000069__12 = linked_616.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_615, arg_618) }
//line :86:1
		var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(0), nil); var r__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__15 any; var root_619 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_621 lang.IFn




		if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any; var fnbody__630 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New(); var tmp7 *jrt.Class; var fncls__629 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class; if fncls__629 == nil { var fncls__629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, nil); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class = fncls__629d; tmp7 = fncls__629d } else { tmp7 = fncls__629 }; arg_622 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__630, tmp7, nil); var arg_623 any = ps__13; if linked_620 == nil { pn__15 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { pn__15 = linked_620.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }
//line :86:1
		var call__16 any; var G__292000074__16_ any = A_arbace_j2g_dyncf_A_const_117.Invoke_O__O(impl__10)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000074__16_) >> 4 & 3 { case 0: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_118) {

		var root_632 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_636 any; var root_639 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = A_arbace_j2g_dyncf_A_const_31; var arg_643 any = A_arbace_j2g_dyncf_A_const_119.Invoke_O__O(impl__10); var arg_644 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_95, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_640 == nil { arg_636 = ifn_641.Invoke_O_O_O__O(arg_642, arg_643, arg_644) } else { arg_636 = linked_640.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_639, arg_642, arg_643, arg_644) }; var arg_637 any = A_arbace_j2g_dyncf_A_const_120; var arg_638 any = pn__15; if linked_633 == nil { call__16 = ifn_634.Invoke_O_O_O_O__O(arg_635, arg_636, arg_637, arg_638) } else { call__16 = linked_633.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_632, arg_635, arg_636, arg_637, arg_638) }
//line :92:1
		break L2 }; case 1: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_121) {
			var root_645 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_649 any; var root_653 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_145, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_654 == nil { arg_649 = ifn_655.Invoke_O__O(arg_656) } else { arg_649 = linked_654.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_653, arg_656) }; var arg_650 any = A_arbace_j2g_dyncf_A_const_122; var arg_651 any = A_arbace_j2g_dyncf_A_const_123; var arg_652 any = pn__15; if linked_646 == nil { call__16 = ifn_647.Invoke_O_O_O_O_O__O(arg_648, arg_649, arg_650, arg_651, arg_652) } else { call__16 = linked_646.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_645, arg_648, arg_649, arg_650, arg_651, arg_652) }
//line :92:1
			break L2 }; case 2: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_124) {
				var root_657 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_661 any; var root_665 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_145, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_666 == nil { arg_661 = ifn_667.Invoke_O__O(arg_668) } else { arg_661 = linked_666.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_665, arg_668) }; var arg_662 any = A_arbace_j2g_dyncf_A_const_122; var arg_663 any = A_arbace_j2g_dyncf_A_const_123; var arg_664 any = pn__15; if linked_658 == nil { call__16 = ifn_659.Invoke_O_O_O_O_O__O(arg_660, arg_661, arg_662, arg_663, arg_664) } else { call__16 = linked_658.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_657, arg_660, arg_661, arg_662, arg_663, arg_664) }
//line :92:1
				break L2 }; case 3: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_125) {


					var root_669 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_673 any; var root_676 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_677 == nil { arg_673 = ifn_678.Invoke_O__O(arg_679) } else { arg_673 = linked_677.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_676, arg_679) }; var arg_674 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp9 any; var root_680 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp11 any; var root_684 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = t.F_n; if linked_685 == nil { tmp11 = ifn_686.Invoke_O__O(arg_687) } else { tmp11 = linked_685.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_684, arg_687) }; arg_683 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(); if linked_681 == nil { tmp9 = ifn_682.Invoke_O__O(arg_683) } else { tmp9 = linked_681.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_680, arg_683) }; arg_674 = tmp8.Invoke_O_O__O(tmp9, A_arbace_j2g_dyncf_A_const_126); var arg_675 any = pn__15; if linked_670 == nil { call__16 = ifn_671.Invoke_O_O_O_O__O(arg_672, arg_673, arg_674, arg_675) } else { call__16 = linked_670.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_669, arg_672, arg_673, arg_674, arg_675) }
//line :92:1
					break L2 }; default:}; call__16 = nil}
//line :86:1
		if jrt.J2g_Truth(call__16) { var root_688 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__6, desc__7)).Ref(); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyncf_A_const_127; var tmp15 any; var root_693 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_695 lang.IFn












			if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any; var tmp16 any; var root_698 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = A_arbace_j2g_dyncf_A_const_128; var arg_702 any = A_arbace_j2g_dyncf_A_const_129; if linked_699 == nil { tmp16 = ifn_700.Invoke_O_O__O(arg_701, arg_702) } else { tmp16 = linked_699.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_698, arg_701, arg_702) }; var tmp17 any = tmp16; var tmp18 any; var root_703 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = A_arbace_j2g_dyncf_A_const_130; var arg_707 any = A_arbace_j2g_dyncf_A_const_141; if linked_704 == nil { tmp18 = ifn_705.Invoke_O_O__O(arg_706, arg_707) } else { tmp18 = linked_704.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_703, arg_706, arg_707) }; arg_696 = lang.Tuple_Create_O_O__IPersistentVector(tmp17, tmp18); var arg_697 any = A_arbace_j2g_dyncf_A_const_142; if linked_694 == nil { tmp15 = ifn_695.Invoke_O_O__O(arg_696, arg_697) } else { tmp15 = linked_694.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_693, arg_696, arg_697) }
//line :86:1
			var tmp19 any = tmp15; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyncf_A_const_133; var tmp22 any = A_arbace_j2g_dyncf_A_const_134; var tmp23 any = lang.Tuple_Create_O_O__IPersistentVector(tmp22, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_135, t.F_recv, A_arbace_j2g_dyncf_A_const_136)); var tmp24 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_146, r__14) {
				tmp24 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_137, call__16, A_arbace_j2g_dyncf_A_const_143) } else {
					var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyncf_A_const_139; tmp24 = tmp25.Invoke_O_O__O(tmp26, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_140, call__16)) }
//line :86:1
			arg_691 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp19, tmp20.Invoke_O_O_O__O(tmp21, tmp23, tmp24))); var arg_692 any; var tmp27 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp28 any; var root_708 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = s__292000044__3; if linked_709 == nil { tmp28 = ifn_710.Invoke_O__O(arg_711) } else { tmp28 = linked_709.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_708, arg_711) }; arg_692 = tmp27.Invoke_O__O(tmp28); if linked_689 == nil { return ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { return linked_689.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) } } else { var tmp29 any; var root_712 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = s__292000044__3; if linked_713 == nil { tmp29 = ifn_714.Invoke_O__O(arg_715) } else { tmp29 = linked_713.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_712, arg_715) }; s__292000044__1 = tmp29; continue L1 } } else { var tmp30 any; var root_716 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = s__292000044__3; if linked_717 == nil { tmp30 = ifn_718.Invoke_O__O(arg_719) } else { tmp30 = linked_717.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_716, arg_719) }; s__292000044__1 = tmp30; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :86:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Ctor_O_O_O_I_O(c__recv, c__b__292000046, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_b__292000046 = c__b__292000046; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :86:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Invoke_O__O(self any) any { { var i__292000045__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000045__1)); var vec__292000053__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__292000053__3; var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_466 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_468 lang.IFn; _ = ___7
																if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = desc__5; if linked_467 == nil { tmp2 = ifn_468.Invoke_O__O(arg_469) } else { tmp2 = linked_467.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_466, arg_469) }
//line :86:1
	if jrt.J2g_Truth(tmp2) { var impl__8 any; var root_470 any = A_arbace_j2g_dyncf_A_const_114.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_472 lang.IFn

		if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = t.F_n; var arg_474 any = k__6; if linked_471 == nil { impl__8 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { impl__8 = linked_471.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }
//line :86:1
		var base__9 any; var root_475 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_477 lang.IFn


		if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = name__4; var arg_479 any = desc__5; if linked_476 == nil { base__9 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { base__9 = linked_476.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }
//line :86:1
		var vec__292000056__10 any; var root_480 any = A_arbace_j2g_dyncf_A_const_83.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_482 lang.IFn



		if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = desc__5; if linked_481 == nil { vec__292000056__10 = ifn_482.Invoke_O__O(arg_483) } else { vec__292000056__10 = linked_481.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_480, arg_483) }
//line :86:1
		var ps__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_484 any = A_arbace_j2g_dyncf_A_const_93.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_486 lang.IFn




		if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any; var fnbody__495 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New(); var tmp3 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, nil); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class = fncls__494d; tmp3 = fncls__494d } else { tmp3 = fncls__494 }; arg_487 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__495, tmp3, nil); var arg_488 any = ps__11; if linked_485 == nil { pn__13 = ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { pn__13 = linked_485.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_484, arg_487, arg_488) }
//line :86:1
		var call__14 any; var G__292000061__14_ any = A_arbace_j2g_dyncf_A_const_117.Invoke_O__O(impl__8)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000061__14_) >> 4 & 3 { case 0: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_118) {

		var root_497 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_501 any; var root_504 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = A_arbace_j2g_dyncf_A_const_31; var arg_508 any = A_arbace_j2g_dyncf_A_const_119.Invoke_O__O(impl__8); var arg_509 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_95, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_505 == nil { arg_501 = ifn_506.Invoke_O_O_O__O(arg_507, arg_508, arg_509) } else { arg_501 = linked_505.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_504, arg_507, arg_508, arg_509) }; var arg_502 any = A_arbace_j2g_dyncf_A_const_120; var arg_503 any = pn__13; if linked_498 == nil { call__14 = ifn_499.Invoke_O_O_O_O__O(arg_500, arg_501, arg_502, arg_503) } else { call__14 = linked_498.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_497, arg_500, arg_501, arg_502, arg_503) }
//line :92:1
		break L2 }; case 1: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_121) {
			var root_510 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_514 any; var root_518 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_145, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_519 == nil { arg_514 = ifn_520.Invoke_O__O(arg_521) } else { arg_514 = linked_519.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_518, arg_521) }; var arg_515 any = A_arbace_j2g_dyncf_A_const_122; var arg_516 any = A_arbace_j2g_dyncf_A_const_123; var arg_517 any = pn__13; if linked_511 == nil { call__14 = ifn_512.Invoke_O_O_O_O_O__O(arg_513, arg_514, arg_515, arg_516, arg_517) } else { call__14 = linked_511.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_510, arg_513, arg_514, arg_515, arg_516, arg_517) }
//line :92:1
			break L2 }; case 2: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_124) {
				var root_522 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_526 any; var root_530 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_145, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_531 == nil { arg_526 = ifn_532.Invoke_O__O(arg_533) } else { arg_526 = linked_531.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_530, arg_533) }; var arg_527 any = A_arbace_j2g_dyncf_A_const_122; var arg_528 any = A_arbace_j2g_dyncf_A_const_123; var arg_529 any = pn__13; if linked_523 == nil { call__14 = ifn_524.Invoke_O_O_O_O_O__O(arg_525, arg_526, arg_527, arg_528, arg_529) } else { call__14 = linked_523.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_522, arg_525, arg_526, arg_527, arg_528, arg_529) }
//line :92:1
				break L2 }; case 3: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_125) {


					var root_534 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_538 any; var root_541 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_542 == nil { arg_538 = ifn_543.Invoke_O__O(arg_544) } else { arg_538 = linked_542.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_541, arg_544) }; var arg_539 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp5 any; var root_545 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp7 any; var root_549 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = t.F_n; if linked_550 == nil { tmp7 = ifn_551.Invoke_O__O(arg_552) } else { tmp7 = linked_550.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_549, arg_552) }; arg_548 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref(); if linked_546 == nil { tmp5 = ifn_547.Invoke_O__O(arg_548) } else { tmp5 = linked_546.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_545, arg_548) }; arg_539 = tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_dyncf_A_const_126); var arg_540 any = pn__13; if linked_535 == nil { call__14 = ifn_536.Invoke_O_O_O_O__O(arg_537, arg_538, arg_539, arg_540) } else { call__14 = linked_535.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_534, arg_537, arg_538, arg_539, arg_540) }
//line :92:1
					break L2 }; default:}; call__14 = nil}
//line :86:1
		if jrt.J2g_Truth(call__14) { var root_553 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = t.F_b__292000046; var arg_557 any; var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__4, desc__5)).Ref(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyncf_A_const_127; var tmp11 any; var root_558 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_560 lang.IFn












			if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any; var tmp12 any; var root_563 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = A_arbace_j2g_dyncf_A_const_128; var arg_567 any = A_arbace_j2g_dyncf_A_const_129; if linked_564 == nil { tmp12 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { tmp12 = linked_564.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_563, arg_566, arg_567) }; var tmp13 any = tmp12; var tmp14 any; var root_568 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = A_arbace_j2g_dyncf_A_const_130; var arg_572 any = A_arbace_j2g_dyncf_A_const_131; if linked_569 == nil { tmp14 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { tmp14 = linked_569.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }; arg_561 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14); var arg_562 any = A_arbace_j2g_dyncf_A_const_132; if linked_559 == nil { tmp11 = ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { tmp11 = linked_559.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_558, arg_561, arg_562) }
//line :86:1
			var tmp15 any = tmp11; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyncf_A_const_133; var tmp18 any = A_arbace_j2g_dyncf_A_const_134; var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(tmp18, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_135, t.F_recv, A_arbace_j2g_dyncf_A_const_136)); var tmp20 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_146, r__12) {
				tmp20 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_137, call__14, A_arbace_j2g_dyncf_A_const_138) } else {
					var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyncf_A_const_139; tmp20 = tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_140, call__14)) }
//line :86:1
			arg_557 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9.Invoke_O_O_O__O(tmp10, tmp15, tmp16.Invoke_O_O_O__O(tmp17, tmp19, tmp20))); if linked_554 == nil { ifn_555.Invoke_O_O__O(arg_556, arg_557) } else { linked_554.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_553, arg_556, arg_557) }; i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Ctor() {}
//line :91:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_489 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = p__2; var arg_493 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_115, A_arbace_j2g_dyncf_A_const_116, i__1); if linked_490 == nil { return ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { return linked_490.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) } }
//line :91:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Ctor() {}
//line :91:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_624 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = p__2; var arg_628 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_115, A_arbace_j2g_dyncf_A_const_116, i__1); if linked_625 == nil { return ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { return linked_625.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) } }

















func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A) Ctor_O_O(c__recv, c__seen any) { t.F_recv = c__recv; t.F_seen = c__seen }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A) Invoke_O_O__O(self, s__292000078__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1053 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_New_O_O_O_O(t.F_recv, self, t.F_seen, s__292000078__1); var tmp2 *jrt.Class; var fncls__1052 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_fn_class; if fncls__1052 == nil { var fncls__1052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, fnbody__1053); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_fn_class = fncls__1052d; tmp2 = fncls__1052d } else { tmp2 = fncls__1052 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1053, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :109:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A) Ctor_O_O_O_O(c__recv, c__iter__292000077, c__seen, c__s__292000078 any) { t.F_recv = c__recv; t.F_iter__292000077 = c__iter__292000077; t.F_seen = c__seen; t.F_s__292000078 = c__s__292000078 }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A) Invoke_O__O(self any) any { { var s__292000078__1 any; var t_ any = t.F_s__292000078; t.F_s__292000078 = nil; s__292000078__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_757 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = s__292000078__1; if linked_758 == nil { temp__1927000414__auto____2 = ifn_759.Invoke_O__O(arg_760) } else { temp__1927000414__auto____2 = linked_758.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_757, arg_760) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_761 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = xs__1927001018__auto____3; if linked_762 == nil { c__4 = ifn_763.Invoke_O__O(arg_764) } else { c__4 = linked_762.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_761, arg_764) }; var tmp1 any; var and__1927000168__auto____5 any = c__4
														if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_765 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = c__4; var arg_769 any = Lit_102; if linked_766 == nil { and__1927000168__auto____6 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { and__1927000168__auto____6 = linked_766.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_770 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var root_774 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = c__4; if linked_775 == nil { arg_773 = ifn_776.Invoke_O__O(arg_777) } else { arg_773 = linked_775.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_774, arg_777) }; if linked_771 == nil { tmp1 = ifn_772.Invoke_O__O(arg_773) } else { tmp1 = linked_771.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_770, arg_773) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }
//line :109:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__1021 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_New_O_O_O(t.F_recv, t.F_seen, c__4); var tmp2 *jrt.Class; var fncls__1020 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_fn_class; if fncls__1020 == nil { var fncls__1020d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, fnbody__1021); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_fn_class = fncls__1020d; tmp2 = fncls__1020d } else { tmp2 = fncls__1020 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1021, tmp2, nil); var fs__1927001036__auto____6 any; var root_1022 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1026 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1028 lang.IFn

		if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = A_arbace_j2g_dyncf_A_const_72; var arg_1030 any; var root_1031 any = A_arbace_j2g_dyncf_A_const_190.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = c__4; if linked_1032 == nil { arg_1030 = ifn_1033.Invoke_O__O(arg_1034) } else { arg_1030 = linked_1032.(*aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A).Invoke_O_O__O(root_1031, arg_1034) }; if linked_1027 == nil { tmp4 = ifn_1028.Invoke_O_O__O(arg_1029, arg_1030) } else { tmp4 = linked_1027.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1026, arg_1029, arg_1030) }
//line :109:1
		arg_1025 = tmp3.Invoke_O__O(tmp4); if linked_1023 == nil { fs__1927001036__auto____6 = ifn_1024.Invoke_O__O(arg_1025) } else { fs__1927001036__auto____6 = linked_1023.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1022, arg_1025) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1035 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = fs__1927001036__auto____6; var arg_1039 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__292000077); var tmp6 any; var root_1040 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = s__292000078__1; if linked_1041 == nil { tmp6 = ifn_1042.Invoke_O__O(arg_1043) } else { tmp6 = linked_1041.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1040, arg_1043) }; arg_1039 = tmp5.Invoke_O__O(tmp6); if linked_1036 == nil { return ifn_1037.Invoke_O_O__O(arg_1038, arg_1039) } else { return linked_1036.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1035, arg_1038, arg_1039) } } else { var tmp7 any; var root_1044 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = s__292000078__1; if linked_1045 == nil { tmp7 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp7 = linked_1045.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1044, arg_1047) }; s__292000078__1 = tmp7; continue L1 } } else { var tmp8 any; var root_1048 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = s__292000078__1; if linked_1049 == nil { tmp8 = ifn_1050.Invoke_O__O(arg_1051) } else { tmp8 = linked_1049.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1048, arg_1051) }; s__292000078__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A) Ctor_O_O_O(c__recv, c__seen, c__c any) { t.F_recv = c__recv; t.F_seen = c__seen; t.F_c = c__c }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A) Invoke_O_O__O(self, s__292000080__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1019 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_New_O_O_O_O_O(t.F_recv, s__292000080__1, t.F_seen, self, t.F_c); var tmp2 *jrt.Class; var fncls__1018 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_fn_class; if fncls__1018 == nil { var fncls__1018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, fnbody__1019); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_fn_class = fncls__1018d; tmp2 = fncls__1018d } else { tmp2 = fncls__1018 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1019, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :109:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A) Ctor_O_O_O_O_O(c__recv, c__s__292000080, c__seen, c__iter__292000079, c__c any) { t.F_recv = c__recv; t.F_s__292000080 = c__s__292000080; t.F_seen = c__seen; t.F_iter__292000079 = c__iter__292000079; t.F_c = c__c }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A) Invoke_O__O(self any) any { { var s__292000080__1 any; var t_ any = t.F_s__292000080; t.F_s__292000080 = nil; s__292000080__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_778 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = s__292000080__1; if linked_779 == nil { temp__1927000414__auto____2 = ifn_780.Invoke_O__O(arg_781) } else { temp__1927000414__auto____2 = linked_779.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_778, arg_781) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000080__3 any = temp__1927000414__auto____2; var tmp1 any; var root_782 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = s__292000080__3; if linked_783 == nil { tmp1 = ifn_784.Invoke_O__O(arg_785) } else { tmp1 = linked_783.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_782, arg_785) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_786 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = s__292000080__3; if linked_787 == nil { c__1927001037__auto____4 = ifn_788.Invoke_O__O(arg_789) } else { c__1927001037__auto____4 = linked_787.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_786, arg_789) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000082__6 any; var root_790 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_791 == nil { b__292000082__6 = ifn_792.Invoke_O__O(arg_793) } else { b__292000082__6 = linked_791.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_790, arg_793) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__887 any = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_New_O_O_I_O_O_O(t.F_recv, t.F_seen, size__1927001038__auto____5, b__292000082__6, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__886 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_fn_class; if fncls__886 == nil { var fncls__886d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, fnbody__887); A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_fn_class = fncls__886d; tmp3 = fncls__886d } else { tmp3 = fncls__886 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__887, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_888 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var root_893 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = b__292000082__6; if linked_894 == nil { arg_891 = ifn_895.Invoke_O__O(arg_896) } else { arg_891 = linked_894.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_893, arg_896) }; var arg_892 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000079); var tmp5 any; var root_897 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = s__292000080__3; if linked_898 == nil { tmp5 = ifn_899.Invoke_O__O(arg_900) } else { tmp5 = linked_898.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_897, arg_900) }; arg_892 = tmp4.Invoke_O__O(tmp5); if linked_889 == nil { return ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { return linked_889.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_888, arg_891, arg_892) } } else { var root_901 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any; var root_906 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = b__292000082__6; if linked_907 == nil { arg_904 = ifn_908.Invoke_O__O(arg_909) } else { arg_904 = linked_907.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_906, arg_909) }; var arg_905 any; if linked_902 == nil { return ifn_903.Invoke_O_O__O(arg_904, arg_905) } else { return linked_902.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_901, arg_904, arg_905) } } } else { var f__4 any; var root_910 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = s__292000080__3; if linked_911 == nil { f__4 = ifn_912.Invoke_O__O(arg_913) } else { f__4 = linked_911.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_910, arg_913) }; var tmp6 any; var root_914 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_916 lang.IFn


	if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = f__4; if linked_915 == nil { tmp6 = ifn_916.Invoke_O__O(arg_917) } else { tmp6 = linked_915.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_914, arg_917) }
//line :109:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_918 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_920 lang.IFn



		if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any; var tmp8 any; var root_922 any = A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = t.F_seen; if linked_923 == nil { tmp8 = ifn_924.Invoke_O__O(arg_925) } else { tmp8 = linked_923.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_922, arg_925) }; arg_921 = lang.IFn_Cast(tmp8).Invoke_O__O(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4)); if linked_919 == nil { tmp7 = ifn_920.Invoke_O__O(arg_921) } else { tmp7 = linked_919.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_918, arg_921) }
//line :109:1
		if jrt.J2g_Truth(tmp7) { var ___5 any; var root_926 any = A_arbace_j2g_dyncf_A_const_154.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_928 lang.IFn; _ = ___5




			if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = t.F_seen; var arg_930 any = A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(); var arg_931 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); if linked_927 == nil { ___5 = ifn_928.Invoke_O_O_O__O(arg_929, arg_930, arg_931) } else { ___5 = linked_927.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_926, arg_929, arg_930, arg_931) }
//line :109:1
			var d__6 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); var place__7 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp10 any; var root_994 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_996 lang.IFn






			if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp12 any; var root_998 any = A_arbace_j2g_dyncf_A_const_155.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); if linked_999 == nil { tmp12 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp12 = linked_999.(*aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A).Invoke_O_O__O(root_998, arg_1001) }; arg_997 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); if linked_995 == nil { tmp10 = ifn_996.Invoke_O__O(arg_997) } else { tmp10 = linked_995.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_994, arg_997) }; var tmp13 any = tmp10; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp15 any; var root_1002 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1004 lang.IFn
			if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp17 any; var root_1006 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = t.F_c; if linked_1007 == nil { tmp17 = ifn_1008.Invoke_O__O(arg_1009) } else { tmp17 = linked_1007.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1006, arg_1009) }; arg_1005 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17)).Ref(); if linked_1003 == nil { tmp15 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp15 = linked_1003.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1002, arg_1005) }
//line :116:1
			place__7 = tmp9.Invoke_O_O__O(tmp13, tmp14.Invoke_O_O__O(tmp15, A_arbace_j2g_dyncf_A_const_156))
//line :109:1
			var root_932 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any; var tmp18 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp19 any; var vol__8 any; var root_937 any = A_arbace_j2g_dyncf_A_const_157.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_field_QMARK__A_fn_class); var ifn_939 lang.IFn









			if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = f__4; if linked_938 == nil { vol__8 = ifn_939.Invoke_O__O(arg_940) } else { vol__8 = linked_938.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_field_QMARK__A).Invoke_O_O__O(root_937, arg_940) }
//line :109:1
			var rd__9 any










			if jrt.J2g_Truth(vol__8) { var root_941 any = A_arbace_j2g_dyncf_A_const_158.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_read_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = place__7; var arg_945 any = d__6; if linked_942 == nil { rd__9 = ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { rd__9 = linked_942.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_read_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) } } else { rd__9 = place__7 }
			var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyncf_A_const_159; var tmp22 any; var root_946 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var tmp23 any; var root_951 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = A_arbace_j2g_dyncf_A_const_160; var arg_955 any = A_arbace_j2g_dyncf_A_const_161; if linked_952 == nil { tmp23 = ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { tmp23 = linked_952.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) }; var tmp24 any = tmp23; var tmp25 any; var root_956 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = A_arbace_j2g_dyncf_A_const_162; var arg_960 any = A_arbace_j2g_dyncf_A_const_163; if linked_957 == nil { tmp25 = ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { tmp25 = linked_957.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }; var tmp26 any = tmp25; var tmp27 any; var root_961 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = A_arbace_j2g_dyncf_A_const_164; var arg_965 any = A_arbace_j2g_dyncf_A_const_165; if linked_962 == nil { tmp27 = ifn_963.Invoke_O_O__O(arg_964, arg_965) } else { tmp27 = linked_962.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_961, arg_964, arg_965) }; arg_949 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp24, tmp26, tmp27); var arg_950 any = A_arbace_j2g_dyncf_A_const_186; if linked_947 == nil { tmp22 = ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { tmp22 = linked_947.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }; var tmp28 any = tmp22; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_dyncf_A_const_167; var tmp31 any = A_arbace_j2g_dyncf_A_const_169; var tmp32 any = lang.Tuple_Create_O_O__IPersistentVector(tmp31, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_170, t.F_recv, A_arbace_j2g_dyncf_A_const_171)); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp34 any = A_arbace_j2g_dyncf_A_const_172; var tmp35 any = A_arbace_j2g_dyncf_A_const_173; var tmp36 any


			if jrt.J2g_Truth(vol__8) { var root_974 any = A_arbace_j2g_dyncf_A_const_174.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_write_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = place__7; var arg_978 any = d__6; var arg_979 any; var root_980 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = d__6; var arg_984 any = A_arbace_j2g_dyncf_A_const_175; if linked_981 == nil { arg_979 = ifn_982.Invoke_O_O__O(arg_983, arg_984) } else { arg_979 = linked_981.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_980, arg_983, arg_984) }; if linked_975 == nil { tmp36 = ifn_976.Invoke_O_O_O__O(arg_977, arg_978, arg_979) } else { tmp36 = linked_975.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_write_A).Invoke_O_O_O_O__O(root_974, arg_977, arg_978, arg_979) } } else { var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp38 any = A_arbace_j2g_dyncf_A_const_177; var tmp39 any; var root_985 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = d__6; var arg_989 any = A_arbace_j2g_dyncf_A_const_178; if linked_986 == nil { tmp39 = ifn_987.Invoke_O_O__O(arg_988, arg_989) } else { tmp39 = linked_986.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_985, arg_988, arg_989) }; tmp36 = tmp37.Invoke_O_O_O__O(tmp38, place__7, tmp39) }
//line :121:1
			var tmp40 any = tmp33.Invoke_O_O_O_O__O(tmp34, tmp35, tmp36, A_arbace_j2g_dyncf_A_const_187); var tmp41 any; var tmp42 any; var root_966 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_968 lang.IFn





			if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = d__6; if linked_967 == nil { tmp42 = ifn_968.Invoke_O__O(arg_969) } else { tmp42 = linked_967.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_966, arg_969) }
//line :126:1
			if jrt.J2g_Truth(tmp42) {
				var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_dyncf_A_const_179; tmp41 = tmp43.Invoke_O_O__O(tmp44, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_180, rd__9)) } else {
//line :126:1
					var tmp45 any; var root_970 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_972 lang.IFn


					if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = d__6; if linked_971 == nil { tmp45 = ifn_972.Invoke_O__O(arg_973) } else { tmp45 = linked_971.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_970, arg_973) }
//line :126:1
					if jrt.J2g_Truth(tmp45) {


						var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp47 any = A_arbace_j2g_dyncf_A_const_181; tmp41 = tmp46.Invoke_O_O_O_O__O(tmp47, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_184, rd__9), A_arbace_j2g_dyncf_A_const_188, A_arbace_j2g_dyncf_A_const_189) } else {
//line :126:1
							if A_arbace_j2g_dyncf_A_const_28 != nil {



								tmp41 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_185, rd__9) } else {
//line :126:1
									tmp41 = nil } } }
//line :121:1
			tmp19 = tmp20.Invoke_O_O_O__O(tmp21, tmp28, tmp29.Invoke_O_O_O_O__O(tmp30, tmp32, tmp40, tmp41))
//line :109:1
			arg_935 = lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19); var arg_936 any; var tmp48 lang.IFn = lang.IFn_Cast(t.F_iter__292000079); var tmp49 any; var root_990 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = s__292000080__3; if linked_991 == nil { tmp49 = ifn_992.Invoke_O__O(arg_993) } else { tmp49 = linked_991.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_990, arg_993) }; arg_936 = tmp48.Invoke_O__O(tmp49); if linked_933 == nil { return ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { return linked_933.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_932, arg_935, arg_936) } } else { var tmp50 any; var root_1010 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = s__292000080__3; if linked_1011 == nil { tmp50 = ifn_1012.Invoke_O__O(arg_1013) } else { tmp50 = linked_1011.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1010, arg_1013) }; s__292000080__1 = tmp50; continue L1 } } else { var tmp51 any; var root_1014 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = s__292000080__3; if linked_1015 == nil { tmp51 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp51 = linked_1015.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1014, arg_1017) }; s__292000080__1 = tmp51; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_New_O_O_I_O_O_O(p0, p1 any, p2 int32, p3, p4, p5 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A{}; t.Ctor_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A) Ctor_O_O_I_O_O_O(c__recv, c__seen any, c__size__1927001038__auto__ int32, c__b__292000082, c__c__1927001037__auto__, c__c any) { t.F_recv = c__recv; t.F_seen = c__seen; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__292000082 = c__b__292000082; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :109:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A) Invoke_O__O(self any) any { { var i__292000081__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000081__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000081__1)); var tmp2 any; var root_794 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_796 lang.IFn


	if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = f__2; if linked_795 == nil { tmp2 = ifn_796.Invoke_O__O(arg_797) } else { tmp2 = linked_795.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_794, arg_797) }
//line :109:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_798 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_800 lang.IFn



		if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var tmp4 any; var root_802 any = A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = t.F_seen; if linked_803 == nil { tmp4 = ifn_804.Invoke_O__O(arg_805) } else { tmp4 = linked_803.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_802, arg_805) }; arg_801 = lang.IFn_Cast(tmp4).Invoke_O__O(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2)); if linked_799 == nil { tmp3 = ifn_800.Invoke_O__O(arg_801) } else { tmp3 = linked_799.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_798, arg_801) }
//line :109:1
		if jrt.J2g_Truth(tmp3) { var ___3 any; var root_806 any = A_arbace_j2g_dyncf_A_const_154.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_808 lang.IFn; _ = ___3




			if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = t.F_seen; var arg_810 any = A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(); var arg_811 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); if linked_807 == nil { ___3 = ifn_808.Invoke_O_O_O__O(arg_809, arg_810, arg_811) } else { ___3 = linked_807.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_806, arg_809, arg_810, arg_811) }
//line :109:1
			var d__4 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); var place__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp6 any; var root_812 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_814 lang.IFn






			if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp8 any; var root_816 any = A_arbace_j2g_dyncf_A_const_155.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); if linked_817 == nil { tmp8 = ifn_818.Invoke_O__O(arg_819) } else { tmp8 = linked_817.(*aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A).Invoke_O_O__O(root_816, arg_819) }; arg_815 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(); if linked_813 == nil { tmp6 = ifn_814.Invoke_O__O(arg_815) } else { tmp6 = linked_813.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_812, arg_815) }; var tmp9 any = tmp6; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any; var root_820 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_822 lang.IFn
			if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp13 any; var root_824 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = t.F_c; if linked_825 == nil { tmp13 = ifn_826.Invoke_O__O(arg_827) } else { tmp13 = linked_825.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_824, arg_827) }; arg_823 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13)).Ref(); if linked_821 == nil { tmp11 = ifn_822.Invoke_O__O(arg_823) } else { tmp11 = linked_821.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_820, arg_823) }
//line :116:1
			place__5 = tmp5.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O__O(tmp11, A_arbace_j2g_dyncf_A_const_156))
//line :109:1
			var root_828 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = t.F_b__292000082; var arg_832 any; var tmp14 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp15 any; var vol__6 any; var root_833 any = A_arbace_j2g_dyncf_A_const_157.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_field_QMARK__A_fn_class); var ifn_835 lang.IFn









			if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = f__2; if linked_834 == nil { vol__6 = ifn_835.Invoke_O__O(arg_836) } else { vol__6 = linked_834.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_field_QMARK__A).Invoke_O_O__O(root_833, arg_836) }
//line :109:1
			var rd__7 any










			if jrt.J2g_Truth(vol__6) { var root_837 any = A_arbace_j2g_dyncf_A_const_158.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_read_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = place__5; var arg_841 any = d__4; if linked_838 == nil { rd__7 = ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { rd__7 = linked_838.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_read_A).Invoke_O_O_O__O(root_837, arg_840, arg_841) } } else { rd__7 = place__5 }
			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyncf_A_const_159; var tmp18 any; var root_842 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var tmp19 any; var root_847 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = A_arbace_j2g_dyncf_A_const_160; var arg_851 any = A_arbace_j2g_dyncf_A_const_161; if linked_848 == nil { tmp19 = ifn_849.Invoke_O_O__O(arg_850, arg_851) } else { tmp19 = linked_848.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_847, arg_850, arg_851) }; var tmp20 any = tmp19; var tmp21 any; var root_852 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = A_arbace_j2g_dyncf_A_const_162; var arg_856 any = A_arbace_j2g_dyncf_A_const_163; if linked_853 == nil { tmp21 = ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { tmp21 = linked_853.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }; var tmp22 any = tmp21; var tmp23 any; var root_857 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = A_arbace_j2g_dyncf_A_const_164; var arg_861 any = A_arbace_j2g_dyncf_A_const_165; if linked_858 == nil { tmp23 = ifn_859.Invoke_O_O__O(arg_860, arg_861) } else { tmp23 = linked_858.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_857, arg_860, arg_861) }; arg_845 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp20, tmp22, tmp23); var arg_846 any = A_arbace_j2g_dyncf_A_const_166; if linked_843 == nil { tmp18 = ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { tmp18 = linked_843.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_842, arg_845, arg_846) }; var tmp24 any = tmp18; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyncf_A_const_167; var tmp27 any = A_arbace_j2g_dyncf_A_const_169; var tmp28 any = lang.Tuple_Create_O_O__IPersistentVector(tmp27, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_170, t.F_recv, A_arbace_j2g_dyncf_A_const_171)); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_dyncf_A_const_172; var tmp31 any = A_arbace_j2g_dyncf_A_const_173; var tmp32 any


			if jrt.J2g_Truth(vol__6) { var root_870 any = A_arbace_j2g_dyncf_A_const_174.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_j2g_code.A_arbace_j2g_code_volatile_write_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = place__5; var arg_874 any = d__4; var arg_875 any; var root_876 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = d__4; var arg_880 any = A_arbace_j2g_dyncf_A_const_175; if linked_877 == nil { arg_875 = ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { arg_875 = linked_877.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_876, arg_879, arg_880) }; if linked_871 == nil { tmp32 = ifn_872.Invoke_O_O_O__O(arg_873, arg_874, arg_875) } else { tmp32 = linked_871.(*aot_arbace_j2g_code.A_arbace_j2g_code_volatile_write_A).Invoke_O_O_O_O__O(root_870, arg_873, arg_874, arg_875) } } else { var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp34 any = A_arbace_j2g_dyncf_A_const_177; var tmp35 any; var root_881 any = A_arbace_j2g_dyncf_A_const_94.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = d__4; var arg_885 any = A_arbace_j2g_dyncf_A_const_178; if linked_882 == nil { tmp35 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { tmp35 = linked_882.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }; tmp32 = tmp33.Invoke_O_O_O__O(tmp34, place__5, tmp35) }
//line :121:1
			var tmp36 any = tmp29.Invoke_O_O_O_O__O(tmp30, tmp31, tmp32, A_arbace_j2g_dyncf_A_const_176); var tmp37 any; var tmp38 any; var root_862 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_864 lang.IFn





			if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = d__4; if linked_863 == nil { tmp38 = ifn_864.Invoke_O__O(arg_865) } else { tmp38 = linked_863.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_862, arg_865) }
//line :126:1
			if jrt.J2g_Truth(tmp38) {
				var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_dyncf_A_const_179; tmp37 = tmp39.Invoke_O_O__O(tmp40, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_180, rd__7)) } else {
//line :126:1
					var tmp41 any; var root_866 any = A_arbace_j2g_dyncf_A_const_168.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_868 lang.IFn


					if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = d__4; if linked_867 == nil { tmp41 = ifn_868.Invoke_O__O(arg_869) } else { tmp41 = linked_867.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_866, arg_869) }
//line :126:1
					if jrt.J2g_Truth(tmp41) {


						var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp43 any = A_arbace_j2g_dyncf_A_const_181; tmp37 = tmp42.Invoke_O_O_O_O__O(tmp43, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_184, rd__7), A_arbace_j2g_dyncf_A_const_182, A_arbace_j2g_dyncf_A_const_183) } else {
//line :126:1
							if A_arbace_j2g_dyncf_A_const_28 != nil {



								tmp37 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_185, rd__7) } else {
//line :126:1
									tmp37 = nil } } }
//line :121:1
			tmp15 = tmp16.Invoke_O_O_O__O(tmp17, tmp24, tmp25.Invoke_O_O_O_O__O(tmp26, tmp28, tmp36, tmp37))
//line :109:1
			arg_832 = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); if linked_829 == nil { ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { linked_829.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) }; i__292000081__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000081__1); continue L1 } else { i__292000081__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000081__1); continue L1 } } else { i__292000081__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000081__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_j2g_dyncf_subs_forms_A_New() *A_arbace_j2g_dyncf_subs_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Invoke_O_O__O(self, T__0_ any) any { var cs__2 any; var root_1060 any = A_arbace_j2g_dyncf_A_const_193.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_1062 lang.IFn; if


	linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = T__0_; if linked_1061 == nil { cs__2 = ifn_1062.Invoke_O__O(arg_1063) } else { cs__2 = linked_1061.(*aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_1060, arg_1063) }; var root_1064 any =
	A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_194.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_195.GetRawRoot__O(), cs__2); var arg_1068 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_196; var tmp3 any = A_arbace_j2g_dyncf_A_const_197; var tmp4 any; var root_1187 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1189 lang.IFn; if




	linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = A_arbace_j2g_dyncf_A_const_205; var arg_1191 any = A_arbace_j2g_dyncf_A_const_206; if linked_1188 == nil { tmp4 = ifn_1189.Invoke_O_O__O(arg_1190, arg_1191) } else { tmp4 = linked_1188.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1187, arg_1190, arg_1191) }; var tmp5 any = /*line :136:1*/lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 any = A_arbace_j2g_dyncf_A_const_198; var tmp7 any = A_arbace_j2g_dyncf_A_const_199; var tmp8 any; var root_1074 any = A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1076 lang.IFn; if







	linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_1078 any = A_arbace_j2g_dyncf_A_const_200; var arg_1079 any = A_arbace_j2g_dyncf_A_const_201; var arg_1080 any; var iter__1927001039__auto____3 any; var fnbody__1186 any = A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A_New(); var tmp9 *jrt.Class; var fncls__1185 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A_fn_class; if
	fncls__1185 == nil { var fncls__1185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, nil); A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A_fn_class = fncls__1185d; tmp9 = fncls__1185d } else { tmp9 = fncls__1185 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1186, tmp9, nil); arg_1080 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(cs__2); if /*line :144:1*/ linked_1075 == nil { tmp8 = ifn_1076.Invoke_O_O_O_O__O(arg_1077, arg_1078, arg_1079, arg_1080) } else { tmp8 = linked_1075.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1074, arg_1077, arg_1078, arg_1079, arg_1080) }; var tmp10 any = /*line :136:1*/tmp1.Invoke_O_O_O_O_O_O_O_O__O(tmp2, tmp3, Lit_153, tmp5, tmp6, tmp7, tmp8, A_arbace_j2g_dyncf_A_const_204); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyncf_A_const_207; var tmp13 any = A_arbace_j2g_dyncf_A_const_208; var tmp14 any; var root_1192 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1194 lang.IFn; if
















	linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any; var tmp15 any; var root_1197 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = A_arbace_j2g_dyncf_A_const_209; var arg_1201 any = A_arbace_j2g_dyncf_A_const_210; if linked_1198 == nil { tmp15 = ifn_1199.Invoke_O_O__O(arg_1200, arg_1201) } else { tmp15 = linked_1198.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1197, arg_1200, arg_1201) }; arg_1195 = lang.Tuple_Create_O__IPersistentVector(tmp15); var arg_1196 any = A_arbace_j2g_dyncf_A_const_211; if linked_1193 == nil { tmp14 = ifn_1194.Invoke_O_O__O(arg_1195, arg_1196) } else { tmp14 = linked_1193.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1192, arg_1195, arg_1196) }; var tmp16 any = tmp14; var tmp17 any; var root_1202 any = /*line :136:1*/A_arbace_j2g_dyncf_A_const_65.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1204 lang.IFn; if

















	linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O(); var arg_1206 any = A_arbace_j2g_dyncf_A_const_212; var arg_1207 any = A_arbace_j2g_dyncf_A_const_213; var arg_1208 any; var iter__1927001039__auto____3_2 any; var fnbody__1298 any = A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A_New(); var tmp18 *jrt.Class; var fncls__1297 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A_fn_class; if
	fncls__1297 == nil { var fncls__1297d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, nil); A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A_fn_class = fncls__1297d; tmp18 = fncls__1297d } else { tmp18 = fncls__1297 }; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1298, tmp18, nil); arg_1208 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(cs__2); if /*line :154:1*/ linked_1203 == nil { tmp17 = ifn_1204.Invoke_O_O_O_O__O(arg_1205, arg_1206, arg_1207, arg_1208) } else { tmp17 = linked_1203.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1202, arg_1205, arg_1206, arg_1207, arg_1208) }; arg_1068 = /*line :136:1*/lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O_O_O_O_O_O__O(tmp12, tmp13, Lit_155, tmp16, tmp17, A_arbace_j2g_dyncf_A_const_216)); if linked_1065 == nil { return ifn_1066.Invoke_O_O__O(arg_1067, arg_1068) } else { return linked_1065.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1064, arg_1067, arg_1068) } }








func A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A_New() *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A) Ctor() {}
//line :145:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A) Invoke_O_O__O(self, s__292000095__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1184 any = A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A_New_O_O(self, s__292000095__1); var tmp2 *jrt.Class; var fncls__1183 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A_fn_class; if fncls__1183 == nil { var fncls__1183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, fnbody__1184); A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A_fn_class = fncls__1183d; tmp2 = fncls__1183d } else { tmp2 = fncls__1183 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1184, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :145:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A{}; t.Ctor_O_O(p0, p1); return t }
//line :145:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A) Ctor_O_O(c__iter__292000094, c__s__292000095 any) { t.F_iter__292000094 = c__iter__292000094; t.F_s__292000095 = c__s__292000095 }
//line :145:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A) Invoke_O__O(self any) any { { var s__292000095__1 any; var t_ any = t.F_s__292000095; t.F_s__292000095 = nil; s__292000095__1 = t_; for { var temp__1927000414__auto____2 any; var root_1081 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = s__292000095__1; if linked_1082 == nil { temp__1927000414__auto____2 = ifn_1083.Invoke_O__O(arg_1084) } else { temp__1927000414__auto____2 = linked_1082.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1081, arg_1084) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000095__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1085 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = s__292000095__3; if linked_1086 == nil { tmp1 = ifn_1087.Invoke_O__O(arg_1088) } else { tmp1 = linked_1086.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1085, arg_1088) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1089 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = s__292000095__3; if linked_1090 == nil { c__1927001037__auto____4 = ifn_1091.Invoke_O__O(arg_1092) } else { c__1927001037__auto____4 = linked_1090.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1089, arg_1092) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000097__6 any; var root_1093 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1094 == nil { b__292000097__6 = ifn_1095.Invoke_O__O(arg_1096) } else { b__292000097__6 = linked_1094.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1093, arg_1096) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1125 any = A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A_New_O_I_O(b__292000097__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1124 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A_fn_class; if fncls__1124 == nil { var fncls__1124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, fnbody__1125); A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A_fn_class = fncls__1124d; tmp3 = fncls__1124d } else { tmp3 = fncls__1124 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1125, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1126 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any; var root_1131 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = b__292000097__6; if linked_1132 == nil { arg_1129 = ifn_1133.Invoke_O__O(arg_1134) } else { arg_1129 = linked_1132.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1131, arg_1134) }; var arg_1130 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000094); var tmp5 any; var root_1135 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = s__292000095__3; if linked_1136 == nil { tmp5 = ifn_1137.Invoke_O__O(arg_1138) } else { tmp5 = linked_1136.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1135, arg_1138) }; arg_1130 = tmp4.Invoke_O__O(tmp5); if linked_1127 == nil { return ifn_1128.Invoke_O_O__O(arg_1129, arg_1130) } else { return linked_1127.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1126, arg_1129, arg_1130) } } else { var root_1139 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any; var root_1144 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = b__292000097__6; if linked_1145 == nil { arg_1142 = ifn_1146.Invoke_O__O(arg_1147) } else { arg_1142 = linked_1145.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1144, arg_1147) }; var arg_1143 any; if linked_1140 == nil { return ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { return linked_1140.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) } } } else { var p__4 any; var root_1148 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = s__292000095__3; if linked_1149 == nil { p__4 = ifn_1150.Invoke_O__O(arg_1151) } else { p__4 = linked_1149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1148, arg_1151) }; var g__5 any; var root_1152 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = p__4; if linked_1153 == nil { g__5 = ifn_1154.Invoke_O__O(arg_1155) } else { g__5 = linked_1153.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1152, arg_1155) }; var root_1156 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_202; var tmp8 any; var root_1161 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1163 lang.IFn
														if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = A_arbace_j2g_dyncf_A_const_31; var arg_1165 any = p__4; var arg_1166 any = Lit_159; if linked_1162 == nil { tmp8 = ifn_1163.Invoke_O_O_O__O(arg_1164, arg_1165, arg_1166) } else { tmp8 = linked_1162.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1161, arg_1164, arg_1165, arg_1166) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_203; var tmp12 any; var root_1167 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1169 lang.IFn
														if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_128, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_1168 == nil { tmp12 = ifn_1169.Invoke_O__O(arg_1170) } else { tmp12 = linked_1168.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1167, arg_1170) }
//line :146:1
	var tmp13 any = tmp12; var tmp14 any; var root_1171 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1173 lang.IFn
	if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_130, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_1172 == nil { tmp14 = ifn_1173.Invoke_O__O(arg_1174) } else { tmp14 = linked_1172.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1171, arg_1174) }
//line :146:1
	var tmp15 any = tmp14; var tmp16 any; var root_1175 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1177 lang.IFn

	if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_132, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_1176 == nil { tmp16 = ifn_1177.Invoke_O__O(arg_1178) } else { tmp16 = linked_1176.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1175, arg_1178) }
//line :146:1
	arg_1159 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp13, tmp15, tmp16))
//line :145:1
	var arg_1160 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__292000094); var tmp18 any; var root_1179 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = s__292000095__3; if linked_1180 == nil { tmp18 = ifn_1181.Invoke_O__O(arg_1182) } else { tmp18 = linked_1180.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1179, arg_1182) }; arg_1160 = tmp17.Invoke_O__O(tmp18); if linked_1157 == nil { return ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { return linked_1157.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :145:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :145:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A) Ctor_O_I_O(c__b__292000097 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000097 = c__b__292000097; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :145:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A) Invoke_O__O(self any) any { { var i__292000096__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000096__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000096__1)); var g__3 any; var root_1097 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1097, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = p__2; if linked_1098 == nil { g__3 = ifn_1099.Invoke_O__O(arg_1100) } else { g__3 = linked_1098.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1097, arg_1100) }; var root_1101 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = t.F_b__292000097; var arg_1105 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_202; var tmp4 any; var root_1106 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1108 lang.IFn
																if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = A_arbace_j2g_dyncf_A_const_31; var arg_1110 any = p__2; var arg_1111 any = Lit_159; if linked_1107 == nil { tmp4 = ifn_1108.Invoke_O_O_O__O(arg_1109, arg_1110, arg_1111) } else { tmp4 = linked_1107.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1106, arg_1109, arg_1110, arg_1111) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_203; var tmp8 any; var root_1112 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1114 lang.IFn
																if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_128, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_1113 == nil { tmp8 = ifn_1114.Invoke_O__O(arg_1115) } else { tmp8 = linked_1113.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1112, arg_1115) }
//line :146:1
	var tmp9 any = tmp8; var tmp10 any; var root_1116 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1118 lang.IFn
	if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_130, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_1117 == nil { tmp10 = ifn_1118.Invoke_O__O(arg_1119) } else { tmp10 = linked_1117.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1116, arg_1119) }
//line :146:1
	var tmp11 any = tmp10; var tmp12 any; var root_1120 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1122 lang.IFn

	if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_132, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_1121 == nil { tmp12 = ifn_1122.Invoke_O__O(arg_1123) } else { tmp12 = linked_1121.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1120, arg_1123) }
//line :146:1
	arg_1105 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp9, tmp11, tmp12))
//line :145:1
	if linked_1102 == nil { ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { linked_1102.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) }; i__292000096__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000096__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A_New() *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A) Ctor() {}
//line :155:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A) Invoke_O_O__O(self, s__292000105__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1296 any = A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A_New_O_O(self, s__292000105__1); var tmp2 *jrt.Class; var fncls__1295 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A_fn_class; if fncls__1295 == nil { var fncls__1295d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, fnbody__1296); A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A_fn_class = fncls__1295d; tmp2 = fncls__1295d } else { tmp2 = fncls__1295 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1296, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :155:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A{}; t.Ctor_O_O(p0, p1); return t }
//line :155:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A) Ctor_O_O(c__iter__292000104, c__s__292000105 any) { t.F_iter__292000104 = c__iter__292000104; t.F_s__292000105 = c__s__292000105 }
//line :155:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A) Invoke_O__O(self any) any { { var s__292000105__1 any; var t_ any = t.F_s__292000105; t.F_s__292000105 = nil; s__292000105__1 = t_; for { var temp__1927000414__auto____2 any; var root_1209 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = s__292000105__1; if linked_1210 == nil { temp__1927000414__auto____2 = ifn_1211.Invoke_O__O(arg_1212) } else { temp__1927000414__auto____2 = linked_1210.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1209, arg_1212) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000105__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1213 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = s__292000105__3; if linked_1214 == nil { tmp1 = ifn_1215.Invoke_O__O(arg_1216) } else { tmp1 = linked_1214.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1213, arg_1216) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1217 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = s__292000105__3; if linked_1218 == nil { c__1927001037__auto____4 = ifn_1219.Invoke_O__O(arg_1220) } else { c__1927001037__auto____4 = linked_1218.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1217, arg_1220) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000107__6 any; var root_1221 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1222 == nil { b__292000107__6 = ifn_1223.Invoke_O__O(arg_1224) } else { b__292000107__6 = linked_1222.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1221, arg_1224) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1245 any = A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A_New_O_I_O(b__292000107__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1244 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A_fn_class; if fncls__1244 == nil { var fncls__1244d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, fnbody__1245); A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A_fn_class = fncls__1244d; tmp3 = fncls__1244d } else { tmp3 = fncls__1244 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1245, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1246 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any; var root_1251 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = b__292000107__6; if linked_1252 == nil { arg_1249 = ifn_1253.Invoke_O__O(arg_1254) } else { arg_1249 = linked_1252.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1251, arg_1254) }; var arg_1250 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000104); var tmp5 any; var root_1255 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = s__292000105__3; if linked_1256 == nil { tmp5 = ifn_1257.Invoke_O__O(arg_1258) } else { tmp5 = linked_1256.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1255, arg_1258) }; arg_1250 = tmp4.Invoke_O__O(tmp5); if linked_1247 == nil { return ifn_1248.Invoke_O_O__O(arg_1249, arg_1250) } else { return linked_1247.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1246, arg_1249, arg_1250) } } else { var root_1259 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any; var root_1264 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = b__292000107__6; if linked_1265 == nil { arg_1262 = ifn_1266.Invoke_O__O(arg_1267) } else { arg_1262 = linked_1265.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1264, arg_1267) }; var arg_1263 any; if linked_1260 == nil { return ifn_1261.Invoke_O_O__O(arg_1262, arg_1263) } else { return linked_1260.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1259, arg_1262, arg_1263) } } } else { var p__4 any; var root_1268 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = s__292000105__3; if linked_1269 == nil { p__4 = ifn_1270.Invoke_O__O(arg_1271) } else { p__4 = linked_1269.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1268, arg_1271) }; var g__5 any; var root_1272 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = p__4; if linked_1273 == nil { g__5 = ifn_1274.Invoke_O__O(arg_1275) } else { g__5 = linked_1273.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1272, arg_1275) }; var root_1276 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_214; var tmp8 any; var root_1281 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1283 lang.IFn
														if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = A_arbace_j2g_dyncf_A_const_31; var arg_1285 any = p__4; var arg_1286 any = Lit_159; if linked_1282 == nil { tmp8 = ifn_1283.Invoke_O_O_O__O(arg_1284, arg_1285, arg_1286) } else { tmp8 = linked_1282.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1281, arg_1284, arg_1285, arg_1286) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_215; var tmp12 any; var root_1287 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1289 lang.IFn
														if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_134, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_1288 == nil { tmp12 = ifn_1289.Invoke_O__O(arg_1290) } else { tmp12 = linked_1288.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1287, arg_1290) }
//line :156:1
	arg_1279 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12))
//line :155:1
	var arg_1280 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__292000104); var tmp14 any; var root_1291 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = s__292000105__3; if linked_1292 == nil { tmp14 = ifn_1293.Invoke_O__O(arg_1294) } else { tmp14 = linked_1292.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1291, arg_1294) }; arg_1280 = tmp13.Invoke_O__O(tmp14); if linked_1277 == nil { return ifn_1278.Invoke_O_O__O(arg_1279, arg_1280) } else { return linked_1277.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1276, arg_1279, arg_1280) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :155:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :155:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A) Ctor_O_I_O(c__b__292000107 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000107 = c__b__292000107; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :155:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A) Invoke_O__O(self any) any { { var i__292000106__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000106__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000106__1)); var g__3 any; var root_1225 any = A_arbace_j2g_dyncf_A_const_36.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = p__2; if linked_1226 == nil { g__3 = ifn_1227.Invoke_O__O(arg_1228) } else { g__3 = linked_1226.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_1225, arg_1228) }; var root_1229 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = t.F_b__292000107; var arg_1233 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_214; var tmp4 any; var root_1234 any = A_arbace_j2g_dyncf_A_const_53.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1236 lang.IFn
																if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = A_arbace_j2g_dyncf_A_const_31; var arg_1238 any = p__2; var arg_1239 any = Lit_159; if linked_1235 == nil { tmp4 = ifn_1236.Invoke_O_O_O__O(arg_1237, arg_1238, arg_1239) } else { tmp4 = linked_1235.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1234, arg_1237, arg_1238, arg_1239) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_215; var tmp8 any; var root_1240 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1242 lang.IFn
																if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_134, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_1241 == nil { tmp8 = ifn_1242.Invoke_O__O(arg_1243) } else { tmp8 = linked_1241.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1240, arg_1243) }
//line :156:1
	arg_1233 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))
//line :155:1
	if linked_1230 == nil { ifn_1231.Invoke_O_O__O(arg_1232, arg_1233) } else { linked_1230.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1229, arg_1232, arg_1233) }; i__292000106__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000106__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_forms_A_New() *A_arbace_j2g_dyncf_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_forms_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_j2g_dyncf_forms_A) Ctor() {}
//line :160:1
func (t *A_arbace_j2g_dyncf_forms_A) Invoke_O_O__O(self, T__0_ any) any {


	var root_1299 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any; var root_1304 any = A_arbace_j2g_dyncf_A_const_217.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, A_arbace_j2g_dyncf_subs_forms_A_fn_class); var ifn_1306 lang.IFn
	if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = T__0_; if linked_1305 == nil { arg_1302 = ifn_1306.Invoke_O__O(arg_1307) } else { arg_1302 = linked_1305.(*A_arbace_j2g_dyncf_subs_forms_A).Invoke_O_O__O(root_1304, arg_1307) }
//line :163:1
	var arg_1303 any; var tmp1 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_222, Lit_1); var tmp2 any = A_arbace_j2g_dyncf_A_const_218; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyncf_A_const_223; var tmp5 any; var root_1308 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1310 lang.IFn














	if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = Lit_2; var arg_1312 any = Lit_3; if linked_1309 == nil { tmp5 = ifn_1310.Invoke_O_O__O(arg_1311, arg_1312) } else { tmp5 = linked_1309.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1308, arg_1311, arg_1312) }
//line :163:1
	var tmp6 any = tmp5; var tmp7 any; var root_1313 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1315 lang.IFn















	if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var tmp8 any; var root_1318 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = A_arbace_j2g_dyncf_A_const_225; var arg_1322 any = A_arbace_j2g_dyncf_A_const_226; if linked_1319 == nil { tmp8 = ifn_1320.Invoke_O_O__O(arg_1321, arg_1322) } else { tmp8 = linked_1319.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1318, arg_1321, arg_1322) }; var tmp9 any = tmp8; var tmp10 any; var root_1323 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = A_arbace_j2g_dyncf_A_const_227; var arg_1327 any = A_arbace_j2g_dyncf_A_const_228; if linked_1324 == nil { tmp10 = ifn_1325.Invoke_O_O__O(arg_1326, arg_1327) } else { tmp10 = linked_1324.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1323, arg_1326, arg_1327) }; var tmp11 any = tmp10; var tmp12 any; var root_1328 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = A_arbace_j2g_dyncf_A_const_229; var arg_1332 any = A_arbace_j2g_dyncf_A_const_230; if linked_1329 == nil { tmp12 = ifn_1330.Invoke_O_O__O(arg_1331, arg_1332) } else { tmp12 = linked_1329.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1328, arg_1331, arg_1332) }; var tmp13 any = tmp12; var tmp14 any; var root_1333 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1335 lang.IFn
	if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = A_arbace_j2g_dyncf_A_const_231; var arg_1337 any = A_arbace_j2g_dyncf_A_const_232; if linked_1334 == nil { tmp14 = ifn_1335.Invoke_O_O__O(arg_1336, arg_1337) } else { tmp14 = linked_1334.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1333, arg_1336, arg_1337) }
//line :179:1
	var tmp15 any = tmp14; var tmp16 any; var root_1338 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1340 lang.IFn
	if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = A_arbace_j2g_dyncf_A_const_233; var arg_1342 any = A_arbace_j2g_dyncf_A_const_234; if linked_1339 == nil { tmp16 = ifn_1340.Invoke_O_O__O(arg_1341, arg_1342) } else { tmp16 = linked_1339.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1338, arg_1341, arg_1342) }
//line :179:1
	var tmp17 any = tmp16; var tmp18 any; var root_1343 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1345 lang.IFn
	if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = A_arbace_j2g_dyncf_A_const_235; var arg_1347 any = A_arbace_j2g_dyncf_A_const_236; if linked_1344 == nil { tmp18 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { tmp18 = linked_1344.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }
//line :179:1
	arg_1316 = lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp9, tmp11, tmp13, tmp15, tmp17, tmp18); var arg_1317 any = A_arbace_j2g_dyncf_A_const_237; if linked_1314 == nil { tmp7 = ifn_1315.Invoke_O_O__O(arg_1316, arg_1317) } else { tmp7 = linked_1314.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1313, arg_1316, arg_1317) }
//line :163:1
	var tmp19 any = tmp3.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, A_arbace_j2g_dyncf_A_const_238); var tmp20 any = A_arbace_j2g_dyncf_A_const_219; var tmp21 any = A_arbace_j2g_dyncf_A_const_220; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_239; var tmp24 any; var root_1348 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1350 lang.IFn















































































	if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = Lit_4; var arg_1352 any = Lit_5; if linked_1349 == nil { tmp24 = ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { tmp24 = linked_1349.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) }
//line :163:1
	var tmp25 any = tmp24; var tmp26 any; var root_1353 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1355 lang.IFn
















































































	if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var tmp27 any; var root_1358 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = A_arbace_j2g_dyncf_A_const_240; var arg_1362 any = A_arbace_j2g_dyncf_A_const_241; if linked_1359 == nil { tmp27 = ifn_1360.Invoke_O_O__O(arg_1361, arg_1362) } else { tmp27 = linked_1359.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1358, arg_1361, arg_1362) }; var tmp28 any = tmp27; var tmp29 any; var root_1363 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = A_arbace_j2g_dyncf_A_const_242; var arg_1367 any = A_arbace_j2g_dyncf_A_const_243; if linked_1364 == nil { tmp29 = ifn_1365.Invoke_O_O__O(arg_1366, arg_1367) } else { tmp29 = linked_1364.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1363, arg_1366, arg_1367) }; arg_1356 = lang.Tuple_Create_O_O__IPersistentVector(tmp28, tmp29); var arg_1357 any = A_arbace_j2g_dyncf_A_const_244; if linked_1354 == nil { tmp26 = ifn_1355.Invoke_O_O__O(arg_1356, arg_1357) } else { tmp26 = linked_1354.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1353, arg_1356, arg_1357) }
//line :163:1
	var tmp30 any = tmp22.Invoke_O_O_O_O__O(tmp23, tmp25, tmp26, A_arbace_j2g_dyncf_A_const_245); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_dyncf_A_const_246; var tmp33 any; var root_1368 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1370 lang.IFn























































































	if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = Lit_6; var arg_1372 any = Lit_7; if linked_1369 == nil { tmp33 = ifn_1370.Invoke_O_O__O(arg_1371, arg_1372) } else { tmp33 = linked_1369.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1368, arg_1371, arg_1372) }
//line :163:1
	var tmp34 any = tmp33; var tmp35 any; var root_1373 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1375 lang.IFn
























































































	if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any; var tmp36 any; var root_1378 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = A_arbace_j2g_dyncf_A_const_247; var arg_1382 any = A_arbace_j2g_dyncf_A_const_248; if linked_1379 == nil { tmp36 = ifn_1380.Invoke_O_O__O(arg_1381, arg_1382) } else { tmp36 = linked_1379.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1378, arg_1381, arg_1382) }; arg_1376 = lang.Tuple_Create_O__IPersistentVector(tmp36); var arg_1377 any = A_arbace_j2g_dyncf_A_const_249; if linked_1374 == nil { tmp35 = ifn_1375.Invoke_O_O__O(arg_1376, arg_1377) } else { tmp35 = linked_1374.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1373, arg_1376, arg_1377) }
//line :163:1
	var tmp37 any = tmp31.Invoke_O_O_O_O__O(tmp32, tmp34, tmp35, A_arbace_j2g_dyncf_A_const_250); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp39 any = A_arbace_j2g_dyncf_A_const_251; var tmp40 any; var root_1383 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1385 lang.IFn



























































































	if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = Lit_8; var arg_1387 any = Lit_9; if linked_1384 == nil { tmp40 = ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { tmp40 = linked_1384.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) }
//line :163:1
	var tmp41 any = tmp40; var tmp42 any; var root_1388 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1390 lang.IFn




























































































	if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = A_arbace_j2g_dyncf_A_const_253; var arg_1392 any = A_arbace_j2g_dyncf_A_const_254; if linked_1389 == nil { tmp42 = ifn_1390.Invoke_O_O__O(arg_1391, arg_1392) } else { tmp42 = linked_1389.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1388, arg_1391, arg_1392) }
//line :163:1
	var tmp43 any = tmp42; var tmp44 any; var root_1393 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1395 lang.IFn




























































































	if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = A_arbace_j2g_dyncf_A_const_255; var arg_1397 any = A_arbace_j2g_dyncf_A_const_256; if linked_1394 == nil { tmp44 = ifn_1395.Invoke_O_O__O(arg_1396, arg_1397) } else { tmp44 = linked_1394.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1393, arg_1396, arg_1397) }
//line :163:1
	var tmp45 any = tmp44; var tmp46 any; var root_1398 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1400 lang.IFn




























































































	if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = A_arbace_j2g_dyncf_A_const_257; var arg_1402 any = A_arbace_j2g_dyncf_A_const_258; if linked_1399 == nil { tmp46 = ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { tmp46 = linked_1399.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) }
//line :163:1
	var tmp47 any = tmp46; var tmp48 any; var root_1403 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1405 lang.IFn




























































































	if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = A_arbace_j2g_dyncf_A_const_259; var arg_1407 any = A_arbace_j2g_dyncf_A_const_260; if linked_1404 == nil { tmp48 = ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { tmp48 = linked_1404.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) }
//line :163:1
	var tmp49 any = tmp38.Invoke_O_O_O_O__O(tmp39, tmp41, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp43, tmp45, tmp47, tmp48), A_arbace_j2g_dyncf_A_const_252); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp51 any = A_arbace_j2g_dyncf_A_const_261; var tmp52 any; var root_1408 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1410 lang.IFn



































































































	if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = Lit_10; var arg_1412 any = Lit_11; if linked_1409 == nil { tmp52 = ifn_1410.Invoke_O_O__O(arg_1411, arg_1412) } else { tmp52 = linked_1409.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1408, arg_1411, arg_1412) }
//line :163:1
	var tmp53 any = tmp52; var tmp54 any; var root_1413 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1415 lang.IFn




































































































	if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any; var tmp55 any; var root_1418 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = A_arbace_j2g_dyncf_A_const_262; var arg_1422 any = A_arbace_j2g_dyncf_A_const_263; if linked_1419 == nil { tmp55 = ifn_1420.Invoke_O_O__O(arg_1421, arg_1422) } else { tmp55 = linked_1419.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1418, arg_1421, arg_1422) }; var tmp56 any = tmp55; var tmp57 any; var root_1423 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = A_arbace_j2g_dyncf_A_const_264; var arg_1427 any = A_arbace_j2g_dyncf_A_const_265; if linked_1424 == nil { tmp57 = ifn_1425.Invoke_O_O__O(arg_1426, arg_1427) } else { tmp57 = linked_1424.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1423, arg_1426, arg_1427) }; var tmp58 any = tmp57; var tmp59 any; var root_1428 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = A_arbace_j2g_dyncf_A_const_266; var arg_1432 any = A_arbace_j2g_dyncf_A_const_267; if linked_1429 == nil { tmp59 = ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { tmp59 = linked_1429.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }; var tmp60 any = tmp59; var tmp61 any; var root_1433 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = A_arbace_j2g_dyncf_A_const_268; var arg_1437 any = A_arbace_j2g_dyncf_A_const_269; if linked_1434 == nil { tmp61 = ifn_1435.Invoke_O_O__O(arg_1436, arg_1437) } else { tmp61 = linked_1434.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1433, arg_1436, arg_1437) }; arg_1416 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp56, tmp58, tmp60, tmp61); var arg_1417 any = A_arbace_j2g_dyncf_A_const_270; if linked_1414 == nil { tmp54 = ifn_1415.Invoke_O_O__O(arg_1416, arg_1417) } else { tmp54 = linked_1414.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1413, arg_1416, arg_1417) }
//line :163:1
	var tmp62 any = tmp50.Invoke_O_O_O_O__O(tmp51, tmp53, tmp54, A_arbace_j2g_dyncf_A_const_271); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyncf_A_const_272; var tmp65 any; var root_1438 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1440 lang.IFn











































































































	if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = Lit_12; var arg_1442 any = Lit_13; if linked_1439 == nil { tmp65 = ifn_1440.Invoke_O_O__O(arg_1441, arg_1442) } else { tmp65 = linked_1439.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1438, arg_1441, arg_1442) }
//line :163:1
	var tmp66 any = tmp65; var tmp67 any; var root_1443 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1445 lang.IFn












































































































	if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any; var tmp68 any; var root_1448 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = A_arbace_j2g_dyncf_A_const_273; var arg_1452 any = A_arbace_j2g_dyncf_A_const_274; if linked_1449 == nil { tmp68 = ifn_1450.Invoke_O_O__O(arg_1451, arg_1452) } else { tmp68 = linked_1449.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1448, arg_1451, arg_1452) }; var tmp69 any = tmp68; var tmp70 any; var root_1453 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = A_arbace_j2g_dyncf_A_const_275; var arg_1457 any = A_arbace_j2g_dyncf_A_const_276; if linked_1454 == nil { tmp70 = ifn_1455.Invoke_O_O__O(arg_1456, arg_1457) } else { tmp70 = linked_1454.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1453, arg_1456, arg_1457) }; var tmp71 any = tmp70; var tmp72 any; var root_1458 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = A_arbace_j2g_dyncf_A_const_277; var arg_1462 any = A_arbace_j2g_dyncf_A_const_278; if linked_1459 == nil { tmp72 = ifn_1460.Invoke_O_O__O(arg_1461, arg_1462) } else { tmp72 = linked_1459.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1458, arg_1461, arg_1462) }; var tmp73 any = tmp72; var tmp74 any; var root_1463 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = A_arbace_j2g_dyncf_A_const_279; var arg_1467 any = A_arbace_j2g_dyncf_A_const_280; if linked_1464 == nil { tmp74 = ifn_1465.Invoke_O_O__O(arg_1466, arg_1467) } else { tmp74 = linked_1464.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1463, arg_1466, arg_1467) }; var tmp75 any = tmp74; var tmp76 any; var root_1468 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = A_arbace_j2g_dyncf_A_const_281; var arg_1472 any = A_arbace_j2g_dyncf_A_const_282; if linked_1469 == nil { tmp76 = ifn_1470.Invoke_O_O__O(arg_1471, arg_1472) } else { tmp76 = linked_1469.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1468, arg_1471, arg_1472) }; arg_1446 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp69, tmp71, tmp73, tmp75, tmp76); var arg_1447 any = A_arbace_j2g_dyncf_A_const_283; if linked_1444 == nil { tmp67 = ifn_1445.Invoke_O_O__O(arg_1446, arg_1447) } else { tmp67 = linked_1444.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1443, arg_1446, arg_1447) }
//line :163:1
	var tmp77 any = tmp63.Invoke_O_O_O_O__O(tmp64, tmp66, tmp67, A_arbace_j2g_dyncf_A_const_284); var tmp78 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp79 any = A_arbace_j2g_dyncf_A_const_285; var tmp80 any; var root_1473 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1475 lang.IFn



















































































































	if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = Lit_14; var arg_1477 any = Lit_15; if linked_1474 == nil { tmp80 = ifn_1475.Invoke_O_O__O(arg_1476, arg_1477) } else { tmp80 = linked_1474.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1473, arg_1476, arg_1477) }
//line :163:1
	var tmp81 any = tmp80; var tmp82 any; var root_1478 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1480 lang.IFn




















































































































	if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = A_arbace_j2g_dyncf_A_const_287; var arg_1482 any = A_arbace_j2g_dyncf_A_const_288; if linked_1479 == nil { tmp82 = ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { tmp82 = linked_1479.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) }
//line :163:1
	var tmp83 any = tmp82; var tmp84 any; var root_1483 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1485 lang.IFn




















































































































	if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = A_arbace_j2g_dyncf_A_const_289; var arg_1487 any = A_arbace_j2g_dyncf_A_const_290; if linked_1484 == nil { tmp84 = ifn_1485.Invoke_O_O__O(arg_1486, arg_1487) } else { tmp84 = linked_1484.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1483, arg_1486, arg_1487) }
//line :163:1
	var tmp85 any = tmp84; var tmp86 any; var root_1488 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1490 lang.IFn




















































































































	if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = A_arbace_j2g_dyncf_A_const_291; var arg_1492 any = A_arbace_j2g_dyncf_A_const_292; if linked_1489 == nil { tmp86 = ifn_1490.Invoke_O_O__O(arg_1491, arg_1492) } else { tmp86 = linked_1489.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1488, arg_1491, arg_1492) }
//line :163:1
	var tmp87 any = tmp78.Invoke_O_O_O_O__O(tmp79, tmp81, lang.Tuple_Create_O_O_O__IPersistentVector(tmp83, tmp85, tmp86), A_arbace_j2g_dyncf_A_const_286); var tmp88 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp89 any = A_arbace_j2g_dyncf_A_const_293; var tmp90 any; var root_1493 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1495 lang.IFn



























































































































	if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = Lit_16; var arg_1497 any = Lit_17; if linked_1494 == nil { tmp90 = ifn_1495.Invoke_O_O__O(arg_1496, arg_1497) } else { tmp90 = linked_1494.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1493, arg_1496, arg_1497) }
//line :163:1
	var tmp91 any = tmp90; var tmp92 any; var root_1498 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1500 lang.IFn




























































































































	if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = A_arbace_j2g_dyncf_A_const_295; var arg_1502 any = A_arbace_j2g_dyncf_A_const_296; if linked_1499 == nil { tmp92 = ifn_1500.Invoke_O_O__O(arg_1501, arg_1502) } else { tmp92 = linked_1499.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1498, arg_1501, arg_1502) }
//line :163:1
	var tmp93 any = tmp88.Invoke_O_O_O_O__O(tmp89, tmp91, lang.Tuple_Create_O__IPersistentVector(tmp92), A_arbace_j2g_dyncf_A_const_294); var tmp94 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp95 any = A_arbace_j2g_dyncf_A_const_297; var tmp96 any; var root_1503 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1505 lang.IFn


































































































































	if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = Lit_18; var arg_1507 any = Lit_19; if linked_1504 == nil { tmp96 = ifn_1505.Invoke_O_O__O(arg_1506, arg_1507) } else { tmp96 = linked_1504.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1503, arg_1506, arg_1507) }
//line :163:1
	var tmp97 any = tmp96; var tmp98 any; var root_1508 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1510 lang.IFn



































































































































	if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = A_arbace_j2g_dyncf_A_const_299; var arg_1512 any = A_arbace_j2g_dyncf_A_const_300; if linked_1509 == nil { tmp98 = ifn_1510.Invoke_O_O__O(arg_1511, arg_1512) } else { tmp98 = linked_1509.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1508, arg_1511, arg_1512) }
//line :163:1
	var tmp99 any = tmp98; var tmp100 any; var root_1513 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1515 lang.IFn



































































































































	if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = A_arbace_j2g_dyncf_A_const_301; var arg_1517 any = A_arbace_j2g_dyncf_A_const_302; if linked_1514 == nil { tmp100 = ifn_1515.Invoke_O_O__O(arg_1516, arg_1517) } else { tmp100 = linked_1514.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1513, arg_1516, arg_1517) }
//line :163:1
	var tmp101 any = tmp94.Invoke_O_O_O_O__O(tmp95, tmp97, lang.Tuple_Create_O_O__IPersistentVector(tmp99, tmp100), A_arbace_j2g_dyncf_A_const_298); var tmp102 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp103 any = A_arbace_j2g_dyncf_A_const_303; var tmp104 any; var root_1518 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1520 lang.IFn







































































































































	if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = Lit_20; var arg_1522 any = Lit_21; if linked_1519 == nil { tmp104 = ifn_1520.Invoke_O_O__O(arg_1521, arg_1522) } else { tmp104 = linked_1519.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1518, arg_1521, arg_1522) }
//line :163:1
	var tmp105 any = tmp104; var tmp106 any; var root_1523 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1525 lang.IFn








































































































































	if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any; var tmp107 any; var root_1528 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = A_arbace_j2g_dyncf_A_const_304; var arg_1532 any = A_arbace_j2g_dyncf_A_const_305; if linked_1529 == nil { tmp107 = ifn_1530.Invoke_O_O__O(arg_1531, arg_1532) } else { tmp107 = linked_1529.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1528, arg_1531, arg_1532) }; arg_1526 = lang.Tuple_Create_O__IPersistentVector(tmp107); var arg_1527 any = A_arbace_j2g_dyncf_A_const_306; if linked_1524 == nil { tmp106 = ifn_1525.Invoke_O_O__O(arg_1526, arg_1527) } else { tmp106 = linked_1524.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1523, arg_1526, arg_1527) }
//line :163:1
	var tmp108 any = tmp102.Invoke_O_O_O_O__O(tmp103, tmp105, tmp106, A_arbace_j2g_dyncf_A_const_307); var tmp109 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp110 any = A_arbace_j2g_dyncf_A_const_308; var tmp111 any; var root_1533 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1535 lang.IFn












































































































































	if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = Lit_22; var arg_1537 any = Lit_23; if linked_1534 == nil { tmp111 = ifn_1535.Invoke_O_O__O(arg_1536, arg_1537) } else { tmp111 = linked_1534.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1533, arg_1536, arg_1537) }
//line :163:1
	var tmp112 any = tmp111; var tmp113 any; var root_1538 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1540 lang.IFn













































































































































	if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = A_arbace_j2g_dyncf_A_const_310; var arg_1542 any = A_arbace_j2g_dyncf_A_const_311; if linked_1539 == nil { tmp113 = ifn_1540.Invoke_O_O__O(arg_1541, arg_1542) } else { tmp113 = linked_1539.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1538, arg_1541, arg_1542) }
//line :163:1
	var tmp114 any = tmp113; var tmp115 any; var root_1543 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1545 lang.IFn













































































































































	if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = A_arbace_j2g_dyncf_A_const_312; var arg_1547 any = A_arbace_j2g_dyncf_A_const_313; if linked_1544 == nil { tmp115 = ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { tmp115 = linked_1544.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) }
//line :163:1
	var tmp116 any = tmp115; var tmp117 any; var root_1548 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1550 lang.IFn













































































































































	if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = A_arbace_j2g_dyncf_A_const_314; var arg_1552 any = A_arbace_j2g_dyncf_A_const_315; if linked_1549 == nil { tmp117 = ifn_1550.Invoke_O_O__O(arg_1551, arg_1552) } else { tmp117 = linked_1549.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1548, arg_1551, arg_1552) }
//line :163:1
	var tmp118 any = tmp117; var tmp119 any; var root_1553 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1555 lang.IFn













































































































































	if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = A_arbace_j2g_dyncf_A_const_316; var arg_1557 any = A_arbace_j2g_dyncf_A_const_317; if linked_1554 == nil { tmp119 = ifn_1555.Invoke_O_O__O(arg_1556, arg_1557) } else { tmp119 = linked_1554.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1553, arg_1556, arg_1557) }
//line :163:1
	var tmp120 any = tmp119; var tmp121 any; var root_1558 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1560 lang.IFn














































































































































	if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = A_arbace_j2g_dyncf_A_const_318; var arg_1562 any = A_arbace_j2g_dyncf_A_const_319; if linked_1559 == nil { tmp121 = ifn_1560.Invoke_O_O__O(arg_1561, arg_1562) } else { tmp121 = linked_1559.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1558, arg_1561, arg_1562) }
//line :163:1
	var tmp122 any = tmp121; var tmp123 any; var root_1563 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1565 lang.IFn














































































































































	if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = A_arbace_j2g_dyncf_A_const_320; var arg_1567 any = A_arbace_j2g_dyncf_A_const_321; if linked_1564 == nil { tmp123 = ifn_1565.Invoke_O_O__O(arg_1566, arg_1567) } else { tmp123 = linked_1564.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1563, arg_1566, arg_1567) }
//line :163:1
	var tmp124 any = tmp109.Invoke_O_O_O_O__O(tmp110, tmp112, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp114, tmp116, tmp118, tmp120, tmp122, tmp123), A_arbace_j2g_dyncf_A_const_309); var tmp125 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp126 any = A_arbace_j2g_dyncf_A_const_322; var tmp127 any; var root_1568 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1570 lang.IFn


















































































































































































	if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = Lit_24; var arg_1572 any = Lit_25; if linked_1569 == nil { tmp127 = ifn_1570.Invoke_O_O__O(arg_1571, arg_1572) } else { tmp127 = linked_1569.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1568, arg_1571, arg_1572) }
//line :163:1
	var tmp128 any = tmp127; var tmp129 any; var root_1573 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1575 lang.IFn



















































































































































































	if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = A_arbace_j2g_dyncf_A_const_324; var arg_1577 any = A_arbace_j2g_dyncf_A_const_325; if linked_1574 == nil { tmp129 = ifn_1575.Invoke_O_O__O(arg_1576, arg_1577) } else { tmp129 = linked_1574.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1573, arg_1576, arg_1577) }
//line :163:1
	var tmp130 any = tmp129; var tmp131 any; var root_1578 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1580 lang.IFn



















































































































































































	if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = A_arbace_j2g_dyncf_A_const_326; var arg_1582 any = A_arbace_j2g_dyncf_A_const_327; if linked_1579 == nil { tmp131 = ifn_1580.Invoke_O_O__O(arg_1581, arg_1582) } else { tmp131 = linked_1579.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1578, arg_1581, arg_1582) }
//line :163:1
	var tmp132 any = tmp131; var tmp133 any; var root_1583 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1585 lang.IFn



















































































































































































	if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = A_arbace_j2g_dyncf_A_const_328; var arg_1587 any = A_arbace_j2g_dyncf_A_const_329; if linked_1584 == nil { tmp133 = ifn_1585.Invoke_O_O__O(arg_1586, arg_1587) } else { tmp133 = linked_1584.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1583, arg_1586, arg_1587) }
//line :163:1
	var tmp134 any = tmp133; var tmp135 any; var root_1588 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1590 lang.IFn



















































































































































































	if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = A_arbace_j2g_dyncf_A_const_330; var arg_1592 any = A_arbace_j2g_dyncf_A_const_331; if linked_1589 == nil { tmp135 = ifn_1590.Invoke_O_O__O(arg_1591, arg_1592) } else { tmp135 = linked_1589.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1588, arg_1591, arg_1592) }
//line :163:1
	var tmp136 any = tmp125.Invoke_O_O_O_O__O(tmp126, tmp128, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp130, tmp132, tmp134, tmp135), A_arbace_j2g_dyncf_A_const_323); var tmp137 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp138 any = A_arbace_j2g_dyncf_A_const_332; var tmp139 any; var root_1593 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1595 lang.IFn

























































































































































































	if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = Lit_26; var arg_1597 any = Lit_27; if linked_1594 == nil { tmp139 = ifn_1595.Invoke_O_O__O(arg_1596, arg_1597) } else { tmp139 = linked_1594.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1593, arg_1596, arg_1597) }
//line :163:1
	var tmp140 any = tmp139; var tmp141 any; var root_1598 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1600 lang.IFn


























































































































































































	if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = A_arbace_j2g_dyncf_A_const_334; var arg_1602 any = A_arbace_j2g_dyncf_A_const_335; if linked_1599 == nil { tmp141 = ifn_1600.Invoke_O_O__O(arg_1601, arg_1602) } else { tmp141 = linked_1599.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1598, arg_1601, arg_1602) }
//line :163:1
	var tmp142 any = tmp141; var tmp143 any; var root_1603 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1605 lang.IFn


























































































































































































	if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = A_arbace_j2g_dyncf_A_const_336; var arg_1607 any = A_arbace_j2g_dyncf_A_const_337; if linked_1604 == nil { tmp143 = ifn_1605.Invoke_O_O__O(arg_1606, arg_1607) } else { tmp143 = linked_1604.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1603, arg_1606, arg_1607) }
//line :163:1
	var tmp144 any = tmp143; var tmp145 any; var root_1608 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1610 lang.IFn


























































































































































































	if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = A_arbace_j2g_dyncf_A_const_338; var arg_1612 any = A_arbace_j2g_dyncf_A_const_339; if linked_1609 == nil { tmp145 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { tmp145 = linked_1609.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) }
//line :163:1
	var tmp146 any = tmp145; var tmp147 any; var root_1613 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1615 lang.IFn


























































































































































































	if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = A_arbace_j2g_dyncf_A_const_340; var arg_1617 any = A_arbace_j2g_dyncf_A_const_341; if linked_1614 == nil { tmp147 = ifn_1615.Invoke_O_O__O(arg_1616, arg_1617) } else { tmp147 = linked_1614.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1613, arg_1616, arg_1617) }
//line :163:1
	var tmp148 any = tmp147; var tmp149 any; var root_1618 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1620 lang.IFn


























































































































































































	if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = A_arbace_j2g_dyncf_A_const_342; var arg_1622 any = A_arbace_j2g_dyncf_A_const_343; if linked_1619 == nil { tmp149 = ifn_1620.Invoke_O_O__O(arg_1621, arg_1622) } else { tmp149 = linked_1619.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1618, arg_1621, arg_1622) }
//line :163:1
	var tmp150 any = tmp137.Invoke_O_O_O_O__O(tmp138, tmp140, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp142, tmp144, tmp146, tmp148, tmp149), A_arbace_j2g_dyncf_A_const_333); var tmp151 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_27.GetRawRoot__O()); var tmp152 any = A_arbace_j2g_dyncf_A_const_344; var tmp153 any; var root_1623 any = A_arbace_j2g_dyncf_A_const_224.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1625 lang.IFn


































































































































































































	if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = Lit_28; var arg_1627 any = Lit_29; if linked_1624 == nil { tmp153 = ifn_1625.Invoke_O_O__O(arg_1626, arg_1627) } else { tmp153 = linked_1624.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1623, arg_1626, arg_1627) }
//line :163:1
	var tmp154 any = tmp153; var tmp155 any; var root_1628 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1630 lang.IFn



































































































































































































	if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = A_arbace_j2g_dyncf_A_const_345; var arg_1632 any = A_arbace_j2g_dyncf_A_const_346; if linked_1629 == nil { tmp155 = ifn_1630.Invoke_O_O__O(arg_1631, arg_1632) } else { tmp155 = linked_1629.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1628, arg_1631, arg_1632) }
//line :163:1
	var tmp156 any = tmp155; var tmp157 any; var root_1633 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1635 lang.IFn



































































































































































































	if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = A_arbace_j2g_dyncf_A_const_347; var arg_1637 any = A_arbace_j2g_dyncf_A_const_348; if linked_1634 == nil { tmp157 = ifn_1635.Invoke_O_O__O(arg_1636, arg_1637) } else { tmp157 = linked_1634.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1633, arg_1636, arg_1637) }
//line :163:1
	var tmp158 any = tmp157; var tmp159 any; var root_1638 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1640 lang.IFn



































































































































































































	if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = A_arbace_j2g_dyncf_A_const_349; var arg_1642 any = A_arbace_j2g_dyncf_A_const_350; if linked_1639 == nil { tmp159 = ifn_1640.Invoke_O_O__O(arg_1641, arg_1642) } else { tmp159 = linked_1639.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1638, arg_1641, arg_1642) }
//line :163:1
	var tmp160 any = tmp159; var tmp161 any; var root_1643 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1645 lang.IFn



































































































































































































	if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = A_arbace_j2g_dyncf_A_const_351; var arg_1647 any = A_arbace_j2g_dyncf_A_const_352; if linked_1644 == nil { tmp161 = ifn_1645.Invoke_O_O__O(arg_1646, arg_1647) } else { tmp161 = linked_1644.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1643, arg_1646, arg_1647) }
//line :163:1
	var tmp162 any = tmp161; var tmp163 any; var root_1648 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1650 lang.IFn




































































































































































































	if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = A_arbace_j2g_dyncf_A_const_353; var arg_1652 any = A_arbace_j2g_dyncf_A_const_354; if linked_1649 == nil { tmp163 = ifn_1650.Invoke_O_O__O(arg_1651, arg_1652) } else { tmp163 = linked_1649.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1648, arg_1651, arg_1652) }
//line :163:1
	var tmp164 any = tmp163; var tmp165 any; var root_1653 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1655 lang.IFn




































































































































































































	if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = A_arbace_j2g_dyncf_A_const_355; var arg_1657 any = A_arbace_j2g_dyncf_A_const_356; if linked_1654 == nil { tmp165 = ifn_1655.Invoke_O_O__O(arg_1656, arg_1657) } else { tmp165 = linked_1654.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1653, arg_1656, arg_1657) }
//line :163:1
	var tmp166 any = tmp165; var tmp167 any; var root_1658 any = A_arbace_j2g_dyncf_A_const_44.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1660 lang.IFn




































































































































































































	if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = A_arbace_j2g_dyncf_A_const_357; var arg_1662 any = A_arbace_j2g_dyncf_A_const_358; if linked_1659 == nil { tmp167 = ifn_1660.Invoke_O_O__O(arg_1661, arg_1662) } else { tmp167 = linked_1659.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1658, arg_1661, arg_1662) }
//line :163:1
	arg_1303 = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp19, tmp20, tmp21, tmp30, tmp37, tmp49, tmp62, tmp77, tmp87, tmp93, tmp101, tmp108, tmp124, tmp136, tmp150, tmp151.Invoke_O_O_O_O__O(tmp152, tmp154, lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp156, tmp158, tmp160, tmp162, tmp164, tmp166, tmp167)), A_arbace_j2g_dyncf_A_const_359), A_arbace_j2g_dyncf_A_const_221)); if linked_1300 == nil { return ifn_1301.Invoke_O_O__O(arg_1302, arg_1303) } else { return linked_1300.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1299, arg_1302, arg_1303)
	}
}

























































































































































































































func A_arbace_j2g_dyncf_strip_anns_A_New() *A_arbace_j2g_dyncf_strip_anns_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_A{}; t.Ctor(); return t }
//line :383:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Ctor() {}
//line :383:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Invoke_O_O__O(self, x__0 any) any {
	var root_1663 any = A_arbace_j2g_dyncf_A_const_360.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_walk.A_arbace_walk_postwalk_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any; var fnbody__1678 any = A_arbace_j2g_dyncf_strip_anns_fn__292000116_A_New(); var tmp1 *jrt.Class; var fncls__1677 *jrt.Class = A_arbace_j2g_dyncf_strip_anns_fn__292000116_A_fn_class; if fncls__1677 == nil { var fncls__1677d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_j2g_dyncf_strip_anns_fn__292000116_A_fn_class = fncls__1677d; tmp1 = fncls__1677d } else { tmp1 = fncls__1677 }; arg_1666 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1678, tmp1, nil); var arg_1667 any = x__0; if linked_1664 == nil { return ifn_1665.Invoke_O_O__O(arg_1666, arg_1667) } else { return linked_1664.(*aot_arbace_walk.A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_1663, arg_1666, arg_1667) } }
//line :384:1
func A_arbace_j2g_dyncf_strip_anns_fn__292000116_A_New() *A_arbace_j2g_dyncf_strip_anns_fn__292000116_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_fn__292000116_A{}; t.Ctor(); return t }
//line :384:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000116_A) Ctor() {}
//line :384:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000116_A) Invoke_O_O__O(self, y__1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_1668 any = A_arbace_j2g_dyncf_A_const_361.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = y__1; if linked_1669 == nil { and__1927000168__auto____2 = ifn_1670.Invoke_O__O(arg_1671) } else { and__1927000168__auto____2 = linked_1669.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1668, arg_1671) }; if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = A_arbace_j2g_dyncf_A_const_362.Invoke_O__O(y__1) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_1672 any = A_arbace_j2g_dyncf_A_const_363.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = y__1; var arg_1676 any = A_arbace_j2g_dyncf_A_const_362; if linked_1673 == nil { return ifn_1674.Invoke_O_O__O(arg_1675, arg_1676) } else { return linked_1673.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1672, arg_1675, arg_1676) } } else { return y__1 } }



func A_arbace_j2g_dyncf_protected_field_QMARK__A_New() *A_arbace_j2g_dyncf_protected_field_QMARK__A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_field_QMARK__A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_j2g_dyncf_protected_field_QMARK__A) Ctor() {}
//line :388:1
func (t *A_arbace_j2g_dyncf_protected_field_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var fl__2 any; var or__1927000174__auto____2 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__0); if



	jrt.J2g_Truth(or__1927000174__auto____2) { fl__2 = or__1927000174__auto____2 } else { fl__2 = A_arbace_j2g_dyncf_A_const_365 }; var and__1927000168__auto____3 bool; var tmp1 int64; var na_1679 any = fl__2; var na_1680 any = /*line :388:1*/A_arbace_j2g_dyncf_A_const_366.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 =




	jrt.Long_InstanceOf(na_1679); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1680) }; tmp2 = tmp3; if tmp2 { var n0_1681 int64 = jrt.NN(jrt.Long_Cast(na_1679)).LongValue__J(); var n1_1682 int64 = jrt.NN(jrt.Long_Cast(na_1680)).LongValue__J(); tmp1 = n0_1681 & n1_1682 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_1679, na_1680) }; and__1927000168__auto____3 = lang.Numbers_IsPos_J__Z_NoInit(tmp1); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool; var tmp4 int64; var na_1684 any = fl__2; var na_1685 int64 = 9; if jrt.Long_InstanceOf(na_1684) { var n0_1686 int64 = jrt.NN(jrt.Long_Cast(na_1684)).LongValue__J(); var n1_1687 int64 = na_1685; tmp4 = n0_1686 & n1_1687 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_1684, na_1685) }; and__1927000168__auto____4 = lang.Numbers_IsZero_J__Z_NoInit(tmp4); if and__1927000168__auto____4 { var root_1689 any = A_arbace_j2g_dyncf_A_const_367.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, aot_arbace_j2g_model.A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__0); if linked_1690 == nil { return ifn_1691.Invoke_O__O(arg_1692) } else { return linked_1690.(*aot_arbace_j2g_model.A_arbace_j2g_model_desc_in_world_QMARK__A).Invoke_O_O__O(root_1689, arg_1692) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

func A_arbace_j2g_dyncf_protected_chain_A_New() *A_arbace_j2g_dyncf_protected_chain_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_j2g_dyncf_protected_chain_A) Ctor() {}
//line :395:1
func (t *A_arbace_j2g_dyncf_protected_chain_A) Invoke_O_O__O(self, T__0_ any) any {



	var root_1693 any = A_arbace_j2g_dyncf_A_const_368.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any; var root_1697 any = A_arbace_j2g_dyncf_A_const_369.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any; var iter__1927001039__auto____2 any; var fnbody__1809 any = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A_New(); var tmp1 *jrt.Class; var fncls__1808 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A_fn_class; if fncls__1808 == nil { var fncls__1808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, nil); A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A_fn_class = fncls__1808d; tmp1 = fncls__1808d } else { tmp1 = fncls__1808 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1809, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_1810 any = A_arbace_j2g_dyncf_A_const_193.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = T__0_; if linked_1811 == nil { tmp3 = ifn_1812.Invoke_O__O(arg_1813) } else { tmp3 = linked_1811.(*aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_1810, arg_1813) }; arg_1700 = tmp2.Invoke_O__O(tmp3); if linked_1698 == nil { arg_1696 = ifn_1699.Invoke_O__O(arg_1700) } else { arg_1696 = linked_1698.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1697, arg_1700) }; if linked_1694 == nil { return ifn_1695.Invoke_O__O(arg_1696) } else { return linked_1694.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1693, arg_1696) } }
//line :399:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A_New() *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A{}; t.Ctor(); return t }
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A) Ctor() {}
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A) Invoke_O_O__O(self, s__292000121__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1807 any = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A_New_O_O(self, s__292000121__1); var tmp2 *jrt.Class; var fncls__1806 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A_fn_class; if fncls__1806 == nil { var fncls__1806d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, fnbody__1807); A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A_fn_class = fncls__1806d; tmp2 = fncls__1806d } else { tmp2 = fncls__1806 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1807, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :399:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A) Ctor_O_O(c__iter__292000120, c__s__292000121 any) { t.F_iter__292000120 = c__iter__292000120; t.F_s__292000121 = c__s__292000121 }
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A) Invoke_O__O(self any) any { { var s__292000121__1 any; var t_ any = t.F_s__292000121; t.F_s__292000121 = nil; s__292000121__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1701 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = s__292000121__1; if linked_1702 == nil { temp__1927000414__auto____2 = ifn_1703.Invoke_O__O(arg_1704) } else { temp__1927000414__auto____2 = linked_1702.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1701, arg_1704) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var p__4 any; var root_1705 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = xs__1927001018__auto____3; if linked_1706 == nil { p__4 = ifn_1707.Invoke_O__O(arg_1708) } else { p__4 = linked_1706.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1705, arg_1708) }; var iterys__1927001035__auto____5 any; var fnbody__1784 any = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A_New(); var tmp1 *jrt.Class; var fncls__1783 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A_fn_class; if fncls__1783 == nil { var fncls__1783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A_fn_class = fncls__1783d; tmp1 = fncls__1783d } else { tmp1 = fncls__1783 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1784, tmp1, nil); var fs__1927001036__auto____6 any; var root_1785 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_1789 any = A_arbace_j2g_dyncf_A_const_192.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1791 lang.IFn
															if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = p__4; if linked_1790 == nil { tmp3 = ifn_1791.Invoke_O__O(arg_1792) } else { tmp3 = linked_1790.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1789, arg_1792) }
//line :399:1
	arg_1788 = tmp2.Invoke_O__O(tmp3); if linked_1786 == nil { fs__1927001036__auto____6 = ifn_1787.Invoke_O__O(arg_1788) } else { fs__1927001036__auto____6 = linked_1786.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1785, arg_1788) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1793 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1795 lang.IFn; if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = fs__1927001036__auto____6; var arg_1797 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000120); var tmp5 any; var root_1798 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = s__292000121__1; if linked_1799 == nil { tmp5 = ifn_1800.Invoke_O__O(arg_1801) } else { tmp5 = linked_1799.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1798, arg_1801) }; arg_1797 = tmp4.Invoke_O__O(tmp5); if linked_1794 == nil { return ifn_1795.Invoke_O_O__O(arg_1796, arg_1797) } else { return linked_1794.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1793, arg_1796, arg_1797) } } else { var tmp6 any; var root_1802 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1804 lang.IFn; if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = s__292000121__1; if linked_1803 == nil { tmp6 = ifn_1804.Invoke_O__O(arg_1805) } else { tmp6 = linked_1803.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1802, arg_1805) }; s__292000121__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :399:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A_New() *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A{}; t.Ctor(); return t }
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A) Ctor() {}
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A) Invoke_O_O__O(self, s__292000123__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1782 any = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A_New_O_O(self, s__292000123__1); var tmp2 *jrt.Class; var fncls__1781 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A_fn_class; if fncls__1781 == nil { var fncls__1781d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__1782); A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A_fn_class = fncls__1781d; tmp2 = fncls__1781d } else { tmp2 = fncls__1781 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1782, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :399:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A) Ctor_O_O(c__iter__292000122, c__s__292000123 any) { t.F_iter__292000122 = c__iter__292000122; t.F_s__292000123 = c__s__292000123 }
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A) Invoke_O__O(self any) any { { var s__292000123__1 any; var t_ any = t.F_s__292000123; t.F_s__292000123 = nil; s__292000123__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1709 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = s__292000123__1; if linked_1710 == nil { temp__1927000414__auto____2 = ifn_1711.Invoke_O__O(arg_1712) } else { temp__1927000414__auto____2 = linked_1710.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1709, arg_1712) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1713 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = s__292000123__3; if linked_1714 == nil { tmp1 = ifn_1715.Invoke_O__O(arg_1716) } else { tmp1 = linked_1714.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1713, arg_1716) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1717 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = s__292000123__3; if linked_1718 == nil { c__1927001037__auto____4 = ifn_1719.Invoke_O__O(arg_1720) } else { c__1927001037__auto____4 = linked_1718.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1717, arg_1720) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000125__6 any; var root_1721 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1722 == nil { b__292000125__6 = ifn_1723.Invoke_O__O(arg_1724) } else { b__292000125__6 = linked_1722.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1721, arg_1724) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1736 any = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A_New_O_I_O(b__292000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1735 *jrt.Class = A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A_fn_class; if fncls__1735 == nil { var fncls__1735d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__1736); A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A_fn_class = fncls__1735d; tmp3 = fncls__1735d } else { tmp3 = fncls__1735 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1736, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1737 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any; var root_1742 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = b__292000125__6; if linked_1743 == nil { arg_1740 = ifn_1744.Invoke_O__O(arg_1745) } else { arg_1740 = linked_1743.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1742, arg_1745) }; var arg_1741 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000122); var tmp5 any; var root_1746 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = s__292000123__3; if linked_1747 == nil { tmp5 = ifn_1748.Invoke_O__O(arg_1749) } else { tmp5 = linked_1747.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1746, arg_1749) }; arg_1741 = tmp4.Invoke_O__O(tmp5); if linked_1738 == nil { return ifn_1739.Invoke_O_O__O(arg_1740, arg_1741) } else { return linked_1738.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1737, arg_1740, arg_1741) } } else { var root_1750 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any; var root_1755 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1757 lang.IFn; if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = b__292000125__6; if linked_1756 == nil { arg_1753 = ifn_1757.Invoke_O__O(arg_1758) } else { arg_1753 = linked_1756.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1755, arg_1758) }; var arg_1754 any; if linked_1751 == nil { return ifn_1752.Invoke_O_O__O(arg_1753, arg_1754) } else { return linked_1751.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1750, arg_1753, arg_1754) } } } else { var c__4 any; var root_1759 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = s__292000123__3; if linked_1760 == nil { c__4 = ifn_1761.Invoke_O__O(arg_1762) } else { c__4 = linked_1760.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1759, arg_1762) }; var tmp6 any
																				var and__1927000168__auto____5 any = c__4
																				if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1763 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = c__4; var arg_1767 any = Lit_102; if linked_1764 == nil { tmp6 = ifn_1765.Invoke_O_O__O(arg_1766, arg_1767) } else { tmp6 = linked_1764.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1763, arg_1766, arg_1767) } } else { tmp6 = and__1927000168__auto____5 }
//line :399:1
	if jrt.J2g_Truth(tmp6) { var root_1768 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = c__4; var arg_1772 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000122); var tmp8 any; var root_1773 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = s__292000123__3; if linked_1774 == nil { tmp8 = ifn_1775.Invoke_O__O(arg_1776) } else { tmp8 = linked_1774.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1773, arg_1776) }; arg_1772 = tmp7.Invoke_O__O(tmp8); if linked_1769 == nil { return ifn_1770.Invoke_O_O__O(arg_1771, arg_1772) } else { return linked_1769.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1768, arg_1771, arg_1772) } } else { var tmp9 any; var root_1777 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = s__292000123__3; if linked_1778 == nil { tmp9 = ifn_1779.Invoke_O__O(arg_1780) } else { tmp9 = linked_1778.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1777, arg_1780) }; s__292000123__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :399:1
func A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A) Ctor_O_I_O(c__b__292000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000125 = c__b__292000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :399:1
func (t *A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A) Invoke_O__O(self any) any { { var i__292000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000124__1)); var tmp2 any
																						var and__1927000168__auto____3 any = c__2
																						if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1725 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = c__2; var arg_1729 any = Lit_102; if linked_1726 == nil { tmp2 = ifn_1727.Invoke_O_O__O(arg_1728, arg_1729) } else { tmp2 = linked_1726.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1725, arg_1728, arg_1729) } } else { tmp2 = and__1927000168__auto____3 }
//line :399:1
	if jrt.J2g_Truth(tmp2) { var root_1730 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = t.F_b__292000125; var arg_1734 any = c__2; if linked_1731 == nil { ifn_1732.Invoke_O_O__O(arg_1733, arg_1734) } else { linked_1731.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1730, arg_1733, arg_1734) }; i__292000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000124__1); continue L1 } else { i__292000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000124__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_protected_members_A_New() *A_arbace_j2g_dyncf_protected_members_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_j2g_dyncf_protected_members_A) Ctor() {}
//line :404:1
func (t *A_arbace_j2g_dyncf_protected_members_A) Invoke_O_O__O(self, T__0_ any) any { var iter__1927001039__auto____2 any; var fnbody__2551 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A_New(); var tmp1 *jrt.Class; var fncls__2550 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A_fn_class; if




	fncls__2550 == nil { var fncls__2550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A_fn_class = fncls__2550d; tmp1 = fncls__2550d } else { tmp1 = fncls__2550 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2551, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_2552 any = A_arbace_j2g_dyncf_A_const_375.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, A_arbace_j2g_dyncf_protected_chain_A_fn_class); var ifn_2554 lang.IFn; if linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var arg_2555 any = T__0_; if linked_2553 == nil { tmp3 = ifn_2554.Invoke_O__O(arg_2555) } else { tmp3 = linked_2553.(*A_arbace_j2g_dyncf_protected_chain_A).Invoke_O_O__O(root_2552, arg_2555) }; return tmp2.Invoke_O__O(tmp3) }
//line :409:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A) Ctor() {}
//line :409:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A) Invoke_O_O__O(self, s__292000138__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2549 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A_New_O_O(self, s__292000138__1); var tmp2 *jrt.Class; var fncls__2548 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A_fn_class; if fncls__2548 == nil { var fncls__2548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, fnbody__2549); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A_fn_class = fncls__2548d; tmp2 = fncls__2548d } else { tmp2 = fncls__2548 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2549, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :409:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :409:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A) Ctor_O_O(c__iter__292000137, c__s__292000138 any) { t.F_iter__292000137 = c__iter__292000137; t.F_s__292000138 = c__s__292000138 }
//line :409:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A) Invoke_O__O(self any) any { { var s__292000138__1 any; var t_ any = t.F_s__292000138; t.F_s__292000138 = nil; s__292000138__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1814 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = s__292000138__1; if linked_1815 == nil { temp__1927000414__auto____2 = ifn_1816.Invoke_O__O(arg_1817) } else { temp__1927000414__auto____2 = linked_1815.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1814, arg_1817) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000138__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1818 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = s__292000138__3; if linked_1819 == nil { tmp1 = ifn_1820.Invoke_O__O(arg_1821) } else { tmp1 = linked_1819.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1818, arg_1821) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1822 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = s__292000138__3; if linked_1823 == nil { c__1927001037__auto____4 = ifn_1824.Invoke_O__O(arg_1825) } else { c__1927001037__auto____4 = linked_1823.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1822, arg_1825) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000140__6 any; var root_1826 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1827 == nil { b__292000140__6 = ifn_1828.Invoke_O__O(arg_1829) } else { b__292000140__6 = linked_1827.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1826, arg_1829) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2172 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A_New_O_I_O(b__292000140__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2171 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class; if fncls__2171 == nil { var fncls__2171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, fnbody__2172); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class = fncls__2171d; tmp3 = fncls__2171d } else { tmp3 = fncls__2171 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2172, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2173 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any; var root_2178 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = b__292000140__6; if linked_2179 == nil { arg_2176 = ifn_2180.Invoke_O__O(arg_2181) } else { arg_2176 = linked_2179.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2178, arg_2181) }; var arg_2177 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000137); var tmp5 any; var root_2182 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2184 lang.IFn; if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any = s__292000138__3; if linked_2183 == nil { tmp5 = ifn_2184.Invoke_O__O(arg_2185) } else { tmp5 = linked_2183.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2182, arg_2185) }; arg_2177 = tmp4.Invoke_O__O(tmp5); if linked_2174 == nil { return ifn_2175.Invoke_O_O__O(arg_2176, arg_2177) } else { return linked_2174.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2173, arg_2176, arg_2177) } } else { var root_2186 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any; var root_2191 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = b__292000140__6; if linked_2192 == nil { arg_2189 = ifn_2193.Invoke_O__O(arg_2194) } else { arg_2189 = linked_2192.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2191, arg_2194) }; var arg_2190 any; if linked_2187 == nil { return ifn_2188.Invoke_O_O__O(arg_2189, arg_2190) } else { return linked_2187.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2186, arg_2189, arg_2190) } } } else { var c__4 any; var root_2195 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = s__292000138__3; if linked_2196 == nil { c__4 = ifn_2197.Invoke_O__O(arg_2198) } else { c__4 = linked_2196.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2195, arg_2198) }; var prot_QMARK___5 any; var fnbody__2210 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A_New(); var tmp6 *jrt.Class; var fncls__2209 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A_fn_class
															if fncls__2209 == nil { var fncls__2209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A_fn_class = fncls__2209d; tmp6 = fncls__2209d } else { tmp6 = fncls__2209 }; prot_QMARK___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2210, tmp6, nil)
//line :409:1
	var ms__6 any; var root_2211 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2213 lang.IFn


	if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any; var iter__1927001039__auto____6 any; var fnbody__2308 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A_New_O(prot_QMARK___5); var tmp7 *jrt.Class; var fncls__2307 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A_fn_class; if fncls__2307 == nil { var fncls__2307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, fnbody__2308); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A_fn_class = fncls__2307d; tmp7 = fncls__2307d } else { tmp7 = fncls__2307 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2308, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp9 any; var root_2309 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2311 lang.IFn; if linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any; var root_2314 any = A_arbace_j2g_dyncf_A_const_371.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2314, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2316 lang.IFn; if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = A_arbace_j2g_dyncf_A_const_72; var arg_2318 any = A_arbace_j2g_dyncf_A_const_76; if linked_2315 == nil { arg_2312 = ifn_2316.Invoke_O_O__O(arg_2317, arg_2318) } else { arg_2312 = linked_2315.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2314, arg_2317, arg_2318) }; var arg_2313 any; var root_2319 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_2320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2319, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2321 lang.IFn; if linked_2320 == nil { ifn_2321 = lang.IFn_Cast(root_2319) } else { ifn_2321 = nil }; var arg_2322 any = c__4; if linked_2320 == nil { arg_2313 = ifn_2321.Invoke_O__O(arg_2322) } else { arg_2313 = linked_2320.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2319, arg_2322) }; if linked_2310 == nil { tmp9 = ifn_2311.Invoke_O_O__O(arg_2312, arg_2313) } else { tmp9 = linked_2310.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2309, arg_2312, arg_2313) }; arg_2214 = tmp8.Invoke_O__O(tmp9); if linked_2212 == nil { ms__6 = ifn_2213.Invoke_O__O(arg_2214) } else { ms__6 = linked_2212.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2211, arg_2214) }
//line :409:1
	var cs__7 any; var root_2323 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2323, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2325 lang.IFn






	if linked_2324 == nil { ifn_2325 = lang.IFn_Cast(root_2323) } else { ifn_2325 = nil }; var arg_2326 any; var iter__1927001039__auto____7 any; var fnbody__2400 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A_New_O(prot_QMARK___5); var tmp10 *jrt.Class; var fncls__2399 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A_fn_class; if fncls__2399 == nil { var fncls__2399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__2400); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A_fn_class = fncls__2399d; tmp10 = fncls__2399d } else { tmp10 = fncls__2399 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2400, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp12 any; var root_2401 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2403 lang.IFn; if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = A_arbace_j2g_dyncf_A_const_76; var arg_2405 any; var root_2406 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_2407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2406, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2408 lang.IFn; if linked_2407 == nil { ifn_2408 = lang.IFn_Cast(root_2406) } else { ifn_2408 = nil }; var arg_2409 any = c__4; if linked_2407 == nil { arg_2405 = ifn_2408.Invoke_O__O(arg_2409) } else { arg_2405 = linked_2407.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2406, arg_2409) }; if linked_2402 == nil { tmp12 = ifn_2403.Invoke_O_O__O(arg_2404, arg_2405) } else { tmp12 = linked_2402.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2401, arg_2404, arg_2405) }; arg_2326 = tmp11.Invoke_O__O(tmp12); if linked_2324 == nil { cs__7 = ifn_2325.Invoke_O__O(arg_2326) } else { cs__7 = linked_2324.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2323, arg_2326) }
//line :409:1
	var fs__8 any; var tmp13 any; var root_2410 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_2411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2410, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2412 lang.IFn









	if linked_2411 == nil { ifn_2412 = lang.IFn_Cast(root_2410) } else { ifn_2412 = nil }; var arg_2413 any = c__4; if linked_2411 == nil { tmp13 = ifn_2412.Invoke_O__O(arg_2413) } else { tmp13 = linked_2411.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2410, arg_2413) }; if jrt.J2g_Truth(tmp13) { fs__8 = nil } else {
		var root_2414 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2414, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2416 lang.IFn; if linked_2415 == nil { ifn_2416 = lang.IFn_Cast(root_2414) } else { ifn_2416 = nil }; var arg_2417 any; var iter__1927001039__auto____8 any; var fnbody__2491 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A_New(); var tmp14 *jrt.Class; var fncls__2490 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A_fn_class; if fncls__2490 == nil { var fncls__2490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A_fn_class = fncls__2490d; tmp14 = fncls__2490d } else { tmp14 = fncls__2490 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2491, tmp14, nil); var tmp15 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp16 any; var root_2492 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2492, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2494 lang.IFn; if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = A_arbace_j2g_dyncf_A_const_72; var arg_2496 any; var root_2497 any = A_arbace_j2g_dyncf_A_const_190.GetRawRoot__O(); var linked_2498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2497, aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A_fn_class); var ifn_2499 lang.IFn; if linked_2498 == nil { ifn_2499 = lang.IFn_Cast(root_2497) } else { ifn_2499 = nil }; var arg_2500 any = c__4; if linked_2498 == nil { arg_2496 = ifn_2499.Invoke_O__O(arg_2500) } else { arg_2496 = linked_2498.(*aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A).Invoke_O_O__O(root_2497, arg_2500) }; if linked_2493 == nil { tmp16 = ifn_2494.Invoke_O_O__O(arg_2495, arg_2496) } else { tmp16 = linked_2493.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2492, arg_2495, arg_2496) }; arg_2417 = tmp15.Invoke_O__O(tmp16); if linked_2415 == nil { fs__8 = ifn_2416.Invoke_O__O(arg_2417) } else { fs__8 = linked_2415.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2414, arg_2417) } }
//line :409:1
	var e__9 any; var G__292000210__9_ any = lang.PersistentArrayMap_EMPTY.Ref(); var G__292000210__10_ any; var tmp17 any; var root_2501 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2501, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2503 lang.IFn













	if linked_2502 == nil { ifn_2503 = lang.IFn_Cast(root_2501) } else { ifn_2503 = nil }; var arg_2504 any = ms__6; if linked_2502 == nil { tmp17 = ifn_2503.Invoke_O__O(arg_2504) } else { tmp17 = linked_2502.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2501, arg_2504) }
//line :422:1
	if jrt.J2g_Truth(tmp17) {
		var root_2505 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_2506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2505, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2507 lang.IFn; if linked_2506 == nil { ifn_2507 = lang.IFn_Cast(root_2505) } else { ifn_2507 = nil }; var arg_2508 any = G__292000210__9_; var arg_2509 any = A_arbace_j2g_dyncf_A_const_108; var arg_2510 any = ms__6; if linked_2506 == nil { G__292000210__10_ = ifn_2507.Invoke_O_O_O__O(arg_2508, arg_2509, arg_2510) } else { G__292000210__10_ = linked_2506.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2505, arg_2508, arg_2509, arg_2510) } } else {
//line :422:1
			G__292000210__10_ = G__292000210__9_ }
//line :409:1
	var G__292000210__11_ any; var tmp18 any; var root_2511 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2511, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2513 lang.IFn














	if linked_2512 == nil { ifn_2513 = lang.IFn_Cast(root_2511) } else { ifn_2513 = nil }; var arg_2514 any = cs__7; if linked_2512 == nil { tmp18 = ifn_2513.Invoke_O__O(arg_2514) } else { tmp18 = linked_2512.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2511, arg_2514) }
//line :422:1
	if jrt.J2g_Truth(tmp18) {

		var root_2515 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_2516 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2515, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2517 lang.IFn; if linked_2516 == nil { ifn_2517 = lang.IFn_Cast(root_2515) } else { ifn_2517 = nil }; var arg_2518 any = G__292000210__10_; var arg_2519 any = A_arbace_j2g_dyncf_A_const_373; var arg_2520 any = cs__7; if linked_2516 == nil { G__292000210__11_ = ifn_2517.Invoke_O_O_O__O(arg_2518, arg_2519, arg_2520) } else { G__292000210__11_ = linked_2516.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2515, arg_2518, arg_2519, arg_2520) } } else {
//line :422:1
			G__292000210__11_ = G__292000210__10_ }; var tmp19 any; var root_2521 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2523 lang.IFn


	if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = fs__8; if linked_2522 == nil { tmp19 = ifn_2523.Invoke_O__O(arg_2524) } else { tmp19 = linked_2522.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2521, arg_2524) }
//line :422:1
	if jrt.J2g_Truth(tmp19) {


		var root_2525 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2527 lang.IFn; if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any = G__292000210__11_; var arg_2529 any = A_arbace_j2g_dyncf_A_const_374; var arg_2530 any = fs__8; if linked_2526 == nil { e__9 = ifn_2527.Invoke_O_O_O__O(arg_2528, arg_2529, arg_2530) } else { e__9 = linked_2526.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2525, arg_2528, arg_2529, arg_2530) } } else {
//line :422:1
			e__9 = G__292000210__11_ }
//line :409:1
	var tmp20 any; var root_2531 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2533 lang.IFn
















	if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = e__9; if linked_2532 == nil { tmp20 = ifn_2533.Invoke_O__O(arg_2534) } else { tmp20 = linked_2532.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2531, arg_2534) }
//line :409:1
	if jrt.J2g_Truth(tmp20) { var root_2535 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2535, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2537 lang.IFn; if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2538 any = lang.Tuple_Create_O_O__IPersistentVector(c__4, e__9); var arg_2539 any; var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__292000137); var tmp22 any; var root_2540 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = s__292000138__3; if linked_2541 == nil { tmp22 = ifn_2542.Invoke_O__O(arg_2543) } else { tmp22 = linked_2541.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2540, arg_2543) }; arg_2539 = tmp21.Invoke_O__O(tmp22); if linked_2536 == nil { return ifn_2537.Invoke_O_O__O(arg_2538, arg_2539) } else { return linked_2536.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2535, arg_2538, arg_2539) } } else { var tmp23 any; var root_2544 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = s__292000138__3; if linked_2545 == nil { tmp23 = ifn_2546.Invoke_O__O(arg_2547) } else { tmp23 = linked_2545.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2544, arg_2547) }; s__292000138__1 = tmp23; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :409:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :409:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A) Ctor_O_I_O(c__b__292000140 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000140 = c__b__292000140; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :409:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A) Invoke_O__O(self any) any { { var i__292000139__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000139__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000139__1)); var prot_QMARK___3 any; var fnbody__1841 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A_New(); var tmp2 *jrt.Class; var fncls__1840 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A_fn_class
																	if fncls__1840 == nil { var fncls__1840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A_fn_class = fncls__1840d; tmp2 = fncls__1840d } else { tmp2 = fncls__1840 }; prot_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1841, tmp2, nil)
//line :409:1
	var ms__4 any; var root_1842 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1844 lang.IFn


	if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any; var iter__1927001039__auto____4 any; var fnbody__1939 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A_New_O(prot_QMARK___3); var tmp3 *jrt.Class; var fncls__1938 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A_fn_class; if fncls__1938 == nil { var fncls__1938d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, fnbody__1939); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A_fn_class = fncls__1938d; tmp3 = fncls__1938d } else { tmp3 = fncls__1938 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1939, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp5 any; var root_1940 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1942 lang.IFn; if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any; var root_1945 any = A_arbace_j2g_dyncf_A_const_371.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = A_arbace_j2g_dyncf_A_const_72; var arg_1949 any = A_arbace_j2g_dyncf_A_const_76; if linked_1946 == nil { arg_1943 = ifn_1947.Invoke_O_O__O(arg_1948, arg_1949) } else { arg_1943 = linked_1946.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_1945, arg_1948, arg_1949) }; var arg_1944 any; var root_1950 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = c__2; if linked_1951 == nil { arg_1944 = ifn_1952.Invoke_O__O(arg_1953) } else { arg_1944 = linked_1951.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_1950, arg_1953) }; if linked_1941 == nil { tmp5 = ifn_1942.Invoke_O_O__O(arg_1943, arg_1944) } else { tmp5 = linked_1941.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1940, arg_1943, arg_1944) }; arg_1845 = tmp4.Invoke_O__O(tmp5); if linked_1843 == nil { ms__4 = ifn_1844.Invoke_O__O(arg_1845) } else { ms__4 = linked_1843.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1842, arg_1845) }
//line :409:1
	var cs__5 any; var root_1954 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1956 lang.IFn






	if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any; var iter__1927001039__auto____5 any; var fnbody__2031 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A_New_O(prot_QMARK___3); var tmp6 *jrt.Class; var fncls__2030 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A_fn_class; if fncls__2030 == nil { var fncls__2030d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, fnbody__2031); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A_fn_class = fncls__2030d; tmp6 = fncls__2030d } else { tmp6 = fncls__2030 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2031, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp8 any; var root_2032 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = A_arbace_j2g_dyncf_A_const_76; var arg_2036 any; var root_2037 any = A_arbace_j2g_dyncf_A_const_107.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = c__2; if linked_2038 == nil { arg_2036 = ifn_2039.Invoke_O__O(arg_2040) } else { arg_2036 = linked_2038.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2037, arg_2040) }; if linked_2033 == nil { tmp8 = ifn_2034.Invoke_O_O__O(arg_2035, arg_2036) } else { tmp8 = linked_2033.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2032, arg_2035, arg_2036) }; arg_1957 = tmp7.Invoke_O__O(tmp8); if linked_1955 == nil { cs__5 = ifn_1956.Invoke_O__O(arg_1957) } else { cs__5 = linked_1955.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1954, arg_1957) }
//line :409:1
	var fs__6 any; var tmp9 any; var root_2041 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2043 lang.IFn









	if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = c__2; if linked_2042 == nil { tmp9 = ifn_2043.Invoke_O__O(arg_2044) } else { tmp9 = linked_2042.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2041, arg_2044) }; if jrt.J2g_Truth(tmp9) { fs__6 = nil } else {
		var root_2045 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2047 lang.IFn; if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any; var iter__1927001039__auto____6 any; var fnbody__2122 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A_New(); var tmp10 *jrt.Class; var fncls__2121 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A_fn_class; if fncls__2121 == nil { var fncls__2121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A_fn_class = fncls__2121d; tmp10 = fncls__2121d } else { tmp10 = fncls__2121 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2122, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp12 any; var root_2123 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2125 lang.IFn; if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any = A_arbace_j2g_dyncf_A_const_72; var arg_2127 any; var root_2128 any = A_arbace_j2g_dyncf_A_const_190.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = c__2; if linked_2129 == nil { arg_2127 = ifn_2130.Invoke_O__O(arg_2131) } else { arg_2127 = linked_2129.(*aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A).Invoke_O_O__O(root_2128, arg_2131) }; if linked_2124 == nil { tmp12 = ifn_2125.Invoke_O_O__O(arg_2126, arg_2127) } else { tmp12 = linked_2124.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2123, arg_2126, arg_2127) }; arg_2048 = tmp11.Invoke_O__O(tmp12); if linked_2046 == nil { fs__6 = ifn_2047.Invoke_O__O(arg_2048) } else { fs__6 = linked_2046.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2045, arg_2048) } }
//line :409:1
	var e__7 any; var G__292000176__7_ any = lang.PersistentArrayMap_EMPTY.Ref(); var G__292000176__8_ any; var tmp13 any; var root_2132 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2134 lang.IFn













	if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = ms__4; if linked_2133 == nil { tmp13 = ifn_2134.Invoke_O__O(arg_2135) } else { tmp13 = linked_2133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2132, arg_2135) }
//line :422:1
	if jrt.J2g_Truth(tmp13) {
		var root_2136 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = G__292000176__7_; var arg_2140 any = A_arbace_j2g_dyncf_A_const_108; var arg_2141 any = ms__4; if linked_2137 == nil { G__292000176__8_ = ifn_2138.Invoke_O_O_O__O(arg_2139, arg_2140, arg_2141) } else { G__292000176__8_ = linked_2137.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2136, arg_2139, arg_2140, arg_2141) } } else {
//line :422:1
			G__292000176__8_ = G__292000176__7_ }
//line :409:1
	var G__292000176__9_ any; var tmp14 any; var root_2142 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2144 lang.IFn














	if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = cs__5; if linked_2143 == nil { tmp14 = ifn_2144.Invoke_O__O(arg_2145) } else { tmp14 = linked_2143.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2142, arg_2145) }
//line :422:1
	if jrt.J2g_Truth(tmp14) {

		var root_2146 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2146, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2148 lang.IFn; if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any = G__292000176__8_; var arg_2150 any = A_arbace_j2g_dyncf_A_const_373; var arg_2151 any = cs__5; if linked_2147 == nil { G__292000176__9_ = ifn_2148.Invoke_O_O_O__O(arg_2149, arg_2150, arg_2151) } else { G__292000176__9_ = linked_2147.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2146, arg_2149, arg_2150, arg_2151) } } else {
//line :422:1
			G__292000176__9_ = G__292000176__8_ }; var tmp15 any; var root_2152 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2154 lang.IFn


	if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = fs__6; if linked_2153 == nil { tmp15 = ifn_2154.Invoke_O__O(arg_2155) } else { tmp15 = linked_2153.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2152, arg_2155) }
//line :422:1
	if jrt.J2g_Truth(tmp15) {


		var root_2156 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = G__292000176__9_; var arg_2160 any = A_arbace_j2g_dyncf_A_const_374; var arg_2161 any = fs__6; if linked_2157 == nil { e__7 = ifn_2158.Invoke_O_O_O__O(arg_2159, arg_2160, arg_2161) } else { e__7 = linked_2157.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2156, arg_2159, arg_2160, arg_2161) } } else {
//line :422:1
			e__7 = G__292000176__9_ }
//line :409:1
	var tmp16 any; var root_2162 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2162, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2164 lang.IFn
















	if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = e__7; if linked_2163 == nil { tmp16 = ifn_2164.Invoke_O__O(arg_2165) } else { tmp16 = linked_2163.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2162, arg_2165) }
//line :409:1
	if jrt.J2g_Truth(tmp16) { var root_2166 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = t.F_b__292000140; var arg_2170 any = lang.Tuple_Create_O_O__IPersistentVector(c__2, e__7); if linked_2167 == nil { ifn_2168.Invoke_O_O__O(arg_2169, arg_2170) } else { linked_2167.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2166, arg_2169, arg_2170) }; i__292000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000139__1); continue L1 } else { i__292000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000139__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A) Ctor() {}
//line :410:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A) Invoke_O_O__O(self, x__1 any) any { var fl__2 any; var or__1927000174__auto____2 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(x__1); if jrt.J2g_Truth(or__1927000174__auto____2) { fl__2 = or__1927000174__auto____2 } else { fl__2 = A_arbace_j2g_dyncf_A_const_365 }; var and__1927000168__auto____3 bool; var tmp1 int64; var na_1830 any = fl__2; var na_1831 any = A_arbace_j2g_dyncf_A_const_366.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 =
																					jrt.Long_InstanceOf(na_1830); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1831) }; tmp2 = tmp3; if tmp2 { var n0_1832 int64 = jrt.NN(jrt.Long_Cast(na_1830)).LongValue__J(); var n1_1833 int64 = jrt.NN(jrt.Long_Cast(na_1831)).LongValue__J(); tmp1 = n0_1832 & n1_1833 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_1830, na_1831) }; and__1927000168__auto____3 = lang.Numbers_IsPos_J__Z_NoInit(tmp1); if and__1927000168__auto____3 { var tmp4 int64; var na_1835 any = fl__2; var na_1836 int64 = 4105; if jrt.Long_InstanceOf(na_1835) { var n0_1837 int64 = jrt.NN(jrt.Long_Cast(na_1835)).LongValue__J(); var n1_1838 int64 = na_1836; tmp4 = n0_1837 & n1_1838 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_1835, na_1836) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp4)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
//line :410:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A) Ctor() {}
//line :410:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A) Invoke_O_O__O(self, x__1 any) any { var fl__2 any; var or__1927000174__auto____2 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(x__1); if jrt.J2g_Truth(or__1927000174__auto____2) { fl__2 = or__1927000174__auto____2 } else { fl__2 = A_arbace_j2g_dyncf_A_const_365 }; var and__1927000168__auto____3 bool; var tmp1 int64; var na_2199 any = fl__2; var na_2200 any = A_arbace_j2g_dyncf_A_const_366.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 =
																			jrt.Long_InstanceOf(na_2199); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_2200) }; tmp2 = tmp3; if tmp2 { var n0_2201 int64 = jrt.NN(jrt.Long_Cast(na_2199)).LongValue__J(); var n1_2202 int64 = jrt.NN(jrt.Long_Cast(na_2200)).LongValue__J(); tmp1 = n0_2201 & n1_2202 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_2199, na_2200) }; and__1927000168__auto____3 = lang.Numbers_IsPos_J__Z_NoInit(tmp1); if and__1927000168__auto____3 { var tmp4 int64; var na_2204 any = fl__2; var na_2205 int64 = 4105; if jrt.Long_InstanceOf(na_2204) { var n0_2206 int64 = jrt.NN(jrt.Long_Cast(na_2204)).LongValue__J(); var n1_2207 int64 = na_2205; tmp4 = n0_2206 & n1_2207 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_2204, na_2205) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp4)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A_New_O(p0 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A{}; t.Ctor_O(p0); return t }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A) Ctor_O(c__prot_QMARK_ any) { t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A) Invoke_O_O__O(self, s__292000147__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1937 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A_New_O_O_O(t.F_prot_QMARK_, self, s__292000147__1); var tmp2 *jrt.Class; var fncls__1936 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A_fn_class; if fncls__1936 == nil { var fncls__1936d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, fnbody__1937); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A_fn_class = fncls__1936d; tmp2 = fncls__1936d } else { tmp2 = fncls__1936 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1937, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :412:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A) Ctor_O_O_O(c__prot_QMARK_, c__iter__292000146, c__s__292000147 any) { t.F_prot_QMARK_ = c__prot_QMARK_; t.F_iter__292000146 = c__iter__292000146; t.F_s__292000147 = c__s__292000147 }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A) Invoke_O__O(self any) any { { var s__292000147__1 any; var t_ any = t.F_s__292000147; t.F_s__292000147 = nil; s__292000147__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1846 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1848 lang.IFn; if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any = s__292000147__1; if linked_1847 == nil { temp__1927000414__auto____2 = ifn_1848.Invoke_O__O(arg_1849) } else { temp__1927000414__auto____2 = linked_1847.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1846, arg_1849) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000147__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1850 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = s__292000147__3; if linked_1851 == nil { tmp1 = ifn_1852.Invoke_O__O(arg_1853) } else { tmp1 = linked_1851.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1850, arg_1853) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1854 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1856 lang.IFn; if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = s__292000147__3; if linked_1855 == nil { c__1927001037__auto____4 = ifn_1856.Invoke_O__O(arg_1857) } else { c__1927001037__auto____4 = linked_1855.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1854, arg_1857) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000149__6 any; var root_1858 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1860 lang.IFn; if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1859 == nil { b__292000149__6 = ifn_1860.Invoke_O__O(arg_1861) } else { b__292000149__6 = linked_1859.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1858, arg_1861) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1882 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A_New_O_O_I_O(b__292000149__6, t.F_prot_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1881 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A_fn_class; if fncls__1881 == nil { var fncls__1881d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, fnbody__1882); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A_fn_class = fncls__1881d; tmp3 = fncls__1881d } else { tmp3 = fncls__1881 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1882, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1883 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any; var root_1888 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1890 lang.IFn; if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any = b__292000149__6; if linked_1889 == nil { arg_1886 = ifn_1890.Invoke_O__O(arg_1891) } else { arg_1886 = linked_1889.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1888, arg_1891) }; var arg_1887 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000146); var tmp5 any; var root_1892 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = s__292000147__3; if linked_1893 == nil { tmp5 = ifn_1894.Invoke_O__O(arg_1895) } else { tmp5 = linked_1893.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1892, arg_1895) }; arg_1887 = tmp4.Invoke_O__O(tmp5); if linked_1884 == nil { return ifn_1885.Invoke_O_O__O(arg_1886, arg_1887) } else { return linked_1884.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1883, arg_1886, arg_1887) } } else { var root_1896 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any; var root_1901 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = b__292000149__6; if linked_1902 == nil { arg_1899 = ifn_1903.Invoke_O__O(arg_1904) } else { arg_1899 = linked_1902.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1901, arg_1904) }; var arg_1900 any; if linked_1897 == nil { return ifn_1898.Invoke_O_O__O(arg_1899, arg_1900) } else { return linked_1897.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1896, arg_1899, arg_1900) } } } else { var mm__4 any; var root_1905 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1907 lang.IFn; if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = s__292000147__3; if linked_1906 == nil { mm__4 = ifn_1907.Invoke_O__O(arg_1908) } else { mm__4 = linked_1906.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1905, arg_1908) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__4)
																						if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1909 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = Lit_61; var arg_1913 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4); if linked_1910 == nil { and__1927000168__auto____6 = ifn_1911.Invoke_O_O__O(arg_1912, arg_1913) } else { and__1927000168__auto____6 = linked_1910.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1909, arg_1912, arg_1913) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1914 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = Lit_116; var arg_1918 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4); if linked_1915 == nil { and__1927000168__auto____7 = ifn_1916.Invoke_O_O__O(arg_1917, arg_1918) } else { and__1927000168__auto____7 = linked_1915.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1914, arg_1917, arg_1918) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
																							var root_1919 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_1920 == nil { tmp6 = ifn_1921.Invoke_O__O(arg_1922) } else { tmp6 = linked_1920.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1919, arg_1922) } } else {
//line :413:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :412:1
	if jrt.J2g_Truth(tmp6) { var root_1923 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)); var arg_1927 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000146); var tmp8 any; var root_1928 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1930 lang.IFn; if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = s__292000147__3; if linked_1929 == nil { tmp8 = ifn_1930.Invoke_O__O(arg_1931) } else { tmp8 = linked_1929.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1928, arg_1931) }; arg_1927 = tmp7.Invoke_O__O(tmp8); if linked_1924 == nil { return ifn_1925.Invoke_O_O__O(arg_1926, arg_1927) } else { return linked_1924.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1923, arg_1926, arg_1927) } } else { var tmp9 any; var root_1932 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = s__292000147__3; if linked_1933 == nil { tmp9 = ifn_1934.Invoke_O__O(arg_1935) } else { tmp9 = linked_1933.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1932, arg_1935) }; s__292000147__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :412:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A) Ctor_O_O_I_O(c__b__292000149, c__prot_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000149 = c__b__292000149; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A) Invoke_O__O(self any) any { { var i__292000148__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000148__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000148__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__2)
																								if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1862 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = Lit_61; var arg_1866 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2); if linked_1863 == nil { and__1927000168__auto____4 = ifn_1864.Invoke_O_O__O(arg_1865, arg_1866) } else { and__1927000168__auto____4 = linked_1863.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1862, arg_1865, arg_1866) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1867 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = Lit_116; var arg_1871 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2); if linked_1868 == nil { and__1927000168__auto____5 = ifn_1869.Invoke_O_O__O(arg_1870, arg_1871) } else { and__1927000168__auto____5 = linked_1868.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1867, arg_1870, arg_1871) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
																									var root_1872 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_1873 == nil { tmp2 = ifn_1874.Invoke_O__O(arg_1875) } else { tmp2 = linked_1873.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1872, arg_1875) } } else {
//line :413:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :412:1
	if jrt.J2g_Truth(tmp2) { var root_1876 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = t.F_b__292000149; var arg_1880 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)); if linked_1877 == nil { ifn_1878.Invoke_O_O__O(arg_1879, arg_1880) } else { linked_1877.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1876, arg_1879, arg_1880) }; i__292000148__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000148__1); continue L1 } else { i__292000148__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000148__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :412:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A_New_O(p0 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A{}; t.Ctor_O(p0); return t }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A) Ctor_O(c__prot_QMARK_ any) { t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A) Invoke_O_O__O(self, s__292000181__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2306 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A_New_O_O_O(self, s__292000181__1, t.F_prot_QMARK_); var tmp2 *jrt.Class; var fncls__2305 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A_fn_class; if fncls__2305 == nil { var fncls__2305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__2306); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A_fn_class = fncls__2305d; tmp2 = fncls__2305d } else { tmp2 = fncls__2305 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2306, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :412:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A) Ctor_O_O_O(c__iter__292000180, c__s__292000181, c__prot_QMARK_ any) { t.F_iter__292000180 = c__iter__292000180; t.F_s__292000181 = c__s__292000181; t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A) Invoke_O__O(self any) any { { var s__292000181__1 any; var t_ any = t.F_s__292000181; t.F_s__292000181 = nil; s__292000181__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2215 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2217 lang.IFn; if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = s__292000181__1; if linked_2216 == nil { temp__1927000414__auto____2 = ifn_2217.Invoke_O__O(arg_2218) } else { temp__1927000414__auto____2 = linked_2216.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2215, arg_2218) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000181__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2219 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = s__292000181__3; if linked_2220 == nil { tmp1 = ifn_2221.Invoke_O__O(arg_2222) } else { tmp1 = linked_2220.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2219, arg_2222) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2223 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2223, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any = s__292000181__3; if linked_2224 == nil { c__1927001037__auto____4 = ifn_2225.Invoke_O__O(arg_2226) } else { c__1927001037__auto____4 = linked_2224.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2223, arg_2226) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000183__6 any; var root_2227 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2227, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2229 lang.IFn; if linked_2228 == nil { ifn_2229 = lang.IFn_Cast(root_2227) } else { ifn_2229 = nil }; var arg_2230 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2228 == nil { b__292000183__6 = ifn_2229.Invoke_O__O(arg_2230) } else { b__292000183__6 = linked_2228.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2227, arg_2230) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2251 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A_New_O_I_O_O(t.F_prot_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4, b__292000183__6); var tmp3 *jrt.Class; var fncls__2250 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A_fn_class; if fncls__2250 == nil { var fncls__2250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, fnbody__2251); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A_fn_class = fncls__2250d; tmp3 = fncls__2250d } else { tmp3 = fncls__2250 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2251, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2252 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2254 lang.IFn; if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any; var root_2257 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = b__292000183__6; if linked_2258 == nil { arg_2255 = ifn_2259.Invoke_O__O(arg_2260) } else { arg_2255 = linked_2258.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2257, arg_2260) }; var arg_2256 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000180); var tmp5 any; var root_2261 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = s__292000181__3; if linked_2262 == nil { tmp5 = ifn_2263.Invoke_O__O(arg_2264) } else { tmp5 = linked_2262.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2261, arg_2264) }; arg_2256 = tmp4.Invoke_O__O(tmp5); if linked_2253 == nil { return ifn_2254.Invoke_O_O__O(arg_2255, arg_2256) } else { return linked_2253.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2252, arg_2255, arg_2256) } } else { var root_2265 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2265, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2267 lang.IFn; if linked_2266 == nil { ifn_2267 = lang.IFn_Cast(root_2265) } else { ifn_2267 = nil }; var arg_2268 any; var root_2270 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2270, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2272 lang.IFn; if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = b__292000183__6; if linked_2271 == nil { arg_2268 = ifn_2272.Invoke_O__O(arg_2273) } else { arg_2268 = linked_2271.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2270, arg_2273) }; var arg_2269 any; if linked_2266 == nil { return ifn_2267.Invoke_O_O__O(arg_2268, arg_2269) } else { return linked_2266.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2265, arg_2268, arg_2269) } } } else { var mm__4 any; var root_2274 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2274, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2276 lang.IFn; if linked_2275 == nil { ifn_2276 = lang.IFn_Cast(root_2274) } else { ifn_2276 = nil }; var arg_2277 any = s__292000181__3; if linked_2275 == nil { mm__4 = ifn_2276.Invoke_O__O(arg_2277) } else { mm__4 = linked_2275.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2274, arg_2277) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2278 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2280 lang.IFn; if linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = Lit_61; var arg_2282 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4); if linked_2279 == nil { and__1927000168__auto____6 = ifn_2280.Invoke_O_O__O(arg_2281, arg_2282) } else { and__1927000168__auto____6 = linked_2279.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2278, arg_2281, arg_2282) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2283 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2284 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2283, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2285 lang.IFn; if linked_2284 == nil { ifn_2285 = lang.IFn_Cast(root_2283) } else { ifn_2285 = nil }; var arg_2286 any = Lit_116; var arg_2287 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4); if linked_2284 == nil { and__1927000168__auto____7 = ifn_2285.Invoke_O_O__O(arg_2286, arg_2287) } else { and__1927000168__auto____7 = linked_2284.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2283, arg_2286, arg_2287) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
																					var root_2288 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2290 lang.IFn; if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_2289 == nil { tmp6 = ifn_2290.Invoke_O__O(arg_2291) } else { tmp6 = linked_2289.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2288, arg_2291) } } else {
//line :413:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :412:1
	if jrt.J2g_Truth(tmp6) { var root_2292 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2294 lang.IFn; if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)); var arg_2296 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000180); var tmp8 any; var root_2297 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = s__292000181__3; if linked_2298 == nil { tmp8 = ifn_2299.Invoke_O__O(arg_2300) } else { tmp8 = linked_2298.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2297, arg_2300) }; arg_2296 = tmp7.Invoke_O__O(tmp8); if linked_2293 == nil { return ifn_2294.Invoke_O_O__O(arg_2295, arg_2296) } else { return linked_2293.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2292, arg_2295, arg_2296) } } else { var tmp9 any; var root_2301 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = s__292000181__3; if linked_2302 == nil { tmp9 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp9 = linked_2302.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2301, arg_2304) }; s__292000181__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :412:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A) Ctor_O_I_O_O(c__prot_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__292000183 any) { t.F_prot_QMARK_ = c__prot_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__292000183 = c__b__292000183 }
//line :412:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A) Invoke_O__O(self any) any { { var i__292000182__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000182__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000182__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__2)
																						if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2231 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2232 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2231, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2233 lang.IFn; if linked_2232 == nil { ifn_2233 = lang.IFn_Cast(root_2231) } else { ifn_2233 = nil }; var arg_2234 any = Lit_61; var arg_2235 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2); if linked_2232 == nil { and__1927000168__auto____4 = ifn_2233.Invoke_O_O__O(arg_2234, arg_2235) } else { and__1927000168__auto____4 = linked_2232.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2231, arg_2234, arg_2235) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_2236 any = A_arbace_j2g_dyncf_A_const_152.GetRawRoot__O(); var linked_2237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2236, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2238 lang.IFn; if linked_2237 == nil { ifn_2238 = lang.IFn_Cast(root_2236) } else { ifn_2238 = nil }; var arg_2239 any = Lit_116; var arg_2240 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2); if linked_2237 == nil { and__1927000168__auto____5 = ifn_2238.Invoke_O_O__O(arg_2239, arg_2240) } else { and__1927000168__auto____5 = linked_2237.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2236, arg_2239, arg_2240) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
																							var root_2241 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_2242 == nil { tmp2 = ifn_2243.Invoke_O__O(arg_2244) } else { tmp2 = linked_2242.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2241, arg_2244) } } else {
//line :413:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :412:1
	if jrt.J2g_Truth(tmp2) { var root_2245 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2247 lang.IFn; if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any = t.F_b__292000183; var arg_2249 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)); if linked_2246 == nil { ifn_2247.Invoke_O_O__O(arg_2248, arg_2249) } else { linked_2246.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2245, arg_2248, arg_2249) }; i__292000182__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000182__1); continue L1 } else { i__292000182__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000182__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A_New_O(p0 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A{}; t.Ctor_O(p0); return t }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A) Ctor_O(c__prot_QMARK_ any) { t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A) Invoke_O_O__O(self, s__292000157__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2029 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A_New_O_O_O(self, t.F_prot_QMARK_, s__292000157__1); var tmp2 *jrt.Class; var fncls__2028 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A_fn_class; if fncls__2028 == nil { var fncls__2028d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, fnbody__2029); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A_fn_class = fncls__2028d; tmp2 = fncls__2028d } else { tmp2 = fncls__2028 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2029, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :416:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A) Ctor_O_O_O(c__iter__292000156, c__prot_QMARK_, c__s__292000157 any) { t.F_iter__292000156 = c__iter__292000156; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_s__292000157 = c__s__292000157 }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A) Invoke_O__O(self any) any { { var s__292000157__1 any; var t_ any = t.F_s__292000157; t.F_s__292000157 = nil; s__292000157__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1958 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = s__292000157__1; if linked_1959 == nil { temp__1927000414__auto____2 = ifn_1960.Invoke_O__O(arg_1961) } else { temp__1927000414__auto____2 = linked_1959.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1958, arg_1961) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000157__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1962 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = s__292000157__3; if linked_1963 == nil { tmp1 = ifn_1964.Invoke_O__O(arg_1965) } else { tmp1 = linked_1963.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1962, arg_1965) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1966 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = s__292000157__3; if linked_1967 == nil { c__1927001037__auto____4 = ifn_1968.Invoke_O__O(arg_1969) } else { c__1927001037__auto____4 = linked_1967.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1966, arg_1969) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000159__6 any; var root_1970 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1971 == nil { b__292000159__6 = ifn_1972.Invoke_O__O(arg_1973) } else { b__292000159__6 = linked_1971.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1970, arg_1973) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1984 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A_New_O_O_I_O(b__292000159__6, t.F_prot_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1983 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class; if fncls__1983 == nil { var fncls__1983d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, fnbody__1984); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class = fncls__1983d; tmp3 = fncls__1983d } else { tmp3 = fncls__1983 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1984, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1985 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any; var root_1990 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = b__292000159__6; if linked_1991 == nil { arg_1988 = ifn_1992.Invoke_O__O(arg_1993) } else { arg_1988 = linked_1991.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1990, arg_1993) }; var arg_1989 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000156); var tmp5 any; var root_1994 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = s__292000157__3; if linked_1995 == nil { tmp5 = ifn_1996.Invoke_O__O(arg_1997) } else { tmp5 = linked_1995.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1994, arg_1997) }; arg_1989 = tmp4.Invoke_O__O(tmp5); if linked_1986 == nil { return ifn_1987.Invoke_O_O__O(arg_1988, arg_1989) } else { return linked_1986.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1985, arg_1988, arg_1989) } } else { var root_1998 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any; var root_2003 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2005 lang.IFn; if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = b__292000159__6; if linked_2004 == nil { arg_2001 = ifn_2005.Invoke_O__O(arg_2006) } else { arg_2001 = linked_2004.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2003, arg_2006) }; var arg_2002 any; if linked_1999 == nil { return ifn_2000.Invoke_O_O__O(arg_2001, arg_2002) } else { return linked_1999.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1998, arg_2001, arg_2002) } } } else { var mm__4 any; var root_2007 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = s__292000157__3; if linked_2008 == nil { mm__4 = ifn_2009.Invoke_O__O(arg_2010) } else { mm__4 = linked_2008.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2007, arg_2010) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__4)
																						if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)); if and__1927000168__auto____6 { var root_2011 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_2012 == nil { tmp6 = ifn_2013.Invoke_O__O(arg_2014) } else { tmp6 = linked_2012.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2011, arg_2014) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp6 = and__1927000168__auto____5 }
//line :416:1
	if jrt.J2g_Truth(tmp6) { var root_2015 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2017 lang.IFn; if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)); var arg_2019 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000156); var tmp8 any; var root_2020 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = s__292000157__3; if linked_2021 == nil { tmp8 = ifn_2022.Invoke_O__O(arg_2023) } else { tmp8 = linked_2021.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2020, arg_2023) }; arg_2019 = tmp7.Invoke_O__O(tmp8); if linked_2016 == nil { return ifn_2017.Invoke_O_O__O(arg_2018, arg_2019) } else { return linked_2016.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2015, arg_2018, arg_2019) } } else { var tmp9 any; var root_2024 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = s__292000157__3; if linked_2025 == nil { tmp9 = ifn_2026.Invoke_O__O(arg_2027) } else { tmp9 = linked_2025.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2024, arg_2027) }; s__292000157__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :416:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A) Ctor_O_O_I_O(c__b__292000159, c__prot_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000159 = c__b__292000159; t.F_prot_QMARK_ = c__prot_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A) Invoke_O__O(self any) any { { var i__292000158__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000158__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000158__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__2)
																								if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)); if and__1927000168__auto____4 { var root_1974 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_1975 == nil { tmp2 = ifn_1976.Invoke_O__O(arg_1977) } else { tmp2 = linked_1975.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1974, arg_1977) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp2 = and__1927000168__auto____3 }
//line :416:1
	if jrt.J2g_Truth(tmp2) { var root_1978 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = t.F_b__292000159; var arg_1982 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)); if linked_1979 == nil { ifn_1980.Invoke_O_O__O(arg_1981, arg_1982) } else { linked_1979.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1978, arg_1981, arg_1982) }; i__292000158__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000158__1); continue L1 } else { i__292000158__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000158__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :416:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A_New_O(p0 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A{}; t.Ctor_O(p0); return t }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A) Ctor_O(c__prot_QMARK_ any) { t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A) Invoke_O_O__O(self, s__292000191__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2398 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A_New_O_O_O(self, s__292000191__1, t.F_prot_QMARK_); var tmp2 *jrt.Class; var fncls__2397 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A_fn_class; if fncls__2397 == nil { var fncls__2397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, fnbody__2398); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A_fn_class = fncls__2397d; tmp2 = fncls__2397d } else { tmp2 = fncls__2397 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2398, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :416:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A) Ctor_O_O_O(c__iter__292000190, c__s__292000191, c__prot_QMARK_ any) { t.F_iter__292000190 = c__iter__292000190; t.F_s__292000191 = c__s__292000191; t.F_prot_QMARK_ = c__prot_QMARK_ }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A) Invoke_O__O(self any) any { { var s__292000191__1 any; var t_ any = t.F_s__292000191; t.F_s__292000191 = nil; s__292000191__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2327 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2327, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2329 lang.IFn; if linked_2328 == nil { ifn_2329 = lang.IFn_Cast(root_2327) } else { ifn_2329 = nil }; var arg_2330 any = s__292000191__1; if linked_2328 == nil { temp__1927000414__auto____2 = ifn_2329.Invoke_O__O(arg_2330) } else { temp__1927000414__auto____2 = linked_2328.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2327, arg_2330) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000191__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2331 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = s__292000191__3; if linked_2332 == nil { tmp1 = ifn_2333.Invoke_O__O(arg_2334) } else { tmp1 = linked_2332.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2331, arg_2334) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2335 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = s__292000191__3; if linked_2336 == nil { c__1927001037__auto____4 = ifn_2337.Invoke_O__O(arg_2338) } else { c__1927001037__auto____4 = linked_2336.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2335, arg_2338) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000193__6 any; var root_2339 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2340 == nil { b__292000193__6 = ifn_2341.Invoke_O__O(arg_2342) } else { b__292000193__6 = linked_2340.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2339, arg_2342) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2353 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A_New_O_I_O_O(t.F_prot_QMARK_, size__1927001038__auto____5, b__292000193__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2352 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A_fn_class; if fncls__2352 == nil { var fncls__2352d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, fnbody__2353); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A_fn_class = fncls__2352d; tmp3 = fncls__2352d } else { tmp3 = fncls__2352 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2353, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2354 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2354, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2356 lang.IFn; if linked_2355 == nil { ifn_2356 = lang.IFn_Cast(root_2354) } else { ifn_2356 = nil }; var arg_2357 any; var root_2359 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any = b__292000193__6; if linked_2360 == nil { arg_2357 = ifn_2361.Invoke_O__O(arg_2362) } else { arg_2357 = linked_2360.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2359, arg_2362) }; var arg_2358 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000190); var tmp5 any; var root_2363 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any = s__292000191__3; if linked_2364 == nil { tmp5 = ifn_2365.Invoke_O__O(arg_2366) } else { tmp5 = linked_2364.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2363, arg_2366) }; arg_2358 = tmp4.Invoke_O__O(tmp5); if linked_2355 == nil { return ifn_2356.Invoke_O_O__O(arg_2357, arg_2358) } else { return linked_2355.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2354, arg_2357, arg_2358) } } else { var root_2367 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2367, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2369 lang.IFn; if linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any; var root_2372 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = b__292000193__6; if linked_2373 == nil { arg_2370 = ifn_2374.Invoke_O__O(arg_2375) } else { arg_2370 = linked_2373.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2372, arg_2375) }; var arg_2371 any; if linked_2368 == nil { return ifn_2369.Invoke_O_O__O(arg_2370, arg_2371) } else { return linked_2368.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2367, arg_2370, arg_2371) } } } else { var mm__4 any; var root_2376 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = s__292000191__3; if linked_2377 == nil { mm__4 = ifn_2378.Invoke_O__O(arg_2379) } else { mm__4 = linked_2377.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2376, arg_2379) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)); if and__1927000168__auto____6 { var root_2380 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2380, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4); if linked_2381 == nil { tmp6 = ifn_2382.Invoke_O__O(arg_2383) } else { tmp6 = linked_2381.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2380, arg_2383) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp6 = and__1927000168__auto____5 }
//line :416:1
	if jrt.J2g_Truth(tmp6) { var root_2384 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2386 lang.IFn; if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)); var arg_2388 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000190); var tmp8 any; var root_2389 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any = s__292000191__3; if linked_2390 == nil { tmp8 = ifn_2391.Invoke_O__O(arg_2392) } else { tmp8 = linked_2390.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2389, arg_2392) }; arg_2388 = tmp7.Invoke_O__O(tmp8); if linked_2385 == nil { return ifn_2386.Invoke_O_O__O(arg_2387, arg_2388) } else { return linked_2385.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2384, arg_2387, arg_2388) } } else { var tmp9 any; var root_2393 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = s__292000191__3; if linked_2394 == nil { tmp9 = ifn_2395.Invoke_O__O(arg_2396) } else { tmp9 = linked_2394.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2393, arg_2396) }; s__292000191__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :416:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A) Ctor_O_I_O_O(c__prot_QMARK_ any, c__size__1927001038__auto__ int32, c__b__292000193, c__c__1927001037__auto__ any) { t.F_prot_QMARK_ = c__prot_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__292000193 = c__b__292000193; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :416:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A) Invoke_O__O(self any) any { { var i__292000192__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000192__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000192__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_prot_QMARK_).Invoke_O__O(mm__2)
																						if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)); if and__1927000168__auto____4 { var root_2343 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2); if linked_2344 == nil { tmp2 = ifn_2345.Invoke_O__O(arg_2346) } else { tmp2 = linked_2344.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_2343, arg_2346) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp2 = and__1927000168__auto____3 }
//line :416:1
	if jrt.J2g_Truth(tmp2) { var root_2347 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = t.F_b__292000193; var arg_2351 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)); if linked_2348 == nil { ifn_2349.Invoke_O_O__O(arg_2350, arg_2351) } else { linked_2348.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2347, arg_2350, arg_2351) }; i__292000192__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000192__1); continue L1 } else { i__292000192__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000192__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A) Ctor() {}
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A) Invoke_O_O__O(self, s__292000167__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2120 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A_New_O_O(self, s__292000167__1); var tmp2 *jrt.Class; var fncls__2119 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A_fn_class; if fncls__2119 == nil { var fncls__2119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__2120); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A_fn_class = fncls__2119d; tmp2 = fncls__2119d } else { tmp2 = fncls__2119 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2120, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :420:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A) Ctor_O_O(c__iter__292000166, c__s__292000167 any) { t.F_iter__292000166 = c__iter__292000166; t.F_s__292000167 = c__s__292000167 }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A) Invoke_O__O(self any) any { { var s__292000167__1 any; var t_ any = t.F_s__292000167; t.F_s__292000167 = nil; s__292000167__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2049 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = s__292000167__1; if linked_2050 == nil { temp__1927000414__auto____2 = ifn_2051.Invoke_O__O(arg_2052) } else { temp__1927000414__auto____2 = linked_2050.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2049, arg_2052) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000167__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2053 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = s__292000167__3; if linked_2054 == nil { tmp1 = ifn_2055.Invoke_O__O(arg_2056) } else { tmp1 = linked_2054.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2053, arg_2056) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2057 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2057, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2059 lang.IFn; if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; var arg_2060 any = s__292000167__3; if linked_2058 == nil { c__1927001037__auto____4 = ifn_2059.Invoke_O__O(arg_2060) } else { c__1927001037__auto____4 = linked_2058.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2057, arg_2060) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000169__6 any; var root_2061 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2063 lang.IFn; if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2062 == nil { b__292000169__6 = ifn_2063.Invoke_O__O(arg_2064) } else { b__292000169__6 = linked_2062.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2061, arg_2064) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2075 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A_New_O_I_O(b__292000169__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2074 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A_fn_class; if fncls__2074 == nil { var fncls__2074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, fnbody__2075); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A_fn_class = fncls__2074d; tmp3 = fncls__2074d } else { tmp3 = fncls__2074 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2075, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2076 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any; var root_2081 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = b__292000169__6; if linked_2082 == nil { arg_2079 = ifn_2083.Invoke_O__O(arg_2084) } else { arg_2079 = linked_2082.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2081, arg_2084) }; var arg_2080 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000166); var tmp5 any; var root_2085 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = s__292000167__3; if linked_2086 == nil { tmp5 = ifn_2087.Invoke_O__O(arg_2088) } else { tmp5 = linked_2086.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2085, arg_2088) }; arg_2080 = tmp4.Invoke_O__O(tmp5); if linked_2077 == nil { return ifn_2078.Invoke_O_O__O(arg_2079, arg_2080) } else { return linked_2077.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2076, arg_2079, arg_2080) } } else { var root_2089 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2091 lang.IFn; if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any; var root_2094 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = b__292000169__6; if linked_2095 == nil { arg_2092 = ifn_2096.Invoke_O__O(arg_2097) } else { arg_2092 = linked_2095.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2094, arg_2097) }; var arg_2093 any; if linked_2090 == nil { return ifn_2091.Invoke_O_O__O(arg_2092, arg_2093) } else { return linked_2090.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2089, arg_2092, arg_2093) } } } else { var f__4 any; var root_2098 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = s__292000167__3; if linked_2099 == nil { f__4 = ifn_2100.Invoke_O__O(arg_2101) } else { f__4 = linked_2099.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2098, arg_2101) }; var tmp6 any; var root_2102 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = f__4; if linked_2103 == nil { tmp6 = ifn_2104.Invoke_O__O(arg_2105) } else { tmp6 = linked_2103.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_2102, arg_2105) }; if jrt.J2g_Truth(tmp6) { var root_2106 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__4)); var arg_2110 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000166); var tmp8 any; var root_2111 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = s__292000167__3; if linked_2112 == nil { tmp8 = ifn_2113.Invoke_O__O(arg_2114) } else { tmp8 = linked_2112.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2111, arg_2114) }; arg_2110 = tmp7.Invoke_O__O(tmp8); if linked_2107 == nil { return ifn_2108.Invoke_O_O__O(arg_2109, arg_2110) } else { return linked_2107.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2106, arg_2109, arg_2110) } } else { var tmp9 any; var root_2115 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = s__292000167__3; if linked_2116 == nil { tmp9 = ifn_2117.Invoke_O__O(arg_2118) } else { tmp9 = linked_2116.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2115, arg_2118) }; s__292000167__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :420:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A) Ctor_O_I_O(c__b__292000169 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000169 = c__b__292000169; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A) Invoke_O__O(self any) any { { var i__292000168__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000168__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000168__1)); var tmp2 any; var root_2065 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = f__2; if linked_2066 == nil { tmp2 = ifn_2067.Invoke_O__O(arg_2068) } else { tmp2 = linked_2066.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_2065, arg_2068) }; if jrt.J2g_Truth(tmp2) { var root_2069 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2071 lang.IFn; if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = t.F_b__292000169; var arg_2073 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__2)); if linked_2070 == nil { ifn_2071.Invoke_O_O__O(arg_2072, arg_2073) } else { linked_2070.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2069, arg_2072, arg_2073) }; i__292000168__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000168__1); continue L1 } else { i__292000168__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000168__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :420:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A_New() *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A) Ctor() {}
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A) Invoke_O_O__O(self, s__292000201__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2489 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A_New_O_O(self, s__292000201__1); var tmp2 *jrt.Class; var fncls__2488 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A_fn_class; if fncls__2488 == nil { var fncls__2488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, fnbody__2489); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A_fn_class = fncls__2488d; tmp2 = fncls__2488d } else { tmp2 = fncls__2488 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2489, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :420:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A{}; t.Ctor_O_O(p0, p1); return t }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A) Ctor_O_O(c__iter__292000200, c__s__292000201 any) { t.F_iter__292000200 = c__iter__292000200; t.F_s__292000201 = c__s__292000201 }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A) Invoke_O__O(self any) any { { var s__292000201__1 any; var t_ any = t.F_s__292000201; t.F_s__292000201 = nil; s__292000201__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2418 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2420 lang.IFn; if linked_2419 == nil { ifn_2420 = lang.IFn_Cast(root_2418) } else { ifn_2420 = nil }; var arg_2421 any = s__292000201__1; if linked_2419 == nil { temp__1927000414__auto____2 = ifn_2420.Invoke_O__O(arg_2421) } else { temp__1927000414__auto____2 = linked_2419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2418, arg_2421) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000201__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2422 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2422, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2424 lang.IFn; if linked_2423 == nil { ifn_2424 = lang.IFn_Cast(root_2422) } else { ifn_2424 = nil }; var arg_2425 any = s__292000201__3; if linked_2423 == nil { tmp1 = ifn_2424.Invoke_O__O(arg_2425) } else { tmp1 = linked_2423.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2422, arg_2425) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2426 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2426, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2428 lang.IFn; if linked_2427 == nil { ifn_2428 = lang.IFn_Cast(root_2426) } else { ifn_2428 = nil }; var arg_2429 any = s__292000201__3; if linked_2427 == nil { c__1927001037__auto____4 = ifn_2428.Invoke_O__O(arg_2429) } else { c__1927001037__auto____4 = linked_2427.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2426, arg_2429) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000203__6 any; var root_2430 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2430, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2432 lang.IFn; if linked_2431 == nil { ifn_2432 = lang.IFn_Cast(root_2430) } else { ifn_2432 = nil }; var arg_2433 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2431 == nil { b__292000203__6 = ifn_2432.Invoke_O__O(arg_2433) } else { b__292000203__6 = linked_2431.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2430, arg_2433) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2444 any = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A_New_O_I_O(b__292000203__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2443 *jrt.Class = A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A_fn_class; if fncls__2443 == nil { var fncls__2443d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, fnbody__2444); A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A_fn_class = fncls__2443d; tmp3 = fncls__2443d } else { tmp3 = fncls__2443 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2444, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2445 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any; var root_2450 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2450, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2452 lang.IFn; if linked_2451 == nil { ifn_2452 = lang.IFn_Cast(root_2450) } else { ifn_2452 = nil }; var arg_2453 any = b__292000203__6; if linked_2451 == nil { arg_2448 = ifn_2452.Invoke_O__O(arg_2453) } else { arg_2448 = linked_2451.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2450, arg_2453) }; var arg_2449 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000200); var tmp5 any; var root_2454 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2454, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2456 lang.IFn; if linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any = s__292000201__3; if linked_2455 == nil { tmp5 = ifn_2456.Invoke_O__O(arg_2457) } else { tmp5 = linked_2455.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2454, arg_2457) }; arg_2449 = tmp4.Invoke_O__O(tmp5); if linked_2446 == nil { return ifn_2447.Invoke_O_O__O(arg_2448, arg_2449) } else { return linked_2446.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2445, arg_2448, arg_2449) } } else { var root_2458 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2458, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2460 lang.IFn; if linked_2459 == nil { ifn_2460 = lang.IFn_Cast(root_2458) } else { ifn_2460 = nil }; var arg_2461 any; var root_2463 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = b__292000203__6; if linked_2464 == nil { arg_2461 = ifn_2465.Invoke_O__O(arg_2466) } else { arg_2461 = linked_2464.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2463, arg_2466) }; var arg_2462 any; if linked_2459 == nil { return ifn_2460.Invoke_O_O__O(arg_2461, arg_2462) } else { return linked_2459.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2458, arg_2461, arg_2462) } } } else { var f__4 any; var root_2467 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = s__292000201__3; if linked_2468 == nil { f__4 = ifn_2469.Invoke_O__O(arg_2470) } else { f__4 = linked_2468.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2467, arg_2470) }; var tmp6 any; var root_2471 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = f__4; if linked_2472 == nil { tmp6 = ifn_2473.Invoke_O__O(arg_2474) } else { tmp6 = linked_2472.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_2471, arg_2474) }; if jrt.J2g_Truth(tmp6) { var root_2475 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2475, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2477 lang.IFn; if linked_2476 == nil { ifn_2477 = lang.IFn_Cast(root_2475) } else { ifn_2477 = nil }; var arg_2478 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__4)); var arg_2479 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000200); var tmp8 any; var root_2480 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = s__292000201__3; if linked_2481 == nil { tmp8 = ifn_2482.Invoke_O__O(arg_2483) } else { tmp8 = linked_2481.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2480, arg_2483) }; arg_2479 = tmp7.Invoke_O__O(tmp8); if linked_2476 == nil { return ifn_2477.Invoke_O_O__O(arg_2478, arg_2479) } else { return linked_2476.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2475, arg_2478, arg_2479) } } else { var tmp9 any; var root_2484 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2486 lang.IFn; if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = s__292000201__3; if linked_2485 == nil { tmp9 = ifn_2486.Invoke_O__O(arg_2487) } else { tmp9 = linked_2485.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2484, arg_2487) }; s__292000201__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :420:1
func A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A) Ctor_O_I_O(c__b__292000203 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000203 = c__b__292000203; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :420:1
func (t *A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A) Invoke_O__O(self any) any { { var i__292000202__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000202__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000202__1)); var tmp2 any; var root_2434 any = A_arbace_j2g_dyncf_A_const_153.GetRawRoot__O(); var linked_2435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2434, A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class); var ifn_2436 lang.IFn; if linked_2435 == nil { ifn_2436 = lang.IFn_Cast(root_2434) } else { ifn_2436 = nil }; var arg_2437 any = f__2; if linked_2435 == nil { tmp2 = ifn_2436.Invoke_O__O(arg_2437) } else { tmp2 = linked_2435.(*A_arbace_j2g_dyncf_protected_field_QMARK__A).Invoke_O_O__O(root_2434, arg_2437) }; if jrt.J2g_Truth(tmp2) { var root_2438 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2438, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2440 lang.IFn; if linked_2439 == nil { ifn_2440 = lang.IFn_Cast(root_2438) } else { ifn_2440 = nil }; var arg_2441 any = t.F_b__292000203; var arg_2442 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__2)); if linked_2439 == nil { ifn_2440.Invoke_O_O__O(arg_2441, arg_2442) } else { linked_2439.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2438, arg_2441, arg_2442) }; i__292000202__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000202__1); continue L1 } else { i__292000202__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000202__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_dyncf_generics_text_A_New() *A_arbace_j2g_dyncf_generics_text_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Ctor() {}
//line :429:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Invoke_O_O__O(self, T__0_ any) any { var extendable__2 any; var root_2556 any = A_arbace_j2g_dyncf_A_const_376.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2558 lang.IFn; if





	linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any; var root_2560 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = A_arbace_j2g_dyncf_A_const_377.GetRawRoot__O(); var arg_2564 any = A_arbace_j2g_dyncf_A_const_378; if linked_2561 == nil { arg_2559 = ifn_2562.Invoke_O_O__O(arg_2563, arg_2564) } else { arg_2559 = linked_2561.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2560, arg_2563, arg_2564) }; if linked_2557 == nil { extendable__2 = ifn_2558.Invoke_O__O(arg_2559) } else { extendable__2 = linked_2557.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2556, arg_2559) }; var hw_entries__3 any; var root_2565 any = /*line :429:1*/A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2567 lang.IFn; if











	linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any; var iter__1927001039__auto____3 any; var fnbody__2880 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A_New(); var tmp1 *jrt.Class; var fncls__2879 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A_fn_class; if fncls__2879 == nil { var fncls__2879d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A_fn_class = fncls__2879d; tmp1 = fncls__2879d } else { tmp1 = fncls__2879 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2880, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_2881 any = A_arbace_j2g_dyncf_A_const_368.GetRawRoot__O(); var linked_2882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2881, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2883 lang.IFn; if linked_2882 == nil { ifn_2883 = lang.IFn_Cast(root_2881) } else { ifn_2883 = nil }; var arg_2884 any; var root_2885 any = A_arbace_j2g_dyncf_A_const_369.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = A_arbace_j2g_dyncf_A_const_377.GetRawRoot__O(); if linked_2886 == nil { arg_2884 = ifn_2887.Invoke_O__O(arg_2888) } else { arg_2884 = linked_2886.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_2885, arg_2888) }; if linked_2882 == nil { tmp3 = ifn_2883.Invoke_O__O(arg_2884) } else { tmp3 = linked_2882.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2881, arg_2884) }; arg_2568 = tmp2.Invoke_O__O(tmp3); if linked_2566 == nil { hw_entries__3 = ifn_2567.Invoke_O__O(arg_2568) } else { hw_entries__3 = linked_2566.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2565, arg_2568) }; var entries__4 any; var iter__1927001039__auto____4 any; var fnbody__3450 any = /*line :429:1*/A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A_New_O(extendable__2); var tmp4 *jrt.Class; var fncls__3449 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A_fn_class; if




















	fncls__3449 == nil { var fncls__3449d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__3450); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A_fn_class = fncls__3449d; tmp4 = fncls__3449d } else { tmp4 = fncls__3449 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3450, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp6 any; var root_4435 any = A_arbace_j2g_dyncf_A_const_368.GetRawRoot__O(); var linked_4436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4435, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4437 lang.IFn; if linked_4436 == nil { ifn_4437 = lang.IFn_Cast(root_4435) } else { ifn_4437 = nil }; var arg_4438 any = T__0_; if linked_4436 == nil { tmp6 = ifn_4437.Invoke_O__O(arg_4438) } else { tmp6 = linked_4436.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4435, arg_4438) }; entries__4 = tmp5.Invoke_O__O(tmp6); var consts__5 any; var iter__1927001039__auto____5 any; var fnbody__3822 any = /*line :429:1*/A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A_New(); var tmp7 *jrt.Class; var fncls__3821 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A_fn_class; if












































	fncls__3821 == nil { var fncls__3821d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A_fn_class = fncls__3821d; tmp7 = fncls__3821d } else { tmp7 = fncls__3821 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3822, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp9 any; var root_4439 any = A_arbace_j2g_dyncf_A_const_368.GetRawRoot__O(); var linked_4440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4439, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4441 lang.IFn; if linked_4440 == nil { ifn_4441 = lang.IFn_Cast(root_4439) } else { ifn_4441 = nil }; var arg_4442 any = T__0_; if linked_4440 == nil { tmp9 = ifn_4441.Invoke_O__O(arg_4442) } else { tmp9 = linked_4440.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4439, arg_4442) }; consts__5 = tmp8.Invoke_O__O(tmp9); var tset__6 any; var root_3823 any = /*line :429:1*/A_arbace_j2g_dyncf_A_const_376.GetRawRoot__O(); var linked_3824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3823, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_3825 lang.IFn; if




























































	linked_3824 == nil { ifn_3825 = lang.IFn_Cast(root_3823) } else { ifn_3825 = nil }; var arg_3826 any = T__0_; if linked_3824 == nil { tset__6 = ifn_3825.Invoke_O__O(arg_3826) } else { tset__6 = linked_3824.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_3823, arg_3826) }; var edge_consts__7 any; var iter__1927001039__auto____7 any; var fnbody__4158 any = /*line :429:1*/A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A_New_O(tset__6); var tmp10 *jrt.Class; var fncls__4157 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A_fn_class; if





























































	fncls__4157 == nil { var fncls__4157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__4158); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A_fn_class = fncls__4157d; tmp10 = fncls__4157d } else { tmp10 = fncls__4157 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4158, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp12 any; var root_4443 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_4444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4443, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_4445 lang.IFn; if linked_4444 == nil { ifn_4445 = lang.IFn_Cast(root_4443) } else { ifn_4445 = nil }; var arg_4446 any = A_arbace_j2g_dyncf_A_const_415.GetRawRoot__O(); var tmp13 *lang.Keyword = A_arbace_j2g_dyncf_A_const_416; var arg_4447 any = tmp13.Invoke_O__O(A_arbace_j2g_dyncf_A_const_417.Get__O()); if linked_4444 == nil { tmp12 = ifn_4445.Invoke_O_O__O(arg_4446, arg_4447) } else { tmp12 = linked_4444.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_4443, arg_4446, arg_4447) }; edge_consts__7 = tmp11.Invoke_O__O(tmp12); var consts__8 any; var root_4159 any = /*line :429:1*/A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_4160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4159, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_4161 lang.IFn; if









































































	linked_4160 == nil { ifn_4161 = lang.IFn_Cast(root_4159) } else { ifn_4161 = nil }; var arg_4162 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var arg_4163 any; var root_4164 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_4165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4164, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4166 lang.IFn; if linked_4165 == nil { ifn_4166 = lang.IFn_Cast(root_4164) } else { ifn_4166 = nil }; var arg_4167 any = consts__5; var arg_4168 any = edge_consts__7; if linked_4165 == nil { arg_4163 = ifn_4166.Invoke_O_O__O(arg_4167, arg_4168) } else { arg_4163 = linked_4165.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4164, arg_4167, arg_4168) }; if linked_4160 == nil { consts__8 = ifn_4161.Invoke_O_O__O(arg_4162, arg_4163) } else { consts__8 = linked_4160.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_4159, arg_4162, arg_4163) }; var protected__9 any; var root_4169 any = /*line :429:1*/A_arbace_j2g_dyncf_A_const_412.GetRawRoot__O(); var linked_4170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4169, A_arbace_j2g_dyncf_protected_members_A_fn_class); var ifn_4171 lang.IFn; if














































































	linked_4170 == nil { ifn_4171 = lang.IFn_Cast(root_4169) } else { ifn_4171 = nil }; var arg_4172 any = T__0_; if linked_4170 == nil { protected__9 = ifn_4171.Invoke_O__O(arg_4172) } else { protected__9 = linked_4170.(*A_arbace_j2g_dyncf_protected_members_A).Invoke_O_O__O(root_4169, arg_4172) }; var root_4448 any =
	A_arbace_j2g_dyncf_A_const_39.GetRawRoot__O(); var linked_4449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4448, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4450 lang.IFn; if linked_4449 == nil { ifn_4450 = lang.IFn_Cast(root_4448) } else { ifn_4450 = nil }; var arg_4451 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_418, nil, A_arbace_j2g_dyncf_A_const_419, nil, A_arbace_j2g_dyncf_A_const_420, jrt.Boolean_FALSE.Ref()); if linked_4449 == nil { ifn_4450.Invoke_O__O(arg_4451) } else { linked_4449.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4448, arg_4451) }; var tmp14 any; tmp26 := /*line :429:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
















































































		{ var tmp15 *jrt.RefArray = jrt.ConstRefArray("[0,9,s92:;; Written by j2g --program (arbace.j2g.dyncf/generics-text): the generic signatures of the\ns93:;; classes of the world, for the Java forms' analysis (doc/go/CLASSFORMS-REPL.md), and under\ns44:;; :consts their public constants' values.\n{ns11:\n :consts {ns15:}\n :protected {ns3:}}\n", []*jrt.Class{jrt.String_class}); var tmp16 any; var root_4173 any = A_arbace_j2g_dyncf_A_const_413.GetRawRoot__O(); var linked_4174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4173, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_4175 lang.IFn


			if linked_4174 == nil { ifn_4175 = lang.IFn_Cast(root_4173) } else { ifn_4175 = nil }; var arg_4176 any = Lit_36; var arg_4177 any; var iter__1927001039__auto____21 any; var fnbody__4255 any = A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A_New(); var tmp17 *jrt.Class; var fncls__4254 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A_fn_class; if fncls__4254 == nil { var fncls__4254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A_fn_class = fncls__4254d; tmp17 = fncls__4254d } else { tmp17 = fncls__4254 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4255, tmp17, nil); var tmp18 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____21); var tmp19 any; var root_4256 any = A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(); var linked_4257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4256, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_4258 lang.IFn; if linked_4257 == nil { ifn_4258 = lang.IFn_Cast(root_4256) } else { ifn_4258 = nil }; var arg_4259 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var arg_4260 any; var root_4261 any = A_arbace_j2g_dyncf_A_const_191.GetRawRoot__O(); var linked_4262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4261, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4263 lang.IFn; if linked_4262 == nil { ifn_4263 = lang.IFn_Cast(root_4261) } else { ifn_4263 = nil }; var arg_4264 any = entries__4; var arg_4265 any = hw_entries__3; if linked_4262 == nil { arg_4260 = ifn_4263.Invoke_O_O__O(arg_4264, arg_4265) } else { arg_4260 = linked_4262.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4261, arg_4264, arg_4265) }; if linked_4257 == nil { tmp19 = ifn_4258.Invoke_O_O__O(arg_4259, arg_4260) } else { tmp19 = linked_4257.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_4256, arg_4259, arg_4260) }; arg_4177 = tmp18.Invoke_O__O(tmp19); if linked_4174 == nil { tmp16 = ifn_4175.Invoke_O_O__O(arg_4176, arg_4177) } else { tmp16 = linked_4174.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_4173, arg_4176, arg_4177) }
//line :510:1
			var tmp20 any = tmp16; var tmp21 any; var root_4266 any = A_arbace_j2g_dyncf_A_const_413.GetRawRoot__O(); var linked_4267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4266, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_4268 lang.IFn




			if linked_4267 == nil { ifn_4268 = lang.IFn_Cast(root_4266) } else { ifn_4268 = nil }; var arg_4269 any = Lit_38; var arg_4270 any; var iter__1927001039__auto____21_2 any; var fnbody__4348 any = A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A_New(); var tmp22 *jrt.Class; var fncls__4347 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A_fn_class; if fncls__4347 == nil { var fncls__4347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A_fn_class = fncls__4347d; tmp22 = fncls__4347d } else { tmp22 = fncls__4347 }; iter__1927001039__auto____21_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4348, tmp22, nil); arg_4270 = lang.IFn_Cast(iter__1927001039__auto____21_2).Invoke_O__O(consts__8); if linked_4267 == nil { tmp21 = ifn_4268.Invoke_O_O__O(arg_4269, arg_4270) } else { tmp21 = linked_4267.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_4266, arg_4269, arg_4270) }
//line :510:1
			var tmp23 any = tmp21; var tmp24 any; var root_4349 any = A_arbace_j2g_dyncf_A_const_413.GetRawRoot__O(); var linked_4350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4349, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_4351 lang.IFn






			if linked_4350 == nil { ifn_4351 = lang.IFn_Cast(root_4349) } else { ifn_4351 = nil }; var arg_4352 any = Lit_38; var arg_4353 any; var iter__1927001039__auto____21_3 any; var fnbody__4431 any = A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A_New(); var tmp25 *jrt.Class; var fncls__4430 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A_fn_class; if fncls__4430 == nil { var fncls__4430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A_fn_class = fncls__4430d; tmp25 = fncls__4430d } else { tmp25 = fncls__4430 }; iter__1927001039__auto____21_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4431, tmp25, nil); arg_4353 = lang.IFn_Cast(iter__1927001039__auto____21_3).Invoke_O__O(protected__9); if linked_4350 == nil { tmp24 = ifn_4351.Invoke_O_O__O(arg_4352, arg_4353) } else { tmp24 = linked_4350.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_4349, arg_4352, arg_4353) }
//line :510:1
			tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp20, nil, tmp23, nil, tmp24, nil)).Ref() }
//line :429:1
		return nil }(); var root_4432 any = A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_4433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4432, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4434 lang.IFn; if















































































	linked_4433 == nil { ifn_4434 = lang.IFn_Cast(root_4432) } else { ifn_4434 = nil }; if linked_4433 == nil { ifn_4434.Invoke__O() } else { linked_4433.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4432) }; if /*line :429:1*/ tmp26 != nil { panic(tmp26) }; return tmp14 }











func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A{}; t.Ctor(); return t }
//line :441:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A) Ctor() {}
//line :441:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A) Invoke_O_O__O(self, s__292000215__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2878 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A_New_O_O(self, s__292000215__1); var tmp2 *jrt.Class; var fncls__2877 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A_fn_class; if fncls__2877 == nil { var fncls__2877d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__2878); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A_fn_class = fncls__2877d; tmp2 = fncls__2877d } else { tmp2 = fncls__2877 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2878, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :441:1
func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A{}; t.Ctor_O_O(p0, p1); return t }
//line :441:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A) Ctor_O_O(c__iter__292000214, c__s__292000215 any) { t.F_iter__292000214 = c__iter__292000214; t.F_s__292000215 = c__s__292000215 }
//line :441:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A) Invoke_O__O(self any) any { { var s__292000215__1 any; var t_ any = t.F_s__292000215; t.F_s__292000215 = nil; s__292000215__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2569 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2569, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2571 lang.IFn; if linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var arg_2572 any = s__292000215__1; if linked_2570 == nil { temp__1927000414__auto____2 = ifn_2571.Invoke_O__O(arg_2572) } else { temp__1927000414__auto____2 = linked_2570.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2569, arg_2572) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000215__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2573 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2573, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2575 lang.IFn; if linked_2574 == nil { ifn_2575 = lang.IFn_Cast(root_2573) } else { ifn_2575 = nil }; var arg_2576 any = s__292000215__3; if linked_2574 == nil { tmp1 = ifn_2575.Invoke_O__O(arg_2576) } else { tmp1 = linked_2574.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2573, arg_2576) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2577 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2577, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2579 lang.IFn; if linked_2578 == nil { ifn_2579 = lang.IFn_Cast(root_2577) } else { ifn_2579 = nil }; var arg_2580 any = s__292000215__3; if linked_2578 == nil { c__1927001037__auto____4 = ifn_2579.Invoke_O__O(arg_2580) } else { c__1927001037__auto____4 = linked_2578.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2577, arg_2580) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000217__6 any; var root_2581 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2583 lang.IFn; if linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2582 == nil { b__292000217__6 = ifn_2583.Invoke_O__O(arg_2584) } else { b__292000217__6 = linked_2582.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2581, arg_2584) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2712 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A_New_O_I_O(b__292000217__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2711 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A_fn_class; if fncls__2711 == nil { var fncls__2711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__2712); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A_fn_class = fncls__2711d; tmp3 = fncls__2711d } else { tmp3 = fncls__2711 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2712, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2713 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2715 lang.IFn; if linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any; var root_2718 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2718, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2720 lang.IFn; if linked_2719 == nil { ifn_2720 = lang.IFn_Cast(root_2718) } else { ifn_2720 = nil }; var arg_2721 any = b__292000217__6; if linked_2719 == nil { arg_2716 = ifn_2720.Invoke_O__O(arg_2721) } else { arg_2716 = linked_2719.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2718, arg_2721) }; var arg_2717 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000214); var tmp5 any; var root_2722 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2722, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2724 lang.IFn; if linked_2723 == nil { ifn_2724 = lang.IFn_Cast(root_2722) } else { ifn_2724 = nil }; var arg_2725 any = s__292000215__3; if linked_2723 == nil { tmp5 = ifn_2724.Invoke_O__O(arg_2725) } else { tmp5 = linked_2723.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2722, arg_2725) }; arg_2717 = tmp4.Invoke_O__O(tmp5); if linked_2714 == nil { return ifn_2715.Invoke_O_O__O(arg_2716, arg_2717) } else { return linked_2714.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2713, arg_2716, arg_2717) } } else { var root_2726 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2726, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2728 lang.IFn; if linked_2727 == nil { ifn_2728 = lang.IFn_Cast(root_2726) } else { ifn_2728 = nil }; var arg_2729 any; var root_2731 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2731, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2733 lang.IFn; if linked_2732 == nil { ifn_2733 = lang.IFn_Cast(root_2731) } else { ifn_2733 = nil }; var arg_2734 any = b__292000217__6; if linked_2732 == nil { arg_2729 = ifn_2733.Invoke_O__O(arg_2734) } else { arg_2729 = linked_2732.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2731, arg_2734) }; var arg_2730 any; if linked_2727 == nil { return ifn_2728.Invoke_O_O__O(arg_2729, arg_2730) } else { return linked_2727.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2726, arg_2729, arg_2730) } } } else { var n__4 any; var root_2735 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2735, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2737 lang.IFn; if linked_2736 == nil { ifn_2737 = lang.IFn_Cast(root_2735) } else { ifn_2737 = nil }; var arg_2738 any = s__292000215__3; if linked_2736 == nil { n__4 = ifn_2737.Invoke_O__O(arg_2738) } else { n__4 = linked_2736.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2735, arg_2738) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2739 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_2740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2739, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2741 lang.IFn
														if linked_2740 == nil { ifn_2741 = lang.IFn_Cast(root_2739) } else { ifn_2741 = nil }; var arg_2742 any = n__4; if linked_2740 == nil { and__1927000168__auto____5 = ifn_2741.Invoke_O__O(arg_2742) } else { and__1927000168__auto____5 = linked_2740.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2739, arg_2742) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2743 any = A_arbace_j2g_dyncf_A_const_379.GetRawRoot__O(); var linked_2744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2743, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_2745 lang.IFn; if linked_2744 == nil { ifn_2745 = lang.IFn_Cast(root_2743) } else { ifn_2745 = nil }; var arg_2746 any = n__4; if linked_2744 == nil { tmp6 = ifn_2745.Invoke_O__O(arg_2746) } else { tmp6 = linked_2744.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_2743, arg_2746) } } else { tmp6 = and__1927000168__auto____5 }
//line :441:1
	if jrt.J2g_Truth(tmp6) { var g__5 any; var tmp7 *lang.Compiler_AOTFn; var fnbody__2748 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A_New_O(n__4); var tmp8 *jrt.Class
		var fncls__2747 /*line :441:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A_fn_class

		if fncls__2747 == nil { var fncls__2747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__2748); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A_fn_class = fncls__2747d; tmp8 = fncls__2747d } else { tmp8 = fncls__2747 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2748, tmp8, nil); g__5 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O()
//line :441:1
		var tmp9 any
		var and__1927000168__auto____6 any = g__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2749 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2749, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2751 lang.IFn; if linked_2750 == nil { ifn_2751 = lang.IFn_Cast(root_2749) } else { ifn_2751 = nil }; var arg_2752 any = A_arbace_j2g_dyncf_A_const_381.Invoke_O__O(g__5); if linked_2750 == nil { tmp9 = ifn_2751.Invoke_O__O(arg_2752) } else { tmp9 = linked_2750.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2749, arg_2752) } } else { tmp9 = and__1927000168__auto____6 }
//line :441:1
		if jrt.J2g_Truth(tmp9) { var root_2753 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2753, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2755 lang.IFn; if linked_2754 == nil { ifn_2755 = lang.IFn_Cast(root_2753) } else { ifn_2755 = nil }; var arg_2756 any; var tmp10 any; var root_2758 any = A_arbace_j2g_dyncf_A_const_382.GetRawRoot__O(); var linked_2759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2758, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_2760 lang.IFn



			if linked_2759 == nil { ifn_2760 = lang.IFn_Cast(root_2758) } else { ifn_2760 = nil }; var arg_2761 any; var tmp11 any = A_arbace_j2g_dyncf_A_const_381; var tmp12 any; var root_2762 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2764 lang.IFn
			if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = A_arbace_j2g_dyncf_A_const_381.Invoke_O__O(g__5); if linked_2763 == nil { tmp12 = ifn_2764.Invoke_O__O(arg_2765) } else { tmp12 = linked_2763.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2762, arg_2765) }
//line :445:1
			var tmp13 any = tmp12; var tmp14 any = A_arbace_j2g_dyncf_A_const_383; var tmp15 any; var root_2766 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2768 lang.IFn
			if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any; var root_2770 any = A_arbace_j2g_dyncf_A_const_384.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2772 lang.IFn; if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = A_arbace_j2g_dyncf_A_const_385.GetRawRoot__O(); var arg_2774 any = A_arbace_j2g_dyncf_A_const_383.Invoke_O__O(g__5); if linked_2771 == nil { arg_2769 = ifn_2772.Invoke_O_O__O(arg_2773, arg_2774) } else { arg_2769 = linked_2771.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2770, arg_2773, arg_2774) }; if linked_2767 == nil { tmp15 = ifn_2768.Invoke_O__O(arg_2769) } else { tmp15 = linked_2767.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2766, arg_2769) }
//line :445:1
			var tmp16 any = tmp15; var tmp17 any = A_arbace_j2g_dyncf_A_const_108; var tmp18 any; var root_2775 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2775, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2777 lang.IFn

			if linked_2776 == nil { ifn_2777 = lang.IFn_Cast(root_2775) } else { ifn_2777 = nil }; var arg_2778 any; var iter__1927001039__auto____6 any; var fnbody__2864 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A_New(); var tmp19 *jrt.Class; var fncls__2863 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A_fn_class; if fncls__2863 == nil { var fncls__2863d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A_fn_class = fncls__2863d; tmp19 = fncls__2863d } else { tmp19 = fncls__2863 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2864, tmp19, nil); arg_2778 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__5)); if linked_2776 == nil { tmp18 = ifn_2777.Invoke_O__O(arg_2778) } else { tmp18 = linked_2776.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2775, arg_2778) }
//line :445:1
			arg_2761 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp14, tmp16, tmp17, tmp18)); if linked_2759 == nil { tmp10 = ifn_2760.Invoke_O__O(arg_2761) } else { tmp10 = linked_2759.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_2758, arg_2761) }
//line :441:1
			arg_2756 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp10); var arg_2757 any; var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__292000214); var tmp21 any; var root_2865 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2865, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2867 lang.IFn; if linked_2866 == nil { ifn_2867 = lang.IFn_Cast(root_2865) } else { ifn_2867 = nil }; var arg_2868 any = s__292000215__3; if linked_2866 == nil { tmp21 = ifn_2867.Invoke_O__O(arg_2868) } else { tmp21 = linked_2866.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2865, arg_2868) }; arg_2757 = tmp20.Invoke_O__O(tmp21); if linked_2754 == nil { return ifn_2755.Invoke_O_O__O(arg_2756, arg_2757) } else { return linked_2754.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2753, arg_2756, arg_2757) } } else { var tmp22 any; var root_2869 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2869, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2871 lang.IFn; if linked_2870 == nil { ifn_2871 = lang.IFn_Cast(root_2869) } else { ifn_2871 = nil }; var arg_2872 any = s__292000215__3; if linked_2870 == nil { tmp22 = ifn_2871.Invoke_O__O(arg_2872) } else { tmp22 = linked_2870.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2869, arg_2872) }; s__292000215__1 = tmp22; continue L1 } } else { var tmp23 any; var root_2873 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2873, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2875 lang.IFn; if linked_2874 == nil { ifn_2875 = lang.IFn_Cast(root_2873) } else { ifn_2875 = nil }; var arg_2876 any = s__292000215__3; if linked_2874 == nil { tmp23 = ifn_2875.Invoke_O__O(arg_2876) } else { tmp23 = linked_2874.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2873, arg_2876) }; s__292000215__1 = tmp23; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :441:1
func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :441:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A) Ctor_O_I_O(c__b__292000217 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000217 = c__b__292000217; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :441:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A) Invoke_O__O(self any) any { { var i__292000216__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000216__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000216__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2585 any = A_arbace_j2g_dyncf_A_const_50.GetRawRoot__O(); var linked_2586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2585, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2587 lang.IFn
																if linked_2586 == nil { ifn_2587 = lang.IFn_Cast(root_2585) } else { ifn_2587 = nil }; var arg_2588 any = n__2; if linked_2586 == nil { and__1927000168__auto____3 = ifn_2587.Invoke_O__O(arg_2588) } else { and__1927000168__auto____3 = linked_2586.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2585, arg_2588) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2589 any = A_arbace_j2g_dyncf_A_const_379.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2589, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any = n__2; if linked_2590 == nil { tmp2 = ifn_2591.Invoke_O__O(arg_2592) } else { tmp2 = linked_2590.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_2589, arg_2592) } } else { tmp2 = and__1927000168__auto____3 }
//line :441:1
	if jrt.J2g_Truth(tmp2) { var g__3 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__2594 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A_New_O(n__2); var tmp4 *jrt.Class
		var fncls__2593 /*line :441:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A_fn_class

		if fncls__2593 == nil { var fncls__2593d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__2594); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A_fn_class = fncls__2593d; tmp4 = fncls__2593d } else { tmp4 = fncls__2593 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2594, tmp4, nil); g__3 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()
//line :441:1
		var tmp5 any
		var and__1927000168__auto____4 any = g__3

		if jrt.J2g_Truth(and__1927000168__auto____4) { var root_2595 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2597 lang.IFn; if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any = A_arbace_j2g_dyncf_A_const_381.Invoke_O__O(g__3); if linked_2596 == nil { tmp5 = ifn_2597.Invoke_O__O(arg_2598) } else { tmp5 = linked_2596.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2595, arg_2598) } } else { tmp5 = and__1927000168__auto____4 }
//line :441:1
		if jrt.J2g_Truth(tmp5) { var root_2599 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2599, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2601 lang.IFn; if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any = t.F_b__292000217; var arg_2603 any; var tmp6 any; var root_2604 any = A_arbace_j2g_dyncf_A_const_382.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_2606 lang.IFn



			if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any; var tmp7 any = A_arbace_j2g_dyncf_A_const_381; var tmp8 any; var root_2608 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2610 lang.IFn
			if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = A_arbace_j2g_dyncf_A_const_381.Invoke_O__O(g__3); if linked_2609 == nil { tmp8 = ifn_2610.Invoke_O__O(arg_2611) } else { tmp8 = linked_2609.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2608, arg_2611) }
//line :445:1
			var tmp9 any = tmp8; var tmp10 any = A_arbace_j2g_dyncf_A_const_383; var tmp11 any; var root_2612 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2614 lang.IFn
			if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any; var root_2616 any = A_arbace_j2g_dyncf_A_const_384.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = A_arbace_j2g_dyncf_A_const_385.GetRawRoot__O(); var arg_2620 any = A_arbace_j2g_dyncf_A_const_383.Invoke_O__O(g__3); if linked_2617 == nil { arg_2615 = ifn_2618.Invoke_O_O__O(arg_2619, arg_2620) } else { arg_2615 = linked_2617.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2616, arg_2619, arg_2620) }; if linked_2613 == nil { tmp11 = ifn_2614.Invoke_O__O(arg_2615) } else { tmp11 = linked_2613.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2612, arg_2615) }
//line :445:1
			var tmp12 any = tmp11; var tmp13 any = A_arbace_j2g_dyncf_A_const_108; var tmp14 any; var root_2621 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2623 lang.IFn

			if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any; var iter__1927001039__auto____4 any; var fnbody__2710 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A_New(); var tmp15 *jrt.Class; var fncls__2709 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A_fn_class; if fncls__2709 == nil { var fncls__2709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A_fn_class = fncls__2709d; tmp15 = fncls__2709d } else { tmp15 = fncls__2709 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2710, tmp15, nil); arg_2624 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__3)); if linked_2622 == nil { tmp14 = ifn_2623.Invoke_O__O(arg_2624) } else { tmp14 = linked_2622.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2621, arg_2624) }
//line :445:1
			arg_2607 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, tmp10, tmp12, tmp13, tmp14)); if linked_2605 == nil { tmp6 = ifn_2606.Invoke_O__O(arg_2607) } else { tmp6 = linked_2605.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_2604, arg_2607) }
//line :441:1
			arg_2603 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp6); if linked_2600 == nil { ifn_2601.Invoke_O_O__O(arg_2602, arg_2603) } else { linked_2600.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2599, arg_2602, arg_2603) }; i__292000216__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000216__1); continue L1 } else { i__292000216__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000216__1); continue L1 } } else { i__292000216__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000216__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A{}; t.Ctor_O(p0); return t }
//line :443:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :443:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_380; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :443:1
func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A{}; t.Ctor_O(p0); return t }
//line :443:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :443:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_380; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }



func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A) Ctor() {}
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A) Invoke_O_O__O(self, s__292000224__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2708 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A_New_O_O(self, s__292000224__1); var tmp2 *jrt.Class; var fncls__2707 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A_fn_class; if fncls__2707 == nil { var fncls__2707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__2708); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A_fn_class = fncls__2707d; tmp2 = fncls__2707d } else { tmp2 = fncls__2707 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2708, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :447:1
func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A) Ctor_O_O(c__iter__292000223, c__s__292000224 any) { t.F_iter__292000223 = c__iter__292000223; t.F_s__292000224 = c__s__292000224 }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A) Invoke_O__O(self any) any { { var s__292000224__1 any; var t_ any = t.F_s__292000224; t.F_s__292000224 = nil; s__292000224__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2625 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any = s__292000224__1; if linked_2626 == nil { temp__1927000414__auto____2 = ifn_2627.Invoke_O__O(arg_2628) } else { temp__1927000414__auto____2 = linked_2626.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2625, arg_2628) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000224__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2629 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = s__292000224__3; if linked_2630 == nil { tmp1 = ifn_2631.Invoke_O__O(arg_2632) } else { tmp1 = linked_2630.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2629, arg_2632) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2633 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2635 lang.IFn; if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any = s__292000224__3; if linked_2634 == nil { c__1927001037__auto____4 = ifn_2635.Invoke_O__O(arg_2636) } else { c__1927001037__auto____4 = linked_2634.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2633, arg_2636) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000226__6 any; var root_2637 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2638 == nil { b__292000226__6 = ifn_2639.Invoke_O__O(arg_2640) } else { b__292000226__6 = linked_2638.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2637, arg_2640) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2657 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A_New_O_I_O(b__292000226__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2656 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A_fn_class; if fncls__2656 == nil { var fncls__2656d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__2657); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A_fn_class = fncls__2656d; tmp3 = fncls__2656d } else { tmp3 = fncls__2656 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2657, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2658 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2658, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2660 lang.IFn; if linked_2659 == nil { ifn_2660 = lang.IFn_Cast(root_2658) } else { ifn_2660 = nil }; var arg_2661 any; var root_2663 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2663, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2665 lang.IFn; if linked_2664 == nil { ifn_2665 = lang.IFn_Cast(root_2663) } else { ifn_2665 = nil }; var arg_2666 any = b__292000226__6; if linked_2664 == nil { arg_2661 = ifn_2665.Invoke_O__O(arg_2666) } else { arg_2661 = linked_2664.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2663, arg_2666) }; var arg_2662 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000223); var tmp5 any; var root_2667 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2667, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2669 lang.IFn; if linked_2668 == nil { ifn_2669 = lang.IFn_Cast(root_2667) } else { ifn_2669 = nil }; var arg_2670 any = s__292000224__3; if linked_2668 == nil { tmp5 = ifn_2669.Invoke_O__O(arg_2670) } else { tmp5 = linked_2668.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2667, arg_2670) }; arg_2662 = tmp4.Invoke_O__O(tmp5); if linked_2659 == nil { return ifn_2660.Invoke_O_O__O(arg_2661, arg_2662) } else { return linked_2659.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2658, arg_2661, arg_2662) } } else { var root_2671 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2671, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2673 lang.IFn; if linked_2672 == nil { ifn_2673 = lang.IFn_Cast(root_2671) } else { ifn_2673 = nil }; var arg_2674 any; var root_2676 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2676, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2678 lang.IFn; if linked_2677 == nil { ifn_2678 = lang.IFn_Cast(root_2676) } else { ifn_2678 = nil }; var arg_2679 any = b__292000226__6; if linked_2677 == nil { arg_2674 = ifn_2678.Invoke_O__O(arg_2679) } else { arg_2674 = linked_2677.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2676, arg_2679) }; var arg_2675 any; if linked_2672 == nil { return ifn_2673.Invoke_O_O__O(arg_2674, arg_2675) } else { return linked_2672.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2671, arg_2674, arg_2675) } } } else { var mm__4 any; var root_2680 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any = s__292000224__3; if linked_2681 == nil { mm__4 = ifn_2682.Invoke_O__O(arg_2683) } else { mm__4 = linked_2681.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2680, arg_2683) }; var tmp6 int64; var na_2684 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { na_2684 = or__1927000174__auto____5 } else { na_2684 = A_arbace_j2g_dyncf_A_const_365 }; var na_2685 int64 = 4098; if jrt.Long_InstanceOf(na_2684) { var n0_2686 int64 = jrt.NN(jrt.Long_Cast(na_2684)).LongValue__J(); var n1_2687 int64 = na_2685; tmp6 = n0_2686 & n1_2687 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_2684, na_2685) }
//line :447:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_2689 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2689, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2691 lang.IFn; if linked_2690 == nil { ifn_2691 = lang.IFn_Cast(root_2689) } else { ifn_2691 = nil }; var arg_2692 any; var root_2694 any = A_arbace_j2g_dyncf_A_const_386.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2694, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2696 lang.IFn

		if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any = mm__4; var arg_2698 any = A_arbace_j2g_dyncf_A_const_388; if linked_2695 == nil { arg_2692 = ifn_2696.Invoke_O_O__O(arg_2697, arg_2698) } else { arg_2692 = linked_2695.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2694, arg_2697, arg_2698) }
//line :447:1
		var arg_2693 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000223); var tmp8 any; var root_2699 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2701 lang.IFn; if linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; var arg_2702 any = s__292000224__3; if linked_2700 == nil { tmp8 = ifn_2701.Invoke_O__O(arg_2702) } else { tmp8 = linked_2700.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2699, arg_2702) }; arg_2693 = tmp7.Invoke_O__O(tmp8); if linked_2690 == nil { return ifn_2691.Invoke_O_O__O(arg_2692, arg_2693) } else { return linked_2690.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2689, arg_2692, arg_2693) } } else { var tmp9 any; var root_2703 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = s__292000224__3; if linked_2704 == nil { tmp9 = ifn_2705.Invoke_O__O(arg_2706) } else { tmp9 = linked_2704.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2703, arg_2706) }; s__292000224__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :447:1
func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A) Ctor_O_I_O(c__b__292000226 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000226 = c__b__292000226; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A) Invoke_O__O(self any) any { { var i__292000225__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000225__1)); var tmp2 int64; var na_2641 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { na_2641 = or__1927000174__auto____3 } else { na_2641 = A_arbace_j2g_dyncf_A_const_365 }; var na_2642 int64 = 4098; if jrt.Long_InstanceOf(na_2641) { var n0_2643 int64 = jrt.NN(jrt.Long_Cast(na_2641)).LongValue__J(); var n1_2644 int64 = na_2642; tmp2 = n0_2643 & n1_2644 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_2641, na_2642) }
//line :447:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_2646 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = t.F_b__292000226; var arg_2650 any; var root_2651 any = A_arbace_j2g_dyncf_A_const_386.GetRawRoot__O(); var linked_2652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2651, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2653 lang.IFn

		if linked_2652 == nil { ifn_2653 = lang.IFn_Cast(root_2651) } else { ifn_2653 = nil }; var arg_2654 any = mm__2; var arg_2655 any = A_arbace_j2g_dyncf_A_const_387; if linked_2652 == nil { arg_2650 = ifn_2653.Invoke_O_O__O(arg_2654, arg_2655) } else { arg_2650 = linked_2652.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2651, arg_2654, arg_2655) }
//line :447:1
		if linked_2647 == nil { ifn_2648.Invoke_O_O__O(arg_2649, arg_2650) } else { linked_2647.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2646, arg_2649, arg_2650) }; i__292000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000225__1); continue L1 } else { i__292000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000225__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :447:1
func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A) Ctor() {}
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A) Invoke_O_O__O(self, s__292000237__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2862 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A_New_O_O(self, s__292000237__1); var tmp2 *jrt.Class; var fncls__2861 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A_fn_class; if fncls__2861 == nil { var fncls__2861d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__2862); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A_fn_class = fncls__2861d; tmp2 = fncls__2861d } else { tmp2 = fncls__2861 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2862, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :447:1
func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A{}; t.Ctor_O_O(p0, p1); return t }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A) Ctor_O_O(c__iter__292000236, c__s__292000237 any) { t.F_iter__292000236 = c__iter__292000236; t.F_s__292000237 = c__s__292000237 }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A) Invoke_O__O(self any) any { { var s__292000237__1 any; var t_ any = t.F_s__292000237; t.F_s__292000237 = nil; s__292000237__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2779 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2779, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2781 lang.IFn; if linked_2780 == nil { ifn_2781 = lang.IFn_Cast(root_2779) } else { ifn_2781 = nil }; var arg_2782 any = s__292000237__1; if linked_2780 == nil { temp__1927000414__auto____2 = ifn_2781.Invoke_O__O(arg_2782) } else { temp__1927000414__auto____2 = linked_2780.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2779, arg_2782) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000237__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2783 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2783, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2785 lang.IFn; if linked_2784 == nil { ifn_2785 = lang.IFn_Cast(root_2783) } else { ifn_2785 = nil }; var arg_2786 any = s__292000237__3; if linked_2784 == nil { tmp1 = ifn_2785.Invoke_O__O(arg_2786) } else { tmp1 = linked_2784.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2783, arg_2786) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2787 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2787, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2789 lang.IFn; if linked_2788 == nil { ifn_2789 = lang.IFn_Cast(root_2787) } else { ifn_2789 = nil }; var arg_2790 any = s__292000237__3; if linked_2788 == nil { c__1927001037__auto____4 = ifn_2789.Invoke_O__O(arg_2790) } else { c__1927001037__auto____4 = linked_2788.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2787, arg_2790) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000239__6 any; var root_2791 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2791, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2793 lang.IFn; if linked_2792 == nil { ifn_2793 = lang.IFn_Cast(root_2791) } else { ifn_2793 = nil }; var arg_2794 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2792 == nil { b__292000239__6 = ifn_2793.Invoke_O__O(arg_2794) } else { b__292000239__6 = linked_2792.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2791, arg_2794) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2811 any = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A_New_O_I_O(b__292000239__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2810 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A_fn_class; if fncls__2810 == nil { var fncls__2810d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__2811); A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A_fn_class = fncls__2810d; tmp3 = fncls__2810d } else { tmp3 = fncls__2810 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2811, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2812 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2812, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2814 lang.IFn; if linked_2813 == nil { ifn_2814 = lang.IFn_Cast(root_2812) } else { ifn_2814 = nil }; var arg_2815 any; var root_2817 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2817, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2819 lang.IFn; if linked_2818 == nil { ifn_2819 = lang.IFn_Cast(root_2817) } else { ifn_2819 = nil }; var arg_2820 any = b__292000239__6; if linked_2818 == nil { arg_2815 = ifn_2819.Invoke_O__O(arg_2820) } else { arg_2815 = linked_2818.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2817, arg_2820) }; var arg_2816 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000236); var tmp5 any; var root_2821 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_2822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2821, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2823 lang.IFn; if linked_2822 == nil { ifn_2823 = lang.IFn_Cast(root_2821) } else { ifn_2823 = nil }; var arg_2824 any = s__292000237__3; if linked_2822 == nil { tmp5 = ifn_2823.Invoke_O__O(arg_2824) } else { tmp5 = linked_2822.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2821, arg_2824) }; arg_2816 = tmp4.Invoke_O__O(tmp5); if linked_2813 == nil { return ifn_2814.Invoke_O_O__O(arg_2815, arg_2816) } else { return linked_2813.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2812, arg_2815, arg_2816) } } else { var root_2825 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any; var root_2830 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_2831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2830, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2832 lang.IFn; if linked_2831 == nil { ifn_2832 = lang.IFn_Cast(root_2830) } else { ifn_2832 = nil }; var arg_2833 any = b__292000239__6; if linked_2831 == nil { arg_2828 = ifn_2832.Invoke_O__O(arg_2833) } else { arg_2828 = linked_2831.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2830, arg_2833) }; var arg_2829 any; if linked_2826 == nil { return ifn_2827.Invoke_O_O__O(arg_2828, arg_2829) } else { return linked_2826.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2825, arg_2828, arg_2829) } } } else { var mm__4 any; var root_2834 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_2835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2834, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2836 lang.IFn; if linked_2835 == nil { ifn_2836 = lang.IFn_Cast(root_2834) } else { ifn_2836 = nil }; var arg_2837 any = s__292000237__3; if linked_2835 == nil { mm__4 = ifn_2836.Invoke_O__O(arg_2837) } else { mm__4 = linked_2835.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2834, arg_2837) }; var tmp6 int64; var na_2838 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { na_2838 = or__1927000174__auto____5 } else { na_2838 = A_arbace_j2g_dyncf_A_const_365 }; var na_2839 int64 = 4098; if jrt.Long_InstanceOf(na_2838) { var n0_2840 int64 = jrt.NN(jrt.Long_Cast(na_2838)).LongValue__J(); var n1_2841 int64 = na_2839; tmp6 = n0_2840 & n1_2841 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_2838, na_2839) }
//line :447:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_2843 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_2844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2843, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2845 lang.IFn; if linked_2844 == nil { ifn_2845 = lang.IFn_Cast(root_2843) } else { ifn_2845 = nil }; var arg_2846 any; var root_2848 any = A_arbace_j2g_dyncf_A_const_386.GetRawRoot__O(); var linked_2849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2848, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2850 lang.IFn

		if linked_2849 == nil { ifn_2850 = lang.IFn_Cast(root_2848) } else { ifn_2850 = nil }; var arg_2851 any = mm__4; var arg_2852 any = A_arbace_j2g_dyncf_A_const_390; if linked_2849 == nil { arg_2846 = ifn_2850.Invoke_O_O__O(arg_2851, arg_2852) } else { arg_2846 = linked_2849.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2848, arg_2851, arg_2852) }
//line :447:1
		var arg_2847 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000236); var tmp8 any; var root_2853 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2853, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2855 lang.IFn; if linked_2854 == nil { ifn_2855 = lang.IFn_Cast(root_2853) } else { ifn_2855 = nil }; var arg_2856 any = s__292000237__3; if linked_2854 == nil { tmp8 = ifn_2855.Invoke_O__O(arg_2856) } else { tmp8 = linked_2854.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2853, arg_2856) }; arg_2847 = tmp7.Invoke_O__O(tmp8); if linked_2844 == nil { return ifn_2845.Invoke_O_O__O(arg_2846, arg_2847) } else { return linked_2844.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2843, arg_2846, arg_2847) } } else { var tmp9 any; var root_2857 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_2858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2857, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2859 lang.IFn; if linked_2858 == nil { ifn_2859 = lang.IFn_Cast(root_2857) } else { ifn_2859 = nil }; var arg_2860 any = s__292000237__3; if linked_2858 == nil { tmp9 = ifn_2859.Invoke_O__O(arg_2860) } else { tmp9 = linked_2858.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2857, arg_2860) }; s__292000237__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :447:1
func A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A) Ctor_O_I_O(c__b__292000239 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000239 = c__b__292000239; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :447:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A) Invoke_O__O(self any) any { { var i__292000238__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000238__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000238__1)); var tmp2 int64; var na_2795 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { na_2795 = or__1927000174__auto____3 } else { na_2795 = A_arbace_j2g_dyncf_A_const_365 }; var na_2796 int64 = 4098; if jrt.Long_InstanceOf(na_2795) { var n0_2797 int64 = jrt.NN(jrt.Long_Cast(na_2795)).LongValue__J(); var n1_2798 int64 = na_2796; tmp2 = n0_2797 & n1_2798 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_2795, na_2796) }
//line :447:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_2800 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2800, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2802 lang.IFn; if linked_2801 == nil { ifn_2802 = lang.IFn_Cast(root_2800) } else { ifn_2802 = nil }; var arg_2803 any = t.F_b__292000239; var arg_2804 any; var root_2805 any = A_arbace_j2g_dyncf_A_const_386.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2807 lang.IFn

		if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any = mm__2; var arg_2809 any = A_arbace_j2g_dyncf_A_const_389; if linked_2806 == nil { arg_2804 = ifn_2807.Invoke_O_O__O(arg_2808, arg_2809) } else { arg_2804 = linked_2806.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2805, arg_2808, arg_2809) }
//line :447:1
		if linked_2801 == nil { ifn_2802.Invoke_O_O__O(arg_2803, arg_2804) } else { linked_2801.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2800, arg_2803, arg_2804) }; i__292000238__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000238__1); continue L1 } else { i__292000238__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000238__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A{}; t.Ctor_O(p0); return t }
//line :450:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A) Ctor_O(c__extendable any) { t.F_extendable = c__extendable }
//line :450:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A) Invoke_O_O__O(self, s__292000249__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3448 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A_New_O_O_O(t.F_extendable, self, s__292000249__1); var tmp2 *jrt.Class; var fncls__3447 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A_fn_class; if fncls__3447 == nil { var fncls__3447d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__3448); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A_fn_class = fncls__3447d; tmp2 = fncls__3447d } else { tmp2 = fncls__3447 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3448, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :450:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :450:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A) Ctor_O_O_O(c__extendable, c__iter__292000248, c__s__292000249 any) { t.F_extendable = c__extendable; t.F_iter__292000248 = c__iter__292000248; t.F_s__292000249 = c__s__292000249 }
//line :450:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A) Invoke_O__O(self any) any { { var s__292000249__1 any; var t_ any = t.F_s__292000249; t.F_s__292000249 = nil; s__292000249__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2889 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2891 lang.IFn; if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = s__292000249__1; if linked_2890 == nil { temp__1927000414__auto____2 = ifn_2891.Invoke_O__O(arg_2892) } else { temp__1927000414__auto____2 = linked_2890.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2889, arg_2892) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000249__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2893 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2893, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2895 lang.IFn; if linked_2894 == nil { ifn_2895 = lang.IFn_Cast(root_2893) } else { ifn_2895 = nil }; var arg_2896 any = s__292000249__3; if linked_2894 == nil { tmp1 = ifn_2895.Invoke_O__O(arg_2896) } else { tmp1 = linked_2894.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2893, arg_2896) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2897 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2897, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2899 lang.IFn; if linked_2898 == nil { ifn_2899 = lang.IFn_Cast(root_2897) } else { ifn_2899 = nil }; var arg_2900 any = s__292000249__3; if linked_2898 == nil { c__1927001037__auto____4 = ifn_2899.Invoke_O__O(arg_2900) } else { c__1927001037__auto____4 = linked_2898.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2897, arg_2900) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000251__6 any; var root_2901 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2901, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2903 lang.IFn; if linked_2902 == nil { ifn_2903 = lang.IFn_Cast(root_2901) } else { ifn_2903 = nil }; var arg_2904 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2902 == nil { b__292000251__6 = ifn_2903.Invoke_O__O(arg_2904) } else { b__292000251__6 = linked_2902.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2901, arg_2904) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3155 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A_New_O_O_I_O(b__292000251__6, t.F_extendable, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3154 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A_fn_class; if fncls__3154 == nil { var fncls__3154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__3155); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A_fn_class = fncls__3154d; tmp3 = fncls__3154d } else { tmp3 = fncls__3154 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3155, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3156 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3156, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3158 lang.IFn; if linked_3157 == nil { ifn_3158 = lang.IFn_Cast(root_3156) } else { ifn_3158 = nil }; var arg_3159 any; var root_3161 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3161, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3163 lang.IFn; if linked_3162 == nil { ifn_3163 = lang.IFn_Cast(root_3161) } else { ifn_3163 = nil }; var arg_3164 any = b__292000251__6; if linked_3162 == nil { arg_3159 = ifn_3163.Invoke_O__O(arg_3164) } else { arg_3159 = linked_3162.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3161, arg_3164) }; var arg_3160 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000248); var tmp5 any; var root_3165 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3165, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3167 lang.IFn; if linked_3166 == nil { ifn_3167 = lang.IFn_Cast(root_3165) } else { ifn_3167 = nil }; var arg_3168 any = s__292000249__3; if linked_3166 == nil { tmp5 = ifn_3167.Invoke_O__O(arg_3168) } else { tmp5 = linked_3166.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3165, arg_3168) }; arg_3160 = tmp4.Invoke_O__O(tmp5); if linked_3157 == nil { return ifn_3158.Invoke_O_O__O(arg_3159, arg_3160) } else { return linked_3157.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3156, arg_3159, arg_3160) } } else { var root_3169 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3169, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3171 lang.IFn; if linked_3170 == nil { ifn_3171 = lang.IFn_Cast(root_3169) } else { ifn_3171 = nil }; var arg_3172 any; var root_3174 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3174, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3176 lang.IFn; if linked_3175 == nil { ifn_3176 = lang.IFn_Cast(root_3174) } else { ifn_3176 = nil }; var arg_3177 any = b__292000251__6; if linked_3175 == nil { arg_3172 = ifn_3176.Invoke_O__O(arg_3177) } else { arg_3172 = linked_3175.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3174, arg_3177) }; var arg_3173 any; if linked_3170 == nil { return ifn_3171.Invoke_O_O__O(arg_3172, arg_3173) } else { return linked_3170.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3169, arg_3172, arg_3173) } } } else { var n__4 any; var root_3178 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3178, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3180 lang.IFn; if linked_3179 == nil { ifn_3180 = lang.IFn_Cast(root_3178) } else { ifn_3180 = nil }; var arg_3181 any = s__292000249__3; if linked_3179 == nil { n__4 = ifn_3180.Invoke_O__O(arg_3181) } else { n__4 = linked_3179.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3178, arg_3181) }; var d__5 any; var root_3182 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_3183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3182, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3184 lang.IFn
														if linked_3183 == nil { ifn_3184 = lang.IFn_Cast(root_3182) } else { ifn_3184 = nil }; var arg_3185 any = n__4; if linked_3183 == nil { d__5 = ifn_3184.Invoke_O__O(arg_3185) } else { d__5 = linked_3183.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3182, arg_3185) }
//line :450:1
	var tmp6 any
	var and__1927000168__auto____6 any = d__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_3186 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3186, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3188 lang.IFn; if linked_3187 == nil { ifn_3188 = lang.IFn_Cast(root_3186) } else { ifn_3188 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_399); var arg_3189 any = tmp7.Invoke_O__O(A_arbace_j2g_dyncf_A_const_392.Invoke_O__O(d__5)); if linked_3187 == nil { and__1927000168__auto____7 = ifn_3188.Invoke_O__O(arg_3189) } else { and__1927000168__auto____7 = linked_3187.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3186, arg_3189) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var or__1927000174__auto____8 any; var root_3190 any = A_arbace_j2g_dyncf_A_const_393.GetRawRoot__O(); var linked_3191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3190, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_3192 lang.IFn
		if linked_3191 == nil { ifn_3192 = lang.IFn_Cast(root_3190) } else { ifn_3192 = nil }; var arg_3193 any = n__4; if linked_3191 == nil { or__1927000174__auto____8 = ifn_3192.Invoke_O__O(arg_3193) } else { or__1927000174__auto____8 = linked_3191.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_3190, arg_3193) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__4) } } else {
//line :454:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }
//line :450:1
	if jrt.J2g_Truth(tmp6) { var g__6 any; var tmp8 *lang.Compiler_AOTFn; var fnbody__3195 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A_New_O(n__4); var tmp9 *jrt.Class
		var fncls__3194 /*line :450:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A_fn_class





		if fncls__3194 == nil { var fncls__3194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__3195); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A_fn_class = fncls__3194d; tmp9 = fncls__3194d } else { tmp9 = fncls__3194 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3195, tmp9, nil); g__6 = Up_Compiler_AOTFn_IFn(tmp8).Invoke__O()
//line :450:1
		if jrt.J2g_Truth(g__6) { var generic_QMARK___7 any; var root_3196 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3198 lang.IFn







			if linked_3197 == nil { ifn_3198 = lang.IFn_Cast(root_3196) } else { ifn_3198 = nil }; var arg_3199 any = A_arbace_j2g_dyncf_A_const_381.Invoke_O__O(g__6); if linked_3197 == nil { generic_QMARK___7 = ifn_3198.Invoke_O__O(arg_3199) } else { generic_QMARK___7 = linked_3197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3196, arg_3199) }
//line :450:1
			var supers__8 any; var root_3200 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_3201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3200, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3202 lang.IFn








			if linked_3201 == nil { ifn_3202 = lang.IFn_Cast(root_3200) } else { ifn_3202 = nil }; var arg_3203 any; var root_3204 any = A_arbace_j2g_dyncf_A_const_384.GetRawRoot__O(); var linked_3205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3204, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3206 lang.IFn; if linked_3205 == nil { ifn_3206 = lang.IFn_Cast(root_3204) } else { ifn_3206 = nil }; var arg_3207 any = A_arbace_j2g_dyncf_A_const_385.GetRawRoot__O(); var arg_3208 any = A_arbace_j2g_dyncf_A_const_383.Invoke_O__O(g__6); if linked_3205 == nil { arg_3203 = ifn_3206.Invoke_O_O__O(arg_3207, arg_3208) } else { arg_3203 = linked_3205.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3204, arg_3207, arg_3208) }; if linked_3201 == nil { supers__8 = ifn_3202.Invoke_O__O(arg_3203) } else { supers__8 = linked_3201.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3200, arg_3203) }
//line :450:1
			var abstract_QMARK___9 any; var and__1927000168__auto____9 any; var root_3209 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3211 lang.IFn









			if linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any; var root_3213 any = A_arbace_j2g_dyncf_A_const_393.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_3215 lang.IFn; if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = n__4; if linked_3214 == nil { arg_3212 = ifn_3215.Invoke_O__O(arg_3216) } else { arg_3212 = linked_3214.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_3213, arg_3216) }; if linked_3210 == nil { and__1927000168__auto____9 = ifn_3211.Invoke_O__O(arg_3212) } else { and__1927000168__auto____9 = linked_3210.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3209, arg_3212) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp10 int64; var na_3217 any; var or__1927000174__auto____10 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(d__5); if jrt.J2g_Truth(or__1927000174__auto____10) { na_3217 = or__1927000174__auto____10 } else { na_3217 = A_arbace_j2g_dyncf_A_const_365 }; var na_3218 int64 = 1024; if jrt.Long_InstanceOf(na_3217) { var n0_3219 int64 = jrt.NN(jrt.Long_Cast(na_3217)).LongValue__J(); var n1_3220 int64 = na_3218; tmp10 = n0_3219 & n1_3220 } else { tmp10 = lang.Numbers_And_O_J__J_NoInit(na_3217, na_3218) }; abstract_QMARK___9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp10)).Ref() } else { abstract_QMARK___9 = and__1927000168__auto____9 }
//line :450:1
			var tmp11 any
			var or__1927000174__auto____10_2 any = generic_QMARK___7









			if jrt.J2g_Truth(or__1927000174__auto____10_2) { tmp11 = or__1927000174__auto____10_2 } else { var or__1927000174__auto____11 any = abstract_QMARK___9; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp11 = or__1927000174__auto____11 } else { var root_3222 any = A_arbace_j2g_dyncf_A_const_394.GetRawRoot__O(); var linked_3223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3222, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3224 lang.IFn; if linked_3223 == nil { ifn_3224 = lang.IFn_Cast(root_3222) } else { ifn_3224 = nil }; var arg_3225 any; var root_3227 any = A_arbace_j2g_dyncf_A_const_395.GetRawRoot__O(); var linked_3228 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3227, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_3229 lang.IFn; if linked_3228 == nil { ifn_3229 = lang.IFn_Cast(root_3227) } else { ifn_3229 = nil }; var arg_3230 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var arg_3231 any = A_arbace_j2g_dyncf_A_const_396; if linked_3228 == nil { arg_3225 = ifn_3229.Invoke_O_O__O(arg_3230, arg_3231) } else { arg_3225 = linked_3228.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_3227, arg_3230, arg_3231) }; var arg_3226 any = supers__8; if linked_3223 == nil { tmp11 = ifn_3224.Invoke_O_O__O(arg_3225, arg_3226) } else { tmp11 = linked_3223.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3222, arg_3225, arg_3226) } } }
//line :450:1
			if jrt.J2g_Truth(tmp11) { var root_3232 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3232, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3234 lang.IFn; if linked_3233 == nil { ifn_3234 = lang.IFn_Cast(root_3232) } else { ifn_3234 = nil }; var arg_3235 any; var tmp12 any; var root_3237 any = A_arbace_j2g_dyncf_A_const_382.GetRawRoot__O(); var linked_3238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3237, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_3239 lang.IFn











				if linked_3238 == nil { ifn_3239 = lang.IFn_Cast(root_3237) } else { ifn_3239 = nil }; var arg_3240 any; var G__292000281__10_ any; var tmp13 any = A_arbace_j2g_dyncf_A_const_381; var tmp14 any; var root_3241 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_3242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3241, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3243 lang.IFn
				if linked_3242 == nil { ifn_3243 = lang.IFn_Cast(root_3241) } else { ifn_3243 = nil }; var arg_3244 any = A_arbace_j2g_dyncf_A_const_381.Invoke_O__O(g__6); if linked_3242 == nil { tmp14 = ifn_3243.Invoke_O__O(arg_3244) } else { tmp14 = linked_3242.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3241, arg_3244) }
//line :462:1
				G__292000281__10_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, A_arbace_j2g_dyncf_A_const_383, supers__8)); var G__292000281__11_ any
				if jrt.J2g_Truth(abstract_QMARK___9) {
					var root_3245 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_3246 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3245, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3247 lang.IFn; if linked_3246 == nil { ifn_3247 = lang.IFn_Cast(root_3245) } else { ifn_3247 = nil }; var arg_3248 any = G__292000281__10_; var arg_3249 any = A_arbace_j2g_dyncf_A_const_373; var arg_3250 any; var root_3251 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_3252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3251, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3253 lang.IFn; if linked_3252 == nil { ifn_3253 = lang.IFn_Cast(root_3251) } else { ifn_3253 = nil }; var arg_3254 any; var iter__1927001039__auto____11 any; var fnbody__3334 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A_New(); var tmp15 *jrt.Class; var fncls__3333 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A_fn_class; if fncls__3333 == nil { var fncls__3333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A_fn_class = fncls__3333d; tmp15 = fncls__3333d } else { tmp15 = fncls__3333 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3334, tmp15, nil); arg_3254 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(d__5)); if linked_3252 == nil { arg_3250 = ifn_3253.Invoke_O__O(arg_3254) } else { arg_3250 = linked_3252.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3251, arg_3254) }; if linked_3246 == nil { G__292000281__11_ = ifn_3247.Invoke_O_O_O__O(arg_3248, arg_3249, arg_3250) } else { G__292000281__11_ = linked_3246.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3245, arg_3248, arg_3249, arg_3250) } } else {
//line :463:1
						G__292000281__11_ = G__292000281__10_ }; if jrt.J2g_Truth(generic_QMARK___7) {




							var root_3335 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_3336 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3335, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3337 lang.IFn; if linked_3336 == nil { ifn_3337 = lang.IFn_Cast(root_3335) } else { ifn_3337 = nil }; var arg_3338 any = G__292000281__11_; var arg_3339 any = A_arbace_j2g_dyncf_A_const_108; var arg_3340 any; var root_3341 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_3342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3341, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3343 lang.IFn; if linked_3342 == nil { ifn_3343 = lang.IFn_Cast(root_3341) } else { ifn_3343 = nil }; var arg_3344 any; var iter__1927001039__auto____12 any; var fnbody__3430 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A_New(); var tmp16 *jrt.Class; var fncls__3429 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A_fn_class; if fncls__3429 == nil { var fncls__3429d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A_fn_class = fncls__3429d; tmp16 = fncls__3429d } else { tmp16 = fncls__3429 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3430, tmp16, nil); arg_3344 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__6)); if linked_3342 == nil { arg_3340 = ifn_3343.Invoke_O__O(arg_3344) } else { arg_3340 = linked_3342.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3341, arg_3344) }; if linked_3336 == nil { arg_3240 = ifn_3337.Invoke_O_O_O__O(arg_3338, arg_3339, arg_3340) } else { arg_3240 = linked_3336.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3335, arg_3338, arg_3339, arg_3340) } } else {
//line :463:1
								arg_3240 = G__292000281__11_ }
//line :462:1
				if linked_3238 == nil { tmp12 = ifn_3239.Invoke_O__O(arg_3240) } else { tmp12 = linked_3238.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_3237, arg_3240) }
//line :450:1
				arg_3235 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp12); var arg_3236 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__292000248); var tmp18 any; var root_3431 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3431, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3433 lang.IFn; if linked_3432 == nil { ifn_3433 = lang.IFn_Cast(root_3431) } else { ifn_3433 = nil }; var arg_3434 any = s__292000249__3; if linked_3432 == nil { tmp18 = ifn_3433.Invoke_O__O(arg_3434) } else { tmp18 = linked_3432.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3431, arg_3434) }; arg_3236 = tmp17.Invoke_O__O(tmp18); if linked_3233 == nil { return ifn_3234.Invoke_O_O__O(arg_3235, arg_3236) } else { return linked_3233.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3232, arg_3235, arg_3236) } } else { var tmp19 any; var root_3435 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3435, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3437 lang.IFn; if linked_3436 == nil { ifn_3437 = lang.IFn_Cast(root_3435) } else { ifn_3437 = nil }; var arg_3438 any = s__292000249__3; if linked_3436 == nil { tmp19 = ifn_3437.Invoke_O__O(arg_3438) } else { tmp19 = linked_3436.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3435, arg_3438) }; s__292000249__1 = tmp19; continue L1 } } else { var tmp20 any; var root_3439 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3439, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3441 lang.IFn; if linked_3440 == nil { ifn_3441 = lang.IFn_Cast(root_3439) } else { ifn_3441 = nil }; var arg_3442 any = s__292000249__3; if linked_3440 == nil { tmp20 = ifn_3441.Invoke_O__O(arg_3442) } else { tmp20 = linked_3440.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3439, arg_3442) }; s__292000249__1 = tmp20; continue L1 } } else { var tmp21 any; var root_3443 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3443, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3445 lang.IFn; if linked_3444 == nil { ifn_3445 = lang.IFn_Cast(root_3443) } else { ifn_3445 = nil }; var arg_3446 any = s__292000249__3; if linked_3444 == nil { tmp21 = ifn_3445.Invoke_O__O(arg_3446) } else { tmp21 = linked_3444.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3443, arg_3446) }; s__292000249__1 = tmp21; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :450:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :450:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A) Ctor_O_O_I_O(c__b__292000251, c__extendable any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000251 = c__b__292000251; t.F_extendable = c__extendable; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :450:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A) Invoke_O__O(self any) any { { var i__292000250__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000250__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000250__1)); var d__3 any; var root_2905 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2905, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2907 lang.IFn
																if linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; var arg_2908 any = n__2; if linked_2906 == nil { d__3 = ifn_2907.Invoke_O__O(arg_2908) } else { d__3 = linked_2906.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2905, arg_2908) }
//line :450:1
	var tmp2 any
	var and__1927000168__auto____4 any = d__3


	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_2909 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_2910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2909, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2911 lang.IFn; if linked_2910 == nil { ifn_2911 = lang.IFn_Cast(root_2909) } else { ifn_2911 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_391); var arg_2912 any = tmp3.Invoke_O__O(A_arbace_j2g_dyncf_A_const_392.Invoke_O__O(d__3)); if linked_2910 == nil { and__1927000168__auto____5 = ifn_2911.Invoke_O__O(arg_2912) } else { and__1927000168__auto____5 = linked_2910.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2909, arg_2912) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_2913 any = A_arbace_j2g_dyncf_A_const_393.GetRawRoot__O(); var linked_2914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2913, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2915 lang.IFn
		if linked_2914 == nil { ifn_2915 = lang.IFn_Cast(root_2913) } else { ifn_2915 = nil }; var arg_2916 any = n__2; if linked_2914 == nil { or__1927000174__auto____6 = ifn_2915.Invoke_O__O(arg_2916) } else { or__1927000174__auto____6 = linked_2914.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2913, arg_2916) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__2) } } else {
//line :454:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :450:1
	if jrt.J2g_Truth(tmp2) { var g__4 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__2918 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A_New_O(n__2); var tmp5 *jrt.Class
		var fncls__2917 /*line :450:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A_fn_class





		if fncls__2917 == nil { var fncls__2917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__2918); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A_fn_class = fncls__2917d; tmp5 = fncls__2917d } else { tmp5 = fncls__2917 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2918, tmp5, nil); g__4 = Up_Compiler_AOTFn_IFn(tmp4).Invoke__O()
//line :450:1
		if jrt.J2g_Truth(g__4) { var generic_QMARK___5 any; var root_2919 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2919, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2921 lang.IFn







			if linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any = A_arbace_j2g_dyncf_A_const_381.Invoke_O__O(g__4); if linked_2920 == nil { generic_QMARK___5 = ifn_2921.Invoke_O__O(arg_2922) } else { generic_QMARK___5 = linked_2920.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2919, arg_2922) }
//line :450:1
			var supers__6 any; var root_2923 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2923, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2925 lang.IFn








			if linked_2924 == nil { ifn_2925 = lang.IFn_Cast(root_2923) } else { ifn_2925 = nil }; var arg_2926 any; var root_2927 any = A_arbace_j2g_dyncf_A_const_384.GetRawRoot__O(); var linked_2928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2927, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2929 lang.IFn; if linked_2928 == nil { ifn_2929 = lang.IFn_Cast(root_2927) } else { ifn_2929 = nil }; var arg_2930 any = A_arbace_j2g_dyncf_A_const_385.GetRawRoot__O(); var arg_2931 any = A_arbace_j2g_dyncf_A_const_383.Invoke_O__O(g__4); if linked_2928 == nil { arg_2926 = ifn_2929.Invoke_O_O__O(arg_2930, arg_2931) } else { arg_2926 = linked_2928.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2927, arg_2930, arg_2931) }; if linked_2924 == nil { supers__6 = ifn_2925.Invoke_O__O(arg_2926) } else { supers__6 = linked_2924.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2923, arg_2926) }
//line :450:1
			var abstract_QMARK___7 any; var and__1927000168__auto____7 any; var root_2932 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_2933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2932, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2934 lang.IFn









			if linked_2933 == nil { ifn_2934 = lang.IFn_Cast(root_2932) } else { ifn_2934 = nil }; var arg_2935 any; var root_2936 any = A_arbace_j2g_dyncf_A_const_393.GetRawRoot__O(); var linked_2937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2936, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2938 lang.IFn; if linked_2937 == nil { ifn_2938 = lang.IFn_Cast(root_2936) } else { ifn_2938 = nil }; var arg_2939 any = n__2; if linked_2937 == nil { arg_2935 = ifn_2938.Invoke_O__O(arg_2939) } else { arg_2935 = linked_2937.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2936, arg_2939) }; if linked_2933 == nil { and__1927000168__auto____7 = ifn_2934.Invoke_O__O(arg_2935) } else { and__1927000168__auto____7 = linked_2933.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2932, arg_2935) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp6 int64; var na_2940 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(d__3); if jrt.J2g_Truth(or__1927000174__auto____8) { na_2940 = or__1927000174__auto____8 } else { na_2940 = A_arbace_j2g_dyncf_A_const_365 }; var na_2941 int64 = 1024; if jrt.Long_InstanceOf(na_2940) { var n0_2942 int64 = jrt.NN(jrt.Long_Cast(na_2940)).LongValue__J(); var n1_2943 int64 = na_2941; tmp6 = n0_2942 & n1_2943 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_2940, na_2941) }; abstract_QMARK___7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp6)).Ref() } else { abstract_QMARK___7 = and__1927000168__auto____7 }
//line :450:1
			var tmp7 any
			var or__1927000174__auto____8_2 any = generic_QMARK___5









			if jrt.J2g_Truth(or__1927000174__auto____8_2) { tmp7 = or__1927000174__auto____8_2 } else { var or__1927000174__auto____9 any = abstract_QMARK___7; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { var root_2945 any = A_arbace_j2g_dyncf_A_const_394.GetRawRoot__O(); var linked_2946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2945, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2947 lang.IFn; if linked_2946 == nil { ifn_2947 = lang.IFn_Cast(root_2945) } else { ifn_2947 = nil }; var arg_2948 any; var root_2950 any = A_arbace_j2g_dyncf_A_const_395.GetRawRoot__O(); var linked_2951 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2950, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2952 lang.IFn; if linked_2951 == nil { ifn_2952 = lang.IFn_Cast(root_2950) } else { ifn_2952 = nil }; var arg_2953 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var arg_2954 any = A_arbace_j2g_dyncf_A_const_396; if linked_2951 == nil { arg_2948 = ifn_2952.Invoke_O_O__O(arg_2953, arg_2954) } else { arg_2948 = linked_2951.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2950, arg_2953, arg_2954) }; var arg_2949 any = supers__6; if linked_2946 == nil { tmp7 = ifn_2947.Invoke_O_O__O(arg_2948, arg_2949) } else { tmp7 = linked_2946.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2945, arg_2948, arg_2949) } } }
//line :450:1
			if jrt.J2g_Truth(tmp7) { var root_2955 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_2956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2955, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2957 lang.IFn; if linked_2956 == nil { ifn_2957 = lang.IFn_Cast(root_2955) } else { ifn_2957 = nil }; var arg_2958 any = t.F_b__292000251; var arg_2959 any; var tmp8 any; var root_2960 any = A_arbace_j2g_dyncf_A_const_382.GetRawRoot__O(); var linked_2961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2960, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_2962 lang.IFn











				if linked_2961 == nil { ifn_2962 = lang.IFn_Cast(root_2960) } else { ifn_2962 = nil }; var arg_2963 any; var G__292000257__8_ any; var tmp9 any = A_arbace_j2g_dyncf_A_const_381; var tmp10 any; var root_2964 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2964, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2966 lang.IFn
				if linked_2965 == nil { ifn_2966 = lang.IFn_Cast(root_2964) } else { ifn_2966 = nil }; var arg_2967 any = A_arbace_j2g_dyncf_A_const_381.Invoke_O__O(g__4); if linked_2965 == nil { tmp10 = ifn_2966.Invoke_O__O(arg_2967) } else { tmp10 = linked_2965.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2964, arg_2967) }
//line :462:1
				G__292000257__8_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, A_arbace_j2g_dyncf_A_const_383, supers__6)); var G__292000257__9_ any
				if jrt.J2g_Truth(abstract_QMARK___7) {
					var root_2968 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_2969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2968, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2970 lang.IFn; if linked_2969 == nil { ifn_2970 = lang.IFn_Cast(root_2968) } else { ifn_2970 = nil }; var arg_2971 any = G__292000257__8_; var arg_2972 any = A_arbace_j2g_dyncf_A_const_373; var arg_2973 any; var root_2974 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_2975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2974, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2976 lang.IFn; if linked_2975 == nil { ifn_2976 = lang.IFn_Cast(root_2974) } else { ifn_2976 = nil }; var arg_2977 any; var iter__1927001039__auto____9 any; var fnbody__3057 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A_New(); var tmp11 *jrt.Class; var fncls__3056 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A_fn_class; if fncls__3056 == nil { var fncls__3056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A_fn_class = fncls__3056d; tmp11 = fncls__3056d } else { tmp11 = fncls__3056 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3057, tmp11, nil); arg_2977 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(d__3)); if linked_2975 == nil { arg_2973 = ifn_2976.Invoke_O__O(arg_2977) } else { arg_2973 = linked_2975.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2974, arg_2977) }; if linked_2969 == nil { G__292000257__9_ = ifn_2970.Invoke_O_O_O__O(arg_2971, arg_2972, arg_2973) } else { G__292000257__9_ = linked_2969.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2968, arg_2971, arg_2972, arg_2973) } } else {
//line :463:1
						G__292000257__9_ = G__292000257__8_ }; if jrt.J2g_Truth(generic_QMARK___5) {




							var root_3058 any = A_arbace_j2g_dyncf_A_const_372.GetRawRoot__O(); var linked_3059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3058, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3060 lang.IFn; if linked_3059 == nil { ifn_3060 = lang.IFn_Cast(root_3058) } else { ifn_3060 = nil }; var arg_3061 any = G__292000257__9_; var arg_3062 any = A_arbace_j2g_dyncf_A_const_108; var arg_3063 any; var root_3064 any = A_arbace_j2g_dyncf_A_const_370.GetRawRoot__O(); var linked_3065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3064, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3066 lang.IFn; if linked_3065 == nil { ifn_3066 = lang.IFn_Cast(root_3064) } else { ifn_3066 = nil }; var arg_3067 any; var iter__1927001039__auto____10 any; var fnbody__3153 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A_New(); var tmp12 *jrt.Class; var fncls__3152 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A_fn_class; if fncls__3152 == nil { var fncls__3152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A_fn_class = fncls__3152d; tmp12 = fncls__3152d } else { tmp12 = fncls__3152 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3153, tmp12, nil); arg_3067 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_j2g_dyncf_A_const_108.Invoke_O__O(g__4)); if linked_3065 == nil { arg_3063 = ifn_3066.Invoke_O__O(arg_3067) } else { arg_3063 = linked_3065.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3064, arg_3067) }; if linked_3059 == nil { arg_2963 = ifn_3060.Invoke_O_O_O__O(arg_3061, arg_3062, arg_3063) } else { arg_2963 = linked_3059.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3058, arg_3061, arg_3062, arg_3063) } } else {
//line :463:1
								arg_2963 = G__292000257__9_ }
//line :462:1
				if linked_2961 == nil { tmp8 = ifn_2962.Invoke_O__O(arg_2963) } else { tmp8 = linked_2961.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_2960, arg_2963) }
//line :450:1
				arg_2959 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp8); if linked_2956 == nil { ifn_2957.Invoke_O_O__O(arg_2958, arg_2959) } else { linked_2956.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2955, arg_2958, arg_2959) }; i__292000250__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000250__1); continue L1 } else { i__292000250__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000250__1); continue L1 } } else { i__292000250__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000250__1); continue L1 } } else { i__292000250__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000250__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A{}; t.Ctor_O(p0); return t }
//line :456:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :456:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_380; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :456:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A{}; t.Ctor_O(p0); return t }
//line :456:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :456:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_380; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A{}; t.Ctor(); return t }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A) Ctor() {}
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A) Invoke_O_O__O(self, s__292000259__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3055 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A_New_O_O(self, s__292000259__1); var tmp2 *jrt.Class; var fncls__3054 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A_fn_class; if fncls__3054 == nil { var fncls__3054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__3055); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A_fn_class = fncls__3054d; tmp2 = fncls__3054d } else { tmp2 = fncls__3054 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3055, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :464:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A{}; t.Ctor_O_O(p0, p1); return t }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A) Ctor_O_O(c__iter__292000258, c__s__292000259 any) { t.F_iter__292000258 = c__iter__292000258; t.F_s__292000259 = c__s__292000259 }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A) Invoke_O__O(self any) any { { var s__292000259__1 any; var t_ any = t.F_s__292000259; t.F_s__292000259 = nil; s__292000259__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2978 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_2979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2978, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2980 lang.IFn; if linked_2979 == nil { ifn_2980 = lang.IFn_Cast(root_2978) } else { ifn_2980 = nil }; var arg_2981 any = s__292000259__1; if linked_2979 == nil { temp__1927000414__auto____2 = ifn_2980.Invoke_O__O(arg_2981) } else { temp__1927000414__auto____2 = linked_2979.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2978, arg_2981) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000259__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2982 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2982, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2984 lang.IFn; if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any = s__292000259__3; if linked_2983 == nil { tmp1 = ifn_2984.Invoke_O__O(arg_2985) } else { tmp1 = linked_2983.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2982, arg_2985) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2986 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2988 lang.IFn; if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; var arg_2989 any = s__292000259__3; if linked_2987 == nil { c__1927001037__auto____4 = ifn_2988.Invoke_O__O(arg_2989) } else { c__1927001037__auto____4 = linked_2987.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2986, arg_2989) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000261__6 any; var root_2990 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_2991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2990, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2992 lang.IFn; if linked_2991 == nil { ifn_2992 = lang.IFn_Cast(root_2990) } else { ifn_2992 = nil }; var arg_2993 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2991 == nil { b__292000261__6 = ifn_2992.Invoke_O__O(arg_2993) } else { b__292000261__6 = linked_2991.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2990, arg_2993) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3005 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A_New_O_I_O(b__292000261__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3004 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A_fn_class; if fncls__3004 == nil { var fncls__3004d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__3005); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A_fn_class = fncls__3004d; tmp3 = fncls__3004d } else { tmp3 = fncls__3004 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3005, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3006 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3006, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3008 lang.IFn; if linked_3007 == nil { ifn_3008 = lang.IFn_Cast(root_3006) } else { ifn_3008 = nil }; var arg_3009 any; var root_3011 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3011, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3013 lang.IFn; if linked_3012 == nil { ifn_3013 = lang.IFn_Cast(root_3011) } else { ifn_3013 = nil }; var arg_3014 any = b__292000261__6; if linked_3012 == nil { arg_3009 = ifn_3013.Invoke_O__O(arg_3014) } else { arg_3009 = linked_3012.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3011, arg_3014) }; var arg_3010 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000258); var tmp5 any; var root_3015 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3015, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3017 lang.IFn; if linked_3016 == nil { ifn_3017 = lang.IFn_Cast(root_3015) } else { ifn_3017 = nil }; var arg_3018 any = s__292000259__3; if linked_3016 == nil { tmp5 = ifn_3017.Invoke_O__O(arg_3018) } else { tmp5 = linked_3016.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3015, arg_3018) }; arg_3010 = tmp4.Invoke_O__O(tmp5); if linked_3007 == nil { return ifn_3008.Invoke_O_O__O(arg_3009, arg_3010) } else { return linked_3007.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3006, arg_3009, arg_3010) } } else { var root_3019 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3019, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3021 lang.IFn; if linked_3020 == nil { ifn_3021 = lang.IFn_Cast(root_3019) } else { ifn_3021 = nil }; var arg_3022 any; var root_3024 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3026 lang.IFn; if linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any = b__292000261__6; if linked_3025 == nil { arg_3022 = ifn_3026.Invoke_O__O(arg_3027) } else { arg_3022 = linked_3025.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3024, arg_3027) }; var arg_3023 any; if linked_3020 == nil { return ifn_3021.Invoke_O_O__O(arg_3022, arg_3023) } else { return linked_3020.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3019, arg_3022, arg_3023) } } } else { var mm__4 any; var root_3028 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3028, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3030 lang.IFn; if linked_3029 == nil { ifn_3030 = lang.IFn_Cast(root_3028) } else { ifn_3030 = nil }; var arg_3031 any = s__292000259__3; if linked_3029 == nil { mm__4 = ifn_3030.Invoke_O__O(arg_3031) } else { mm__4 = linked_3029.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3028, arg_3031) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)) { var tmp6 int64; var na_3032 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_3032 = or__1927000174__auto____5 } else { na_3032 = A_arbace_j2g_dyncf_A_const_365 }; var na_3033 int64 = 4098; if jrt.Long_InstanceOf(na_3032) { var n0_3034 int64 = jrt.NN(jrt.Long_Cast(na_3032)).LongValue__J(); var n1_3035 int64 = na_3033; tmp6 = n0_3034 & n1_3035 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3032, na_3033) }
//line :464:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3037 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3037, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3039 lang.IFn; if linked_3038 == nil { ifn_3039 = lang.IFn_Cast(root_3037) } else { ifn_3039 = nil }; var arg_3040 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)); var arg_3041 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000258); var tmp8 any; var root_3042 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3042, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3044 lang.IFn; if linked_3043 == nil { ifn_3044 = lang.IFn_Cast(root_3042) } else { ifn_3044 = nil }; var arg_3045 any = s__292000259__3; if linked_3043 == nil { tmp8 = ifn_3044.Invoke_O__O(arg_3045) } else { tmp8 = linked_3043.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3042, arg_3045) }; arg_3041 = tmp7.Invoke_O__O(tmp8); if linked_3038 == nil { return ifn_3039.Invoke_O_O__O(arg_3040, arg_3041) } else { return linked_3038.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3037, arg_3040, arg_3041) } } else { var tmp9 any; var root_3046 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3046, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3048 lang.IFn; if linked_3047 == nil { ifn_3048 = lang.IFn_Cast(root_3046) } else { ifn_3048 = nil }; var arg_3049 any = s__292000259__3; if linked_3047 == nil { tmp9 = ifn_3048.Invoke_O__O(arg_3049) } else { tmp9 = linked_3047.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3046, arg_3049) }; s__292000259__1 = tmp9; continue L1 } } else { var tmp10 any; var root_3050 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3052 lang.IFn; if linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any = s__292000259__3; if linked_3051 == nil { tmp10 = ifn_3052.Invoke_O__O(arg_3053) } else { tmp10 = linked_3051.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3050, arg_3053) }; s__292000259__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :464:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A) Ctor_O_I_O(c__b__292000261 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000261 = c__b__292000261; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A) Invoke_O__O(self any) any { { var i__292000260__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000260__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000260__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)) { var tmp2 int64; var na_2994 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_2994 = or__1927000174__auto____3 } else { na_2994 = A_arbace_j2g_dyncf_A_const_365 }; var na_2995 int64 = 4098; if jrt.Long_InstanceOf(na_2994) { var n0_2996 int64 = jrt.NN(jrt.Long_Cast(na_2994)).LongValue__J(); var n1_2997 int64 = na_2995; tmp2 = n0_2996 & n1_2997 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_2994, na_2995) }
//line :464:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_2999 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2999, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3001 lang.IFn; if linked_3000 == nil { ifn_3001 = lang.IFn_Cast(root_2999) } else { ifn_3001 = nil }; var arg_3002 any = t.F_b__292000261; var arg_3003 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)); if linked_3000 == nil { ifn_3001.Invoke_O_O__O(arg_3002, arg_3003) } else { linked_3000.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2999, arg_3002, arg_3003) }; i__292000260__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000260__1); continue L1 } else { i__292000260__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000260__1); continue L1 } } else { i__292000260__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000260__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :464:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A{}; t.Ctor(); return t }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A) Ctor() {}
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A) Invoke_O_O__O(self, s__292000283__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3332 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A_New_O_O(self, s__292000283__1); var tmp2 *jrt.Class; var fncls__3331 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A_fn_class; if fncls__3331 == nil { var fncls__3331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__3332); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A_fn_class = fncls__3331d; tmp2 = fncls__3331d } else { tmp2 = fncls__3331 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3332, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :464:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A{}; t.Ctor_O_O(p0, p1); return t }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A) Ctor_O_O(c__iter__292000282, c__s__292000283 any) { t.F_iter__292000282 = c__iter__292000282; t.F_s__292000283 = c__s__292000283 }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A) Invoke_O__O(self any) any { { var s__292000283__1 any; var t_ any = t.F_s__292000283; t.F_s__292000283 = nil; s__292000283__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3255 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3255, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3257 lang.IFn; if linked_3256 == nil { ifn_3257 = lang.IFn_Cast(root_3255) } else { ifn_3257 = nil }; var arg_3258 any = s__292000283__1; if linked_3256 == nil { temp__1927000414__auto____2 = ifn_3257.Invoke_O__O(arg_3258) } else { temp__1927000414__auto____2 = linked_3256.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3255, arg_3258) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000283__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3259 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3259, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3261 lang.IFn; if linked_3260 == nil { ifn_3261 = lang.IFn_Cast(root_3259) } else { ifn_3261 = nil }; var arg_3262 any = s__292000283__3; if linked_3260 == nil { tmp1 = ifn_3261.Invoke_O__O(arg_3262) } else { tmp1 = linked_3260.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3259, arg_3262) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3263 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3263, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3265 lang.IFn; if linked_3264 == nil { ifn_3265 = lang.IFn_Cast(root_3263) } else { ifn_3265 = nil }; var arg_3266 any = s__292000283__3; if linked_3264 == nil { c__1927001037__auto____4 = ifn_3265.Invoke_O__O(arg_3266) } else { c__1927001037__auto____4 = linked_3264.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3263, arg_3266) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000285__6 any; var root_3267 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3267, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3269 lang.IFn; if linked_3268 == nil { ifn_3269 = lang.IFn_Cast(root_3267) } else { ifn_3269 = nil }; var arg_3270 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3268 == nil { b__292000285__6 = ifn_3269.Invoke_O__O(arg_3270) } else { b__292000285__6 = linked_3268.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3267, arg_3270) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3282 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A_New_O_I_O(b__292000285__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3281 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A_fn_class; if fncls__3281 == nil { var fncls__3281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__3282); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A_fn_class = fncls__3281d; tmp3 = fncls__3281d } else { tmp3 = fncls__3281 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3282, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3283 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3283, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3285 lang.IFn; if linked_3284 == nil { ifn_3285 = lang.IFn_Cast(root_3283) } else { ifn_3285 = nil }; var arg_3286 any; var root_3288 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3290 lang.IFn; if linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = b__292000285__6; if linked_3289 == nil { arg_3286 = ifn_3290.Invoke_O__O(arg_3291) } else { arg_3286 = linked_3289.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3288, arg_3291) }; var arg_3287 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000282); var tmp5 any; var root_3292 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3292, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3294 lang.IFn; if linked_3293 == nil { ifn_3294 = lang.IFn_Cast(root_3292) } else { ifn_3294 = nil }; var arg_3295 any = s__292000283__3; if linked_3293 == nil { tmp5 = ifn_3294.Invoke_O__O(arg_3295) } else { tmp5 = linked_3293.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3292, arg_3295) }; arg_3287 = tmp4.Invoke_O__O(tmp5); if linked_3284 == nil { return ifn_3285.Invoke_O_O__O(arg_3286, arg_3287) } else { return linked_3284.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3283, arg_3286, arg_3287) } } else { var root_3296 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3296, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3298 lang.IFn; if linked_3297 == nil { ifn_3298 = lang.IFn_Cast(root_3296) } else { ifn_3298 = nil }; var arg_3299 any; var root_3301 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3301, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3303 lang.IFn; if linked_3302 == nil { ifn_3303 = lang.IFn_Cast(root_3301) } else { ifn_3303 = nil }; var arg_3304 any = b__292000285__6; if linked_3302 == nil { arg_3299 = ifn_3303.Invoke_O__O(arg_3304) } else { arg_3299 = linked_3302.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3301, arg_3304) }; var arg_3300 any; if linked_3297 == nil { return ifn_3298.Invoke_O_O__O(arg_3299, arg_3300) } else { return linked_3297.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3296, arg_3299, arg_3300) } } } else { var mm__4 any; var root_3305 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3305, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3307 lang.IFn; if linked_3306 == nil { ifn_3307 = lang.IFn_Cast(root_3305) } else { ifn_3307 = nil }; var arg_3308 any = s__292000283__3; if linked_3306 == nil { mm__4 = ifn_3307.Invoke_O__O(arg_3308) } else { mm__4 = linked_3306.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3305, arg_3308) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__4)) { var tmp6 int64; var na_3309 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_3309 = or__1927000174__auto____5 } else { na_3309 = A_arbace_j2g_dyncf_A_const_365 }; var na_3310 int64 = 4098; if jrt.Long_InstanceOf(na_3309) { var n0_3311 int64 = jrt.NN(jrt.Long_Cast(na_3309)).LongValue__J(); var n1_3312 int64 = na_3310; tmp6 = n0_3311 & n1_3312 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3309, na_3310) }
//line :464:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3314 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3314, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3316 lang.IFn; if linked_3315 == nil { ifn_3316 = lang.IFn_Cast(root_3314) } else { ifn_3316 = nil }; var arg_3317 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)); var arg_3318 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000282); var tmp8 any; var root_3319 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3319, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3321 lang.IFn; if linked_3320 == nil { ifn_3321 = lang.IFn_Cast(root_3319) } else { ifn_3321 = nil }; var arg_3322 any = s__292000283__3; if linked_3320 == nil { tmp8 = ifn_3321.Invoke_O__O(arg_3322) } else { tmp8 = linked_3320.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3319, arg_3322) }; arg_3318 = tmp7.Invoke_O__O(tmp8); if linked_3315 == nil { return ifn_3316.Invoke_O_O__O(arg_3317, arg_3318) } else { return linked_3315.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3314, arg_3317, arg_3318) } } else { var tmp9 any; var root_3323 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3323, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3325 lang.IFn; if linked_3324 == nil { ifn_3325 = lang.IFn_Cast(root_3323) } else { ifn_3325 = nil }; var arg_3326 any = s__292000283__3; if linked_3324 == nil { tmp9 = ifn_3325.Invoke_O__O(arg_3326) } else { tmp9 = linked_3324.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3323, arg_3326) }; s__292000283__1 = tmp9; continue L1 } } else { var tmp10 any; var root_3327 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3327, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3329 lang.IFn; if linked_3328 == nil { ifn_3329 = lang.IFn_Cast(root_3327) } else { ifn_3329 = nil }; var arg_3330 any = s__292000283__3; if linked_3328 == nil { tmp10 = ifn_3329.Invoke_O__O(arg_3330) } else { tmp10 = linked_3328.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3327, arg_3330) }; s__292000283__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :464:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A) Ctor_O_I_O(c__b__292000285 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000285 = c__b__292000285; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :464:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A) Invoke_O__O(self any) any { { var i__292000284__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000284__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000284__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_61, A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(mm__2)) { var tmp2 int64; var na_3271 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_3271 = or__1927000174__auto____3 } else { na_3271 = A_arbace_j2g_dyncf_A_const_365 }; var na_3272 int64 = 4098; if jrt.Long_InstanceOf(na_3271) { var n0_3273 int64 = jrt.NN(jrt.Long_Cast(na_3271)).LongValue__J(); var n1_3274 int64 = na_3272; tmp2 = n0_3273 & n1_3274 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_3271, na_3272) }
//line :464:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_3276 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3276, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3278 lang.IFn; if linked_3277 == nil { ifn_3278 = lang.IFn_Cast(root_3276) } else { ifn_3278 = nil }; var arg_3279 any = t.F_b__292000285; var arg_3280 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)); if linked_3277 == nil { ifn_3278.Invoke_O_O__O(arg_3279, arg_3280) } else { linked_3277.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3276, arg_3279, arg_3280) }; i__292000284__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000284__1); continue L1 } else { i__292000284__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000284__1); continue L1 } } else { i__292000284__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000284__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A) Ctor() {}
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A) Invoke_O_O__O(self, s__292000269__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3151 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A_New_O_O(self, s__292000269__1); var tmp2 *jrt.Class; var fncls__3150 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A_fn_class; if fncls__3150 == nil { var fncls__3150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__3151); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A_fn_class = fncls__3150d; tmp2 = fncls__3150d } else { tmp2 = fncls__3150 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3151, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :468:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A) Ctor_O_O(c__iter__292000268, c__s__292000269 any) { t.F_iter__292000268 = c__iter__292000268; t.F_s__292000269 = c__s__292000269 }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A) Invoke_O__O(self any) any { { var s__292000269__1 any; var t_ any = t.F_s__292000269; t.F_s__292000269 = nil; s__292000269__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3068 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3068, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3070 lang.IFn; if linked_3069 == nil { ifn_3070 = lang.IFn_Cast(root_3068) } else { ifn_3070 = nil }; var arg_3071 any = s__292000269__1; if linked_3069 == nil { temp__1927000414__auto____2 = ifn_3070.Invoke_O__O(arg_3071) } else { temp__1927000414__auto____2 = linked_3069.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3068, arg_3071) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000269__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3072 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3072, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3074 lang.IFn; if linked_3073 == nil { ifn_3074 = lang.IFn_Cast(root_3072) } else { ifn_3074 = nil }; var arg_3075 any = s__292000269__3; if linked_3073 == nil { tmp1 = ifn_3074.Invoke_O__O(arg_3075) } else { tmp1 = linked_3073.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3072, arg_3075) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3076 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3078 lang.IFn; if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any = s__292000269__3; if linked_3077 == nil { c__1927001037__auto____4 = ifn_3078.Invoke_O__O(arg_3079) } else { c__1927001037__auto____4 = linked_3077.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3076, arg_3079) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000271__6 any; var root_3080 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3080, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3082 lang.IFn; if linked_3081 == nil { ifn_3082 = lang.IFn_Cast(root_3080) } else { ifn_3082 = nil }; var arg_3083 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3081 == nil { b__292000271__6 = ifn_3082.Invoke_O__O(arg_3083) } else { b__292000271__6 = linked_3081.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3080, arg_3083) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3100 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__292000271__6); var tmp3 *jrt.Class; var fncls__3099 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A_fn_class; if fncls__3099 == nil { var fncls__3099d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__3100); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A_fn_class = fncls__3099d; tmp3 = fncls__3099d } else { tmp3 = fncls__3099 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3100, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3101 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3101, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3103 lang.IFn; if linked_3102 == nil { ifn_3103 = lang.IFn_Cast(root_3101) } else { ifn_3103 = nil }; var arg_3104 any; var root_3106 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3106, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3108 lang.IFn; if linked_3107 == nil { ifn_3108 = lang.IFn_Cast(root_3106) } else { ifn_3108 = nil }; var arg_3109 any = b__292000271__6; if linked_3107 == nil { arg_3104 = ifn_3108.Invoke_O__O(arg_3109) } else { arg_3104 = linked_3107.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3106, arg_3109) }; var arg_3105 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000268); var tmp5 any; var root_3110 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3110, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3112 lang.IFn; if linked_3111 == nil { ifn_3112 = lang.IFn_Cast(root_3110) } else { ifn_3112 = nil }; var arg_3113 any = s__292000269__3; if linked_3111 == nil { tmp5 = ifn_3112.Invoke_O__O(arg_3113) } else { tmp5 = linked_3111.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3110, arg_3113) }; arg_3105 = tmp4.Invoke_O__O(tmp5); if linked_3102 == nil { return ifn_3103.Invoke_O_O__O(arg_3104, arg_3105) } else { return linked_3102.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3101, arg_3104, arg_3105) } } else { var root_3114 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3114, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3116 lang.IFn; if linked_3115 == nil { ifn_3116 = lang.IFn_Cast(root_3114) } else { ifn_3116 = nil }; var arg_3117 any; var root_3119 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3119, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3121 lang.IFn; if linked_3120 == nil { ifn_3121 = lang.IFn_Cast(root_3119) } else { ifn_3121 = nil }; var arg_3122 any = b__292000271__6; if linked_3120 == nil { arg_3117 = ifn_3121.Invoke_O__O(arg_3122) } else { arg_3117 = linked_3120.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3119, arg_3122) }; var arg_3118 any; if linked_3115 == nil { return ifn_3116.Invoke_O_O__O(arg_3117, arg_3118) } else { return linked_3115.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3114, arg_3117, arg_3118) } } } else { var mm__4 any; var root_3123 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3123, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3125 lang.IFn; if linked_3124 == nil { ifn_3125 = lang.IFn_Cast(root_3123) } else { ifn_3125 = nil }; var arg_3126 any = s__292000269__3; if linked_3124 == nil { mm__4 = ifn_3125.Invoke_O__O(arg_3126) } else { mm__4 = linked_3124.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3123, arg_3126) }; var tmp6 int64; var na_3127 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { na_3127 = or__1927000174__auto____5 } else { na_3127 = A_arbace_j2g_dyncf_A_const_365 }; var na_3128 int64 = 4098; if jrt.Long_InstanceOf(na_3127) { var n0_3129 int64 = jrt.NN(jrt.Long_Cast(na_3127)).LongValue__J(); var n1_3130 int64 = na_3128; tmp6 = n0_3129 & n1_3130 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3127, na_3128) }
//line :468:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3132 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3132, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3134 lang.IFn; if linked_3133 == nil { ifn_3134 = lang.IFn_Cast(root_3132) } else { ifn_3134 = nil }; var arg_3135 any; var root_3137 any = A_arbace_j2g_dyncf_A_const_386.GetRawRoot__O(); var linked_3138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3137, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3139 lang.IFn

		if linked_3138 == nil { ifn_3139 = lang.IFn_Cast(root_3137) } else { ifn_3139 = nil }; var arg_3140 any = mm__4; var arg_3141 any = A_arbace_j2g_dyncf_A_const_398; if linked_3138 == nil { arg_3135 = ifn_3139.Invoke_O_O__O(arg_3140, arg_3141) } else { arg_3135 = linked_3138.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3137, arg_3140, arg_3141) }
//line :468:1
		var arg_3136 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000268); var tmp8 any; var root_3142 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3142, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3144 lang.IFn; if linked_3143 == nil { ifn_3144 = lang.IFn_Cast(root_3142) } else { ifn_3144 = nil }; var arg_3145 any = s__292000269__3; if linked_3143 == nil { tmp8 = ifn_3144.Invoke_O__O(arg_3145) } else { tmp8 = linked_3143.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3142, arg_3145) }; arg_3136 = tmp7.Invoke_O__O(tmp8); if linked_3133 == nil { return ifn_3134.Invoke_O_O__O(arg_3135, arg_3136) } else { return linked_3133.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3132, arg_3135, arg_3136) } } else { var tmp9 any; var root_3146 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3146, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3148 lang.IFn; if linked_3147 == nil { ifn_3148 = lang.IFn_Cast(root_3146) } else { ifn_3148 = nil }; var arg_3149 any = s__292000269__3; if linked_3147 == nil { tmp9 = ifn_3148.Invoke_O__O(arg_3149) } else { tmp9 = linked_3147.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3146, arg_3149) }; s__292000269__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :468:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__292000271 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__292000271 = c__b__292000271 }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A) Invoke_O__O(self any) any { { var i__292000270__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000270__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000270__1)); var tmp2 int64; var na_3084 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { na_3084 = or__1927000174__auto____3 } else { na_3084 = A_arbace_j2g_dyncf_A_const_365 }; var na_3085 int64 = 4098; if jrt.Long_InstanceOf(na_3084) { var n0_3086 int64 = jrt.NN(jrt.Long_Cast(na_3084)).LongValue__J(); var n1_3087 int64 = na_3085; tmp2 = n0_3086 & n1_3087 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_3084, na_3085) }
//line :468:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_3089 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3089, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3091 lang.IFn; if linked_3090 == nil { ifn_3091 = lang.IFn_Cast(root_3089) } else { ifn_3091 = nil }; var arg_3092 any = t.F_b__292000271; var arg_3093 any; var root_3094 any = A_arbace_j2g_dyncf_A_const_386.GetRawRoot__O(); var linked_3095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3094, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3096 lang.IFn

		if linked_3095 == nil { ifn_3096 = lang.IFn_Cast(root_3094) } else { ifn_3096 = nil }; var arg_3097 any = mm__2; var arg_3098 any = A_arbace_j2g_dyncf_A_const_397; if linked_3095 == nil { arg_3093 = ifn_3096.Invoke_O_O__O(arg_3097, arg_3098) } else { arg_3093 = linked_3095.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3094, arg_3097, arg_3098) }
//line :468:1
		if linked_3090 == nil { ifn_3091.Invoke_O_O__O(arg_3092, arg_3093) } else { linked_3090.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3089, arg_3092, arg_3093) }; i__292000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000270__1); continue L1 } else { i__292000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000270__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :468:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A) Ctor() {}
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A) Invoke_O_O__O(self, s__292000293__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3428 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A_New_O_O(self, s__292000293__1); var tmp2 *jrt.Class; var fncls__3427 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A_fn_class; if fncls__3427 == nil { var fncls__3427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__3428); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A_fn_class = fncls__3427d; tmp2 = fncls__3427d } else { tmp2 = fncls__3427 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3428, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :468:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A{}; t.Ctor_O_O(p0, p1); return t }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A) Ctor_O_O(c__iter__292000292, c__s__292000293 any) { t.F_iter__292000292 = c__iter__292000292; t.F_s__292000293 = c__s__292000293 }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A) Invoke_O__O(self any) any { { var s__292000293__1 any; var t_ any = t.F_s__292000293; t.F_s__292000293 = nil; s__292000293__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3345 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3347 lang.IFn; if linked_3346 == nil { ifn_3347 = lang.IFn_Cast(root_3345) } else { ifn_3347 = nil }; var arg_3348 any = s__292000293__1; if linked_3346 == nil { temp__1927000414__auto____2 = ifn_3347.Invoke_O__O(arg_3348) } else { temp__1927000414__auto____2 = linked_3346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3345, arg_3348) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000293__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3349 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3349, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3351 lang.IFn; if linked_3350 == nil { ifn_3351 = lang.IFn_Cast(root_3349) } else { ifn_3351 = nil }; var arg_3352 any = s__292000293__3; if linked_3350 == nil { tmp1 = ifn_3351.Invoke_O__O(arg_3352) } else { tmp1 = linked_3350.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3349, arg_3352) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3353 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3353, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3355 lang.IFn; if linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any = s__292000293__3; if linked_3354 == nil { c__1927001037__auto____4 = ifn_3355.Invoke_O__O(arg_3356) } else { c__1927001037__auto____4 = linked_3354.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3353, arg_3356) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000295__6 any; var root_3357 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3357, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3359 lang.IFn; if linked_3358 == nil { ifn_3359 = lang.IFn_Cast(root_3357) } else { ifn_3359 = nil }; var arg_3360 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3358 == nil { b__292000295__6 = ifn_3359.Invoke_O__O(arg_3360) } else { b__292000295__6 = linked_3358.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3357, arg_3360) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3377 any = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A_New_O_I_O(b__292000295__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3376 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A_fn_class; if fncls__3376 == nil { var fncls__3376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__3377); A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A_fn_class = fncls__3376d; tmp3 = fncls__3376d } else { tmp3 = fncls__3376 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3377, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3378 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3378, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3380 lang.IFn; if linked_3379 == nil { ifn_3380 = lang.IFn_Cast(root_3378) } else { ifn_3380 = nil }; var arg_3381 any; var root_3383 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3383, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3385 lang.IFn; if linked_3384 == nil { ifn_3385 = lang.IFn_Cast(root_3383) } else { ifn_3385 = nil }; var arg_3386 any = b__292000295__6; if linked_3384 == nil { arg_3381 = ifn_3385.Invoke_O__O(arg_3386) } else { arg_3381 = linked_3384.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3383, arg_3386) }; var arg_3382 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000292); var tmp5 any; var root_3387 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3387, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3389 lang.IFn; if linked_3388 == nil { ifn_3389 = lang.IFn_Cast(root_3387) } else { ifn_3389 = nil }; var arg_3390 any = s__292000293__3; if linked_3388 == nil { tmp5 = ifn_3389.Invoke_O__O(arg_3390) } else { tmp5 = linked_3388.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3387, arg_3390) }; arg_3382 = tmp4.Invoke_O__O(tmp5); if linked_3379 == nil { return ifn_3380.Invoke_O_O__O(arg_3381, arg_3382) } else { return linked_3379.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3378, arg_3381, arg_3382) } } else { var root_3391 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3391, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3393 lang.IFn; if linked_3392 == nil { ifn_3393 = lang.IFn_Cast(root_3391) } else { ifn_3393 = nil }; var arg_3394 any; var root_3396 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3396, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3398 lang.IFn; if linked_3397 == nil { ifn_3398 = lang.IFn_Cast(root_3396) } else { ifn_3398 = nil }; var arg_3399 any = b__292000295__6; if linked_3397 == nil { arg_3394 = ifn_3398.Invoke_O__O(arg_3399) } else { arg_3394 = linked_3397.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3396, arg_3399) }; var arg_3395 any; if linked_3392 == nil { return ifn_3393.Invoke_O_O__O(arg_3394, arg_3395) } else { return linked_3392.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3391, arg_3394, arg_3395) } } } else { var mm__4 any; var root_3400 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3400, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3402 lang.IFn; if linked_3401 == nil { ifn_3402 = lang.IFn_Cast(root_3400) } else { ifn_3402 = nil }; var arg_3403 any = s__292000293__3; if linked_3401 == nil { mm__4 = ifn_3402.Invoke_O__O(arg_3403) } else { mm__4 = linked_3401.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3400, arg_3403) }; var tmp6 int64; var na_3404 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { na_3404 = or__1927000174__auto____5 } else { na_3404 = A_arbace_j2g_dyncf_A_const_365 }; var na_3405 int64 = 4098; if jrt.Long_InstanceOf(na_3404) { var n0_3406 int64 = jrt.NN(jrt.Long_Cast(na_3404)).LongValue__J(); var n1_3407 int64 = na_3405; tmp6 = n0_3406 & n1_3407 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_3404, na_3405) }
//line :468:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_3409 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3409, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3411 lang.IFn; if linked_3410 == nil { ifn_3411 = lang.IFn_Cast(root_3409) } else { ifn_3411 = nil }; var arg_3412 any; var root_3414 any = A_arbace_j2g_dyncf_A_const_386.GetRawRoot__O(); var linked_3415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3414, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3416 lang.IFn

		if linked_3415 == nil { ifn_3416 = lang.IFn_Cast(root_3414) } else { ifn_3416 = nil }; var arg_3417 any = mm__4; var arg_3418 any = A_arbace_j2g_dyncf_A_const_401; if linked_3415 == nil { arg_3412 = ifn_3416.Invoke_O_O__O(arg_3417, arg_3418) } else { arg_3412 = linked_3415.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3414, arg_3417, arg_3418) }
//line :468:1
		var arg_3413 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000292); var tmp8 any; var root_3419 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3419, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3421 lang.IFn; if linked_3420 == nil { ifn_3421 = lang.IFn_Cast(root_3419) } else { ifn_3421 = nil }; var arg_3422 any = s__292000293__3; if linked_3420 == nil { tmp8 = ifn_3421.Invoke_O__O(arg_3422) } else { tmp8 = linked_3420.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3419, arg_3422) }; arg_3413 = tmp7.Invoke_O__O(tmp8); if linked_3410 == nil { return ifn_3411.Invoke_O_O__O(arg_3412, arg_3413) } else { return linked_3410.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3409, arg_3412, arg_3413) } } else { var tmp9 any; var root_3423 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3423, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3425 lang.IFn; if linked_3424 == nil { ifn_3425 = lang.IFn_Cast(root_3423) } else { ifn_3425 = nil }; var arg_3426 any = s__292000293__3; if linked_3424 == nil { tmp9 = ifn_3425.Invoke_O__O(arg_3426) } else { tmp9 = linked_3424.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3423, arg_3426) }; s__292000293__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :468:1
func A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A) Ctor_O_I_O(c__b__292000295 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000295 = c__b__292000295; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :468:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A) Invoke_O__O(self any) any { { var i__292000294__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000294__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000294__1)); var tmp2 int64; var na_3361 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(mm__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { na_3361 = or__1927000174__auto____3 } else { na_3361 = A_arbace_j2g_dyncf_A_const_365 }; var na_3362 int64 = 4098; if jrt.Long_InstanceOf(na_3361) { var n0_3363 int64 = jrt.NN(jrt.Long_Cast(na_3361)).LongValue__J(); var n1_3364 int64 = na_3362; tmp2 = n0_3363 & n1_3364 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_3361, na_3362) }
//line :468:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_3366 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3366, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3368 lang.IFn; if linked_3367 == nil { ifn_3368 = lang.IFn_Cast(root_3366) } else { ifn_3368 = nil }; var arg_3369 any = t.F_b__292000295; var arg_3370 any; var root_3371 any = A_arbace_j2g_dyncf_A_const_386.GetRawRoot__O(); var linked_3372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3371, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_3373 lang.IFn

		if linked_3372 == nil { ifn_3373 = lang.IFn_Cast(root_3371) } else { ifn_3373 = nil }; var arg_3374 any = mm__2; var arg_3375 any = A_arbace_j2g_dyncf_A_const_400; if linked_3372 == nil { arg_3370 = ifn_3373.Invoke_O_O__O(arg_3374, arg_3375) } else { arg_3370 = linked_3372.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_3371, arg_3374, arg_3375) }
//line :468:1
		if linked_3367 == nil { ifn_3368.Invoke_O_O__O(arg_3369, arg_3370) } else { linked_3367.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3366, arg_3369, arg_3370) }; i__292000294__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000294__1); continue L1 } else { i__292000294__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000294__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A{}; t.Ctor(); return t }
//line :474:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A) Ctor() {}
//line :474:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A) Invoke_O_O__O(self, s__292000305__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3820 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A_New_O_O(self, s__292000305__1); var tmp2 *jrt.Class; var fncls__3819 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A_fn_class; if fncls__3819 == nil { var fncls__3819d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__3820); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A_fn_class = fncls__3819d; tmp2 = fncls__3819d } else { tmp2 = fncls__3819 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3820, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :474:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A{}; t.Ctor_O_O(p0, p1); return t }
//line :474:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A) Ctor_O_O(c__iter__292000304, c__s__292000305 any) { t.F_iter__292000304 = c__iter__292000304; t.F_s__292000305 = c__s__292000305 }
//line :474:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A) Invoke_O__O(self any) any { { var s__292000305__1 any; var t_ any = t.F_s__292000305; t.F_s__292000305 = nil; s__292000305__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3451 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3453 lang.IFn; if linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any = s__292000305__1; if linked_3452 == nil { temp__1927000414__auto____2 = ifn_3453.Invoke_O__O(arg_3454) } else { temp__1927000414__auto____2 = linked_3452.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3451, arg_3454) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000305__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3455 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3457 lang.IFn; if linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any = s__292000305__3; if linked_3456 == nil { tmp1 = ifn_3457.Invoke_O__O(arg_3458) } else { tmp1 = linked_3456.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3455, arg_3458) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3459 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3459, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3461 lang.IFn; if linked_3460 == nil { ifn_3461 = lang.IFn_Cast(root_3459) } else { ifn_3461 = nil }; var arg_3462 any = s__292000305__3; if linked_3460 == nil { c__1927001037__auto____4 = ifn_3461.Invoke_O__O(arg_3462) } else { c__1927001037__auto____4 = linked_3460.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3459, arg_3462) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000307__6 any; var root_3463 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3463, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3465 lang.IFn; if linked_3464 == nil { ifn_3465 = lang.IFn_Cast(root_3463) } else { ifn_3465 = nil }; var arg_3466 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3464 == nil { b__292000307__6 = ifn_3465.Invoke_O__O(arg_3466) } else { b__292000307__6 = linked_3464.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3463, arg_3466) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3624 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A_New_O_I_O(b__292000307__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3623 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A_fn_class; if fncls__3623 == nil { var fncls__3623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__3624); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A_fn_class = fncls__3623d; tmp3 = fncls__3623d } else { tmp3 = fncls__3623 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3624, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3625 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3625, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3627 lang.IFn; if linked_3626 == nil { ifn_3627 = lang.IFn_Cast(root_3625) } else { ifn_3627 = nil }; var arg_3628 any; var root_3630 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3630, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3632 lang.IFn; if linked_3631 == nil { ifn_3632 = lang.IFn_Cast(root_3630) } else { ifn_3632 = nil }; var arg_3633 any = b__292000307__6; if linked_3631 == nil { arg_3628 = ifn_3632.Invoke_O__O(arg_3633) } else { arg_3628 = linked_3631.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3630, arg_3633) }; var arg_3629 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000304); var tmp5 any; var root_3634 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3634, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3636 lang.IFn; if linked_3635 == nil { ifn_3636 = lang.IFn_Cast(root_3634) } else { ifn_3636 = nil }; var arg_3637 any = s__292000305__3; if linked_3635 == nil { tmp5 = ifn_3636.Invoke_O__O(arg_3637) } else { tmp5 = linked_3635.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3634, arg_3637) }; arg_3629 = tmp4.Invoke_O__O(tmp5); if linked_3626 == nil { return ifn_3627.Invoke_O_O__O(arg_3628, arg_3629) } else { return linked_3626.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3625, arg_3628, arg_3629) } } else { var root_3638 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3638, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3640 lang.IFn; if linked_3639 == nil { ifn_3640 = lang.IFn_Cast(root_3638) } else { ifn_3640 = nil }; var arg_3641 any; var root_3643 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3645 lang.IFn; if linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any = b__292000307__6; if linked_3644 == nil { arg_3641 = ifn_3645.Invoke_O__O(arg_3646) } else { arg_3641 = linked_3644.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3643, arg_3646) }; var arg_3642 any; if linked_3639 == nil { return ifn_3640.Invoke_O_O__O(arg_3641, arg_3642) } else { return linked_3639.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3638, arg_3641, arg_3642) } } } else { var n__4 any; var root_3647 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3647, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3649 lang.IFn; if linked_3648 == nil { ifn_3649 = lang.IFn_Cast(root_3647) } else { ifn_3649 = nil }; var arg_3650 any = s__292000305__3; if linked_3648 == nil { n__4 = ifn_3649.Invoke_O__O(arg_3650) } else { n__4 = linked_3648.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3647, arg_3650) }; var d__5 any; var root_3651 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_3652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3651, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3653 lang.IFn
														if linked_3652 == nil { ifn_3653 = lang.IFn_Cast(root_3651) } else { ifn_3653 = nil }; var arg_3654 any = n__4; if linked_3652 == nil { d__5 = ifn_3653.Invoke_O__O(arg_3654) } else { d__5 = linked_3652.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3651, arg_3654) }
//line :474:1
	var tmp6 any
	var and__1927000168__auto____6 any = d__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_3655 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3655, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3657 lang.IFn; if linked_3656 == nil { ifn_3657 = lang.IFn_Cast(root_3655) } else { ifn_3657 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_409); var arg_3658 any = tmp7.Invoke_O__O(A_arbace_j2g_dyncf_A_const_392.Invoke_O__O(d__5)); if linked_3656 == nil { and__1927000168__auto____7 = ifn_3657.Invoke_O__O(arg_3658) } else { and__1927000168__auto____7 = linked_3656.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3655, arg_3658) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
		var tmp8 int64; var na_3659 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(d__5); if jrt.J2g_Truth(or__1927000174__auto____8) { na_3659 = or__1927000174__auto____8 } else { na_3659 = A_arbace_j2g_dyncf_A_const_365 }; var na_3660 int64 = 1; if jrt.Long_InstanceOf(na_3659) { var n0_3661 int64 = jrt.NN(jrt.Long_Cast(na_3659)).LongValue__J(); var n1_3662 int64 = na_3660; tmp8 = n0_3661 & n1_3662 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_3659, na_3660) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp8)).Ref() } else {
//line :476:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }
//line :474:1
	if jrt.J2g_Truth(tmp6) { var cs__6 any; var root_3664 any = A_arbace_j2g_dyncf_A_const_403.GetRawRoot__O(); var linked_3665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3664, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3666 lang.IFn



		if linked_3665 == nil { ifn_3666 = lang.IFn_Cast(root_3664) } else { ifn_3666 = nil }; var arg_3667 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_404.GetRawRoot__O()).Invoke__O(); var arg_3668 any; var iter__1927001039__auto____6 any; var fnbody__3797 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A_New(); var tmp9 *jrt.Class; var fncls__3796 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A_fn_class
		if fncls__3796 == nil { var fncls__3796d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A_fn_class = fncls__3796d; tmp9 = fncls__3796d } else { tmp9 = fncls__3796 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3797, tmp9, nil); arg_3668 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(A_arbace_j2g_dyncf_A_const_374.Invoke_O__O(d__5))
//line :478:1
		if linked_3665 == nil { cs__6 = ifn_3666.Invoke_O_O__O(arg_3667, arg_3668) } else { cs__6 = linked_3665.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3664, arg_3667, arg_3668) }
//line :474:1
		var tmp10 any; var root_3798 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3798, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3800 lang.IFn











		if linked_3799 == nil { ifn_3800 = lang.IFn_Cast(root_3798) } else { ifn_3800 = nil }; var arg_3801 any = cs__6; if linked_3799 == nil { tmp10 = ifn_3800.Invoke_O__O(arg_3801) } else { tmp10 = linked_3799.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3798, arg_3801) }
//line :474:1
		if jrt.J2g_Truth(tmp10) { var root_3802 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3802, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3804 lang.IFn; if linked_3803 == nil { ifn_3804 = lang.IFn_Cast(root_3802) } else { ifn_3804 = nil }; var arg_3805 any = lang.Tuple_Create_O_O__IPersistentVector(n__4, cs__6); var arg_3806 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__292000304); var tmp12 any; var root_3807 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3809 lang.IFn; if linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any = s__292000305__3; if linked_3808 == nil { tmp12 = ifn_3809.Invoke_O__O(arg_3810) } else { tmp12 = linked_3808.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3807, arg_3810) }; arg_3806 = tmp11.Invoke_O__O(tmp12); if linked_3803 == nil { return ifn_3804.Invoke_O_O__O(arg_3805, arg_3806) } else { return linked_3803.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3802, arg_3805, arg_3806) } } else { var tmp13 any; var root_3811 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3813 lang.IFn; if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; var arg_3814 any = s__292000305__3; if linked_3812 == nil { tmp13 = ifn_3813.Invoke_O__O(arg_3814) } else { tmp13 = linked_3812.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3811, arg_3814) }; s__292000305__1 = tmp13; continue L1 } } else { var tmp14 any; var root_3815 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3815, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3817 lang.IFn; if linked_3816 == nil { ifn_3817 = lang.IFn_Cast(root_3815) } else { ifn_3817 = nil }; var arg_3818 any = s__292000305__3; if linked_3816 == nil { tmp14 = ifn_3817.Invoke_O__O(arg_3818) } else { tmp14 = linked_3816.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3815, arg_3818) }; s__292000305__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :474:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :474:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A) Ctor_O_I_O(c__b__292000307 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000307 = c__b__292000307; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :474:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A) Invoke_O__O(self any) any { { var i__292000306__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000306__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000306__1)); var d__3 any; var root_3467 any = A_arbace_j2g_dyncf_A_const_109.GetRawRoot__O(); var linked_3468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3467, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3469 lang.IFn
																if linked_3468 == nil { ifn_3469 = lang.IFn_Cast(root_3467) } else { ifn_3469 = nil }; var arg_3470 any = n__2; if linked_3468 == nil { d__3 = ifn_3469.Invoke_O__O(arg_3470) } else { d__3 = linked_3468.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3467, arg_3470) }
//line :474:1
	var tmp2 any
	var and__1927000168__auto____4 any = d__3
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_3471 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3471, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3473 lang.IFn; if linked_3472 == nil { ifn_3473 = lang.IFn_Cast(root_3471) } else { ifn_3473 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_402); var arg_3474 any = tmp3.Invoke_O__O(A_arbace_j2g_dyncf_A_const_392.Invoke_O__O(d__3)); if linked_3472 == nil { and__1927000168__auto____5 = ifn_3473.Invoke_O__O(arg_3474) } else { and__1927000168__auto____5 = linked_3472.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3471, arg_3474) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
		var tmp4 int64; var na_3475 any; var or__1927000174__auto____6 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(d__3); if jrt.J2g_Truth(or__1927000174__auto____6) { na_3475 = or__1927000174__auto____6 } else { na_3475 = A_arbace_j2g_dyncf_A_const_365 }; var na_3476 int64 = 1; if jrt.Long_InstanceOf(na_3475) { var n0_3477 int64 = jrt.NN(jrt.Long_Cast(na_3475)).LongValue__J(); var n1_3478 int64 = na_3476; tmp4 = n0_3477 & n1_3478 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_3475, na_3476) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp4)).Ref() } else {
//line :476:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :474:1
	if jrt.J2g_Truth(tmp2) { var cs__4 any; var root_3480 any = A_arbace_j2g_dyncf_A_const_403.GetRawRoot__O(); var linked_3481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3480, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3482 lang.IFn



		if linked_3481 == nil { ifn_3482 = lang.IFn_Cast(root_3480) } else { ifn_3482 = nil }; var arg_3483 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_404.GetRawRoot__O()).Invoke__O(); var arg_3484 any; var iter__1927001039__auto____4 any; var fnbody__3613 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A_New(); var tmp5 *jrt.Class; var fncls__3612 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A_fn_class
		if fncls__3612 == nil { var fncls__3612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A_fn_class = fncls__3612d; tmp5 = fncls__3612d } else { tmp5 = fncls__3612 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3613, tmp5, nil); arg_3484 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_j2g_dyncf_A_const_374.Invoke_O__O(d__3))
//line :478:1
		if linked_3481 == nil { cs__4 = ifn_3482.Invoke_O_O__O(arg_3483, arg_3484) } else { cs__4 = linked_3481.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3480, arg_3483, arg_3484) }
//line :474:1
		var tmp6 any; var root_3614 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3616 lang.IFn











		if linked_3615 == nil { ifn_3616 = lang.IFn_Cast(root_3614) } else { ifn_3616 = nil }; var arg_3617 any = cs__4; if linked_3615 == nil { tmp6 = ifn_3616.Invoke_O__O(arg_3617) } else { tmp6 = linked_3615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3614, arg_3617) }
//line :474:1
		if jrt.J2g_Truth(tmp6) { var root_3618 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3618, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3620 lang.IFn; if linked_3619 == nil { ifn_3620 = lang.IFn_Cast(root_3618) } else { ifn_3620 = nil }; var arg_3621 any = t.F_b__292000307; var arg_3622 any = lang.Tuple_Create_O_O__IPersistentVector(n__2, cs__4); if linked_3619 == nil { ifn_3620.Invoke_O_O__O(arg_3621, arg_3622) } else { linked_3619.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3618, arg_3621, arg_3622) }; i__292000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000306__1); continue L1 } else { i__292000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000306__1); continue L1 } } else { i__292000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000306__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A{}; t.Ctor(); return t }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A) Ctor() {}
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A) Invoke_O_O__O(self, s__292000312__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3611 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A_New_O_O(self, s__292000312__1); var tmp2 *jrt.Class; var fncls__3610 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A_fn_class; if fncls__3610 == nil { var fncls__3610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__3611); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A_fn_class = fncls__3610d; tmp2 = fncls__3610d } else { tmp2 = fncls__3610 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3611, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :479:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A{}; t.Ctor_O_O(p0, p1); return t }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A) Ctor_O_O(c__iter__292000311, c__s__292000312 any) { t.F_iter__292000311 = c__iter__292000311; t.F_s__292000312 = c__s__292000312 }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A) Invoke_O__O(self any) any { { var s__292000312__1 any; var t_ any = t.F_s__292000312; t.F_s__292000312 = nil; s__292000312__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3488 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3490 lang.IFn; if linked_3489 == nil { ifn_3490 = lang.IFn_Cast(root_3488) } else { ifn_3490 = nil }; var arg_3491 any = s__292000312__1; if linked_3489 == nil { temp__1927000414__auto____2 = ifn_3490.Invoke_O__O(arg_3491) } else { temp__1927000414__auto____2 = linked_3489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3488, arg_3491) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000312__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3492 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3492, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3494 lang.IFn; if linked_3493 == nil { ifn_3494 = lang.IFn_Cast(root_3492) } else { ifn_3494 = nil }; var arg_3495 any = s__292000312__3; if linked_3493 == nil { tmp1 = ifn_3494.Invoke_O__O(arg_3495) } else { tmp1 = linked_3493.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3492, arg_3495) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3496 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3496, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3498 lang.IFn; if linked_3497 == nil { ifn_3498 = lang.IFn_Cast(root_3496) } else { ifn_3498 = nil }; var arg_3499 any = s__292000312__3; if linked_3497 == nil { c__1927001037__auto____4 = ifn_3498.Invoke_O__O(arg_3499) } else { c__1927001037__auto____4 = linked_3497.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3496, arg_3499) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000314__6 any; var root_3500 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3500, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3502 lang.IFn; if linked_3501 == nil { ifn_3502 = lang.IFn_Cast(root_3500) } else { ifn_3502 = nil }; var arg_3503 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3501 == nil { b__292000314__6 = ifn_3502.Invoke_O__O(arg_3503) } else { b__292000314__6 = linked_3501.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3500, arg_3503) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3538 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A_New_O_I_O(b__292000314__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3537 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A_fn_class; if fncls__3537 == nil { var fncls__3537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__3538); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A_fn_class = fncls__3537d; tmp3 = fncls__3537d } else { tmp3 = fncls__3537 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3538, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3539 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3539, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3541 lang.IFn; if linked_3540 == nil { ifn_3541 = lang.IFn_Cast(root_3539) } else { ifn_3541 = nil }; var arg_3542 any; var root_3544 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3544, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3546 lang.IFn; if linked_3545 == nil { ifn_3546 = lang.IFn_Cast(root_3544) } else { ifn_3546 = nil }; var arg_3547 any = b__292000314__6; if linked_3545 == nil { arg_3542 = ifn_3546.Invoke_O__O(arg_3547) } else { arg_3542 = linked_3545.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3544, arg_3547) }; var arg_3543 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000311); var tmp5 any; var root_3548 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3548, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3550 lang.IFn; if linked_3549 == nil { ifn_3550 = lang.IFn_Cast(root_3548) } else { ifn_3550 = nil }; var arg_3551 any = s__292000312__3; if linked_3549 == nil { tmp5 = ifn_3550.Invoke_O__O(arg_3551) } else { tmp5 = linked_3549.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3548, arg_3551) }; arg_3543 = tmp4.Invoke_O__O(tmp5); if linked_3540 == nil { return ifn_3541.Invoke_O_O__O(arg_3542, arg_3543) } else { return linked_3540.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3539, arg_3542, arg_3543) } } else { var root_3552 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3552, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3554 lang.IFn; if linked_3553 == nil { ifn_3554 = lang.IFn_Cast(root_3552) } else { ifn_3554 = nil }; var arg_3555 any; var root_3557 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3557, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any = b__292000314__6; if linked_3558 == nil { arg_3555 = ifn_3559.Invoke_O__O(arg_3560) } else { arg_3555 = linked_3558.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3557, arg_3560) }; var arg_3556 any; if linked_3553 == nil { return ifn_3554.Invoke_O_O__O(arg_3555, arg_3556) } else { return linked_3553.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3552, arg_3555, arg_3556) } } } else { var f__4 any; var root_3561 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3561, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3563 lang.IFn; if linked_3562 == nil { ifn_3563 = lang.IFn_Cast(root_3561) } else { ifn_3563 = nil }; var arg_3564 any = s__292000312__3; if linked_3562 == nil { f__4 = ifn_3563.Invoke_O__O(arg_3564) } else { f__4 = linked_3562.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3561, arg_3564) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_365 }
//line :479:1
	var tmp6 any; var and__1927000168__auto____6 bool; var tmp7 int64
	var na_3565 any = fl__5; var na_3566 int64 = 24
	if jrt.Long_InstanceOf(na_3565) { var n0_3567 int64 = jrt.NN(jrt.Long_Cast(na_3565)).LongValue__J(); var n1_3568 int64 = na_3566; tmp7 = n0_3567 & n1_3568 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_3565, na_3566) }; and__1927000168__auto____6 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool; var tmp8 int64; var na_3570 any = fl__5; var na_3571 int64 = 5; if jrt.Long_InstanceOf(na_3570) { var n0_3572 int64 = jrt.NN(jrt.Long_Cast(na_3570)).LongValue__J(); var n1_3573 int64 = na_3571; tmp8 = n0_3572 & n1_3573 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_3570, na_3571) }; and__1927000168__auto____7 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____7 { var or__1927000174__auto____8 any; var root_3575 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3575, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3577 lang.IFn
		if linked_3576 == nil { ifn_3577 = lang.IFn_Cast(root_3575) } else { ifn_3577 = nil }; var arg_3578 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_3576 == nil { or__1927000174__auto____8 = ifn_3577.Invoke_O__O(arg_3578) } else { or__1927000174__auto____8 = linked_3576.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3575, arg_3578) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_405.GetRawRoot__O())).Ref() } } else {
//line :481:1
			tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }
//line :479:1
	if jrt.J2g_Truth(tmp6) { var v__6 any; var tmp9 *lang.Compiler_AOTFn; var fnbody__3584 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A_New_O(f__4); var tmp10 *jrt.Class
		var fncls__3583 /*line :479:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A_fn_class



		if fncls__3583 == nil { var fncls__3583d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__3584); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A_fn_class = fncls__3583d; tmp10 = fncls__3583d } else { tmp10 = fncls__3583 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3584, tmp10, nil); v__6 = Up_Compiler_AOTFn_IFn(tmp9).Invoke__O()
//line :479:1
		var tmp11 any; var root_3585 any = A_arbace_j2g_dyncf_A_const_407.GetRawRoot__O(); var linked_3586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3585, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3587 lang.IFn




		if linked_3586 == nil { ifn_3587 = lang.IFn_Cast(root_3585) } else { ifn_3587 = nil }; var arg_3588 any = v__6; if linked_3586 == nil { tmp11 = ifn_3587.Invoke_O__O(arg_3588) } else { tmp11 = linked_3586.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3585, arg_3588) }
//line :479:1
		if jrt.J2g_Truth(tmp11) { var root_3589 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3589, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3591 lang.IFn; if linked_3590 == nil { ifn_3591 = lang.IFn_Cast(root_3589) } else { ifn_3591 = nil }; var arg_3592 any; var tmp12 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp13 any; var tmp14 any; var root_3594 any = A_arbace_j2g_dyncf_A_const_408.GetRawRoot__O(); var linked_3595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3594, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_3596 lang.IFn





			if linked_3595 == nil { ifn_3596 = lang.IFn_Cast(root_3594) } else { ifn_3596 = nil }; var arg_3597 any = v__6; if linked_3595 == nil { tmp14 = ifn_3596.Invoke_O__O(arg_3597) } else { tmp14 = linked_3595.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_3594, arg_3597) }; if jrt.J2g_Truth(tmp14) { tmp13 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp13 = v__6 }
//line :479:1
			arg_3592 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); var arg_3593 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__292000311); var tmp16 any; var root_3598 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3598, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3600 lang.IFn; if linked_3599 == nil { ifn_3600 = lang.IFn_Cast(root_3598) } else { ifn_3600 = nil }; var arg_3601 any = s__292000312__3; if linked_3599 == nil { tmp16 = ifn_3600.Invoke_O__O(arg_3601) } else { tmp16 = linked_3599.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3598, arg_3601) }; arg_3593 = tmp15.Invoke_O__O(tmp16); if linked_3590 == nil { return ifn_3591.Invoke_O_O__O(arg_3592, arg_3593) } else { return linked_3590.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3589, arg_3592, arg_3593) } } else { var tmp17 any; var root_3602 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3602, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3604 lang.IFn; if linked_3603 == nil { ifn_3604 = lang.IFn_Cast(root_3602) } else { ifn_3604 = nil }; var arg_3605 any = s__292000312__3; if linked_3603 == nil { tmp17 = ifn_3604.Invoke_O__O(arg_3605) } else { tmp17 = linked_3603.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3602, arg_3605) }; s__292000312__1 = tmp17; continue L1 } } else { var tmp18 any; var root_3606 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3606, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3608 lang.IFn; if linked_3607 == nil { ifn_3608 = lang.IFn_Cast(root_3606) } else { ifn_3608 = nil }; var arg_3609 any = s__292000312__3; if linked_3607 == nil { tmp18 = ifn_3608.Invoke_O__O(arg_3609) } else { tmp18 = linked_3607.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3606, arg_3609) }; s__292000312__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :479:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A) Ctor_O_I_O(c__b__292000314 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000314 = c__b__292000314; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A) Invoke_O__O(self any) any { { var i__292000313__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000313__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000313__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_365 }
//line :479:1
	var tmp2 any; var and__1927000168__auto____4 bool; var tmp3 int64
	var na_3504 any = fl__3; var na_3505 int64 = 24
	if jrt.Long_InstanceOf(na_3504) { var n0_3506 int64 = jrt.NN(jrt.Long_Cast(na_3504)).LongValue__J(); var n1_3507 int64 = na_3505; tmp3 = n0_3506 & n1_3507 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_3504, na_3505) }; and__1927000168__auto____4 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool; var tmp4 int64; var na_3509 any = fl__3; var na_3510 int64 = 5; if jrt.Long_InstanceOf(na_3509) { var n0_3511 int64 = jrt.NN(jrt.Long_Cast(na_3509)).LongValue__J(); var n1_3512 int64 = na_3510; tmp4 = n0_3511 & n1_3512 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_3509, na_3510) }; and__1927000168__auto____5 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____5 { var or__1927000174__auto____6 any; var root_3514 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3514, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3516 lang.IFn
		if linked_3515 == nil { ifn_3516 = lang.IFn_Cast(root_3514) } else { ifn_3516 = nil }; var arg_3517 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_3515 == nil { or__1927000174__auto____6 = ifn_3516.Invoke_O__O(arg_3517) } else { or__1927000174__auto____6 = linked_3515.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3514, arg_3517) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_405.GetRawRoot__O())).Ref() } } else {
//line :481:1
			tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }
//line :479:1
	if jrt.J2g_Truth(tmp2) { var v__4 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__3523 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A_New_O(f__2); var tmp6 *jrt.Class
		var fncls__3522 /*line :479:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A_fn_class



		if fncls__3522 == nil { var fncls__3522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__3523); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A_fn_class = fncls__3522d; tmp6 = fncls__3522d } else { tmp6 = fncls__3522 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3523, tmp6, nil); v__4 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :479:1
		var tmp7 any; var root_3524 any = A_arbace_j2g_dyncf_A_const_407.GetRawRoot__O(); var linked_3525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3524, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3526 lang.IFn




		if linked_3525 == nil { ifn_3526 = lang.IFn_Cast(root_3524) } else { ifn_3526 = nil }; var arg_3527 any = v__4; if linked_3525 == nil { tmp7 = ifn_3526.Invoke_O__O(arg_3527) } else { tmp7 = linked_3525.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3524, arg_3527) }
//line :479:1
		if jrt.J2g_Truth(tmp7) { var root_3528 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3528, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3530 lang.IFn; if linked_3529 == nil { ifn_3530 = lang.IFn_Cast(root_3528) } else { ifn_3530 = nil }; var arg_3531 any = t.F_b__292000314; var arg_3532 any; var tmp8 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp9 any; var tmp10 any; var root_3533 any = A_arbace_j2g_dyncf_A_const_408.GetRawRoot__O(); var linked_3534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3533, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_3535 lang.IFn





			if linked_3534 == nil { ifn_3535 = lang.IFn_Cast(root_3533) } else { ifn_3535 = nil }; var arg_3536 any = v__4; if linked_3534 == nil { tmp10 = ifn_3535.Invoke_O__O(arg_3536) } else { tmp10 = linked_3534.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_3533, arg_3536) }; if jrt.J2g_Truth(tmp10) { tmp9 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp9 = v__4 }
//line :479:1
			arg_3532 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); if linked_3529 == nil { ifn_3530.Invoke_O_O__O(arg_3531, arg_3532) } else { linked_3529.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3528, arg_3531, arg_3532) }; i__292000313__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000313__1); continue L1 } else { i__292000313__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000313__1); continue L1 } } else { i__292000313__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000313__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :479:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A{}; t.Ctor(); return t }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A) Ctor() {}
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A) Invoke_O_O__O(self, s__292000327__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3795 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A_New_O_O(self, s__292000327__1); var tmp2 *jrt.Class; var fncls__3794 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A_fn_class; if fncls__3794 == nil { var fncls__3794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__3795); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A_fn_class = fncls__3794d; tmp2 = fncls__3794d } else { tmp2 = fncls__3794 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3795, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :479:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A{}; t.Ctor_O_O(p0, p1); return t }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A) Ctor_O_O(c__iter__292000326, c__s__292000327 any) { t.F_iter__292000326 = c__iter__292000326; t.F_s__292000327 = c__s__292000327 }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A) Invoke_O__O(self any) any { { var s__292000327__1 any; var t_ any = t.F_s__292000327; t.F_s__292000327 = nil; s__292000327__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3672 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3672, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3674 lang.IFn; if linked_3673 == nil { ifn_3674 = lang.IFn_Cast(root_3672) } else { ifn_3674 = nil }; var arg_3675 any = s__292000327__1; if linked_3673 == nil { temp__1927000414__auto____2 = ifn_3674.Invoke_O__O(arg_3675) } else { temp__1927000414__auto____2 = linked_3673.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3672, arg_3675) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000327__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3676 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3676, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3678 lang.IFn; if linked_3677 == nil { ifn_3678 = lang.IFn_Cast(root_3676) } else { ifn_3678 = nil }; var arg_3679 any = s__292000327__3; if linked_3677 == nil { tmp1 = ifn_3678.Invoke_O__O(arg_3679) } else { tmp1 = linked_3677.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3676, arg_3679) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3680 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3680, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3682 lang.IFn; if linked_3681 == nil { ifn_3682 = lang.IFn_Cast(root_3680) } else { ifn_3682 = nil }; var arg_3683 any = s__292000327__3; if linked_3681 == nil { c__1927001037__auto____4 = ifn_3682.Invoke_O__O(arg_3683) } else { c__1927001037__auto____4 = linked_3681.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3680, arg_3683) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000329__6 any; var root_3684 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3684, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3686 lang.IFn; if linked_3685 == nil { ifn_3686 = lang.IFn_Cast(root_3684) } else { ifn_3686 = nil }; var arg_3687 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3685 == nil { b__292000329__6 = ifn_3686.Invoke_O__O(arg_3687) } else { b__292000329__6 = linked_3685.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3684, arg_3687) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3722 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A_New_O_I_O(b__292000329__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3721 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A_fn_class; if fncls__3721 == nil { var fncls__3721d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__3722); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A_fn_class = fncls__3721d; tmp3 = fncls__3721d } else { tmp3 = fncls__3721 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3722, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3723 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3723, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3725 lang.IFn; if linked_3724 == nil { ifn_3725 = lang.IFn_Cast(root_3723) } else { ifn_3725 = nil }; var arg_3726 any; var root_3728 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3728, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3730 lang.IFn; if linked_3729 == nil { ifn_3730 = lang.IFn_Cast(root_3728) } else { ifn_3730 = nil }; var arg_3731 any = b__292000329__6; if linked_3729 == nil { arg_3726 = ifn_3730.Invoke_O__O(arg_3731) } else { arg_3726 = linked_3729.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3728, arg_3731) }; var arg_3727 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000326); var tmp5 any; var root_3732 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3732, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3734 lang.IFn; if linked_3733 == nil { ifn_3734 = lang.IFn_Cast(root_3732) } else { ifn_3734 = nil }; var arg_3735 any = s__292000327__3; if linked_3733 == nil { tmp5 = ifn_3734.Invoke_O__O(arg_3735) } else { tmp5 = linked_3733.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3732, arg_3735) }; arg_3727 = tmp4.Invoke_O__O(tmp5); if linked_3724 == nil { return ifn_3725.Invoke_O_O__O(arg_3726, arg_3727) } else { return linked_3724.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3723, arg_3726, arg_3727) } } else { var root_3736 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3736, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3738 lang.IFn; if linked_3737 == nil { ifn_3738 = lang.IFn_Cast(root_3736) } else { ifn_3738 = nil }; var arg_3739 any; var root_3741 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3741, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3743 lang.IFn; if linked_3742 == nil { ifn_3743 = lang.IFn_Cast(root_3741) } else { ifn_3743 = nil }; var arg_3744 any = b__292000329__6; if linked_3742 == nil { arg_3739 = ifn_3743.Invoke_O__O(arg_3744) } else { arg_3739 = linked_3742.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3741, arg_3744) }; var arg_3740 any; if linked_3737 == nil { return ifn_3738.Invoke_O_O__O(arg_3739, arg_3740) } else { return linked_3737.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3736, arg_3739, arg_3740) } } } else { var f__4 any; var root_3745 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3745, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3747 lang.IFn; if linked_3746 == nil { ifn_3747 = lang.IFn_Cast(root_3745) } else { ifn_3747 = nil }; var arg_3748 any = s__292000327__3; if linked_3746 == nil { f__4 = ifn_3747.Invoke_O__O(arg_3748) } else { f__4 = linked_3746.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3745, arg_3748) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_365 }
//line :479:1
	var tmp6 any; var and__1927000168__auto____6 bool; var tmp7 int64
	var na_3749 any = fl__5; var na_3750 int64 = 24
	if jrt.Long_InstanceOf(na_3749) { var n0_3751 int64 = jrt.NN(jrt.Long_Cast(na_3749)).LongValue__J(); var n1_3752 int64 = na_3750; tmp7 = n0_3751 & n1_3752 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_3749, na_3750) }; and__1927000168__auto____6 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool; var tmp8 int64; var na_3754 any = fl__5; var na_3755 int64 = 5; if jrt.Long_InstanceOf(na_3754) { var n0_3756 int64 = jrt.NN(jrt.Long_Cast(na_3754)).LongValue__J(); var n1_3757 int64 = na_3755; tmp8 = n0_3756 & n1_3757 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_3754, na_3755) }; and__1927000168__auto____7 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____7 { var or__1927000174__auto____8 any; var root_3759 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3759, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3761 lang.IFn
		if linked_3760 == nil { ifn_3761 = lang.IFn_Cast(root_3759) } else { ifn_3761 = nil }; var arg_3762 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_3760 == nil { or__1927000174__auto____8 = ifn_3761.Invoke_O__O(arg_3762) } else { or__1927000174__auto____8 = linked_3760.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3759, arg_3762) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_405.GetRawRoot__O())).Ref() } } else {
//line :481:1
			tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }
//line :479:1
	if jrt.J2g_Truth(tmp6) { var v__6 any; var tmp9 *lang.Compiler_AOTFn; var fnbody__3768 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A_New_O(f__4); var tmp10 *jrt.Class
		var fncls__3767 /*line :479:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A_fn_class



		if fncls__3767 == nil { var fncls__3767d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__3768); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A_fn_class = fncls__3767d; tmp10 = fncls__3767d } else { tmp10 = fncls__3767 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3768, tmp10, nil); v__6 = Up_Compiler_AOTFn_IFn(tmp9).Invoke__O()
//line :479:1
		var tmp11 any; var root_3769 any = A_arbace_j2g_dyncf_A_const_407.GetRawRoot__O(); var linked_3770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3769, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3771 lang.IFn




		if linked_3770 == nil { ifn_3771 = lang.IFn_Cast(root_3769) } else { ifn_3771 = nil }; var arg_3772 any = v__6; if linked_3770 == nil { tmp11 = ifn_3771.Invoke_O__O(arg_3772) } else { tmp11 = linked_3770.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3769, arg_3772) }
//line :479:1
		if jrt.J2g_Truth(tmp11) { var root_3773 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3775 lang.IFn; if linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any; var tmp12 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp13 any; var tmp14 any; var root_3778 any = A_arbace_j2g_dyncf_A_const_408.GetRawRoot__O(); var linked_3779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3778, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_3780 lang.IFn





			if linked_3779 == nil { ifn_3780 = lang.IFn_Cast(root_3778) } else { ifn_3780 = nil }; var arg_3781 any = v__6; if linked_3779 == nil { tmp14 = ifn_3780.Invoke_O__O(arg_3781) } else { tmp14 = linked_3779.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_3778, arg_3781) }; if jrt.J2g_Truth(tmp14) { tmp13 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp13 = v__6 }
//line :479:1
			arg_3776 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); var arg_3777 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__292000326); var tmp16 any; var root_3782 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3782, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3784 lang.IFn; if linked_3783 == nil { ifn_3784 = lang.IFn_Cast(root_3782) } else { ifn_3784 = nil }; var arg_3785 any = s__292000327__3; if linked_3783 == nil { tmp16 = ifn_3784.Invoke_O__O(arg_3785) } else { tmp16 = linked_3783.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3782, arg_3785) }; arg_3777 = tmp15.Invoke_O__O(tmp16); if linked_3774 == nil { return ifn_3775.Invoke_O_O__O(arg_3776, arg_3777) } else { return linked_3774.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3773, arg_3776, arg_3777) } } else { var tmp17 any; var root_3786 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3786, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3788 lang.IFn; if linked_3787 == nil { ifn_3788 = lang.IFn_Cast(root_3786) } else { ifn_3788 = nil }; var arg_3789 any = s__292000327__3; if linked_3787 == nil { tmp17 = ifn_3788.Invoke_O__O(arg_3789) } else { tmp17 = linked_3787.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3786, arg_3789) }; s__292000327__1 = tmp17; continue L1 } } else { var tmp18 any; var root_3790 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3790, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3792 lang.IFn; if linked_3791 == nil { ifn_3792 = lang.IFn_Cast(root_3790) } else { ifn_3792 = nil }; var arg_3793 any = s__292000327__3; if linked_3791 == nil { tmp18 = ifn_3792.Invoke_O__O(arg_3793) } else { tmp18 = linked_3791.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3790, arg_3793) }; s__292000327__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :479:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A) Ctor_O_I_O(c__b__292000329 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000329 = c__b__292000329; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :479:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A) Invoke_O__O(self any) any { { var i__292000328__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000328__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000328__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_365 }
//line :479:1
	var tmp2 any; var and__1927000168__auto____4 bool; var tmp3 int64
	var na_3688 any = fl__3; var na_3689 int64 = 24
	if jrt.Long_InstanceOf(na_3688) { var n0_3690 int64 = jrt.NN(jrt.Long_Cast(na_3688)).LongValue__J(); var n1_3691 int64 = na_3689; tmp3 = n0_3690 & n1_3691 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_3688, na_3689) }; and__1927000168__auto____4 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool; var tmp4 int64; var na_3693 any = fl__3; var na_3694 int64 = 5; if jrt.Long_InstanceOf(na_3693) { var n0_3695 int64 = jrt.NN(jrt.Long_Cast(na_3693)).LongValue__J(); var n1_3696 int64 = na_3694; tmp4 = n0_3695 & n1_3696 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_3693, na_3694) }; and__1927000168__auto____5 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____5 { var or__1927000174__auto____6 any; var root_3698 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3698, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3700 lang.IFn
		if linked_3699 == nil { ifn_3700 = lang.IFn_Cast(root_3698) } else { ifn_3700 = nil }; var arg_3701 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_3699 == nil { or__1927000174__auto____6 = ifn_3700.Invoke_O__O(arg_3701) } else { or__1927000174__auto____6 = linked_3699.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3698, arg_3701) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_405.GetRawRoot__O())).Ref() } } else {
//line :481:1
			tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }
//line :479:1
	if jrt.J2g_Truth(tmp2) { var v__4 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__3707 any = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A_New_O(f__2); var tmp6 *jrt.Class
		var fncls__3706 /*line :479:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A_fn_class



		if fncls__3706 == nil { var fncls__3706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__3707); A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A_fn_class = fncls__3706d; tmp6 = fncls__3706d } else { tmp6 = fncls__3706 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3707, tmp6, nil); v__4 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :479:1
		var tmp7 any; var root_3708 any = A_arbace_j2g_dyncf_A_const_407.GetRawRoot__O(); var linked_3709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3708, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3710 lang.IFn




		if linked_3709 == nil { ifn_3710 = lang.IFn_Cast(root_3708) } else { ifn_3710 = nil }; var arg_3711 any = v__4; if linked_3709 == nil { tmp7 = ifn_3710.Invoke_O__O(arg_3711) } else { tmp7 = linked_3709.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3708, arg_3711) }
//line :479:1
		if jrt.J2g_Truth(tmp7) { var root_3712 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3712, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3714 lang.IFn; if linked_3713 == nil { ifn_3714 = lang.IFn_Cast(root_3712) } else { ifn_3714 = nil }; var arg_3715 any = t.F_b__292000329; var arg_3716 any; var tmp8 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp9 any; var tmp10 any; var root_3717 any = A_arbace_j2g_dyncf_A_const_408.GetRawRoot__O(); var linked_3718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3717, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_3719 lang.IFn





			if linked_3718 == nil { ifn_3719 = lang.IFn_Cast(root_3717) } else { ifn_3719 = nil }; var arg_3720 any = v__4; if linked_3718 == nil { tmp10 = ifn_3719.Invoke_O__O(arg_3720) } else { tmp10 = linked_3718.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_3717, arg_3720) }; if jrt.J2g_Truth(tmp10) { tmp9 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp9 = v__4 }
//line :479:1
			arg_3716 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); if linked_3713 == nil { ifn_3714.Invoke_O_O__O(arg_3715, arg_3716) } else { linked_3713.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3712, arg_3715, arg_3716) }; i__292000328__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000328__1); continue L1 } else { i__292000328__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000328__1); continue L1 } } else { i__292000328__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000328__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A{}; t.Ctor_O(p0); return t }
//line :483:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :483:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3518 any = A_arbace_j2g_dyncf_A_const_406.GetRawRoot__O(); var linked_3519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3518, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_3520 lang.IFn; if linked_3519 == nil { ifn_3520 = lang.IFn_Cast(root_3518) } else { ifn_3520 = nil }; var arg_3521 any; var t_ any = t.F_f; t.F_f = nil; arg_3521 = t_; if linked_3519 == nil { tmp1 = ifn_3520.Invoke_O__O(arg_3521) } else { tmp1 = linked_3519.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_3518, arg_3521) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :483:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A{}; t.Ctor_O(p0); return t }
//line :483:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :483:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3579 any = A_arbace_j2g_dyncf_A_const_406.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3579, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_3581 lang.IFn; if linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any; var t_ any = t.F_f; t.F_f = nil; arg_3582 = t_; if linked_3580 == nil { tmp1 = ifn_3581.Invoke_O__O(arg_3582) } else { tmp1 = linked_3580.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_3579, arg_3582) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :483:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A{}; t.Ctor_O(p0); return t }
//line :483:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :483:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3702 any = A_arbace_j2g_dyncf_A_const_406.GetRawRoot__O(); var linked_3703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3702, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_3704 lang.IFn; if linked_3703 == nil { ifn_3704 = lang.IFn_Cast(root_3702) } else { ifn_3704 = nil }; var arg_3705 any; var t_ any = t.F_f; t.F_f = nil; arg_3705 = t_; if linked_3703 == nil { tmp1 = ifn_3704.Invoke_O__O(arg_3705) } else { tmp1 = linked_3703.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_3702, arg_3705) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :483:1
func A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A{}; t.Ctor_O(p0); return t }
//line :483:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :483:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3763 any = A_arbace_j2g_dyncf_A_const_406.GetRawRoot__O(); var linked_3764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3763, aot_arbace_classes_env.A_arbace_classes_env_const_value_A_fn_class); var ifn_3765 lang.IFn; if linked_3764 == nil { ifn_3765 = lang.IFn_Cast(root_3763) } else { ifn_3765 = nil }; var arg_3766 any; var t_ any = t.F_f; t.F_f = nil; arg_3766 = t_; if linked_3764 == nil { tmp1 = ifn_3765.Invoke_O__O(arg_3766) } else { tmp1 = linked_3764.(*aot_arbace_classes_env.A_arbace_classes_env_const_value_A).Invoke_O_O__O(root_3763, arg_3766) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A{}; t.Ctor_O(p0); return t }
//line :491:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A) Ctor_O(c__tset any) { t.F_tset = c__tset }
//line :491:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A) Invoke_O_O__O(self, s__292000343__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4156 any = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A_New_O_O_O(t.F_tset, self, s__292000343__1); var tmp2 *jrt.Class; var fncls__4155 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A_fn_class; if fncls__4155 == nil { var fncls__4155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__4156); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A_fn_class = fncls__4155d; tmp2 = fncls__4155d } else { tmp2 = fncls__4155 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4156, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :491:1
func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :491:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A) Ctor_O_O_O(c__tset, c__iter__292000342, c__s__292000343 any) { t.F_tset = c__tset; t.F_iter__292000342 = c__iter__292000342; t.F_s__292000343 = c__s__292000343 }
//line :491:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A) Invoke_O__O(self any) any { { var s__292000343__1 any; var t_ any = t.F_s__292000343; t.F_s__292000343 = nil; s__292000343__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3827 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3827, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3829 lang.IFn; if linked_3828 == nil { ifn_3829 = lang.IFn_Cast(root_3827) } else { ifn_3829 = nil }; var arg_3830 any = s__292000343__1; if linked_3828 == nil { temp__1927000414__auto____2 = ifn_3829.Invoke_O__O(arg_3830) } else { temp__1927000414__auto____2 = linked_3828.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3827, arg_3830) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000343__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3831 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3831, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3833 lang.IFn; if linked_3832 == nil { ifn_3833 = lang.IFn_Cast(root_3831) } else { ifn_3833 = nil }; var arg_3834 any = s__292000343__3; if linked_3832 == nil { tmp1 = ifn_3833.Invoke_O__O(arg_3834) } else { tmp1 = linked_3832.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3831, arg_3834) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3835 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3835, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3837 lang.IFn; if linked_3836 == nil { ifn_3837 = lang.IFn_Cast(root_3835) } else { ifn_3837 = nil }; var arg_3838 any = s__292000343__3; if linked_3836 == nil { c__1927001037__auto____4 = ifn_3837.Invoke_O__O(arg_3838) } else { c__1927001037__auto____4 = linked_3836.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3835, arg_3838) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000345__6 any; var root_3839 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3839, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3841 lang.IFn; if linked_3840 == nil { ifn_3841 = lang.IFn_Cast(root_3839) } else { ifn_3841 = nil }; var arg_3842 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3840 == nil { b__292000345__6 = ifn_3841.Invoke_O__O(arg_3842) } else { b__292000345__6 = linked_3840.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3839, arg_3842) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3980 any = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A_New_O_O_I_O(b__292000345__6, t.F_tset, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3979 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A_fn_class; if fncls__3979 == nil { var fncls__3979d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__3980); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A_fn_class = fncls__3979d; tmp3 = fncls__3979d } else { tmp3 = fncls__3979 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3980, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3981 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3981, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3983 lang.IFn; if linked_3982 == nil { ifn_3983 = lang.IFn_Cast(root_3981) } else { ifn_3983 = nil }; var arg_3984 any; var root_3986 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3986, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3988 lang.IFn; if linked_3987 == nil { ifn_3988 = lang.IFn_Cast(root_3986) } else { ifn_3988 = nil }; var arg_3989 any = b__292000345__6; if linked_3987 == nil { arg_3984 = ifn_3988.Invoke_O__O(arg_3989) } else { arg_3984 = linked_3987.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3986, arg_3989) }; var arg_3985 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000342); var tmp5 any; var root_3990 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3990, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3992 lang.IFn; if linked_3991 == nil { ifn_3992 = lang.IFn_Cast(root_3990) } else { ifn_3992 = nil }; var arg_3993 any = s__292000343__3; if linked_3991 == nil { tmp5 = ifn_3992.Invoke_O__O(arg_3993) } else { tmp5 = linked_3991.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3990, arg_3993) }; arg_3985 = tmp4.Invoke_O__O(tmp5); if linked_3982 == nil { return ifn_3983.Invoke_O_O__O(arg_3984, arg_3985) } else { return linked_3982.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3981, arg_3984, arg_3985) } } else { var root_3994 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3994, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3996 lang.IFn; if linked_3995 == nil { ifn_3996 = lang.IFn_Cast(root_3994) } else { ifn_3996 = nil }; var arg_3997 any; var root_3999 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3999, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4001 lang.IFn; if linked_4000 == nil { ifn_4001 = lang.IFn_Cast(root_3999) } else { ifn_4001 = nil }; var arg_4002 any = b__292000345__6; if linked_4000 == nil { arg_3997 = ifn_4001.Invoke_O__O(arg_4002) } else { arg_3997 = linked_4000.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3999, arg_4002) }; var arg_3998 any; if linked_3995 == nil { return ifn_3996.Invoke_O_O__O(arg_3997, arg_3998) } else { return linked_3995.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3994, arg_3997, arg_3998) } } } else { var vec__292000363__4 any; var root_4003 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4003, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4005 lang.IFn; if linked_4004 == nil { ifn_4005 = lang.IFn_Cast(root_4003) } else { ifn_4005 = nil }; var arg_4006 any = s__292000343__3; if linked_4004 == nil { vec__292000363__4 = ifn_4005.Invoke_O__O(arg_4006) } else { vec__292000363__4 = linked_4004.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4003, arg_4006) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000363__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000363__4, lang.RT_IntCast_J__I_NoInit(1), nil); var i__7 any = A_arbace_j2g_dyncf_A_const_410.Invoke_O__O(facets__6); var tmp6 any
														var and__1927000168__auto____8 any = i__7
														if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_4007 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_4008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4007, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4009 lang.IFn; if linked_4008 == nil { ifn_4009 = lang.IFn_Cast(root_4007) } else { ifn_4009 = nil }; var arg_4010 any = lang.IFn_Cast(t.F_tset).Invoke_O__O(n__5); if linked_4008 == nil { and__1927000168__auto____9 = ifn_4009.Invoke_O__O(arg_4010) } else { and__1927000168__auto____9 = linked_4008.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4007, arg_4010) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp7 int64; var na_4011 any; var or__1927000174__auto____10 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(i__7); if jrt.J2g_Truth(or__1927000174__auto____10) { na_4011 = or__1927000174__auto____10 } else { na_4011 = A_arbace_j2g_dyncf_A_const_365 }; var na_4012 int64 = 1; if jrt.Long_InstanceOf(na_4011) { var n0_4013 int64 = jrt.NN(jrt.Long_Cast(na_4011)).LongValue__J(); var n1_4014 int64 = na_4012; tmp7 = n0_4013 & n1_4014 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_4011, na_4012) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp7)).Ref() } else { tmp6 = and__1927000168__auto____9 } } else { tmp6 = and__1927000168__auto____8 }
//line :491:1
	if jrt.J2g_Truth(tmp6) { var cs__8 any; var root_4016 any = A_arbace_j2g_dyncf_A_const_403.GetRawRoot__O(); var linked_4017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4016, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_4018 lang.IFn


		if linked_4017 == nil { ifn_4018 = lang.IFn_Cast(root_4016) } else { ifn_4018 = nil }; var arg_4019 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_404.GetRawRoot__O()).Invoke__O(); var arg_4020 any; var iter__1927001039__auto____8 any; var fnbody__4133 any = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A_New(); var tmp8 *jrt.Class; var fncls__4132 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A_fn_class
		if fncls__4132 == nil { var fncls__4132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A_fn_class = fncls__4132d; tmp8 = fncls__4132d } else { tmp8 = fncls__4132 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4133, tmp8, nil); arg_4020 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(A_arbace_j2g_dyncf_A_const_374.Invoke_O__O(i__7))
//line :494:1
		if linked_4017 == nil { cs__8 = ifn_4018.Invoke_O_O__O(arg_4019, arg_4020) } else { cs__8 = linked_4017.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_4016, arg_4019, arg_4020) }
//line :491:1
		var tmp9 any; var root_4134 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4134, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4136 lang.IFn









		if linked_4135 == nil { ifn_4136 = lang.IFn_Cast(root_4134) } else { ifn_4136 = nil }; var arg_4137 any = cs__8; if linked_4135 == nil { tmp9 = ifn_4136.Invoke_O__O(arg_4137) } else { tmp9 = linked_4135.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4134, arg_4137) }
//line :491:1
		if jrt.J2g_Truth(tmp9) { var root_4138 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4138, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4140 lang.IFn; if linked_4139 == nil { ifn_4140 = lang.IFn_Cast(root_4138) } else { ifn_4140 = nil }; var arg_4141 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, cs__8); var arg_4142 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__292000342); var tmp11 any; var root_4143 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4143, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4145 lang.IFn; if linked_4144 == nil { ifn_4145 = lang.IFn_Cast(root_4143) } else { ifn_4145 = nil }; var arg_4146 any = s__292000343__3; if linked_4144 == nil { tmp11 = ifn_4145.Invoke_O__O(arg_4146) } else { tmp11 = linked_4144.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4143, arg_4146) }; arg_4142 = tmp10.Invoke_O__O(tmp11); if linked_4139 == nil { return ifn_4140.Invoke_O_O__O(arg_4141, arg_4142) } else { return linked_4139.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4138, arg_4141, arg_4142) } } else { var tmp12 any; var root_4147 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4147, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4149 lang.IFn; if linked_4148 == nil { ifn_4149 = lang.IFn_Cast(root_4147) } else { ifn_4149 = nil }; var arg_4150 any = s__292000343__3; if linked_4148 == nil { tmp12 = ifn_4149.Invoke_O__O(arg_4150) } else { tmp12 = linked_4148.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4147, arg_4150) }; s__292000343__1 = tmp12; continue L1 } } else { var tmp13 any; var root_4151 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4151, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4153 lang.IFn; if linked_4152 == nil { ifn_4153 = lang.IFn_Cast(root_4151) } else { ifn_4153 = nil }; var arg_4154 any = s__292000343__3; if linked_4152 == nil { tmp13 = ifn_4153.Invoke_O__O(arg_4154) } else { tmp13 = linked_4152.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4151, arg_4154) }; s__292000343__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :491:1
func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :491:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A) Ctor_O_O_I_O(c__b__292000345, c__tset any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000345 = c__b__292000345; t.F_tset = c__tset; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :491:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A) Invoke_O__O(self any) any { { var i__292000344__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000344__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000349__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000344__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000349__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000349__2, lang.RT_IntCast_J__I_NoInit(1), nil); var i__5 any = A_arbace_j2g_dyncf_A_const_410.Invoke_O__O(facets__4); var tmp2 any
																var and__1927000168__auto____6 any = i__5
																if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_3843 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_3844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3843, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3845 lang.IFn; if linked_3844 == nil { ifn_3845 = lang.IFn_Cast(root_3843) } else { ifn_3845 = nil }; var arg_3846 any = lang.IFn_Cast(t.F_tset).Invoke_O__O(n__3); if linked_3844 == nil { and__1927000168__auto____7 = ifn_3845.Invoke_O__O(arg_3846) } else { and__1927000168__auto____7 = linked_3844.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3843, arg_3846) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp3 int64; var na_3847 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(i__5); if jrt.J2g_Truth(or__1927000174__auto____8) { na_3847 = or__1927000174__auto____8 } else { na_3847 = A_arbace_j2g_dyncf_A_const_365 }; var na_3848 int64 = 1; if jrt.Long_InstanceOf(na_3847) { var n0_3849 int64 = jrt.NN(jrt.Long_Cast(na_3847)).LongValue__J(); var n1_3850 int64 = na_3848; tmp3 = n0_3849 & n1_3850 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_3847, na_3848) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp3)).Ref() } else { tmp2 = and__1927000168__auto____7 } } else { tmp2 = and__1927000168__auto____6 }
//line :491:1
	if jrt.J2g_Truth(tmp2) { var cs__6 any; var root_3852 any = A_arbace_j2g_dyncf_A_const_403.GetRawRoot__O(); var linked_3853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3852, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3854 lang.IFn


		if linked_3853 == nil { ifn_3854 = lang.IFn_Cast(root_3852) } else { ifn_3854 = nil }; var arg_3855 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_404.GetRawRoot__O()).Invoke__O(); var arg_3856 any; var iter__1927001039__auto____6 any; var fnbody__3969 any = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A_New(); var tmp4 *jrt.Class; var fncls__3968 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A_fn_class
		if fncls__3968 == nil { var fncls__3968d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, nil); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A_fn_class = fncls__3968d; tmp4 = fncls__3968d } else { tmp4 = fncls__3968 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3969, tmp4, nil); arg_3856 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(A_arbace_j2g_dyncf_A_const_374.Invoke_O__O(i__5))
//line :494:1
		if linked_3853 == nil { cs__6 = ifn_3854.Invoke_O_O__O(arg_3855, arg_3856) } else { cs__6 = linked_3853.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3852, arg_3855, arg_3856) }
//line :491:1
		var tmp5 any; var root_3970 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3970, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3972 lang.IFn









		if linked_3971 == nil { ifn_3972 = lang.IFn_Cast(root_3970) } else { ifn_3972 = nil }; var arg_3973 any = cs__6; if linked_3971 == nil { tmp5 = ifn_3972.Invoke_O__O(arg_3973) } else { tmp5 = linked_3971.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3970, arg_3973) }
//line :491:1
		if jrt.J2g_Truth(tmp5) { var root_3974 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3974, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3976 lang.IFn; if linked_3975 == nil { ifn_3976 = lang.IFn_Cast(root_3974) } else { ifn_3976 = nil }; var arg_3977 any = t.F_b__292000345; var arg_3978 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, cs__6); if linked_3975 == nil { ifn_3976.Invoke_O_O__O(arg_3977, arg_3978) } else { linked_3975.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3974, arg_3977, arg_3978) }; i__292000344__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000344__1); continue L1 } else { i__292000344__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000344__1); continue L1 } } else { i__292000344__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000344__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A) Ctor() {}
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A) Invoke_O_O__O(self, s__292000353__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3967 any = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A_New_O_O(self, s__292000353__1); var tmp2 *jrt.Class; var fncls__3966 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A_fn_class; if fncls__3966 == nil { var fncls__3966d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__3967); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A_fn_class = fncls__3966d; tmp2 = fncls__3966d } else { tmp2 = fncls__3966 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3967, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :495:1
func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A{}; t.Ctor_O_O(p0, p1); return t }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A) Ctor_O_O(c__iter__292000352, c__s__292000353 any) { t.F_iter__292000352 = c__iter__292000352; t.F_s__292000353 = c__s__292000353 }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A) Invoke_O__O(self any) any { { var s__292000353__1 any; var t_ any = t.F_s__292000353; t.F_s__292000353 = nil; s__292000353__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3860 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_3861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3860, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3862 lang.IFn; if linked_3861 == nil { ifn_3862 = lang.IFn_Cast(root_3860) } else { ifn_3862 = nil }; var arg_3863 any = s__292000353__1; if linked_3861 == nil { temp__1927000414__auto____2 = ifn_3862.Invoke_O__O(arg_3863) } else { temp__1927000414__auto____2 = linked_3861.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3860, arg_3863) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000353__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3864 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_3865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3864, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3866 lang.IFn; if linked_3865 == nil { ifn_3866 = lang.IFn_Cast(root_3864) } else { ifn_3866 = nil }; var arg_3867 any = s__292000353__3; if linked_3865 == nil { tmp1 = ifn_3866.Invoke_O__O(arg_3867) } else { tmp1 = linked_3865.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3864, arg_3867) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3868 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_3869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3868, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3870 lang.IFn; if linked_3869 == nil { ifn_3870 = lang.IFn_Cast(root_3868) } else { ifn_3870 = nil }; var arg_3871 any = s__292000353__3; if linked_3869 == nil { c__1927001037__auto____4 = ifn_3870.Invoke_O__O(arg_3871) } else { c__1927001037__auto____4 = linked_3869.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3868, arg_3871) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000355__6 any; var root_3872 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_3873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3872, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3874 lang.IFn; if linked_3873 == nil { ifn_3874 = lang.IFn_Cast(root_3872) } else { ifn_3874 = nil }; var arg_3875 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3873 == nil { b__292000355__6 = ifn_3874.Invoke_O__O(arg_3875) } else { b__292000355__6 = linked_3873.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3872, arg_3875) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3904 any = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A_New_O_I_O(b__292000355__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3903 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A_fn_class; if fncls__3903 == nil { var fncls__3903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__3904); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A_fn_class = fncls__3903d; tmp3 = fncls__3903d } else { tmp3 = fncls__3903 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3904, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3905 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3905, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3907 lang.IFn; if linked_3906 == nil { ifn_3907 = lang.IFn_Cast(root_3905) } else { ifn_3907 = nil }; var arg_3908 any; var root_3910 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3910, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3912 lang.IFn; if linked_3911 == nil { ifn_3912 = lang.IFn_Cast(root_3910) } else { ifn_3912 = nil }; var arg_3913 any = b__292000355__6; if linked_3911 == nil { arg_3908 = ifn_3912.Invoke_O__O(arg_3913) } else { arg_3908 = linked_3911.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3910, arg_3913) }; var arg_3909 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000352); var tmp5 any; var root_3914 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_3915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3914, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3916 lang.IFn; if linked_3915 == nil { ifn_3916 = lang.IFn_Cast(root_3914) } else { ifn_3916 = nil }; var arg_3917 any = s__292000353__3; if linked_3915 == nil { tmp5 = ifn_3916.Invoke_O__O(arg_3917) } else { tmp5 = linked_3915.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3914, arg_3917) }; arg_3909 = tmp4.Invoke_O__O(tmp5); if linked_3906 == nil { return ifn_3907.Invoke_O_O__O(arg_3908, arg_3909) } else { return linked_3906.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3905, arg_3908, arg_3909) } } else { var root_3918 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_3919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3918, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3920 lang.IFn; if linked_3919 == nil { ifn_3920 = lang.IFn_Cast(root_3918) } else { ifn_3920 = nil }; var arg_3921 any; var root_3923 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_3924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3923, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3925 lang.IFn; if linked_3924 == nil { ifn_3925 = lang.IFn_Cast(root_3923) } else { ifn_3925 = nil }; var arg_3926 any = b__292000355__6; if linked_3924 == nil { arg_3921 = ifn_3925.Invoke_O__O(arg_3926) } else { arg_3921 = linked_3924.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3923, arg_3926) }; var arg_3922 any; if linked_3919 == nil { return ifn_3920.Invoke_O_O__O(arg_3921, arg_3922) } else { return linked_3919.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3918, arg_3921, arg_3922) } } } else { var f__4 any; var root_3927 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_3928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3927, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3929 lang.IFn; if linked_3928 == nil { ifn_3929 = lang.IFn_Cast(root_3927) } else { ifn_3929 = nil }; var arg_3930 any = s__292000353__3; if linked_3928 == nil { f__4 = ifn_3929.Invoke_O__O(arg_3930) } else { f__4 = linked_3928.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3927, arg_3930) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_365 }
//line :495:1
	var v__6 any = A_arbace_j2g_dyncf_A_const_411.Invoke_O__O(f__4); var tmp6 any; var and__1927000168__auto____7 bool; var tmp7 int64
	var na_3931 any = fl__5; var na_3932 int64 = 24
	if jrt.Long_InstanceOf(na_3931) { var n0_3933 int64 = jrt.NN(jrt.Long_Cast(na_3931)).LongValue__J(); var n1_3934 int64 = na_3932; tmp7 = n0_3933 & n1_3934 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_3931, na_3932) }; and__1927000168__auto____7 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp8 int64; var na_3936 any = fl__5; var na_3937 int64 = 5; if jrt.Long_InstanceOf(na_3936) { var n0_3938 int64 = jrt.NN(jrt.Long_Cast(na_3936)).LongValue__J(); var n1_3939 int64 = na_3937; tmp8 = n0_3938 & n1_3939 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_3936, na_3937) }; and__1927000168__auto____8 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var or__1927000174__auto____9 any; var root_3941 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3941, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3943 lang.IFn
		if linked_3942 == nil { ifn_3943 = lang.IFn_Cast(root_3941) } else { ifn_3943 = nil }; var arg_3944 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_3942 == nil { or__1927000174__auto____9 = ifn_3943.Invoke_O__O(arg_3944) } else { or__1927000174__auto____9 = linked_3942.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3941, arg_3944) }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____9 = or__1927000174__auto____9 } else { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_405.GetRawRoot__O())).Ref() }
//line :497:1
		if jrt.J2g_Truth(and__1927000168__auto____9) {

			var root_3945 any = A_arbace_j2g_dyncf_A_const_407.GetRawRoot__O(); var linked_3946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3945, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3947 lang.IFn; if linked_3946 == nil { ifn_3947 = lang.IFn_Cast(root_3945) } else { ifn_3947 = nil }; var arg_3948 any = v__6; if linked_3946 == nil { tmp6 = ifn_3947.Invoke_O__O(arg_3948) } else { tmp6 = linked_3946.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3945, arg_3948) } } else {
//line :497:1
				tmp6 = and__1927000168__auto____9 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :495:1
	if jrt.J2g_Truth(tmp6) { var root_3949 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_3950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3949, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3951 lang.IFn; if linked_3950 == nil { ifn_3951 = lang.IFn_Cast(root_3949) } else { ifn_3951 = nil }; var arg_3952 any; var tmp9 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp10 any; var tmp11 any; var root_3954 any = A_arbace_j2g_dyncf_A_const_408.GetRawRoot__O(); var linked_3955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3954, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_3956 lang.IFn




		if linked_3955 == nil { ifn_3956 = lang.IFn_Cast(root_3954) } else { ifn_3956 = nil }; var arg_3957 any = v__6; if linked_3955 == nil { tmp11 = ifn_3956.Invoke_O__O(arg_3957) } else { tmp11 = linked_3955.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_3954, arg_3957) }; if jrt.J2g_Truth(tmp11) { tmp10 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp10 = v__6 }
//line :495:1
		arg_3952 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10); var arg_3953 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__292000352); var tmp13 any; var root_3958 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3958, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3960 lang.IFn; if linked_3959 == nil { ifn_3960 = lang.IFn_Cast(root_3958) } else { ifn_3960 = nil }; var arg_3961 any = s__292000353__3; if linked_3959 == nil { tmp13 = ifn_3960.Invoke_O__O(arg_3961) } else { tmp13 = linked_3959.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3958, arg_3961) }; arg_3953 = tmp12.Invoke_O__O(tmp13); if linked_3950 == nil { return ifn_3951.Invoke_O_O__O(arg_3952, arg_3953) } else { return linked_3950.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3949, arg_3952, arg_3953) } } else { var tmp14 any; var root_3962 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_3963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3962, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3964 lang.IFn; if linked_3963 == nil { ifn_3964 = lang.IFn_Cast(root_3962) } else { ifn_3964 = nil }; var arg_3965 any = s__292000353__3; if linked_3963 == nil { tmp14 = ifn_3964.Invoke_O__O(arg_3965) } else { tmp14 = linked_3963.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3962, arg_3965) }; s__292000353__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :495:1
func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A) Ctor_O_I_O(c__b__292000355 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000355 = c__b__292000355; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A) Invoke_O__O(self any) any { { var i__292000354__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000354__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000354__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_365 }
//line :495:1
	var v__4 any = A_arbace_j2g_dyncf_A_const_411.Invoke_O__O(f__2); var tmp2 any; var and__1927000168__auto____5 bool; var tmp3 int64
	var na_3876 any = fl__3; var na_3877 int64 = 24
	if jrt.Long_InstanceOf(na_3876) { var n0_3878 int64 = jrt.NN(jrt.Long_Cast(na_3876)).LongValue__J(); var n1_3879 int64 = na_3877; tmp3 = n0_3878 & n1_3879 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_3876, na_3877) }; and__1927000168__auto____5 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool; var tmp4 int64; var na_3881 any = fl__3; var na_3882 int64 = 5; if jrt.Long_InstanceOf(na_3881) { var n0_3883 int64 = jrt.NN(jrt.Long_Cast(na_3881)).LongValue__J(); var n1_3884 int64 = na_3882; tmp4 = n0_3883 & n1_3884 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_3881, na_3882) }; and__1927000168__auto____6 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____6 { var and__1927000168__auto____7 any; var or__1927000174__auto____7 any; var root_3886 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_3887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3886, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_3888 lang.IFn
		if linked_3887 == nil { ifn_3888 = lang.IFn_Cast(root_3886) } else { ifn_3888 = nil }; var arg_3889 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_3887 == nil { or__1927000174__auto____7 = ifn_3888.Invoke_O__O(arg_3889) } else { or__1927000174__auto____7 = linked_3887.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_3886, arg_3889) }; if jrt.J2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7 = or__1927000174__auto____7 } else { and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_405.GetRawRoot__O())).Ref() }
//line :497:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {

			var root_3890 any = A_arbace_j2g_dyncf_A_const_407.GetRawRoot__O(); var linked_3891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3890, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3892 lang.IFn; if linked_3891 == nil { ifn_3892 = lang.IFn_Cast(root_3890) } else { ifn_3892 = nil }; var arg_3893 any = v__4; if linked_3891 == nil { tmp2 = ifn_3892.Invoke_O__O(arg_3893) } else { tmp2 = linked_3891.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3890, arg_3893) } } else {
//line :497:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :495:1
	if jrt.J2g_Truth(tmp2) { var root_3894 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_3895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3894, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3896 lang.IFn; if linked_3895 == nil { ifn_3896 = lang.IFn_Cast(root_3894) } else { ifn_3896 = nil }; var arg_3897 any = t.F_b__292000355; var arg_3898 any; var tmp5 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp6 any; var tmp7 any; var root_3899 any = A_arbace_j2g_dyncf_A_const_408.GetRawRoot__O(); var linked_3900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3899, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_3901 lang.IFn




		if linked_3900 == nil { ifn_3901 = lang.IFn_Cast(root_3899) } else { ifn_3901 = nil }; var arg_3902 any = v__4; if linked_3900 == nil { tmp7 = ifn_3901.Invoke_O__O(arg_3902) } else { tmp7 = linked_3900.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_3899, arg_3902) }; if jrt.J2g_Truth(tmp7) { tmp6 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp6 = v__4 }
//line :495:1
		arg_3898 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6); if linked_3895 == nil { ifn_3896.Invoke_O_O__O(arg_3897, arg_3898) } else { linked_3895.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3894, arg_3897, arg_3898) }; i__292000354__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000354__1); continue L1 } else { i__292000354__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000354__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :495:1
func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A) Ctor() {}
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A) Invoke_O_O__O(self, s__292000367__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4131 any = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A_New_O_O(self, s__292000367__1); var tmp2 *jrt.Class; var fncls__4130 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A_fn_class; if fncls__4130 == nil { var fncls__4130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__4131); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A_fn_class = fncls__4130d; tmp2 = fncls__4130d } else { tmp2 = fncls__4130 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4131, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :495:1
func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A{}; t.Ctor_O_O(p0, p1); return t }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A) Ctor_O_O(c__iter__292000366, c__s__292000367 any) { t.F_iter__292000366 = c__iter__292000366; t.F_s__292000367 = c__s__292000367 }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A) Invoke_O__O(self any) any { { var s__292000367__1 any; var t_ any = t.F_s__292000367; t.F_s__292000367 = nil; s__292000367__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4024 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4024, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4026 lang.IFn; if linked_4025 == nil { ifn_4026 = lang.IFn_Cast(root_4024) } else { ifn_4026 = nil }; var arg_4027 any = s__292000367__1; if linked_4025 == nil { temp__1927000414__auto____2 = ifn_4026.Invoke_O__O(arg_4027) } else { temp__1927000414__auto____2 = linked_4025.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4024, arg_4027) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000367__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4028 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4028, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4030 lang.IFn; if linked_4029 == nil { ifn_4030 = lang.IFn_Cast(root_4028) } else { ifn_4030 = nil }; var arg_4031 any = s__292000367__3; if linked_4029 == nil { tmp1 = ifn_4030.Invoke_O__O(arg_4031) } else { tmp1 = linked_4029.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4028, arg_4031) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4032 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4032, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4034 lang.IFn; if linked_4033 == nil { ifn_4034 = lang.IFn_Cast(root_4032) } else { ifn_4034 = nil }; var arg_4035 any = s__292000367__3; if linked_4033 == nil { c__1927001037__auto____4 = ifn_4034.Invoke_O__O(arg_4035) } else { c__1927001037__auto____4 = linked_4033.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4032, arg_4035) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000369__6 any; var root_4036 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4036, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4038 lang.IFn; if linked_4037 == nil { ifn_4038 = lang.IFn_Cast(root_4036) } else { ifn_4038 = nil }; var arg_4039 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4037 == nil { b__292000369__6 = ifn_4038.Invoke_O__O(arg_4039) } else { b__292000369__6 = linked_4037.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4036, arg_4039) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4068 any = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A_New_O_I_O(b__292000369__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4067 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A_fn_class; if fncls__4067 == nil { var fncls__4067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__4068); A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A_fn_class = fncls__4067d; tmp3 = fncls__4067d } else { tmp3 = fncls__4067 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4068, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4069 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4069, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4071 lang.IFn; if linked_4070 == nil { ifn_4071 = lang.IFn_Cast(root_4069) } else { ifn_4071 = nil }; var arg_4072 any; var root_4074 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4074, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4076 lang.IFn; if linked_4075 == nil { ifn_4076 = lang.IFn_Cast(root_4074) } else { ifn_4076 = nil }; var arg_4077 any = b__292000369__6; if linked_4075 == nil { arg_4072 = ifn_4076.Invoke_O__O(arg_4077) } else { arg_4072 = linked_4075.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4074, arg_4077) }; var arg_4073 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000366); var tmp5 any; var root_4078 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4078, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4080 lang.IFn; if linked_4079 == nil { ifn_4080 = lang.IFn_Cast(root_4078) } else { ifn_4080 = nil }; var arg_4081 any = s__292000367__3; if linked_4079 == nil { tmp5 = ifn_4080.Invoke_O__O(arg_4081) } else { tmp5 = linked_4079.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4078, arg_4081) }; arg_4073 = tmp4.Invoke_O__O(tmp5); if linked_4070 == nil { return ifn_4071.Invoke_O_O__O(arg_4072, arg_4073) } else { return linked_4070.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4069, arg_4072, arg_4073) } } else { var root_4082 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4082, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4084 lang.IFn; if linked_4083 == nil { ifn_4084 = lang.IFn_Cast(root_4082) } else { ifn_4084 = nil }; var arg_4085 any; var root_4087 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4087, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4089 lang.IFn; if linked_4088 == nil { ifn_4089 = lang.IFn_Cast(root_4087) } else { ifn_4089 = nil }; var arg_4090 any = b__292000369__6; if linked_4088 == nil { arg_4085 = ifn_4089.Invoke_O__O(arg_4090) } else { arg_4085 = linked_4088.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4087, arg_4090) }; var arg_4086 any; if linked_4083 == nil { return ifn_4084.Invoke_O_O__O(arg_4085, arg_4086) } else { return linked_4083.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4082, arg_4085, arg_4086) } } } else { var f__4 any; var root_4091 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4091, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4093 lang.IFn; if linked_4092 == nil { ifn_4093 = lang.IFn_Cast(root_4091) } else { ifn_4093 = nil }; var arg_4094 any = s__292000367__3; if linked_4092 == nil { f__4 = ifn_4093.Invoke_O__O(arg_4094) } else { f__4 = linked_4092.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4091, arg_4094) }; var fl__5 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { fl__5 = or__1927000174__auto____5 } else { fl__5 = A_arbace_j2g_dyncf_A_const_365 }
//line :495:1
	var v__6 any = A_arbace_j2g_dyncf_A_const_411.Invoke_O__O(f__4); var tmp6 any; var and__1927000168__auto____7 bool; var tmp7 int64
	var na_4095 any = fl__5; var na_4096 int64 = 24
	if jrt.Long_InstanceOf(na_4095) { var n0_4097 int64 = jrt.NN(jrt.Long_Cast(na_4095)).LongValue__J(); var n1_4098 int64 = na_4096; tmp7 = n0_4097 & n1_4098 } else { tmp7 = lang.Numbers_And_O_J__J_NoInit(na_4095, na_4096) }; and__1927000168__auto____7 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp7); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp8 int64; var na_4100 any = fl__5; var na_4101 int64 = 5; if jrt.Long_InstanceOf(na_4100) { var n0_4102 int64 = jrt.NN(jrt.Long_Cast(na_4100)).LongValue__J(); var n1_4103 int64 = na_4101; tmp8 = n0_4102 & n1_4103 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_4100, na_4101) }; and__1927000168__auto____8 = lang.Numbers_IsPos_J__Z_NoInit(tmp8); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var or__1927000174__auto____9 any; var root_4105 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_4106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4105, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_4107 lang.IFn
		if linked_4106 == nil { ifn_4107 = lang.IFn_Cast(root_4105) } else { ifn_4107 = nil }; var arg_4108 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4); if linked_4106 == nil { or__1927000174__auto____9 = ifn_4107.Invoke_O__O(arg_4108) } else { or__1927000174__auto____9 = linked_4106.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_4105, arg_4108) }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____9 = or__1927000174__auto____9 } else { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__4), A_arbace_j2g_dyncf_A_const_405.GetRawRoot__O())).Ref() }
//line :497:1
		if jrt.J2g_Truth(and__1927000168__auto____9) {

			var root_4109 any = A_arbace_j2g_dyncf_A_const_407.GetRawRoot__O(); var linked_4110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4109, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_4111 lang.IFn; if linked_4110 == nil { ifn_4111 = lang.IFn_Cast(root_4109) } else { ifn_4111 = nil }; var arg_4112 any = v__6; if linked_4110 == nil { tmp6 = ifn_4111.Invoke_O__O(arg_4112) } else { tmp6 = linked_4110.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_4109, arg_4112) } } else {
//line :497:1
				tmp6 = and__1927000168__auto____9 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :495:1
	if jrt.J2g_Truth(tmp6) { var root_4113 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4113, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4115 lang.IFn; if linked_4114 == nil { ifn_4115 = lang.IFn_Cast(root_4113) } else { ifn_4115 = nil }; var arg_4116 any; var tmp9 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__4); var tmp10 any; var tmp11 any; var root_4118 any = A_arbace_j2g_dyncf_A_const_408.GetRawRoot__O(); var linked_4119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4118, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_4120 lang.IFn




		if linked_4119 == nil { ifn_4120 = lang.IFn_Cast(root_4118) } else { ifn_4120 = nil }; var arg_4121 any = v__6; if linked_4119 == nil { tmp11 = ifn_4120.Invoke_O__O(arg_4121) } else { tmp11 = linked_4119.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_4118, arg_4121) }; if jrt.J2g_Truth(tmp11) { tmp10 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__6)).Ref() } else { tmp10 = v__6 }
//line :495:1
		arg_4116 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10); var arg_4117 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__292000366); var tmp13 any; var root_4122 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4122, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4124 lang.IFn; if linked_4123 == nil { ifn_4124 = lang.IFn_Cast(root_4122) } else { ifn_4124 = nil }; var arg_4125 any = s__292000367__3; if linked_4123 == nil { tmp13 = ifn_4124.Invoke_O__O(arg_4125) } else { tmp13 = linked_4123.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4122, arg_4125) }; arg_4117 = tmp12.Invoke_O__O(tmp13); if linked_4114 == nil { return ifn_4115.Invoke_O_O__O(arg_4116, arg_4117) } else { return linked_4114.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4113, arg_4116, arg_4117) } } else { var tmp14 any; var root_4126 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4126, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4128 lang.IFn; if linked_4127 == nil { ifn_4128 = lang.IFn_Cast(root_4126) } else { ifn_4128 = nil }; var arg_4129 any = s__292000367__3; if linked_4127 == nil { tmp14 = ifn_4128.Invoke_O__O(arg_4129) } else { tmp14 = linked_4127.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4126, arg_4129) }; s__292000367__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :495:1
func A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A) Ctor_O_I_O(c__b__292000369 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000369 = c__b__292000369; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :495:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A) Invoke_O__O(self any) any { { var i__292000368__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000368__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000368__1)); var fl__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_364.Invoke_O__O(f__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { fl__3 = or__1927000174__auto____3 } else { fl__3 = A_arbace_j2g_dyncf_A_const_365 }
//line :495:1
	var v__4 any = A_arbace_j2g_dyncf_A_const_411.Invoke_O__O(f__2); var tmp2 any; var and__1927000168__auto____5 bool; var tmp3 int64
	var na_4040 any = fl__3; var na_4041 int64 = 24
	if jrt.Long_InstanceOf(na_4040) { var n0_4042 int64 = jrt.NN(jrt.Long_Cast(na_4040)).LongValue__J(); var n1_4043 int64 = na_4041; tmp3 = n0_4042 & n1_4043 } else { tmp3 = lang.Numbers_And_O_J__J_NoInit(na_4040, na_4041) }; and__1927000168__auto____5 = lang.Util_Equiv_J_J__Z_NoInit(24, tmp3); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool; var tmp4 int64; var na_4045 any = fl__3; var na_4046 int64 = 5; if jrt.Long_InstanceOf(na_4045) { var n0_4047 int64 = jrt.NN(jrt.Long_Cast(na_4045)).LongValue__J(); var n1_4048 int64 = na_4046; tmp4 = n0_4047 & n1_4048 } else { tmp4 = lang.Numbers_And_O_J__J_NoInit(na_4045, na_4046) }; and__1927000168__auto____6 = lang.Numbers_IsPos_J__Z_NoInit(tmp4); if and__1927000168__auto____6 { var and__1927000168__auto____7 any; var or__1927000174__auto____7 any; var root_4050 any = A_arbace_j2g_dyncf_A_const_26.GetRawRoot__O(); var linked_4051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4050, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_4052 lang.IFn
		if linked_4051 == nil { ifn_4052 = lang.IFn_Cast(root_4050) } else { ifn_4052 = nil }; var arg_4053 any = A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2); if linked_4051 == nil { or__1927000174__auto____7 = ifn_4052.Invoke_O__O(arg_4053) } else { or__1927000174__auto____7 = linked_4051.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_4050, arg_4053) }; if jrt.J2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7 = or__1927000174__auto____7 } else { and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_dyncf_A_const_76.Invoke_O__O(f__2), A_arbace_j2g_dyncf_A_const_405.GetRawRoot__O())).Ref() }
//line :497:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {

			var root_4054 any = A_arbace_j2g_dyncf_A_const_407.GetRawRoot__O(); var linked_4055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4054, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_4056 lang.IFn; if linked_4055 == nil { ifn_4056 = lang.IFn_Cast(root_4054) } else { ifn_4056 = nil }; var arg_4057 any = v__4; if linked_4055 == nil { tmp2 = ifn_4056.Invoke_O__O(arg_4057) } else { tmp2 = linked_4055.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_4054, arg_4057) } } else {
//line :497:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :495:1
	if jrt.J2g_Truth(tmp2) { var root_4058 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4058, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4060 lang.IFn; if linked_4059 == nil { ifn_4060 = lang.IFn_Cast(root_4058) } else { ifn_4060 = nil }; var arg_4061 any = t.F_b__292000369; var arg_4062 any; var tmp5 any = A_arbace_j2g_dyncf_A_const_72.Invoke_O__O(f__2); var tmp6 any; var tmp7 any; var root_4063 any = A_arbace_j2g_dyncf_A_const_408.GetRawRoot__O(); var linked_4064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4063, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_4065 lang.IFn




		if linked_4064 == nil { ifn_4065 = lang.IFn_Cast(root_4063) } else { ifn_4065 = nil }; var arg_4066 any = v__4; if linked_4064 == nil { tmp7 = ifn_4065.Invoke_O__O(arg_4066) } else { tmp7 = linked_4064.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_4063, arg_4066) }; if jrt.J2g_Truth(tmp7) { tmp6 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__4)).Ref() } else { tmp6 = v__4 }
//line :495:1
		arg_4062 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6); if linked_4059 == nil { ifn_4060.Invoke_O_O__O(arg_4061, arg_4062) } else { linked_4059.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4058, arg_4061, arg_4062) }; i__292000368__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000368__1); continue L1 } else { i__292000368__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000368__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A{}; t.Ctor(); return t }
//line :513:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A) Ctor() {}
//line :513:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A) Invoke_O_O__O(self, s__292000379__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4253 any = A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A_New_O_O(self, s__292000379__1); var tmp2 *jrt.Class; var fncls__4252 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A_fn_class; if fncls__4252 == nil { var fncls__4252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__4253); A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A_fn_class = fncls__4252d; tmp2 = fncls__4252d } else { tmp2 = fncls__4252 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4253, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :513:1
func A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A{}; t.Ctor_O_O(p0, p1); return t }
//line :513:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A) Ctor_O_O(c__iter__292000378, c__s__292000379 any) { t.F_iter__292000378 = c__iter__292000378; t.F_s__292000379 = c__s__292000379 }
//line :513:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A) Invoke_O__O(self any) any { { var s__292000379__1 any; var t_ any = t.F_s__292000379; t.F_s__292000379 = nil; s__292000379__1 = t_; for { var temp__1927000414__auto____2 any; var root_4178 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4178, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4180 lang.IFn; if linked_4179 == nil { ifn_4180 = lang.IFn_Cast(root_4178) } else { ifn_4180 = nil }; var arg_4181 any = s__292000379__1; if linked_4179 == nil { temp__1927000414__auto____2 = ifn_4180.Invoke_O__O(arg_4181) } else { temp__1927000414__auto____2 = linked_4179.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4178, arg_4181) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000379__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4182 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4182, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4184 lang.IFn; if linked_4183 == nil { ifn_4184 = lang.IFn_Cast(root_4182) } else { ifn_4184 = nil }; var arg_4185 any = s__292000379__3; if linked_4183 == nil { tmp1 = ifn_4184.Invoke_O__O(arg_4185) } else { tmp1 = linked_4183.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4182, arg_4185) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4186 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4186, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4188 lang.IFn; if linked_4187 == nil { ifn_4188 = lang.IFn_Cast(root_4186) } else { ifn_4188 = nil }; var arg_4189 any = s__292000379__3; if linked_4187 == nil { c__1927001037__auto____4 = ifn_4188.Invoke_O__O(arg_4189) } else { c__1927001037__auto____4 = linked_4187.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4186, arg_4189) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000381__6 any; var root_4190 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4190, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4192 lang.IFn; if linked_4191 == nil { ifn_4192 = lang.IFn_Cast(root_4190) } else { ifn_4192 = nil }; var arg_4193 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4191 == nil { b__292000381__6 = ifn_4192.Invoke_O__O(arg_4193) } else { b__292000381__6 = linked_4191.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4190, arg_4193) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4208 any = A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__292000381__6); var tmp3 *jrt.Class; var fncls__4207 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A_fn_class; if fncls__4207 == nil { var fncls__4207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__4208); A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A_fn_class = fncls__4207d; tmp3 = fncls__4207d } else { tmp3 = fncls__4207 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4208, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4209 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4209, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4211 lang.IFn; if linked_4210 == nil { ifn_4211 = lang.IFn_Cast(root_4209) } else { ifn_4211 = nil }; var arg_4212 any; var root_4214 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4214, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4216 lang.IFn; if linked_4215 == nil { ifn_4216 = lang.IFn_Cast(root_4214) } else { ifn_4216 = nil }; var arg_4217 any = b__292000381__6; if linked_4215 == nil { arg_4212 = ifn_4216.Invoke_O__O(arg_4217) } else { arg_4212 = linked_4215.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4214, arg_4217) }; var arg_4213 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000378); var tmp5 any; var root_4218 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4218, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4220 lang.IFn; if linked_4219 == nil { ifn_4220 = lang.IFn_Cast(root_4218) } else { ifn_4220 = nil }; var arg_4221 any = s__292000379__3; if linked_4219 == nil { tmp5 = ifn_4220.Invoke_O__O(arg_4221) } else { tmp5 = linked_4219.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4218, arg_4221) }; arg_4213 = tmp4.Invoke_O__O(tmp5); if linked_4210 == nil { return ifn_4211.Invoke_O_O__O(arg_4212, arg_4213) } else { return linked_4210.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4209, arg_4212, arg_4213) } } else { var root_4222 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4222, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4224 lang.IFn; if linked_4223 == nil { ifn_4224 = lang.IFn_Cast(root_4222) } else { ifn_4224 = nil }; var arg_4225 any; var root_4227 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4227, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4229 lang.IFn; if linked_4228 == nil { ifn_4229 = lang.IFn_Cast(root_4227) } else { ifn_4229 = nil }; var arg_4230 any = b__292000381__6; if linked_4228 == nil { arg_4225 = ifn_4229.Invoke_O__O(arg_4230) } else { arg_4225 = linked_4228.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4227, arg_4230) }; var arg_4226 any; if linked_4223 == nil { return ifn_4224.Invoke_O_O__O(arg_4225, arg_4226) } else { return linked_4223.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4222, arg_4225, arg_4226) } } } else { var vec__292000389__4 any; var root_4231 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4231, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4233 lang.IFn; if linked_4232 == nil { ifn_4233 = lang.IFn_Cast(root_4231) } else { ifn_4233 = nil }; var arg_4234 any = s__292000379__3; if linked_4232 == nil { vec__292000389__4 = ifn_4233.Invoke_O__O(arg_4234) } else { vec__292000389__4 = linked_4232.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4231, arg_4234) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000389__4, lang.RT_IntCast_J__I_NoInit(0), nil); var g__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000389__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4235 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4235, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4237 lang.IFn; if linked_4236 == nil { ifn_4237 = lang.IFn_Cast(root_4235) } else { ifn_4237 = nil }; var arg_4238 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_90, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(g__6))).Ref(); var arg_4239 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000378); var tmp7 any; var root_4248 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4248, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4250 lang.IFn; if linked_4249 == nil { ifn_4250 = lang.IFn_Cast(root_4248) } else { ifn_4250 = nil }; var arg_4251 any = s__292000379__3; if linked_4249 == nil { tmp7 = ifn_4250.Invoke_O__O(arg_4251) } else { tmp7 = linked_4249.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4248, arg_4251) }; arg_4239 = tmp6.Invoke_O__O(tmp7); if linked_4236 == nil { return ifn_4237.Invoke_O_O__O(arg_4238, arg_4239) } else { return linked_4236.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4235, arg_4238, arg_4239) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :513:1
func A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :513:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__292000381 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__292000381 = c__b__292000381 }
//line :513:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A) Invoke_O__O(self any) any { { var i__292000380__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000380__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000385__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000380__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000385__2, lang.RT_IntCast_J__I_NoInit(0), nil); var g__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000385__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4194 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4194, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4196 lang.IFn; if linked_4195 == nil { ifn_4196 = lang.IFn_Cast(root_4194) } else { ifn_4196 = nil }; var arg_4197 any = t.F_b__292000381; var arg_4198 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_90, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(g__4))).Ref(); if linked_4195 == nil { ifn_4196.Invoke_O_O__O(arg_4197, arg_4198) } else { linked_4195.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4194, arg_4197, arg_4198) }; i__292000380__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000380__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A) Ctor() {}
//line :515:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A) Invoke_O_O__O(self, s__292000395__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4346 any = A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A_New_O_O(self, s__292000395__1); var tmp2 *jrt.Class; var fncls__4345 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A_fn_class; if fncls__4345 == nil { var fncls__4345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__4346); A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A_fn_class = fncls__4345d; tmp2 = fncls__4345d } else { tmp2 = fncls__4345 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4346, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :515:1
func A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A{}; t.Ctor_O_O(p0, p1); return t }
//line :515:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A) Ctor_O_O(c__iter__292000394, c__s__292000395 any) { t.F_iter__292000394 = c__iter__292000394; t.F_s__292000395 = c__s__292000395 }
//line :515:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A) Invoke_O__O(self any) any { { var s__292000395__1 any; var t_ any = t.F_s__292000395; t.F_s__292000395 = nil; s__292000395__1 = t_; for { var temp__1927000414__auto____2 any; var root_4271 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4271, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4273 lang.IFn; if linked_4272 == nil { ifn_4273 = lang.IFn_Cast(root_4271) } else { ifn_4273 = nil }; var arg_4274 any = s__292000395__1; if linked_4272 == nil { temp__1927000414__auto____2 = ifn_4273.Invoke_O__O(arg_4274) } else { temp__1927000414__auto____2 = linked_4272.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4271, arg_4274) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000395__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4275 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4275, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4277 lang.IFn; if linked_4276 == nil { ifn_4277 = lang.IFn_Cast(root_4275) } else { ifn_4277 = nil }; var arg_4278 any = s__292000395__3; if linked_4276 == nil { tmp1 = ifn_4277.Invoke_O__O(arg_4278) } else { tmp1 = linked_4276.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4275, arg_4278) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4279 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4279, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4281 lang.IFn; if linked_4280 == nil { ifn_4281 = lang.IFn_Cast(root_4279) } else { ifn_4281 = nil }; var arg_4282 any = s__292000395__3; if linked_4280 == nil { c__1927001037__auto____4 = ifn_4281.Invoke_O__O(arg_4282) } else { c__1927001037__auto____4 = linked_4280.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4279, arg_4282) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000397__6 any; var root_4283 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4283, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4285 lang.IFn; if linked_4284 == nil { ifn_4285 = lang.IFn_Cast(root_4283) } else { ifn_4285 = nil }; var arg_4286 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4284 == nil { b__292000397__6 = ifn_4285.Invoke_O__O(arg_4286) } else { b__292000397__6 = linked_4284.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4283, arg_4286) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4301 any = A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A_New_O_I_O(b__292000397__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4300 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A_fn_class; if fncls__4300 == nil { var fncls__4300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__4301); A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A_fn_class = fncls__4300d; tmp3 = fncls__4300d } else { tmp3 = fncls__4300 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4301, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4302 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4302, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4304 lang.IFn; if linked_4303 == nil { ifn_4304 = lang.IFn_Cast(root_4302) } else { ifn_4304 = nil }; var arg_4305 any; var root_4307 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4307, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4309 lang.IFn; if linked_4308 == nil { ifn_4309 = lang.IFn_Cast(root_4307) } else { ifn_4309 = nil }; var arg_4310 any = b__292000397__6; if linked_4308 == nil { arg_4305 = ifn_4309.Invoke_O__O(arg_4310) } else { arg_4305 = linked_4308.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4307, arg_4310) }; var arg_4306 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000394); var tmp5 any; var root_4311 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4311, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4313 lang.IFn; if linked_4312 == nil { ifn_4313 = lang.IFn_Cast(root_4311) } else { ifn_4313 = nil }; var arg_4314 any = s__292000395__3; if linked_4312 == nil { tmp5 = ifn_4313.Invoke_O__O(arg_4314) } else { tmp5 = linked_4312.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4311, arg_4314) }; arg_4306 = tmp4.Invoke_O__O(tmp5); if linked_4303 == nil { return ifn_4304.Invoke_O_O__O(arg_4305, arg_4306) } else { return linked_4303.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4302, arg_4305, arg_4306) } } else { var root_4315 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4315, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4317 lang.IFn; if linked_4316 == nil { ifn_4317 = lang.IFn_Cast(root_4315) } else { ifn_4317 = nil }; var arg_4318 any; var root_4320 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4320, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4322 lang.IFn; if linked_4321 == nil { ifn_4322 = lang.IFn_Cast(root_4320) } else { ifn_4322 = nil }; var arg_4323 any = b__292000397__6; if linked_4321 == nil { arg_4318 = ifn_4322.Invoke_O__O(arg_4323) } else { arg_4318 = linked_4321.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4320, arg_4323) }; var arg_4319 any; if linked_4316 == nil { return ifn_4317.Invoke_O_O__O(arg_4318, arg_4319) } else { return linked_4316.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4315, arg_4318, arg_4319) } } } else { var vec__292000405__4 any; var root_4324 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4324, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4326 lang.IFn; if linked_4325 == nil { ifn_4326 = lang.IFn_Cast(root_4324) } else { ifn_4326 = nil }; var arg_4327 any = s__292000395__3; if linked_4325 == nil { vec__292000405__4 = ifn_4326.Invoke_O__O(arg_4327) } else { vec__292000405__4 = linked_4325.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4324, arg_4327) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000405__4, lang.RT_IntCast_J__I_NoInit(0), nil); var cs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000405__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4328 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4328, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4330 lang.IFn; if linked_4329 == nil { ifn_4330 = lang.IFn_Cast(root_4328) } else { ifn_4330 = nil }; var arg_4331 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_90, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(cs__6))).Ref(); var arg_4332 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000394); var tmp7 any; var root_4341 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4341, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4343 lang.IFn; if linked_4342 == nil { ifn_4343 = lang.IFn_Cast(root_4341) } else { ifn_4343 = nil }; var arg_4344 any = s__292000395__3; if linked_4342 == nil { tmp7 = ifn_4343.Invoke_O__O(arg_4344) } else { tmp7 = linked_4342.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4341, arg_4344) }; arg_4332 = tmp6.Invoke_O__O(tmp7); if linked_4329 == nil { return ifn_4330.Invoke_O_O__O(arg_4331, arg_4332) } else { return linked_4329.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4328, arg_4331, arg_4332) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :515:1
func A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :515:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A) Ctor_O_I_O(c__b__292000397 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000397 = c__b__292000397; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :515:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A) Invoke_O__O(self any) any { { var i__292000396__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000396__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000401__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000396__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000401__2, lang.RT_IntCast_J__I_NoInit(0), nil); var cs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000401__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4287 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4287, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4289 lang.IFn; if linked_4288 == nil { ifn_4289 = lang.IFn_Cast(root_4287) } else { ifn_4289 = nil }; var arg_4290 any = t.F_b__292000397; var arg_4291 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_90, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(cs__4))).Ref(); if linked_4288 == nil { ifn_4289.Invoke_O_O__O(arg_4290, arg_4291) } else { linked_4288.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4287, arg_4290, arg_4291) }; i__292000396__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000396__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A) Ctor() {}
//line :517:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A) Invoke_O_O__O(self, s__292000411__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4429 any = A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A_New_O_O(self, s__292000411__1); var tmp2 *jrt.Class; var fncls__4428 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A_fn_class; if fncls__4428 == nil { var fncls__4428d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__4429); A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A_fn_class = fncls__4428d; tmp2 = fncls__4428d } else { tmp2 = fncls__4428 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4429, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :517:1
func A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A{}; t.Ctor_O_O(p0, p1); return t }
//line :517:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A) Ctor_O_O(c__iter__292000410, c__s__292000411 any) { t.F_iter__292000410 = c__iter__292000410; t.F_s__292000411 = c__s__292000411 }
//line :517:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A) Invoke_O__O(self any) any { { var s__292000411__1 any; var t_ any = t.F_s__292000411; t.F_s__292000411 = nil; s__292000411__1 = t_; for { var temp__1927000414__auto____2 any; var root_4354 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_4355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4354, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4356 lang.IFn; if linked_4355 == nil { ifn_4356 = lang.IFn_Cast(root_4354) } else { ifn_4356 = nil }; var arg_4357 any = s__292000411__1; if linked_4355 == nil { temp__1927000414__auto____2 = ifn_4356.Invoke_O__O(arg_4357) } else { temp__1927000414__auto____2 = linked_4355.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4354, arg_4357) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000411__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4358 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_4359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4358, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4360 lang.IFn; if linked_4359 == nil { ifn_4360 = lang.IFn_Cast(root_4358) } else { ifn_4360 = nil }; var arg_4361 any = s__292000411__3; if linked_4359 == nil { tmp1 = ifn_4360.Invoke_O__O(arg_4361) } else { tmp1 = linked_4359.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4358, arg_4361) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4362 any = A_arbace_j2g_dyncf_A_const_70.GetRawRoot__O(); var linked_4363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4362, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4364 lang.IFn; if linked_4363 == nil { ifn_4364 = lang.IFn_Cast(root_4362) } else { ifn_4364 = nil }; var arg_4365 any = s__292000411__3; if linked_4363 == nil { c__1927001037__auto____4 = ifn_4364.Invoke_O__O(arg_4365) } else { c__1927001037__auto____4 = linked_4363.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4362, arg_4365) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000413__6 any; var root_4366 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_4367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4366, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4368 lang.IFn; if linked_4367 == nil { ifn_4368 = lang.IFn_Cast(root_4366) } else { ifn_4368 = nil }; var arg_4369 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4367 == nil { b__292000413__6 = ifn_4368.Invoke_O__O(arg_4369) } else { b__292000413__6 = linked_4367.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4366, arg_4369) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4384 any = A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A_New_O_I_O(b__292000413__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4383 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A_fn_class; if fncls__4383 == nil { var fncls__4383d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__4384); A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A_fn_class = fncls__4383d; tmp3 = fncls__4383d } else { tmp3 = fncls__4383 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4384, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4385 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4385, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4387 lang.IFn; if linked_4386 == nil { ifn_4387 = lang.IFn_Cast(root_4385) } else { ifn_4387 = nil }; var arg_4388 any; var root_4390 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4390, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4392 lang.IFn; if linked_4391 == nil { ifn_4392 = lang.IFn_Cast(root_4390) } else { ifn_4392 = nil }; var arg_4393 any = b__292000413__6; if linked_4391 == nil { arg_4388 = ifn_4392.Invoke_O__O(arg_4393) } else { arg_4388 = linked_4391.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4390, arg_4393) }; var arg_4389 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000410); var tmp5 any; var root_4394 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_4395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4394, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4396 lang.IFn; if linked_4395 == nil { ifn_4396 = lang.IFn_Cast(root_4394) } else { ifn_4396 = nil }; var arg_4397 any = s__292000411__3; if linked_4395 == nil { tmp5 = ifn_4396.Invoke_O__O(arg_4397) } else { tmp5 = linked_4395.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4394, arg_4397) }; arg_4389 = tmp4.Invoke_O__O(tmp5); if linked_4386 == nil { return ifn_4387.Invoke_O_O__O(arg_4388, arg_4389) } else { return linked_4386.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4385, arg_4388, arg_4389) } } else { var root_4398 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_4399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4398, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4400 lang.IFn; if linked_4399 == nil { ifn_4400 = lang.IFn_Cast(root_4398) } else { ifn_4400 = nil }; var arg_4401 any; var root_4403 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_4404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4403, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4405 lang.IFn; if linked_4404 == nil { ifn_4405 = lang.IFn_Cast(root_4403) } else { ifn_4405 = nil }; var arg_4406 any = b__292000413__6; if linked_4404 == nil { arg_4401 = ifn_4405.Invoke_O__O(arg_4406) } else { arg_4401 = linked_4404.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4403, arg_4406) }; var arg_4402 any; if linked_4399 == nil { return ifn_4400.Invoke_O_O__O(arg_4401, arg_4402) } else { return linked_4399.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4398, arg_4401, arg_4402) } } } else { var vec__292000421__4 any; var root_4407 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_4408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4407, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4409 lang.IFn; if linked_4408 == nil { ifn_4409 = lang.IFn_Cast(root_4407) } else { ifn_4409 = nil }; var arg_4410 any = s__292000411__3; if linked_4408 == nil { vec__292000421__4 = ifn_4409.Invoke_O__O(arg_4410) } else { vec__292000421__4 = linked_4408.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4407, arg_4410) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000421__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ms__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000421__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4411 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_4412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4411, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4413 lang.IFn; if linked_4412 == nil { ifn_4413 = lang.IFn_Cast(root_4411) } else { ifn_4413 = nil }; var arg_4414 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_90, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(ms__6))).Ref(); var arg_4415 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000410); var tmp7 any; var root_4424 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_4425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4424, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4426 lang.IFn; if linked_4425 == nil { ifn_4426 = lang.IFn_Cast(root_4424) } else { ifn_4426 = nil }; var arg_4427 any = s__292000411__3; if linked_4425 == nil { tmp7 = ifn_4426.Invoke_O__O(arg_4427) } else { tmp7 = linked_4425.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4424, arg_4427) }; arg_4415 = tmp6.Invoke_O__O(tmp7); if linked_4412 == nil { return ifn_4413.Invoke_O_O__O(arg_4414, arg_4415) } else { return linked_4412.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4411, arg_4414, arg_4415) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :517:1
func A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :517:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A) Ctor_O_I_O(c__b__292000413 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000413 = c__b__292000413; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :517:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A) Invoke_O__O(self any) any { { var i__292000412__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000412__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000417__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000412__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000417__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ms__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000417__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4370 any = A_arbace_j2g_dyncf_A_const_84.GetRawRoot__O(); var linked_4371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4370, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4372 lang.IFn; if linked_4371 == nil { ifn_4372 = lang.IFn_Cast(root_4370) } else { ifn_4372 = nil }; var arg_4373 any = t.F_b__292000413; var arg_4374 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_90, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_414.GetRawRoot__O()).Invoke_O__O(ms__4))).Ref(); if linked_4371 == nil { ifn_4372.Invoke_O_O__O(arg_4373, arg_4374) } else { linked_4371.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4370, arg_4373, arg_4374) }; i__292000412__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000412__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































































































































































































































































































































































































































type A_arbace_j2g_dyncf_A struct{ jrt.Object }

var A_arbace_j2g_dyncf_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyncf_A_const_0 *lang.Var

var A_arbace_j2g_dyncf_A_const_1 any

var A_arbace_j2g_dyncf_A_const_2 any

var A_arbace_j2g_dyncf_A_const_3 any

var A_arbace_j2g_dyncf_A_const_4 any

var A_arbace_j2g_dyncf_A_const_5 any

var A_arbace_j2g_dyncf_A_const_6 any

var A_arbace_j2g_dyncf_A_const_7 any

var A_arbace_j2g_dyncf_A_const_8 any

var A_arbace_j2g_dyncf_A_const_9 any

var A_arbace_j2g_dyncf_A_const_10 any

var A_arbace_j2g_dyncf_A_const_11 any

var A_arbace_j2g_dyncf_A_const_12 *lang.Var

var A_arbace_j2g_dyncf_A_const_13 any

var A_arbace_j2g_dyncf_A_const_14 *lang.Var

var A_arbace_j2g_dyncf_A_const_15 *lang.Var

var A_arbace_j2g_dyncf_A_const_16 *lang.Var

var A_arbace_j2g_dyncf_A_const_17 *lang.Var

var A_arbace_j2g_dyncf_A_const_18 any

var A_arbace_j2g_dyncf_A_const_19 *lang.Var

var A_arbace_j2g_dyncf_A_const_20 *lang.Var

var A_arbace_j2g_dyncf_A_const_21 *lang.Var

var A_arbace_j2g_dyncf_A_const_22 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_23 *lang.Var

var A_arbace_j2g_dyncf_A_const_24 *lang.Var

var A_arbace_j2g_dyncf_A_const_25 *lang.Var

var A_arbace_j2g_dyncf_A_const_26 *lang.Var

var A_arbace_j2g_dyncf_A_const_27 *lang.Var

var A_arbace_j2g_dyncf_A_const_28 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_29 any

var A_arbace_j2g_dyncf_A_const_30 *lang.Var

var A_arbace_j2g_dyncf_A_const_31 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_32 any

var A_arbace_j2g_dyncf_A_const_33 *lang.Var

var A_arbace_j2g_dyncf_A_const_34 any

var A_arbace_j2g_dyncf_A_const_35 any

var A_arbace_j2g_dyncf_A_const_36 *lang.Var

var A_arbace_j2g_dyncf_A_const_37 *lang.Var

var A_arbace_j2g_dyncf_A_const_38 any

var A_arbace_j2g_dyncf_A_const_39 *lang.Var

var A_arbace_j2g_dyncf_A_const_40 *lang.Var

var A_arbace_j2g_dyncf_A_const_41 *lang.Var

var A_arbace_j2g_dyncf_A_const_42 any

var A_arbace_j2g_dyncf_A_const_43 any

var A_arbace_j2g_dyncf_A_const_44 *lang.Var

var A_arbace_j2g_dyncf_A_const_45 any

var A_arbace_j2g_dyncf_A_const_46 any

var A_arbace_j2g_dyncf_A_const_47 any

var A_arbace_j2g_dyncf_A_const_48 any

var A_arbace_j2g_dyncf_A_const_49 any

var A_arbace_j2g_dyncf_A_const_50 *lang.Var

var A_arbace_j2g_dyncf_A_const_51 *lang.Var

var A_arbace_j2g_dyncf_A_const_52 any

var A_arbace_j2g_dyncf_A_const_53 *lang.Var

var A_arbace_j2g_dyncf_A_const_54 any

var A_arbace_j2g_dyncf_A_const_55 any

var A_arbace_j2g_dyncf_A_const_56 any

var A_arbace_j2g_dyncf_A_const_57 any

var A_arbace_j2g_dyncf_A_const_58 any

var A_arbace_j2g_dyncf_A_const_59 any

var A_arbace_j2g_dyncf_A_const_60 any

var A_arbace_j2g_dyncf_A_const_61 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_62 any

var A_arbace_j2g_dyncf_A_const_63 any

var A_arbace_j2g_dyncf_A_const_64 any

var A_arbace_j2g_dyncf_A_const_65 *lang.Var

var A_arbace_j2g_dyncf_A_const_66 any

var A_arbace_j2g_dyncf_A_const_67 any

var A_arbace_j2g_dyncf_A_const_68 *lang.Var

var A_arbace_j2g_dyncf_A_const_69 *lang.Var

var A_arbace_j2g_dyncf_A_const_70 *lang.Var

var A_arbace_j2g_dyncf_A_const_71 *lang.Var

var A_arbace_j2g_dyncf_A_const_72 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_73 *lang.Var

var A_arbace_j2g_dyncf_A_const_74 *lang.Var

var A_arbace_j2g_dyncf_A_const_75 *lang.Var

var A_arbace_j2g_dyncf_A_const_76 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_77 *lang.Var

var A_arbace_j2g_dyncf_A_const_78 *lang.Var

var A_arbace_j2g_dyncf_A_const_79 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_80 *lang.Var

var A_arbace_j2g_dyncf_A_const_81 *lang.Var

var A_arbace_j2g_dyncf_A_const_82 *lang.Var

var A_arbace_j2g_dyncf_A_const_83 *lang.Var

var A_arbace_j2g_dyncf_A_const_84 *lang.Var

var A_arbace_j2g_dyncf_A_const_85 any

var A_arbace_j2g_dyncf_A_const_86 any

var A_arbace_j2g_dyncf_A_const_87 any

var A_arbace_j2g_dyncf_A_const_88 any

var A_arbace_j2g_dyncf_A_const_89 any

var A_arbace_j2g_dyncf_A_const_90 any

var A_arbace_j2g_dyncf_A_const_91 any

var A_arbace_j2g_dyncf_A_const_92 any

var A_arbace_j2g_dyncf_A_const_93 *lang.Var

var A_arbace_j2g_dyncf_A_const_94 *lang.Var

var A_arbace_j2g_dyncf_A_const_95 any

var A_arbace_j2g_dyncf_A_const_96 any

var A_arbace_j2g_dyncf_A_const_97 any

var A_arbace_j2g_dyncf_A_const_98 any

var A_arbace_j2g_dyncf_A_const_99 any

var A_arbace_j2g_dyncf_A_const_100 *lang.Var

var A_arbace_j2g_dyncf_A_const_101 *lang.Var

var A_arbace_j2g_dyncf_A_const_102 *lang.Var

var A_arbace_j2g_dyncf_A_const_103 *lang.Var

var A_arbace_j2g_dyncf_A_const_104 *lang.Var

var A_arbace_j2g_dyncf_A_const_105 any

var A_arbace_j2g_dyncf_A_const_106 *lang.Var

var A_arbace_j2g_dyncf_A_const_107 *lang.Var

var A_arbace_j2g_dyncf_A_const_108 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_109 *lang.Var

var A_arbace_j2g_dyncf_A_const_110 any

var A_arbace_j2g_dyncf_A_const_111 any

var A_arbace_j2g_dyncf_A_const_112 any

var A_arbace_j2g_dyncf_A_const_113 any

var A_arbace_j2g_dyncf_A_const_114 *lang.Var

var A_arbace_j2g_dyncf_A_const_115 any

var A_arbace_j2g_dyncf_A_const_116 any

var A_arbace_j2g_dyncf_A_const_117 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_118 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_119 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_120 any

var A_arbace_j2g_dyncf_A_const_121 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_122 any

var A_arbace_j2g_dyncf_A_const_123 any

var A_arbace_j2g_dyncf_A_const_124 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_125 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_126 any

var A_arbace_j2g_dyncf_A_const_127 any

var A_arbace_j2g_dyncf_A_const_128 any

var A_arbace_j2g_dyncf_A_const_129 any

var A_arbace_j2g_dyncf_A_const_130 any

var A_arbace_j2g_dyncf_A_const_131 any

var A_arbace_j2g_dyncf_A_const_132 any

var A_arbace_j2g_dyncf_A_const_133 any

var A_arbace_j2g_dyncf_A_const_134 any

var A_arbace_j2g_dyncf_A_const_135 any

var A_arbace_j2g_dyncf_A_const_136 any

var A_arbace_j2g_dyncf_A_const_137 any

var A_arbace_j2g_dyncf_A_const_138 any

var A_arbace_j2g_dyncf_A_const_139 any

var A_arbace_j2g_dyncf_A_const_140 any

var A_arbace_j2g_dyncf_A_const_141 any

var A_arbace_j2g_dyncf_A_const_142 any

var A_arbace_j2g_dyncf_A_const_143 any

var A_arbace_j2g_dyncf_A_const_144 *lang.Var

var A_arbace_j2g_dyncf_A_const_145 *lang.Var

var A_arbace_j2g_dyncf_A_const_146 any

var A_arbace_j2g_dyncf_A_const_147 any

var A_arbace_j2g_dyncf_A_const_148 any

var A_arbace_j2g_dyncf_A_const_149 any

var A_arbace_j2g_dyncf_A_const_150 *lang.Var

var A_arbace_j2g_dyncf_A_const_151 *lang.Var

var A_arbace_j2g_dyncf_A_const_152 *lang.Var

var A_arbace_j2g_dyncf_A_const_153 *lang.Var

var A_arbace_j2g_dyncf_A_const_154 *lang.Var

var A_arbace_j2g_dyncf_A_const_155 *lang.Var

var A_arbace_j2g_dyncf_A_const_156 any

var A_arbace_j2g_dyncf_A_const_157 *lang.Var

var A_arbace_j2g_dyncf_A_const_158 *lang.Var

var A_arbace_j2g_dyncf_A_const_159 any

var A_arbace_j2g_dyncf_A_const_160 any

var A_arbace_j2g_dyncf_A_const_161 any

var A_arbace_j2g_dyncf_A_const_162 any

var A_arbace_j2g_dyncf_A_const_163 any

var A_arbace_j2g_dyncf_A_const_164 any

var A_arbace_j2g_dyncf_A_const_165 any

var A_arbace_j2g_dyncf_A_const_166 any

var A_arbace_j2g_dyncf_A_const_167 any

var A_arbace_j2g_dyncf_A_const_168 *lang.Var

var A_arbace_j2g_dyncf_A_const_169 any

var A_arbace_j2g_dyncf_A_const_170 any

var A_arbace_j2g_dyncf_A_const_171 any

var A_arbace_j2g_dyncf_A_const_172 any

var A_arbace_j2g_dyncf_A_const_173 any

var A_arbace_j2g_dyncf_A_const_174 *lang.Var

var A_arbace_j2g_dyncf_A_const_175 any

var A_arbace_j2g_dyncf_A_const_176 any

var A_arbace_j2g_dyncf_A_const_177 any

var A_arbace_j2g_dyncf_A_const_178 any

var A_arbace_j2g_dyncf_A_const_179 any

var A_arbace_j2g_dyncf_A_const_180 any

var A_arbace_j2g_dyncf_A_const_181 any

var A_arbace_j2g_dyncf_A_const_182 any

var A_arbace_j2g_dyncf_A_const_183 any

var A_arbace_j2g_dyncf_A_const_184 any

var A_arbace_j2g_dyncf_A_const_185 any

var A_arbace_j2g_dyncf_A_const_186 any

var A_arbace_j2g_dyncf_A_const_187 any

var A_arbace_j2g_dyncf_A_const_188 any

var A_arbace_j2g_dyncf_A_const_189 any

var A_arbace_j2g_dyncf_A_const_190 *lang.Var

var A_arbace_j2g_dyncf_A_const_191 *lang.Var

var A_arbace_j2g_dyncf_A_const_192 *lang.Var

var A_arbace_j2g_dyncf_A_const_193 *lang.Var

var A_arbace_j2g_dyncf_A_const_194 *lang.Var

var A_arbace_j2g_dyncf_A_const_195 *lang.Var

var A_arbace_j2g_dyncf_A_const_196 any

var A_arbace_j2g_dyncf_A_const_197 any

var A_arbace_j2g_dyncf_A_const_198 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_199 any

var A_arbace_j2g_dyncf_A_const_200 any

var A_arbace_j2g_dyncf_A_const_201 any

var A_arbace_j2g_dyncf_A_const_202 any

var A_arbace_j2g_dyncf_A_const_203 any

var A_arbace_j2g_dyncf_A_const_204 any

var A_arbace_j2g_dyncf_A_const_205 any

var A_arbace_j2g_dyncf_A_const_206 any

var A_arbace_j2g_dyncf_A_const_207 any

var A_arbace_j2g_dyncf_A_const_208 any

var A_arbace_j2g_dyncf_A_const_209 any

var A_arbace_j2g_dyncf_A_const_210 any

var A_arbace_j2g_dyncf_A_const_211 any

var A_arbace_j2g_dyncf_A_const_212 any

var A_arbace_j2g_dyncf_A_const_213 any

var A_arbace_j2g_dyncf_A_const_214 any

var A_arbace_j2g_dyncf_A_const_215 any

var A_arbace_j2g_dyncf_A_const_216 any

var A_arbace_j2g_dyncf_A_const_217 *lang.Var

var A_arbace_j2g_dyncf_A_const_218 any

var A_arbace_j2g_dyncf_A_const_219 any

var A_arbace_j2g_dyncf_A_const_220 any

var A_arbace_j2g_dyncf_A_const_221 any

var A_arbace_j2g_dyncf_A_const_222 any

var A_arbace_j2g_dyncf_A_const_223 any

var A_arbace_j2g_dyncf_A_const_224 *lang.Var

var A_arbace_j2g_dyncf_A_const_225 any

var A_arbace_j2g_dyncf_A_const_226 any

var A_arbace_j2g_dyncf_A_const_227 any

var A_arbace_j2g_dyncf_A_const_228 any

var A_arbace_j2g_dyncf_A_const_229 any

var A_arbace_j2g_dyncf_A_const_230 any

var A_arbace_j2g_dyncf_A_const_231 any

var A_arbace_j2g_dyncf_A_const_232 any

var A_arbace_j2g_dyncf_A_const_233 any

var A_arbace_j2g_dyncf_A_const_234 any

var A_arbace_j2g_dyncf_A_const_235 any

var A_arbace_j2g_dyncf_A_const_236 any

var A_arbace_j2g_dyncf_A_const_237 any

var A_arbace_j2g_dyncf_A_const_238 any

var A_arbace_j2g_dyncf_A_const_239 any

var A_arbace_j2g_dyncf_A_const_240 any

var A_arbace_j2g_dyncf_A_const_241 any

var A_arbace_j2g_dyncf_A_const_242 any

var A_arbace_j2g_dyncf_A_const_243 any

var A_arbace_j2g_dyncf_A_const_244 any

var A_arbace_j2g_dyncf_A_const_245 any

var A_arbace_j2g_dyncf_A_const_246 any

var A_arbace_j2g_dyncf_A_const_247 any

var A_arbace_j2g_dyncf_A_const_248 any

var A_arbace_j2g_dyncf_A_const_249 any

var A_arbace_j2g_dyncf_A_const_250 any

var A_arbace_j2g_dyncf_A_const_251 any

var A_arbace_j2g_dyncf_A_const_252 any

var A_arbace_j2g_dyncf_A_const_253 any

var A_arbace_j2g_dyncf_A_const_254 any

var A_arbace_j2g_dyncf_A_const_255 any

var A_arbace_j2g_dyncf_A_const_256 any

var A_arbace_j2g_dyncf_A_const_257 any

var A_arbace_j2g_dyncf_A_const_258 any

var A_arbace_j2g_dyncf_A_const_259 any

var A_arbace_j2g_dyncf_A_const_260 any

var A_arbace_j2g_dyncf_A_const_261 any

var A_arbace_j2g_dyncf_A_const_262 any

var A_arbace_j2g_dyncf_A_const_263 any

var A_arbace_j2g_dyncf_A_const_264 any

var A_arbace_j2g_dyncf_A_const_265 any

var A_arbace_j2g_dyncf_A_const_266 any

var A_arbace_j2g_dyncf_A_const_267 any

var A_arbace_j2g_dyncf_A_const_268 any

var A_arbace_j2g_dyncf_A_const_269 any

var A_arbace_j2g_dyncf_A_const_270 any

var A_arbace_j2g_dyncf_A_const_271 any

var A_arbace_j2g_dyncf_A_const_272 any

var A_arbace_j2g_dyncf_A_const_273 any

var A_arbace_j2g_dyncf_A_const_274 any

var A_arbace_j2g_dyncf_A_const_275 any

var A_arbace_j2g_dyncf_A_const_276 any

var A_arbace_j2g_dyncf_A_const_277 any

var A_arbace_j2g_dyncf_A_const_278 any

var A_arbace_j2g_dyncf_A_const_279 any

var A_arbace_j2g_dyncf_A_const_280 any

var A_arbace_j2g_dyncf_A_const_281 any

var A_arbace_j2g_dyncf_A_const_282 any

var A_arbace_j2g_dyncf_A_const_283 any

var A_arbace_j2g_dyncf_A_const_284 any

var A_arbace_j2g_dyncf_A_const_285 any

var A_arbace_j2g_dyncf_A_const_286 any

var A_arbace_j2g_dyncf_A_const_287 any

var A_arbace_j2g_dyncf_A_const_288 any

var A_arbace_j2g_dyncf_A_const_289 any

var A_arbace_j2g_dyncf_A_const_290 any

var A_arbace_j2g_dyncf_A_const_291 any

var A_arbace_j2g_dyncf_A_const_292 any

var A_arbace_j2g_dyncf_A_const_293 any

var A_arbace_j2g_dyncf_A_const_294 any

var A_arbace_j2g_dyncf_A_const_295 any

var A_arbace_j2g_dyncf_A_const_296 any

var A_arbace_j2g_dyncf_A_const_297 any

var A_arbace_j2g_dyncf_A_const_298 any

var A_arbace_j2g_dyncf_A_const_299 any

var A_arbace_j2g_dyncf_A_const_300 any

var A_arbace_j2g_dyncf_A_const_301 any

var A_arbace_j2g_dyncf_A_const_302 any

var A_arbace_j2g_dyncf_A_const_303 any

var A_arbace_j2g_dyncf_A_const_304 any

var A_arbace_j2g_dyncf_A_const_305 any

var A_arbace_j2g_dyncf_A_const_306 any

var A_arbace_j2g_dyncf_A_const_307 any

var A_arbace_j2g_dyncf_A_const_308 any

var A_arbace_j2g_dyncf_A_const_309 any

var A_arbace_j2g_dyncf_A_const_310 any

var A_arbace_j2g_dyncf_A_const_311 any

var A_arbace_j2g_dyncf_A_const_312 any

var A_arbace_j2g_dyncf_A_const_313 any

var A_arbace_j2g_dyncf_A_const_314 any

var A_arbace_j2g_dyncf_A_const_315 any

var A_arbace_j2g_dyncf_A_const_316 any

var A_arbace_j2g_dyncf_A_const_317 any

var A_arbace_j2g_dyncf_A_const_318 any

var A_arbace_j2g_dyncf_A_const_319 any

var A_arbace_j2g_dyncf_A_const_320 any

var A_arbace_j2g_dyncf_A_const_321 any

var A_arbace_j2g_dyncf_A_const_322 any

var A_arbace_j2g_dyncf_A_const_323 any

var A_arbace_j2g_dyncf_A_const_324 any

var A_arbace_j2g_dyncf_A_const_325 any

var A_arbace_j2g_dyncf_A_const_326 any

var A_arbace_j2g_dyncf_A_const_327 any

var A_arbace_j2g_dyncf_A_const_328 any

var A_arbace_j2g_dyncf_A_const_329 any

var A_arbace_j2g_dyncf_A_const_330 any

var A_arbace_j2g_dyncf_A_const_331 any

var A_arbace_j2g_dyncf_A_const_332 any

var A_arbace_j2g_dyncf_A_const_333 any

var A_arbace_j2g_dyncf_A_const_334 any

var A_arbace_j2g_dyncf_A_const_335 any

var A_arbace_j2g_dyncf_A_const_336 any

var A_arbace_j2g_dyncf_A_const_337 any

var A_arbace_j2g_dyncf_A_const_338 any

var A_arbace_j2g_dyncf_A_const_339 any

var A_arbace_j2g_dyncf_A_const_340 any

var A_arbace_j2g_dyncf_A_const_341 any

var A_arbace_j2g_dyncf_A_const_342 any

var A_arbace_j2g_dyncf_A_const_343 any

var A_arbace_j2g_dyncf_A_const_344 any

var A_arbace_j2g_dyncf_A_const_345 any

var A_arbace_j2g_dyncf_A_const_346 any

var A_arbace_j2g_dyncf_A_const_347 any

var A_arbace_j2g_dyncf_A_const_348 any

var A_arbace_j2g_dyncf_A_const_349 any

var A_arbace_j2g_dyncf_A_const_350 any

var A_arbace_j2g_dyncf_A_const_351 any

var A_arbace_j2g_dyncf_A_const_352 any

var A_arbace_j2g_dyncf_A_const_353 any

var A_arbace_j2g_dyncf_A_const_354 any

var A_arbace_j2g_dyncf_A_const_355 any

var A_arbace_j2g_dyncf_A_const_356 any

var A_arbace_j2g_dyncf_A_const_357 any

var A_arbace_j2g_dyncf_A_const_358 any

var A_arbace_j2g_dyncf_A_const_359 any

var A_arbace_j2g_dyncf_A_const_360 *lang.Var

var A_arbace_j2g_dyncf_A_const_361 *lang.Var

var A_arbace_j2g_dyncf_A_const_362 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_363 *lang.Var

var A_arbace_j2g_dyncf_A_const_364 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_365 any

var A_arbace_j2g_dyncf_A_const_366 *lang.Var

var A_arbace_j2g_dyncf_A_const_367 *lang.Var

var A_arbace_j2g_dyncf_A_const_368 *lang.Var

var A_arbace_j2g_dyncf_A_const_369 *lang.Var

var A_arbace_j2g_dyncf_A_const_370 *lang.Var

var A_arbace_j2g_dyncf_A_const_371 *lang.Var

var A_arbace_j2g_dyncf_A_const_372 *lang.Var

var A_arbace_j2g_dyncf_A_const_373 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_374 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_375 *lang.Var

var A_arbace_j2g_dyncf_A_const_376 *lang.Var

var A_arbace_j2g_dyncf_A_const_377 *lang.Var

var A_arbace_j2g_dyncf_A_const_378 any

var A_arbace_j2g_dyncf_A_const_379 *lang.Var

var A_arbace_j2g_dyncf_A_const_380 *lang.Var

var A_arbace_j2g_dyncf_A_const_381 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_382 *lang.Var

var A_arbace_j2g_dyncf_A_const_383 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_384 *lang.Var

var A_arbace_j2g_dyncf_A_const_385 *lang.Var

var A_arbace_j2g_dyncf_A_const_386 *lang.Var

var A_arbace_j2g_dyncf_A_const_387 any

var A_arbace_j2g_dyncf_A_const_388 any

var A_arbace_j2g_dyncf_A_const_389 any

var A_arbace_j2g_dyncf_A_const_390 any

var A_arbace_j2g_dyncf_A_const_391 any

var A_arbace_j2g_dyncf_A_const_392 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_393 *lang.Var

var A_arbace_j2g_dyncf_A_const_394 *lang.Var

var A_arbace_j2g_dyncf_A_const_395 *lang.Var

var A_arbace_j2g_dyncf_A_const_396 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_397 any

var A_arbace_j2g_dyncf_A_const_398 any

var A_arbace_j2g_dyncf_A_const_399 any

var A_arbace_j2g_dyncf_A_const_400 any

var A_arbace_j2g_dyncf_A_const_401 any

var A_arbace_j2g_dyncf_A_const_402 any

var A_arbace_j2g_dyncf_A_const_403 *lang.Var

var A_arbace_j2g_dyncf_A_const_404 *lang.Var

var A_arbace_j2g_dyncf_A_const_405 *lang.Var

var A_arbace_j2g_dyncf_A_const_406 *lang.Var

var A_arbace_j2g_dyncf_A_const_407 *lang.Var

var A_arbace_j2g_dyncf_A_const_408 *lang.Var

var A_arbace_j2g_dyncf_A_const_409 any

var A_arbace_j2g_dyncf_A_const_410 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_411 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_412 *lang.Var

var A_arbace_j2g_dyncf_A_const_413 *lang.Var

var A_arbace_j2g_dyncf_A_const_414 *lang.Var

var A_arbace_j2g_dyncf_A_const_415 *lang.Var

var A_arbace_j2g_dyncf_A_const_416 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_417 *lang.Var

var A_arbace_j2g_dyncf_A_const_418 *lang.Var

var A_arbace_j2g_dyncf_A_const_419 *lang.Var

var A_arbace_j2g_dyncf_A_const_420 *lang.Var

var A_arbace_j2g_dyncf_A_init jrt.ClassInit

func A_arbace_j2g_dyncf_A_Init() { if !A_arbace_j2g_dyncf_A_init.Done() { A_arbace_j2g_dyncf_A_init.Run(A_arbace_j2g_dyncf_A_clinit) } }

func A_arbace_j2g_dyncf_A_clinit() { A_arbace_j2g_dyncf_A_clinit_p0(); A_arbace_j2g_dyncf_A_clinit_p1(); A_arbace_j2g_dyncf_A_clinit_p2(); A_arbace_j2g_dyncf_A_clinit_p3(); A_arbace_j2g_dyncf_A_clinit_p4(); A_arbace_j2g_dyncf_A_clinit_p5(); A_arbace_j2g_dyncf_A_clinit_p6(); A_arbace_j2g_dyncf_A_clinit_p7(); A_arbace_j2g_dyncf_A_clinit_p8(); A_arbace_j2g_dyncf_A_clinit_p9(); A_arbace_j2g_dyncf_A_clinit_p10(); A_arbace_j2g_dyncf_A_clinit_p11(); A_arbace_j2g_dyncf_A_clinit_p12(); A_arbace_j2g_dyncf_A_clinit_p13(); A_arbace_j2g_dyncf_A_clinit_p14(); A_arbace_j2g_dyncf_A_clinit_p15(); A_arbace_j2g_dyncf_A_clinit_p16(); A_arbace_j2g_dyncf_A_clinit_p17(); A_arbace_j2g_dyncf_A_clinit_p18(); A_arbace_j2g_dyncf_A_clinit_p19(); A_arbace_j2g_dyncf_A_clinit_p20(); A_arbace_j2g_dyncf_A_clinit_p21(); A_arbace_j2g_dyncf_A_clinit_p22(); A_arbace_j2g_dyncf_A_clinit_p23(); A_arbace_j2g_dyncf_A_clinit_p24(); A_arbace_j2g_dyncf_A_clinit_p25(); A_arbace_j2g_dyncf_A_clinit_p26(); A_arbace_j2g_dyncf_A_clinit_p27(); A_arbace_j2g_dyncf_A_clinit_p28(); A_arbace_j2g_dyncf_A_clinit_p29() }

func A_arbace_j2g_dyncf_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyncf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 661); A_arbace_j2g_dyncf_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[240]); A_arbace_j2g_dyncf_A_const_1 = A_arbace_j2g_dyncf_A_const_pool.A[241]; A_arbace_j2g_dyncf_A_const_2 = A_arbace_j2g_dyncf_A_const_pool.A[242]; A_arbace_j2g_dyncf_A_const_3 = A_arbace_j2g_dyncf_A_const_pool.A[243]; A_arbace_j2g_dyncf_A_const_4 = A_arbace_j2g_dyncf_A_const_pool.A[244]; A_arbace_j2g_dyncf_A_const_5 = A_arbace_j2g_dyncf_A_const_pool.A[245]; A_arbace_j2g_dyncf_A_const_6 = A_arbace_j2g_dyncf_A_const_pool.A[246]; A_arbace_j2g_dyncf_A_const_7 = A_arbace_j2g_dyncf_A_const_pool.A[247]; A_arbace_j2g_dyncf_A_const_8 = A_arbace_j2g_dyncf_A_const_pool.A[248]; A_arbace_j2g_dyncf_A_const_9 = A_arbace_j2g_dyncf_A_const_pool.A[249]; A_arbace_j2g_dyncf_A_const_10 = A_arbace_j2g_dyncf_A_const_pool.A[250]; A_arbace_j2g_dyncf_A_const_11 = A_arbace_j2g_dyncf_A_const_pool.A[251]; A_arbace_j2g_dyncf_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[252]); A_arbace_j2g_dyncf_A_const_13 = A_arbace_j2g_dyncf_A_const_pool.A[253] }

func A_arbace_j2g_dyncf_A_clinit_p1() { A_arbace_j2g_dyncf_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[254]); A_arbace_j2g_dyncf_A_const_15 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[255]); A_arbace_j2g_dyncf_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[256]); A_arbace_j2g_dyncf_A_const_17 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[257]); A_arbace_j2g_dyncf_A_const_18 = A_arbace_j2g_dyncf_A_const_pool.A[258]; A_arbace_j2g_dyncf_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[259]); A_arbace_j2g_dyncf_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[260]); A_arbace_j2g_dyncf_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[261]); A_arbace_j2g_dyncf_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[262]); A_arbace_j2g_dyncf_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[263]); A_arbace_j2g_dyncf_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[264]); A_arbace_j2g_dyncf_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[265]) }

func A_arbace_j2g_dyncf_A_clinit_p2() { A_arbace_j2g_dyncf_A_const_26 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[266]); A_arbace_j2g_dyncf_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[267]); A_arbace_j2g_dyncf_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[268]); A_arbace_j2g_dyncf_A_const_29 = A_arbace_j2g_dyncf_A_const_pool.A[269]; A_arbace_j2g_dyncf_A_const_30 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[270]); A_arbace_j2g_dyncf_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[271]); A_arbace_j2g_dyncf_A_const_32 = A_arbace_j2g_dyncf_A_const_pool.A[272]; A_arbace_j2g_dyncf_A_const_33 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[273]); A_arbace_j2g_dyncf_A_const_34 = A_arbace_j2g_dyncf_A_const_pool.A[274]; A_arbace_j2g_dyncf_A_const_35 = A_arbace_j2g_dyncf_A_const_pool.A[275]; A_arbace_j2g_dyncf_A_const_36 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[276]); A_arbace_j2g_dyncf_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[277]); A_arbace_j2g_dyncf_A_const_38 = A_arbace_j2g_dyncf_A_const_pool.A[278] }

func A_arbace_j2g_dyncf_A_clinit_p3() { A_arbace_j2g_dyncf_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[279]); A_arbace_j2g_dyncf_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[280]); A_arbace_j2g_dyncf_A_const_41 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[281]); A_arbace_j2g_dyncf_A_const_42 = A_arbace_j2g_dyncf_A_const_pool.A[282]; A_arbace_j2g_dyncf_A_const_43 = A_arbace_j2g_dyncf_A_const_pool.A[283]; A_arbace_j2g_dyncf_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[284]); A_arbace_j2g_dyncf_A_const_45 = A_arbace_j2g_dyncf_A_const_pool.A[285]; A_arbace_j2g_dyncf_A_const_46 = A_arbace_j2g_dyncf_A_const_pool.A[286]; A_arbace_j2g_dyncf_A_const_47 = A_arbace_j2g_dyncf_A_const_pool.A[287]; A_arbace_j2g_dyncf_A_const_48 = A_arbace_j2g_dyncf_A_const_pool.A[288]; A_arbace_j2g_dyncf_A_const_49 = A_arbace_j2g_dyncf_A_const_pool.A[289]; A_arbace_j2g_dyncf_A_const_50 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[290]); A_arbace_j2g_dyncf_A_const_51 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[291]); A_arbace_j2g_dyncf_A_const_52 = A_arbace_j2g_dyncf_A_const_pool.A[292] }

func A_arbace_j2g_dyncf_A_clinit_p4() { A_arbace_j2g_dyncf_A_const_53 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[293]); A_arbace_j2g_dyncf_A_const_54 = A_arbace_j2g_dyncf_A_const_pool.A[294]; A_arbace_j2g_dyncf_A_const_55 = A_arbace_j2g_dyncf_A_const_pool.A[295]; A_arbace_j2g_dyncf_A_const_56 = A_arbace_j2g_dyncf_A_const_pool.A[296]; A_arbace_j2g_dyncf_A_const_57 = A_arbace_j2g_dyncf_A_const_pool.A[297]; A_arbace_j2g_dyncf_A_const_58 = A_arbace_j2g_dyncf_A_const_pool.A[298]; A_arbace_j2g_dyncf_A_const_59 = A_arbace_j2g_dyncf_A_const_pool.A[299]; A_arbace_j2g_dyncf_A_const_60 = A_arbace_j2g_dyncf_A_const_pool.A[300]; A_arbace_j2g_dyncf_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[301]); A_arbace_j2g_dyncf_A_const_62 = A_arbace_j2g_dyncf_A_const_pool.A[302]; A_arbace_j2g_dyncf_A_const_63 = A_arbace_j2g_dyncf_A_const_pool.A[303]; A_arbace_j2g_dyncf_A_const_64 = A_arbace_j2g_dyncf_A_const_pool.A[304]; A_arbace_j2g_dyncf_A_const_65 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[305]); A_arbace_j2g_dyncf_A_const_66 = A_arbace_j2g_dyncf_A_const_pool.A[306]; A_arbace_j2g_dyncf_A_const_67 = A_arbace_j2g_dyncf_A_const_pool.A[307] }

func A_arbace_j2g_dyncf_A_clinit_p5() { A_arbace_j2g_dyncf_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[308]); A_arbace_j2g_dyncf_A_const_69 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[309]); A_arbace_j2g_dyncf_A_const_70 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[310]); A_arbace_j2g_dyncf_A_const_71 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[311]); A_arbace_j2g_dyncf_A_const_72 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[312]); A_arbace_j2g_dyncf_A_const_73 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[313]); A_arbace_j2g_dyncf_A_const_74 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[314]); A_arbace_j2g_dyncf_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[315]); A_arbace_j2g_dyncf_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[316]); A_arbace_j2g_dyncf_A_const_77 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[317]); A_arbace_j2g_dyncf_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[318]); A_arbace_j2g_dyncf_A_const_79 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[319]) }

func A_arbace_j2g_dyncf_A_clinit_p6() { A_arbace_j2g_dyncf_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[320]); A_arbace_j2g_dyncf_A_const_81 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[321]); A_arbace_j2g_dyncf_A_const_82 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[322]); A_arbace_j2g_dyncf_A_const_83 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[323]); A_arbace_j2g_dyncf_A_const_84 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[324]); A_arbace_j2g_dyncf_A_const_85 = A_arbace_j2g_dyncf_A_const_pool.A[325]; A_arbace_j2g_dyncf_A_const_86 = A_arbace_j2g_dyncf_A_const_pool.A[326]; A_arbace_j2g_dyncf_A_const_87 = A_arbace_j2g_dyncf_A_const_pool.A[327]; A_arbace_j2g_dyncf_A_const_88 = A_arbace_j2g_dyncf_A_const_pool.A[328]; A_arbace_j2g_dyncf_A_const_89 = A_arbace_j2g_dyncf_A_const_pool.A[329]; A_arbace_j2g_dyncf_A_const_90 = A_arbace_j2g_dyncf_A_const_pool.A[330]; A_arbace_j2g_dyncf_A_const_91 = A_arbace_j2g_dyncf_A_const_pool.A[331]; A_arbace_j2g_dyncf_A_const_92 = A_arbace_j2g_dyncf_A_const_pool.A[332]; A_arbace_j2g_dyncf_A_const_93 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[333]) }

func A_arbace_j2g_dyncf_A_clinit_p7() { A_arbace_j2g_dyncf_A_const_94 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[334]); A_arbace_j2g_dyncf_A_const_95 = A_arbace_j2g_dyncf_A_const_pool.A[335]; A_arbace_j2g_dyncf_A_const_96 = A_arbace_j2g_dyncf_A_const_pool.A[336]; A_arbace_j2g_dyncf_A_const_97 = A_arbace_j2g_dyncf_A_const_pool.A[337]; A_arbace_j2g_dyncf_A_const_98 = A_arbace_j2g_dyncf_A_const_pool.A[338]; A_arbace_j2g_dyncf_A_const_99 = A_arbace_j2g_dyncf_A_const_pool.A[339]; A_arbace_j2g_dyncf_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[340]); A_arbace_j2g_dyncf_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[341]); A_arbace_j2g_dyncf_A_const_102 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[342]); A_arbace_j2g_dyncf_A_const_103 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[343]); A_arbace_j2g_dyncf_A_const_104 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[344]); A_arbace_j2g_dyncf_A_const_105 = A_arbace_j2g_dyncf_A_const_pool.A[345]; A_arbace_j2g_dyncf_A_const_106 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[346]) }

func A_arbace_j2g_dyncf_A_clinit_p8() { A_arbace_j2g_dyncf_A_const_107 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[347]); A_arbace_j2g_dyncf_A_const_108 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[348]); A_arbace_j2g_dyncf_A_const_109 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[349]); A_arbace_j2g_dyncf_A_const_110 = A_arbace_j2g_dyncf_A_const_pool.A[350]; A_arbace_j2g_dyncf_A_const_111 = A_arbace_j2g_dyncf_A_const_pool.A[351]; A_arbace_j2g_dyncf_A_const_112 = A_arbace_j2g_dyncf_A_const_pool.A[352]; A_arbace_j2g_dyncf_A_const_113 = A_arbace_j2g_dyncf_A_const_pool.A[353]; A_arbace_j2g_dyncf_A_const_114 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[354]); A_arbace_j2g_dyncf_A_const_115 = A_arbace_j2g_dyncf_A_const_pool.A[355]; A_arbace_j2g_dyncf_A_const_116 = A_arbace_j2g_dyncf_A_const_pool.A[356]; A_arbace_j2g_dyncf_A_const_117 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[357]); A_arbace_j2g_dyncf_A_const_118 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[358]); A_arbace_j2g_dyncf_A_const_119 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[359]) }

func A_arbace_j2g_dyncf_A_clinit_p9() { A_arbace_j2g_dyncf_A_const_120 = A_arbace_j2g_dyncf_A_const_pool.A[360]; A_arbace_j2g_dyncf_A_const_121 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[361]); A_arbace_j2g_dyncf_A_const_122 = A_arbace_j2g_dyncf_A_const_pool.A[362]; A_arbace_j2g_dyncf_A_const_123 = A_arbace_j2g_dyncf_A_const_pool.A[363]; A_arbace_j2g_dyncf_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[364]); A_arbace_j2g_dyncf_A_const_125 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[365]); A_arbace_j2g_dyncf_A_const_126 = A_arbace_j2g_dyncf_A_const_pool.A[366]; A_arbace_j2g_dyncf_A_const_127 = A_arbace_j2g_dyncf_A_const_pool.A[367]; A_arbace_j2g_dyncf_A_const_128 = A_arbace_j2g_dyncf_A_const_pool.A[368]; A_arbace_j2g_dyncf_A_const_129 = A_arbace_j2g_dyncf_A_const_pool.A[369]; A_arbace_j2g_dyncf_A_const_130 = A_arbace_j2g_dyncf_A_const_pool.A[370]; A_arbace_j2g_dyncf_A_const_131 = A_arbace_j2g_dyncf_A_const_pool.A[371]; A_arbace_j2g_dyncf_A_const_132 = A_arbace_j2g_dyncf_A_const_pool.A[372]; A_arbace_j2g_dyncf_A_const_133 = A_arbace_j2g_dyncf_A_const_pool.A[373]; A_arbace_j2g_dyncf_A_const_134 = A_arbace_j2g_dyncf_A_const_pool.A[374] }

func A_arbace_j2g_dyncf_A_clinit_p10() { A_arbace_j2g_dyncf_A_const_135 = A_arbace_j2g_dyncf_A_const_pool.A[375]; A_arbace_j2g_dyncf_A_const_136 = A_arbace_j2g_dyncf_A_const_pool.A[376]; A_arbace_j2g_dyncf_A_const_137 = A_arbace_j2g_dyncf_A_const_pool.A[377]; A_arbace_j2g_dyncf_A_const_138 = A_arbace_j2g_dyncf_A_const_pool.A[378]; A_arbace_j2g_dyncf_A_const_139 = A_arbace_j2g_dyncf_A_const_pool.A[379]; A_arbace_j2g_dyncf_A_const_140 = A_arbace_j2g_dyncf_A_const_pool.A[380]; A_arbace_j2g_dyncf_A_const_141 = A_arbace_j2g_dyncf_A_const_pool.A[381]; A_arbace_j2g_dyncf_A_const_142 = A_arbace_j2g_dyncf_A_const_pool.A[382]; A_arbace_j2g_dyncf_A_const_143 = A_arbace_j2g_dyncf_A_const_pool.A[383]; A_arbace_j2g_dyncf_A_const_144 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[384]); A_arbace_j2g_dyncf_A_const_145 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[385]); A_arbace_j2g_dyncf_A_const_146 = A_arbace_j2g_dyncf_A_const_pool.A[386]; A_arbace_j2g_dyncf_A_const_147 = A_arbace_j2g_dyncf_A_const_pool.A[387]; A_arbace_j2g_dyncf_A_const_148 = A_arbace_j2g_dyncf_A_const_pool.A[388]; A_arbace_j2g_dyncf_A_const_149 = A_arbace_j2g_dyncf_A_const_pool.A[389] }

func A_arbace_j2g_dyncf_A_clinit_p11() { A_arbace_j2g_dyncf_A_const_150 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[390]); A_arbace_j2g_dyncf_A_const_151 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[391]); A_arbace_j2g_dyncf_A_const_152 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[392]); A_arbace_j2g_dyncf_A_const_153 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[393]); A_arbace_j2g_dyncf_A_const_154 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[394]); A_arbace_j2g_dyncf_A_const_155 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[395]); A_arbace_j2g_dyncf_A_const_156 = A_arbace_j2g_dyncf_A_const_pool.A[396]; A_arbace_j2g_dyncf_A_const_157 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[397]); A_arbace_j2g_dyncf_A_const_158 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[398]); A_arbace_j2g_dyncf_A_const_159 = A_arbace_j2g_dyncf_A_const_pool.A[399]; A_arbace_j2g_dyncf_A_const_160 = A_arbace_j2g_dyncf_A_const_pool.A[400]; A_arbace_j2g_dyncf_A_const_161 = A_arbace_j2g_dyncf_A_const_pool.A[401]; A_arbace_j2g_dyncf_A_const_162 = A_arbace_j2g_dyncf_A_const_pool.A[402] }

func A_arbace_j2g_dyncf_A_clinit_p12() { A_arbace_j2g_dyncf_A_const_163 = A_arbace_j2g_dyncf_A_const_pool.A[403]; A_arbace_j2g_dyncf_A_const_164 = A_arbace_j2g_dyncf_A_const_pool.A[404]; A_arbace_j2g_dyncf_A_const_165 = A_arbace_j2g_dyncf_A_const_pool.A[405]; A_arbace_j2g_dyncf_A_const_166 = A_arbace_j2g_dyncf_A_const_pool.A[406]; A_arbace_j2g_dyncf_A_const_167 = A_arbace_j2g_dyncf_A_const_pool.A[407]; A_arbace_j2g_dyncf_A_const_168 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[408]); A_arbace_j2g_dyncf_A_const_169 = A_arbace_j2g_dyncf_A_const_pool.A[409]; A_arbace_j2g_dyncf_A_const_170 = A_arbace_j2g_dyncf_A_const_pool.A[410]; A_arbace_j2g_dyncf_A_const_171 = A_arbace_j2g_dyncf_A_const_pool.A[411]; A_arbace_j2g_dyncf_A_const_172 = A_arbace_j2g_dyncf_A_const_pool.A[412]; A_arbace_j2g_dyncf_A_const_173 = A_arbace_j2g_dyncf_A_const_pool.A[413]; A_arbace_j2g_dyncf_A_const_174 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[414]); A_arbace_j2g_dyncf_A_const_175 = A_arbace_j2g_dyncf_A_const_pool.A[415]; A_arbace_j2g_dyncf_A_const_176 = A_arbace_j2g_dyncf_A_const_pool.A[416]; A_arbace_j2g_dyncf_A_const_177 = A_arbace_j2g_dyncf_A_const_pool.A[417] }

func A_arbace_j2g_dyncf_A_clinit_p13() { A_arbace_j2g_dyncf_A_const_178 = A_arbace_j2g_dyncf_A_const_pool.A[418]; A_arbace_j2g_dyncf_A_const_179 = A_arbace_j2g_dyncf_A_const_pool.A[419]; A_arbace_j2g_dyncf_A_const_180 = A_arbace_j2g_dyncf_A_const_pool.A[420]; A_arbace_j2g_dyncf_A_const_181 = A_arbace_j2g_dyncf_A_const_pool.A[421]; A_arbace_j2g_dyncf_A_const_182 = A_arbace_j2g_dyncf_A_const_pool.A[422]; A_arbace_j2g_dyncf_A_const_183 = A_arbace_j2g_dyncf_A_const_pool.A[423]; A_arbace_j2g_dyncf_A_const_184 = A_arbace_j2g_dyncf_A_const_pool.A[424]; A_arbace_j2g_dyncf_A_const_185 = A_arbace_j2g_dyncf_A_const_pool.A[425]; A_arbace_j2g_dyncf_A_const_186 = A_arbace_j2g_dyncf_A_const_pool.A[426]; A_arbace_j2g_dyncf_A_const_187 = A_arbace_j2g_dyncf_A_const_pool.A[427]; A_arbace_j2g_dyncf_A_const_188 = A_arbace_j2g_dyncf_A_const_pool.A[428]; A_arbace_j2g_dyncf_A_const_189 = A_arbace_j2g_dyncf_A_const_pool.A[429]; A_arbace_j2g_dyncf_A_const_190 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[430]); A_arbace_j2g_dyncf_A_const_191 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[431]); A_arbace_j2g_dyncf_A_const_192 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[432]) }

func A_arbace_j2g_dyncf_A_clinit_p14() { A_arbace_j2g_dyncf_A_const_193 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[433]); A_arbace_j2g_dyncf_A_const_194 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[434]); A_arbace_j2g_dyncf_A_const_195 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[435]); A_arbace_j2g_dyncf_A_const_196 = A_arbace_j2g_dyncf_A_const_pool.A[436]; A_arbace_j2g_dyncf_A_const_197 = A_arbace_j2g_dyncf_A_const_pool.A[437]; A_arbace_j2g_dyncf_A_const_198 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[438]); A_arbace_j2g_dyncf_A_const_199 = A_arbace_j2g_dyncf_A_const_pool.A[439]; A_arbace_j2g_dyncf_A_const_200 = A_arbace_j2g_dyncf_A_const_pool.A[440]; A_arbace_j2g_dyncf_A_const_201 = A_arbace_j2g_dyncf_A_const_pool.A[441]; A_arbace_j2g_dyncf_A_const_202 = A_arbace_j2g_dyncf_A_const_pool.A[442]; A_arbace_j2g_dyncf_A_const_203 = A_arbace_j2g_dyncf_A_const_pool.A[443]; A_arbace_j2g_dyncf_A_const_204 = A_arbace_j2g_dyncf_A_const_pool.A[444]; A_arbace_j2g_dyncf_A_const_205 = A_arbace_j2g_dyncf_A_const_pool.A[445]; A_arbace_j2g_dyncf_A_const_206 = A_arbace_j2g_dyncf_A_const_pool.A[446] }

func A_arbace_j2g_dyncf_A_clinit_p15() { A_arbace_j2g_dyncf_A_const_207 = A_arbace_j2g_dyncf_A_const_pool.A[447]; A_arbace_j2g_dyncf_A_const_208 = A_arbace_j2g_dyncf_A_const_pool.A[448]; A_arbace_j2g_dyncf_A_const_209 = A_arbace_j2g_dyncf_A_const_pool.A[449]; A_arbace_j2g_dyncf_A_const_210 = A_arbace_j2g_dyncf_A_const_pool.A[450]; A_arbace_j2g_dyncf_A_const_211 = A_arbace_j2g_dyncf_A_const_pool.A[451]; A_arbace_j2g_dyncf_A_const_212 = A_arbace_j2g_dyncf_A_const_pool.A[452]; A_arbace_j2g_dyncf_A_const_213 = A_arbace_j2g_dyncf_A_const_pool.A[453]; A_arbace_j2g_dyncf_A_const_214 = A_arbace_j2g_dyncf_A_const_pool.A[454]; A_arbace_j2g_dyncf_A_const_215 = A_arbace_j2g_dyncf_A_const_pool.A[455]; A_arbace_j2g_dyncf_A_const_216 = A_arbace_j2g_dyncf_A_const_pool.A[456]; A_arbace_j2g_dyncf_A_const_217 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[457]); A_arbace_j2g_dyncf_A_const_218 = A_arbace_j2g_dyncf_A_const_pool.A[458]; A_arbace_j2g_dyncf_A_const_219 = A_arbace_j2g_dyncf_A_const_pool.A[459]; A_arbace_j2g_dyncf_A_const_220 = A_arbace_j2g_dyncf_A_const_pool.A[460]; A_arbace_j2g_dyncf_A_const_221 = A_arbace_j2g_dyncf_A_const_pool.A[461] }

func A_arbace_j2g_dyncf_A_clinit_p16() { A_arbace_j2g_dyncf_A_const_222 = A_arbace_j2g_dyncf_A_const_pool.A[462]; A_arbace_j2g_dyncf_A_const_223 = A_arbace_j2g_dyncf_A_const_pool.A[463]; A_arbace_j2g_dyncf_A_const_224 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[464]); A_arbace_j2g_dyncf_A_const_225 = A_arbace_j2g_dyncf_A_const_pool.A[465]; A_arbace_j2g_dyncf_A_const_226 = A_arbace_j2g_dyncf_A_const_pool.A[466]; A_arbace_j2g_dyncf_A_const_227 = A_arbace_j2g_dyncf_A_const_pool.A[467]; A_arbace_j2g_dyncf_A_const_228 = A_arbace_j2g_dyncf_A_const_pool.A[468]; A_arbace_j2g_dyncf_A_const_229 = A_arbace_j2g_dyncf_A_const_pool.A[469]; A_arbace_j2g_dyncf_A_const_230 = A_arbace_j2g_dyncf_A_const_pool.A[470]; A_arbace_j2g_dyncf_A_const_231 = A_arbace_j2g_dyncf_A_const_pool.A[471]; A_arbace_j2g_dyncf_A_const_232 = A_arbace_j2g_dyncf_A_const_pool.A[472]; A_arbace_j2g_dyncf_A_const_233 = A_arbace_j2g_dyncf_A_const_pool.A[473]; A_arbace_j2g_dyncf_A_const_234 = A_arbace_j2g_dyncf_A_const_pool.A[474]; A_arbace_j2g_dyncf_A_const_235 = A_arbace_j2g_dyncf_A_const_pool.A[475]; A_arbace_j2g_dyncf_A_const_236 = A_arbace_j2g_dyncf_A_const_pool.A[476] }

func A_arbace_j2g_dyncf_A_clinit_p17() { A_arbace_j2g_dyncf_A_const_237 = A_arbace_j2g_dyncf_A_const_pool.A[477]; A_arbace_j2g_dyncf_A_const_238 = A_arbace_j2g_dyncf_A_const_pool.A[478]; A_arbace_j2g_dyncf_A_const_239 = A_arbace_j2g_dyncf_A_const_pool.A[479]; A_arbace_j2g_dyncf_A_const_240 = A_arbace_j2g_dyncf_A_const_pool.A[480]; A_arbace_j2g_dyncf_A_const_241 = A_arbace_j2g_dyncf_A_const_pool.A[481]; A_arbace_j2g_dyncf_A_const_242 = A_arbace_j2g_dyncf_A_const_pool.A[482]; A_arbace_j2g_dyncf_A_const_243 = A_arbace_j2g_dyncf_A_const_pool.A[483]; A_arbace_j2g_dyncf_A_const_244 = A_arbace_j2g_dyncf_A_const_pool.A[484]; A_arbace_j2g_dyncf_A_const_245 = A_arbace_j2g_dyncf_A_const_pool.A[485]; A_arbace_j2g_dyncf_A_const_246 = A_arbace_j2g_dyncf_A_const_pool.A[486]; A_arbace_j2g_dyncf_A_const_247 = A_arbace_j2g_dyncf_A_const_pool.A[487]; A_arbace_j2g_dyncf_A_const_248 = A_arbace_j2g_dyncf_A_const_pool.A[488]; A_arbace_j2g_dyncf_A_const_249 = A_arbace_j2g_dyncf_A_const_pool.A[489]; A_arbace_j2g_dyncf_A_const_250 = A_arbace_j2g_dyncf_A_const_pool.A[490]; A_arbace_j2g_dyncf_A_const_251 = A_arbace_j2g_dyncf_A_const_pool.A[491]; A_arbace_j2g_dyncf_A_const_252 = A_arbace_j2g_dyncf_A_const_pool.A[492] }

func A_arbace_j2g_dyncf_A_clinit_p18() { A_arbace_j2g_dyncf_A_const_253 = A_arbace_j2g_dyncf_A_const_pool.A[493]; A_arbace_j2g_dyncf_A_const_254 = A_arbace_j2g_dyncf_A_const_pool.A[494]; A_arbace_j2g_dyncf_A_const_255 = A_arbace_j2g_dyncf_A_const_pool.A[495]; A_arbace_j2g_dyncf_A_const_256 = A_arbace_j2g_dyncf_A_const_pool.A[496]; A_arbace_j2g_dyncf_A_const_257 = A_arbace_j2g_dyncf_A_const_pool.A[497]; A_arbace_j2g_dyncf_A_const_258 = A_arbace_j2g_dyncf_A_const_pool.A[498]; A_arbace_j2g_dyncf_A_const_259 = A_arbace_j2g_dyncf_A_const_pool.A[499]; A_arbace_j2g_dyncf_A_const_260 = A_arbace_j2g_dyncf_A_const_pool.A[500]; A_arbace_j2g_dyncf_A_const_261 = A_arbace_j2g_dyncf_A_const_pool.A[501]; A_arbace_j2g_dyncf_A_const_262 = A_arbace_j2g_dyncf_A_const_pool.A[502]; A_arbace_j2g_dyncf_A_const_263 = A_arbace_j2g_dyncf_A_const_pool.A[503]; A_arbace_j2g_dyncf_A_const_264 = A_arbace_j2g_dyncf_A_const_pool.A[504]; A_arbace_j2g_dyncf_A_const_265 = A_arbace_j2g_dyncf_A_const_pool.A[505]; A_arbace_j2g_dyncf_A_const_266 = A_arbace_j2g_dyncf_A_const_pool.A[506]; A_arbace_j2g_dyncf_A_const_267 = A_arbace_j2g_dyncf_A_const_pool.A[507]; A_arbace_j2g_dyncf_A_const_268 = A_arbace_j2g_dyncf_A_const_pool.A[508] }

func A_arbace_j2g_dyncf_A_clinit_p19() { A_arbace_j2g_dyncf_A_const_269 = A_arbace_j2g_dyncf_A_const_pool.A[509]; A_arbace_j2g_dyncf_A_const_270 = A_arbace_j2g_dyncf_A_const_pool.A[510]; A_arbace_j2g_dyncf_A_const_271 = A_arbace_j2g_dyncf_A_const_pool.A[511]; A_arbace_j2g_dyncf_A_const_272 = A_arbace_j2g_dyncf_A_const_pool.A[512]; A_arbace_j2g_dyncf_A_const_273 = A_arbace_j2g_dyncf_A_const_pool.A[513]; A_arbace_j2g_dyncf_A_const_274 = A_arbace_j2g_dyncf_A_const_pool.A[514]; A_arbace_j2g_dyncf_A_const_275 = A_arbace_j2g_dyncf_A_const_pool.A[515]; A_arbace_j2g_dyncf_A_const_276 = A_arbace_j2g_dyncf_A_const_pool.A[516]; A_arbace_j2g_dyncf_A_const_277 = A_arbace_j2g_dyncf_A_const_pool.A[517]; A_arbace_j2g_dyncf_A_const_278 = A_arbace_j2g_dyncf_A_const_pool.A[518]; A_arbace_j2g_dyncf_A_const_279 = A_arbace_j2g_dyncf_A_const_pool.A[519]; A_arbace_j2g_dyncf_A_const_280 = A_arbace_j2g_dyncf_A_const_pool.A[520]; A_arbace_j2g_dyncf_A_const_281 = A_arbace_j2g_dyncf_A_const_pool.A[521]; A_arbace_j2g_dyncf_A_const_282 = A_arbace_j2g_dyncf_A_const_pool.A[522]; A_arbace_j2g_dyncf_A_const_283 = A_arbace_j2g_dyncf_A_const_pool.A[523]; A_arbace_j2g_dyncf_A_const_284 = A_arbace_j2g_dyncf_A_const_pool.A[524] }

func A_arbace_j2g_dyncf_A_clinit_p20() { A_arbace_j2g_dyncf_A_const_285 = A_arbace_j2g_dyncf_A_const_pool.A[525]; A_arbace_j2g_dyncf_A_const_286 = A_arbace_j2g_dyncf_A_const_pool.A[526]; A_arbace_j2g_dyncf_A_const_287 = A_arbace_j2g_dyncf_A_const_pool.A[527]; A_arbace_j2g_dyncf_A_const_288 = A_arbace_j2g_dyncf_A_const_pool.A[528]; A_arbace_j2g_dyncf_A_const_289 = A_arbace_j2g_dyncf_A_const_pool.A[529]; A_arbace_j2g_dyncf_A_const_290 = A_arbace_j2g_dyncf_A_const_pool.A[530]; A_arbace_j2g_dyncf_A_const_291 = A_arbace_j2g_dyncf_A_const_pool.A[531]; A_arbace_j2g_dyncf_A_const_292 = A_arbace_j2g_dyncf_A_const_pool.A[532]; A_arbace_j2g_dyncf_A_const_293 = A_arbace_j2g_dyncf_A_const_pool.A[533]; A_arbace_j2g_dyncf_A_const_294 = A_arbace_j2g_dyncf_A_const_pool.A[534]; A_arbace_j2g_dyncf_A_const_295 = A_arbace_j2g_dyncf_A_const_pool.A[535]; A_arbace_j2g_dyncf_A_const_296 = A_arbace_j2g_dyncf_A_const_pool.A[536]; A_arbace_j2g_dyncf_A_const_297 = A_arbace_j2g_dyncf_A_const_pool.A[537]; A_arbace_j2g_dyncf_A_const_298 = A_arbace_j2g_dyncf_A_const_pool.A[538]; A_arbace_j2g_dyncf_A_const_299 = A_arbace_j2g_dyncf_A_const_pool.A[539]; A_arbace_j2g_dyncf_A_const_300 = A_arbace_j2g_dyncf_A_const_pool.A[540] }

func A_arbace_j2g_dyncf_A_clinit_p21() { A_arbace_j2g_dyncf_A_const_301 = A_arbace_j2g_dyncf_A_const_pool.A[541]; A_arbace_j2g_dyncf_A_const_302 = A_arbace_j2g_dyncf_A_const_pool.A[542]; A_arbace_j2g_dyncf_A_const_303 = A_arbace_j2g_dyncf_A_const_pool.A[543]; A_arbace_j2g_dyncf_A_const_304 = A_arbace_j2g_dyncf_A_const_pool.A[544]; A_arbace_j2g_dyncf_A_const_305 = A_arbace_j2g_dyncf_A_const_pool.A[545]; A_arbace_j2g_dyncf_A_const_306 = A_arbace_j2g_dyncf_A_const_pool.A[546]; A_arbace_j2g_dyncf_A_const_307 = A_arbace_j2g_dyncf_A_const_pool.A[547]; A_arbace_j2g_dyncf_A_const_308 = A_arbace_j2g_dyncf_A_const_pool.A[548]; A_arbace_j2g_dyncf_A_const_309 = A_arbace_j2g_dyncf_A_const_pool.A[549]; A_arbace_j2g_dyncf_A_const_310 = A_arbace_j2g_dyncf_A_const_pool.A[550]; A_arbace_j2g_dyncf_A_const_311 = A_arbace_j2g_dyncf_A_const_pool.A[551]; A_arbace_j2g_dyncf_A_const_312 = A_arbace_j2g_dyncf_A_const_pool.A[552]; A_arbace_j2g_dyncf_A_const_313 = A_arbace_j2g_dyncf_A_const_pool.A[553]; A_arbace_j2g_dyncf_A_const_314 = A_arbace_j2g_dyncf_A_const_pool.A[554]; A_arbace_j2g_dyncf_A_const_315 = A_arbace_j2g_dyncf_A_const_pool.A[555]; A_arbace_j2g_dyncf_A_const_316 = A_arbace_j2g_dyncf_A_const_pool.A[556] }

func A_arbace_j2g_dyncf_A_clinit_p22() { A_arbace_j2g_dyncf_A_const_317 = A_arbace_j2g_dyncf_A_const_pool.A[557]; A_arbace_j2g_dyncf_A_const_318 = A_arbace_j2g_dyncf_A_const_pool.A[558]; A_arbace_j2g_dyncf_A_const_319 = A_arbace_j2g_dyncf_A_const_pool.A[559]; A_arbace_j2g_dyncf_A_const_320 = A_arbace_j2g_dyncf_A_const_pool.A[560]; A_arbace_j2g_dyncf_A_const_321 = A_arbace_j2g_dyncf_A_const_pool.A[561]; A_arbace_j2g_dyncf_A_const_322 = A_arbace_j2g_dyncf_A_const_pool.A[562]; A_arbace_j2g_dyncf_A_const_323 = A_arbace_j2g_dyncf_A_const_pool.A[563]; A_arbace_j2g_dyncf_A_const_324 = A_arbace_j2g_dyncf_A_const_pool.A[564]; A_arbace_j2g_dyncf_A_const_325 = A_arbace_j2g_dyncf_A_const_pool.A[565]; A_arbace_j2g_dyncf_A_const_326 = A_arbace_j2g_dyncf_A_const_pool.A[566]; A_arbace_j2g_dyncf_A_const_327 = A_arbace_j2g_dyncf_A_const_pool.A[567]; A_arbace_j2g_dyncf_A_const_328 = A_arbace_j2g_dyncf_A_const_pool.A[568]; A_arbace_j2g_dyncf_A_const_329 = A_arbace_j2g_dyncf_A_const_pool.A[569]; A_arbace_j2g_dyncf_A_const_330 = A_arbace_j2g_dyncf_A_const_pool.A[570]; A_arbace_j2g_dyncf_A_const_331 = A_arbace_j2g_dyncf_A_const_pool.A[571]; A_arbace_j2g_dyncf_A_const_332 = A_arbace_j2g_dyncf_A_const_pool.A[572] }

func A_arbace_j2g_dyncf_A_clinit_p23() { A_arbace_j2g_dyncf_A_const_333 = A_arbace_j2g_dyncf_A_const_pool.A[573]; A_arbace_j2g_dyncf_A_const_334 = A_arbace_j2g_dyncf_A_const_pool.A[574]; A_arbace_j2g_dyncf_A_const_335 = A_arbace_j2g_dyncf_A_const_pool.A[575]; A_arbace_j2g_dyncf_A_const_336 = A_arbace_j2g_dyncf_A_const_pool.A[576]; A_arbace_j2g_dyncf_A_const_337 = A_arbace_j2g_dyncf_A_const_pool.A[577]; A_arbace_j2g_dyncf_A_const_338 = A_arbace_j2g_dyncf_A_const_pool.A[578]; A_arbace_j2g_dyncf_A_const_339 = A_arbace_j2g_dyncf_A_const_pool.A[579]; A_arbace_j2g_dyncf_A_const_340 = A_arbace_j2g_dyncf_A_const_pool.A[580]; A_arbace_j2g_dyncf_A_const_341 = A_arbace_j2g_dyncf_A_const_pool.A[581]; A_arbace_j2g_dyncf_A_const_342 = A_arbace_j2g_dyncf_A_const_pool.A[582]; A_arbace_j2g_dyncf_A_const_343 = A_arbace_j2g_dyncf_A_const_pool.A[583]; A_arbace_j2g_dyncf_A_const_344 = A_arbace_j2g_dyncf_A_const_pool.A[584]; A_arbace_j2g_dyncf_A_const_345 = A_arbace_j2g_dyncf_A_const_pool.A[585]; A_arbace_j2g_dyncf_A_const_346 = A_arbace_j2g_dyncf_A_const_pool.A[586]; A_arbace_j2g_dyncf_A_const_347 = A_arbace_j2g_dyncf_A_const_pool.A[587]; A_arbace_j2g_dyncf_A_const_348 = A_arbace_j2g_dyncf_A_const_pool.A[588] }

func A_arbace_j2g_dyncf_A_clinit_p24() { A_arbace_j2g_dyncf_A_const_349 = A_arbace_j2g_dyncf_A_const_pool.A[589]; A_arbace_j2g_dyncf_A_const_350 = A_arbace_j2g_dyncf_A_const_pool.A[590]; A_arbace_j2g_dyncf_A_const_351 = A_arbace_j2g_dyncf_A_const_pool.A[591]; A_arbace_j2g_dyncf_A_const_352 = A_arbace_j2g_dyncf_A_const_pool.A[592]; A_arbace_j2g_dyncf_A_const_353 = A_arbace_j2g_dyncf_A_const_pool.A[593]; A_arbace_j2g_dyncf_A_const_354 = A_arbace_j2g_dyncf_A_const_pool.A[594]; A_arbace_j2g_dyncf_A_const_355 = A_arbace_j2g_dyncf_A_const_pool.A[595]; A_arbace_j2g_dyncf_A_const_356 = A_arbace_j2g_dyncf_A_const_pool.A[596]; A_arbace_j2g_dyncf_A_const_357 = A_arbace_j2g_dyncf_A_const_pool.A[597]; A_arbace_j2g_dyncf_A_const_358 = A_arbace_j2g_dyncf_A_const_pool.A[598]; A_arbace_j2g_dyncf_A_const_359 = A_arbace_j2g_dyncf_A_const_pool.A[599]; A_arbace_j2g_dyncf_A_const_360 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[600]); A_arbace_j2g_dyncf_A_const_361 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[601]); A_arbace_j2g_dyncf_A_const_362 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[602]) }

func A_arbace_j2g_dyncf_A_clinit_p25() { A_arbace_j2g_dyncf_A_const_363 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[603]); A_arbace_j2g_dyncf_A_const_364 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[604]); A_arbace_j2g_dyncf_A_const_365 = A_arbace_j2g_dyncf_A_const_pool.A[605]; A_arbace_j2g_dyncf_A_const_366 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[606]); A_arbace_j2g_dyncf_A_const_367 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[607]); A_arbace_j2g_dyncf_A_const_368 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[608]); A_arbace_j2g_dyncf_A_const_369 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[609]); A_arbace_j2g_dyncf_A_const_370 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[610]); A_arbace_j2g_dyncf_A_const_371 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[611]); A_arbace_j2g_dyncf_A_const_372 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[612]); A_arbace_j2g_dyncf_A_const_373 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[613]); A_arbace_j2g_dyncf_A_const_374 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[614]) }

func A_arbace_j2g_dyncf_A_clinit_p26() { A_arbace_j2g_dyncf_A_const_375 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[615]); A_arbace_j2g_dyncf_A_const_376 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[616]); A_arbace_j2g_dyncf_A_const_377 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[617]); A_arbace_j2g_dyncf_A_const_378 = A_arbace_j2g_dyncf_A_const_pool.A[618]; A_arbace_j2g_dyncf_A_const_379 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[619]); A_arbace_j2g_dyncf_A_const_380 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[620]); A_arbace_j2g_dyncf_A_const_381 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[621]); A_arbace_j2g_dyncf_A_const_382 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[622]); A_arbace_j2g_dyncf_A_const_383 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[623]); A_arbace_j2g_dyncf_A_const_384 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[624]); A_arbace_j2g_dyncf_A_const_385 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[625]); A_arbace_j2g_dyncf_A_const_386 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[626]) }

func A_arbace_j2g_dyncf_A_clinit_p27() { A_arbace_j2g_dyncf_A_const_387 = A_arbace_j2g_dyncf_A_const_pool.A[627]; A_arbace_j2g_dyncf_A_const_388 = A_arbace_j2g_dyncf_A_const_pool.A[628]; A_arbace_j2g_dyncf_A_const_389 = A_arbace_j2g_dyncf_A_const_pool.A[629]; A_arbace_j2g_dyncf_A_const_390 = A_arbace_j2g_dyncf_A_const_pool.A[630]; A_arbace_j2g_dyncf_A_const_391 = A_arbace_j2g_dyncf_A_const_pool.A[631]; A_arbace_j2g_dyncf_A_const_392 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[632]); A_arbace_j2g_dyncf_A_const_393 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[633]); A_arbace_j2g_dyncf_A_const_394 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[634]); A_arbace_j2g_dyncf_A_const_395 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[635]); A_arbace_j2g_dyncf_A_const_396 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[636]); A_arbace_j2g_dyncf_A_const_397 = A_arbace_j2g_dyncf_A_const_pool.A[637]; A_arbace_j2g_dyncf_A_const_398 = A_arbace_j2g_dyncf_A_const_pool.A[638]; A_arbace_j2g_dyncf_A_const_399 = A_arbace_j2g_dyncf_A_const_pool.A[639]; A_arbace_j2g_dyncf_A_const_400 = A_arbace_j2g_dyncf_A_const_pool.A[640] }

func A_arbace_j2g_dyncf_A_clinit_p28() { A_arbace_j2g_dyncf_A_const_401 = A_arbace_j2g_dyncf_A_const_pool.A[641]; A_arbace_j2g_dyncf_A_const_402 = A_arbace_j2g_dyncf_A_const_pool.A[642]; A_arbace_j2g_dyncf_A_const_403 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[643]); A_arbace_j2g_dyncf_A_const_404 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[644]); A_arbace_j2g_dyncf_A_const_405 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[645]); A_arbace_j2g_dyncf_A_const_406 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[646]); A_arbace_j2g_dyncf_A_const_407 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[647]); A_arbace_j2g_dyncf_A_const_408 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[648]); A_arbace_j2g_dyncf_A_const_409 = A_arbace_j2g_dyncf_A_const_pool.A[649]; A_arbace_j2g_dyncf_A_const_410 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[650]); A_arbace_j2g_dyncf_A_const_411 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[651]); A_arbace_j2g_dyncf_A_const_412 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[652]) }

func A_arbace_j2g_dyncf_A_clinit_p29() { A_arbace_j2g_dyncf_A_const_413 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[653]); A_arbace_j2g_dyncf_A_const_414 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[654]); A_arbace_j2g_dyncf_A_const_415 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[655]); A_arbace_j2g_dyncf_A_const_416 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[656]); A_arbace_j2g_dyncf_A_const_417 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[657]); A_arbace_j2g_dyncf_A_const_418 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[658]); A_arbace_j2g_dyncf_A_const_419 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[659]); A_arbace_j2g_dyncf_A_const_420 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[660]) }

func A_arbace_j2g_dyncf_A_New() *A_arbace_j2g_dyncf_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_A_class }

func (t *A_arbace_j2g_dyncf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_A); return ok }

func A_arbace_j2g_dyncf_A_Cast(x any) *A_arbace_j2g_dyncf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_A_class)) }; return v }



type A_arbace_j2g_dyncf_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000004_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000004_A_New() *A_arbace_j2g_dyncf_eval292000004_A { t := &A_arbace_j2g_dyncf_eval292000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000004_A_class }

func (t *A_arbace_j2g_dyncf_eval292000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); return ok }

func A_arbace_j2g_dyncf_eval292000004_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000004_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000008_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000008_A_New() *A_arbace_j2g_dyncf_eval292000008_A { t := &A_arbace_j2g_dyncf_eval292000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000008_A_class }

func (t *A_arbace_j2g_dyncf_eval292000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); return ok }

func A_arbace_j2g_dyncf_eval292000008_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000008_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000008_fn__292000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_from_object_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_from_object_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A struct{ j2g_header uint64; F_iter__292000214, F_s__292000215 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A struct{ j2g_header uint64; F_b__292000217 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_fn__292000221_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A struct{ j2g_header uint64; F_iter__292000223, F_s__292000224 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A struct{ j2g_header uint64; F_b__292000226 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000220_iter__292000223__292000227_fn__292000228_fn__292000229_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_fn__292000234_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A struct{ j2g_header uint64; F_iter__292000236, F_s__292000237 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A struct{ j2g_header uint64; F_b__292000239 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000214__292000218_fn__292000219_iter__292000236__292000240_fn__292000241_fn__292000242_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A struct{ j2g_header uint64; F_extendable any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A struct{ j2g_header uint64; F_extendable, F_iter__292000248, F_s__292000249 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A struct{ j2g_header uint64; F_b__292000251, F_extendable any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_fn__292000255_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A struct{ j2g_header uint64; F_iter__292000258, F_s__292000259 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A struct{ j2g_header uint64; F_b__292000261 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000258__292000262_fn__292000263_fn__292000264_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A struct{ j2g_header uint64; F_iter__292000268, F_s__292000269 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__292000271 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000254_iter__292000268__292000272_fn__292000273_fn__292000274_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_fn__292000279_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A struct{ j2g_header uint64; F_iter__292000282, F_s__292000283 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A struct{ j2g_header uint64; F_b__292000285 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000282__292000286_fn__292000287_fn__292000288_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A struct{ j2g_header uint64; F_iter__292000292, F_s__292000293 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A struct{ j2g_header uint64; F_b__292000295 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000248__292000252_fn__292000253_iter__292000292__292000296_fn__292000297_fn__292000298_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A struct{ j2g_header uint64; F_iter__292000304, F_s__292000305 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A struct{ j2g_header uint64; F_b__292000307 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A struct{ j2g_header uint64; F_iter__292000311, F_s__292000312 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A struct{ j2g_header uint64; F_b__292000314 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000317_fn__292000318_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_fn__292000310_iter__292000311__292000315_fn__292000316_fn__292000321_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A struct{ j2g_header uint64; F_iter__292000326, F_s__292000327 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A struct{ j2g_header uint64; F_b__292000329 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000332_fn__292000333_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_dyncf_generics_text_iter__292000304__292000308_fn__292000309_iter__292000326__292000330_fn__292000331_fn__292000336_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A struct{ j2g_header uint64; F_tset any }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A struct{ j2g_header uint64; F_tset, F_iter__292000342, F_s__292000343 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A struct{ j2g_header uint64; F_b__292000345, F_tset any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A struct{ j2g_header uint64; F_iter__292000352, F_s__292000353 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A struct{ j2g_header uint64; F_b__292000355 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_fn__292000348_iter__292000352__292000356_fn__292000357_fn__292000358_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A struct{ j2g_header uint64; F_iter__292000366, F_s__292000367 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A struct{ j2g_header uint64; F_b__292000369 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000342__292000346_fn__292000347_iter__292000366__292000370_fn__292000371_fn__292000372_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A struct{ j2g_header uint64; F_iter__292000378, F_s__292000379 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__292000381 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000378__292000382_fn__292000383_fn__292000384_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A struct{ j2g_header uint64; F_iter__292000394, F_s__292000395 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A struct{ j2g_header uint64; F_b__292000397 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000394__292000398_fn__292000399_fn__292000400_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A struct{ j2g_header uint64; F_iter__292000410, F_s__292000411 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A struct{ j2g_header uint64; F_b__292000413 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000410__292000414_fn__292000415_fn__292000416_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_chain_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A struct{ j2g_header uint64; F_iter__292000120, F_s__292000121 any }

var A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A struct{ j2g_header uint64; F_iter__292000122, F_s__292000123 any }

var A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A struct{ j2g_header uint64; F_b__292000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_chain_iter__292000120__292000126_fn__292000127_iter__292000122__292000128_fn__292000129_fn__292000130_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_field_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_field_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A struct{ j2g_header uint64; F_iter__292000137, F_s__292000138 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A struct{ j2g_header uint64; F_b__292000140 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A struct{ j2g_header uint64; F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A struct{ j2g_header uint64; F_prot_QMARK_, F_iter__292000146, F_s__292000147 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A struct{ j2g_header uint64; F_b__292000149, F_prot_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000146__292000150_fn__292000151_fn__292000152_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A struct{ j2g_header uint64; F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A struct{ j2g_header uint64; F_iter__292000156, F_prot_QMARK_, F_s__292000157 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A struct{ j2g_header uint64; F_b__292000159, F_prot_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000156__292000160_fn__292000161_fn__292000162_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A struct{ j2g_header uint64; F_iter__292000166, F_s__292000167 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A struct{ j2g_header uint64; F_b__292000169 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_iter__292000166__292000170_fn__292000171_fn__292000172_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_fn__292000143_prot_QMARK___292000144_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A struct{ j2g_header uint64; F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A struct{ j2g_header uint64; F_iter__292000180, F_s__292000181, F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A struct{ j2g_header uint64; F_prot_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__292000183 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000180__292000184_fn__292000185_fn__292000186_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A struct{ j2g_header uint64; F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A struct{ j2g_header uint64; F_iter__292000190, F_s__292000191, F_prot_QMARK_ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A struct{ j2g_header uint64; F_prot_QMARK_ any; F_size__1927001038__auto__ int32; F_b__292000193, F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000190__292000194_fn__292000195_fn__292000196_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A struct{ j2g_header uint64; F_iter__292000200, F_s__292000201 any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A struct{ j2g_header uint64; F_b__292000203 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_iter__292000200__292000204_fn__292000205_fn__292000206_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_protected_members_iter__292000137__292000141_fn__292000142_prot_QMARK___292000178_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_fn__292000116_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_fn__292000116_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000017, F_s__292000018 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A struct{ j2g_header uint64; F_b__292000020, F_recv, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000043, F_s__292000044 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A struct{ j2g_header uint64; F_recv, F_b__292000046, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A struct{ j2g_header uint64; F_recv, F_seen any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A struct{ j2g_header uint64; F_recv, F_iter__292000077, F_seen, F_s__292000078 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A struct{ j2g_header uint64; F_recv, F_seen, F_c any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A struct{ j2g_header uint64; F_recv, F_s__292000080, F_seen, F_iter__292000079, F_c any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A struct{ j2g_header uint64; F_recv, F_seen any; F_size__1927001038__auto__ int32; F_b__292000082, F_c__1927001037__auto__, F_c any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000077__292000083_fn__292000084_iter__292000079__292000085_fn__292000086_fn__292000087_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A struct{ j2g_header uint64; F_iter__292000094, F_s__292000095 any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A struct{ j2g_header uint64; F_b__292000097 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000094__292000098_fn__292000099_fn__292000100_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A struct{ j2g_header uint64; F_iter__292000104, F_s__292000105 any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A struct{ j2g_header uint64; F_b__292000107 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000104__292000108_fn__292000109_fn__292000110_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_tag_A_fn_class *jrt.Class
