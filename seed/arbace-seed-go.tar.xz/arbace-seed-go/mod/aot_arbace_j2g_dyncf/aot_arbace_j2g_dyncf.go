//line aot_arbace_j2g_dyncf.ae:1
package aot_arbace_j2g_dyncf

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_dyn"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/aot_arbace_walk"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_New() *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyncf_A_const_11); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_1, A_arbace_j2g_dyncf_A_const_2, A_arbace_j2g_dyncf_A_const_3, A_arbace_j2g_dyncf_A_const_4, A_arbace_j2g_dyncf_A_const_5, A_arbace_j2g_dyncf_A_const_6, A_arbace_j2g_dyncf_A_const_7, A_arbace_j2g_dyncf_A_const_8, A_arbace_j2g_dyncf_A_const_9); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_New() *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_eval292000008_fn__292000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyncf_eval292000008_fn__292000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_12.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_j2g_dyncf_A_const_13.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_j2g_dyncf_A_const_14; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyncf_A_const_15.GetRawRoot__O(), A_arbace_j2g_dyncf_A_const_16) }



















func A_arbace_j2g_dyncf_enabled_QMARK__A_New() *A_arbace_j2g_dyncf_enabled_QMARK__A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_enabled_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_j2g_dyncf_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_27 any = A_arbace_j2g_dyncf_A_const_17.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = A_arbace_j2g_dyncf_A_const_18.GetRawRoot__O(); if linked_28 == nil { return ifn_29.Invoke_O__O(arg_30) } else { return linked_28.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_27, arg_30)
	} }
func A_arbace_j2g_dyncf_tag_A_New() *A_arbace_j2g_dyncf_tag_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_tag_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_dyncf_tag_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_dyncf_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_31 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = sym__0; var arg_35 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyncf_A_const_20, type__1)); if linked_32 == nil { return ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { return linked_32.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) } }

func A_arbace_j2g_dyncf_native_name_A_New() *A_arbace_j2g_dyncf_native_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_native_name_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_j2g_dyncf_native_name_A) Ctor() {}
//line :28:1
func (t *A_arbace_j2g_dyncf_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var root_45 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_56, nil, Lit_57); var tmp2 any; var root_36 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_j2g_dyncf_A_const_18.GetRawRoot__O(); if linked_37 == nil { tmp2 = ifn_38.Invoke_O__O(arg_39) } else { tmp2 = linked_37.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_36, arg_39) }; var tmp3 any = tmp2; var tmp4 any; var root_40 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = mname__0; var arg_44 any = desc__1; if linked_41 == nil { tmp4 = ifn_42.Invoke_O_O__O(arg_43, arg_44) } else { tmp4 = linked_41.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_40, arg_43, arg_44) }; arg_48 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref(); if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_45, arg_48)
	}
}







func A_arbace_j2g_dyncf_sub_name_A_New() *A_arbace_j2g_dyncf_sub_name_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_name_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_dyncf_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_77, nil); var tmp2 any; var root_49 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = n__0; if linked_50 == nil { tmp2 = ifn_51.Invoke_O__O(arg_52) } else { tmp2 = linked_50.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_49, arg_52) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyncf_from_object_A_New() *A_arbace_j2g_dyncf_from_object_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_from_object_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_j2g_dyncf_from_object_A) Ctor() {}
//line :41:1
func (t *A_arbace_j2g_dyncf_from_object_A) Invoke_O_O_O__O(self, d__0, x__1 any) any {


	var tmp1 any; var root_53 any = A_arbace_j2g_dyncf_A_const_24.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = d__0; if linked_54 == nil { tmp1 = ifn_55.Invoke_O__O(arg_56) } else { tmp1 = linked_54.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_53, arg_56) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_27; var tmp4 any; var root_57 any = A_arbace_j2g_dyncf_A_const_28.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = A_arbace_j2g_dyncf_A_const_29; var arg_61 any = d__0; if linked_58 == nil { tmp4 = ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { tmp4 = linked_58.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_57, arg_60, arg_61) }; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_30; var tmp8 any; var root_62 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_64 lang.IFn
		if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_31.GetRawRoot__O()).Invoke_O__O(d__0))).Ref(); if linked_63 == nil { tmp8 = ifn_64.Invoke_O__O(arg_65) } else { tmp8 = linked_63.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_62, arg_65) }
//line :44:1
		return tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O__O(tmp7, tmp8, x__1)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_29) { return x__1 } else { if A_arbace_j2g_dyncf_A_const_26 != nil {


			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_32; var tmp12 any = A_arbace_j2g_dyncf_A_const_33; var tmp13 any; var root_66 any = A_arbace_j2g_dyncf_A_const_28.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = A_arbace_j2g_dyncf_A_const_29; var arg_70 any = d__0; if linked_67 == nil { tmp13 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { tmp13 = linked_67.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }; return tmp9.Invoke_O_O__O(tmp10.Invoke_O_O_O__O(tmp11, tmp12, tmp13), x__1) } else {
//line :44:1
				return nil
			}
		}
		}
}
func A_arbace_j2g_dyncf_sub_forms_A_New() *A_arbace_j2g_dyncf_sub_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_dyncf_sub_forms_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_71 any = A_arbace_j2g_dyncf_A_const_34.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_73 lang.IFn; if


	linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = n__0; if linked_72 == nil { g__2 = ifn_73.Invoke_O__O(arg_74) } else { g__2 = linked_72.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_71, arg_74) }; var recv__3 any; var tmp1 lang.IFn = /*line :49:1*/lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_36; var tmp3 any; var root_78 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_80 lang.IFn; if



	linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = g__2; if linked_79 == nil { tmp3 = ifn_80.Invoke_O__O(arg_81) } else { tmp3 = linked_79.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_78, arg_81) }; recv__3 = tmp1.Invoke_O_O__O(tmp2, tmp3); var root_87 any =
	A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_39, A_arbace_j2g_dyncf_A_const_40); if linked_88 == nil { ifn_89.Invoke_O__O(arg_90) } else { linked_88.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_87, arg_90) }; var tmp4 any; tmp50 := /*line :49:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyncf_A_const_41; var tmp7 any; var root_91 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_93 lang.IFn





		if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_92 == nil { tmp7 = ifn_93.Invoke_O__O(arg_94) } else { tmp7 = linked_92.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_91, arg_94) }
//line :49:1
		var tmp8 any = tmp7; var tmp9 any; var root_105 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_107 lang.IFn





		if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var tmp10 any; var root_95 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = A_arbace_j2g_dyncf_A_const_43; var arg_99 any = A_arbace_j2g_dyncf_A_const_44; if linked_96 == nil { tmp10 = ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { tmp10 = linked_96.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }; var tmp11 any = tmp10; var tmp12 any; var root_100 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = A_arbace_j2g_dyncf_A_const_45; var arg_104 any = A_arbace_j2g_dyncf_A_const_46; if linked_101 == nil { tmp12 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp12 = linked_101.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; arg_108 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12); var arg_109 any = A_arbace_j2g_dyncf_A_const_47; if linked_106 == nil { tmp9 = ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { tmp9 = linked_106.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) }
//line :49:1
		var tmp13 any = tmp9; var tmp14 any; var tmp15 any; var or__1927000174__auto____6 any; var root_110 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_112 lang.IFn






		if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = n__0; if linked_111 == nil { or__1927000174__auto____6 = ifn_112.Invoke_O__O(arg_113) } else { or__1927000174__auto____6 = linked_111.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_110, arg_113) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp15 = or__1927000174__auto____6 } else { var root_114 any = A_arbace_j2g_dyncf_A_const_49.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = n__0; if linked_115 == nil { tmp15 = ifn_116.Invoke_O__O(arg_117) } else { tmp15 = linked_115.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_114, arg_117) } }; if jrt.J2g_Truth(tmp15) { tmp14 = A_arbace_j2g_dyncf_A_const_50 } else {

			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp17 any; var root_118 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_j2g_dyncf_A_const_29; var arg_122 any = n__0; var arg_123 any = Lit_60; if linked_119 == nil { tmp17 = ifn_120.Invoke_O_O_O__O(arg_121, arg_122, arg_123) } else { tmp17 = linked_119.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_118, arg_121, arg_122, arg_123) }; tmp14 = tmp16.Invoke_O__O(tmp17) }
//line :49:1
		var tmp18 any = tmp14; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyncf_A_const_52; var tmp21 any = A_arbace_j2g_dyncf_A_const_56; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_57; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyncf_A_const_58; var tmp26 any; var root_124 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_126 lang.IFn









		if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = g__2; if linked_125 == nil { tmp26 = ifn_126.Invoke_O__O(arg_127) } else { tmp26 = linked_125.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_124, arg_127) }
//line :49:1
		var tmp27 any = tmp5.Invoke_O_O_O_O_O__O(tmp6, tmp8, tmp13, tmp18, tmp19.Invoke_O_O_O_O_O__O(tmp20, lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp22.Invoke_O_O__O(tmp23, tmp24.Invoke_O_O_O_O__O(tmp25, tmp26, A_arbace_j2g_dyncf_A_const_59, A_arbace_j2g_dyncf_A_const_60))), A_arbace_j2g_dyncf_A_const_53, A_arbace_j2g_dyncf_A_const_54, A_arbace_j2g_dyncf_A_const_55)); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyncf_A_const_61; var tmp30 any; var root_132 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_134 lang.IFn














		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var root_128 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_129 == nil { arg_135 = ifn_130.Invoke_O__O(arg_131) } else { arg_135 = linked_129.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_128, arg_131) }; var arg_136 any = A_arbace_j2g_dyncf_A_const_62; if linked_133 == nil { tmp30 = ifn_134.Invoke_O_O__O(arg_135, arg_136) } else { tmp30 = linked_133.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_132, arg_135, arg_136) }
//line :49:1
		var tmp31 any = tmp30; var tmp32 any; var root_420 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_422 lang.IFn















		if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_424 any = A_arbace_j2g_dyncf_A_const_64; var arg_425 any = A_arbace_j2g_dyncf_A_const_65; var arg_426 any; var iter__1927001039__auto____6 any; var tmp33 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(recv__3, n__0); var tmp34 *jrt.Class; var fncls__407 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class
		if fncls__407 == nil { var fncls__407d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class = fncls__407d; tmp34 = fncls__407d } else { tmp34 = fncls__407 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var tmp35 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp36 any; var tmp37 any; var root_408 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = n__0; if linked_409 == nil { tmp37 = ifn_410.Invoke_O__O(arg_411) } else { tmp37 = linked_409.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(tmp37) { var root_412 any = A_arbace_j2g_dyncf_A_const_104.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = n__0; if linked_413 == nil { tmp36 = ifn_414.Invoke_O__O(arg_415) } else { tmp36 = linked_413.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_412, arg_415) } } else { var tmp38 *lang.Keyword = A_arbace_j2g_dyncf_A_const_105; var tmp39 any; var root_416 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = n__0; if linked_417 == nil { tmp39 = ifn_418.Invoke_O__O(arg_419) } else { tmp39 = linked_417.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_416, arg_419) }; tmp36 = tmp38.Invoke_O__O(tmp39) }; arg_426 = tmp35.Invoke_O__O(tmp36)
//line :65:1
		if linked_421 == nil { tmp32 = ifn_422.Invoke_O_O_O_O__O(arg_423, arg_424, arg_425, arg_426) } else { tmp32 = linked_421.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_420, arg_423, arg_424, arg_425, arg_426) }
//line :49:1
		var tmp40 any = tmp28.Invoke_O_O_O__O(tmp29, tmp31, tmp32); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp42 any = A_arbace_j2g_dyncf_A_const_107; var tmp43 any; var root_431 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_433 lang.IFn






























		if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any; var root_427 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_428 == nil { arg_434 = ifn_429.Invoke_O__O(arg_430) } else { arg_434 = linked_428.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_427, arg_430) }; var arg_435 any = A_arbace_j2g_dyncf_A_const_108; if linked_432 == nil { tmp43 = ifn_433.Invoke_O_O__O(arg_434, arg_435) } else { tmp43 = linked_432.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_431, arg_434, arg_435) }
//line :49:1
		var tmp44 any = tmp43; var tmp45 any; var root_714 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_716 lang.IFn































		if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_718 any = A_arbace_j2g_dyncf_A_const_109; var arg_719 any = A_arbace_j2g_dyncf_A_const_110; var arg_720 any; var iter__1927001039__auto____6_2 any; var tmp46 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(recv__3, n__0); var tmp47 *jrt.Class; var fncls__704 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class
		if fncls__704 == nil { var fncls__704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class = fncls__704d; tmp47 = fncls__704d } else { tmp47 = fncls__704 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil); var tmp48 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6_2); var tmp49 any; var root_709 any = A_arbace_j2g_dyncf_A_const_139.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var arg_713 any; var root_705 any = A_arbace_j2g_dyncf_A_const_140.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = n__0; if linked_706 == nil { arg_713 = ifn_707.Invoke_O__O(arg_708) } else { arg_713 = linked_706.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_705, arg_708) }; if linked_710 == nil { tmp49 = ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { tmp49 = linked_710.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) }; arg_720 = tmp48.Invoke_O__O(tmp49)
//line :81:1
		if linked_715 == nil { tmp45 = ifn_716.Invoke_O_O_O_O__O(arg_717, arg_718, arg_719, arg_720) } else { tmp45 = linked_715.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_714, arg_717, arg_718, arg_719, arg_720) }
//line :49:1
		tmp4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp27, tmp40, tmp41.Invoke_O_O_O__O(tmp42, tmp44, tmp45)) }; return nil }(); var root_75 any = A_arbace_j2g_dyncf_A_const_35.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_77 lang.IFn; if




	linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; if linked_76 == nil { ifn_77.Invoke__O() } else { linked_76.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_75) }; if /*line :49:1*/ tmp50 != nil { panic(tmp50) }; return tmp4 }
















func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A) Invoke_O_O__O(self, s__292000018__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000018__1); var tmp2 *jrt.Class; var fncls__406 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class; if fncls__406 == nil { var fncls__406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class = fncls__406d; tmp2 = fncls__406d } else { tmp2 = fncls__406 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000017, c__s__292000018 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000017 = c__iter__292000017; t.F_s__292000018 = c__s__292000018 }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A) Invoke_O__O(self any) any { { var s__292000018__1 any; var t_ any = t.F_s__292000018; t.F_s__292000018 = nil; s__292000018__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_137 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = s__292000018__1; if linked_138 == nil { temp__1927000414__auto____2 = ifn_139.Invoke_O__O(arg_140) } else { temp__1927000414__auto____2 = linked_138.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000018__3 any = temp__1927000414__auto____2; var tmp1 any; var root_141 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = s__292000018__3; if linked_142 == nil { tmp1 = ifn_143.Invoke_O__O(arg_144) } else { tmp1 = linked_142.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_141, arg_144) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_145 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = s__292000018__3; if linked_146 == nil { c__1927001037__auto____4 = ifn_147.Invoke_O__O(arg_148) } else { c__1927001037__auto____4 = linked_146.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_145, arg_148) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000020__6 any; var root_149 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_150 == nil { b__292000020__6 = ifn_151.Invoke_O__O(arg_152) } else { b__292000020__6 = linked_150.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_149, arg_152) }; var tmp2 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(b__292000020__6, t.F_recv, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__258 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class; if fncls__258 == nil { var fncls__258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class = fncls__258d; tmp3 = fncls__258d } else { tmp3 = fncls__258 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_267 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any; var root_259 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = b__292000020__6; if linked_260 == nil { arg_270 = ifn_261.Invoke_O__O(arg_262) } else { arg_270 = linked_260.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_259, arg_262) }; var arg_271 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp5 any; var root_263 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = s__292000018__3; if linked_264 == nil { tmp5 = ifn_265.Invoke_O__O(arg_266) } else { tmp5 = linked_264.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_263, arg_266) }; arg_271 = tmp4.Invoke_O__O(tmp5); if linked_268 == nil { return ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { return linked_268.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_267, arg_270, arg_271) } } else { var root_276 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any; var root_272 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = b__292000020__6; if linked_273 == nil { arg_279 = ifn_274.Invoke_O__O(arg_275) } else { arg_279 = linked_273.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_272, arg_275) }; var arg_280 any; if linked_277 == nil { return ifn_278.Invoke_O_O__O(arg_279, arg_280) } else { return linked_277.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_276, arg_279, arg_280) } } } else { var mm__4 any; var root_281 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = s__292000018__3; if linked_282 == nil { mm__4 = ifn_283.Invoke_O__O(arg_284) } else { mm__4 = linked_282.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_281, arg_284) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_289 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any; var root_285 any = A_arbace_j2g_dyncf_A_const_72.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = mm__4; if linked_286 == nil { arg_292 = ifn_287.Invoke_O__O(arg_288) } else { arg_292 = linked_286.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_285, arg_288) }; if linked_290 == nil { and__1927000168__auto____6 = ifn_291.Invoke_O__O(arg_292) } else { and__1927000168__auto____6 = linked_290.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_289, arg_292) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_293 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4); if linked_294 == nil { tmp6 = ifn_295.Invoke_O__O(arg_296) } else { tmp6 = linked_294.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_293, arg_296) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :66:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_301 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_303 lang.IFn

		if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any; var root_297 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = t.F_n; if linked_298 == nil { arg_304 = ifn_299.Invoke_O__O(arg_300) } else { arg_304 = linked_298.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_297, arg_300) }; if linked_302 == nil { or__1927000174__auto____5 = ifn_303.Invoke_O__O(arg_304) } else { or__1927000174__auto____5 = linked_302.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_301, arg_304) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_318 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any; var root_309 any = A_arbace_j2g_dyncf_A_const_76.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyncf_A_const_77; var arg_312 any = tmp8.Invoke_O__O(A_arbace_j2g_dyncf_A_const_78.Get__O()); var arg_313 any; var root_305 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = t.F_n; if linked_306 == nil { arg_313 = ifn_307.Invoke_O__O(arg_308) } else { arg_313 = linked_306.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_305, arg_308) }; if linked_310 == nil { arg_321 = ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { arg_321 = linked_310.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_309, arg_312, arg_313) }; var arg_322 any; var root_314 any = A_arbace_j2g_dyncf_A_const_79.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4); if linked_315 == nil { arg_322 = ifn_316.Invoke_O__O(arg_317) } else { arg_322 = linked_315.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_314, arg_317) }; if linked_319 == nil { tmp7 = ifn_320.Invoke_O_O__O(arg_321, arg_322) } else { tmp7 = linked_319.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_318, arg_321, arg_322) } }
//line :66:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_323 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_325 lang.IFn



			if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = t.F_n; if linked_324 == nil { tmp9 = ifn_325.Invoke_O__O(arg_326) } else { tmp9 = linked_324.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_323, arg_326) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4) } else { var root_327 any = A_arbace_j2g_dyncf_A_const_80.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = t.F_n; var arg_331 any = mm__4; if linked_328 == nil { real__5 = ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { real__5 = linked_328.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_327, arg_330, arg_331) } }
//line :66:1
			var vec__292000033__6 any; var root_332 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_334 lang.IFn




			if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4); if linked_333 == nil { vec__292000033__6 = ifn_334.Invoke_O__O(arg_335) } else { vec__292000033__6 = linked_333.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_332, arg_335) }
//line :66:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000033__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000036__9 any; var root_336 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_338 lang.IFn; _ = ___8





			if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = real__5; if linked_337 == nil { vec__292000036__9 = ifn_338.Invoke_O__O(arg_339) } else { vec__292000036__9 = linked_337.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_336, arg_339) }
//line :66:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000036__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_389 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var tmp10 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyncf_A_const_83; var tmp13 any; var root_340 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_342 lang.IFn








				if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = A_arbace_j2g_dyncf_A_const_84; var arg_344 any = A_arbace_j2g_dyncf_A_const_85; if linked_341 == nil { tmp13 = ifn_342.Invoke_O_O__O(arg_343, arg_344) } else { tmp13 = linked_341.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_340, arg_343, arg_344) }
//line :66:1
				var tmp14 any = tmp13; var tmp15 any; var root_345 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_347 lang.IFn








				if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = A_arbace_j2g_dyncf_A_const_86; var arg_349 any = A_arbace_j2g_dyncf_A_const_87; if linked_346 == nil { tmp15 = ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { tmp15 = linked_346.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_345, arg_348, arg_349) }
//line :66:1
				var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyncf_A_const_88; var tmp19 any = A_arbace_j2g_dyncf_A_const_95; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_96, t.F_recv, A_arbace_j2g_dyncf_A_const_97)); var tmp21 any; var root_377 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_379 lang.IFn










				if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_381 any; var root_354 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp23 any; var root_350 any = A_arbace_j2g_dyncf_A_const_79.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = real__5; if linked_351 == nil { tmp23 = ifn_352.Invoke_O__O(arg_353) } else { tmp23 = linked_351.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_350, arg_353) }; arg_357 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_355 == nil { arg_381 = ifn_356.Invoke_O__O(arg_357) } else { arg_381 = linked_355.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_354, arg_357) }; var arg_382 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp25 any; var root_362 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_364 lang.IFn
				if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp27 any; var root_358 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = t.F_n; if linked_359 == nil { tmp27 = ifn_360.Invoke_O__O(arg_361) } else { tmp27 = linked_359.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_358, arg_361) }; arg_365 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp27)).Ref(); if linked_363 == nil { tmp25 = ifn_364.Invoke_O__O(arg_365) } else { tmp25 = linked_363.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_362, arg_365) }; arg_382 = tmp24.Invoke_O_O__O(tmp25, A_arbace_j2g_dyncf_A_const_89)
//line :77:1
				var arg_383 any = A_arbace_j2g_dyncf_A_const_90; var arg_384 any; var root_372 any = A_arbace_j2g_dyncf_A_const_91.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_374 lang.IFn

				if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any; var tmp28 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New(); var tmp29 *jrt.Class; var fncls__371 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class; if fncls__371 == nil { var fncls__371d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class = fncls__371d; tmp29 = fncls__371d } else { tmp29 = fncls__371 }; arg_375 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_376 any = ps__7; if linked_373 == nil { arg_384 = ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { arg_384 = linked_373.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) }
//line :77:1
				if linked_378 == nil { tmp21 = ifn_379.Invoke_O_O_O_O_O__O(arg_380, arg_381, arg_382, arg_383, arg_384) } else { tmp21 = linked_378.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_377, arg_380, arg_381, arg_382, arg_383, arg_384) }
//line :66:1
				arg_392 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp20, tmp21))); var arg_393 any; var tmp30 lang.IFn = lang.IFn_Cast(t.F_iter__292000017); var tmp31 any; var root_385 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = s__292000018__3; if linked_386 == nil { tmp31 = ifn_387.Invoke_O__O(arg_388) } else { tmp31 = linked_386.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_385, arg_388) }; arg_393 = tmp30.Invoke_O__O(tmp31); if linked_390 == nil { return ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { return linked_390.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) } } else { var tmp32 any; var root_394 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = s__292000018__3; if linked_395 == nil { tmp32 = ifn_396.Invoke_O__O(arg_397) } else { tmp32 = linked_395.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_394, arg_397) }; s__292000018__1 = tmp32; continue L1 } } else { var tmp33 any; var root_398 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = s__292000018__3; if linked_399 == nil { tmp33 = ifn_400.Invoke_O__O(arg_401) } else { tmp33 = linked_399.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_398, arg_401) }; s__292000018__1 = tmp33; continue L1 } } else { var tmp34 any; var root_402 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = s__292000018__3; if linked_403 == nil { tmp34 = ifn_404.Invoke_O__O(arg_405) } else { tmp34 = linked_403.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_402, arg_405) }; s__292000018__1 = tmp34; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Ctor_O_O_O_I_O(c__b__292000020, c__recv, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000020 = c__b__292000020; t.F_recv = c__recv; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A) Invoke_O__O(self any) any { { var i__292000019__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000019__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000019__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_157 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_153 any = A_arbace_j2g_dyncf_A_const_72.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = mm__2; if linked_154 == nil { arg_160 = ifn_155.Invoke_O__O(arg_156) } else { arg_160 = linked_154.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_153, arg_156) }; if linked_158 == nil { and__1927000168__auto____4 = ifn_159.Invoke_O__O(arg_160) } else { and__1927000168__auto____4 = linked_158.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_157, arg_160) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_161 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2); if linked_162 == nil { tmp2 = ifn_163.Invoke_O__O(arg_164) } else { tmp2 = linked_162.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_161, arg_164) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :66:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_169 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn

		if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any; var root_165 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = t.F_n; if linked_166 == nil { arg_172 = ifn_167.Invoke_O__O(arg_168) } else { arg_172 = linked_166.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_165, arg_168) }; if linked_170 == nil { or__1927000174__auto____3 = ifn_171.Invoke_O__O(arg_172) } else { or__1927000174__auto____3 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_186 any = A_arbace_j2g_dyncf_A_const_75.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var root_177 any = A_arbace_j2g_dyncf_A_const_76.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyncf_A_const_77; var arg_180 any = tmp4.Invoke_O__O(A_arbace_j2g_dyncf_A_const_78.Get__O()); var arg_181 any; var root_173 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = t.F_n; if linked_174 == nil { arg_181 = ifn_175.Invoke_O__O(arg_176) } else { arg_181 = linked_174.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_173, arg_176) }; if linked_178 == nil { arg_189 = ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { arg_189 = linked_178.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) }; var arg_190 any; var root_182 any = A_arbace_j2g_dyncf_A_const_79.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2); if linked_183 == nil { arg_190 = ifn_184.Invoke_O__O(arg_185) } else { arg_190 = linked_183.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_182, arg_185) }; if linked_187 == nil { tmp3 = ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { tmp3 = linked_187.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_186, arg_189, arg_190) } }
//line :66:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_191 any = A_arbace_j2g_dyncf_A_const_48.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_193 lang.IFn



			if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = t.F_n; if linked_192 == nil { tmp5 = ifn_193.Invoke_O__O(arg_194) } else { tmp5 = linked_192.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_191, arg_194) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2) } else { var root_195 any = A_arbace_j2g_dyncf_A_const_80.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = t.F_n; var arg_199 any = mm__2; if linked_196 == nil { real__3 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { real__3 = linked_196.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) } }
//line :66:1
			var vec__292000024__4 any; var root_200 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_202 lang.IFn




			if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2); if linked_201 == nil { vec__292000024__4 = ifn_202.Invoke_O__O(arg_203) } else { vec__292000024__4 = linked_201.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_200, arg_203) }
//line :66:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__292000027__7 any; var root_204 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_206 lang.IFn; _ = ___6





			if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = real__3; if linked_205 == nil { vec__292000027__7 = ifn_206.Invoke_O__O(arg_207) } else { vec__292000027__7 = linked_205.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_204, arg_207) }
//line :66:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000027__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_253 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = t.F_b__292000020; var arg_257 any; var tmp6 any = A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyncf_A_const_83; var tmp9 any; var root_208 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_210 lang.IFn








				if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = A_arbace_j2g_dyncf_A_const_84; var arg_212 any = A_arbace_j2g_dyncf_A_const_85; if linked_209 == nil { tmp9 = ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { tmp9 = linked_209.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_208, arg_211, arg_212) }
//line :66:1
				var tmp10 any = tmp9; var tmp11 any; var root_213 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_215 lang.IFn








				if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = A_arbace_j2g_dyncf_A_const_86; var arg_217 any = A_arbace_j2g_dyncf_A_const_87; if linked_214 == nil { tmp11 = ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { tmp11 = linked_214.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) }
//line :66:1
				var tmp12 any = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyncf_A_const_88; var tmp15 any = A_arbace_j2g_dyncf_A_const_95; var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_96, t.F_recv, A_arbace_j2g_dyncf_A_const_97)); var tmp17 any; var root_245 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_247 lang.IFn










				if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_249 any; var root_222 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any; var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp19 any; var root_218 any = A_arbace_j2g_dyncf_A_const_79.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = real__3; if linked_219 == nil { tmp19 = ifn_220.Invoke_O__O(arg_221) } else { tmp19 = linked_219.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_218, arg_221) }; arg_225 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19)).Ref(); if linked_223 == nil { arg_249 = ifn_224.Invoke_O__O(arg_225) } else { arg_249 = linked_223.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_222, arg_225) }; var arg_250 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp21 any; var root_230 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_232 lang.IFn
				if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp23 any; var root_226 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = t.F_n; if linked_227 == nil { tmp23 = ifn_228.Invoke_O__O(arg_229) } else { tmp23 = linked_227.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_226, arg_229) }; arg_233 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref(); if linked_231 == nil { tmp21 = ifn_232.Invoke_O__O(arg_233) } else { tmp21 = linked_231.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_230, arg_233) }; arg_250 = tmp20.Invoke_O_O__O(tmp21, A_arbace_j2g_dyncf_A_const_89)
//line :77:1
				var arg_251 any = A_arbace_j2g_dyncf_A_const_90; var arg_252 any; var root_240 any = A_arbace_j2g_dyncf_A_const_91.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_242 lang.IFn

				if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var tmp24 any = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New(); var tmp25 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class; if fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class = fncls__239d; tmp25 = fncls__239d } else { tmp25 = fncls__239 }; arg_243 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var arg_244 any = ps__5; if linked_241 == nil { arg_252 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { arg_252 = linked_241.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }
//line :77:1
				if linked_246 == nil { tmp17 = ifn_247.Invoke_O_O_O_O_O__O(arg_248, arg_249, arg_250, arg_251, arg_252) } else { tmp17 = linked_246.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_245, arg_248, arg_249, arg_250, arg_251, arg_252) }
//line :66:1
				arg_257 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp16, tmp17))); if linked_254 == nil { ifn_255.Invoke_O_O__O(arg_256, arg_257) } else { linked_254.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_253, arg_256, arg_257) }; i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { i__292000019__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000019__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_234 any = A_arbace_j2g_dyncf_A_const_92.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = p__2; var arg_238 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_93, A_arbace_j2g_dyncf_A_const_94, i__1); if linked_235 == nil { return ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { return linked_235.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_234, arg_237, arg_238) } }
//line :79:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_366 any = A_arbace_j2g_dyncf_A_const_92.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = p__2; var arg_370 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_93, A_arbace_j2g_dyncf_A_const_94, i__1); if linked_367 == nil { return ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { return linked_367.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) } }


func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A) Invoke_O_O__O(self, s__292000044__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(t.F_recv, t.F_n, self, s__292000044__1); var tmp2 *jrt.Class; var fncls__703 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class; if fncls__703 == nil { var fncls__703d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class = fncls__703d; tmp2 = fncls__703d } else { tmp2 = fncls__703 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Ctor_O_O_O_O(c__recv, c__n, c__iter__292000043, c__s__292000044 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_iter__292000043 = c__iter__292000043; t.F_s__292000044 = c__s__292000044 }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A) Invoke_O__O(self any) any { { var s__292000044__1 any; var t_ any = t.F_s__292000044; t.F_s__292000044 = nil; s__292000044__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_436 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = s__292000044__1; if linked_437 == nil { temp__1927000414__auto____2 = ifn_438.Invoke_O__O(arg_439) } else { temp__1927000414__auto____2 = linked_437.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_436, arg_439) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000044__3 any = temp__1927000414__auto____2; var tmp1 any; var root_440 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = s__292000044__3; if linked_441 == nil { tmp1 = ifn_442.Invoke_O__O(arg_443) } else { tmp1 = linked_441.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_440, arg_443) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_444 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = s__292000044__3; if linked_445 == nil { c__1927001037__auto____4 = ifn_446.Invoke_O__O(arg_447) } else { c__1927001037__auto____4 = linked_445.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_444, arg_447) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000046__6 any; var root_448 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_449 == nil { b__292000046__6 = ifn_450.Invoke_O__O(arg_451) } else { b__292000046__6 = linked_449.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_448, arg_451) }; var tmp2 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(t.F_recv, b__292000046__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__558 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class; if fncls__558 == nil { var fncls__558d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class = fncls__558d; tmp3 = fncls__558d } else { tmp3 = fncls__558 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_567 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any; var root_559 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = b__292000046__6; if linked_560 == nil { arg_570 = ifn_561.Invoke_O__O(arg_562) } else { arg_570 = linked_560.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_559, arg_562) }; var arg_571 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp5 any; var root_563 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = s__292000044__3; if linked_564 == nil { tmp5 = ifn_565.Invoke_O__O(arg_566) } else { tmp5 = linked_564.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_563, arg_566) }; arg_571 = tmp4.Invoke_O__O(tmp5); if linked_568 == nil { return ifn_569.Invoke_O_O__O(arg_570, arg_571) } else { return linked_568.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_567, arg_570, arg_571) } } else { var root_576 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any; var root_572 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = b__292000046__6; if linked_573 == nil { arg_579 = ifn_574.Invoke_O__O(arg_575) } else { arg_579 = linked_573.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_572, arg_575) }; var arg_580 any; if linked_577 == nil { return ifn_578.Invoke_O_O__O(arg_579, arg_580) } else { return linked_577.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_576, arg_579, arg_580) } } } else { var vec__292000063__4 any; var root_581 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = s__292000044__3; if linked_582 == nil { vec__292000063__4 = ifn_583.Invoke_O__O(arg_584) } else { vec__292000063__4 = linked_582.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_581, arg_584) }; var vec__292000066__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(0), nil); var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000066__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__292000066__5; var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000063__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_585 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_587 lang.IFn; _ = ___9
														if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = desc__7; if linked_586 == nil { tmp6 = ifn_587.Invoke_O__O(arg_588) } else { tmp6 = linked_586.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_585, arg_588) }
//line :82:1
	if jrt.J2g_Truth(tmp6) { var impl__10 any; var root_589 any = A_arbace_j2g_dyncf_A_const_111.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_591 lang.IFn

		if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = t.F_n; var arg_593 any = k__8; if linked_590 == nil { impl__10 = ifn_591.Invoke_O_O__O(arg_592, arg_593) } else { impl__10 = linked_590.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_589, arg_592, arg_593) }
//line :82:1
		var base__11 any; var root_594 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_596 lang.IFn


		if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = name__6; var arg_598 any = desc__7; if linked_595 == nil { base__11 = ifn_596.Invoke_O_O__O(arg_597, arg_598) } else { base__11 = linked_595.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_594, arg_597, arg_598) }
//line :82:1
		var vec__292000069__12 any; var root_599 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_601 lang.IFn



		if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = desc__7; if linked_600 == nil { vec__292000069__12 = ifn_601.Invoke_O__O(arg_602) } else { vec__292000069__12 = linked_600.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_599, arg_602) }
//line :82:1
		var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(0), nil); var r__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000069__12, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__15 any; var root_609 any = A_arbace_j2g_dyncf_A_const_91.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_611 lang.IFn




		if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any; var tmp7 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New(); var tmp8 *jrt.Class; var fncls__608 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class; if fncls__608 == nil { var fncls__608d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class = fncls__608d; tmp8 = fncls__608d } else { tmp8 = fncls__608 }; arg_612 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_613 any = ps__13; if linked_610 == nil { pn__15 = ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { pn__15 = linked_610.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) }
//line :82:1
		var call__16 any; var G__292000074__16_ any = A_arbace_j2g_dyncf_A_const_114.Invoke_O__O(impl__10)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000074__16_) >> 4 & 3 { case 0: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_115) {

		var root_621 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_625 any; var root_615 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = A_arbace_j2g_dyncf_A_const_29; var arg_619 any = A_arbace_j2g_dyncf_A_const_116.Invoke_O__O(impl__10); var arg_620 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_616 == nil { arg_625 = ifn_617.Invoke_O_O_O__O(arg_618, arg_619, arg_620) } else { arg_625 = linked_616.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_615, arg_618, arg_619, arg_620) }; var arg_626 any = A_arbace_j2g_dyncf_A_const_117; var arg_627 any = pn__15; if linked_622 == nil { call__16 = ifn_623.Invoke_O_O_O_O__O(arg_624, arg_625, arg_626, arg_627) } else { call__16 = linked_622.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_621, arg_624, arg_625, arg_626, arg_627) }
//line :88:1
		break L2 }; case 1: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_118) {
			var root_632 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_636 any; var root_628 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_629 == nil { arg_636 = ifn_630.Invoke_O__O(arg_631) } else { arg_636 = linked_629.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_628, arg_631) }; var arg_637 any = A_arbace_j2g_dyncf_A_const_119; var arg_638 any = A_arbace_j2g_dyncf_A_const_120; var arg_639 any = pn__15; if linked_633 == nil { call__16 = ifn_634.Invoke_O_O_O_O_O__O(arg_635, arg_636, arg_637, arg_638, arg_639) } else { call__16 = linked_633.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_632, arg_635, arg_636, arg_637, arg_638, arg_639) }
//line :88:1
			break L2 }; case 2: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_121) {
				var root_644 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_648 any; var root_640 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_641 == nil { arg_648 = ifn_642.Invoke_O__O(arg_643) } else { arg_648 = linked_641.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_640, arg_643) }; var arg_649 any = A_arbace_j2g_dyncf_A_const_119; var arg_650 any = A_arbace_j2g_dyncf_A_const_120; var arg_651 any = pn__15; if linked_645 == nil { call__16 = ifn_646.Invoke_O_O_O_O_O__O(arg_647, arg_648, arg_649, arg_650, arg_651) } else { call__16 = linked_645.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_644, arg_647, arg_648, arg_649, arg_650, arg_651) }
//line :88:1
				break L2 }; case 3: if any(G__292000074__16_) == any(A_arbace_j2g_dyncf_A_const_122) {


					var root_664 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_668 any; var root_652 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref(); if linked_653 == nil { arg_668 = ifn_654.Invoke_O__O(arg_655) } else { arg_668 = linked_653.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_652, arg_655) }; var arg_669 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp10 any; var root_660 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp12 any; var root_656 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = t.F_n; if linked_657 == nil { tmp12 = ifn_658.Invoke_O__O(arg_659) } else { tmp12 = linked_657.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_656, arg_659) }; arg_663 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); if linked_661 == nil { tmp10 = ifn_662.Invoke_O__O(arg_663) } else { tmp10 = linked_661.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_660, arg_663) }; arg_669 = tmp9.Invoke_O_O__O(tmp10, A_arbace_j2g_dyncf_A_const_123); var arg_670 any = pn__15; if linked_665 == nil { call__16 = ifn_666.Invoke_O_O_O_O__O(arg_667, arg_668, arg_669, arg_670) } else { call__16 = linked_665.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_664, arg_667, arg_668, arg_669, arg_670) }
//line :88:1
					break L2 }; default:}; call__16 = nil}
//line :82:1
		if jrt.J2g_Truth(call__16) { var root_690 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__6, desc__7)).Ref(); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyncf_A_const_124; var tmp16 any; var root_681 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_683 lang.IFn












			if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any; var tmp17 any; var root_671 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = A_arbace_j2g_dyncf_A_const_125; var arg_675 any = A_arbace_j2g_dyncf_A_const_126; if linked_672 == nil { tmp17 = ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { tmp17 = linked_672.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_671, arg_674, arg_675) }; var tmp18 any = tmp17; var tmp19 any; var root_676 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = A_arbace_j2g_dyncf_A_const_127; var arg_680 any = A_arbace_j2g_dyncf_A_const_128; if linked_677 == nil { tmp19 = ifn_678.Invoke_O_O__O(arg_679, arg_680) } else { tmp19 = linked_677.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_676, arg_679, arg_680) }; arg_684 = lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19); var arg_685 any = A_arbace_j2g_dyncf_A_const_138; if linked_682 == nil { tmp16 = ifn_683.Invoke_O_O__O(arg_684, arg_685) } else { tmp16 = linked_682.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_681, arg_684, arg_685) }
//line :82:1
			var tmp20 any = tmp16; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyncf_A_const_130; var tmp23 any = A_arbace_j2g_dyncf_A_const_131; var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_132, t.F_recv, A_arbace_j2g_dyncf_A_const_133)); var tmp25 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_75, r__14) {
				tmp25 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_134, call__16, A_arbace_j2g_dyncf_A_const_135) } else {
					var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyncf_A_const_136; tmp25 = tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_137, call__16)) }
//line :82:1
			arg_693 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp24, tmp25))); var arg_694 any; var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__292000043); var tmp29 any; var root_686 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = s__292000044__3; if linked_687 == nil { tmp29 = ifn_688.Invoke_O__O(arg_689) } else { tmp29 = linked_687.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_686, arg_689) }; arg_694 = tmp28.Invoke_O__O(tmp29); if linked_691 == nil { return ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { return linked_691.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) } } else { var tmp30 any; var root_695 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__292000044__3; if linked_696 == nil { tmp30 = ifn_697.Invoke_O__O(arg_698) } else { tmp30 = linked_696.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_695, arg_698) }; s__292000044__1 = tmp30; continue L1 } } else { var tmp31 any; var root_699 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = s__292000044__3; if linked_700 == nil { tmp31 = ifn_701.Invoke_O__O(arg_702) } else { tmp31 = linked_700.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_699, arg_702) }; s__292000044__1 = tmp31; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :82:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Ctor_O_O_O_I_O(c__recv, c__b__292000046, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_b__292000046 = c__b__292000046; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :82:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A) Invoke_O__O(self any) any { { var i__292000045__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000045__1)); var vec__292000053__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000053__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__292000053__3; var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_452 any = A_arbace_j2g_dyncf_A_const_73.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_454 lang.IFn; _ = ___7
																if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = desc__5; if linked_453 == nil { tmp2 = ifn_454.Invoke_O__O(arg_455) } else { tmp2 = linked_453.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_452, arg_455) }
//line :82:1
	if jrt.J2g_Truth(tmp2) { var impl__8 any; var root_456 any = A_arbace_j2g_dyncf_A_const_111.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_458 lang.IFn

		if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = t.F_n; var arg_460 any = k__6; if linked_457 == nil { impl__8 = ifn_458.Invoke_O_O__O(arg_459, arg_460) } else { impl__8 = linked_457.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_456, arg_459, arg_460) }
//line :82:1
		var base__9 any; var root_461 any = A_arbace_j2g_dyncf_A_const_23.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_463 lang.IFn


		if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = name__4; var arg_465 any = desc__5; if linked_462 == nil { base__9 = ifn_463.Invoke_O_O__O(arg_464, arg_465) } else { base__9 = linked_462.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_461, arg_464, arg_465) }
//line :82:1
		var vec__292000056__10 any; var root_466 any = A_arbace_j2g_dyncf_A_const_81.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_468 lang.IFn



		if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = desc__5; if linked_467 == nil { vec__292000056__10 = ifn_468.Invoke_O__O(arg_469) } else { vec__292000056__10 = linked_467.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_466, arg_469) }
//line :82:1
		var ps__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000056__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_476 any = A_arbace_j2g_dyncf_A_const_91.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_478 lang.IFn




		if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var tmp3 any = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New(); var tmp4 *jrt.Class; var fncls__475 *jrt.Class = A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class; if fncls__475 == nil { var fncls__475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class = fncls__475d; tmp4 = fncls__475d } else { tmp4 = fncls__475 }; arg_479 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_480 any = ps__11; if linked_477 == nil { pn__13 = ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { pn__13 = linked_477.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) }
//line :82:1
		var call__14 any; var G__292000061__14_ any = A_arbace_j2g_dyncf_A_const_114.Invoke_O__O(impl__8)





	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__292000061__14_) >> 4 & 3 { case 0: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_115) {

		var root_488 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_492 any; var root_482 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = A_arbace_j2g_dyncf_A_const_29; var arg_486 any = A_arbace_j2g_dyncf_A_const_116.Invoke_O__O(impl__8); var arg_487 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_483 == nil { arg_492 = ifn_484.Invoke_O_O_O__O(arg_485, arg_486, arg_487) } else { arg_492 = linked_483.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_482, arg_485, arg_486, arg_487) }; var arg_493 any = A_arbace_j2g_dyncf_A_const_117; var arg_494 any = pn__13; if linked_489 == nil { call__14 = ifn_490.Invoke_O_O_O_O__O(arg_491, arg_492, arg_493, arg_494) } else { call__14 = linked_489.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_488, arg_491, arg_492, arg_493, arg_494) }
//line :88:1
		break L2 }; case 1: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_118) {
			var root_499 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_503 any; var root_495 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_496 == nil { arg_503 = ifn_497.Invoke_O__O(arg_498) } else { arg_503 = linked_496.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_495, arg_498) }; var arg_504 any = A_arbace_j2g_dyncf_A_const_119; var arg_505 any = A_arbace_j2g_dyncf_A_const_120; var arg_506 any = pn__13; if linked_500 == nil { call__14 = ifn_501.Invoke_O_O_O_O_O__O(arg_502, arg_503, arg_504, arg_505, arg_506) } else { call__14 = linked_500.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_499, arg_502, arg_503, arg_504, arg_505, arg_506) }
//line :88:1
			break L2 }; case 2: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_121) {
				var root_511 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_515 any; var root_507 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_508 == nil { arg_515 = ifn_509.Invoke_O__O(arg_510) } else { arg_515 = linked_508.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_507, arg_510) }; var arg_516 any = A_arbace_j2g_dyncf_A_const_119; var arg_517 any = A_arbace_j2g_dyncf_A_const_120; var arg_518 any = pn__13; if linked_512 == nil { call__14 = ifn_513.Invoke_O_O_O_O_O__O(arg_514, arg_515, arg_516, arg_517, arg_518) } else { call__14 = linked_512.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_511, arg_514, arg_515, arg_516, arg_517, arg_518) }
//line :88:1
				break L2 }; case 3: if any(G__292000061__14_) == any(A_arbace_j2g_dyncf_A_const_122) {


					var root_531 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_535 any; var root_519 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref(); if linked_520 == nil { arg_535 = ifn_521.Invoke_O__O(arg_522) } else { arg_535 = linked_520.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_519, arg_522) }; var arg_536 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp6 any; var root_527 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp8 any; var root_523 any = A_arbace_j2g_dyncf_A_const_22.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = t.F_n; if linked_524 == nil { tmp8 = ifn_525.Invoke_O__O(arg_526) } else { tmp8 = linked_524.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_523, arg_526) }; arg_530 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(); if linked_528 == nil { tmp6 = ifn_529.Invoke_O__O(arg_530) } else { tmp6 = linked_528.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_527, arg_530) }; arg_536 = tmp5.Invoke_O_O__O(tmp6, A_arbace_j2g_dyncf_A_const_123); var arg_537 any = pn__13; if linked_532 == nil { call__14 = ifn_533.Invoke_O_O_O_O__O(arg_534, arg_535, arg_536, arg_537) } else { call__14 = linked_532.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_531, arg_534, arg_535, arg_536, arg_537) }
//line :88:1
					break L2 }; default:}; call__14 = nil}
//line :82:1
		if jrt.J2g_Truth(call__14) { var root_553 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = t.F_b__292000046; var arg_557 any; var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__4, desc__5)).Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_124; var tmp12 any; var root_548 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_550 lang.IFn












			if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any; var tmp13 any; var root_538 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = A_arbace_j2g_dyncf_A_const_125; var arg_542 any = A_arbace_j2g_dyncf_A_const_126; if linked_539 == nil { tmp13 = ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { tmp13 = linked_539.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) }; var tmp14 any = tmp13; var tmp15 any; var root_543 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = A_arbace_j2g_dyncf_A_const_127; var arg_547 any = A_arbace_j2g_dyncf_A_const_128; if linked_544 == nil { tmp15 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { tmp15 = linked_544.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; arg_551 = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15); var arg_552 any = A_arbace_j2g_dyncf_A_const_129; if linked_549 == nil { tmp12 = ifn_550.Invoke_O_O__O(arg_551, arg_552) } else { tmp12 = linked_549.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_548, arg_551, arg_552) }
//line :82:1
			var tmp16 any = tmp12; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyncf_A_const_130; var tmp19 any = A_arbace_j2g_dyncf_A_const_131; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_132, t.F_recv, A_arbace_j2g_dyncf_A_const_133)); var tmp21 any














			if lang.Util_Equiv_O_O__Z_NoInit(Lit_75, r__12) {
				tmp21 = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_134, call__14, A_arbace_j2g_dyncf_A_const_135) } else {
					var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_136; tmp21 = tmp22.Invoke_O_O__O(tmp23, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_137, call__14)) }
//line :82:1
			arg_557 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Invoke_O_O_O__O(tmp11, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp20, tmp21))); if linked_554 == nil { ifn_555.Invoke_O_O__O(arg_556, arg_557) } else { linked_554.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_553, arg_556, arg_557) }; i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { i__292000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000045__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_470 any = A_arbace_j2g_dyncf_A_const_92.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = p__2; var arg_474 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_112, A_arbace_j2g_dyncf_A_const_113, i__1); if linked_471 == nil { return ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { return linked_471.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) } }
//line :87:1
func A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_New() *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var root_603 any = A_arbace_j2g_dyncf_A_const_92.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, A_arbace_j2g_dyncf_from_object_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = p__2; var arg_607 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyncf_A_const_112, A_arbace_j2g_dyncf_A_const_113, i__1); if linked_604 == nil { return ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { return linked_604.(*A_arbace_j2g_dyncf_from_object_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) } }













func A_arbace_j2g_dyncf_subs_forms_A_New() *A_arbace_j2g_dyncf_subs_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Ctor() {}
//line :101:1
func (t *A_arbace_j2g_dyncf_subs_forms_A) Invoke_O_O__O(self, T__0_ any) any { var cs__2 any; var root_721 any = A_arbace_j2g_dyncf_A_const_141.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_723 lang.IFn; if


	linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = T__0_; if linked_722 == nil { cs__2 = ifn_723.Invoke_O__O(arg_724) } else { cs__2 = linked_722.(*aot_arbace_j2g_dyn.A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_721, arg_724) }; var root_845 any =
	A_arbace_j2g_dyncf_A_const_142.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_144.GetRawRoot__O(), cs__2); var arg_849 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyncf_A_const_145; var tmp3 any = A_arbace_j2g_dyncf_A_const_146; var tmp4 any; var root_840 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_842 lang.IFn; if




	linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = A_arbace_j2g_dyncf_A_const_154; var arg_844 any = A_arbace_j2g_dyncf_A_const_155; if linked_841 == nil { tmp4 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { tmp4 = linked_841.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_840, arg_843, arg_844) }; var tmp5 any = /*line :105:1*/lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 any = A_arbace_j2g_dyncf_A_const_147; var tmp7 any = A_arbace_j2g_dyncf_A_const_148; var tmp8 any; var root_833 any = A_arbace_j2g_dyncf_A_const_63.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_835 lang.IFn; if







	linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O(); var arg_837 any = A_arbace_j2g_dyncf_A_const_149; var arg_838 any = A_arbace_j2g_dyncf_A_const_150; var arg_839 any; var iter__1927001039__auto____3 any; var tmp9 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_New(); var tmp10 *jrt.Class; var fncls__832 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class; if
	fncls__832 == nil { var fncls__832d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class = fncls__832d; tmp10 = fncls__832d } else { tmp10 = fncls__832 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_839 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(cs__2); if /*line :113:1*/ linked_834 == nil { tmp8 = ifn_835.Invoke_O_O_O_O__O(arg_836, arg_837, arg_838, arg_839) } else { tmp8 = linked_834.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_833, arg_836, arg_837, arg_838, arg_839) }; arg_849 = /*line :105:1*/lang.Tuple_Create_O__IPersistentVector(tmp1.Invoke_O_O_O_O_O_O_O_O__O(tmp2, tmp3, Lit_78, tmp5, tmp6, tmp7, tmp8, A_arbace_j2g_dyncf_A_const_153)); if linked_846 == nil { return ifn_847.Invoke_O_O__O(arg_848, arg_849) } else { return linked_846.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_845, arg_848, arg_849) } }








func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_New() *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A) Ctor() {}
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A) Invoke_O_O__O(self, s__292000079__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_New_O_O(self, s__292000079__1); var tmp2 *jrt.Class; var fncls__831 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class; if fncls__831 == nil { var fncls__831d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class = fncls__831d; tmp2 = fncls__831d } else { tmp2 = fncls__831 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A) Ctor_O_O(c__iter__292000078, c__s__292000079 any) { t.F_iter__292000078 = c__iter__292000078; t.F_s__292000079 = c__s__292000079 }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A) Invoke_O__O(self any) any { { var s__292000079__1 any; var t_ any = t.F_s__292000079; t.F_s__292000079 = nil; s__292000079__1 = t_; for { var temp__1927000414__auto____2 any; var root_730 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__292000079__1; if linked_731 == nil { temp__1927000414__auto____2 = ifn_732.Invoke_O__O(arg_733) } else { temp__1927000414__auto____2 = linked_731.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_730, arg_733) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000079__3 any = temp__1927000414__auto____2; var tmp1 any; var root_734 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = s__292000079__3; if linked_735 == nil { tmp1 = ifn_736.Invoke_O__O(arg_737) } else { tmp1 = linked_735.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_734, arg_737) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_738 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = s__292000079__3; if linked_739 == nil { c__1927001037__auto____4 = ifn_740.Invoke_O__O(arg_741) } else { c__1927001037__auto____4 = linked_739.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_738, arg_741) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000081__6 any; var root_742 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_743 == nil { b__292000081__6 = ifn_744.Invoke_O__O(arg_745) } else { b__292000081__6 = linked_743.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_742, arg_745) }; var tmp2 any = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_New_O_I_O(b__292000081__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__773 *jrt.Class = A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class; if fncls__773 == nil { var fncls__773d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class = fncls__773d; tmp3 = fncls__773d } else { tmp3 = fncls__773 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_782 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any; var root_774 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = b__292000081__6; if linked_775 == nil { arg_785 = ifn_776.Invoke_O__O(arg_777) } else { arg_785 = linked_775.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_774, arg_777) }; var arg_786 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000078); var tmp5 any; var root_778 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = s__292000079__3; if linked_779 == nil { tmp5 = ifn_780.Invoke_O__O(arg_781) } else { tmp5 = linked_779.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_778, arg_781) }; arg_786 = tmp4.Invoke_O__O(tmp5); if linked_783 == nil { return ifn_784.Invoke_O_O__O(arg_785, arg_786) } else { return linked_783.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_782, arg_785, arg_786) } } else { var root_791 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any; var root_787 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = b__292000081__6; if linked_788 == nil { arg_794 = ifn_789.Invoke_O__O(arg_790) } else { arg_794 = linked_788.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_787, arg_790) }; var arg_795 any; if linked_792 == nil { return ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { return linked_792.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_791, arg_794, arg_795) } } } else { var p__4 any; var root_796 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = s__292000079__3; if linked_797 == nil { p__4 = ifn_798.Invoke_O__O(arg_799) } else { p__4 = linked_797.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_796, arg_799) }; var g__5 any; var root_800 any = A_arbace_j2g_dyncf_A_const_34.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = p__4; if linked_801 == nil { g__5 = ifn_802.Invoke_O__O(arg_803) } else { g__5 = linked_801.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_800, arg_803) }; var root_826 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_151; var tmp8 any; var root_804 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_806 lang.IFn
														if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = A_arbace_j2g_dyncf_A_const_29; var arg_808 any = p__4; var arg_809 any = Lit_82; if linked_805 == nil { tmp8 = ifn_806.Invoke_O_O_O__O(arg_807, arg_808, arg_809) } else { tmp8 = linked_805.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_804, arg_807, arg_808, arg_809) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyncf_A_const_152; var tmp12 any; var root_810 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_812 lang.IFn
														if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_811 == nil { tmp12 = ifn_812.Invoke_O__O(arg_813) } else { tmp12 = linked_811.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_810, arg_813) }
//line :115:1
	var tmp13 any = tmp12; var tmp14 any; var root_814 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_816 lang.IFn
	if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_815 == nil { tmp14 = ifn_816.Invoke_O__O(arg_817) } else { tmp14 = linked_815.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_814, arg_817) }
//line :115:1
	var tmp15 any = tmp14; var tmp16 any; var root_818 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_820 lang.IFn

	if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref(); if linked_819 == nil { tmp16 = ifn_820.Invoke_O__O(arg_821) } else { tmp16 = linked_819.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_818, arg_821) }
//line :115:1
	arg_829 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp13, tmp15, tmp16))
//line :114:1
	var arg_830 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__292000078); var tmp18 any; var root_822 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = s__292000079__3; if linked_823 == nil { tmp18 = ifn_824.Invoke_O__O(arg_825) } else { tmp18 = linked_823.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_822, arg_825) }; arg_830 = tmp17.Invoke_O__O(tmp18); if linked_827 == nil { return ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { return linked_827.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_826, arg_829, arg_830) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A) Ctor_O_I_O(c__b__292000081 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000081 = c__b__292000081; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A) Invoke_O__O(self any) any { { var i__292000080__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000080__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000080__1)); var g__3 any; var root_746 any = A_arbace_j2g_dyncf_A_const_34.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, A_arbace_j2g_dyncf_sub_name_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = p__2; if linked_747 == nil { g__3 = ifn_748.Invoke_O__O(arg_749) } else { g__3 = linked_747.(*A_arbace_j2g_dyncf_sub_name_A).Invoke_O_O__O(root_746, arg_749) }; var root_768 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = t.F_b__292000081; var arg_772 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyncf_A_const_151; var tmp4 any; var root_750 any = A_arbace_j2g_dyncf_A_const_51.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_752 lang.IFn
																if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = A_arbace_j2g_dyncf_A_const_29; var arg_754 any = p__2; var arg_755 any = Lit_82; if linked_751 == nil { tmp4 = ifn_752.Invoke_O_O_O__O(arg_753, arg_754, arg_755) } else { tmp4 = linked_751.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_750, arg_753, arg_754, arg_755) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyncf_A_const_152; var tmp8 any; var root_756 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_758 lang.IFn
																if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_757 == nil { tmp8 = ifn_758.Invoke_O__O(arg_759) } else { tmp8 = linked_757.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_756, arg_759) }
//line :115:1
	var tmp9 any = tmp8; var tmp10 any; var root_760 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_762 lang.IFn
	if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_761 == nil { tmp10 = ifn_762.Invoke_O__O(arg_763) } else { tmp10 = linked_761.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_760, arg_763) }
//line :115:1
	var tmp11 any = tmp10; var tmp12 any; var root_764 any = A_arbace_j2g_dyncf_A_const_21.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_766 lang.IFn

	if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref(); if linked_765 == nil { tmp12 = ifn_766.Invoke_O__O(arg_767) } else { tmp12 = linked_765.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_764, arg_767) }
//line :115:1
	arg_772 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp9, tmp11, tmp12))
//line :114:1
	if linked_769 == nil { ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { linked_769.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) }; i__292000080__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000080__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_forms_A_New() *A_arbace_j2g_dyncf_forms_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_forms_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_j2g_dyncf_forms_A) Ctor() {}
//line :120:1
func (t *A_arbace_j2g_dyncf_forms_A) Invoke_O_O__O(self, T__0_ any) any {


	var root_1174 any = A_arbace_j2g_dyncf_A_const_142.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any; var root_850 any = A_arbace_j2g_dyncf_A_const_156.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, A_arbace_j2g_dyncf_subs_forms_A_fn_class); var ifn_852 lang.IFn
	if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = T__0_; if linked_851 == nil { arg_1177 = ifn_852.Invoke_O__O(arg_853) } else { arg_1177 = linked_851.(*A_arbace_j2g_dyncf_subs_forms_A).Invoke_O_O__O(root_850, arg_853) }
//line :123:1
	var arg_1178 any; var tmp1 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyncf_A_const_161, Lit_1); var tmp2 any = A_arbace_j2g_dyncf_A_const_157; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyncf_A_const_162; var tmp5 any; var root_854 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_856 lang.IFn














	if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = Lit_2; var arg_858 any = Lit_3; if linked_855 == nil { tmp5 = ifn_856.Invoke_O_O__O(arg_857, arg_858) } else { tmp5 = linked_855.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_854, arg_857, arg_858) }
//line :123:1
	var tmp6 any = tmp5; var tmp7 any; var root_889 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_891 lang.IFn















	if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any; var tmp8 any; var root_859 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = A_arbace_j2g_dyncf_A_const_164; var arg_863 any = A_arbace_j2g_dyncf_A_const_165; if linked_860 == nil { tmp8 = ifn_861.Invoke_O_O__O(arg_862, arg_863) } else { tmp8 = linked_860.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_859, arg_862, arg_863) }; var tmp9 any = tmp8; var tmp10 any; var root_864 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = A_arbace_j2g_dyncf_A_const_166; var arg_868 any = A_arbace_j2g_dyncf_A_const_167; if linked_865 == nil { tmp10 = ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { tmp10 = linked_865.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) }; var tmp11 any = tmp10; var tmp12 any; var root_869 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = A_arbace_j2g_dyncf_A_const_168; var arg_873 any = A_arbace_j2g_dyncf_A_const_169; if linked_870 == nil { tmp12 = ifn_871.Invoke_O_O__O(arg_872, arg_873) } else { tmp12 = linked_870.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_869, arg_872, arg_873) }; var tmp13 any = tmp12; var tmp14 any; var root_874 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_876 lang.IFn
	if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = A_arbace_j2g_dyncf_A_const_170; var arg_878 any = A_arbace_j2g_dyncf_A_const_171; if linked_875 == nil { tmp14 = ifn_876.Invoke_O_O__O(arg_877, arg_878) } else { tmp14 = linked_875.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_874, arg_877, arg_878) }
//line :139:1
	var tmp15 any = tmp14; var tmp16 any; var root_879 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_881 lang.IFn
	if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = A_arbace_j2g_dyncf_A_const_172; var arg_883 any = A_arbace_j2g_dyncf_A_const_173; if linked_880 == nil { tmp16 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { tmp16 = linked_880.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) }
//line :139:1
	var tmp17 any = tmp16; var tmp18 any; var root_884 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_886 lang.IFn
	if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = A_arbace_j2g_dyncf_A_const_174; var arg_888 any = A_arbace_j2g_dyncf_A_const_175; if linked_885 == nil { tmp18 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { tmp18 = linked_885.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) }
//line :139:1
	arg_892 = lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp9, tmp11, tmp13, tmp15, tmp17, tmp18); var arg_893 any = A_arbace_j2g_dyncf_A_const_176; if linked_890 == nil { tmp7 = ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { tmp7 = linked_890.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) }
//line :123:1
	var tmp19 any = tmp3.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, A_arbace_j2g_dyncf_A_const_177); var tmp20 any = A_arbace_j2g_dyncf_A_const_158; var tmp21 any = A_arbace_j2g_dyncf_A_const_159; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyncf_A_const_178; var tmp24 any; var root_894 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_896 lang.IFn















































































	if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = Lit_4; var arg_898 any = Lit_5; if linked_895 == nil { tmp24 = ifn_896.Invoke_O_O__O(arg_897, arg_898) } else { tmp24 = linked_895.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_894, arg_897, arg_898) }
//line :123:1
	var tmp25 any = tmp24; var tmp26 any; var root_909 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_911 lang.IFn
















































































	if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any; var tmp27 any; var root_899 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = A_arbace_j2g_dyncf_A_const_179; var arg_903 any = A_arbace_j2g_dyncf_A_const_180; if linked_900 == nil { tmp27 = ifn_901.Invoke_O_O__O(arg_902, arg_903) } else { tmp27 = linked_900.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_899, arg_902, arg_903) }; var tmp28 any = tmp27; var tmp29 any; var root_904 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = A_arbace_j2g_dyncf_A_const_181; var arg_908 any = A_arbace_j2g_dyncf_A_const_182; if linked_905 == nil { tmp29 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { tmp29 = linked_905.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }; arg_912 = lang.Tuple_Create_O_O__IPersistentVector(tmp28, tmp29); var arg_913 any = A_arbace_j2g_dyncf_A_const_183; if linked_910 == nil { tmp26 = ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { tmp26 = linked_910.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) }
//line :123:1
	var tmp30 any = tmp22.Invoke_O_O_O_O__O(tmp23, tmp25, tmp26, A_arbace_j2g_dyncf_A_const_184); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_dyncf_A_const_185; var tmp33 any; var root_914 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_916 lang.IFn























































































	if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = Lit_6; var arg_918 any = Lit_7; if linked_915 == nil { tmp33 = ifn_916.Invoke_O_O__O(arg_917, arg_918) } else { tmp33 = linked_915.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_914, arg_917, arg_918) }
//line :123:1
	var tmp34 any = tmp33; var tmp35 any; var root_924 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_926 lang.IFn
























































































	if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any; var tmp36 any; var root_919 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = A_arbace_j2g_dyncf_A_const_186; var arg_923 any = A_arbace_j2g_dyncf_A_const_187; if linked_920 == nil { tmp36 = ifn_921.Invoke_O_O__O(arg_922, arg_923) } else { tmp36 = linked_920.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_919, arg_922, arg_923) }; arg_927 = lang.Tuple_Create_O__IPersistentVector(tmp36); var arg_928 any = A_arbace_j2g_dyncf_A_const_188; if linked_925 == nil { tmp35 = ifn_926.Invoke_O_O__O(arg_927, arg_928) } else { tmp35 = linked_925.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_924, arg_927, arg_928) }
//line :123:1
	var tmp37 any = tmp31.Invoke_O_O_O_O__O(tmp32, tmp34, tmp35, A_arbace_j2g_dyncf_A_const_189); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp39 any = A_arbace_j2g_dyncf_A_const_190; var tmp40 any; var root_929 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_931 lang.IFn



























































































	if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = Lit_8; var arg_933 any = Lit_9; if linked_930 == nil { tmp40 = ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { tmp40 = linked_930.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_929, arg_932, arg_933) }
//line :123:1
	var tmp41 any = tmp40; var tmp42 any; var root_934 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_936 lang.IFn




























































































	if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = A_arbace_j2g_dyncf_A_const_192; var arg_938 any = A_arbace_j2g_dyncf_A_const_193; if linked_935 == nil { tmp42 = ifn_936.Invoke_O_O__O(arg_937, arg_938) } else { tmp42 = linked_935.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_934, arg_937, arg_938) }
//line :123:1
	var tmp43 any = tmp42; var tmp44 any; var root_939 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_941 lang.IFn




























































































	if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = A_arbace_j2g_dyncf_A_const_194; var arg_943 any = A_arbace_j2g_dyncf_A_const_195; if linked_940 == nil { tmp44 = ifn_941.Invoke_O_O__O(arg_942, arg_943) } else { tmp44 = linked_940.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_939, arg_942, arg_943) }
//line :123:1
	var tmp45 any = tmp44; var tmp46 any; var root_944 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_946 lang.IFn




























































































	if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = A_arbace_j2g_dyncf_A_const_196; var arg_948 any = A_arbace_j2g_dyncf_A_const_197; if linked_945 == nil { tmp46 = ifn_946.Invoke_O_O__O(arg_947, arg_948) } else { tmp46 = linked_945.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_944, arg_947, arg_948) }
//line :123:1
	var tmp47 any = tmp46; var tmp48 any; var root_949 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_951 lang.IFn




























































































	if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = A_arbace_j2g_dyncf_A_const_198; var arg_953 any = A_arbace_j2g_dyncf_A_const_199; if linked_950 == nil { tmp48 = ifn_951.Invoke_O_O__O(arg_952, arg_953) } else { tmp48 = linked_950.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_949, arg_952, arg_953) }
//line :123:1
	var tmp49 any = tmp38.Invoke_O_O_O_O__O(tmp39, tmp41, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp43, tmp45, tmp47, tmp48), A_arbace_j2g_dyncf_A_const_191); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp51 any = A_arbace_j2g_dyncf_A_const_200; var tmp52 any; var root_954 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_956 lang.IFn



































































































	if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = Lit_10; var arg_958 any = Lit_11; if linked_955 == nil { tmp52 = ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { tmp52 = linked_955.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_954, arg_957, arg_958) }
//line :123:1
	var tmp53 any = tmp52; var tmp54 any; var root_979 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_981 lang.IFn




































































































	if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var tmp55 any; var root_959 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = A_arbace_j2g_dyncf_A_const_201; var arg_963 any = A_arbace_j2g_dyncf_A_const_202; if linked_960 == nil { tmp55 = ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { tmp55 = linked_960.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) }; var tmp56 any = tmp55; var tmp57 any; var root_964 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = A_arbace_j2g_dyncf_A_const_203; var arg_968 any = A_arbace_j2g_dyncf_A_const_204; if linked_965 == nil { tmp57 = ifn_966.Invoke_O_O__O(arg_967, arg_968) } else { tmp57 = linked_965.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_964, arg_967, arg_968) }; var tmp58 any = tmp57; var tmp59 any; var root_969 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = A_arbace_j2g_dyncf_A_const_205; var arg_973 any = A_arbace_j2g_dyncf_A_const_206; if linked_970 == nil { tmp59 = ifn_971.Invoke_O_O__O(arg_972, arg_973) } else { tmp59 = linked_970.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_969, arg_972, arg_973) }; var tmp60 any = tmp59; var tmp61 any; var root_974 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = A_arbace_j2g_dyncf_A_const_207; var arg_978 any = A_arbace_j2g_dyncf_A_const_208; if linked_975 == nil { tmp61 = ifn_976.Invoke_O_O__O(arg_977, arg_978) } else { tmp61 = linked_975.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_974, arg_977, arg_978) }; arg_982 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp56, tmp58, tmp60, tmp61); var arg_983 any = A_arbace_j2g_dyncf_A_const_209; if linked_980 == nil { tmp54 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { tmp54 = linked_980.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }
//line :123:1
	var tmp62 any = tmp50.Invoke_O_O_O_O__O(tmp51, tmp53, tmp54, A_arbace_j2g_dyncf_A_const_210); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyncf_A_const_211; var tmp65 any; var root_984 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_986 lang.IFn











































































































	if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = Lit_12; var arg_988 any = Lit_13; if linked_985 == nil { tmp65 = ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { tmp65 = linked_985.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }
//line :123:1
	var tmp66 any = tmp65; var tmp67 any; var root_989 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_991 lang.IFn












































































































	if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = A_arbace_j2g_dyncf_A_const_213; var arg_993 any = A_arbace_j2g_dyncf_A_const_214; if linked_990 == nil { tmp67 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { tmp67 = linked_990.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }
//line :123:1
	var tmp68 any = tmp67; var tmp69 any; var root_994 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_996 lang.IFn












































































































	if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = A_arbace_j2g_dyncf_A_const_215; var arg_998 any = A_arbace_j2g_dyncf_A_const_216; if linked_995 == nil { tmp69 = ifn_996.Invoke_O_O__O(arg_997, arg_998) } else { tmp69 = linked_995.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_994, arg_997, arg_998) }
//line :123:1
	var tmp70 any = tmp69; var tmp71 any; var root_999 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1001 lang.IFn












































































































	if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = A_arbace_j2g_dyncf_A_const_217; var arg_1003 any = A_arbace_j2g_dyncf_A_const_218; if linked_1000 == nil { tmp71 = ifn_1001.Invoke_O_O__O(arg_1002, arg_1003) } else { tmp71 = linked_1000.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_999, arg_1002, arg_1003) }
//line :123:1
	var tmp72 any = tmp63.Invoke_O_O_O_O__O(tmp64, tmp66, lang.Tuple_Create_O_O_O__IPersistentVector(tmp68, tmp70, tmp71), A_arbace_j2g_dyncf_A_const_212); var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_dyncf_A_const_219; var tmp75 any; var root_1004 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1006 lang.IFn



















































































































	if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = Lit_14; var arg_1008 any = Lit_15; if linked_1005 == nil { tmp75 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { tmp75 = linked_1005.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }
//line :123:1
	var tmp76 any = tmp75; var tmp77 any; var root_1009 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1011 lang.IFn




















































































































	if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = A_arbace_j2g_dyncf_A_const_221; var arg_1013 any = A_arbace_j2g_dyncf_A_const_222; if linked_1010 == nil { tmp77 = ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { tmp77 = linked_1010.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) }
//line :123:1
	var tmp78 any = tmp73.Invoke_O_O_O_O__O(tmp74, tmp76, lang.Tuple_Create_O__IPersistentVector(tmp77), A_arbace_j2g_dyncf_A_const_220); var tmp79 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp80 any = A_arbace_j2g_dyncf_A_const_223; var tmp81 any; var root_1014 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1016 lang.IFn


























































































































	if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = Lit_16; var arg_1018 any = Lit_17; if linked_1015 == nil { tmp81 = ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { tmp81 = linked_1015.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) }
//line :123:1
	var tmp82 any = tmp81; var tmp83 any; var root_1019 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1021 lang.IFn



























































































































	if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = A_arbace_j2g_dyncf_A_const_225; var arg_1023 any = A_arbace_j2g_dyncf_A_const_226; if linked_1020 == nil { tmp83 = ifn_1021.Invoke_O_O__O(arg_1022, arg_1023) } else { tmp83 = linked_1020.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1019, arg_1022, arg_1023) }
//line :123:1
	var tmp84 any = tmp83; var tmp85 any; var root_1024 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1026 lang.IFn



























































































































	if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = A_arbace_j2g_dyncf_A_const_227; var arg_1028 any = A_arbace_j2g_dyncf_A_const_228; if linked_1025 == nil { tmp85 = ifn_1026.Invoke_O_O__O(arg_1027, arg_1028) } else { tmp85 = linked_1025.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1024, arg_1027, arg_1028) }
//line :123:1
	var tmp86 any = tmp79.Invoke_O_O_O_O__O(tmp80, tmp82, lang.Tuple_Create_O_O__IPersistentVector(tmp84, tmp85), A_arbace_j2g_dyncf_A_const_224); var tmp87 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp88 any = A_arbace_j2g_dyncf_A_const_229; var tmp89 any; var root_1029 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1031 lang.IFn































































































































	if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = Lit_18; var arg_1033 any = Lit_19; if linked_1030 == nil { tmp89 = ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { tmp89 = linked_1030.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) }
//line :123:1
	var tmp90 any = tmp89; var tmp91 any; var root_1039 any = A_arbace_j2g_dyncf_A_const_19.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1041 lang.IFn
































































































































	if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any; var tmp92 any; var root_1034 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = A_arbace_j2g_dyncf_A_const_230; var arg_1038 any = A_arbace_j2g_dyncf_A_const_231; if linked_1035 == nil { tmp92 = ifn_1036.Invoke_O_O__O(arg_1037, arg_1038) } else { tmp92 = linked_1035.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1034, arg_1037, arg_1038) }; arg_1042 = lang.Tuple_Create_O__IPersistentVector(tmp92); var arg_1043 any = A_arbace_j2g_dyncf_A_const_232; if linked_1040 == nil { tmp91 = ifn_1041.Invoke_O_O__O(arg_1042, arg_1043) } else { tmp91 = linked_1040.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1039, arg_1042, arg_1043) }
//line :123:1
	var tmp93 any = tmp87.Invoke_O_O_O_O__O(tmp88, tmp90, tmp91, A_arbace_j2g_dyncf_A_const_233); var tmp94 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp95 any = A_arbace_j2g_dyncf_A_const_234; var tmp96 any; var root_1044 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1046 lang.IFn




































































































































	if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = Lit_20; var arg_1048 any = Lit_21; if linked_1045 == nil { tmp96 = ifn_1046.Invoke_O_O__O(arg_1047, arg_1048) } else { tmp96 = linked_1045.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1044, arg_1047, arg_1048) }
//line :123:1
	var tmp97 any = tmp96; var tmp98 any; var root_1049 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1051 lang.IFn





































































































































	if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = A_arbace_j2g_dyncf_A_const_236; var arg_1053 any = A_arbace_j2g_dyncf_A_const_237; if linked_1050 == nil { tmp98 = ifn_1051.Invoke_O_O__O(arg_1052, arg_1053) } else { tmp98 = linked_1050.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1049, arg_1052, arg_1053) }
//line :123:1
	var tmp99 any = tmp98; var tmp100 any; var root_1054 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1056 lang.IFn





































































































































	if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = A_arbace_j2g_dyncf_A_const_238; var arg_1058 any = A_arbace_j2g_dyncf_A_const_239; if linked_1055 == nil { tmp100 = ifn_1056.Invoke_O_O__O(arg_1057, arg_1058) } else { tmp100 = linked_1055.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1054, arg_1057, arg_1058) }
//line :123:1
	var tmp101 any = tmp100; var tmp102 any; var root_1059 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1061 lang.IFn





































































































































	if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = A_arbace_j2g_dyncf_A_const_240; var arg_1063 any = A_arbace_j2g_dyncf_A_const_241; if linked_1060 == nil { tmp102 = ifn_1061.Invoke_O_O__O(arg_1062, arg_1063) } else { tmp102 = linked_1060.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1059, arg_1062, arg_1063) }
//line :123:1
	var tmp103 any = tmp102; var tmp104 any; var root_1064 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1066 lang.IFn





































































































































	if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = A_arbace_j2g_dyncf_A_const_242; var arg_1068 any = A_arbace_j2g_dyncf_A_const_243; if linked_1065 == nil { tmp104 = ifn_1066.Invoke_O_O__O(arg_1067, arg_1068) } else { tmp104 = linked_1065.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1064, arg_1067, arg_1068) }
//line :123:1
	var tmp105 any = tmp104; var tmp106 any; var root_1069 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1071 lang.IFn






































































































































	if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = A_arbace_j2g_dyncf_A_const_244; var arg_1073 any = A_arbace_j2g_dyncf_A_const_245; if linked_1070 == nil { tmp106 = ifn_1071.Invoke_O_O__O(arg_1072, arg_1073) } else { tmp106 = linked_1070.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1069, arg_1072, arg_1073) }
//line :123:1
	var tmp107 any = tmp106; var tmp108 any; var root_1074 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1076 lang.IFn






































































































































	if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = A_arbace_j2g_dyncf_A_const_246; var arg_1078 any = A_arbace_j2g_dyncf_A_const_247; if linked_1075 == nil { tmp108 = ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { tmp108 = linked_1075.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) }
//line :123:1
	var tmp109 any = tmp94.Invoke_O_O_O_O__O(tmp95, tmp97, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp99, tmp101, tmp103, tmp105, tmp107, tmp108), A_arbace_j2g_dyncf_A_const_235); var tmp110 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp111 any = A_arbace_j2g_dyncf_A_const_248; var tmp112 any; var root_1079 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1081 lang.IFn






































































































































































	if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = Lit_22; var arg_1083 any = Lit_23; if linked_1080 == nil { tmp112 = ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { tmp112 = linked_1080.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) }
//line :123:1
	var tmp113 any = tmp112; var tmp114 any; var root_1084 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1086 lang.IFn







































































































































































	if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = A_arbace_j2g_dyncf_A_const_250; var arg_1088 any = A_arbace_j2g_dyncf_A_const_251; if linked_1085 == nil { tmp114 = ifn_1086.Invoke_O_O__O(arg_1087, arg_1088) } else { tmp114 = linked_1085.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1084, arg_1087, arg_1088) }
//line :123:1
	var tmp115 any = tmp114; var tmp116 any; var root_1089 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1091 lang.IFn







































































































































































	if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = A_arbace_j2g_dyncf_A_const_252; var arg_1093 any = A_arbace_j2g_dyncf_A_const_253; if linked_1090 == nil { tmp116 = ifn_1091.Invoke_O_O__O(arg_1092, arg_1093) } else { tmp116 = linked_1090.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1089, arg_1092, arg_1093) }
//line :123:1
	var tmp117 any = tmp116; var tmp118 any; var root_1094 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1096 lang.IFn







































































































































































	if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = A_arbace_j2g_dyncf_A_const_254; var arg_1098 any = A_arbace_j2g_dyncf_A_const_255; if linked_1095 == nil { tmp118 = ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { tmp118 = linked_1095.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) }
//line :123:1
	var tmp119 any = tmp118; var tmp120 any; var root_1099 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1101 lang.IFn







































































































































































	if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = A_arbace_j2g_dyncf_A_const_256; var arg_1103 any = A_arbace_j2g_dyncf_A_const_257; if linked_1100 == nil { tmp120 = ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { tmp120 = linked_1100.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103) }
//line :123:1
	var tmp121 any = tmp110.Invoke_O_O_O_O__O(tmp111, tmp113, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp115, tmp117, tmp119, tmp120), A_arbace_j2g_dyncf_A_const_249); var tmp122 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp123 any = A_arbace_j2g_dyncf_A_const_258; var tmp124 any; var root_1104 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1106 lang.IFn













































































































































































	if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = Lit_24; var arg_1108 any = Lit_25; if linked_1105 == nil { tmp124 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { tmp124 = linked_1105.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) }
//line :123:1
	var tmp125 any = tmp124; var tmp126 any; var root_1109 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1111 lang.IFn














































































































































































	if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = A_arbace_j2g_dyncf_A_const_260; var arg_1113 any = A_arbace_j2g_dyncf_A_const_261; if linked_1110 == nil { tmp126 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { tmp126 = linked_1110.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }
//line :123:1
	var tmp127 any = tmp126; var tmp128 any; var root_1114 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1116 lang.IFn














































































































































































	if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = A_arbace_j2g_dyncf_A_const_262; var arg_1118 any = A_arbace_j2g_dyncf_A_const_263; if linked_1115 == nil { tmp128 = ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { tmp128 = linked_1115.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) }
//line :123:1
	var tmp129 any = tmp128; var tmp130 any; var root_1119 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1121 lang.IFn














































































































































































	if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = A_arbace_j2g_dyncf_A_const_264; var arg_1123 any = A_arbace_j2g_dyncf_A_const_265; if linked_1120 == nil { tmp130 = ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { tmp130 = linked_1120.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) }
//line :123:1
	var tmp131 any = tmp130; var tmp132 any; var root_1124 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1126 lang.IFn














































































































































































	if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = A_arbace_j2g_dyncf_A_const_266; var arg_1128 any = A_arbace_j2g_dyncf_A_const_267; if linked_1125 == nil { tmp132 = ifn_1126.Invoke_O_O__O(arg_1127, arg_1128) } else { tmp132 = linked_1125.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1124, arg_1127, arg_1128) }
//line :123:1
	var tmp133 any = tmp132; var tmp134 any; var root_1129 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1131 lang.IFn














































































































































































	if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = A_arbace_j2g_dyncf_A_const_268; var arg_1133 any = A_arbace_j2g_dyncf_A_const_269; if linked_1130 == nil { tmp134 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { tmp134 = linked_1130.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }
//line :123:1
	var tmp135 any = tmp122.Invoke_O_O_O_O__O(tmp123, tmp125, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp127, tmp129, tmp131, tmp133, tmp134), A_arbace_j2g_dyncf_A_const_259); var tmp136 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_25.GetRawRoot__O()); var tmp137 any = A_arbace_j2g_dyncf_A_const_270; var tmp138 any; var root_1134 any = A_arbace_j2g_dyncf_A_const_163.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, A_arbace_j2g_dyncf_native_name_A_fn_class); var ifn_1136 lang.IFn






















































































































































































	if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = Lit_26; var arg_1138 any = Lit_27; if linked_1135 == nil { tmp138 = ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { tmp138 = linked_1135.(*A_arbace_j2g_dyncf_native_name_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }
//line :123:1
	var tmp139 any = tmp138; var tmp140 any; var root_1139 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1141 lang.IFn























































































































































































	if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = A_arbace_j2g_dyncf_A_const_271; var arg_1143 any = A_arbace_j2g_dyncf_A_const_272; if linked_1140 == nil { tmp140 = ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { tmp140 = linked_1140.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) }
//line :123:1
	var tmp141 any = tmp140; var tmp142 any; var root_1144 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1146 lang.IFn























































































































































































	if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = A_arbace_j2g_dyncf_A_const_273; var arg_1148 any = A_arbace_j2g_dyncf_A_const_274; if linked_1145 == nil { tmp142 = ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { tmp142 = linked_1145.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) }
//line :123:1
	var tmp143 any = tmp142; var tmp144 any; var root_1149 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1151 lang.IFn























































































































































































	if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = A_arbace_j2g_dyncf_A_const_275; var arg_1153 any = A_arbace_j2g_dyncf_A_const_276; if linked_1150 == nil { tmp144 = ifn_1151.Invoke_O_O__O(arg_1152, arg_1153) } else { tmp144 = linked_1150.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1149, arg_1152, arg_1153) }
//line :123:1
	var tmp145 any = tmp144; var tmp146 any; var root_1154 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1156 lang.IFn























































































































































































	if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = A_arbace_j2g_dyncf_A_const_277; var arg_1158 any = A_arbace_j2g_dyncf_A_const_278; if linked_1155 == nil { tmp146 = ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { tmp146 = linked_1155.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) }
//line :123:1
	var tmp147 any = tmp146; var tmp148 any; var root_1159 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1161 lang.IFn
























































































































































































	if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = A_arbace_j2g_dyncf_A_const_279; var arg_1163 any = A_arbace_j2g_dyncf_A_const_280; if linked_1160 == nil { tmp148 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { tmp148 = linked_1160.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }
//line :123:1
	var tmp149 any = tmp148; var tmp150 any; var root_1164 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1166 lang.IFn
























































































































































































	if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = A_arbace_j2g_dyncf_A_const_281; var arg_1168 any = A_arbace_j2g_dyncf_A_const_282; if linked_1165 == nil { tmp150 = ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { tmp150 = linked_1165.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) }
//line :123:1
	var tmp151 any = tmp150; var tmp152 any; var root_1169 any = A_arbace_j2g_dyncf_A_const_42.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, A_arbace_j2g_dyncf_tag_A_fn_class); var ifn_1171 lang.IFn
























































































































































































	if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = A_arbace_j2g_dyncf_A_const_283; var arg_1173 any = A_arbace_j2g_dyncf_A_const_284; if linked_1170 == nil { tmp152 = ifn_1171.Invoke_O_O__O(arg_1172, arg_1173) } else { tmp152 = linked_1170.(*A_arbace_j2g_dyncf_tag_A).Invoke_O_O_O__O(root_1169, arg_1172, arg_1173) }
//line :123:1
	arg_1178 = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp19, tmp20, tmp21, tmp30, tmp37, tmp49, tmp62, tmp72, tmp78, tmp86, tmp93, tmp109, tmp121, tmp135, tmp136.Invoke_O_O_O_O__O(tmp137, tmp139, lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp141, tmp143, tmp145, tmp147, tmp149, tmp151, tmp152)), A_arbace_j2g_dyncf_A_const_285), A_arbace_j2g_dyncf_A_const_160)); if linked_1175 == nil { return ifn_1176.Invoke_O_O__O(arg_1177, arg_1178) } else { return linked_1175.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1174, arg_1177, arg_1178)
	}
}













































































































































































































func A_arbace_j2g_dyncf_strip_anns_A_New() *A_arbace_j2g_dyncf_strip_anns_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Ctor() {}
//line :331:1
func (t *A_arbace_j2g_dyncf_strip_anns_A) Invoke_O_O__O(self, x__0 any) any {
	var root_1189 any = A_arbace_j2g_dyncf_A_const_286.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_walk.A_arbace_walk_postwalk_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any; var tmp1 any = A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_New(); var tmp2 *jrt.Class; var fncls__1188 *jrt.Class = A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class; if fncls__1188 == nil { var fncls__1188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class = fncls__1188d; tmp2 = fncls__1188d } else { tmp2 = fncls__1188 }; arg_1192 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1193 any = x__0; if linked_1190 == nil { return ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { return linked_1190.(*aot_arbace_walk.A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) } }
//line :332:1
func A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_New() *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_strip_anns_fn__292000090_A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A) Ctor() {}
//line :332:1
func (t *A_arbace_j2g_dyncf_strip_anns_fn__292000090_A) Invoke_O_O__O(self, y__1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_1179 any = A_arbace_j2g_dyncf_A_const_287.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = y__1; if linked_1180 == nil { and__1927000168__auto____2 = ifn_1181.Invoke_O__O(arg_1182) } else { and__1927000168__auto____2 = linked_1180.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1179, arg_1182) }; if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = A_arbace_j2g_dyncf_A_const_288.Invoke_O__O(y__1) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_1183 any = A_arbace_j2g_dyncf_A_const_289.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = y__1; var arg_1187 any = A_arbace_j2g_dyncf_A_const_288; if linked_1184 == nil { return ifn_1185.Invoke_O_O__O(arg_1186, arg_1187) } else { return linked_1184.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1183, arg_1186, arg_1187) } } else { return y__1 } }

func A_arbace_j2g_dyncf_generics_text_A_New() *A_arbace_j2g_dyncf_generics_text_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Ctor() {}
//line :334:1
func (t *A_arbace_j2g_dyncf_generics_text_A) Invoke_O_O__O(self, T__0_ any) any { var extendable__2 any; var root_1199 any = A_arbace_j2g_dyncf_A_const_290.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1201 lang.IFn; if





	linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any; var root_1194 any = A_arbace_j2g_dyncf_A_const_142.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = A_arbace_j2g_dyncf_A_const_291.GetRawRoot__O(); var arg_1198 any = A_arbace_j2g_dyncf_A_const_292; if linked_1195 == nil { arg_1202 = ifn_1196.Invoke_O_O__O(arg_1197, arg_1198) } else { arg_1202 = linked_1195.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1194, arg_1197, arg_1198) }; if linked_1200 == nil { extendable__2 = ifn_1201.Invoke_O__O(arg_1202) } else { extendable__2 = linked_1200.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1199, arg_1202) }; var entries__3 any; var iter__1927001039__auto____3 any; var tmp1 any = /*line :334:1*/A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_New_O(extendable__2); var tmp2 *jrt.Class; var fncls__1747 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class; if






	fncls__1747 == nil { var fncls__1747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class = fncls__1747d; tmp2 = fncls__1747d } else { tmp2 = fncls__1747 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1831 any = A_arbace_j2g_dyncf_A_const_318.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1833 lang.IFn; if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any = T__0_; if linked_1832 == nil { tmp4 = ifn_1833.Invoke_O__O(arg_1834) } else { tmp4 = linked_1832.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1831, arg_1834) }; entries__3 = tmp3.Invoke_O__O(tmp4); var root_1844 any =




















	A_arbace_j2g_dyncf_A_const_37.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_38.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_j2g_dyncf_A_const_319, nil, A_arbace_j2g_dyncf_A_const_320, nil, A_arbace_j2g_dyncf_A_const_321, jrt.Boolean_FALSE.Ref()); if linked_1845 == nil { ifn_1846.Invoke_O__O(arg_1847) } else { linked_1845.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1844, arg_1847) }; var tmp5 any; tmp10 := /*line :334:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




























		{ var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, Lit_32, nil, Lit_33); var tmp7 any; var root_1823 any = A_arbace_j2g_dyncf_A_const_316.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1825 lang.IFn

			if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = Lit_34; var arg_1827 any; var iter__1927001039__auto____10 any; var tmp8 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_New(); var tmp9 *jrt.Class; var fncls__1822 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class; if fncls__1822 == nil { var fncls__1822d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class = fncls__1822d; tmp9 = fncls__1822d } else { tmp9 = fncls__1822 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_1827 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(entries__3); if linked_1824 == nil { tmp7 = ifn_1825.Invoke_O_O__O(arg_1826, arg_1827) } else { tmp7 = linked_1824.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1823, arg_1826, arg_1827) }
//line :363:1
			tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, nil, tmp7, nil)).Ref() }
//line :334:1
		return nil }(); var root_1828 any = A_arbace_j2g_dyncf_A_const_35.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1830 lang.IFn; if



























	linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; if linked_1829 == nil { ifn_1830.Invoke__O() } else { linked_1829.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1828) }; if /*line :334:1*/ tmp10 != nil { panic(tmp10) }; return tmp5 }






func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A{}; t.Ctor_O(p0); return t }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A) Ctor_O(c__extendable any) { t.F_extendable = c__extendable }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A) Invoke_O_O__O(self, s__292000094__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_New_O_O_O(self, s__292000094__1, t.F_extendable); var tmp2 *jrt.Class; var fncls__1746 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class; if fncls__1746 == nil { var fncls__1746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class = fncls__1746d; tmp2 = fncls__1746d } else { tmp2 = fncls__1746 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :341:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A) Ctor_O_O_O(c__iter__292000093, c__s__292000094, c__extendable any) { t.F_iter__292000093 = c__iter__292000093; t.F_s__292000094 = c__s__292000094; t.F_extendable = c__extendable }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A) Invoke_O__O(self any) any { { var s__292000094__1 any; var t_ any = t.F_s__292000094; t.F_s__292000094 = nil; s__292000094__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1203 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = s__292000094__1; if linked_1204 == nil { temp__1927000414__auto____2 = ifn_1205.Invoke_O__O(arg_1206) } else { temp__1927000414__auto____2 = linked_1204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1203, arg_1206) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000094__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1207 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = s__292000094__3; if linked_1208 == nil { tmp1 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp1 = linked_1208.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1207, arg_1210) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1211 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = s__292000094__3; if linked_1212 == nil { c__1927001037__auto____4 = ifn_1213.Invoke_O__O(arg_1214) } else { c__1927001037__auto____4 = linked_1212.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1211, arg_1214) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000096__6 any; var root_1215 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1216 == nil { b__292000096__6 = ifn_1217.Invoke_O__O(arg_1218) } else { b__292000096__6 = linked_1216.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1215, arg_1218) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_New_O_O_I_O(b__292000096__6, t.F_extendable, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1461 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class; if fncls__1461 == nil { var fncls__1461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class = fncls__1461d; tmp3 = fncls__1461d } else { tmp3 = fncls__1461 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1470 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any; var root_1462 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = b__292000096__6; if linked_1463 == nil { arg_1473 = ifn_1464.Invoke_O__O(arg_1465) } else { arg_1473 = linked_1463.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1462, arg_1465) }; var arg_1474 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000093); var tmp5 any; var root_1466 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = s__292000094__3; if linked_1467 == nil { tmp5 = ifn_1468.Invoke_O__O(arg_1469) } else { tmp5 = linked_1467.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1466, arg_1469) }; arg_1474 = tmp4.Invoke_O__O(tmp5); if linked_1471 == nil { return ifn_1472.Invoke_O_O__O(arg_1473, arg_1474) } else { return linked_1471.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1470, arg_1473, arg_1474) } } else { var root_1479 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any; var root_1475 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = b__292000096__6; if linked_1476 == nil { arg_1482 = ifn_1477.Invoke_O__O(arg_1478) } else { arg_1482 = linked_1476.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1475, arg_1478) }; var arg_1483 any; if linked_1480 == nil { return ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { return linked_1480.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) } } } else { var n__4 any; var root_1484 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = s__292000094__3; if linked_1485 == nil { n__4 = ifn_1486.Invoke_O__O(arg_1487) } else { n__4 = linked_1485.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1484, arg_1487) }; var d__5 any; var root_1488 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1490 lang.IFn
														if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = n__4; if linked_1489 == nil { d__5 = ifn_1490.Invoke_O__O(arg_1491) } else { d__5 = linked_1489.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1488, arg_1491) }
//line :341:1
	var tmp6 any
	var and__1927000168__auto____6 any = d__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1492 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_313); var arg_1495 any = tmp7.Invoke_O__O(A_arbace_j2g_dyncf_A_const_294.Invoke_O__O(d__5)); if linked_1493 == nil { and__1927000168__auto____7 = ifn_1494.Invoke_O__O(arg_1495) } else { and__1927000168__auto____7 = linked_1493.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1492, arg_1495) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var or__1927000174__auto____8 any; var root_1496 any = A_arbace_j2g_dyncf_A_const_295.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1498 lang.IFn
		if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = n__4; if linked_1497 == nil { or__1927000174__auto____8 = ifn_1498.Invoke_O__O(arg_1499) } else { or__1927000174__auto____8 = linked_1497.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1496, arg_1499) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__4) } } else {
//line :345:1
			tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }
//line :341:1
	if jrt.J2g_Truth(tmp6) { var g__6 any; var tmp8 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_New_O(n__4); var tmp9 *jrt.Class
		var fncls__1500 /*line :341:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class





		if fncls__1500 == nil { var fncls__1500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class = fncls__1500d; tmp9 = fncls__1500d } else { tmp9 = fncls__1500 }; g__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()
//line :341:1
		if jrt.J2g_Truth(g__6) { var generic_QMARK___7 any; var root_1501 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1503 lang.IFn







			if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = A_arbace_j2g_dyncf_A_const_297.Invoke_O__O(g__6); if linked_1502 == nil { generic_QMARK___7 = ifn_1503.Invoke_O__O(arg_1504) } else { generic_QMARK___7 = linked_1502.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1501, arg_1504) }
//line :341:1
			var supers__8 any; var root_1510 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1512 lang.IFn








			if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any; var root_1505 any = A_arbace_j2g_dyncf_A_const_299.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = A_arbace_j2g_dyncf_A_const_300.GetRawRoot__O(); var arg_1509 any = A_arbace_j2g_dyncf_A_const_301.Invoke_O__O(g__6); if linked_1506 == nil { arg_1513 = ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { arg_1513 = linked_1506.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) }; if linked_1511 == nil { supers__8 = ifn_1512.Invoke_O__O(arg_1513) } else { supers__8 = linked_1511.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1510, arg_1513) }
//line :341:1
			var abstract_QMARK___9 any; var and__1927000168__auto____9 any; var root_1518 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1520 lang.IFn









			if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any; var root_1514 any = A_arbace_j2g_dyncf_A_const_295.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = n__4; if linked_1515 == nil { arg_1521 = ifn_1516.Invoke_O__O(arg_1517) } else { arg_1521 = linked_1515.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1514, arg_1517) }; if linked_1519 == nil { and__1927000168__auto____9 = ifn_1520.Invoke_O__O(arg_1521) } else { and__1927000168__auto____9 = linked_1519.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1518, arg_1521) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp10 int64; var na_1522 any; var or__1927000174__auto____10 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(d__5); if jrt.J2g_Truth(or__1927000174__auto____10) { na_1522 = or__1927000174__auto____10 } else { na_1522 = A_arbace_j2g_dyncf_A_const_303 }; var na_1523 int64 = 1024; if jrt.Long_InstanceOf(na_1522) { var n0_1524 int64 = jrt.NN(jrt.Long_Cast(na_1522)).LongValue__J(); var n1_1525 int64 = na_1523; tmp10 = n0_1524 & n1_1525 } else { tmp10 = lang.Numbers_And_O_J__J_NoInit(na_1522, na_1523) }; abstract_QMARK___9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp10)).Ref() } else { abstract_QMARK___9 = and__1927000168__auto____9 }
//line :341:1
			var tmp11 any
			var or__1927000174__auto____10_2 any = generic_QMARK___7









			if jrt.J2g_Truth(or__1927000174__auto____10_2) { tmp11 = or__1927000174__auto____10_2 } else { var or__1927000174__auto____11 any = abstract_QMARK___9; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp11 = or__1927000174__auto____11 } else { var root_1532 any = A_arbace_j2g_dyncf_A_const_304.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any; var root_1527 any = A_arbace_j2g_dyncf_A_const_305.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var arg_1531 any = A_arbace_j2g_dyncf_A_const_306; if linked_1528 == nil { arg_1535 = ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { arg_1535 = linked_1528.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) }; var arg_1536 any = supers__8; if linked_1533 == nil { tmp11 = ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { tmp11 = linked_1533.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) } } }
//line :341:1
			if jrt.J2g_Truth(tmp11) { var root_1729 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any; var tmp12 any; var root_1721 any = A_arbace_j2g_dyncf_A_const_307.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_1723 lang.IFn











				if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any; var G__292000126__10_ any; var tmp13 any = A_arbace_j2g_dyncf_A_const_297; var tmp14 any; var root_1537 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1539 lang.IFn
				if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = A_arbace_j2g_dyncf_A_const_297.Invoke_O__O(g__6); if linked_1538 == nil { tmp14 = ifn_1539.Invoke_O__O(arg_1540) } else { tmp14 = linked_1538.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1537, arg_1540) }
//line :353:1
				G__292000126__10_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, A_arbace_j2g_dyncf_A_const_301, supers__8)); var G__292000126__11_ any
				if jrt.J2g_Truth(abstract_QMARK___9) {
					var root_1622 any = A_arbace_j2g_dyncf_A_const_308.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = G__292000126__10_; var arg_1626 any = A_arbace_j2g_dyncf_A_const_309; var arg_1627 any; var root_1618 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any; var iter__1927001039__auto____11 any; var tmp15 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_New(); var tmp16 *jrt.Class; var fncls__1617 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class; if fncls__1617 == nil { var fncls__1617d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class = fncls__1617d; tmp16 = fncls__1617d } else { tmp16 = fncls__1617 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); arg_1621 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_j2g_dyncf_A_const_105.Invoke_O__O(d__5)); if linked_1619 == nil { arg_1627 = ifn_1620.Invoke_O__O(arg_1621) } else { arg_1627 = linked_1619.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1618, arg_1621) }; if linked_1623 == nil { G__292000126__11_ = ifn_1624.Invoke_O_O_O__O(arg_1625, arg_1626, arg_1627) } else { G__292000126__11_ = linked_1623.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1622, arg_1625, arg_1626, arg_1627) } } else {
//line :354:1
						G__292000126__11_ = G__292000126__10_ }; if jrt.J2g_Truth(generic_QMARK___7) {




							var root_1715 any = A_arbace_j2g_dyncf_A_const_308.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = G__292000126__11_; var arg_1719 any = A_arbace_j2g_dyncf_A_const_105; var arg_1720 any; var root_1711 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any; var iter__1927001039__auto____12 any; var tmp17 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_New(); var tmp18 *jrt.Class; var fncls__1710 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class; if fncls__1710 == nil { var fncls__1710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class = fncls__1710d; tmp18 = fncls__1710d } else { tmp18 = fncls__1710 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); arg_1714 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_j2g_dyncf_A_const_105.Invoke_O__O(g__6)); if linked_1712 == nil { arg_1720 = ifn_1713.Invoke_O__O(arg_1714) } else { arg_1720 = linked_1712.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1711, arg_1714) }; if linked_1716 == nil { arg_1724 = ifn_1717.Invoke_O_O_O__O(arg_1718, arg_1719, arg_1720) } else { arg_1724 = linked_1716.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1715, arg_1718, arg_1719, arg_1720) } } else {
//line :354:1
								arg_1724 = G__292000126__11_ }
//line :353:1
				if linked_1722 == nil { tmp12 = ifn_1723.Invoke_O__O(arg_1724) } else { tmp12 = linked_1722.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_1721, arg_1724) }
//line :341:1
				arg_1732 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp12); var arg_1733 any; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__292000093); var tmp20 any; var root_1725 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = s__292000094__3; if linked_1726 == nil { tmp20 = ifn_1727.Invoke_O__O(arg_1728) } else { tmp20 = linked_1726.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1725, arg_1728) }; arg_1733 = tmp19.Invoke_O__O(tmp20); if linked_1730 == nil { return ifn_1731.Invoke_O_O__O(arg_1732, arg_1733) } else { return linked_1730.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1729, arg_1732, arg_1733) } } else { var tmp21 any; var root_1734 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = s__292000094__3; if linked_1735 == nil { tmp21 = ifn_1736.Invoke_O__O(arg_1737) } else { tmp21 = linked_1735.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1734, arg_1737) }; s__292000094__1 = tmp21; continue L1 } } else { var tmp22 any; var root_1738 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = s__292000094__3; if linked_1739 == nil { tmp22 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp22 = linked_1739.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1738, arg_1741) }; s__292000094__1 = tmp22; continue L1 } } else { var tmp23 any; var root_1742 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = s__292000094__3; if linked_1743 == nil { tmp23 = ifn_1744.Invoke_O__O(arg_1745) } else { tmp23 = linked_1743.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1742, arg_1745) }; s__292000094__1 = tmp23; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :341:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A) Ctor_O_O_I_O(c__b__292000096, c__extendable any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000096 = c__b__292000096; t.F_extendable = c__extendable; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :341:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A) Invoke_O__O(self any) any { { var i__292000095__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000095__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000095__1)); var d__3 any; var root_1219 any = A_arbace_j2g_dyncf_A_const_106.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1221 lang.IFn
																if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = n__2; if linked_1220 == nil { d__3 = ifn_1221.Invoke_O__O(arg_1222) } else { d__3 = linked_1220.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1219, arg_1222) }
//line :341:1
	var tmp2 any
	var and__1927000168__auto____4 any = d__3


	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1223 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_293); var arg_1226 any = tmp3.Invoke_O__O(A_arbace_j2g_dyncf_A_const_294.Invoke_O__O(d__3)); if linked_1224 == nil { and__1927000168__auto____5 = ifn_1225.Invoke_O__O(arg_1226) } else { and__1927000168__auto____5 = linked_1224.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1223, arg_1226) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1227 any = A_arbace_j2g_dyncf_A_const_295.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1229 lang.IFn
		if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = n__2; if linked_1228 == nil { or__1927000174__auto____6 = ifn_1229.Invoke_O__O(arg_1230) } else { or__1927000174__auto____6 = linked_1228.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1227, arg_1230) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__2) } } else {
//line :345:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :341:1
	if jrt.J2g_Truth(tmp2) { var g__4 any; var tmp4 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_New_O(n__2); var tmp5 *jrt.Class
		var fncls__1231 /*line :341:1*/*jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class





		if fncls__1231 == nil { var fncls__1231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class = fncls__1231d; tmp5 = fncls__1231d } else { tmp5 = fncls__1231 }; g__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :341:1
		if jrt.J2g_Truth(g__4) { var generic_QMARK___5 any; var root_1232 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1234 lang.IFn







			if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = A_arbace_j2g_dyncf_A_const_297.Invoke_O__O(g__4); if linked_1233 == nil { generic_QMARK___5 = ifn_1234.Invoke_O__O(arg_1235) } else { generic_QMARK___5 = linked_1233.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1232, arg_1235) }
//line :341:1
			var supers__6 any; var root_1241 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1243 lang.IFn








			if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any; var root_1236 any = A_arbace_j2g_dyncf_A_const_299.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = A_arbace_j2g_dyncf_A_const_300.GetRawRoot__O(); var arg_1240 any = A_arbace_j2g_dyncf_A_const_301.Invoke_O__O(g__4); if linked_1237 == nil { arg_1244 = ifn_1238.Invoke_O_O__O(arg_1239, arg_1240) } else { arg_1244 = linked_1237.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1236, arg_1239, arg_1240) }; if linked_1242 == nil { supers__6 = ifn_1243.Invoke_O__O(arg_1244) } else { supers__6 = linked_1242.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1241, arg_1244) }
//line :341:1
			var abstract_QMARK___7 any; var and__1927000168__auto____7 any; var root_1249 any = A_arbace_j2g_dyncf_A_const_71.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1251 lang.IFn









			if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any; var root_1245 any = A_arbace_j2g_dyncf_A_const_295.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = n__2; if linked_1246 == nil { arg_1252 = ifn_1247.Invoke_O__O(arg_1248) } else { arg_1252 = linked_1246.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1245, arg_1248) }; if linked_1250 == nil { and__1927000168__auto____7 = ifn_1251.Invoke_O__O(arg_1252) } else { and__1927000168__auto____7 = linked_1250.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1249, arg_1252) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp6 int64; var na_1253 any; var or__1927000174__auto____8 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(d__3); if jrt.J2g_Truth(or__1927000174__auto____8) { na_1253 = or__1927000174__auto____8 } else { na_1253 = A_arbace_j2g_dyncf_A_const_303 }; var na_1254 int64 = 1024; if jrt.Long_InstanceOf(na_1253) { var n0_1255 int64 = jrt.NN(jrt.Long_Cast(na_1253)).LongValue__J(); var n1_1256 int64 = na_1254; tmp6 = n0_1255 & n1_1256 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1253, na_1254) }; abstract_QMARK___7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(tmp6)).Ref() } else { abstract_QMARK___7 = and__1927000168__auto____7 }
//line :341:1
			var tmp7 any
			var or__1927000174__auto____8_2 any = generic_QMARK___5









			if jrt.J2g_Truth(or__1927000174__auto____8_2) { tmp7 = or__1927000174__auto____8_2 } else { var or__1927000174__auto____9 any = abstract_QMARK___7; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { var root_1263 any = A_arbace_j2g_dyncf_A_const_304.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any; var root_1258 any = A_arbace_j2g_dyncf_A_const_305.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var arg_1262 any = A_arbace_j2g_dyncf_A_const_306; if linked_1259 == nil { arg_1266 = ifn_1260.Invoke_O_O__O(arg_1261, arg_1262) } else { arg_1266 = linked_1259.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1258, arg_1261, arg_1262) }; var arg_1267 any = supers__6; if linked_1264 == nil { tmp7 = ifn_1265.Invoke_O_O__O(arg_1266, arg_1267) } else { tmp7 = linked_1264.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1263, arg_1266, arg_1267) } } }
//line :341:1
			if jrt.J2g_Truth(tmp7) { var root_1456 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = t.F_b__292000096; var arg_1460 any; var tmp8 any; var root_1452 any = A_arbace_j2g_dyncf_A_const_307.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, A_arbace_j2g_dyncf_strip_anns_A_fn_class); var ifn_1454 lang.IFn











				if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any; var G__292000102__8_ any; var tmp9 any = A_arbace_j2g_dyncf_A_const_297; var tmp10 any; var root_1268 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1270 lang.IFn
				if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = A_arbace_j2g_dyncf_A_const_297.Invoke_O__O(g__4); if linked_1269 == nil { tmp10 = ifn_1270.Invoke_O__O(arg_1271) } else { tmp10 = linked_1269.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1268, arg_1271) }
//line :353:1
				G__292000102__8_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, A_arbace_j2g_dyncf_A_const_301, supers__6)); var G__292000102__9_ any
				if jrt.J2g_Truth(abstract_QMARK___7) {
					var root_1353 any = A_arbace_j2g_dyncf_A_const_308.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = G__292000102__8_; var arg_1357 any = A_arbace_j2g_dyncf_A_const_309; var arg_1358 any; var root_1349 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any; var iter__1927001039__auto____9 any; var tmp11 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_New(); var tmp12 *jrt.Class; var fncls__1348 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class; if fncls__1348 == nil { var fncls__1348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class = fncls__1348d; tmp12 = fncls__1348d } else { tmp12 = fncls__1348 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1352 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_j2g_dyncf_A_const_105.Invoke_O__O(d__3)); if linked_1350 == nil { arg_1358 = ifn_1351.Invoke_O__O(arg_1352) } else { arg_1358 = linked_1350.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1349, arg_1352) }; if linked_1354 == nil { G__292000102__9_ = ifn_1355.Invoke_O_O_O__O(arg_1356, arg_1357, arg_1358) } else { G__292000102__9_ = linked_1354.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1353, arg_1356, arg_1357, arg_1358) } } else {
//line :354:1
						G__292000102__9_ = G__292000102__8_ }; if jrt.J2g_Truth(generic_QMARK___5) {




							var root_1446 any = A_arbace_j2g_dyncf_A_const_308.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = G__292000102__9_; var arg_1450 any = A_arbace_j2g_dyncf_A_const_105; var arg_1451 any; var root_1442 any = A_arbace_j2g_dyncf_A_const_298.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any; var iter__1927001039__auto____10 any; var tmp13 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_New(); var tmp14 *jrt.Class; var fncls__1441 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class; if fncls__1441 == nil { var fncls__1441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class = fncls__1441d; tmp14 = fncls__1441d } else { tmp14 = fncls__1441 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); arg_1445 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_j2g_dyncf_A_const_105.Invoke_O__O(g__4)); if linked_1443 == nil { arg_1451 = ifn_1444.Invoke_O__O(arg_1445) } else { arg_1451 = linked_1443.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1442, arg_1445) }; if linked_1447 == nil { arg_1455 = ifn_1448.Invoke_O_O_O__O(arg_1449, arg_1450, arg_1451) } else { arg_1455 = linked_1447.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1446, arg_1449, arg_1450, arg_1451) } } else {
//line :354:1
								arg_1455 = G__292000102__9_ }
//line :353:1
				if linked_1453 == nil { tmp8 = ifn_1454.Invoke_O__O(arg_1455) } else { tmp8 = linked_1453.(*A_arbace_j2g_dyncf_strip_anns_A).Invoke_O_O__O(root_1452, arg_1455) }
//line :341:1
				arg_1460 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp8); if linked_1457 == nil { ifn_1458.Invoke_O_O__O(arg_1459, arg_1460) } else { linked_1457.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1456, arg_1459, arg_1460) }; i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { i__292000095__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000095__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A{}; t.Ctor_O(p0); return t }
//line :347:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :347:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_296; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :347:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_New_O(p0 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A{}; t.Ctor_O(p0); return t }
//line :347:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :347:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_j2g_dyncf_A_const_296; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A) Ctor() {}
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A) Invoke_O_O__O(self, s__292000104__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_New_O_O(self, s__292000104__1); var tmp2 *jrt.Class; var fncls__1347 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class; if fncls__1347 == nil { var fncls__1347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class = fncls__1347d; tmp2 = fncls__1347d } else { tmp2 = fncls__1347 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A{}; t.Ctor_O_O(p0, p1); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A) Ctor_O_O(c__iter__292000103, c__s__292000104 any) { t.F_iter__292000103 = c__iter__292000103; t.F_s__292000104 = c__s__292000104 }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A) Invoke_O__O(self any) any { { var s__292000104__1 any; var t_ any = t.F_s__292000104; t.F_s__292000104 = nil; s__292000104__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1272 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = s__292000104__1; if linked_1273 == nil { temp__1927000414__auto____2 = ifn_1274.Invoke_O__O(arg_1275) } else { temp__1927000414__auto____2 = linked_1273.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1272, arg_1275) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1276 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = s__292000104__3; if linked_1277 == nil { tmp1 = ifn_1278.Invoke_O__O(arg_1279) } else { tmp1 = linked_1277.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1276, arg_1279) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1280 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = s__292000104__3; if linked_1281 == nil { c__1927001037__auto____4 = ifn_1282.Invoke_O__O(arg_1283) } else { c__1927001037__auto____4 = linked_1281.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1280, arg_1283) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000106__6 any; var root_1284 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1285 == nil { b__292000106__6 = ifn_1286.Invoke_O__O(arg_1287) } else { b__292000106__6 = linked_1285.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1284, arg_1287) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_New_O_I_O(b__292000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1298 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class; if fncls__1298 == nil { var fncls__1298d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class = fncls__1298d; tmp3 = fncls__1298d } else { tmp3 = fncls__1298 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1307 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any; var root_1299 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = b__292000106__6; if linked_1300 == nil { arg_1310 = ifn_1301.Invoke_O__O(arg_1302) } else { arg_1310 = linked_1300.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1299, arg_1302) }; var arg_1311 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000103); var tmp5 any; var root_1303 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = s__292000104__3; if linked_1304 == nil { tmp5 = ifn_1305.Invoke_O__O(arg_1306) } else { tmp5 = linked_1304.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1303, arg_1306) }; arg_1311 = tmp4.Invoke_O__O(tmp5); if linked_1308 == nil { return ifn_1309.Invoke_O_O__O(arg_1310, arg_1311) } else { return linked_1308.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1307, arg_1310, arg_1311) } } else { var root_1316 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any; var root_1312 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = b__292000106__6; if linked_1313 == nil { arg_1319 = ifn_1314.Invoke_O__O(arg_1315) } else { arg_1319 = linked_1313.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1312, arg_1315) }; var arg_1320 any; if linked_1317 == nil { return ifn_1318.Invoke_O_O__O(arg_1319, arg_1320) } else { return linked_1317.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1316, arg_1319, arg_1320) } } } else { var mm__4 any; var root_1321 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = s__292000104__3; if linked_1322 == nil { mm__4 = ifn_1323.Invoke_O__O(arg_1324) } else { mm__4 = linked_1322.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1321, arg_1324) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__4)) { var tmp6 int64; var na_1325 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_1325 = or__1927000174__auto____5 } else { na_1325 = A_arbace_j2g_dyncf_A_const_303 }; var na_1326 int64 = 4098; if jrt.Long_InstanceOf(na_1325) { var n0_1327 int64 = jrt.NN(jrt.Long_Cast(na_1325)).LongValue__J(); var n1_1328 int64 = na_1326; tmp6 = n0_1327 & n1_1328 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1325, na_1326) }
//line :355:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1334 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__4)); var arg_1338 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000103); var tmp8 any; var root_1330 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = s__292000104__3; if linked_1331 == nil { tmp8 = ifn_1332.Invoke_O__O(arg_1333) } else { tmp8 = linked_1331.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1330, arg_1333) }; arg_1338 = tmp7.Invoke_O__O(tmp8); if linked_1335 == nil { return ifn_1336.Invoke_O_O__O(arg_1337, arg_1338) } else { return linked_1335.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1334, arg_1337, arg_1338) } } else { var tmp9 any; var root_1339 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = s__292000104__3; if linked_1340 == nil { tmp9 = ifn_1341.Invoke_O__O(arg_1342) } else { tmp9 = linked_1340.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1339, arg_1342) }; s__292000104__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1343 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = s__292000104__3; if linked_1344 == nil { tmp10 = ifn_1345.Invoke_O__O(arg_1346) } else { tmp10 = linked_1344.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1343, arg_1346) }; s__292000104__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A) Ctor_O_I_O(c__b__292000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000106 = c__b__292000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A) Invoke_O__O(self any) any { { var i__292000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000105__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__2)) { var tmp2 int64; var na_1288 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_1288 = or__1927000174__auto____3 } else { na_1288 = A_arbace_j2g_dyncf_A_const_303 }; var na_1289 int64 = 4098; if jrt.Long_InstanceOf(na_1288) { var n0_1290 int64 = jrt.NN(jrt.Long_Cast(na_1288)).LongValue__J(); var n1_1291 int64 = na_1289; tmp2 = n0_1290 & n1_1291 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1288, na_1289) }
//line :355:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1293 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = t.F_b__292000106; var arg_1297 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__2)); if linked_1294 == nil { ifn_1295.Invoke_O_O__O(arg_1296, arg_1297) } else { linked_1294.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1293, arg_1296, arg_1297) }; i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } else { i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } } else { i__292000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000105__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A) Ctor() {}
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A) Invoke_O_O__O(self, s__292000128__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_New_O_O(self, s__292000128__1); var tmp2 *jrt.Class; var fncls__1616 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class; if fncls__1616 == nil { var fncls__1616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class = fncls__1616d; tmp2 = fncls__1616d } else { tmp2 = fncls__1616 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A{}; t.Ctor_O_O(p0, p1); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A) Ctor_O_O(c__iter__292000127, c__s__292000128 any) { t.F_iter__292000127 = c__iter__292000127; t.F_s__292000128 = c__s__292000128 }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A) Invoke_O__O(self any) any { { var s__292000128__1 any; var t_ any = t.F_s__292000128; t.F_s__292000128 = nil; s__292000128__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1541 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = s__292000128__1; if linked_1542 == nil { temp__1927000414__auto____2 = ifn_1543.Invoke_O__O(arg_1544) } else { temp__1927000414__auto____2 = linked_1542.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1541, arg_1544) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000128__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1545 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = s__292000128__3; if linked_1546 == nil { tmp1 = ifn_1547.Invoke_O__O(arg_1548) } else { tmp1 = linked_1546.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1545, arg_1548) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1549 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = s__292000128__3; if linked_1550 == nil { c__1927001037__auto____4 = ifn_1551.Invoke_O__O(arg_1552) } else { c__1927001037__auto____4 = linked_1550.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1549, arg_1552) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000130__6 any; var root_1553 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1554 == nil { b__292000130__6 = ifn_1555.Invoke_O__O(arg_1556) } else { b__292000130__6 = linked_1554.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1553, arg_1556) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_New_O_I_O(b__292000130__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1567 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class; if fncls__1567 == nil { var fncls__1567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class = fncls__1567d; tmp3 = fncls__1567d } else { tmp3 = fncls__1567 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1576 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any; var root_1568 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = b__292000130__6; if linked_1569 == nil { arg_1579 = ifn_1570.Invoke_O__O(arg_1571) } else { arg_1579 = linked_1569.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1568, arg_1571) }; var arg_1580 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000127); var tmp5 any; var root_1572 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = s__292000128__3; if linked_1573 == nil { tmp5 = ifn_1574.Invoke_O__O(arg_1575) } else { tmp5 = linked_1573.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1572, arg_1575) }; arg_1580 = tmp4.Invoke_O__O(tmp5); if linked_1577 == nil { return ifn_1578.Invoke_O_O__O(arg_1579, arg_1580) } else { return linked_1577.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1576, arg_1579, arg_1580) } } else { var root_1585 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any; var root_1581 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = b__292000130__6; if linked_1582 == nil { arg_1588 = ifn_1583.Invoke_O__O(arg_1584) } else { arg_1588 = linked_1582.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1581, arg_1584) }; var arg_1589 any; if linked_1586 == nil { return ifn_1587.Invoke_O_O__O(arg_1588, arg_1589) } else { return linked_1586.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1585, arg_1588, arg_1589) } } } else { var mm__4 any; var root_1590 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = s__292000128__3; if linked_1591 == nil { mm__4 = ifn_1592.Invoke_O__O(arg_1593) } else { mm__4 = linked_1591.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1590, arg_1593) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__4)) { var tmp6 int64; var na_1594 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__4)

	if jrt.J2g_Truth(or__1927000174__auto____5) { na_1594 = or__1927000174__auto____5 } else { na_1594 = A_arbace_j2g_dyncf_A_const_303 }; var na_1595 int64 = 4098; if jrt.Long_InstanceOf(na_1594) { var n0_1596 int64 = jrt.NN(jrt.Long_Cast(na_1594)).LongValue__J(); var n1_1597 int64 = na_1595; tmp6 = n0_1596 & n1_1597 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1594, na_1595) }
//line :355:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1603 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__4), A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__4)); var arg_1607 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000127); var tmp8 any; var root_1599 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = s__292000128__3; if linked_1600 == nil { tmp8 = ifn_1601.Invoke_O__O(arg_1602) } else { tmp8 = linked_1600.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1599, arg_1602) }; arg_1607 = tmp7.Invoke_O__O(tmp8); if linked_1604 == nil { return ifn_1605.Invoke_O_O__O(arg_1606, arg_1607) } else { return linked_1604.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1603, arg_1606, arg_1607) } } else { var tmp9 any; var root_1608 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = s__292000128__3; if linked_1609 == nil { tmp9 = ifn_1610.Invoke_O__O(arg_1611) } else { tmp9 = linked_1609.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1608, arg_1611) }; s__292000128__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1612 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = s__292000128__3; if linked_1613 == nil { tmp10 = ifn_1614.Invoke_O__O(arg_1615) } else { tmp10 = linked_1613.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1612, arg_1615) }; s__292000128__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :355:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A) Ctor_O_I_O(c__b__292000130 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000130 = c__b__292000130; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :355:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A) Invoke_O__O(self any) any { { var i__292000129__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000129__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000129__1)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_46, A_arbace_j2g_dyncf_A_const_70.Invoke_O__O(mm__2)) { var tmp2 int64; var na_1557 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__2)

	if jrt.J2g_Truth(or__1927000174__auto____3) { na_1557 = or__1927000174__auto____3 } else { na_1557 = A_arbace_j2g_dyncf_A_const_303 }; var na_1558 int64 = 4098; if jrt.Long_InstanceOf(na_1557) { var n0_1559 int64 = jrt.NN(jrt.Long_Cast(na_1557)).LongValue__J(); var n1_1560 int64 = na_1558; tmp2 = n0_1559 & n1_1560 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1557, na_1558) }
//line :355:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1562 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = t.F_b__292000130; var arg_1566 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyncf_A_const_74.Invoke_O__O(mm__2), A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__2)); if linked_1563 == nil { ifn_1564.Invoke_O_O__O(arg_1565, arg_1566) } else { linked_1563.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1562, arg_1565, arg_1566) }; i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } else { i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } } else { i__292000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000129__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A) Ctor() {}
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A) Invoke_O_O__O(self, s__292000114__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_New_O_O(self, s__292000114__1); var tmp2 *jrt.Class; var fncls__1440 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class; if fncls__1440 == nil { var fncls__1440d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class = fncls__1440d; tmp2 = fncls__1440d } else { tmp2 = fncls__1440 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A) Ctor_O_O(c__iter__292000113, c__s__292000114 any) { t.F_iter__292000113 = c__iter__292000113; t.F_s__292000114 = c__s__292000114 }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A) Invoke_O__O(self any) any { { var s__292000114__1 any; var t_ any = t.F_s__292000114; t.F_s__292000114 = nil; s__292000114__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1359 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = s__292000114__1; if linked_1360 == nil { temp__1927000414__auto____2 = ifn_1361.Invoke_O__O(arg_1362) } else { temp__1927000414__auto____2 = linked_1360.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1359, arg_1362) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000114__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1363 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = s__292000114__3; if linked_1364 == nil { tmp1 = ifn_1365.Invoke_O__O(arg_1366) } else { tmp1 = linked_1364.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1363, arg_1366) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1367 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = s__292000114__3; if linked_1368 == nil { c__1927001037__auto____4 = ifn_1369.Invoke_O__O(arg_1370) } else { c__1927001037__auto____4 = linked_1368.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1367, arg_1370) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000116__6 any; var root_1371 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1372 == nil { b__292000116__6 = ifn_1373.Invoke_O__O(arg_1374) } else { b__292000116__6 = linked_1372.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1371, arg_1374) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_New_O_I_O(b__292000116__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1390 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class; if fncls__1390 == nil { var fncls__1390d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class = fncls__1390d; tmp3 = fncls__1390d } else { tmp3 = fncls__1390 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1399 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any; var root_1391 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = b__292000116__6; if linked_1392 == nil { arg_1402 = ifn_1393.Invoke_O__O(arg_1394) } else { arg_1402 = linked_1392.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1391, arg_1394) }; var arg_1403 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000113); var tmp5 any; var root_1395 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = s__292000114__3; if linked_1396 == nil { tmp5 = ifn_1397.Invoke_O__O(arg_1398) } else { tmp5 = linked_1396.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1395, arg_1398) }; arg_1403 = tmp4.Invoke_O__O(tmp5); if linked_1400 == nil { return ifn_1401.Invoke_O_O__O(arg_1402, arg_1403) } else { return linked_1400.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1399, arg_1402, arg_1403) } } else { var root_1408 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any; var root_1404 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = b__292000116__6; if linked_1405 == nil { arg_1411 = ifn_1406.Invoke_O__O(arg_1407) } else { arg_1411 = linked_1405.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1404, arg_1407) }; var arg_1412 any; if linked_1409 == nil { return ifn_1410.Invoke_O_O__O(arg_1411, arg_1412) } else { return linked_1409.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1408, arg_1411, arg_1412) } } } else { var mm__4 any; var root_1413 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = s__292000114__3; if linked_1414 == nil { mm__4 = ifn_1415.Invoke_O__O(arg_1416) } else { mm__4 = linked_1414.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1413, arg_1416) }; var tmp6 int64; var na_1417 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__4)
																					if jrt.J2g_Truth(or__1927000174__auto____5) { na_1417 = or__1927000174__auto____5 } else { na_1417 = A_arbace_j2g_dyncf_A_const_303 }; var na_1418 int64 = 4098; if jrt.Long_InstanceOf(na_1417) { var n0_1419 int64 = jrt.NN(jrt.Long_Cast(na_1417)).LongValue__J(); var n1_1420 int64 = na_1418; tmp6 = n0_1419 & n1_1420 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1417, na_1418) }
//line :359:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1431 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any; var root_1422 any = A_arbace_j2g_dyncf_A_const_310.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1424 lang.IFn

		if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = mm__4; var arg_1426 any = A_arbace_j2g_dyncf_A_const_312; if linked_1423 == nil { arg_1434 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { arg_1434 = linked_1423.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }
//line :359:1
		var arg_1435 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000113); var tmp8 any; var root_1427 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = s__292000114__3; if linked_1428 == nil { tmp8 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp8 = linked_1428.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1427, arg_1430) }; arg_1435 = tmp7.Invoke_O__O(tmp8); if linked_1432 == nil { return ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { return linked_1432.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) } } else { var tmp9 any; var root_1436 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = s__292000114__3; if linked_1437 == nil { tmp9 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp9 = linked_1437.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1436, arg_1439) }; s__292000114__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A) Ctor_O_I_O(c__b__292000116 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000116 = c__b__292000116; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A) Invoke_O__O(self any) any { { var i__292000115__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000115__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000115__1)); var tmp2 int64; var na_1375 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__2)
																							if jrt.J2g_Truth(or__1927000174__auto____3) { na_1375 = or__1927000174__auto____3 } else { na_1375 = A_arbace_j2g_dyncf_A_const_303 }; var na_1376 int64 = 4098; if jrt.Long_InstanceOf(na_1375) { var n0_1377 int64 = jrt.NN(jrt.Long_Cast(na_1375)).LongValue__J(); var n1_1378 int64 = na_1376; tmp2 = n0_1377 & n1_1378 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1375, na_1376) }
//line :359:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1385 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = t.F_b__292000116; var arg_1389 any; var root_1380 any = A_arbace_j2g_dyncf_A_const_310.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1382 lang.IFn

		if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = mm__2; var arg_1384 any = A_arbace_j2g_dyncf_A_const_311; if linked_1381 == nil { arg_1389 = ifn_1382.Invoke_O_O__O(arg_1383, arg_1384) } else { arg_1389 = linked_1381.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1380, arg_1383, arg_1384) }
//line :359:1
		if linked_1386 == nil { ifn_1387.Invoke_O_O__O(arg_1388, arg_1389) } else { linked_1386.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1385, arg_1388, arg_1389) }; i__292000115__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000115__1); continue L1 } else { i__292000115__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000115__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A) Ctor() {}
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A) Invoke_O_O__O(self, s__292000138__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_New_O_O(self, s__292000138__1); var tmp2 *jrt.Class; var fncls__1709 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class; if fncls__1709 == nil { var fncls__1709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class = fncls__1709d; tmp2 = fncls__1709d } else { tmp2 = fncls__1709 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A) Ctor_O_O(c__iter__292000137, c__s__292000138 any) { t.F_iter__292000137 = c__iter__292000137; t.F_s__292000138 = c__s__292000138 }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A) Invoke_O__O(self any) any { { var s__292000138__1 any; var t_ any = t.F_s__292000138; t.F_s__292000138 = nil; s__292000138__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1628 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = s__292000138__1; if linked_1629 == nil { temp__1927000414__auto____2 = ifn_1630.Invoke_O__O(arg_1631) } else { temp__1927000414__auto____2 = linked_1629.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1628, arg_1631) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000138__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1632 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = s__292000138__3; if linked_1633 == nil { tmp1 = ifn_1634.Invoke_O__O(arg_1635) } else { tmp1 = linked_1633.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1632, arg_1635) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1636 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = s__292000138__3; if linked_1637 == nil { c__1927001037__auto____4 = ifn_1638.Invoke_O__O(arg_1639) } else { c__1927001037__auto____4 = linked_1637.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1636, arg_1639) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000140__6 any; var root_1640 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1641 == nil { b__292000140__6 = ifn_1642.Invoke_O__O(arg_1643) } else { b__292000140__6 = linked_1641.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1640, arg_1643) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_New_O_I_O(b__292000140__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1659 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class; if fncls__1659 == nil { var fncls__1659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class = fncls__1659d; tmp3 = fncls__1659d } else { tmp3 = fncls__1659 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1668 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any; var root_1660 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = b__292000140__6; if linked_1661 == nil { arg_1671 = ifn_1662.Invoke_O__O(arg_1663) } else { arg_1671 = linked_1661.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1660, arg_1663) }; var arg_1672 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000137); var tmp5 any; var root_1664 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = s__292000138__3; if linked_1665 == nil { tmp5 = ifn_1666.Invoke_O__O(arg_1667) } else { tmp5 = linked_1665.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1664, arg_1667) }; arg_1672 = tmp4.Invoke_O__O(tmp5); if linked_1669 == nil { return ifn_1670.Invoke_O_O__O(arg_1671, arg_1672) } else { return linked_1669.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1668, arg_1671, arg_1672) } } else { var root_1677 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any; var root_1673 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = b__292000140__6; if linked_1674 == nil { arg_1680 = ifn_1675.Invoke_O__O(arg_1676) } else { arg_1680 = linked_1674.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1673, arg_1676) }; var arg_1681 any; if linked_1678 == nil { return ifn_1679.Invoke_O_O__O(arg_1680, arg_1681) } else { return linked_1678.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1677, arg_1680, arg_1681) } } } else { var mm__4 any; var root_1682 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = s__292000138__3; if linked_1683 == nil { mm__4 = ifn_1684.Invoke_O__O(arg_1685) } else { mm__4 = linked_1683.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1682, arg_1685) }; var tmp6 int64; var na_1686 any; var or__1927000174__auto____5 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__4)
																				if jrt.J2g_Truth(or__1927000174__auto____5) { na_1686 = or__1927000174__auto____5 } else { na_1686 = A_arbace_j2g_dyncf_A_const_303 }; var na_1687 int64 = 4098; if jrt.Long_InstanceOf(na_1686) { var n0_1688 int64 = jrt.NN(jrt.Long_Cast(na_1686)).LongValue__J(); var n1_1689 int64 = na_1687; tmp6 = n0_1688 & n1_1689 } else { tmp6 = lang.Numbers_And_O_J__J_NoInit(na_1686, na_1687) }
//line :359:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp6) { var root_1700 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any; var root_1691 any = A_arbace_j2g_dyncf_A_const_310.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1693 lang.IFn

		if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = mm__4; var arg_1695 any = A_arbace_j2g_dyncf_A_const_315; if linked_1692 == nil { arg_1703 = ifn_1693.Invoke_O_O__O(arg_1694, arg_1695) } else { arg_1703 = linked_1692.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1691, arg_1694, arg_1695) }
//line :359:1
		var arg_1704 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__292000137); var tmp8 any; var root_1696 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = s__292000138__3; if linked_1697 == nil { tmp8 = ifn_1698.Invoke_O__O(arg_1699) } else { tmp8 = linked_1697.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1696, arg_1699) }; arg_1704 = tmp7.Invoke_O__O(tmp8); if linked_1701 == nil { return ifn_1702.Invoke_O_O__O(arg_1703, arg_1704) } else { return linked_1701.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1700, arg_1703, arg_1704) } } else { var tmp9 any; var root_1705 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = s__292000138__3; if linked_1706 == nil { tmp9 = ifn_1707.Invoke_O__O(arg_1708) } else { tmp9 = linked_1706.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1705, arg_1708) }; s__292000138__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :359:1
func A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A) Ctor_O_I_O(c__b__292000140 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000140 = c__b__292000140; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :359:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A) Invoke_O__O(self any) any { { var i__292000139__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000139__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000139__1)); var tmp2 int64; var na_1644 any; var or__1927000174__auto____3 any = A_arbace_j2g_dyncf_A_const_302.Invoke_O__O(mm__2)
																					if jrt.J2g_Truth(or__1927000174__auto____3) { na_1644 = or__1927000174__auto____3 } else { na_1644 = A_arbace_j2g_dyncf_A_const_303 }; var na_1645 int64 = 4098; if jrt.Long_InstanceOf(na_1644) { var n0_1646 int64 = jrt.NN(jrt.Long_Cast(na_1644)).LongValue__J(); var n1_1647 int64 = na_1645; tmp2 = n0_1646 & n1_1647 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1644, na_1645) }
//line :359:1
	if lang.Numbers_IsZero_J__Z_NoInit(tmp2) { var root_1654 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = t.F_b__292000140; var arg_1658 any; var root_1649 any = A_arbace_j2g_dyncf_A_const_310.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1651 lang.IFn

		if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = mm__2; var arg_1653 any = A_arbace_j2g_dyncf_A_const_314; if linked_1650 == nil { arg_1658 = ifn_1651.Invoke_O_O__O(arg_1652, arg_1653) } else { arg_1658 = linked_1650.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1649, arg_1652, arg_1653) }
//line :359:1
		if linked_1655 == nil { ifn_1656.Invoke_O_O__O(arg_1657, arg_1658) } else { linked_1655.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1654, arg_1657, arg_1658) }; i__292000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000139__1); continue L1 } else { i__292000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000139__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_New() *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A{}; t.Ctor(); return t }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A) Ctor() {}
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A) Invoke_O_O__O(self, s__292000150__1 any) any { var tmp1 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_New_O_O(s__292000150__1, self); var tmp2 *jrt.Class; var fncls__1821 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class; if fncls__1821 == nil { var fncls__1821d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class = fncls__1821d; tmp2 = fncls__1821d } else { tmp2 = fncls__1821 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :365:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A) Ctor_O_O(c__s__292000150, c__iter__292000149 any) { t.F_s__292000150 = c__s__292000150; t.F_iter__292000149 = c__iter__292000149 }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A) Invoke_O__O(self any) any { { var s__292000150__1 any; var t_ any = t.F_s__292000150; t.F_s__292000150 = nil; s__292000150__1 = t_; for { var temp__1927000414__auto____2 any; var root_1748 any = A_arbace_j2g_dyncf_A_const_66.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = s__292000150__1; if linked_1749 == nil { temp__1927000414__auto____2 = ifn_1750.Invoke_O__O(arg_1751) } else { temp__1927000414__auto____2 = linked_1749.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1748, arg_1751) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__292000150__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1752 any = A_arbace_j2g_dyncf_A_const_67.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = s__292000150__3; if linked_1753 == nil { tmp1 = ifn_1754.Invoke_O__O(arg_1755) } else { tmp1 = linked_1753.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1752, arg_1755) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1756 any = A_arbace_j2g_dyncf_A_const_68.GetRawRoot__O(); var linked_1757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1756, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1758 lang.IFn; if linked_1757 == nil { ifn_1758 = lang.IFn_Cast(root_1756) } else { ifn_1758 = nil }; var arg_1759 any = s__292000150__3; if linked_1757 == nil { c__1927001037__auto____4 = ifn_1758.Invoke_O__O(arg_1759) } else { c__1927001037__auto____4 = linked_1757.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1756, arg_1759) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__292000152__6 any; var root_1760 any = A_arbace_j2g_dyncf_A_const_69.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1761 == nil { b__292000152__6 = ifn_1762.Invoke_O__O(arg_1763) } else { b__292000152__6 = linked_1761.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1760, arg_1763) }; var tmp2 any = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_New_O_I_O(b__292000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1777 *jrt.Class = A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class; if fncls__1777 == nil { var fncls__1777d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class = fncls__1777d; tmp3 = fncls__1777d } else { tmp3 = fncls__1777 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1786 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any; var root_1778 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = b__292000152__6; if linked_1779 == nil { arg_1789 = ifn_1780.Invoke_O__O(arg_1781) } else { arg_1789 = linked_1779.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1778, arg_1781) }; var arg_1790 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__292000149); var tmp5 any; var root_1782 any = A_arbace_j2g_dyncf_A_const_100.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = s__292000150__3; if linked_1783 == nil { tmp5 = ifn_1784.Invoke_O__O(arg_1785) } else { tmp5 = linked_1783.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1782, arg_1785) }; arg_1790 = tmp4.Invoke_O__O(tmp5); if linked_1787 == nil { return ifn_1788.Invoke_O_O__O(arg_1789, arg_1790) } else { return linked_1787.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1786, arg_1789, arg_1790) } } else { var root_1795 any = A_arbace_j2g_dyncf_A_const_98.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any; var root_1791 any = A_arbace_j2g_dyncf_A_const_99.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = b__292000152__6; if linked_1792 == nil { arg_1798 = ifn_1793.Invoke_O__O(arg_1794) } else { arg_1798 = linked_1792.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1791, arg_1794) }; var arg_1799 any; if linked_1796 == nil { return ifn_1797.Invoke_O_O__O(arg_1798, arg_1799) } else { return linked_1796.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1795, arg_1798, arg_1799) } } } else { var vec__292000160__4 any; var root_1800 any = A_arbace_j2g_dyncf_A_const_101.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = s__292000150__3; if linked_1801 == nil { vec__292000160__4 = ifn_1802.Invoke_O__O(arg_1803) } else { vec__292000160__4 = linked_1801.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1800, arg_1803) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000160__4, lang.RT_IntCast_J__I_NoInit(0), nil); var g__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000160__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1816 any = A_arbace_j2g_dyncf_A_const_102.GetRawRoot__O(); var linked_1817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1816, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1818 lang.IFn; if linked_1817 == nil { ifn_1818 = lang.IFn_Cast(root_1816) } else { ifn_1818 = nil }; var arg_1819 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_317.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_317.GetRawRoot__O()).Invoke_O__O(g__6))).Ref(); var arg_1820 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__292000149); var tmp7 any; var root_1812 any = A_arbace_j2g_dyncf_A_const_103.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1814 lang.IFn; if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = s__292000150__3; if linked_1813 == nil { tmp7 = ifn_1814.Invoke_O__O(arg_1815) } else { tmp7 = linked_1813.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1812, arg_1815) }; arg_1820 = tmp6.Invoke_O__O(tmp7); if linked_1817 == nil { return ifn_1818.Invoke_O_O__O(arg_1819, arg_1820) } else { return linked_1817.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1816, arg_1819, arg_1820) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :365:1
func A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A) Ctor_O_I_O(c__b__292000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__292000152 = c__b__292000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :365:1
func (t *A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A) Invoke_O__O(self any) any { { var i__292000151__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__292000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__292000156__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__292000151__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000156__2, lang.RT_IntCast_J__I_NoInit(0), nil); var g__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__292000156__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1772 any = A_arbace_j2g_dyncf_A_const_82.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1774 lang.IFn; if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = t.F_b__292000152; var arg_1776 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_317.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_j2g_dyncf_A_const_317.GetRawRoot__O()).Invoke_O__O(g__4))).Ref(); if linked_1773 == nil { ifn_1774.Invoke_O_O__O(arg_1775, arg_1776) } else { linked_1773.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1772, arg_1775, arg_1776) }; i__292000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__292000151__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































































































type A_arbace_j2g_dyncf_A struct{ jrt.Object }

var A_arbace_j2g_dyncf_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyncf_A_const_0 *lang.Var

var A_arbace_j2g_dyncf_A_const_1 any

var A_arbace_j2g_dyncf_A_const_2 any

var A_arbace_j2g_dyncf_A_const_3 any

var A_arbace_j2g_dyncf_A_const_4 any

var A_arbace_j2g_dyncf_A_const_5 any

var A_arbace_j2g_dyncf_A_const_6 any

var A_arbace_j2g_dyncf_A_const_7 any

var A_arbace_j2g_dyncf_A_const_8 any

var A_arbace_j2g_dyncf_A_const_9 any

var A_arbace_j2g_dyncf_A_const_10 *lang.Var

var A_arbace_j2g_dyncf_A_const_11 any

var A_arbace_j2g_dyncf_A_const_12 *lang.Var

var A_arbace_j2g_dyncf_A_const_13 *lang.Var

var A_arbace_j2g_dyncf_A_const_14 *lang.Var

var A_arbace_j2g_dyncf_A_const_15 *lang.Var

var A_arbace_j2g_dyncf_A_const_16 any

var A_arbace_j2g_dyncf_A_const_17 *lang.Var

var A_arbace_j2g_dyncf_A_const_18 *lang.Var

var A_arbace_j2g_dyncf_A_const_19 *lang.Var

var A_arbace_j2g_dyncf_A_const_20 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_21 *lang.Var

var A_arbace_j2g_dyncf_A_const_22 *lang.Var

var A_arbace_j2g_dyncf_A_const_23 *lang.Var

var A_arbace_j2g_dyncf_A_const_24 *lang.Var

var A_arbace_j2g_dyncf_A_const_25 *lang.Var

var A_arbace_j2g_dyncf_A_const_26 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_27 any

var A_arbace_j2g_dyncf_A_const_28 *lang.Var

var A_arbace_j2g_dyncf_A_const_29 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_30 any

var A_arbace_j2g_dyncf_A_const_31 *lang.Var

var A_arbace_j2g_dyncf_A_const_32 any

var A_arbace_j2g_dyncf_A_const_33 any

var A_arbace_j2g_dyncf_A_const_34 *lang.Var

var A_arbace_j2g_dyncf_A_const_35 *lang.Var

var A_arbace_j2g_dyncf_A_const_36 any

var A_arbace_j2g_dyncf_A_const_37 *lang.Var

var A_arbace_j2g_dyncf_A_const_38 *lang.Var

var A_arbace_j2g_dyncf_A_const_39 *lang.Var

var A_arbace_j2g_dyncf_A_const_40 any

var A_arbace_j2g_dyncf_A_const_41 any

var A_arbace_j2g_dyncf_A_const_42 *lang.Var

var A_arbace_j2g_dyncf_A_const_43 any

var A_arbace_j2g_dyncf_A_const_44 any

var A_arbace_j2g_dyncf_A_const_45 any

var A_arbace_j2g_dyncf_A_const_46 any

var A_arbace_j2g_dyncf_A_const_47 any

var A_arbace_j2g_dyncf_A_const_48 *lang.Var

var A_arbace_j2g_dyncf_A_const_49 *lang.Var

var A_arbace_j2g_dyncf_A_const_50 any

var A_arbace_j2g_dyncf_A_const_51 *lang.Var

var A_arbace_j2g_dyncf_A_const_52 any

var A_arbace_j2g_dyncf_A_const_53 any

var A_arbace_j2g_dyncf_A_const_54 any

var A_arbace_j2g_dyncf_A_const_55 any

var A_arbace_j2g_dyncf_A_const_56 any

var A_arbace_j2g_dyncf_A_const_57 any

var A_arbace_j2g_dyncf_A_const_58 any

var A_arbace_j2g_dyncf_A_const_59 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_60 any

var A_arbace_j2g_dyncf_A_const_61 any

var A_arbace_j2g_dyncf_A_const_62 any

var A_arbace_j2g_dyncf_A_const_63 *lang.Var

var A_arbace_j2g_dyncf_A_const_64 any

var A_arbace_j2g_dyncf_A_const_65 any

var A_arbace_j2g_dyncf_A_const_66 *lang.Var

var A_arbace_j2g_dyncf_A_const_67 *lang.Var

var A_arbace_j2g_dyncf_A_const_68 *lang.Var

var A_arbace_j2g_dyncf_A_const_69 *lang.Var

var A_arbace_j2g_dyncf_A_const_70 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_71 *lang.Var

var A_arbace_j2g_dyncf_A_const_72 *lang.Var

var A_arbace_j2g_dyncf_A_const_73 *lang.Var

var A_arbace_j2g_dyncf_A_const_74 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_75 *lang.Var

var A_arbace_j2g_dyncf_A_const_76 *lang.Var

var A_arbace_j2g_dyncf_A_const_77 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_78 *lang.Var

var A_arbace_j2g_dyncf_A_const_79 *lang.Var

var A_arbace_j2g_dyncf_A_const_80 *lang.Var

var A_arbace_j2g_dyncf_A_const_81 *lang.Var

var A_arbace_j2g_dyncf_A_const_82 *lang.Var

var A_arbace_j2g_dyncf_A_const_83 any

var A_arbace_j2g_dyncf_A_const_84 any

var A_arbace_j2g_dyncf_A_const_85 any

var A_arbace_j2g_dyncf_A_const_86 any

var A_arbace_j2g_dyncf_A_const_87 any

var A_arbace_j2g_dyncf_A_const_88 any

var A_arbace_j2g_dyncf_A_const_89 any

var A_arbace_j2g_dyncf_A_const_90 any

var A_arbace_j2g_dyncf_A_const_91 *lang.Var

var A_arbace_j2g_dyncf_A_const_92 *lang.Var

var A_arbace_j2g_dyncf_A_const_93 any

var A_arbace_j2g_dyncf_A_const_94 any

var A_arbace_j2g_dyncf_A_const_95 any

var A_arbace_j2g_dyncf_A_const_96 any

var A_arbace_j2g_dyncf_A_const_97 any

var A_arbace_j2g_dyncf_A_const_98 *lang.Var

var A_arbace_j2g_dyncf_A_const_99 *lang.Var

var A_arbace_j2g_dyncf_A_const_100 *lang.Var

var A_arbace_j2g_dyncf_A_const_101 *lang.Var

var A_arbace_j2g_dyncf_A_const_102 *lang.Var

var A_arbace_j2g_dyncf_A_const_103 *lang.Var

var A_arbace_j2g_dyncf_A_const_104 *lang.Var

var A_arbace_j2g_dyncf_A_const_105 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_106 *lang.Var

var A_arbace_j2g_dyncf_A_const_107 any

var A_arbace_j2g_dyncf_A_const_108 any

var A_arbace_j2g_dyncf_A_const_109 any

var A_arbace_j2g_dyncf_A_const_110 any

var A_arbace_j2g_dyncf_A_const_111 *lang.Var

var A_arbace_j2g_dyncf_A_const_112 any

var A_arbace_j2g_dyncf_A_const_113 any

var A_arbace_j2g_dyncf_A_const_114 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_115 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_116 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_117 any

var A_arbace_j2g_dyncf_A_const_118 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_119 any

var A_arbace_j2g_dyncf_A_const_120 any

var A_arbace_j2g_dyncf_A_const_121 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_122 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_123 any

var A_arbace_j2g_dyncf_A_const_124 any

var A_arbace_j2g_dyncf_A_const_125 any

var A_arbace_j2g_dyncf_A_const_126 any

var A_arbace_j2g_dyncf_A_const_127 any

var A_arbace_j2g_dyncf_A_const_128 any

var A_arbace_j2g_dyncf_A_const_129 any

var A_arbace_j2g_dyncf_A_const_130 any

var A_arbace_j2g_dyncf_A_const_131 any

var A_arbace_j2g_dyncf_A_const_132 any

var A_arbace_j2g_dyncf_A_const_133 any

var A_arbace_j2g_dyncf_A_const_134 any

var A_arbace_j2g_dyncf_A_const_135 any

var A_arbace_j2g_dyncf_A_const_136 any

var A_arbace_j2g_dyncf_A_const_137 any

var A_arbace_j2g_dyncf_A_const_138 any

var A_arbace_j2g_dyncf_A_const_139 *lang.Var

var A_arbace_j2g_dyncf_A_const_140 *lang.Var

var A_arbace_j2g_dyncf_A_const_141 *lang.Var

var A_arbace_j2g_dyncf_A_const_142 *lang.Var

var A_arbace_j2g_dyncf_A_const_143 *lang.Var

var A_arbace_j2g_dyncf_A_const_144 *lang.Var

var A_arbace_j2g_dyncf_A_const_145 any

var A_arbace_j2g_dyncf_A_const_146 any

var A_arbace_j2g_dyncf_A_const_147 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_148 any

var A_arbace_j2g_dyncf_A_const_149 any

var A_arbace_j2g_dyncf_A_const_150 any

var A_arbace_j2g_dyncf_A_const_151 any

var A_arbace_j2g_dyncf_A_const_152 any

var A_arbace_j2g_dyncf_A_const_153 any

var A_arbace_j2g_dyncf_A_const_154 any

var A_arbace_j2g_dyncf_A_const_155 any

var A_arbace_j2g_dyncf_A_const_156 *lang.Var

var A_arbace_j2g_dyncf_A_const_157 any

var A_arbace_j2g_dyncf_A_const_158 any

var A_arbace_j2g_dyncf_A_const_159 any

var A_arbace_j2g_dyncf_A_const_160 any

var A_arbace_j2g_dyncf_A_const_161 any

var A_arbace_j2g_dyncf_A_const_162 any

var A_arbace_j2g_dyncf_A_const_163 *lang.Var

var A_arbace_j2g_dyncf_A_const_164 any

var A_arbace_j2g_dyncf_A_const_165 any

var A_arbace_j2g_dyncf_A_const_166 any

var A_arbace_j2g_dyncf_A_const_167 any

var A_arbace_j2g_dyncf_A_const_168 any

var A_arbace_j2g_dyncf_A_const_169 any

var A_arbace_j2g_dyncf_A_const_170 any

var A_arbace_j2g_dyncf_A_const_171 any

var A_arbace_j2g_dyncf_A_const_172 any

var A_arbace_j2g_dyncf_A_const_173 any

var A_arbace_j2g_dyncf_A_const_174 any

var A_arbace_j2g_dyncf_A_const_175 any

var A_arbace_j2g_dyncf_A_const_176 any

var A_arbace_j2g_dyncf_A_const_177 any

var A_arbace_j2g_dyncf_A_const_178 any

var A_arbace_j2g_dyncf_A_const_179 any

var A_arbace_j2g_dyncf_A_const_180 any

var A_arbace_j2g_dyncf_A_const_181 any

var A_arbace_j2g_dyncf_A_const_182 any

var A_arbace_j2g_dyncf_A_const_183 any

var A_arbace_j2g_dyncf_A_const_184 any

var A_arbace_j2g_dyncf_A_const_185 any

var A_arbace_j2g_dyncf_A_const_186 any

var A_arbace_j2g_dyncf_A_const_187 any

var A_arbace_j2g_dyncf_A_const_188 any

var A_arbace_j2g_dyncf_A_const_189 any

var A_arbace_j2g_dyncf_A_const_190 any

var A_arbace_j2g_dyncf_A_const_191 any

var A_arbace_j2g_dyncf_A_const_192 any

var A_arbace_j2g_dyncf_A_const_193 any

var A_arbace_j2g_dyncf_A_const_194 any

var A_arbace_j2g_dyncf_A_const_195 any

var A_arbace_j2g_dyncf_A_const_196 any

var A_arbace_j2g_dyncf_A_const_197 any

var A_arbace_j2g_dyncf_A_const_198 any

var A_arbace_j2g_dyncf_A_const_199 any

var A_arbace_j2g_dyncf_A_const_200 any

var A_arbace_j2g_dyncf_A_const_201 any

var A_arbace_j2g_dyncf_A_const_202 any

var A_arbace_j2g_dyncf_A_const_203 any

var A_arbace_j2g_dyncf_A_const_204 any

var A_arbace_j2g_dyncf_A_const_205 any

var A_arbace_j2g_dyncf_A_const_206 any

var A_arbace_j2g_dyncf_A_const_207 any

var A_arbace_j2g_dyncf_A_const_208 any

var A_arbace_j2g_dyncf_A_const_209 any

var A_arbace_j2g_dyncf_A_const_210 any

var A_arbace_j2g_dyncf_A_const_211 any

var A_arbace_j2g_dyncf_A_const_212 any

var A_arbace_j2g_dyncf_A_const_213 any

var A_arbace_j2g_dyncf_A_const_214 any

var A_arbace_j2g_dyncf_A_const_215 any

var A_arbace_j2g_dyncf_A_const_216 any

var A_arbace_j2g_dyncf_A_const_217 any

var A_arbace_j2g_dyncf_A_const_218 any

var A_arbace_j2g_dyncf_A_const_219 any

var A_arbace_j2g_dyncf_A_const_220 any

var A_arbace_j2g_dyncf_A_const_221 any

var A_arbace_j2g_dyncf_A_const_222 any

var A_arbace_j2g_dyncf_A_const_223 any

var A_arbace_j2g_dyncf_A_const_224 any

var A_arbace_j2g_dyncf_A_const_225 any

var A_arbace_j2g_dyncf_A_const_226 any

var A_arbace_j2g_dyncf_A_const_227 any

var A_arbace_j2g_dyncf_A_const_228 any

var A_arbace_j2g_dyncf_A_const_229 any

var A_arbace_j2g_dyncf_A_const_230 any

var A_arbace_j2g_dyncf_A_const_231 any

var A_arbace_j2g_dyncf_A_const_232 any

var A_arbace_j2g_dyncf_A_const_233 any

var A_arbace_j2g_dyncf_A_const_234 any

var A_arbace_j2g_dyncf_A_const_235 any

var A_arbace_j2g_dyncf_A_const_236 any

var A_arbace_j2g_dyncf_A_const_237 any

var A_arbace_j2g_dyncf_A_const_238 any

var A_arbace_j2g_dyncf_A_const_239 any

var A_arbace_j2g_dyncf_A_const_240 any

var A_arbace_j2g_dyncf_A_const_241 any

var A_arbace_j2g_dyncf_A_const_242 any

var A_arbace_j2g_dyncf_A_const_243 any

var A_arbace_j2g_dyncf_A_const_244 any

var A_arbace_j2g_dyncf_A_const_245 any

var A_arbace_j2g_dyncf_A_const_246 any

var A_arbace_j2g_dyncf_A_const_247 any

var A_arbace_j2g_dyncf_A_const_248 any

var A_arbace_j2g_dyncf_A_const_249 any

var A_arbace_j2g_dyncf_A_const_250 any

var A_arbace_j2g_dyncf_A_const_251 any

var A_arbace_j2g_dyncf_A_const_252 any

var A_arbace_j2g_dyncf_A_const_253 any

var A_arbace_j2g_dyncf_A_const_254 any

var A_arbace_j2g_dyncf_A_const_255 any

var A_arbace_j2g_dyncf_A_const_256 any

var A_arbace_j2g_dyncf_A_const_257 any

var A_arbace_j2g_dyncf_A_const_258 any

var A_arbace_j2g_dyncf_A_const_259 any

var A_arbace_j2g_dyncf_A_const_260 any

var A_arbace_j2g_dyncf_A_const_261 any

var A_arbace_j2g_dyncf_A_const_262 any

var A_arbace_j2g_dyncf_A_const_263 any

var A_arbace_j2g_dyncf_A_const_264 any

var A_arbace_j2g_dyncf_A_const_265 any

var A_arbace_j2g_dyncf_A_const_266 any

var A_arbace_j2g_dyncf_A_const_267 any

var A_arbace_j2g_dyncf_A_const_268 any

var A_arbace_j2g_dyncf_A_const_269 any

var A_arbace_j2g_dyncf_A_const_270 any

var A_arbace_j2g_dyncf_A_const_271 any

var A_arbace_j2g_dyncf_A_const_272 any

var A_arbace_j2g_dyncf_A_const_273 any

var A_arbace_j2g_dyncf_A_const_274 any

var A_arbace_j2g_dyncf_A_const_275 any

var A_arbace_j2g_dyncf_A_const_276 any

var A_arbace_j2g_dyncf_A_const_277 any

var A_arbace_j2g_dyncf_A_const_278 any

var A_arbace_j2g_dyncf_A_const_279 any

var A_arbace_j2g_dyncf_A_const_280 any

var A_arbace_j2g_dyncf_A_const_281 any

var A_arbace_j2g_dyncf_A_const_282 any

var A_arbace_j2g_dyncf_A_const_283 any

var A_arbace_j2g_dyncf_A_const_284 any

var A_arbace_j2g_dyncf_A_const_285 any

var A_arbace_j2g_dyncf_A_const_286 *lang.Var

var A_arbace_j2g_dyncf_A_const_287 *lang.Var

var A_arbace_j2g_dyncf_A_const_288 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_289 *lang.Var

var A_arbace_j2g_dyncf_A_const_290 *lang.Var

var A_arbace_j2g_dyncf_A_const_291 *lang.Var

var A_arbace_j2g_dyncf_A_const_292 any

var A_arbace_j2g_dyncf_A_const_293 any

var A_arbace_j2g_dyncf_A_const_294 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_295 *lang.Var

var A_arbace_j2g_dyncf_A_const_296 *lang.Var

var A_arbace_j2g_dyncf_A_const_297 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_298 *lang.Var

var A_arbace_j2g_dyncf_A_const_299 *lang.Var

var A_arbace_j2g_dyncf_A_const_300 *lang.Var

var A_arbace_j2g_dyncf_A_const_301 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_302 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_303 any

var A_arbace_j2g_dyncf_A_const_304 *lang.Var

var A_arbace_j2g_dyncf_A_const_305 *lang.Var

var A_arbace_j2g_dyncf_A_const_306 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_307 *lang.Var

var A_arbace_j2g_dyncf_A_const_308 *lang.Var

var A_arbace_j2g_dyncf_A_const_309 *lang.Keyword

var A_arbace_j2g_dyncf_A_const_310 *lang.Var

var A_arbace_j2g_dyncf_A_const_311 any

var A_arbace_j2g_dyncf_A_const_312 any

var A_arbace_j2g_dyncf_A_const_313 any

var A_arbace_j2g_dyncf_A_const_314 any

var A_arbace_j2g_dyncf_A_const_315 any

var A_arbace_j2g_dyncf_A_const_316 *lang.Var

var A_arbace_j2g_dyncf_A_const_317 *lang.Var

var A_arbace_j2g_dyncf_A_const_318 *lang.Var

var A_arbace_j2g_dyncf_A_const_319 *lang.Var

var A_arbace_j2g_dyncf_A_const_320 *lang.Var

var A_arbace_j2g_dyncf_A_const_321 *lang.Var

var A_arbace_j2g_dyncf_A_init jrt.ClassInit

func A_arbace_j2g_dyncf_A_Init() { if !A_arbace_j2g_dyncf_A_init.Done() { A_arbace_j2g_dyncf_A_init.Run(A_arbace_j2g_dyncf_A_clinit) } }

func A_arbace_j2g_dyncf_A_clinit() { A_arbace_j2g_dyncf_A_clinit_p0(); A_arbace_j2g_dyncf_A_clinit_p1(); A_arbace_j2g_dyncf_A_clinit_p2(); A_arbace_j2g_dyncf_A_clinit_p3(); A_arbace_j2g_dyncf_A_clinit_p4(); A_arbace_j2g_dyncf_A_clinit_p5(); A_arbace_j2g_dyncf_A_clinit_p6(); A_arbace_j2g_dyncf_A_clinit_p7(); A_arbace_j2g_dyncf_A_clinit_p8(); A_arbace_j2g_dyncf_A_clinit_p9(); A_arbace_j2g_dyncf_A_clinit_p10(); A_arbace_j2g_dyncf_A_clinit_p11(); A_arbace_j2g_dyncf_A_clinit_p12(); A_arbace_j2g_dyncf_A_clinit_p13(); A_arbace_j2g_dyncf_A_clinit_p14(); A_arbace_j2g_dyncf_A_clinit_p15(); A_arbace_j2g_dyncf_A_clinit_p16(); A_arbace_j2g_dyncf_A_clinit_p17(); A_arbace_j2g_dyncf_A_clinit_p18(); A_arbace_j2g_dyncf_A_clinit_p19(); A_arbace_j2g_dyncf_A_clinit_p20(); A_arbace_j2g_dyncf_A_clinit_p21(); A_arbace_j2g_dyncf_A_clinit_p22() }

func A_arbace_j2g_dyncf_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyncf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 551); A_arbace_j2g_dyncf_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[229]); A_arbace_j2g_dyncf_A_const_1 = A_arbace_j2g_dyncf_A_const_pool.A[230]; A_arbace_j2g_dyncf_A_const_2 = A_arbace_j2g_dyncf_A_const_pool.A[231]; A_arbace_j2g_dyncf_A_const_3 = A_arbace_j2g_dyncf_A_const_pool.A[232]; A_arbace_j2g_dyncf_A_const_4 = A_arbace_j2g_dyncf_A_const_pool.A[233]; A_arbace_j2g_dyncf_A_const_5 = A_arbace_j2g_dyncf_A_const_pool.A[234]; A_arbace_j2g_dyncf_A_const_6 = A_arbace_j2g_dyncf_A_const_pool.A[235]; A_arbace_j2g_dyncf_A_const_7 = A_arbace_j2g_dyncf_A_const_pool.A[236]; A_arbace_j2g_dyncf_A_const_8 = A_arbace_j2g_dyncf_A_const_pool.A[237]; A_arbace_j2g_dyncf_A_const_9 = A_arbace_j2g_dyncf_A_const_pool.A[238]; A_arbace_j2g_dyncf_A_const_10 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[239]); A_arbace_j2g_dyncf_A_const_11 = A_arbace_j2g_dyncf_A_const_pool.A[240]; A_arbace_j2g_dyncf_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[241]) }

func A_arbace_j2g_dyncf_A_clinit_p1() { A_arbace_j2g_dyncf_A_const_13 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[242]); A_arbace_j2g_dyncf_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[243]); A_arbace_j2g_dyncf_A_const_15 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[244]); A_arbace_j2g_dyncf_A_const_16 = A_arbace_j2g_dyncf_A_const_pool.A[245]; A_arbace_j2g_dyncf_A_const_17 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[246]); A_arbace_j2g_dyncf_A_const_18 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[247]); A_arbace_j2g_dyncf_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[248]); A_arbace_j2g_dyncf_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[249]); A_arbace_j2g_dyncf_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[250]); A_arbace_j2g_dyncf_A_const_22 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[251]); A_arbace_j2g_dyncf_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[252]); A_arbace_j2g_dyncf_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[253]) }

func A_arbace_j2g_dyncf_A_clinit_p2() { A_arbace_j2g_dyncf_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[254]); A_arbace_j2g_dyncf_A_const_26 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[255]); A_arbace_j2g_dyncf_A_const_27 = A_arbace_j2g_dyncf_A_const_pool.A[256]; A_arbace_j2g_dyncf_A_const_28 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[257]); A_arbace_j2g_dyncf_A_const_29 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[258]); A_arbace_j2g_dyncf_A_const_30 = A_arbace_j2g_dyncf_A_const_pool.A[259]; A_arbace_j2g_dyncf_A_const_31 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[260]); A_arbace_j2g_dyncf_A_const_32 = A_arbace_j2g_dyncf_A_const_pool.A[261]; A_arbace_j2g_dyncf_A_const_33 = A_arbace_j2g_dyncf_A_const_pool.A[262]; A_arbace_j2g_dyncf_A_const_34 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[263]); A_arbace_j2g_dyncf_A_const_35 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[264]); A_arbace_j2g_dyncf_A_const_36 = A_arbace_j2g_dyncf_A_const_pool.A[265]; A_arbace_j2g_dyncf_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[266]) }

func A_arbace_j2g_dyncf_A_clinit_p3() { A_arbace_j2g_dyncf_A_const_38 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[267]); A_arbace_j2g_dyncf_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[268]); A_arbace_j2g_dyncf_A_const_40 = A_arbace_j2g_dyncf_A_const_pool.A[269]; A_arbace_j2g_dyncf_A_const_41 = A_arbace_j2g_dyncf_A_const_pool.A[270]; A_arbace_j2g_dyncf_A_const_42 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[271]); A_arbace_j2g_dyncf_A_const_43 = A_arbace_j2g_dyncf_A_const_pool.A[272]; A_arbace_j2g_dyncf_A_const_44 = A_arbace_j2g_dyncf_A_const_pool.A[273]; A_arbace_j2g_dyncf_A_const_45 = A_arbace_j2g_dyncf_A_const_pool.A[274]; A_arbace_j2g_dyncf_A_const_46 = A_arbace_j2g_dyncf_A_const_pool.A[275]; A_arbace_j2g_dyncf_A_const_47 = A_arbace_j2g_dyncf_A_const_pool.A[276]; A_arbace_j2g_dyncf_A_const_48 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[277]); A_arbace_j2g_dyncf_A_const_49 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[278]); A_arbace_j2g_dyncf_A_const_50 = A_arbace_j2g_dyncf_A_const_pool.A[279]; A_arbace_j2g_dyncf_A_const_51 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[280]) }

func A_arbace_j2g_dyncf_A_clinit_p4() { A_arbace_j2g_dyncf_A_const_52 = A_arbace_j2g_dyncf_A_const_pool.A[281]; A_arbace_j2g_dyncf_A_const_53 = A_arbace_j2g_dyncf_A_const_pool.A[282]; A_arbace_j2g_dyncf_A_const_54 = A_arbace_j2g_dyncf_A_const_pool.A[283]; A_arbace_j2g_dyncf_A_const_55 = A_arbace_j2g_dyncf_A_const_pool.A[284]; A_arbace_j2g_dyncf_A_const_56 = A_arbace_j2g_dyncf_A_const_pool.A[285]; A_arbace_j2g_dyncf_A_const_57 = A_arbace_j2g_dyncf_A_const_pool.A[286]; A_arbace_j2g_dyncf_A_const_58 = A_arbace_j2g_dyncf_A_const_pool.A[287]; A_arbace_j2g_dyncf_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[288]); A_arbace_j2g_dyncf_A_const_60 = A_arbace_j2g_dyncf_A_const_pool.A[289]; A_arbace_j2g_dyncf_A_const_61 = A_arbace_j2g_dyncf_A_const_pool.A[290]; A_arbace_j2g_dyncf_A_const_62 = A_arbace_j2g_dyncf_A_const_pool.A[291]; A_arbace_j2g_dyncf_A_const_63 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[292]); A_arbace_j2g_dyncf_A_const_64 = A_arbace_j2g_dyncf_A_const_pool.A[293]; A_arbace_j2g_dyncf_A_const_65 = A_arbace_j2g_dyncf_A_const_pool.A[294]; A_arbace_j2g_dyncf_A_const_66 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[295]) }

func A_arbace_j2g_dyncf_A_clinit_p5() { A_arbace_j2g_dyncf_A_const_67 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[296]); A_arbace_j2g_dyncf_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[297]); A_arbace_j2g_dyncf_A_const_69 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[298]); A_arbace_j2g_dyncf_A_const_70 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[299]); A_arbace_j2g_dyncf_A_const_71 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[300]); A_arbace_j2g_dyncf_A_const_72 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[301]); A_arbace_j2g_dyncf_A_const_73 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[302]); A_arbace_j2g_dyncf_A_const_74 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[303]); A_arbace_j2g_dyncf_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[304]); A_arbace_j2g_dyncf_A_const_76 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[305]); A_arbace_j2g_dyncf_A_const_77 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[306]); A_arbace_j2g_dyncf_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[307]) }

func A_arbace_j2g_dyncf_A_clinit_p6() { A_arbace_j2g_dyncf_A_const_79 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[308]); A_arbace_j2g_dyncf_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[309]); A_arbace_j2g_dyncf_A_const_81 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[310]); A_arbace_j2g_dyncf_A_const_82 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[311]); A_arbace_j2g_dyncf_A_const_83 = A_arbace_j2g_dyncf_A_const_pool.A[312]; A_arbace_j2g_dyncf_A_const_84 = A_arbace_j2g_dyncf_A_const_pool.A[313]; A_arbace_j2g_dyncf_A_const_85 = A_arbace_j2g_dyncf_A_const_pool.A[314]; A_arbace_j2g_dyncf_A_const_86 = A_arbace_j2g_dyncf_A_const_pool.A[315]; A_arbace_j2g_dyncf_A_const_87 = A_arbace_j2g_dyncf_A_const_pool.A[316]; A_arbace_j2g_dyncf_A_const_88 = A_arbace_j2g_dyncf_A_const_pool.A[317]; A_arbace_j2g_dyncf_A_const_89 = A_arbace_j2g_dyncf_A_const_pool.A[318]; A_arbace_j2g_dyncf_A_const_90 = A_arbace_j2g_dyncf_A_const_pool.A[319]; A_arbace_j2g_dyncf_A_const_91 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[320]); A_arbace_j2g_dyncf_A_const_92 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[321]) }

func A_arbace_j2g_dyncf_A_clinit_p7() { A_arbace_j2g_dyncf_A_const_93 = A_arbace_j2g_dyncf_A_const_pool.A[322]; A_arbace_j2g_dyncf_A_const_94 = A_arbace_j2g_dyncf_A_const_pool.A[323]; A_arbace_j2g_dyncf_A_const_95 = A_arbace_j2g_dyncf_A_const_pool.A[324]; A_arbace_j2g_dyncf_A_const_96 = A_arbace_j2g_dyncf_A_const_pool.A[325]; A_arbace_j2g_dyncf_A_const_97 = A_arbace_j2g_dyncf_A_const_pool.A[326]; A_arbace_j2g_dyncf_A_const_98 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[327]); A_arbace_j2g_dyncf_A_const_99 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[328]); A_arbace_j2g_dyncf_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[329]); A_arbace_j2g_dyncf_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[330]); A_arbace_j2g_dyncf_A_const_102 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[331]); A_arbace_j2g_dyncf_A_const_103 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[332]); A_arbace_j2g_dyncf_A_const_104 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[333]); A_arbace_j2g_dyncf_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[334]) }

func A_arbace_j2g_dyncf_A_clinit_p8() { A_arbace_j2g_dyncf_A_const_106 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[335]); A_arbace_j2g_dyncf_A_const_107 = A_arbace_j2g_dyncf_A_const_pool.A[336]; A_arbace_j2g_dyncf_A_const_108 = A_arbace_j2g_dyncf_A_const_pool.A[337]; A_arbace_j2g_dyncf_A_const_109 = A_arbace_j2g_dyncf_A_const_pool.A[338]; A_arbace_j2g_dyncf_A_const_110 = A_arbace_j2g_dyncf_A_const_pool.A[339]; A_arbace_j2g_dyncf_A_const_111 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[340]); A_arbace_j2g_dyncf_A_const_112 = A_arbace_j2g_dyncf_A_const_pool.A[341]; A_arbace_j2g_dyncf_A_const_113 = A_arbace_j2g_dyncf_A_const_pool.A[342]; A_arbace_j2g_dyncf_A_const_114 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[343]); A_arbace_j2g_dyncf_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[344]); A_arbace_j2g_dyncf_A_const_116 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[345]); A_arbace_j2g_dyncf_A_const_117 = A_arbace_j2g_dyncf_A_const_pool.A[346]; A_arbace_j2g_dyncf_A_const_118 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[347]); A_arbace_j2g_dyncf_A_const_119 = A_arbace_j2g_dyncf_A_const_pool.A[348] }

func A_arbace_j2g_dyncf_A_clinit_p9() { A_arbace_j2g_dyncf_A_const_120 = A_arbace_j2g_dyncf_A_const_pool.A[349]; A_arbace_j2g_dyncf_A_const_121 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[350]); A_arbace_j2g_dyncf_A_const_122 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[351]); A_arbace_j2g_dyncf_A_const_123 = A_arbace_j2g_dyncf_A_const_pool.A[352]; A_arbace_j2g_dyncf_A_const_124 = A_arbace_j2g_dyncf_A_const_pool.A[353]; A_arbace_j2g_dyncf_A_const_125 = A_arbace_j2g_dyncf_A_const_pool.A[354]; A_arbace_j2g_dyncf_A_const_126 = A_arbace_j2g_dyncf_A_const_pool.A[355]; A_arbace_j2g_dyncf_A_const_127 = A_arbace_j2g_dyncf_A_const_pool.A[356]; A_arbace_j2g_dyncf_A_const_128 = A_arbace_j2g_dyncf_A_const_pool.A[357]; A_arbace_j2g_dyncf_A_const_129 = A_arbace_j2g_dyncf_A_const_pool.A[358]; A_arbace_j2g_dyncf_A_const_130 = A_arbace_j2g_dyncf_A_const_pool.A[359]; A_arbace_j2g_dyncf_A_const_131 = A_arbace_j2g_dyncf_A_const_pool.A[360]; A_arbace_j2g_dyncf_A_const_132 = A_arbace_j2g_dyncf_A_const_pool.A[361]; A_arbace_j2g_dyncf_A_const_133 = A_arbace_j2g_dyncf_A_const_pool.A[362]; A_arbace_j2g_dyncf_A_const_134 = A_arbace_j2g_dyncf_A_const_pool.A[363] }

func A_arbace_j2g_dyncf_A_clinit_p10() { A_arbace_j2g_dyncf_A_const_135 = A_arbace_j2g_dyncf_A_const_pool.A[364]; A_arbace_j2g_dyncf_A_const_136 = A_arbace_j2g_dyncf_A_const_pool.A[365]; A_arbace_j2g_dyncf_A_const_137 = A_arbace_j2g_dyncf_A_const_pool.A[366]; A_arbace_j2g_dyncf_A_const_138 = A_arbace_j2g_dyncf_A_const_pool.A[367]; A_arbace_j2g_dyncf_A_const_139 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[368]); A_arbace_j2g_dyncf_A_const_140 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[369]); A_arbace_j2g_dyncf_A_const_141 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[370]); A_arbace_j2g_dyncf_A_const_142 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[371]); A_arbace_j2g_dyncf_A_const_143 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[372]); A_arbace_j2g_dyncf_A_const_144 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[373]); A_arbace_j2g_dyncf_A_const_145 = A_arbace_j2g_dyncf_A_const_pool.A[374]; A_arbace_j2g_dyncf_A_const_146 = A_arbace_j2g_dyncf_A_const_pool.A[375]; A_arbace_j2g_dyncf_A_const_147 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[376]) }

func A_arbace_j2g_dyncf_A_clinit_p11() { A_arbace_j2g_dyncf_A_const_148 = A_arbace_j2g_dyncf_A_const_pool.A[377]; A_arbace_j2g_dyncf_A_const_149 = A_arbace_j2g_dyncf_A_const_pool.A[378]; A_arbace_j2g_dyncf_A_const_150 = A_arbace_j2g_dyncf_A_const_pool.A[379]; A_arbace_j2g_dyncf_A_const_151 = A_arbace_j2g_dyncf_A_const_pool.A[380]; A_arbace_j2g_dyncf_A_const_152 = A_arbace_j2g_dyncf_A_const_pool.A[381]; A_arbace_j2g_dyncf_A_const_153 = A_arbace_j2g_dyncf_A_const_pool.A[382]; A_arbace_j2g_dyncf_A_const_154 = A_arbace_j2g_dyncf_A_const_pool.A[383]; A_arbace_j2g_dyncf_A_const_155 = A_arbace_j2g_dyncf_A_const_pool.A[384]; A_arbace_j2g_dyncf_A_const_156 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[385]); A_arbace_j2g_dyncf_A_const_157 = A_arbace_j2g_dyncf_A_const_pool.A[386]; A_arbace_j2g_dyncf_A_const_158 = A_arbace_j2g_dyncf_A_const_pool.A[387]; A_arbace_j2g_dyncf_A_const_159 = A_arbace_j2g_dyncf_A_const_pool.A[388]; A_arbace_j2g_dyncf_A_const_160 = A_arbace_j2g_dyncf_A_const_pool.A[389]; A_arbace_j2g_dyncf_A_const_161 = A_arbace_j2g_dyncf_A_const_pool.A[390]; A_arbace_j2g_dyncf_A_const_162 = A_arbace_j2g_dyncf_A_const_pool.A[391] }

func A_arbace_j2g_dyncf_A_clinit_p12() { A_arbace_j2g_dyncf_A_const_163 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[392]); A_arbace_j2g_dyncf_A_const_164 = A_arbace_j2g_dyncf_A_const_pool.A[393]; A_arbace_j2g_dyncf_A_const_165 = A_arbace_j2g_dyncf_A_const_pool.A[394]; A_arbace_j2g_dyncf_A_const_166 = A_arbace_j2g_dyncf_A_const_pool.A[395]; A_arbace_j2g_dyncf_A_const_167 = A_arbace_j2g_dyncf_A_const_pool.A[396]; A_arbace_j2g_dyncf_A_const_168 = A_arbace_j2g_dyncf_A_const_pool.A[397]; A_arbace_j2g_dyncf_A_const_169 = A_arbace_j2g_dyncf_A_const_pool.A[398]; A_arbace_j2g_dyncf_A_const_170 = A_arbace_j2g_dyncf_A_const_pool.A[399]; A_arbace_j2g_dyncf_A_const_171 = A_arbace_j2g_dyncf_A_const_pool.A[400]; A_arbace_j2g_dyncf_A_const_172 = A_arbace_j2g_dyncf_A_const_pool.A[401]; A_arbace_j2g_dyncf_A_const_173 = A_arbace_j2g_dyncf_A_const_pool.A[402]; A_arbace_j2g_dyncf_A_const_174 = A_arbace_j2g_dyncf_A_const_pool.A[403]; A_arbace_j2g_dyncf_A_const_175 = A_arbace_j2g_dyncf_A_const_pool.A[404]; A_arbace_j2g_dyncf_A_const_176 = A_arbace_j2g_dyncf_A_const_pool.A[405]; A_arbace_j2g_dyncf_A_const_177 = A_arbace_j2g_dyncf_A_const_pool.A[406] }

func A_arbace_j2g_dyncf_A_clinit_p13() { A_arbace_j2g_dyncf_A_const_178 = A_arbace_j2g_dyncf_A_const_pool.A[407]; A_arbace_j2g_dyncf_A_const_179 = A_arbace_j2g_dyncf_A_const_pool.A[408]; A_arbace_j2g_dyncf_A_const_180 = A_arbace_j2g_dyncf_A_const_pool.A[409]; A_arbace_j2g_dyncf_A_const_181 = A_arbace_j2g_dyncf_A_const_pool.A[410]; A_arbace_j2g_dyncf_A_const_182 = A_arbace_j2g_dyncf_A_const_pool.A[411]; A_arbace_j2g_dyncf_A_const_183 = A_arbace_j2g_dyncf_A_const_pool.A[412]; A_arbace_j2g_dyncf_A_const_184 = A_arbace_j2g_dyncf_A_const_pool.A[413]; A_arbace_j2g_dyncf_A_const_185 = A_arbace_j2g_dyncf_A_const_pool.A[414]; A_arbace_j2g_dyncf_A_const_186 = A_arbace_j2g_dyncf_A_const_pool.A[415]; A_arbace_j2g_dyncf_A_const_187 = A_arbace_j2g_dyncf_A_const_pool.A[416]; A_arbace_j2g_dyncf_A_const_188 = A_arbace_j2g_dyncf_A_const_pool.A[417]; A_arbace_j2g_dyncf_A_const_189 = A_arbace_j2g_dyncf_A_const_pool.A[418]; A_arbace_j2g_dyncf_A_const_190 = A_arbace_j2g_dyncf_A_const_pool.A[419]; A_arbace_j2g_dyncf_A_const_191 = A_arbace_j2g_dyncf_A_const_pool.A[420]; A_arbace_j2g_dyncf_A_const_192 = A_arbace_j2g_dyncf_A_const_pool.A[421]; A_arbace_j2g_dyncf_A_const_193 = A_arbace_j2g_dyncf_A_const_pool.A[422] }

func A_arbace_j2g_dyncf_A_clinit_p14() { A_arbace_j2g_dyncf_A_const_194 = A_arbace_j2g_dyncf_A_const_pool.A[423]; A_arbace_j2g_dyncf_A_const_195 = A_arbace_j2g_dyncf_A_const_pool.A[424]; A_arbace_j2g_dyncf_A_const_196 = A_arbace_j2g_dyncf_A_const_pool.A[425]; A_arbace_j2g_dyncf_A_const_197 = A_arbace_j2g_dyncf_A_const_pool.A[426]; A_arbace_j2g_dyncf_A_const_198 = A_arbace_j2g_dyncf_A_const_pool.A[427]; A_arbace_j2g_dyncf_A_const_199 = A_arbace_j2g_dyncf_A_const_pool.A[428]; A_arbace_j2g_dyncf_A_const_200 = A_arbace_j2g_dyncf_A_const_pool.A[429]; A_arbace_j2g_dyncf_A_const_201 = A_arbace_j2g_dyncf_A_const_pool.A[430]; A_arbace_j2g_dyncf_A_const_202 = A_arbace_j2g_dyncf_A_const_pool.A[431]; A_arbace_j2g_dyncf_A_const_203 = A_arbace_j2g_dyncf_A_const_pool.A[432]; A_arbace_j2g_dyncf_A_const_204 = A_arbace_j2g_dyncf_A_const_pool.A[433]; A_arbace_j2g_dyncf_A_const_205 = A_arbace_j2g_dyncf_A_const_pool.A[434]; A_arbace_j2g_dyncf_A_const_206 = A_arbace_j2g_dyncf_A_const_pool.A[435]; A_arbace_j2g_dyncf_A_const_207 = A_arbace_j2g_dyncf_A_const_pool.A[436]; A_arbace_j2g_dyncf_A_const_208 = A_arbace_j2g_dyncf_A_const_pool.A[437]; A_arbace_j2g_dyncf_A_const_209 = A_arbace_j2g_dyncf_A_const_pool.A[438] }

func A_arbace_j2g_dyncf_A_clinit_p15() { A_arbace_j2g_dyncf_A_const_210 = A_arbace_j2g_dyncf_A_const_pool.A[439]; A_arbace_j2g_dyncf_A_const_211 = A_arbace_j2g_dyncf_A_const_pool.A[440]; A_arbace_j2g_dyncf_A_const_212 = A_arbace_j2g_dyncf_A_const_pool.A[441]; A_arbace_j2g_dyncf_A_const_213 = A_arbace_j2g_dyncf_A_const_pool.A[442]; A_arbace_j2g_dyncf_A_const_214 = A_arbace_j2g_dyncf_A_const_pool.A[443]; A_arbace_j2g_dyncf_A_const_215 = A_arbace_j2g_dyncf_A_const_pool.A[444]; A_arbace_j2g_dyncf_A_const_216 = A_arbace_j2g_dyncf_A_const_pool.A[445]; A_arbace_j2g_dyncf_A_const_217 = A_arbace_j2g_dyncf_A_const_pool.A[446]; A_arbace_j2g_dyncf_A_const_218 = A_arbace_j2g_dyncf_A_const_pool.A[447]; A_arbace_j2g_dyncf_A_const_219 = A_arbace_j2g_dyncf_A_const_pool.A[448]; A_arbace_j2g_dyncf_A_const_220 = A_arbace_j2g_dyncf_A_const_pool.A[449]; A_arbace_j2g_dyncf_A_const_221 = A_arbace_j2g_dyncf_A_const_pool.A[450]; A_arbace_j2g_dyncf_A_const_222 = A_arbace_j2g_dyncf_A_const_pool.A[451]; A_arbace_j2g_dyncf_A_const_223 = A_arbace_j2g_dyncf_A_const_pool.A[452]; A_arbace_j2g_dyncf_A_const_224 = A_arbace_j2g_dyncf_A_const_pool.A[453]; A_arbace_j2g_dyncf_A_const_225 = A_arbace_j2g_dyncf_A_const_pool.A[454] }

func A_arbace_j2g_dyncf_A_clinit_p16() { A_arbace_j2g_dyncf_A_const_226 = A_arbace_j2g_dyncf_A_const_pool.A[455]; A_arbace_j2g_dyncf_A_const_227 = A_arbace_j2g_dyncf_A_const_pool.A[456]; A_arbace_j2g_dyncf_A_const_228 = A_arbace_j2g_dyncf_A_const_pool.A[457]; A_arbace_j2g_dyncf_A_const_229 = A_arbace_j2g_dyncf_A_const_pool.A[458]; A_arbace_j2g_dyncf_A_const_230 = A_arbace_j2g_dyncf_A_const_pool.A[459]; A_arbace_j2g_dyncf_A_const_231 = A_arbace_j2g_dyncf_A_const_pool.A[460]; A_arbace_j2g_dyncf_A_const_232 = A_arbace_j2g_dyncf_A_const_pool.A[461]; A_arbace_j2g_dyncf_A_const_233 = A_arbace_j2g_dyncf_A_const_pool.A[462]; A_arbace_j2g_dyncf_A_const_234 = A_arbace_j2g_dyncf_A_const_pool.A[463]; A_arbace_j2g_dyncf_A_const_235 = A_arbace_j2g_dyncf_A_const_pool.A[464]; A_arbace_j2g_dyncf_A_const_236 = A_arbace_j2g_dyncf_A_const_pool.A[465]; A_arbace_j2g_dyncf_A_const_237 = A_arbace_j2g_dyncf_A_const_pool.A[466]; A_arbace_j2g_dyncf_A_const_238 = A_arbace_j2g_dyncf_A_const_pool.A[467]; A_arbace_j2g_dyncf_A_const_239 = A_arbace_j2g_dyncf_A_const_pool.A[468]; A_arbace_j2g_dyncf_A_const_240 = A_arbace_j2g_dyncf_A_const_pool.A[469]; A_arbace_j2g_dyncf_A_const_241 = A_arbace_j2g_dyncf_A_const_pool.A[470] }

func A_arbace_j2g_dyncf_A_clinit_p17() { A_arbace_j2g_dyncf_A_const_242 = A_arbace_j2g_dyncf_A_const_pool.A[471]; A_arbace_j2g_dyncf_A_const_243 = A_arbace_j2g_dyncf_A_const_pool.A[472]; A_arbace_j2g_dyncf_A_const_244 = A_arbace_j2g_dyncf_A_const_pool.A[473]; A_arbace_j2g_dyncf_A_const_245 = A_arbace_j2g_dyncf_A_const_pool.A[474]; A_arbace_j2g_dyncf_A_const_246 = A_arbace_j2g_dyncf_A_const_pool.A[475]; A_arbace_j2g_dyncf_A_const_247 = A_arbace_j2g_dyncf_A_const_pool.A[476]; A_arbace_j2g_dyncf_A_const_248 = A_arbace_j2g_dyncf_A_const_pool.A[477]; A_arbace_j2g_dyncf_A_const_249 = A_arbace_j2g_dyncf_A_const_pool.A[478]; A_arbace_j2g_dyncf_A_const_250 = A_arbace_j2g_dyncf_A_const_pool.A[479]; A_arbace_j2g_dyncf_A_const_251 = A_arbace_j2g_dyncf_A_const_pool.A[480]; A_arbace_j2g_dyncf_A_const_252 = A_arbace_j2g_dyncf_A_const_pool.A[481]; A_arbace_j2g_dyncf_A_const_253 = A_arbace_j2g_dyncf_A_const_pool.A[482]; A_arbace_j2g_dyncf_A_const_254 = A_arbace_j2g_dyncf_A_const_pool.A[483]; A_arbace_j2g_dyncf_A_const_255 = A_arbace_j2g_dyncf_A_const_pool.A[484]; A_arbace_j2g_dyncf_A_const_256 = A_arbace_j2g_dyncf_A_const_pool.A[485]; A_arbace_j2g_dyncf_A_const_257 = A_arbace_j2g_dyncf_A_const_pool.A[486] }

func A_arbace_j2g_dyncf_A_clinit_p18() { A_arbace_j2g_dyncf_A_const_258 = A_arbace_j2g_dyncf_A_const_pool.A[487]; A_arbace_j2g_dyncf_A_const_259 = A_arbace_j2g_dyncf_A_const_pool.A[488]; A_arbace_j2g_dyncf_A_const_260 = A_arbace_j2g_dyncf_A_const_pool.A[489]; A_arbace_j2g_dyncf_A_const_261 = A_arbace_j2g_dyncf_A_const_pool.A[490]; A_arbace_j2g_dyncf_A_const_262 = A_arbace_j2g_dyncf_A_const_pool.A[491]; A_arbace_j2g_dyncf_A_const_263 = A_arbace_j2g_dyncf_A_const_pool.A[492]; A_arbace_j2g_dyncf_A_const_264 = A_arbace_j2g_dyncf_A_const_pool.A[493]; A_arbace_j2g_dyncf_A_const_265 = A_arbace_j2g_dyncf_A_const_pool.A[494]; A_arbace_j2g_dyncf_A_const_266 = A_arbace_j2g_dyncf_A_const_pool.A[495]; A_arbace_j2g_dyncf_A_const_267 = A_arbace_j2g_dyncf_A_const_pool.A[496]; A_arbace_j2g_dyncf_A_const_268 = A_arbace_j2g_dyncf_A_const_pool.A[497]; A_arbace_j2g_dyncf_A_const_269 = A_arbace_j2g_dyncf_A_const_pool.A[498]; A_arbace_j2g_dyncf_A_const_270 = A_arbace_j2g_dyncf_A_const_pool.A[499]; A_arbace_j2g_dyncf_A_const_271 = A_arbace_j2g_dyncf_A_const_pool.A[500]; A_arbace_j2g_dyncf_A_const_272 = A_arbace_j2g_dyncf_A_const_pool.A[501]; A_arbace_j2g_dyncf_A_const_273 = A_arbace_j2g_dyncf_A_const_pool.A[502] }

func A_arbace_j2g_dyncf_A_clinit_p19() { A_arbace_j2g_dyncf_A_const_274 = A_arbace_j2g_dyncf_A_const_pool.A[503]; A_arbace_j2g_dyncf_A_const_275 = A_arbace_j2g_dyncf_A_const_pool.A[504]; A_arbace_j2g_dyncf_A_const_276 = A_arbace_j2g_dyncf_A_const_pool.A[505]; A_arbace_j2g_dyncf_A_const_277 = A_arbace_j2g_dyncf_A_const_pool.A[506]; A_arbace_j2g_dyncf_A_const_278 = A_arbace_j2g_dyncf_A_const_pool.A[507]; A_arbace_j2g_dyncf_A_const_279 = A_arbace_j2g_dyncf_A_const_pool.A[508]; A_arbace_j2g_dyncf_A_const_280 = A_arbace_j2g_dyncf_A_const_pool.A[509]; A_arbace_j2g_dyncf_A_const_281 = A_arbace_j2g_dyncf_A_const_pool.A[510]; A_arbace_j2g_dyncf_A_const_282 = A_arbace_j2g_dyncf_A_const_pool.A[511]; A_arbace_j2g_dyncf_A_const_283 = A_arbace_j2g_dyncf_A_const_pool.A[512]; A_arbace_j2g_dyncf_A_const_284 = A_arbace_j2g_dyncf_A_const_pool.A[513]; A_arbace_j2g_dyncf_A_const_285 = A_arbace_j2g_dyncf_A_const_pool.A[514]; A_arbace_j2g_dyncf_A_const_286 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[515]); A_arbace_j2g_dyncf_A_const_287 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[516]); A_arbace_j2g_dyncf_A_const_288 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[517]) }

func A_arbace_j2g_dyncf_A_clinit_p20() { A_arbace_j2g_dyncf_A_const_289 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[518]); A_arbace_j2g_dyncf_A_const_290 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[519]); A_arbace_j2g_dyncf_A_const_291 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[520]); A_arbace_j2g_dyncf_A_const_292 = A_arbace_j2g_dyncf_A_const_pool.A[521]; A_arbace_j2g_dyncf_A_const_293 = A_arbace_j2g_dyncf_A_const_pool.A[522]; A_arbace_j2g_dyncf_A_const_294 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[523]); A_arbace_j2g_dyncf_A_const_295 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[524]); A_arbace_j2g_dyncf_A_const_296 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[525]); A_arbace_j2g_dyncf_A_const_297 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[526]); A_arbace_j2g_dyncf_A_const_298 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[527]); A_arbace_j2g_dyncf_A_const_299 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[528]); A_arbace_j2g_dyncf_A_const_300 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[529]) }

func A_arbace_j2g_dyncf_A_clinit_p21() { A_arbace_j2g_dyncf_A_const_301 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[530]); A_arbace_j2g_dyncf_A_const_302 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[531]); A_arbace_j2g_dyncf_A_const_303 = A_arbace_j2g_dyncf_A_const_pool.A[532]; A_arbace_j2g_dyncf_A_const_304 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[533]); A_arbace_j2g_dyncf_A_const_305 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[534]); A_arbace_j2g_dyncf_A_const_306 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[535]); A_arbace_j2g_dyncf_A_const_307 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[536]); A_arbace_j2g_dyncf_A_const_308 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[537]); A_arbace_j2g_dyncf_A_const_309 = lang.Keyword_Cast(A_arbace_j2g_dyncf_A_const_pool.A[538]); A_arbace_j2g_dyncf_A_const_310 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[539]); A_arbace_j2g_dyncf_A_const_311 = A_arbace_j2g_dyncf_A_const_pool.A[540]; A_arbace_j2g_dyncf_A_const_312 = A_arbace_j2g_dyncf_A_const_pool.A[541]; A_arbace_j2g_dyncf_A_const_313 = A_arbace_j2g_dyncf_A_const_pool.A[542] }

func A_arbace_j2g_dyncf_A_clinit_p22() { A_arbace_j2g_dyncf_A_const_314 = A_arbace_j2g_dyncf_A_const_pool.A[543]; A_arbace_j2g_dyncf_A_const_315 = A_arbace_j2g_dyncf_A_const_pool.A[544]; A_arbace_j2g_dyncf_A_const_316 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[545]); A_arbace_j2g_dyncf_A_const_317 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[546]); A_arbace_j2g_dyncf_A_const_318 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[547]); A_arbace_j2g_dyncf_A_const_319 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[548]); A_arbace_j2g_dyncf_A_const_320 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[549]); A_arbace_j2g_dyncf_A_const_321 = lang.Var_Cast(A_arbace_j2g_dyncf_A_const_pool.A[550]) }

func A_arbace_j2g_dyncf_A_New() *A_arbace_j2g_dyncf_A { A_arbace_j2g_dyncf_A_Init(); t := &A_arbace_j2g_dyncf_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_A_class }

func (t *A_arbace_j2g_dyncf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_A); return ok }

func A_arbace_j2g_dyncf_A_Cast(x any) *A_arbace_j2g_dyncf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_A_class)) }; return v }



type A_arbace_j2g_dyncf_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000004_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000004_A_New() *A_arbace_j2g_dyncf_eval292000004_A { t := &A_arbace_j2g_dyncf_eval292000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000004_A_class }

func (t *A_arbace_j2g_dyncf_eval292000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); return ok }

func A_arbace_j2g_dyncf_eval292000004_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000004_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000004_loading__1927001464__auto____292000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_eval292000008_A struct{ jrt.Object }

func A_arbace_j2g_dyncf_eval292000008_A_New() *A_arbace_j2g_dyncf_eval292000008_A { t := &A_arbace_j2g_dyncf_eval292000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ctor() {}

func (t *A_arbace_j2g_dyncf_eval292000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyncf_eval292000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyncf_eval292000008_A_class }

func (t *A_arbace_j2g_dyncf_eval292000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyncf_eval292000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyncf_eval292000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); return ok }

func A_arbace_j2g_dyncf_eval292000008_A_Cast(x any) *A_arbace_j2g_dyncf_eval292000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyncf_eval292000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyncf_eval292000008_A_class)) }; return v }



type A_arbace_j2g_dyncf_eval292000008_fn__292000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_eval292000008_fn__292000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_from_object_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_from_object_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A struct{ j2g_header uint64; F_extendable any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A struct{ j2g_header uint64; F_iter__292000093, F_s__292000094, F_extendable any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A struct{ j2g_header uint64; F_b__292000096, F_extendable any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_fn__292000100_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A struct{ j2g_header uint64; F_iter__292000103, F_s__292000104 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A struct{ j2g_header uint64; F_b__292000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000103__292000107_fn__292000108_fn__292000109_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A struct{ j2g_header uint64; F_iter__292000113, F_s__292000114 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A struct{ j2g_header uint64; F_b__292000116 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000099_iter__292000113__292000117_fn__292000118_fn__292000119_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_fn__292000124_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A struct{ j2g_header uint64; F_iter__292000127, F_s__292000128 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A struct{ j2g_header uint64; F_b__292000130 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000127__292000131_fn__292000132_fn__292000133_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A struct{ j2g_header uint64; F_iter__292000137, F_s__292000138 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A struct{ j2g_header uint64; F_b__292000140 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000093__292000097_fn__292000098_iter__292000137__292000141_fn__292000142_fn__292000143_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A struct{ j2g_header uint64; F_s__292000150, F_iter__292000149 any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A struct{ j2g_header uint64; F_b__292000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_generics_text_iter__292000149__292000153_fn__292000154_fn__292000155_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_strip_anns_fn__292000090_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_strip_anns_fn__292000090_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000017, F_s__292000018 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A struct{ j2g_header uint64; F_b__292000020, F_recv, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000023_fn__292000030_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000017__292000021_fn__292000022_fn__292000039_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A struct{ j2g_header uint64; F_recv, F_n, F_iter__292000043, F_s__292000044 any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A struct{ j2g_header uint64; F_recv, F_b__292000046, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000049_fn__292000059_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_forms_iter__292000043__292000047_fn__292000048_fn__292000072_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A struct{ j2g_header uint64; F_iter__292000078, F_s__292000079 any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A struct{ j2g_header uint64; F_b__292000081 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyncf_subs_forms_iter__292000078__292000082_fn__292000083_fn__292000084_A_fn_class *jrt.Class



type A_arbace_j2g_dyncf_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyncf_tag_A_fn_class *jrt.Class
