//line aot_arbace_j2g_world__init.ae:1
package aot_arbace_j2g_world

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_world__init_A_Unit0__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_world__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world__init_A_const_1) }
//line :1:1
func A_arbace_j2g_world__init_A_Unit1__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_world__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_world__init_A_Unit2__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_194, false, nil); A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_world__init_A_Unit3__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_world__init_A_const_1)).Equals_O__Z(A_arbace_j2g_world__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_world_eval78000008_fn__78000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_world_eval78000008_fn__78000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_195, false, nil); A_arbace_j2g_world_eval78000008_fn__78000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_j2g_world__init_A_Load__O() any { A_arbace_j2g_world__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_world__init_A_Unit0__O(); A_arbace_j2g_world__init_A_Unit1__O(); A_arbace_j2g_world__init_A_Unit2__O(); A_arbace_j2g_world__init_A_Unit3__O(); A_arbace_j2g_world__init_A_Unit4__O(); A_arbace_j2g_world__init_A_Unit5__O(); A_arbace_j2g_world__init_A_Unit6__O(); A_arbace_j2g_world__init_A_Unit7__O(); A_arbace_j2g_world__init_A_Unit8__O(); A_arbace_j2g_world__init_A_Unit9__O(); A_arbace_j2g_world__init_A_Unit10__O(); A_arbace_j2g_world__init_A_Unit11__O(); A_arbace_j2g_world__init_A_Unit12__O(); A_arbace_j2g_world__init_A_Unit13__O(); A_arbace_j2g_world__init_A_Unit14__O(); A_arbace_j2g_world__init_A_Unit15__O(); A_arbace_j2g_world__init_A_Unit16__O(); A_arbace_j2g_world__init_A_Unit17__O(); A_arbace_j2g_world__init_A_Unit18__O(); A_arbace_j2g_world__init_A_Unit19__O(); A_arbace_j2g_world__init_A_Unit20__O(); A_arbace_j2g_world__init_A_Unit21__O(); A_arbace_j2g_world__init_A_Unit22__O(); A_arbace_j2g_world__init_A_Unit23__O(); A_arbace_j2g_world__init_A_Unit24__O(); A_arbace_j2g_world__init_A_Unit25__O(); A_arbace_j2g_world__init_A_Unit26__O(); A_arbace_j2g_world__init_A_Unit27__O(); A_arbace_j2g_world__init_A_Unit28__O(); A_arbace_j2g_world__init_A_Unit29__O(); A_arbace_j2g_world__init_A_Unit30__O(); A_arbace_j2g_world__init_A_Unit31__O(); A_arbace_j2g_world__init_A_Unit32__O(); A_arbace_j2g_world__init_A_Unit33__O(); return nil }











func A_arbace_j2g_world__init_A_Unit4__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_world_read_forms_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_world_read_forms_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_196, false, nil); A_arbace_j2g_world_read_forms_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_5)); return A_arbace_j2g_world__init_A_const_4 }










func A_arbace_j2g_world__init_A_Unit5__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_world_first_form_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_world_first_form_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_197, false, nil); A_arbace_j2g_world_first_form_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_7)); return A_arbace_j2g_world__init_A_const_6 }







func A_arbace_j2g_world__init_A_Unit6__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_world_class_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_world_class_form_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_198, false, nil); A_arbace_j2g_world_class_form_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_9)); return A_arbace_j2g_world__init_A_const_8 }

func A_arbace_j2g_world__init_A_Unit7__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_world_class_forms_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_world_class_forms_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_199, false, nil); A_arbace_j2g_world_class_forms_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_11)); return A_arbace_j2g_world__init_A_const_10 }





func A_arbace_j2g_world__init_A_Unit8__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_world_continued_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_world_continued_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_200, false, nil); A_arbace_j2g_world_continued_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_13)); return A_arbace_j2g_world__init_A_const_12 }

func A_arbace_j2g_world__init_A_Unit9__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_world_join_continued_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_world_join_continued_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_201, false, nil); A_arbace_j2g_world_join_continued_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_15)); return A_arbace_j2g_world__init_A_const_14 }
































func A_arbace_j2g_world__init_A_Unit10__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_world_refer_vars_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_world_refer_vars_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_202, false, nil); A_arbace_j2g_world_refer_vars_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_17)); return A_arbace_j2g_world__init_A_const_16 }

























func A_arbace_j2g_world__init_A_Unit11__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_world_ns_of_forms_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_world_ns_of_forms_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_203, false, nil); A_arbace_j2g_world_ns_of_forms_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_19)); return A_arbace_j2g_world__init_A_const_18 }



func A_arbace_j2g_world__init_A_Unit12__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_world_top_names_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_world_top_names_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_204, false, nil); A_arbace_j2g_world_top_names_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_21)); return A_arbace_j2g_world__init_A_const_20 }











func A_arbace_j2g_world__init_A_Unit13__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_world_source_files_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_world_source_files_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_205, false, nil); A_arbace_j2g_world_source_files_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_23)); return A_arbace_j2g_world__init_A_const_22 }




















func A_arbace_j2g_world__init_A_Unit14__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_world_head_name_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_world_head_name_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_206, false, nil); A_arbace_j2g_world_head_name_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_25)); return A_arbace_j2g_world__init_A_const_24 }

func A_arbace_j2g_world__init_A_Unit15__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_world_param_key_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_world_param_key_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_207, false, nil); A_arbace_j2g_world_param_key_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_27)); return A_arbace_j2g_world__init_A_const_26 }


























func A_arbace_j2g_world__init_A_Unit16__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_world_cut_key_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_world_cut_key_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_208, false, nil); A_arbace_j2g_world_cut_key_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_29)); return A_arbace_j2g_world__init_A_const_28 }







func A_arbace_j2g_world__init_A_Unit17__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(179, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_world_class_parts_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_world_class_parts_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_209, false, nil); A_arbace_j2g_world_class_parts_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_31)); return A_arbace_j2g_world__init_A_const_30 }







func A_arbace_j2g_world__init_A_Unit18__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_world_apply_variant_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_world_apply_variant_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_210, false, nil); A_arbace_j2g_world_apply_variant_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_33)); return A_arbace_j2g_world__init_A_const_32 }














































func A_arbace_j2g_world__init_A_Unit19__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_world_read_variants_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_world_read_variants_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_211, false, nil); A_arbace_j2g_world_read_variants_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_35)); return A_arbace_j2g_world__init_A_const_34 }




















func A_arbace_j2g_world__init_A_Unit20__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_world_new_unit_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_world_new_unit_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_212, false, nil); A_arbace_j2g_world_new_unit_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_37)); return A_arbace_j2g_world__init_A_const_36 }



func A_arbace_j2g_world__init_A_Unit21__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(259, 1); A_arbace_j2g_world__init_A_const_38.BindRoot_O__V(A_arbace_j2g_world__init_A_const_39); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_40)); return A_arbace_j2g_world__init_A_const_38 }




func A_arbace_j2g_world__init_A_Unit22__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(264, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_world_id_space_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_world_id_space_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_213, false, nil); A_arbace_j2g_world_id_space_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_42)); return A_arbace_j2g_world__init_A_const_41 }







func A_arbace_j2g_world__init_A_Unit23__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(272, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_world_parse_member_classes_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_world_parse_member_classes_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_214, false, nil); A_arbace_j2g_world_parse_member_classes_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_44)); return A_arbace_j2g_world__init_A_const_43 }









func A_arbace_j2g_world__init_A_Unit24__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(282, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_world_levels_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_world_levels_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_215, false, nil); A_arbace_j2g_world_levels_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_46)); return A_arbace_j2g_world__init_A_const_45 }














func A_arbace_j2g_world__init_A_Unit25__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_world_supers_of_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_world_supers_of_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_216, false, nil); A_arbace_j2g_world_supers_of_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_48)); return A_arbace_j2g_world__init_A_const_47 }




func A_arbace_j2g_world__init_A_Unit26__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(302, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_world_par_levels_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_world_par_levels_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_217, false, nil); A_arbace_j2g_world_par_levels_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_50)); return A_arbace_j2g_world__init_A_const_49 }









func A_arbace_j2g_world__init_A_Unit27__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_j2g_world_imported_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_world_imported_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_218, false, nil); A_arbace_j2g_world_imported_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_52)); return A_arbace_j2g_world__init_A_const_51 }














func A_arbace_j2g_world__init_A_Unit28__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(327, 1); A_arbace_j2g_world__init_A_const_53.BindRoot_O__V(A_arbace_j2g_world__init_A_const_54); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_55)); return A_arbace_j2g_world__init_A_const_53 }


func A_arbace_j2g_world__init_A_Unit29__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_j2g_world_name_import_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_world_name_import_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_219, false, nil); A_arbace_j2g_world_name_import_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_57)); return A_arbace_j2g_world__init_A_const_56 }













func A_arbace_j2g_world__init_A_Unit30__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(344, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_58; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__54 any = A_arbace_j2g_world_load_world_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_world_load_world_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_220, true, nil); A_arbace_j2g_world_load_world_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__54, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_59)); return A_arbace_j2g_world__init_A_const_58 }



















































































































































































































































func A_arbace_j2g_world__init_A_Unit31__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(588, 1); var tmp1 *lang.Var = A_arbace_j2g_world__init_A_const_60; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__56 any = A_arbace_j2g_world_with_world_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_world_with_world_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_221, true, nil); A_arbace_j2g_world_with_world_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__56, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_world__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_world__init_A_const_61)); return A_arbace_j2g_world__init_A_const_60 }
//line :588:1
func A_arbace_j2g_world__init_A_Unit32__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(588, 1); A_arbace_j2g_world__init_A_const_60.SetMacro__V(); return nil }
//line :588:1
func A_arbace_j2g_world__init_A_Unit33__O() any { A_arbace_j2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(588, 1); return A_arbace_j2g_world__init_A_const_60 }







type A_arbace_j2g_world__init_A struct{ jrt.Object }

var A_arbace_j2g_world__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_world__init_A_const_0 *lang.Var

var A_arbace_j2g_world__init_A_const_1 any

var A_arbace_j2g_world__init_A_const_2 any

var A_arbace_j2g_world__init_A_const_3 any

var A_arbace_j2g_world__init_A_const_4 *lang.Var

var A_arbace_j2g_world__init_A_const_5 any

var A_arbace_j2g_world__init_A_const_6 *lang.Var

var A_arbace_j2g_world__init_A_const_7 any

var A_arbace_j2g_world__init_A_const_8 *lang.Var

var A_arbace_j2g_world__init_A_const_9 any

var A_arbace_j2g_world__init_A_const_10 *lang.Var

var A_arbace_j2g_world__init_A_const_11 any

var A_arbace_j2g_world__init_A_const_12 *lang.Var

var A_arbace_j2g_world__init_A_const_13 any

var A_arbace_j2g_world__init_A_const_14 *lang.Var

var A_arbace_j2g_world__init_A_const_15 any

var A_arbace_j2g_world__init_A_const_16 *lang.Var

var A_arbace_j2g_world__init_A_const_17 any

var A_arbace_j2g_world__init_A_const_18 *lang.Var

var A_arbace_j2g_world__init_A_const_19 any

var A_arbace_j2g_world__init_A_const_20 *lang.Var

var A_arbace_j2g_world__init_A_const_21 any

var A_arbace_j2g_world__init_A_const_22 *lang.Var

var A_arbace_j2g_world__init_A_const_23 any

var A_arbace_j2g_world__init_A_const_24 *lang.Var

var A_arbace_j2g_world__init_A_const_25 any

var A_arbace_j2g_world__init_A_const_26 *lang.Var

var A_arbace_j2g_world__init_A_const_27 any

var A_arbace_j2g_world__init_A_const_28 *lang.Var

var A_arbace_j2g_world__init_A_const_29 any

var A_arbace_j2g_world__init_A_const_30 *lang.Var

var A_arbace_j2g_world__init_A_const_31 any

var A_arbace_j2g_world__init_A_const_32 *lang.Var

var A_arbace_j2g_world__init_A_const_33 any

var A_arbace_j2g_world__init_A_const_34 *lang.Var

var A_arbace_j2g_world__init_A_const_35 any

var A_arbace_j2g_world__init_A_const_36 *lang.Var

var A_arbace_j2g_world__init_A_const_37 any

var A_arbace_j2g_world__init_A_const_38 *lang.Var

var A_arbace_j2g_world__init_A_const_39 any

var A_arbace_j2g_world__init_A_const_40 any

var A_arbace_j2g_world__init_A_const_41 *lang.Var

var A_arbace_j2g_world__init_A_const_42 any

var A_arbace_j2g_world__init_A_const_43 *lang.Var

var A_arbace_j2g_world__init_A_const_44 any

var A_arbace_j2g_world__init_A_const_45 *lang.Var

var A_arbace_j2g_world__init_A_const_46 any

var A_arbace_j2g_world__init_A_const_47 *lang.Var

var A_arbace_j2g_world__init_A_const_48 any

var A_arbace_j2g_world__init_A_const_49 *lang.Var

var A_arbace_j2g_world__init_A_const_50 any

var A_arbace_j2g_world__init_A_const_51 *lang.Var

var A_arbace_j2g_world__init_A_const_52 any

var A_arbace_j2g_world__init_A_const_53 *lang.Var

var A_arbace_j2g_world__init_A_const_54 any

var A_arbace_j2g_world__init_A_const_55 any

var A_arbace_j2g_world__init_A_const_56 *lang.Var

var A_arbace_j2g_world__init_A_const_57 any

var A_arbace_j2g_world__init_A_const_58 *lang.Var

var A_arbace_j2g_world__init_A_const_59 any

var A_arbace_j2g_world__init_A_const_60 *lang.Var

var A_arbace_j2g_world__init_A_const_61 any

var A_arbace_j2g_world__init_A_init jrt.ClassInit

func A_arbace_j2g_world__init_A_Init() { if !A_arbace_j2g_world__init_A_init.Done() { A_arbace_j2g_world__init_A_init.Run(A_arbace_j2g_world__init_A_clinit) } }

func A_arbace_j2g_world__init_A_clinit() { A_arbace_j2g_world__init_A_clinit_p0(); A_arbace_j2g_world__init_A_clinit_p1(); A_arbace_j2g_world__init_A_clinit_p2(); A_arbace_j2g_world__init_A_clinit_p3(); A_arbace_j2g_world__init_A_clinit_p4() }

func A_arbace_j2g_world__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_world__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_193, 100); A_arbace_j2g_world__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[38]); A_arbace_j2g_world__init_A_const_1 = A_arbace_j2g_world__init_A_const_pool.A[39]; A_arbace_j2g_world__init_A_const_2 = A_arbace_j2g_world__init_A_const_pool.A[40]; A_arbace_j2g_world__init_A_const_3 = A_arbace_j2g_world__init_A_const_pool.A[41]; A_arbace_j2g_world__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[42]); A_arbace_j2g_world__init_A_const_5 = A_arbace_j2g_world__init_A_const_pool.A[43]; A_arbace_j2g_world__init_A_const_6 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[44]); A_arbace_j2g_world__init_A_const_7 = A_arbace_j2g_world__init_A_const_pool.A[45]; A_arbace_j2g_world__init_A_const_8 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[46]); A_arbace_j2g_world__init_A_const_9 = A_arbace_j2g_world__init_A_const_pool.A[47]; A_arbace_j2g_world__init_A_const_10 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[48]); A_arbace_j2g_world__init_A_const_11 = A_arbace_j2g_world__init_A_const_pool.A[49]; A_arbace_j2g_world__init_A_const_12 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[50]) }

func A_arbace_j2g_world__init_A_clinit_p1() { A_arbace_j2g_world__init_A_const_13 = A_arbace_j2g_world__init_A_const_pool.A[51]; A_arbace_j2g_world__init_A_const_14 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[52]); A_arbace_j2g_world__init_A_const_15 = A_arbace_j2g_world__init_A_const_pool.A[53]; A_arbace_j2g_world__init_A_const_16 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[54]); A_arbace_j2g_world__init_A_const_17 = A_arbace_j2g_world__init_A_const_pool.A[55]; A_arbace_j2g_world__init_A_const_18 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[56]); A_arbace_j2g_world__init_A_const_19 = A_arbace_j2g_world__init_A_const_pool.A[57]; A_arbace_j2g_world__init_A_const_20 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[58]); A_arbace_j2g_world__init_A_const_21 = A_arbace_j2g_world__init_A_const_pool.A[59]; A_arbace_j2g_world__init_A_const_22 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[60]); A_arbace_j2g_world__init_A_const_23 = A_arbace_j2g_world__init_A_const_pool.A[61]; A_arbace_j2g_world__init_A_const_24 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[62]); A_arbace_j2g_world__init_A_const_25 = A_arbace_j2g_world__init_A_const_pool.A[63] }

func A_arbace_j2g_world__init_A_clinit_p2() { A_arbace_j2g_world__init_A_const_26 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[64]); A_arbace_j2g_world__init_A_const_27 = A_arbace_j2g_world__init_A_const_pool.A[65]; A_arbace_j2g_world__init_A_const_28 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[66]); A_arbace_j2g_world__init_A_const_29 = A_arbace_j2g_world__init_A_const_pool.A[67]; A_arbace_j2g_world__init_A_const_30 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[68]); A_arbace_j2g_world__init_A_const_31 = A_arbace_j2g_world__init_A_const_pool.A[69]; A_arbace_j2g_world__init_A_const_32 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[70]); A_arbace_j2g_world__init_A_const_33 = A_arbace_j2g_world__init_A_const_pool.A[71]; A_arbace_j2g_world__init_A_const_34 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[72]); A_arbace_j2g_world__init_A_const_35 = A_arbace_j2g_world__init_A_const_pool.A[73]; A_arbace_j2g_world__init_A_const_36 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[74]); A_arbace_j2g_world__init_A_const_37 = A_arbace_j2g_world__init_A_const_pool.A[75]; A_arbace_j2g_world__init_A_const_38 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[76]) }

func A_arbace_j2g_world__init_A_clinit_p3() { A_arbace_j2g_world__init_A_const_39 = A_arbace_j2g_world__init_A_const_pool.A[77]; A_arbace_j2g_world__init_A_const_40 = A_arbace_j2g_world__init_A_const_pool.A[78]; A_arbace_j2g_world__init_A_const_41 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[79]); A_arbace_j2g_world__init_A_const_42 = A_arbace_j2g_world__init_A_const_pool.A[80]; A_arbace_j2g_world__init_A_const_43 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[81]); A_arbace_j2g_world__init_A_const_44 = A_arbace_j2g_world__init_A_const_pool.A[82]; A_arbace_j2g_world__init_A_const_45 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[83]); A_arbace_j2g_world__init_A_const_46 = A_arbace_j2g_world__init_A_const_pool.A[84]; A_arbace_j2g_world__init_A_const_47 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[85]); A_arbace_j2g_world__init_A_const_48 = A_arbace_j2g_world__init_A_const_pool.A[86]; A_arbace_j2g_world__init_A_const_49 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[87]); A_arbace_j2g_world__init_A_const_50 = A_arbace_j2g_world__init_A_const_pool.A[88]; A_arbace_j2g_world__init_A_const_51 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[89]); A_arbace_j2g_world__init_A_const_52 = A_arbace_j2g_world__init_A_const_pool.A[90] }

func A_arbace_j2g_world__init_A_clinit_p4() { A_arbace_j2g_world__init_A_const_53 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[91]); A_arbace_j2g_world__init_A_const_54 = A_arbace_j2g_world__init_A_const_pool.A[92]; A_arbace_j2g_world__init_A_const_55 = A_arbace_j2g_world__init_A_const_pool.A[93]; A_arbace_j2g_world__init_A_const_56 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[94]); A_arbace_j2g_world__init_A_const_57 = A_arbace_j2g_world__init_A_const_pool.A[95]; A_arbace_j2g_world__init_A_const_58 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[96]); A_arbace_j2g_world__init_A_const_59 = A_arbace_j2g_world__init_A_const_pool.A[97]; A_arbace_j2g_world__init_A_const_60 = lang.Var_Cast(A_arbace_j2g_world__init_A_const_pool.A[98]); A_arbace_j2g_world__init_A_const_61 = A_arbace_j2g_world__init_A_const_pool.A[99] }

func A_arbace_j2g_world__init_A_New() *A_arbace_j2g_world__init_A { A_arbace_j2g_world__init_A_Init(); t := &A_arbace_j2g_world__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_world__init_A) Ctor() {}

func (t *A_arbace_j2g_world__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_world__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_world__init_A_class }

func (t *A_arbace_j2g_world__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_world__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_world__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_world__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_world__init_A); return ok }

func A_arbace_j2g_world__init_A_Cast(x any) *A_arbace_j2g_world__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_world__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_world__init_A_class)) }; return v }
