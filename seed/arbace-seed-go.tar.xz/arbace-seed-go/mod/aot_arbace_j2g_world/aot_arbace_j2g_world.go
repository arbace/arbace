//line aot_arbace_j2g_world.ae:1
package aot_arbace_j2g_world

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_parse"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A_New() *A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_world_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_1); lang.IFn_Cast(A_arbace_j2g_world_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_world_A_const_3, A_arbace_j2g_world_A_const_4, A_arbace_j2g_world_A_const_5, A_arbace_j2g_world_A_const_6, A_arbace_j2g_world_A_const_7, A_arbace_j2g_world_A_const_8, A_arbace_j2g_world_A_const_9, A_arbace_j2g_world_A_const_10); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_world_eval78000008_fn__78000009_A_New() *A_arbace_j2g_world_eval78000008_fn__78000009_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_eval78000008_fn__78000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_world_eval78000008_fn__78000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_world_eval78000008_fn__78000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_11.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_j2g_world_A_const_13; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_world_A_const_14.GetRawRoot__O(), A_arbace_j2g_world_A_const_15) }















func A_arbace_j2g_world_read_forms_A_New() *A_arbace_j2g_world_read_forms_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_forms_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_world_read_forms_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_world_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_j2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_63 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_world_A_const_27, jrt.Boolean_FALSE.Ref()); if linked_64 == nil { ifn_65.Invoke_O__O(arg_66) } else { linked_64.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_63, arg_66) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_51 any = A_arbace_j2g_world_A_const_17.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any; var root_46 any = A_arbace_j2g_world_A_const_18.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var tmp2 any = A_arbace_j2g_world_read_forms_fn__78000013_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_world_read_forms_fn__78000013_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_j2g_world_read_forms_fn__78000013_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; arg_49 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_50 any; var root_42 any = A_arbace_j2g_world_A_const_21.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any; var tmp4 any = A_arbace_j2g_world_read_forms_fn__78000015_A_New_O(r__2); var tmp5 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_world_read_forms_fn__78000015_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_j2g_world_read_forms_fn__78000015_A_fn_class = fncls__41d; tmp5 = fncls__41d } else { tmp5 = fncls__41 }; arg_45 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_43 == nil { arg_50 = ifn_44.Invoke_O__O(arg_45) } else { arg_50 = linked_43.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O__O(root_42, arg_45) }; if linked_47 == nil { arg_54 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { arg_54 = linked_47.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_51, arg_54) } }
//line :19:1
		return nil }(); var root_55 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; if linked_56 == nil { ifn_57.Invoke__O() } else { linked_56.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_55) }
//line :17:1
		if tmp6 != nil { panic(tmp6) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :17:1*/ tmp7 != nil { panic(tmp7) }; return tmp1 }


func A_arbace_j2g_world_read_forms_fn__78000013_A_New() *A_arbace_j2g_world_read_forms_fn__78000013_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_forms_fn__78000013_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_j2g_world_read_forms_fn__78000013_A) Ctor() {}
//line :20:1
func (t *A_arbace_j2g_world_read_forms_fn__78000013_A) Invoke_O_O__O(self, p1__78000012_SHARP___1 any) any { var root_30 any = A_arbace_j2g_world_A_const_19.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = p1__78000012_SHARP___1; var arg_34 any = A_arbace_j2g_world_A_const_20; if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } }
//line :20:1
func A_arbace_j2g_world_read_forms_fn__78000015_A_New_O(p0 any) *A_arbace_j2g_world_read_forms_fn__78000015_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_forms_fn__78000015_A{}; t.Ctor_O(p0); return t }
//line :20:1
func (t *A_arbace_j2g_world_read_forms_fn__78000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :20:1
func (t *A_arbace_j2g_world_read_forms_fn__78000015_A) Invoke_O__O(self any) any { var root_36 any = A_arbace_j2g_world_A_const_22.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_j2g_world_A_const_23; var arg_40 any = t.F_r; if linked_37 == nil { return ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { return linked_37.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_36, arg_39, arg_40) } }

func A_arbace_j2g_world_first_form_A_New() *A_arbace_j2g_world_first_form_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_first_form_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_j2g_world_first_form_A) Ctor() {}
//line :22:1
func (t *A_arbace_j2g_world_first_form_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_j2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var root_84 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_world_A_const_27, jrt.Boolean_FALSE.Ref()); if linked_85 == nil { ifn_86.Invoke_O__O(arg_87) } else { linked_85.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_84, arg_87) }; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :22:1
		{ var x__7 any; var root_71 any = A_arbace_j2g_world_A_const_22.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_73 lang.IFn




			if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_j2g_world_A_const_28; var arg_75 any = r__2; if linked_72 == nil { x__7 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { x__7 = linked_72.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }
			if lang.Util_Equiv_O_O__Z_NoInit(x__7, A_arbace_j2g_world_A_const_20) { tmp1 = nil } else { tmp1 = x__7 } }
//line :26:1
		return nil }(); var root_76 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; if linked_77 == nil { ifn_78.Invoke__O() } else { linked_77.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_76) }
//line :22:1
		if tmp2 != nil { panic(tmp2) } }; return nil }();


	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :22:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }







func A_arbace_j2g_world_class_form_QMARK__A_New() *A_arbace_j2g_world_class_form_QMARK__A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_form_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_j2g_world_class_form_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_j2g_world_class_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any; var root_88 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = f__0; if linked_89 == nil { and__1927000168__auto____2 = ifn_90.Invoke_O__O(arg_91) } else { and__1927000168__auto____2 = linked_89.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_88, arg_91) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_96 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var root_92 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = f__0; if linked_93 == nil { arg_99 = ifn_94.Invoke_O__O(arg_95) } else { arg_99 = linked_93.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_92, arg_95) }; if linked_97 == nil { and__1927000168__auto____3 = ifn_98.Invoke_O__O(arg_99) } else { and__1927000168__auto____3 = linked_97.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any; var root_104 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any; var root_100 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = f__0; if linked_101 == nil { arg_107 = ifn_102.Invoke_O__O(arg_103) } else { arg_107 = linked_101.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_100, arg_103) }; if linked_105 == nil { tmp1 = ifn_106.Invoke_O__O(arg_107) } else { tmp1 = linked_105.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_104, arg_107) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_12, tmp1)).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_world_class_forms_A_New() *A_arbace_j2g_world_class_forms_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_j2g_world_class_forms_A) Ctor() {}
//line :32:1
func (t *A_arbace_j2g_world_class_forms_A) Invoke_O_O__O(self, forms__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_New(); var tmp2 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_fn_class; if
											fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_fn_class = fncls__217d; tmp2 = fncls__217d } else { tmp2 = fncls__217 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0) }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_New() *A_arbace_j2g_world_class_forms_iter__78000020__78000026_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_A) Ctor() {}
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_A) Invoke_O_O__O(self, s__78000021__1 any) any { var tmp1 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_New_O_O(s__78000021__1, self); var tmp2 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_fn_class = fncls__216d; tmp2 = fncls__216d } else { tmp2 = fncls__216 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A) Ctor_O_O(c__s__78000021, c__iter__78000020 any) { t.F_s__78000021 = c__s__78000021; t.F_iter__78000020 = c__iter__78000020 }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A) Invoke_O__O(self any) any { { var s__78000021__1 any; var t_ any = t.F_s__78000021; t.F_s__78000021 = nil; s__78000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_108 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = s__78000021__1; if linked_109 == nil { temp__1927000414__auto____2 = ifn_110.Invoke_O__O(arg_111) } else { temp__1927000414__auto____2 = linked_109.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_108, arg_111) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_112 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = xs__1927001018__auto____3; if linked_113 == nil { f__4 = ifn_114.Invoke_O__O(arg_115) } else { f__4 = linked_113.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_112, arg_115) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_New(); var tmp2 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_fn_class = fncls__186d; tmp2 = fncls__186d } else { tmp2 = fncls__186 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_199 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var tmp5 any; var and__1927000168__auto____6 any; var root_187 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_189 lang.IFn
														if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = f__4; if linked_188 == nil { and__1927000168__auto____6 = ifn_189.Invoke_O__O(arg_190) } else { and__1927000168__auto____6 = linked_188.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_187, arg_190) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp6 any = A_arbace_j2g_world_A_const_44; var tmp7 any; var root_191 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = f__4; if linked_192 == nil { tmp7 = ifn_193.Invoke_O__O(arg_194) } else { tmp7 = linked_192.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_191, arg_194) }; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7)).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { var root_195 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = f__4; if linked_196 == nil { tmp4 = ifn_197.Invoke_O__O(arg_198) } else { tmp4 = linked_196.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_195, arg_198) } } else { tmp4 = lang.Tuple_Create_O__IPersistentVector(f__4) }
//line :33:1
	arg_202 = tmp3.Invoke_O__O(tmp4); if linked_200 == nil { fs__1927001036__auto____6 = ifn_201.Invoke_O__O(arg_202) } else { fs__1927001036__auto____6 = linked_200.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_199, arg_202) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_207 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = fs__1927001036__auto____6; var arg_211 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000020); var tmp9 any; var root_203 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = s__78000021__1; if linked_204 == nil { tmp9 = ifn_205.Invoke_O__O(arg_206) } else { tmp9 = linked_204.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_203, arg_206) }; arg_211 = tmp8.Invoke_O__O(tmp9); if linked_208 == nil { return ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { return linked_208.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) } } else { var tmp10 any; var root_212 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = s__78000021__1; if linked_213 == nil { tmp10 = ifn_214.Invoke_O__O(arg_215) } else { tmp10 = linked_213.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_212, arg_215) }; s__78000021__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_New() *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A) Ctor() {}
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A) Invoke_O_O__O(self, s__78000023__1 any) any { var tmp1 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_New_O_O(s__78000023__1, self); var tmp2 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_fn_class; if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_fn_class = fncls__185d; tmp2 = fncls__185d } else { tmp2 = fncls__185 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A) Ctor_O_O(c__s__78000023, c__iter__78000022 any) { t.F_s__78000023 = c__s__78000023; t.F_iter__78000022 = c__iter__78000022 }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A) Invoke_O__O(self any) any { { var s__78000023__1 any; var t_ any = t.F_s__78000023; t.F_s__78000023 = nil; s__78000023__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_116 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = s__78000023__1; if linked_117 == nil { temp__1927000414__auto____2 = ifn_118.Invoke_O__O(arg_119) } else { temp__1927000414__auto____2 = linked_117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000023__3 any = temp__1927000414__auto____2; var tmp1 any; var root_120 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__78000023__3; if linked_121 == nil { tmp1 = ifn_122.Invoke_O__O(arg_123) } else { tmp1 = linked_121.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_120, arg_123) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_124 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__78000023__3; if linked_125 == nil { c__1927001037__auto____4 = ifn_126.Invoke_O__O(arg_127) } else { c__1927001037__auto____4 = linked_125.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_124, arg_127) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000025__6 any; var root_128 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_129 == nil { b__78000025__6 = ifn_130.Invoke_O__O(arg_131) } else { b__78000025__6 = linked_129.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_128, arg_131) }; var tmp2 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_New_O_I_O(b__78000025__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_150 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var root_142 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = b__78000025__6; if linked_143 == nil { arg_153 = ifn_144.Invoke_O__O(arg_145) } else { arg_153 = linked_143.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_142, arg_145) }; var arg_154 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000022); var tmp5 any; var root_146 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = s__78000023__3; if linked_147 == nil { tmp5 = ifn_148.Invoke_O__O(arg_149) } else { tmp5 = linked_147.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_146, arg_149) }; arg_154 = tmp4.Invoke_O__O(tmp5); if linked_151 == nil { return ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { return linked_151.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_150, arg_153, arg_154) } } else { var root_159 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_155 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = b__78000025__6; if linked_156 == nil { arg_162 = ifn_157.Invoke_O__O(arg_158) } else { arg_162 = linked_156.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_155, arg_158) }; var arg_163 any; if linked_160 == nil { return ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { return linked_160.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) } } } else { var f__4 any; var root_164 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = s__78000023__3; if linked_165 == nil { f__4 = ifn_166.Invoke_O__O(arg_167) } else { f__4 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; var tmp6 any; var root_168 any = A_arbace_j2g_world_A_const_37.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_j2g_world_class_form_QMARK__A_fn_class); var ifn_170 lang.IFn

	if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = f__4; if linked_169 == nil { tmp6 = ifn_170.Invoke_O__O(arg_171) } else { tmp6 = linked_169.(*A_arbace_j2g_world_class_form_QMARK__A).Invoke_O_O__O(root_168, arg_171) }
//line :33:1
	if jrt.J2g_Truth(tmp6) { var root_176 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = f__4; var arg_180 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000022); var tmp8 any; var root_172 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = s__78000023__3; if linked_173 == nil { tmp8 = ifn_174.Invoke_O__O(arg_175) } else { tmp8 = linked_173.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_172, arg_175) }; arg_180 = tmp7.Invoke_O__O(tmp8); if linked_177 == nil { return ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { return linked_177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) } } else { var tmp9 any; var root_181 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = s__78000023__3; if linked_182 == nil { tmp9 = ifn_183.Invoke_O__O(arg_184) } else { tmp9 = linked_182.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_181, arg_184) }; s__78000023__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A) Ctor_O_I_O(c__b__78000025 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000025 = c__b__78000025; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A) Invoke_O__O(self any) any { { var i__78000024__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000024__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000024__1)); var tmp2 any; var root_132 any = A_arbace_j2g_world_A_const_37.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_j2g_world_class_form_QMARK__A_fn_class); var ifn_134 lang.IFn

	if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__2; if linked_133 == nil { tmp2 = ifn_134.Invoke_O__O(arg_135) } else { tmp2 = linked_133.(*A_arbace_j2g_world_class_form_QMARK__A).Invoke_O_O__O(root_132, arg_135) }
//line :33:1
	if jrt.J2g_Truth(tmp2) { var root_136 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t.F_b__78000025; var arg_140 any = f__2; if linked_137 == nil { ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { linked_137.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; i__78000024__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000024__1); continue L1 } else { i__78000024__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000024__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_world_continued_QMARK__A_New() *A_arbace_j2g_world_continued_QMARK__A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_continued_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_j2g_world_continued_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_j2g_world_continued_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any; var root_218 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = f__0; if linked_219 == nil { and__1927000168__auto____2 = ifn_220.Invoke_O__O(arg_221) } else { and__1927000168__auto____2 = linked_219.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_218, arg_221) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_j2g_world_A_const_46; var tmp2 any; var root_222 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = f__0; if linked_223 == nil { tmp2 = ifn_224.Invoke_O__O(arg_225) } else { tmp2 = linked_223.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_222, arg_225) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_world_join_continued_A_New() *A_arbace_j2g_world_join_continued_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_j2g_world_join_continued_A) Ctor() {}
//line :40:1
func (t *A_arbace_j2g_world_join_continued_A) Invoke_O_O__O(self, ps__0 any) any { var conts__2 any; var root_358 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_360 lang.IFn; if








	linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_362 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_New(); var tmp2 *jrt.Class; var fncls__357 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_fn_class; if fncls__357 == nil { var fncls__357d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_fn_class = fncls__357d; tmp2 = fncls__357d } else { tmp2 = fncls__357 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_362 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ps__0); if linked_359 == nil { conts__2 = ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { conts__2 = linked_359.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) }; var tmp3 any; var root_363 any =

	A_arbace_j2g_world_A_const_55.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = conts__2; if linked_364 == nil { tmp3 = ifn_365.Invoke_O__O(arg_366) } else { tmp3 = linked_364.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_363, arg_366) }; if jrt.J2g_Truth(tmp3) { return ps__0 } else { var claimed__3 any; var root_367 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_369 lang.IFn

		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_368 == nil { claimed__3 = ifn_369.Invoke_O__O(arg_370) } else { claimed__3 = linked_368.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_367, arg_370) }
//line :51:1
		var ps__4 any; var root_728 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_730 lang.IFn


		if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any; var tmp4 any = A_arbace_j2g_world_join_continued_fn__78000057_A_New_O_O(claimed__3, conts__2); var tmp5 *jrt.Class; var fncls__727 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_A_fn_class; if fncls__727 == nil { var fncls__727d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_world_join_continued_fn__78000057_A_fn_class = fncls__727d; tmp5 = fncls__727d } else { tmp5 = fncls__727 }; arg_731 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_732 any = ps__0; if linked_729 == nil { ps__4 = ifn_730.Invoke_O_O__O(arg_731, arg_732) } else { ps__4 = linked_729.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_728, arg_731, arg_732) }
//line :51:1
		var temp__1927000414__auto____5 any; var root_746 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_748 lang.IFn

















		if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any; var root_741 any = A_arbace_j2g_world_A_const_77.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any; var root_733 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = claimed__3; if linked_734 == nil { arg_744 = ifn_735.Invoke_O__O(arg_736) } else { arg_744 = linked_734.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_733, arg_736) }; var arg_745 any; var root_737 any = A_arbace_j2g_world_A_const_78.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = conts__2; if linked_738 == nil { arg_745 = ifn_739.Invoke_O__O(arg_740) } else { arg_745 = linked_738.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_737, arg_740) }; if linked_742 == nil { arg_749 = ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { arg_749 = linked_742.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_741, arg_744, arg_745) }; if linked_747 == nil { temp__1927000414__auto____5 = ifn_748.Invoke_O__O(arg_749) } else { temp__1927000414__auto____5 = linked_747.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_746, arg_749) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var u__6 any = temp__1927000414__auto____5; var tmp6 any; var root_758 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_760 lang.IFn
			if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_79.GetRawRoot__O()); var tmp9 any; var root_750 any = A_arbace_j2g_world_A_const_80.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = u__6; if linked_751 == nil { tmp9 = ifn_752.Invoke_O__O(arg_753) } else { tmp9 = linked_751.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_750, arg_753) }; arg_761 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))).Ref(); var arg_762 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_759 == nil { tmp6 = ifn_760.Invoke_O_O__O(arg_761, arg_762) } else { tmp6 = linked_759.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_758, arg_761, arg_762) }
//line :69:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) }
//line :51:1
		return ps__4 } }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_New() *A_arbace_j2g_world_join_continued_iter__78000039__78000045_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_A) Invoke_O_O__O(self, s__78000040__1 any) any { var tmp1 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_New_O_O(s__78000040__1, self); var tmp2 *jrt.Class; var fncls__356 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_fn_class; if fncls__356 == nil { var fncls__356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_fn_class = fncls__356d; tmp2 = fncls__356d } else { tmp2 = fncls__356 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A) Ctor_O_O(c__s__78000040, c__iter__78000039 any) { t.F_s__78000040 = c__s__78000040; t.F_iter__78000039 = c__iter__78000039 }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A) Invoke_O__O(self any) any { { var s__78000040__1 any; var t_ any = t.F_s__78000040; t.F_s__78000040 = nil; s__78000040__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_226 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = s__78000040__1; if linked_227 == nil { temp__1927000414__auto____2 = ifn_228.Invoke_O__O(arg_229) } else { temp__1927000414__auto____2 = linked_227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__78000047__4 any; var root_230 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = xs__1927001018__auto____3; if linked_231 == nil { map__78000047__4 = ifn_232.Invoke_O__O(arg_233) } else { map__78000047__4 = linked_231.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_230, arg_233) }; var map__78000047__5 any; if lang.ISeq_InstanceOf(map__78000047__4) { var tmp1 any; var root_234 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = map__78000047__4; if linked_235 == nil { tmp1 = ifn_236.Invoke_O__O(arg_237) } else { tmp1 = linked_235.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_238 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = map__78000047__4; if linked_239 == nil { tmp2 = ifn_240.Invoke_O__O(arg_241) } else { tmp2 = linked_239.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_238, arg_241) }; map__78000047__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_242 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = map__78000047__4; if linked_243 == nil { tmp3 = ifn_244.Invoke_O__O(arg_245) } else { tmp3 = linked_243.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_242, arg_245) }; if jrt.J2g_Truth(tmp3) { var root_246 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = map__78000047__4; if linked_247 == nil { map__78000047__5 = ifn_248.Invoke_O__O(arg_249) } else { map__78000047__5 = linked_247.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_246, arg_249) } } else { map__78000047__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000047__5 = map__78000047__4 }; var forms__6 any = lang.RT_Get_O_O__O_NoInit(map__78000047__5, A_arbace_j2g_world_A_const_50); var iterys__1927001035__auto____7 any; var tmp4 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_New(); var tmp5 *jrt.Class; var fncls__338 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_fn_class; if fncls__338 == nil { var fncls__338d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_fn_class = fncls__338d; tmp5 = fncls__338d } else { tmp5 = fncls__338 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____8 any; var root_339 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(forms__6); if linked_340 == nil { fs__1927001036__auto____8 = ifn_341.Invoke_O__O(arg_342) } else { fs__1927001036__auto____8 = linked_340.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_339, arg_342) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_347 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = fs__1927001036__auto____8; var arg_351 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__78000039); var tmp7 any; var root_343 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = s__78000040__1; if linked_344 == nil { tmp7 = ifn_345.Invoke_O__O(arg_346) } else { tmp7 = linked_344.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_343, arg_346) }; arg_351 = tmp6.Invoke_O__O(tmp7); if linked_348 == nil { return ifn_349.Invoke_O_O__O(arg_350, arg_351) } else { return linked_348.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_347, arg_350, arg_351) } } else { var tmp8 any; var root_352 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = s__78000040__1; if linked_353 == nil { tmp8 = ifn_354.Invoke_O__O(arg_355) } else { tmp8 = linked_353.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_352, arg_355) }; s__78000040__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_New() *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A) Invoke_O_O__O(self, s__78000042__1 any) any { var tmp1 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_New_O_O(s__78000042__1, self); var tmp2 *jrt.Class; var fncls__337 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_fn_class; if fncls__337 == nil { var fncls__337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_fn_class = fncls__337d; tmp2 = fncls__337d } else { tmp2 = fncls__337 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A{}; t.Ctor_O_O(p0, p1); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A) Ctor_O_O(c__s__78000042, c__iter__78000041 any) { t.F_s__78000042 = c__s__78000042; t.F_iter__78000041 = c__iter__78000041 }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A) Invoke_O__O(self any) any { { var s__78000042__1 any; var t_ any = t.F_s__78000042; t.F_s__78000042 = nil; s__78000042__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_250 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = s__78000042__1; if linked_251 == nil { temp__1927000414__auto____2 = ifn_252.Invoke_O__O(arg_253) } else { temp__1927000414__auto____2 = linked_251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000042__3 any = temp__1927000414__auto____2; var tmp1 any; var root_254 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = s__78000042__3; if linked_255 == nil { tmp1 = ifn_256.Invoke_O__O(arg_257) } else { tmp1 = linked_255.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_258 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = s__78000042__3; if linked_259 == nil { c__1927001037__auto____4 = ifn_260.Invoke_O__O(arg_261) } else { c__1927001037__auto____4 = linked_259.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_258, arg_261) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000044__6 any; var root_262 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_263 == nil { b__78000044__6 = ifn_264.Invoke_O__O(arg_265) } else { b__78000044__6 = linked_263.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_262, arg_265) }; var tmp2 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_New_I_O_O(size__1927001038__auto____5, b__78000044__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__284 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_fn_class; if fncls__284 == nil { var fncls__284d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_fn_class = fncls__284d; tmp3 = fncls__284d } else { tmp3 = fncls__284 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_293 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any; var root_285 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = b__78000044__6; if linked_286 == nil { arg_296 = ifn_287.Invoke_O__O(arg_288) } else { arg_296 = linked_286.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_285, arg_288) }; var arg_297 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000041); var tmp5 any; var root_289 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = s__78000042__3; if linked_290 == nil { tmp5 = ifn_291.Invoke_O__O(arg_292) } else { tmp5 = linked_290.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_289, arg_292) }; arg_297 = tmp4.Invoke_O__O(tmp5); if linked_294 == nil { return ifn_295.Invoke_O_O__O(arg_296, arg_297) } else { return linked_294.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_293, arg_296, arg_297) } } else { var root_302 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var root_298 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = b__78000044__6; if linked_299 == nil { arg_305 = ifn_300.Invoke_O__O(arg_301) } else { arg_305 = linked_299.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_298, arg_301) }; var arg_306 any; if linked_303 == nil { return ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { return linked_303.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) } } } else { var f__4 any; var root_307 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = s__78000042__3; if linked_308 == nil { f__4 = ifn_309.Invoke_O__O(arg_310) } else { f__4 = linked_308.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_307, arg_310) }; var tmp6 any; var root_311 any = A_arbace_j2g_world_A_const_51.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, A_arbace_j2g_world_continued_QMARK__A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = f__4; if linked_312 == nil { tmp6 = ifn_313.Invoke_O__O(arg_314) } else { tmp6 = linked_312.(*A_arbace_j2g_world_continued_QMARK__A).Invoke_O_O__O(root_311, arg_314) }; if jrt.J2g_Truth(tmp6) { var root_328 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any; var tmp7 any; var root_320 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_322 lang.IFn
																			if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = lang.RT_Nth_O_I__O_NoInit(f__4, lang.RT_IntCast_J__I_NoInit(1)); if linked_321 == nil { tmp7 = ifn_322.Invoke_O__O(arg_323) } else { tmp7 = linked_321.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_320, arg_323) }
//line :49:1
	var tmp8 any = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.RT_Nth_O_I__O_NoInit(f__4, lang.RT_IntCast_J__I_NoInit(2))); var tmp9 any; var root_315 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_317 lang.IFn
	if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = A_arbace_j2g_world_A_const_53; var arg_319 any = f__4; if linked_316 == nil { tmp9 = ifn_317.Invoke_O_O__O(arg_318, arg_319) } else { tmp9 = linked_316.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_315, arg_318, arg_319) }
//line :49:1
	arg_331 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); var arg_332 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__78000041); var tmp11 any; var root_324 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = s__78000042__3; if linked_325 == nil { tmp11 = ifn_326.Invoke_O__O(arg_327) } else { tmp11 = linked_325.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_324, arg_327) }; arg_332 = tmp10.Invoke_O__O(tmp11); if linked_329 == nil { return ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { return linked_329.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) } } else { var tmp12 any; var root_333 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = s__78000042__3; if linked_334 == nil { tmp12 = ifn_335.Invoke_O__O(arg_336) } else { tmp12 = linked_334.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_333, arg_336) }; s__78000042__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__78000044, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__78000044 = c__b__78000044; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A) Invoke_O__O(self any) any { { var i__78000043__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000043__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000043__1)); var tmp2 any; var root_266 any = A_arbace_j2g_world_A_const_51.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, A_arbace_j2g_world_continued_QMARK__A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = f__2; if linked_267 == nil { tmp2 = ifn_268.Invoke_O__O(arg_269) } else { tmp2 = linked_267.(*A_arbace_j2g_world_continued_QMARK__A).Invoke_O_O__O(root_266, arg_269) }; if jrt.J2g_Truth(tmp2) { var root_279 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = t.F_b__78000044; var arg_283 any; var tmp3 any; var root_275 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_277 lang.IFn
																					if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = lang.RT_Nth_O_I__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_276 == nil { tmp3 = ifn_277.Invoke_O__O(arg_278) } else { tmp3 = linked_276.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_275, arg_278) }
//line :49:1
	var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.RT_Nth_O_I__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(2))); var tmp5 any; var root_270 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_272 lang.IFn
	if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = A_arbace_j2g_world_A_const_53; var arg_274 any = f__2; if linked_271 == nil { tmp5 = ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { tmp5 = linked_271.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) }
//line :49:1
	arg_283 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5); if linked_280 == nil { ifn_281.Invoke_O_O__O(arg_282, arg_283) } else { linked_280.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_279, arg_282, arg_283) }; i__78000043__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000043__1); continue L1 } else { i__78000043__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000043__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_world_join_continued_fn__78000057_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_fn__78000057_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :54:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :54:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_A) Invoke_O_O__O(self, p__1 any) any {
	var root_721 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = p__1; var arg_725 any = A_arbace_j2g_world_A_const_50; var arg_726 any; var tmp1 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_New_O_O(t.F_claimed, t.F_conts); var tmp2 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_fn_class
	if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_fn_class = fncls__720d; tmp2 = fncls__720d } else { tmp2 = fncls__720 }; arg_726 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :55:1
	if linked_722 == nil { return ifn_723.Invoke_O_O_O__O(arg_724, arg_725, arg_726) } else { return linked_722.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_721, arg_724, arg_725, arg_726) } }
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A{}; t.Ctor_O_O(p0, p1); return t }
//line :56:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :56:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A) Invoke_O_O__O(self, forms__1 any) any {
	var root_716 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_New_O_O(t.F_claimed, t.F_conts); var tmp2 *jrt.Class; var fncls__715 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_fn_class; if fncls__715 == nil { var fncls__715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_fn_class = fncls__715d; tmp2 = fncls__715d } else { tmp2 = fncls__715 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_719 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__1); if linked_717 == nil { return ifn_718.Invoke_O__O(arg_719) } else { return linked_717.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_716, arg_719) } }
//line :57:1
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A) Invoke_O_O__O(self, s__78000060__1 any) any { var tmp1 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_New_O_O_O_O(s__78000060__1, t.F_claimed, self, t.F_conts); var tmp2 *jrt.Class; var fncls__714 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_fn_class; if fncls__714 == nil { var fncls__714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_fn_class = fncls__714d; tmp2 = fncls__714d } else { tmp2 = fncls__714 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :57:1
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A) Ctor_O_O_O_O(c__s__78000060, c__claimed, c__iter__78000059, c__conts any) { t.F_s__78000060 = c__s__78000060; t.F_claimed = c__claimed; t.F_iter__78000059 = c__iter__78000059; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A) Invoke_O__O(self any) any { { var s__78000060__1 any; var t_ any = t.F_s__78000060; t.F_s__78000060 = nil; s__78000060__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_371 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = s__78000060__1; if linked_372 == nil { temp__1927000414__auto____2 = ifn_373.Invoke_O__O(arg_374) } else { temp__1927000414__auto____2 = linked_372.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000060__3 any = temp__1927000414__auto____2; var tmp1 any; var root_375 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = s__78000060__3; if linked_376 == nil { tmp1 = ifn_377.Invoke_O__O(arg_378) } else { tmp1 = linked_376.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_375, arg_378) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_379 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = s__78000060__3; if linked_380 == nil { c__1927001037__auto____4 = ifn_381.Invoke_O__O(arg_382) } else { c__1927001037__auto____4 = linked_380.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_379, arg_382) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000062__6 any; var root_383 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_384 == nil { b__78000062__6 = ifn_385.Invoke_O__O(arg_386) } else { b__78000062__6 = linked_384.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_383, arg_386) }; var tmp2 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_New_O_O_I_O_O(t.F_claimed, b__78000062__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_conts); var tmp3 *jrt.Class; var fncls__533 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_fn_class; if fncls__533 == nil { var fncls__533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_fn_class = fncls__533d; tmp3 = fncls__533d } else { tmp3 = fncls__533 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_542 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any; var root_534 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = b__78000062__6; if linked_535 == nil { arg_545 = ifn_536.Invoke_O__O(arg_537) } else { arg_545 = linked_535.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_534, arg_537) }; var arg_546 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000059); var tmp5 any; var root_538 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = s__78000060__3; if linked_539 == nil { tmp5 = ifn_540.Invoke_O__O(arg_541) } else { tmp5 = linked_539.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_538, arg_541) }; arg_546 = tmp4.Invoke_O__O(tmp5); if linked_543 == nil { return ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { return linked_543.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) } } else { var root_551 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any; var root_547 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = b__78000062__6; if linked_548 == nil { arg_554 = ifn_549.Invoke_O__O(arg_550) } else { arg_554 = linked_548.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_547, arg_550) }; var arg_555 any; if linked_552 == nil { return ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { return linked_552.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) } } } else { var f__4 any; var root_556 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = s__78000060__3; if linked_557 == nil { f__4 = ifn_558.Invoke_O__O(arg_559) } else { f__4 = linked_557.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_556, arg_559) }; var tmp6 any; var root_564 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any; var root_560 any = A_arbace_j2g_world_A_const_51.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, A_arbace_j2g_world_continued_QMARK__A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = f__4; if linked_561 == nil { arg_567 = ifn_562.Invoke_O__O(arg_563) } else { arg_567 = linked_561.(*A_arbace_j2g_world_continued_QMARK__A).Invoke_O_O__O(root_560, arg_563) }; if linked_565 == nil { tmp6 = ifn_566.Invoke_O__O(arg_567) } else { tmp6 = linked_565.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_564, arg_567) }; if jrt.J2g_Truth(tmp6) { var root_705 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any; var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any; var root_568 any = A_arbace_j2g_world_A_const_37.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_j2g_world_class_form_QMARK__A_fn_class); var ifn_570 lang.IFn
																	if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = f__4; if linked_569 == nil { and__1927000168__auto____5 = ifn_570.Invoke_O__O(arg_571) } else { and__1927000168__auto____5 = linked_569.(*A_arbace_j2g_world_class_form_QMARK__A).Invoke_O_O__O(root_568, arg_571) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 *lang.Keyword = A_arbace_j2g_world_A_const_61; temp__1927000408__auto____5 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__4)) } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5; var c__7 any; var root_576 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_578 lang.IFn
																		if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any; var root_572 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = f__4; if linked_573 == nil { arg_579 = ifn_574.Invoke_O__O(arg_575) } else { arg_579 = linked_573.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_572, arg_575) }; if linked_577 == nil { c__7 = ifn_578.Invoke_O__O(arg_579) } else { c__7 = linked_577.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_576, arg_579) }
//line :58:1
		var ks__8 any; var root_593 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_595 lang.IFn

		if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any; var tmp8 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_New_O(c__7); var tmp9 *jrt.Class; var fncls__585 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_fn_class; if fncls__585 == nil { var fncls__585d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_fn_class = fncls__585d; tmp9 = fncls__585d } else { tmp9 = fncls__585 }; arg_596 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_597 any; var root_588 any = A_arbace_j2g_world_A_const_65.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = A_arbace_j2g_world_A_const_66; var arg_592 any; var na_586 any = n__6; if jrt.Long_InstanceOf(na_586) { var n0_587 int64 = jrt.NN(jrt.Long_Cast(na_586)).LongValue__J(); if n0_587 == 9223372036854775807 { arg_592 = lang.Numbers_Inc_O__Number_NoInit(na_586) } else { arg_592 = jrt.Long_ValueOf_J__Long_NoInit(n0_587 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_586) { var n0_587_2 float64 = jrt.NN(jrt.Double_Cast(na_586)).DoubleValue__D(); arg_592 = jrt.Double_ValueOf_D__Double_NoInit(n0_587_2 + 1.0).Ref() } else { arg_592 = lang.Numbers_Inc_O__Number_NoInit(na_586) } }; if linked_589 == nil { arg_597 = ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { arg_597 = linked_589.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }; if linked_594 == nil { ks__8 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { ks__8 = linked_594.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }
//line :58:1
		var seq_78000075__9 any; var root_627 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_629 lang.IFn


		if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = ks__8; if linked_628 == nil { seq_78000075__9 = ifn_629.Invoke_O__O(arg_630) } else { seq_78000075__9 = linked_628.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_627, arg_630) }
//line :58:1
		var chunk_78000076__10 any; var count_78000077__11 int64 = 0; var i_78000078__12 int64 = 0; L2: for {


			if lang.Numbers_Lt_J_J__Z_NoInit(i_78000078__12, count_78000077__11) { var k__13 any = lang.Indexed_Cast(chunk_78000076__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000078__12)); var tmp10 any; var root_636 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any; var root_631 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = t.F_conts; var arg_635 any = k__13; if linked_632 == nil { arg_639 = ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { arg_639 = linked_632.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_631, arg_634, arg_635) }; if linked_637 == nil { tmp10 = ifn_638.Invoke_O__O(arg_639) } else { tmp10 = linked_637.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_636, arg_639) }; if jrt.J2g_Truth(tmp10) { var tmp11 any; var root_675 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_677 lang.IFn
				if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any; var tmp12 *jrt.RefArray = jrt.ConstRefArray("[0,7,s5:j2g: ns7:: part ns4: of ns23: missing (c2j/continue)", []*jrt.Class{jrt.String_class}); var tmp13 any; var root_671 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = k__13; if linked_672 == nil { tmp13 = ifn_673.Invoke_O__O(arg_674) } else { tmp13 = linked_672.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_671, arg_674) }; arg_678 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, c__7, nil, tmp13, nil, n__6, nil)).Ref(); var arg_679 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_76, c__7)); if linked_676 == nil { tmp11 = ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { tmp11 = linked_676.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) }
//line :61:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp11))); seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = seq_78000075__9, chunk_78000076__10, count_78000077__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000078__12); continue L2 } else { seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = seq_78000075__9, chunk_78000076__10, count_78000077__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000078__12); continue L2 } } else { var temp__1927000414__auto____13 any; var root_640 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = seq_78000075__9; if linked_641 == nil { temp__1927000414__auto____13 = ifn_642.Invoke_O__O(arg_643) } else { temp__1927000414__auto____13 = linked_641.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_640, arg_643) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_78000075__14 any = temp__1927000414__auto____13; var tmp14 any; var root_644 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = seq_78000075__14; if linked_645 == nil { tmp14 = ifn_646.Invoke_O__O(arg_647) } else { tmp14 = linked_645.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_644, arg_647) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____15 any; var root_648 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = seq_78000075__14; if linked_649 == nil { c__1927000678__auto____15 = ifn_650.Invoke_O__O(arg_651) } else { c__1927000678__auto____15 = linked_649.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_648, arg_651) }; var tmp15 any; var root_680 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = seq_78000075__14; if linked_681 == nil { tmp15 = ifn_682.Invoke_O__O(arg_683) } else { tmp15 = linked_681.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_680, arg_683) }; seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = tmp15, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var k__15 any; var root_652 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = seq_78000075__14; if linked_653 == nil { k__15 = ifn_654.Invoke_O__O(arg_655) } else { k__15 = linked_653.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_652, arg_655) }; var tmp16 any; var root_661 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any; var root_656 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = t.F_conts; var arg_660 any = k__15; if linked_657 == nil { arg_664 = ifn_658.Invoke_O_O__O(arg_659, arg_660) } else { arg_664 = linked_657.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_656, arg_659, arg_660) }; if linked_662 == nil { tmp16 = ifn_663.Invoke_O__O(arg_664) } else { tmp16 = linked_662.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_661, arg_664) }; if jrt.J2g_Truth(tmp16) { var tmp17 any; var root_688 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_690 lang.IFn
					if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var tmp18 *jrt.RefArray = jrt.ConstRefArray("[0,7,s5:j2g: ns7:: part ns4: of ns23: missing (c2j/continue)", []*jrt.Class{jrt.String_class}); var tmp19 any; var root_684 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = k__15; if linked_685 == nil { tmp19 = ifn_686.Invoke_O__O(arg_687) } else { tmp19 = linked_685.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_684, arg_687) }; arg_691 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, c__7, nil, tmp19, nil, n__6, nil)).Ref(); var arg_692 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_76, c__7)); if linked_689 == nil { tmp17 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { tmp17 = linked_689.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }
//line :61:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))); var tmp20 any; var root_693 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = seq_78000075__14; if linked_694 == nil { tmp20 = ifn_695.Invoke_O__O(arg_696) } else { tmp20 = linked_694.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_693, arg_696) }; seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = tmp20, nil, 0, 0; continue L2 } else { var tmp21 any; var root_697 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = seq_78000075__14; if linked_698 == nil { tmp21 = ifn_699.Invoke_O__O(arg_700) } else { tmp21 = linked_698.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_697, arg_700) }; seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = tmp21, nil, 0, 0; continue L2 } } } }
//line :58:1
			break L2
		}




		var root_665 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = t.F_claimed; var arg_669 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_670 any = ks__8; if linked_666 == nil { ifn_667.Invoke_O_O_O__O(arg_668, arg_669, arg_670) } else { linked_666.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_665, arg_668, arg_669, arg_670) }
		var root_622 any = A_arbace_j2g_world_A_const_67.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any; var root_608 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = A_arbace_j2g_world_A_const_69.GetRawRoot__O(); var arg_612 any; var root_603 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = f__4; var arg_607 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, ks__8); if linked_604 == nil { arg_612 = ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { arg_612 = linked_604.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) }; if linked_609 == nil { arg_625 = ifn_610.Invoke_O_O__O(arg_611, arg_612) } else { arg_625 = linked_609.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_608, arg_611, arg_612) }; var arg_626 any; var root_618 any = A_arbace_j2g_world_A_const_71.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_620 lang.IFn
		if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any; var root_613 any = A_arbace_j2g_world_A_const_72.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__4); var arg_617 any = A_arbace_j2g_world_A_const_61; if linked_614 == nil { arg_621 = ifn_615.Invoke_O_O__O(arg_616, arg_617) } else { arg_621 = linked_614.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_613, arg_616, arg_617) }; if linked_619 == nil { arg_626 = ifn_620.Invoke_O__O(arg_621) } else { arg_626 = linked_619.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_618, arg_621) }
//line :65:1
		if linked_623 == nil { arg_708 = ifn_624.Invoke_O_O__O(arg_625, arg_626) } else { arg_708 = linked_623.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_622, arg_625, arg_626) } } else {
//line :58:1
			arg_708 = f__4 }
//line :57:1
	var arg_709 any; var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__78000059); var tmp23 any; var root_701 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = s__78000060__3; if linked_702 == nil { tmp23 = ifn_703.Invoke_O__O(arg_704) } else { tmp23 = linked_702.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_701, arg_704) }; arg_709 = tmp22.Invoke_O__O(tmp23); if linked_706 == nil { return ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { return linked_706.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_705, arg_708, arg_709) } } else { var tmp24 any; var root_710 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = s__78000060__3; if linked_711 == nil { tmp24 = ifn_712.Invoke_O__O(arg_713) } else { tmp24 = linked_711.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_710, arg_713) }; s__78000060__1 = tmp24; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :57:1
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A) Ctor_O_O_I_O_O(c__claimed, c__b__78000062 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__conts any) { t.F_claimed = c__claimed; t.F_b__78000062 = c__b__78000062; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A) Invoke_O__O(self any) any { { var i__78000061__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000061__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000061__1)); var tmp2 any; var root_391 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any; var root_387 any = A_arbace_j2g_world_A_const_51.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, A_arbace_j2g_world_continued_QMARK__A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = f__2; if linked_388 == nil { arg_394 = ifn_389.Invoke_O__O(arg_390) } else { arg_394 = linked_388.(*A_arbace_j2g_world_continued_QMARK__A).Invoke_O_O__O(root_387, arg_390) }; if linked_392 == nil { tmp2 = ifn_393.Invoke_O__O(arg_394) } else { tmp2 = linked_392.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_391, arg_394) }; if jrt.J2g_Truth(tmp2) { var root_528 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = t.F_b__78000062; var arg_532 any; var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any; var root_395 any = A_arbace_j2g_world_A_const_37.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_j2g_world_class_form_QMARK__A_fn_class); var ifn_397 lang.IFn
																			if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = f__2; if linked_396 == nil { and__1927000168__auto____3 = ifn_397.Invoke_O__O(arg_398) } else { and__1927000168__auto____3 = linked_396.(*A_arbace_j2g_world_class_form_QMARK__A).Invoke_O_O__O(root_395, arg_398) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Keyword = A_arbace_j2g_world_A_const_61; temp__1927000408__auto____3 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__2)) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; var c__5 any; var root_403 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_405 lang.IFn
																				if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var root_399 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = f__2; if linked_400 == nil { arg_406 = ifn_401.Invoke_O__O(arg_402) } else { arg_406 = linked_400.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_399, arg_402) }; if linked_404 == nil { c__5 = ifn_405.Invoke_O__O(arg_406) } else { c__5 = linked_404.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_403, arg_406) }
//line :58:1
		var ks__6 any; var root_420 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_422 lang.IFn

		if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any; var tmp4 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_New_O(c__5); var tmp5 *jrt.Class; var fncls__412 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_fn_class; if fncls__412 == nil { var fncls__412d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_fn_class = fncls__412d; tmp5 = fncls__412d } else { tmp5 = fncls__412 }; arg_423 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_424 any; var root_415 any = A_arbace_j2g_world_A_const_65.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = A_arbace_j2g_world_A_const_66; var arg_419 any; var na_413 any = n__4; if jrt.Long_InstanceOf(na_413) { var n0_414 int64 = jrt.NN(jrt.Long_Cast(na_413)).LongValue__J(); if n0_414 == 9223372036854775807 { arg_419 = lang.Numbers_Inc_O__Number_NoInit(na_413) } else { arg_419 = jrt.Long_ValueOf_J__Long_NoInit(n0_414 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_413) { var n0_414_2 float64 = jrt.NN(jrt.Double_Cast(na_413)).DoubleValue__D(); arg_419 = jrt.Double_ValueOf_D__Double_NoInit(n0_414_2 + 1.0).Ref() } else { arg_419 = lang.Numbers_Inc_O__Number_NoInit(na_413) } }; if linked_416 == nil { arg_424 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { arg_424 = linked_416.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }; if linked_421 == nil { ks__6 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { ks__6 = linked_421.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }
//line :58:1
		var seq_78000068__7 any; var root_454 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn


		if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = ks__6; if linked_455 == nil { seq_78000068__7 = ifn_456.Invoke_O__O(arg_457) } else { seq_78000068__7 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }
//line :58:1
		var chunk_78000069__8 any; var count_78000070__9 int64 = 0; var i_78000071__10 int64 = 0; L2: for {


			if lang.Numbers_Lt_J_J__Z_NoInit(i_78000071__10, count_78000070__9) { var k__11 any = lang.Indexed_Cast(chunk_78000069__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000071__10)); var tmp6 any; var root_463 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any; var root_458 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = t.F_conts; var arg_462 any = k__11; if linked_459 == nil { arg_466 = ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { arg_466 = linked_459.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_458, arg_461, arg_462) }; if linked_464 == nil { tmp6 = ifn_465.Invoke_O__O(arg_466) } else { tmp6 = linked_464.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_463, arg_466) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_502 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_504 lang.IFn
				if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any; var tmp8 *jrt.RefArray = jrt.ConstRefArray("[0,7,s5:j2g: ns7:: part ns4: of ns23: missing (c2j/continue)", []*jrt.Class{jrt.String_class}); var tmp9 any; var root_498 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = k__11; if linked_499 == nil { tmp9 = ifn_500.Invoke_O__O(arg_501) } else { tmp9 = linked_499.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_498, arg_501) }; arg_505 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, c__5, nil, tmp9, nil, n__4, nil)).Ref(); var arg_506 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_76, c__5)); if linked_503 == nil { tmp7 = ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { tmp7 = linked_503.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) }
//line :61:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp7))); seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = seq_78000068__7, chunk_78000069__8, count_78000070__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000071__10); continue L2 } else { seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = seq_78000068__7, chunk_78000069__8, count_78000070__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000071__10); continue L2 } } else { var temp__1927000414__auto____11 any; var root_467 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = seq_78000068__7; if linked_468 == nil { temp__1927000414__auto____11 = ifn_469.Invoke_O__O(arg_470) } else { temp__1927000414__auto____11 = linked_468.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_78000068__12 any = temp__1927000414__auto____11; var tmp10 any; var root_471 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = seq_78000068__12; if linked_472 == nil { tmp10 = ifn_473.Invoke_O__O(arg_474) } else { tmp10 = linked_472.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_471, arg_474) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____13 any; var root_475 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = seq_78000068__12; if linked_476 == nil { c__1927000678__auto____13 = ifn_477.Invoke_O__O(arg_478) } else { c__1927000678__auto____13 = linked_476.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_475, arg_478) }; var tmp11 any; var root_507 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_78000068__12; if linked_508 == nil { tmp11 = ifn_509.Invoke_O__O(arg_510) } else { tmp11 = linked_508.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_507, arg_510) }; seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = tmp11, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var k__13 any; var root_479 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_78000068__12; if linked_480 == nil { k__13 = ifn_481.Invoke_O__O(arg_482) } else { k__13 = linked_480.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_479, arg_482) }; var tmp12 any; var root_488 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any; var root_483 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = t.F_conts; var arg_487 any = k__13; if linked_484 == nil { arg_491 = ifn_485.Invoke_O_O__O(arg_486, arg_487) } else { arg_491 = linked_484.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_483, arg_486, arg_487) }; if linked_489 == nil { tmp12 = ifn_490.Invoke_O__O(arg_491) } else { tmp12 = linked_489.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_488, arg_491) }; if jrt.J2g_Truth(tmp12) { var tmp13 any; var root_515 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_517 lang.IFn
					if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any; var tmp14 *jrt.RefArray = jrt.ConstRefArray("[0,7,s5:j2g: ns7:: part ns4: of ns23: missing (c2j/continue)", []*jrt.Class{jrt.String_class}); var tmp15 any; var root_511 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = k__13; if linked_512 == nil { tmp15 = ifn_513.Invoke_O__O(arg_514) } else { tmp15 = linked_512.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_511, arg_514) }; arg_518 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, c__5, nil, tmp15, nil, n__4, nil)).Ref(); var arg_519 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_76, c__5)); if linked_516 == nil { tmp13 = ifn_517.Invoke_O_O__O(arg_518, arg_519) } else { tmp13 = linked_516.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_515, arg_518, arg_519) }
//line :61:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp13))); var tmp16 any; var root_520 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = seq_78000068__12; if linked_521 == nil { tmp16 = ifn_522.Invoke_O__O(arg_523) } else { tmp16 = linked_521.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_520, arg_523) }; seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = tmp16, nil, 0, 0; continue L2 } else { var tmp17 any; var root_524 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = seq_78000068__12; if linked_525 == nil { tmp17 = ifn_526.Invoke_O__O(arg_527) } else { tmp17 = linked_525.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_524, arg_527) }; seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = tmp17, nil, 0, 0; continue L2 } } } }
//line :58:1
			break L2
		}




		var root_492 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = t.F_claimed; var arg_496 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_497 any = ks__6; if linked_493 == nil { ifn_494.Invoke_O_O_O__O(arg_495, arg_496, arg_497) } else { linked_493.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_492, arg_495, arg_496, arg_497) }
		var root_449 any = A_arbace_j2g_world_A_const_67.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_435 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = A_arbace_j2g_world_A_const_69.GetRawRoot__O(); var arg_439 any; var root_430 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = f__2; var arg_434 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, ks__6); if linked_431 == nil { arg_439 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { arg_439 = linked_431.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }; if linked_436 == nil { arg_452 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { arg_452 = linked_436.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }; var arg_453 any; var root_445 any = A_arbace_j2g_world_A_const_71.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_447 lang.IFn
		if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var root_440 any = A_arbace_j2g_world_A_const_72.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__2); var arg_444 any = A_arbace_j2g_world_A_const_61; if linked_441 == nil { arg_448 = ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { arg_448 = linked_441.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) }; if linked_446 == nil { arg_453 = ifn_447.Invoke_O__O(arg_448) } else { arg_453 = linked_446.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_445, arg_448) }
//line :65:1
		if linked_450 == nil { arg_532 = ifn_451.Invoke_O_O__O(arg_452, arg_453) } else { arg_532 = linked_450.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_449, arg_452, arg_453) } } else {
//line :58:1
			arg_532 = f__2 }
//line :57:1
	if linked_529 == nil { ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { linked_529.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_528, arg_531, arg_532) }; i__78000061__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000061__1); continue L1 } else { i__78000061__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000061__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_New_O(p0 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :60:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A) Invoke_O_O__O(self, p1__78000038_SHARP___1 any) any { var root_407 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_vector_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = t.F_c; var arg_411 any = p1__78000038_SHARP___1; if linked_408 == nil { return ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { return linked_408.(*aot_arbace_core.A_arbace_core_vector_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) } }
//line :60:1
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_New_O(p0 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :60:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A) Invoke_O_O__O(self, p1__78000038_SHARP___1 any) any { var root_580 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_vector_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = t.F_c; var arg_584 any = p1__78000038_SHARP___1; if linked_581 == nil { return ifn_582.Invoke_O_O__O(arg_583, arg_584) } else { return linked_581.(*aot_arbace_core.A_arbace_core_vector_A).Invoke_O_O_O__O(root_580, arg_583, arg_584) } }












func A_arbace_j2g_world_ns_of_forms_A_New() *A_arbace_j2g_world_ns_of_forms_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_ns_of_forms_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_world_ns_of_forms_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_world_ns_of_forms_A) Invoke_O_O__O(self, forms__0 any) any { var f__2 any; var root_789 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_791 lang.IFn; if
											linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var root_784 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any; var tmp1 any = A_arbace_j2g_world_ns_of_forms_fn__78000085_A_New(); var tmp2 *jrt.Class; var fncls__783 *jrt.Class = A_arbace_j2g_world_ns_of_forms_fn__78000085_A_fn_class; if fncls__783 == nil { var fncls__783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_j2g_world_ns_of_forms_fn__78000085_A_fn_class = fncls__783d; tmp2 = fncls__783d } else { tmp2 = fncls__783 }; arg_787 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_788 any = forms__0; if linked_785 == nil { arg_792 = ifn_786.Invoke_O_O__O(arg_787, arg_788) } else { arg_792 = linked_785.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_784, arg_787, arg_788) }; if linked_790 == nil { f__2 = ifn_791.Invoke_O__O(arg_792) } else { f__2 = linked_790.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_789, arg_792) }; if
											jrt.J2g_Truth(f__2) { var n__3 any; var root_793 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = f__2; if linked_794 == nil { n__3 = ifn_795.Invoke_O__O(arg_796) } else { n__3 = linked_794.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_793, arg_796) }; var tmp3 any; var root_797 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = n__3; if linked_798 == nil { tmp3 = ifn_799.Invoke_O__O(arg_800) } else { tmp3 = linked_798.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_797, arg_800) }; if jrt.J2g_Truth(tmp3) { var root_801 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = n__3; if linked_802 == nil { return ifn_803.Invoke_O__O(arg_804) } else { return linked_802.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_801, arg_804) } } else { return n__3 } } else { return nil } }
//line :74:1
func A_arbace_j2g_world_ns_of_forms_fn__78000085_A_New() *A_arbace_j2g_world_ns_of_forms_fn__78000085_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_ns_of_forms_fn__78000085_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_j2g_world_ns_of_forms_fn__78000085_A) Ctor() {}
//line :74:1
func (t *A_arbace_j2g_world_ns_of_forms_fn__78000085_A) Invoke_O_O__O(self, p1__78000084_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_763 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = p1__78000084_SHARP___1; if linked_764 == nil { and__1927000168__auto____2 = ifn_765.Invoke_O__O(arg_766) } else { and__1927000168__auto____2 = linked_764.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_763, arg_766) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_771 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any; var root_767 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = p1__78000084_SHARP___1; if linked_768 == nil { arg_774 = ifn_769.Invoke_O__O(arg_770) } else { arg_774 = linked_768.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_767, arg_770) }; if linked_772 == nil { and__1927000168__auto____3 = ifn_773.Invoke_O__O(arg_774) } else { and__1927000168__auto____3 = linked_772.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_771, arg_774) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any; var root_779 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any; var root_775 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = p1__78000084_SHARP___1; if linked_776 == nil { arg_782 = ifn_777.Invoke_O__O(arg_778) } else { arg_782 = linked_776.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_775, arg_778) }; if linked_780 == nil { tmp1 = ifn_781.Invoke_O__O(arg_782) } else { tmp1 = linked_780.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_779, arg_782) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_122, tmp1)).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_world_top_names_A_New() *A_arbace_j2g_world_top_names_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_top_names_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_j2g_world_top_names_A) Ctor() {}
//line :77:1
func (t *A_arbace_j2g_world_top_names_A) Invoke_O_O_O__O(self, nsname__0, forms__1 any) any { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_world_top_names_iter__78000088__78000092_A_New_O(nsname__0); var tmp2 *jrt.Class; var fncls__1037 *jrt.Class = A_arbace_j2g_world_top_names_iter__78000088__78000092_A_fn_class; if


	fncls__1037 == nil { var fncls__1037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_j2g_world_top_names_iter__78000088__78000092_A_fn_class = fncls__1037d; tmp2 = fncls__1037d } else { tmp2 = fncls__1037 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1038 any = A_arbace_j2g_world_A_const_90.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, A_arbace_j2g_world_class_forms_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = forms__1; if linked_1039 == nil { tmp4 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp4 = linked_1039.(*A_arbace_j2g_world_class_forms_A).Invoke_O_O__O(root_1038, arg_1041) }; return tmp3.Invoke_O__O(tmp4) }
//line :80:1
func A_arbace_j2g_world_top_names_iter__78000088__78000092_A_New_O(p0 any) *A_arbace_j2g_world_top_names_iter__78000088__78000092_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_top_names_iter__78000088__78000092_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_A) Invoke_O_O__O(self, s__78000089__1 any) any { var tmp1 any = A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_New_O_O_O(t.F_nsname, s__78000089__1, self); var tmp2 *jrt.Class; var fncls__1036 *jrt.Class = A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_fn_class; if fncls__1036 == nil { var fncls__1036d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_fn_class = fncls__1036d; tmp2 = fncls__1036d } else { tmp2 = fncls__1036 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :80:1
func A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A) Ctor_O_O_O(c__nsname, c__s__78000089, c__iter__78000088 any) { t.F_nsname = c__nsname; t.F_s__78000089 = c__s__78000089; t.F_iter__78000088 = c__iter__78000088 }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A) Invoke_O__O(self any) any { { var s__78000089__1 any; var t_ any = t.F_s__78000089; t.F_s__78000089 = nil; s__78000089__1 = t_; for { var temp__1927000414__auto____2 any; var root_805 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = s__78000089__1; if linked_806 == nil { temp__1927000414__auto____2 = ifn_807.Invoke_O__O(arg_808) } else { temp__1927000414__auto____2 = linked_806.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_805, arg_808) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000089__3 any = temp__1927000414__auto____2; var tmp1 any; var root_809 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = s__78000089__3; if linked_810 == nil { tmp1 = ifn_811.Invoke_O__O(arg_812) } else { tmp1 = linked_810.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_809, arg_812) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_813 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = s__78000089__3; if linked_814 == nil { c__1927001037__auto____4 = ifn_815.Invoke_O__O(arg_816) } else { c__1927001037__auto____4 = linked_814.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_813, arg_816) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000091__6 any; var root_817 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_818 == nil { b__78000091__6 = ifn_819.Invoke_O__O(arg_820) } else { b__78000091__6 = linked_818.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_817, arg_820) }; var tmp2 any = A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_New_O_O_I_O(t.F_nsname, b__78000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__913 *jrt.Class = A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_fn_class; if fncls__913 == nil { var fncls__913d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_fn_class = fncls__913d; tmp3 = fncls__913d } else { tmp3 = fncls__913 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_922 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any; var root_914 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = b__78000091__6; if linked_915 == nil { arg_925 = ifn_916.Invoke_O__O(arg_917) } else { arg_925 = linked_915.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_914, arg_917) }; var arg_926 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000088); var tmp5 any; var root_918 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = s__78000089__3; if linked_919 == nil { tmp5 = ifn_920.Invoke_O__O(arg_921) } else { tmp5 = linked_919.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_918, arg_921) }; arg_926 = tmp4.Invoke_O__O(tmp5); if linked_923 == nil { return ifn_924.Invoke_O_O__O(arg_925, arg_926) } else { return linked_923.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_922, arg_925, arg_926) } } else { var root_931 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any; var root_927 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = b__78000091__6; if linked_928 == nil { arg_934 = ifn_929.Invoke_O__O(arg_930) } else { arg_934 = linked_928.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_927, arg_930) }; var arg_935 any; if linked_932 == nil { return ifn_933.Invoke_O_O__O(arg_934, arg_935) } else { return linked_932.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_931, arg_934, arg_935) } } } else { var cf__4 any; var root_936 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = s__78000089__3; if linked_937 == nil { cf__4 = ifn_938.Invoke_O__O(arg_939) } else { cf__4 = linked_937.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_936, arg_939) }; var vec__78000099__5 any; var root_940 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_942 lang.IFn
														if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = cf__4; if linked_941 == nil { vec__78000099__5 = ifn_942.Invoke_O__O(arg_943) } else { vec__78000099__5 = linked_941.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_940, arg_943) }
//line :80:1
	var seq__78000100__6 any; var root_944 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = vec__78000099__5; if linked_945 == nil { seq__78000100__6 = ifn_946.Invoke_O__O(arg_947) } else { seq__78000100__6 = linked_945.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_944, arg_947) }; var first__78000101__7 any; var root_948 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = seq__78000100__6; if linked_949 == nil { first__78000101__7 = ifn_950.Invoke_O__O(arg_951) } else { first__78000101__7 = linked_949.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_948, arg_951) }; var seq__78000100__8 any; var root_952 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = seq__78000100__6; if linked_953 == nil { seq__78000100__8 = ifn_954.Invoke_O__O(arg_955) } else { seq__78000100__8 = linked_953.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_952, arg_955) }; var nm__9 any = first__78000101__7; var more__10 any = seq__78000100__8; var more__11 any; var tmp6 any; var root_960 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_962 lang.IFn

	if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any; var root_956 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = more__10; if linked_957 == nil { arg_963 = ifn_958.Invoke_O__O(arg_959) } else { arg_963 = linked_957.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_956, arg_959) }; if linked_961 == nil { tmp6 = ifn_962.Invoke_O__O(arg_963) } else { tmp6 = linked_961.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_960, arg_963) }; if jrt.J2g_Truth(tmp6) { var root_964 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = more__10; if linked_965 == nil { more__11 = ifn_966.Invoke_O__O(arg_967) } else { more__11 = linked_965.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_964, arg_967) } } else { more__11 = more__10 }
//line :80:1
	var pkg__12 any; var tmp7 *lang.Keyword = A_arbace_j2g_world_A_const_83; var tmp8 any; var root_972 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_974 lang.IFn


	if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var root_968 any = A_arbace_j2g_world_A_const_84.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = more__11; if linked_969 == nil { arg_975 = ifn_970.Invoke_O__O(arg_971) } else { arg_975 = linked_969.(*aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A).Invoke_O_O__O(root_968, arg_971) }; if linked_973 == nil { tmp8 = ifn_974.Invoke_O__O(arg_975) } else { tmp8 = linked_973.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_972, arg_975) }; pkg__12 = tmp7.Invoke_O__O(tmp8)
//line :80:1
	var s__13 any; var root_976 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_978 lang.IFn



	if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = nm__9; if linked_977 == nil { s__13 = ifn_978.Invoke_O__O(arg_979) } else { s__13 = linked_977.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_976, arg_979) }
//line :80:1
	var root_1031 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any; var tmp9 any; var root_980 any = A_arbace_j2g_world_A_const_85.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_982 lang.IFn




	if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = pkg__12; if linked_981 == nil { tmp9 = ifn_982.Invoke_O__O(arg_983) } else { tmp9 = linked_981.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_980, arg_983) }; if jrt.J2g_Truth(tmp9) { var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp11 *jrt.String; var tmp12 any; var root_988 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any; var root_984 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = pkg__12; if linked_985 == nil { arg_991 = ifn_986.Invoke_O__O(arg_987) } else { arg_991 = linked_985.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_984, arg_987) }; if linked_989 == nil { tmp12 = ifn_990.Invoke_O__O(arg_991) } else { tmp12 = linked_989.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_988, arg_991) }; if jrt.J2g_Truth(tmp12) { var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140); var tmp14 any; var root_996 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var root_992 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = pkg__12; if linked_993 == nil { arg_999 = ifn_994.Invoke_O__O(arg_995) } else { arg_999 = linked_993.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_992, arg_995) }; var arg_1000 any = Lit_141; var arg_1001 any = Lit_140; if linked_997 == nil { tmp14 = ifn_998.Invoke_O_O_O__O(arg_999, arg_1000, arg_1001) } else { tmp14 = linked_997.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_996, arg_999, arg_1000, arg_1001) }; tmp11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, tmp14, nil)) } else { tmp11 = nil }; arg_1034 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11.Ref(), s__13)).Ref() } else { var tmp15 any; var root_1002 any = A_arbace_j2g_world_A_const_87.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1004 lang.IFn
		if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = s__13; var arg_1006 any = Lit_141; if linked_1003 == nil { tmp15 = ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { tmp15 = linked_1003.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }
//line :85:1
		if jrt.J2g_Truth(tmp15) {
			var root_1007 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = s__13; var arg_1011 any = Lit_141; var arg_1012 any = Lit_140; if linked_1008 == nil { arg_1034 = ifn_1009.Invoke_O_O_O__O(arg_1010, arg_1011, arg_1012) } else { arg_1034 = linked_1008.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1007, arg_1010, arg_1011, arg_1012) } } else {
//line :85:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140, nil); var tmp17 any; var root_1021 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any; var root_1017 any = A_arbace_j2g_world_A_const_89.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any; var root_1013 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = t.F_nsname; if linked_1014 == nil { arg_1020 = ifn_1015.Invoke_O__O(arg_1016) } else { arg_1020 = linked_1014.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1013, arg_1016) }; if linked_1018 == nil { arg_1024 = ifn_1019.Invoke_O__O(arg_1020) } else { arg_1024 = linked_1018.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_1017, arg_1020) }; var arg_1025 any = Lit_141; var arg_1026 any = Lit_140; if linked_1022 == nil { tmp17 = ifn_1023.Invoke_O_O_O__O(arg_1024, arg_1025, arg_1026) } else { tmp17 = linked_1022.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1021, arg_1024, arg_1025, arg_1026) }; arg_1034 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, nil, s__13)).Ref() } else {
//line :85:1
						arg_1034 = nil } } }
//line :80:1
	var arg_1035 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__78000088); var tmp19 any; var root_1027 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = s__78000089__3; if linked_1028 == nil { tmp19 = ifn_1029.Invoke_O__O(arg_1030) } else { tmp19 = linked_1028.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1027, arg_1030) }; arg_1035 = tmp18.Invoke_O__O(tmp19); if linked_1032 == nil { return ifn_1033.Invoke_O_O__O(arg_1034, arg_1035) } else { return linked_1032.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1031, arg_1034, arg_1035) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A) Ctor_O_O_I_O(c__nsname, c__b__78000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_nsname = c__nsname; t.F_b__78000091 = c__b__78000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A) Invoke_O__O(self any) any { { var i__78000090__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000090__1)); var vec__78000095__3 any; var root_821 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_823 lang.IFn
															if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = cf__2; if linked_822 == nil { vec__78000095__3 = ifn_823.Invoke_O__O(arg_824) } else { vec__78000095__3 = linked_822.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_821, arg_824) }
//line :80:1
	var seq__78000096__4 any; var root_825 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = vec__78000095__3; if linked_826 == nil { seq__78000096__4 = ifn_827.Invoke_O__O(arg_828) } else { seq__78000096__4 = linked_826.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_825, arg_828) }; var first__78000097__5 any; var root_829 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = seq__78000096__4; if linked_830 == nil { first__78000097__5 = ifn_831.Invoke_O__O(arg_832) } else { first__78000097__5 = linked_830.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_829, arg_832) }; var seq__78000096__6 any; var root_833 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = seq__78000096__4; if linked_834 == nil { seq__78000096__6 = ifn_835.Invoke_O__O(arg_836) } else { seq__78000096__6 = linked_834.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_833, arg_836) }; var nm__7 any = first__78000097__5; var more__8 any = seq__78000096__6; var more__9 any; var tmp2 any; var root_841 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_843 lang.IFn

	if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any; var root_837 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = more__8; if linked_838 == nil { arg_844 = ifn_839.Invoke_O__O(arg_840) } else { arg_844 = linked_838.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_837, arg_840) }; if linked_842 == nil { tmp2 = ifn_843.Invoke_O__O(arg_844) } else { tmp2 = linked_842.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_841, arg_844) }; if jrt.J2g_Truth(tmp2) { var root_845 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = more__8; if linked_846 == nil { more__9 = ifn_847.Invoke_O__O(arg_848) } else { more__9 = linked_846.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_845, arg_848) } } else { more__9 = more__8 }
//line :80:1
	var pkg__10 any; var tmp3 *lang.Keyword = A_arbace_j2g_world_A_const_83; var tmp4 any; var root_853 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_855 lang.IFn


	if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any; var root_849 any = A_arbace_j2g_world_A_const_84.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = more__9; if linked_850 == nil { arg_856 = ifn_851.Invoke_O__O(arg_852) } else { arg_856 = linked_850.(*aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A).Invoke_O_O__O(root_849, arg_852) }; if linked_854 == nil { tmp4 = ifn_855.Invoke_O__O(arg_856) } else { tmp4 = linked_854.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_853, arg_856) }; pkg__10 = tmp3.Invoke_O__O(tmp4)
//line :80:1
	var s__11 any; var root_857 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_859 lang.IFn



	if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = nm__7; if linked_858 == nil { s__11 = ifn_859.Invoke_O__O(arg_860) } else { s__11 = linked_858.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_857, arg_860) }
//line :80:1
	var root_908 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = t.F_b__78000091; var arg_912 any; var tmp5 any; var root_861 any = A_arbace_j2g_world_A_const_85.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_863 lang.IFn




	if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = pkg__10; if linked_862 == nil { tmp5 = ifn_863.Invoke_O__O(arg_864) } else { tmp5 = linked_862.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_861, arg_864) }; if jrt.J2g_Truth(tmp5) { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; var tmp8 any; var root_869 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any; var root_865 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = pkg__10; if linked_866 == nil { arg_872 = ifn_867.Invoke_O__O(arg_868) } else { arg_872 = linked_866.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_865, arg_868) }; if linked_870 == nil { tmp8 = ifn_871.Invoke_O__O(arg_872) } else { tmp8 = linked_870.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_869, arg_872) }; if jrt.J2g_Truth(tmp8) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140); var tmp10 any; var root_877 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any; var root_873 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = pkg__10; if linked_874 == nil { arg_880 = ifn_875.Invoke_O__O(arg_876) } else { arg_880 = linked_874.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_873, arg_876) }; var arg_881 any = Lit_141; var arg_882 any = Lit_140; if linked_878 == nil { tmp10 = ifn_879.Invoke_O_O_O__O(arg_880, arg_881, arg_882) } else { tmp10 = linked_878.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_877, arg_880, arg_881, arg_882) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10, nil)) } else { tmp7 = nil }; arg_912 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), s__11)).Ref() } else { var tmp11 any; var root_883 any = A_arbace_j2g_world_A_const_87.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_885 lang.IFn
		if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = s__11; var arg_887 any = Lit_141; if linked_884 == nil { tmp11 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { tmp11 = linked_884.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_883, arg_886, arg_887) }
//line :85:1
		if jrt.J2g_Truth(tmp11) {
			var root_888 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = s__11; var arg_892 any = Lit_141; var arg_893 any = Lit_140; if linked_889 == nil { arg_912 = ifn_890.Invoke_O_O_O__O(arg_891, arg_892, arg_893) } else { arg_912 = linked_889.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_888, arg_891, arg_892, arg_893) } } else {
//line :85:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140, nil); var tmp13 any; var root_902 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any; var root_898 any = A_arbace_j2g_world_A_const_89.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any; var root_894 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = t.F_nsname; if linked_895 == nil { arg_901 = ifn_896.Invoke_O__O(arg_897) } else { arg_901 = linked_895.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_894, arg_897) }; if linked_899 == nil { arg_905 = ifn_900.Invoke_O__O(arg_901) } else { arg_905 = linked_899.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_898, arg_901) }; var arg_906 any = Lit_141; var arg_907 any = Lit_140; if linked_903 == nil { tmp13 = ifn_904.Invoke_O_O_O__O(arg_905, arg_906, arg_907) } else { tmp13 = linked_903.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_902, arg_905, arg_906, arg_907) }; arg_912 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, s__11)).Ref() } else {
//line :85:1
						arg_912 = nil } } }
//line :80:1
	if linked_909 == nil { ifn_910.Invoke_O_O__O(arg_911, arg_912) } else { linked_909.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_908, arg_911, arg_912) }; i__78000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000090__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_world_source_files_A_New() *A_arbace_j2g_world_source_files_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_j2g_world_source_files_A) Ctor() {}
//line :89:1
func (t *A_arbace_j2g_world_source_files_A) Invoke_O_O__O(self, p__78000107__0 any) any { var map__78000108__2 any = p__78000107__0; var map__78000108__3 any; if lang.ISeq_InstanceOf(map__78000108__2) { var tmp1 any; var root_1042 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = map__78000108__2; if linked_1043 == nil { tmp1 = ifn_1044.Invoke_O__O(arg_1045) } else { tmp1 = linked_1043.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1042, arg_1045) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1046 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = map__78000108__2; if linked_1047 == nil { tmp2 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp2 = linked_1047.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1046, arg_1049) }; map__78000108__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1050 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = map__78000108__2; if linked_1051 == nil { tmp3 = ifn_1052.Invoke_O__O(arg_1053) } else { tmp3 = linked_1051.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1050, arg_1053) }; if jrt.J2g_Truth(tmp3) { var root_1054 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = map__78000108__2; if linked_1055 == nil { map__78000108__3 = ifn_1056.Invoke_O__O(arg_1057) } else { map__78000108__3 = linked_1055.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1054, arg_1057) } } else { map__78000108__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000108__3 = map__78000108__2 }; var root__4 any = lang.RT_Get_O_O__O_NoInit(map__78000108__3, A_arbace_j2g_world_A_const_91); var dirs__5 any = lang.RT_Get_O_O__O_NoInit(map__78000108__3, A_arbace_j2g_world_A_const_92); var tree__6 any = lang.RT_Get_O_O__O_NoInit(map__78000108__3, A_arbace_j2g_world_A_const_93); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__78000108__3, A_arbace_j2g_world_A_const_94); if



	jrt.J2g_Truth(files__7) {
		var root_1058 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = A_arbace_j2g_world_A_const_95.GetRawRoot__O(); var arg_1062 any = files__7; if linked_1059 == nil { return ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { return linked_1059.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) } } else {
//line :93:1
			if jrt.J2g_Truth(tree__6) {






				var root_1100 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var arg_1104 any; var root_1095 any = A_arbace_j2g_world_A_const_77.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1097 lang.IFn
//line :99:1
				if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any; var tmp4 any = A_arbace_j2g_world_source_files_fn__78000110_A_New(); var tmp5 *jrt.Class; var fncls__1075 *jrt.Class = A_arbace_j2g_world_source_files_fn__78000110_A_fn_class; if fncls__1075 == nil { var fncls__1075d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_j2g_world_source_files_fn__78000110_A_fn_class = fncls__1075d; tmp5 = fncls__1075d } else { tmp5 = fncls__1075 }; arg_1098 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1099 any; var root_1090 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1092 lang.IFn
//line :96:1
				if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any; var tmp6 any = A_arbace_j2g_world_source_files_fn__78000112_A_New(); var tmp7 *jrt.Class; var fncls__1081 *jrt.Class = A_arbace_j2g_world_source_files_fn__78000112_A_fn_class; if fncls__1081 == nil { var fncls__1081d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_j2g_world_source_files_fn__78000112_A_fn_class = fncls__1081d; tmp7 = fncls__1081d } else { tmp7 = fncls__1081 }; arg_1093 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1094 any; var root_1086 any = A_arbace_j2g_world_A_const_100.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1088 lang.IFn
//line :95:1
				if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any; var root_1082 any = A_arbace_j2g_world_A_const_95.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1082, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = root__4; if linked_1083 == nil { arg_1089 = ifn_1084.Invoke_O__O(arg_1085) } else { arg_1089 = linked_1083.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1082, arg_1085) }; if linked_1087 == nil { arg_1094 = ifn_1088.Invoke_O__O(arg_1089) } else { arg_1094 = linked_1087.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1086, arg_1089) }
				if linked_1091 == nil { arg_1099 = ifn_1092.Invoke_O_O__O(arg_1093, arg_1094) } else { arg_1099 = linked_1091.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1090, arg_1093, arg_1094)
				}

				if linked_1096 == nil { arg_1104 = ifn_1097.Invoke_O_O__O(arg_1098, arg_1099) } else { arg_1104 = linked_1096.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1095, arg_1098, arg_1099) }
				if linked_1101 == nil { return ifn_1102.Invoke_O_O__O(arg_1103, arg_1104) } else { return linked_1101.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1100, arg_1103, arg_1104) } } else {
//line :93:1
					if A_arbace_j2g_world_A_const_88 != nil {










						var root_1210 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var arg_1214 any; var iter__1927001039__auto____8 any; var tmp8 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_A_New_O(root__4); var tmp9 *jrt.Class; var fncls__1209 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_A_fn_class
//line :101:1
						if fncls__1209 == nil { var fncls__1209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_A_fn_class = fncls__1209d; tmp9 = fncls__1209d } else { tmp9 = fncls__1209 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_1214 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(dirs__5)


						if linked_1211 == nil { return ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { return linked_1211.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) } } else {
//line :93:1
							return nil } } } }


func A_arbace_j2g_world_source_files_fn__78000112_A_New() *A_arbace_j2g_world_source_files_fn__78000112_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_fn__78000112_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_j2g_world_source_files_fn__78000112_A) Ctor() {}
//line :96:1
func (t *A_arbace_j2g_world_source_files_fn__78000112_A) Invoke_O_O__O(self, p1__78000105_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__78000105_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var root_1076 any = A_arbace_j2g_world_A_const_99.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = jrt.NN(jrt.File_Cast(p1__78000105_SHARP___1)).GetName__String().Ref(); var arg_1080 any = Lit_146; if linked_1077 == nil { return ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { return linked_1077.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }


func A_arbace_j2g_world_source_files_fn__78000110_A_New() *A_arbace_j2g_world_source_files_fn__78000110_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_fn__78000110_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_j2g_world_source_files_fn__78000110_A) Ctor() {}
//line :99:1
func (t *A_arbace_j2g_world_source_files_fn__78000110_A) Invoke_O_O__O(self, p1__78000106_SHARP___1 any) any { var f__2 any; var root_1063 any = A_arbace_j2g_world_A_const_97.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, A_arbace_j2g_world_first_form_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = p1__78000106_SHARP___1; if linked_1064 == nil { f__2 = ifn_1065.Invoke_O__O(arg_1066) } else { f__2 = linked_1064.(*A_arbace_j2g_world_first_form_A).Invoke_O_O__O(root_1063, arg_1066) }; var and__1927000168__auto____3 any; var root_1067 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = f__2; if linked_1068 == nil { and__1927000168__auto____3 = ifn_1069.Invoke_O__O(arg_1070) } else { and__1927000168__auto____3 = linked_1068.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1067, arg_1070) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_j2g_world_A_const_98; var tmp2 any; var root_1071 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = f__2; if linked_1072 == nil { tmp2 = ifn_1073.Invoke_O__O(arg_1074) } else { tmp2 = linked_1072.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1071, arg_1074) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____3 } }

func A_arbace_j2g_world_source_files_iter__78000114__78000120_A_New_O(p0 any) *A_arbace_j2g_world_source_files_iter__78000114__78000120_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_A) Invoke_O_O__O(self, s__78000115__1 any) any { var tmp1 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_New_O_O_O(s__78000115__1, self, t.F_root); var tmp2 *jrt.Class; var fncls__1208 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_fn_class; if fncls__1208 == nil { var fncls__1208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_fn_class = fncls__1208d; tmp2 = fncls__1208d } else { tmp2 = fncls__1208 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :101:1
func A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A) Ctor_O_O_O(c__s__78000115, c__iter__78000114, c__root any) { t.F_s__78000115 = c__s__78000115; t.F_iter__78000114 = c__iter__78000114; t.F_root = c__root }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A) Invoke_O__O(self any) any { { var s__78000115__1 any; var t_ any = t.F_s__78000115; t.F_s__78000115 = nil; s__78000115__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1105 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = s__78000115__1; if linked_1106 == nil { temp__1927000414__auto____2 = ifn_1107.Invoke_O__O(arg_1108) } else { temp__1927000414__auto____2 = linked_1106.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1105, arg_1108) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any; var root_1109 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = xs__1927001018__auto____3; if linked_1110 == nil { d__4 = ifn_1111.Invoke_O__O(arg_1112) } else { d__4 = linked_1110.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1109, arg_1112) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_New(); var tmp2 *jrt.Class; var fncls__1185 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_fn_class; if fncls__1185 == nil { var fncls__1185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_fn_class = fncls__1185d; tmp2 = fncls__1185d } else { tmp2 = fncls__1185 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_1191 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1186 any = A_arbace_j2g_world_A_const_95.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1186, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = t.F_root; var arg_1190 any = d__4; if linked_1187 == nil { tmp4 = ifn_1188.Invoke_O_O__O(arg_1189, arg_1190) } else { tmp4 = linked_1187.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1186, arg_1189, arg_1190) }; arg_1194 = tmp3.Invoke_O__O(jrt.NN(jrt.File_Cast(tmp4)).ListFiles__File1().Ref()); if linked_1192 == nil { fs__1927001036__auto____6 = ifn_1193.Invoke_O__O(arg_1194) } else { fs__1927001036__auto____6 = linked_1192.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1191, arg_1194) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1199 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = fs__1927001036__auto____6; var arg_1203 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__78000114); var tmp6 any; var root_1195 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = s__78000115__1; if linked_1196 == nil { tmp6 = ifn_1197.Invoke_O__O(arg_1198) } else { tmp6 = linked_1196.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1195, arg_1198) }; arg_1203 = tmp5.Invoke_O__O(tmp6); if linked_1200 == nil { return ifn_1201.Invoke_O_O__O(arg_1202, arg_1203) } else { return linked_1200.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1199, arg_1202, arg_1203) } } else { var tmp7 any; var root_1204 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = s__78000115__1; if linked_1205 == nil { tmp7 = ifn_1206.Invoke_O__O(arg_1207) } else { tmp7 = linked_1205.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1204, arg_1207) }; s__78000115__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :101:1
func A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_New() *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A) Ctor() {}
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A) Invoke_O_O__O(self, s__78000117__1 any) any { var tmp1 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_New_O_O(s__78000117__1, self); var tmp2 *jrt.Class; var fncls__1184 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_fn_class; if fncls__1184 == nil { var fncls__1184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_fn_class = fncls__1184d; tmp2 = fncls__1184d } else { tmp2 = fncls__1184 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :101:1
func A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A{}; t.Ctor_O_O(p0, p1); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A) Ctor_O_O(c__s__78000117, c__iter__78000116 any) { t.F_s__78000117 = c__s__78000117; t.F_iter__78000116 = c__iter__78000116 }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A) Invoke_O__O(self any) any { { var s__78000117__1 any; var t_ any = t.F_s__78000117; t.F_s__78000117 = nil; s__78000117__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1113 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = s__78000117__1; if linked_1114 == nil { temp__1927000414__auto____2 = ifn_1115.Invoke_O__O(arg_1116) } else { temp__1927000414__auto____2 = linked_1114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000117__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1117 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = s__78000117__3; if linked_1118 == nil { tmp1 = ifn_1119.Invoke_O__O(arg_1120) } else { tmp1 = linked_1118.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1117, arg_1120) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1121 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = s__78000117__3; if linked_1122 == nil { c__1927001037__auto____4 = ifn_1123.Invoke_O__O(arg_1124) } else { c__1927001037__auto____4 = linked_1122.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1121, arg_1124) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000119__6 any; var root_1125 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1126 == nil { b__78000119__6 = ifn_1127.Invoke_O__O(arg_1128) } else { b__78000119__6 = linked_1126.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp2 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_New_O_I_O(b__78000119__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1139 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_fn_class; if fncls__1139 == nil { var fncls__1139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_fn_class = fncls__1139d; tmp3 = fncls__1139d } else { tmp3 = fncls__1139 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1148 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any; var root_1140 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = b__78000119__6; if linked_1141 == nil { arg_1151 = ifn_1142.Invoke_O__O(arg_1143) } else { arg_1151 = linked_1141.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1140, arg_1143) }; var arg_1152 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000116); var tmp5 any; var root_1144 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = s__78000117__3; if linked_1145 == nil { tmp5 = ifn_1146.Invoke_O__O(arg_1147) } else { tmp5 = linked_1145.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1144, arg_1147) }; arg_1152 = tmp4.Invoke_O__O(tmp5); if linked_1149 == nil { return ifn_1150.Invoke_O_O__O(arg_1151, arg_1152) } else { return linked_1149.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1148, arg_1151, arg_1152) } } else { var root_1157 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any; var root_1153 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = b__78000119__6; if linked_1154 == nil { arg_1160 = ifn_1155.Invoke_O__O(arg_1156) } else { arg_1160 = linked_1154.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1153, arg_1156) }; var arg_1161 any; if linked_1158 == nil { return ifn_1159.Invoke_O_O__O(arg_1160, arg_1161) } else { return linked_1158.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1157, arg_1160, arg_1161) } } } else { var f__4 any; var root_1162 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = s__78000117__3; if linked_1163 == nil { f__4 = ifn_1164.Invoke_O__O(arg_1165) } else { f__4 = linked_1163.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1162, arg_1165) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
																			if and__1927000168__auto____5 { var root_1166 any = A_arbace_j2g_world_A_const_99.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_1170 any = Lit_146; if linked_1167 == nil { tmp6 = ifn_1168.Invoke_O_O__O(arg_1169, arg_1170) } else { tmp6 = linked_1167.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1166, arg_1169, arg_1170) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :101:1
	if jrt.J2g_Truth(tmp6) { var root_1175 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = f__4; var arg_1179 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000116); var tmp8 any; var root_1171 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = s__78000117__3; if linked_1172 == nil { tmp8 = ifn_1173.Invoke_O__O(arg_1174) } else { tmp8 = linked_1172.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1171, arg_1174) }; arg_1179 = tmp7.Invoke_O__O(tmp8); if linked_1176 == nil { return ifn_1177.Invoke_O_O__O(arg_1178, arg_1179) } else { return linked_1176.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1175, arg_1178, arg_1179) } } else { var tmp9 any; var root_1180 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = s__78000117__3; if linked_1181 == nil { tmp9 = ifn_1182.Invoke_O__O(arg_1183) } else { tmp9 = linked_1181.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1180, arg_1183) }; s__78000117__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :101:1
func A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A) Ctor_O_I_O(c__b__78000119 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000119 = c__b__78000119; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A) Invoke_O__O(self any) any { { var i__78000118__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000118__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000118__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																				if and__1927000168__auto____3 { var root_1129 any = A_arbace_j2g_world_A_const_99.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_1133 any = Lit_146; if linked_1130 == nil { tmp2 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { tmp2 = linked_1130.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :101:1
	if jrt.J2g_Truth(tmp2) { var root_1134 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = t.F_b__78000119; var arg_1138 any = f__2; if linked_1135 == nil { ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { linked_1135.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }; i__78000118__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000118__1); continue L1 } else { i__78000118__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000118__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_world_head_name_A_New() *A_arbace_j2g_world_head_name_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_head_name_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_j2g_world_head_name_A) Ctor() {}
//line :110:1
func (t *A_arbace_j2g_world_head_name_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_1215 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = f__0; if linked_1216 == nil { and__1927000168__auto____2 = ifn_1217.Invoke_O__O(arg_1218) } else { and__1927000168__auto____2 = linked_1216.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1215, arg_1218) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1223 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any; var root_1219 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = f__0; if linked_1220 == nil { arg_1226 = ifn_1221.Invoke_O__O(arg_1222) } else { arg_1226 = linked_1220.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1219, arg_1222) }; if linked_1224 == nil { tmp1 = ifn_1225.Invoke_O__O(arg_1226) } else { tmp1 = linked_1224.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1223, arg_1226) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_1231 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any; var root_1227 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = f__0; if linked_1228 == nil { arg_1234 = ifn_1229.Invoke_O__O(arg_1230) } else { arg_1234 = linked_1228.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1227, arg_1230) }; if linked_1232 == nil { return ifn_1233.Invoke_O__O(arg_1234) } else { return linked_1232.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1231, arg_1234) } } else { return nil } }

func A_arbace_j2g_world_param_key_A_New() *A_arbace_j2g_world_param_key_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_j2g_world_param_key_A) Ctor() {}
//line :112:1
func (t *A_arbace_j2g_world_param_key_A) Invoke_O_O__O(self, f__0 any) any { var h__2 any; var root_1235 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1237 lang.IFn; if


	linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = f__0; if linked_1236 == nil { h__2 = ifn_1237.Invoke_O__O(arg_1238) } else { h__2 = linked_1236.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1235, arg_1238) }; var G__78000134__3_ any = h__2; switch
	lang.Util_Hash_O__I_NoInit(G__78000134__3_) >> 17 & 15 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_123) { var vec__78000135__4 any = f__0; var seq__78000136__5 any; var root_1240 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1242 lang.IFn

		if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = vec__78000135__4; if linked_1241 == nil { seq__78000136__5 = ifn_1242.Invoke_O__O(arg_1243) } else { seq__78000136__5 = linked_1241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1240, arg_1243) }
//line :116:1
		var first__78000137__6 any; var root_1244 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1246 lang.IFn

		if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = seq__78000136__5; if linked_1245 == nil { first__78000137__6 = ifn_1246.Invoke_O__O(arg_1247) } else { first__78000137__6 = linked_1245.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1244, arg_1247) }
//line :116:1
		var seq__78000136__7 any; var root_1248 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1250 lang.IFn

		if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = seq__78000136__5; if linked_1249 == nil { seq__78000136__7 = ifn_1250.Invoke_O__O(arg_1251) } else { seq__78000136__7 = linked_1249.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1248, arg_1251) }
//line :116:1
		var ___8 any = first__78000137__6; var first__78000137__9 any; var root_1252 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1254 lang.IFn; _ = ___8

		if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = seq__78000136__7; if linked_1253 == nil { first__78000137__9 = ifn_1254.Invoke_O__O(arg_1255) } else { first__78000137__9 = linked_1253.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1252, arg_1255) }
//line :116:1
		var seq__78000136__10 any; var root_1256 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1258 lang.IFn

		if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = seq__78000136__7; if linked_1257 == nil { seq__78000136__10 = ifn_1258.Invoke_O__O(arg_1259) } else { seq__78000136__10 = linked_1257.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1256, arg_1259) }
//line :116:1
		var nm__11 any = first__78000137__9; var more__12 any = seq__78000136__10; var more__13 any; var tmp1 any = A_arbace_j2g_world_param_key_fn__78000138_A_New_O(more__12); var tmp2 *jrt.Class
		var fncls__1286 /*line :116:1*/*jrt.Class = A_arbace_j2g_world_param_key_fn__78000138_A_fn_class



		if fncls__1286 == nil { var fncls__1286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_j2g_world_param_key_fn__78000138_A_fn_class = fncls__1286d; tmp2 = fncls__1286d } else { tmp2 = fncls__1286 }; more__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :116:1
		var params__14 any; var root_1292 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1294 lang.IFn







		if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any; var root_1287 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var arg_1291 any = more__13; if linked_1288 == nil { arg_1295 = ifn_1289.Invoke_O_O__O(arg_1290, arg_1291) } else { arg_1295 = linked_1288.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1287, arg_1290, arg_1291) }; if linked_1293 == nil { params__14 = ifn_1294.Invoke_O__O(arg_1295) } else { params__14 = linked_1293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1292, arg_1295) }
//line :116:1
		var tmp3 *lang.Keyword = A_arbace_j2g_world_A_const_104; var static__15 bool = lang.RT_BooleanCast_O__Z_NoInit(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__11))); var ps__16 any









		if static__15 { ps__16 = params__14 } else { var root_1296 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = params__14; if linked_1297 == nil { ps__16 = ifn_1298.Invoke_O__O(arg_1299) } else { ps__16 = linked_1297.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1296, arg_1299) } }
//line :116:1
		var tmp4 any = A_arbace_j2g_world_A_const_105; var tmp5 any; var root_1413 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1415 lang.IFn










		if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = nm__11; if linked_1414 == nil { tmp5 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp5 = linked_1414.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1413, arg_1416) }
//line :116:1
		var tmp6 any = tmp5; var tmp7 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(static__15).Ref(); var tmp8 any; var root_1422 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1424 lang.IFn










		if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any; var tmp9 any = A_arbace_j2g_world_param_key_fn__78000140_A_New(); var tmp10 *jrt.Class; var fncls__1421 *jrt.Class = A_arbace_j2g_world_param_key_fn__78000140_A_fn_class; if fncls__1421 == nil { var fncls__1421d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_j2g_world_param_key_fn__78000140_A_fn_class = fncls__1421d; tmp10 = fncls__1421d } else { tmp10 = fncls__1421 }; arg_1425 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1426 any = ps__16; if linked_1423 == nil { tmp8 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { tmp8 = linked_1423.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }
//line :116:1
		return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp4, tmp6, tmp7, tmp8) }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_126) { var vec__78000143__4 any = f__0; var seq__78000144__5 any; var root_1300 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1302 lang.IFn

			if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = vec__78000143__4; if linked_1301 == nil { seq__78000144__5 = ifn_1302.Invoke_O__O(arg_1303) } else { seq__78000144__5 = linked_1301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1300, arg_1303) }
//line :116:1
			var first__78000145__6 any; var root_1304 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1306 lang.IFn

			if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = seq__78000144__5; if linked_1305 == nil { first__78000145__6 = ifn_1306.Invoke_O__O(arg_1307) } else { first__78000145__6 = linked_1305.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1304, arg_1307) }
//line :116:1
			var seq__78000144__7 any; var root_1308 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1310 lang.IFn

			if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = seq__78000144__5; if linked_1309 == nil { seq__78000144__7 = ifn_1310.Invoke_O__O(arg_1311) } else { seq__78000144__7 = linked_1309.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1308, arg_1311) }
//line :116:1
			var ___8_2 any = first__78000145__6; var first__78000145__9 any; var root_1312 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1314 lang.IFn; _ = ___8_2

			if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = seq__78000144__7; if linked_1313 == nil { first__78000145__9 = ifn_1314.Invoke_O__O(arg_1315) } else { first__78000145__9 = linked_1313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1312, arg_1315) }
//line :116:1
			var seq__78000144__10 any; var root_1316 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1318 lang.IFn

			if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = seq__78000144__7; if linked_1317 == nil { seq__78000144__10 = ifn_1318.Invoke_O__O(arg_1319) } else { seq__78000144__10 = linked_1317.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1316, arg_1319) }
//line :116:1
			var nm__11_2 any = first__78000145__9; var more__12_2 any = seq__78000144__10; var more__13_2 any; var tmp11 any = A_arbace_j2g_world_param_key_fn__78000146_A_New_O(more__12_2); var tmp12 *jrt.Class
			var fncls__1346 /*line :116:1*/*jrt.Class = A_arbace_j2g_world_param_key_fn__78000146_A_fn_class



			if fncls__1346 == nil { var fncls__1346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_j2g_world_param_key_fn__78000146_A_fn_class = fncls__1346d; tmp12 = fncls__1346d } else { tmp12 = fncls__1346 }; more__13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :116:1
			var params__14_2 any; var root_1352 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1354 lang.IFn







			if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any; var root_1347 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var arg_1351 any = more__13_2; if linked_1348 == nil { arg_1355 = ifn_1349.Invoke_O_O__O(arg_1350, arg_1351) } else { arg_1355 = linked_1348.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1347, arg_1350, arg_1351) }; if linked_1353 == nil { params__14_2 = ifn_1354.Invoke_O__O(arg_1355) } else { params__14_2 = linked_1353.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1352, arg_1355) }
//line :116:1
			var tmp13 *lang.Keyword = A_arbace_j2g_world_A_const_104; var static__15_2 bool = lang.RT_BooleanCast_O__Z_NoInit(tmp13.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__11_2))); var ps__16_2 any









			if static__15_2 { ps__16_2 = params__14_2 } else { var root_1356 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = params__14_2; if linked_1357 == nil { ps__16_2 = ifn_1358.Invoke_O__O(arg_1359) } else { ps__16_2 = linked_1357.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1356, arg_1359) } }
//line :116:1
			var tmp14 any = A_arbace_j2g_world_A_const_105; var tmp15 any; var root_1427 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1429 lang.IFn










			if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = nm__11_2; if linked_1428 == nil { tmp15 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp15 = linked_1428.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1427, arg_1430) }
//line :116:1
			var tmp16 any = tmp15; var tmp17 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(static__15_2).Ref(); var tmp18 any; var root_1436 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1438 lang.IFn










			if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any; var tmp19 any = A_arbace_j2g_world_param_key_fn__78000148_A_New(); var tmp20 *jrt.Class; var fncls__1435 *jrt.Class = A_arbace_j2g_world_param_key_fn__78000148_A_fn_class; if fncls__1435 == nil { var fncls__1435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_j2g_world_param_key_fn__78000148_A_fn_class = fncls__1435d; tmp20 = fncls__1435d } else { tmp20 = fncls__1435 }; arg_1439 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_1440 any = ps__16_2; if linked_1437 == nil { tmp18 = ifn_1438.Invoke_O_O__O(arg_1439, arg_1440) } else { tmp18 = linked_1437.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1436, arg_1439, arg_1440) }
//line :116:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, tmp18) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_19) { var nm__4 any; var root_1369 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1371 lang.IFn

















				if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any; var root_1364 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var arg_1368 any; var root_1360 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = f__0; if linked_1361 == nil { arg_1368 = ifn_1362.Invoke_O__O(arg_1363) } else { arg_1368 = linked_1361.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1360, arg_1363) }; if linked_1365 == nil { arg_1372 = ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { arg_1372 = linked_1365.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) }; if linked_1370 == nil { nm__4 = ifn_1371.Invoke_O__O(arg_1372) } else { nm__4 = linked_1370.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1369, arg_1372) }
//line :116:1
				var tmp21 any = A_arbace_j2g_world_A_const_107; var tmp22 any; var root_1441 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1443 lang.IFn

















				if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = nm__4; if linked_1442 == nil { tmp22 = ifn_1443.Invoke_O__O(arg_1444) } else { tmp22 = linked_1442.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1441, arg_1444) }
//line :116:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp22) }; case 9: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_129) { var params__4 any; var root_1409 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1411 lang.IFn












					if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any; var root_1404 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var arg_1408 any; var tmp23 any = A_arbace_j2g_world_param_key_fn__78000151_A_New_O(f__0); var tmp24 *jrt.Class; var fncls__1403 *jrt.Class = A_arbace_j2g_world_param_key_fn__78000151_A_fn_class; if fncls__1403 == nil { var fncls__1403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_j2g_world_param_key_fn__78000151_A_fn_class = fncls__1403d; tmp24 = fncls__1403d } else { tmp24 = fncls__1403 }; arg_1408 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O(); if linked_1405 == nil { arg_1412 = ifn_1406.Invoke_O_O__O(arg_1407, arg_1408) } else { arg_1412 = linked_1405.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1404, arg_1407, arg_1408) }; if linked_1410 == nil { params__4 = ifn_1411.Invoke_O__O(arg_1412) } else { params__4 = linked_1410.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1409, arg_1412) }
//line :116:1
					var tmp25 any = A_arbace_j2g_world_A_const_108; var tmp26 any; var root_1454 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1456 lang.IFn
















					if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any; var tmp27 any = A_arbace_j2g_world_param_key_fn__78000153_A_New(); var tmp28 *jrt.Class; var fncls__1449 *jrt.Class = A_arbace_j2g_world_param_key_fn__78000153_A_fn_class; if fncls__1449 == nil { var fncls__1449d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_j2g_world_param_key_fn__78000153_A_fn_class = fncls__1449d; tmp28 = fncls__1449d } else { tmp28 = fncls__1449 }; arg_1457 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_1458 any; var root_1450 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = params__4; if linked_1451 == nil { arg_1458 = ifn_1452.Invoke_O__O(arg_1453) } else { arg_1458 = linked_1451.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1450, arg_1453) }; if linked_1455 == nil { tmp26 = ifn_1456.Invoke_O_O__O(arg_1457, arg_1458) } else { tmp26 = linked_1455.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1454, arg_1457, arg_1458) }
//line :116:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp25, tmp26) }; case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_4) { var tmp29 any = A_arbace_j2g_world_A_const_109; var tmp30 any; var tmp31 *lang.Keyword = A_arbace_j2g_world_A_const_110; var or__1927000174__auto____4 any = tmp31.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0))


















						if jrt.J2g_Truth(or__1927000174__auto____4) { tmp30 = or__1927000174__auto____4 } else { tmp30 = A_arbace_j2g_world_A_const_111 }
//line :116:1
						return lang.Tuple_Create_O_O__IPersistentVector(tmp29, tmp30) }; case 15: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_12) { var tmp32 any = A_arbace_j2g_world_A_const_76; var tmp33 any; var root_1463 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1465 lang.IFn



















							if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any; var root_1459 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = f__0; if linked_1460 == nil { arg_1466 = ifn_1461.Invoke_O__O(arg_1462) } else { arg_1466 = linked_1460.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1459, arg_1462) }; if linked_1464 == nil { tmp33 = ifn_1465.Invoke_O__O(arg_1466) } else { tmp33 = linked_1464.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1463, arg_1466) }
//line :116:1
							return lang.Tuple_Create_O_O__IPersistentVector(tmp32, tmp33) }; default:}; return nil }



func A_arbace_j2g_world_param_key_fn__78000138_A_New_O(p0 any) *A_arbace_j2g_world_param_key_fn__78000138_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000138_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_j2g_world_param_key_fn__78000138_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :120:1
func (t *A_arbace_j2g_world_param_key_fn__78000138_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
										var tmp1 any; var root_1260 any = A_arbace_j2g_world_A_const_55.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = xs__1; if linked_1261 == nil { tmp1 = ifn_1262.Invoke_O__O(arg_1263) } else { tmp1 = linked_1261.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1260, arg_1263) }; if jrt.J2g_Truth(tmp1) { return acc__2 } else { var tmp2 any = A_arbace_j2g_world_A_const_102; var tmp3 any; var root_1264 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1266 lang.IFn
											if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = xs__1; if linked_1265 == nil { tmp3 = ifn_1266.Invoke_O__O(arg_1267) } else { tmp3 = linked_1265.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1264, arg_1267) }
//line :121:1
		if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) {
			var tmp4 any; var root_1268 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = A_arbace_j2g_world_A_const_103; var arg_1272 any = xs__1; if linked_1269 == nil { tmp4 = ifn_1270.Invoke_O_O__O(arg_1271, arg_1272) } else { tmp4 = linked_1269.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_1268, arg_1271, arg_1272) }; xs__1, acc__2 = tmp4, acc__2; continue L1 } else {
//line :121:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp5 any; var root_1273 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = xs__1; if linked_1274 == nil { tmp5 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp5 = linked_1274.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1273, arg_1276) }; var tmp6 any = tmp5; var tmp7 any; var root_1281 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = acc__2; var arg_1285 any; var root_1277 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = xs__1; if linked_1278 == nil { arg_1285 = ifn_1279.Invoke_O__O(arg_1280) } else { arg_1285 = linked_1278.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1277, arg_1280) }; if linked_1282 == nil { tmp7 = ifn_1283.Invoke_O_O__O(arg_1284, arg_1285) } else { tmp7 = linked_1282.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1281, arg_1284, arg_1285) }; xs__1, acc__2 = tmp6, tmp7; continue L1 } else {
//line :121:1
						return nil } } } } }; /*line :120:1*/panic("j2g: unreachable") }
//line :120:1
func A_arbace_j2g_world_param_key_fn__78000146_A_New_O(p0 any) *A_arbace_j2g_world_param_key_fn__78000146_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000146_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_j2g_world_param_key_fn__78000146_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :120:1
func (t *A_arbace_j2g_world_param_key_fn__78000146_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
										var tmp1 any; var root_1320 any = A_arbace_j2g_world_A_const_55.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = xs__1; if linked_1321 == nil { tmp1 = ifn_1322.Invoke_O__O(arg_1323) } else { tmp1 = linked_1321.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1320, arg_1323) }; if jrt.J2g_Truth(tmp1) { return acc__2 } else { var tmp2 any = A_arbace_j2g_world_A_const_102; var tmp3 any; var root_1324 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1326 lang.IFn
											if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = xs__1; if linked_1325 == nil { tmp3 = ifn_1326.Invoke_O__O(arg_1327) } else { tmp3 = linked_1325.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1324, arg_1327) }
//line :121:1
		if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) {
			var tmp4 any; var root_1328 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = A_arbace_j2g_world_A_const_103; var arg_1332 any = xs__1; if linked_1329 == nil { tmp4 = ifn_1330.Invoke_O_O__O(arg_1331, arg_1332) } else { tmp4 = linked_1329.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_1328, arg_1331, arg_1332) }; xs__1, acc__2 = tmp4, acc__2; continue L1 } else {
//line :121:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp5 any; var root_1333 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = xs__1; if linked_1334 == nil { tmp5 = ifn_1335.Invoke_O__O(arg_1336) } else { tmp5 = linked_1334.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1333, arg_1336) }; var tmp6 any = tmp5; var tmp7 any; var root_1341 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = acc__2; var arg_1345 any; var root_1337 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = xs__1; if linked_1338 == nil { arg_1345 = ifn_1339.Invoke_O__O(arg_1340) } else { arg_1345 = linked_1338.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1337, arg_1340) }; if linked_1342 == nil { tmp7 = ifn_1343.Invoke_O_O__O(arg_1344, arg_1345) } else { tmp7 = linked_1342.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1341, arg_1344, arg_1345) }; xs__1, acc__2 = tmp6, tmp7; continue L1 } else {
//line :121:1
						return nil } } } } }; /*line :120:1*/panic("j2g: unreachable") }






func A_arbace_j2g_world_param_key_fn__78000140_A_New() *A_arbace_j2g_world_param_key_fn__78000140_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000140_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_world_param_key_fn__78000140_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_world_param_key_fn__78000140_A) Invoke_O_O__O(self, p1__78000132_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_world_A_const_106; var G__78000141__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__78000132_SHARP___1)); if lang.Util_Identical_O_O__Z_NoInit(G__78000141__2_, nil) { return nil } else { var root_1417 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = G__78000141__2_; if linked_1418 == nil { return ifn_1419.Invoke_O__O(arg_1420) } else { return linked_1418.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1417, arg_1420) } } }
//line :127:1
func A_arbace_j2g_world_param_key_fn__78000148_A_New() *A_arbace_j2g_world_param_key_fn__78000148_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000148_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_world_param_key_fn__78000148_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_world_param_key_fn__78000148_A) Invoke_O_O__O(self, p1__78000132_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_world_A_const_106; var G__78000149__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__78000132_SHARP___1)); if lang.Util_Identical_O_O__Z_NoInit(G__78000149__2_, nil) { return nil } else { var root_1431 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = G__78000149__2_; if linked_1432 == nil { return ifn_1433.Invoke_O__O(arg_1434) } else { return linked_1432.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1431, arg_1434) } } }

func A_arbace_j2g_world_param_key_fn__78000151_A_New_O(p0 any) *A_arbace_j2g_world_param_key_fn__78000151_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000151_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_j2g_world_param_key_fn__78000151_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :129:1
func (t *A_arbace_j2g_world_param_key_fn__78000151_A) Invoke_O__O(self any) any { { var xs__1 any; var root_1373 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any; var t_ any = t.F_f; t.F_f = nil; arg_1376 = t_; if linked_1374 == nil { xs__1 = ifn_1375.Invoke_O__O(arg_1376) } else { xs__1 = linked_1374.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1373, arg_1376) }; var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
										var tmp1 any; var root_1377 any = A_arbace_j2g_world_A_const_55.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = xs__1; if linked_1378 == nil { tmp1 = ifn_1379.Invoke_O__O(arg_1380) } else { tmp1 = linked_1378.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1377, arg_1380) }; if jrt.J2g_Truth(tmp1) { return acc__2 } else { var tmp2 any = A_arbace_j2g_world_A_const_102; var tmp3 any; var root_1381 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1383 lang.IFn
											if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = xs__1; if linked_1382 == nil { tmp3 = ifn_1383.Invoke_O__O(arg_1384) } else { tmp3 = linked_1382.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1381, arg_1384) }
//line :130:1
		if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) {
			var tmp4 any; var root_1385 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = A_arbace_j2g_world_A_const_103; var arg_1389 any = xs__1; if linked_1386 == nil { tmp4 = ifn_1387.Invoke_O_O__O(arg_1388, arg_1389) } else { tmp4 = linked_1386.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_1385, arg_1388, arg_1389) }; xs__1, acc__2 = tmp4, acc__2; continue L1 } else {
//line :130:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp5 any; var root_1390 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = xs__1; if linked_1391 == nil { tmp5 = ifn_1392.Invoke_O__O(arg_1393) } else { tmp5 = linked_1391.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1390, arg_1393) }; var tmp6 any = tmp5; var tmp7 any; var root_1398 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = acc__2; var arg_1402 any; var root_1394 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = xs__1; if linked_1395 == nil { arg_1402 = ifn_1396.Invoke_O__O(arg_1397) } else { arg_1402 = linked_1395.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1394, arg_1397) }; if linked_1399 == nil { tmp7 = ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { tmp7 = linked_1399.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) }; xs__1, acc__2 = tmp6, tmp7; continue L1 } else {
//line :130:1
						return nil } } } } }; /*line :129:1*/panic("j2g: unreachable") }



func A_arbace_j2g_world_param_key_fn__78000153_A_New() *A_arbace_j2g_world_param_key_fn__78000153_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000153_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_j2g_world_param_key_fn__78000153_A) Ctor() {}
//line :133:1
func (t *A_arbace_j2g_world_param_key_fn__78000153_A) Invoke_O_O__O(self, p1__78000133_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_world_A_const_106; var G__78000154__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__78000133_SHARP___1)); if lang.Util_Identical_O_O__Z_NoInit(G__78000154__2_, nil) { return nil } else { var root_1445 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = G__78000154__2_; if linked_1446 == nil { return ifn_1447.Invoke_O__O(arg_1448) } else { return linked_1446.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1445, arg_1448) } } }





func A_arbace_j2g_world_cut_key_A_New() *A_arbace_j2g_world_cut_key_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_cut_key_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_world_cut_key_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_world_cut_key_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1467 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1469 lang.IFn
	if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = x__0; if linked_1468 == nil { and__1927000168__auto____2 = ifn_1469.Invoke_O__O(arg_1470) } else { and__1927000168__auto____2 = linked_1468.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1467, arg_1470) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_1471 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = x__0; if linked_1472 == nil { tmp2 = ifn_1473.Invoke_O__O(arg_1474) } else { tmp2 = linked_1472.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1471, arg_1474) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_19, tmp2)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :140:1
	if jrt.J2g_Truth(tmp1) {
		var root_1475 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = x__0; if linked_1476 == nil { return ifn_1477.Invoke_O__O(arg_1478) } else { return linked_1476.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1475, arg_1478) } } else {
//line :140:1
			var tmp3 any; var and__1927000168__auto____2_2 any; var root_1479 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1481 lang.IFn


			if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = x__0; if linked_1480 == nil { and__1927000168__auto____2_2 = ifn_1481.Invoke_O__O(arg_1482) } else { and__1927000168__auto____2_2 = linked_1480.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1479, arg_1482) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp4 any; var root_1483 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = x__0; if linked_1484 == nil { tmp4 = ifn_1485.Invoke_O__O(arg_1486) } else { tmp4 = linked_1484.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1483, arg_1486) }; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_4, tmp4)).Ref() } else { tmp3 = and__1927000168__auto____2_2 }
//line :140:1
			if jrt.J2g_Truth(tmp3) { var tmp5 any = A_arbace_j2g_world_A_const_109; var tmp6 any; var or__1927000174__auto____2 any; var root_1513 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1515 lang.IFn


				if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = x__0; if linked_1514 == nil { or__1927000174__auto____2 = ifn_1515.Invoke_O__O(arg_1516) } else { or__1927000174__auto____2 = linked_1514.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1513, arg_1516) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp6 = or__1927000174__auto____2 } else { tmp6 = A_arbace_j2g_world_A_const_111 }
//line :140:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6) } else { var tmp7 any; var root_1491 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1493 lang.IFn



					if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any; var root_1487 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = x__0; if linked_1488 == nil { arg_1494 = ifn_1489.Invoke_O__O(arg_1490) } else { arg_1494 = linked_1488.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1487, arg_1490) }; if linked_1492 == nil { tmp7 = ifn_1493.Invoke_O__O(arg_1494) } else { tmp7 = linked_1492.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1491, arg_1494) }
//line :140:1
					if jrt.J2g_Truth(tmp7) {



						var root_1500 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any; var root_1495 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = A_arbace_j2g_world_A_const_113; var arg_1499 any = x__0; if linked_1496 == nil { arg_1503 = ifn_1497.Invoke_O_O__O(arg_1498, arg_1499) } else { arg_1503 = linked_1496.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1495, arg_1498, arg_1499) }; if linked_1501 == nil { return ifn_1502.Invoke_O__O(arg_1503) } else { return linked_1501.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1500, arg_1503) } } else {
//line :140:1
							if A_arbace_j2g_world_A_const_88 != nil { var tmp8 any; var root_1508 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1510 lang.IFn




								if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_world_A_const_79.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var arg_1512 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1509 == nil { tmp8 = ifn_1510.Invoke_O_O__O(arg_1511, arg_1512) } else { tmp8 = linked_1509.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1508, arg_1511, arg_1512) }
//line :140:1
								panic(jrt.Thrown(jrt.Throwable_Cast(tmp8))) } else { return nil
								}
						}
				}
		}
}

func A_arbace_j2g_world_class_parts_A_New() *A_arbace_j2g_world_class_parts_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_parts_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_j2g_world_class_parts_A) Ctor() {}
//line :147:1
func (t *A_arbace_j2g_world_class_parts_A) Invoke_O_O__O(self, cf__0 any) any { var vec__78000158__2 any = cf__0; var seq__78000159__3 any; var root_1517 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1519 lang.IFn; if


	linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = vec__78000158__2; if linked_1518 == nil { seq__78000159__3 = ifn_1519.Invoke_O__O(arg_1520) } else { seq__78000159__3 = linked_1518.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1517, arg_1520) }; var first__78000160__4 any; var root_1521 any = /*line :147:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1523 lang.IFn; if


	linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = seq__78000159__3; if linked_1522 == nil { first__78000160__4 = ifn_1523.Invoke_O__O(arg_1524) } else { first__78000160__4 = linked_1522.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1521, arg_1524) }; var seq__78000159__5 any; var root_1525 any = /*line :147:1*/A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1527 lang.IFn; if


	linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = seq__78000159__3; if linked_1526 == nil { seq__78000159__5 = ifn_1527.Invoke_O__O(arg_1528) } else { seq__78000159__5 = linked_1526.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1525, arg_1528) }; var dc__6 any = first__78000160__4; var first__78000160__7 any; var root_1529 any = /*line :147:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1531 lang.IFn; if


	linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any = seq__78000159__5; if linked_1530 == nil { first__78000160__7 = ifn_1531.Invoke_O__O(arg_1532) } else { first__78000160__7 = linked_1530.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1529, arg_1532) }; var seq__78000159__8 any; var root_1533 any = /*line :147:1*/A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1535 lang.IFn; if


	linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = seq__78000159__5; if linked_1534 == nil { seq__78000159__8 = ifn_1535.Invoke_O__O(arg_1536) } else { seq__78000159__8 = linked_1534.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1533, arg_1536) }; var nm__9 any = first__78000160__7; var more__10 any = seq__78000159__8; var vec__78000161__11 any; var tmp1 any; var root_1541 any = /*line :147:1*/A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1543 lang.IFn; if



	linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any; var root_1537 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = more__10; if linked_1538 == nil { arg_1544 = ifn_1539.Invoke_O__O(arg_1540) } else { arg_1544 = linked_1538.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1537, arg_1540) }; if linked_1542 == nil { tmp1 = ifn_1543.Invoke_O__O(arg_1544) } else { tmp1 = linked_1542.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1541, arg_1544) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1553 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = more__10; if linked_1554 == nil { tmp2 = ifn_1555.Invoke_O__O(arg_1556) } else { tmp2 = linked_1554.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1553, arg_1556) }; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(tmp2); var tmp4 any; var root_1549 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = more__10; if linked_1550 == nil { tmp4 = ifn_1551.Invoke_O__O(arg_1552) } else { tmp4 = linked_1550.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1549, arg_1552) }; vec__78000161__11 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { vec__78000161__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.PersistentVector_EMPTY.Ref(), more__10) }; var comps__12 any = /*line :147:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__78000161__11, lang.RT_IntCast_J__I_NoInit(0), nil); var more__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000161__11, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__78000164__14 any; var root_1545 any = A_arbace_j2g_world_A_const_84.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A_fn_class); var ifn_1547 lang.IFn; if




	linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = more__13; if linked_1546 == nil { vec__78000164__14 = ifn_1547.Invoke_O__O(arg_1548) } else { vec__78000164__14 = linked_1546.(*aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A).Invoke_O_O__O(root_1545, arg_1548) }; var opts__15 any = /*line :147:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__78000164__14, lang.RT_IntCast_J__I_NoInit(0), nil); var members__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000164__14, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(dc__6, nm__9), comps__12, lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_world_A_const_114.GetRawRoot__O(), opts__15)); var tmp6 any; var root_1568 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1570 lang.IFn; if





	linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = members__16; if linked_1569 == nil { tmp6 = ifn_1570.Invoke_O__O(arg_1571) } else { tmp6 = linked_1569.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1568, arg_1571) }; return /*line :147:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6) }







func A_arbace_j2g_world_apply_variant_A_New() *A_arbace_j2g_world_apply_variant_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_j2g_world_apply_variant_A) Ctor() {}
//line :155:1
func (t *A_arbace_j2g_world_apply_variant_A) Invoke_O_O_O_O_O_O__O(self, cf__0, vforms__1, prefix__2, variants_of__3, applied__4 any) any { var vec__78000170__6 any; var root_1572 any = A_arbace_j2g_world_A_const_115.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, A_arbace_j2g_world_class_parts_A_fn_class); var ifn_1574 lang.IFn; if







	linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = cf__0; if linked_1573 == nil { vec__78000170__6 = ifn_1574.Invoke_O__O(arg_1575) } else { vec__78000170__6 = linked_1573.(*A_arbace_j2g_world_class_parts_A).Invoke_O_O__O(root_1572, arg_1575) }; var head__7 any = /*line :155:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__78000170__6, lang.RT_IntCast_J__I_NoInit(0), nil); var members__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000170__6, lang.RT_IntCast_J__I_NoInit(1), nil); var members__9 any; var n__9 any; var root_1576 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1578 lang.IFn; if









	linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = A_arbace_j2g_world_A_const_116; if linked_1577 == nil { n__9 = ifn_1578.Invoke_O__O(arg_1579) } else { n__9 = linked_1577.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1576, arg_1579) }; var root_1597 any =
	A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any; var tmp1 any = A_arbace_j2g_world_apply_variant_fn__78000173_A_New_O(n__9); var tmp2 *jrt.Class; var fncls__1596 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000173_A_fn_class; if fncls__1596 == nil { var fncls__1596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_j2g_world_apply_variant_fn__78000173_A_fn_class = fncls__1596d; tmp2 = fncls__1596d } else { tmp2 = fncls__1596 }; arg_1600 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1601 any = members__8; if linked_1598 == nil { members__9 = ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { members__9 = linked_1598.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) }; var counts__10 any; var root_1602 any = /*line :155:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1604 lang.IFn; if














	linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = A_arbace_j2g_world_A_const_120; if linked_1603 == nil { counts__10 = ifn_1604.Invoke_O__O(arg_1605) } else { counts__10 = linked_1603.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1602, arg_1605) }; var members__11 any; var root_1732 any = /*line :155:1*/A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1734 lang.IFn; if















	linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any; var tmp3 any = A_arbace_j2g_world_apply_variant_fn__78000175_A_New_O(counts__10); var tmp4 *jrt.Class; var fncls__1731 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000175_A_fn_class; if
	fncls__1731 == nil { var fncls__1731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_world_apply_variant_fn__78000175_A_fn_class = fncls__1731d; tmp4 = fncls__1731d } else { tmp4 = fncls__1731 }; arg_1735 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1736 any = members__9; var arg_1737 any = vforms__1; if /*line :171:1*/ linked_1733 == nil { members__11 = ifn_1734.Invoke_O_O_O__O(arg_1735, arg_1736, arg_1737) } else { members__11 = linked_1733.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1732, arg_1735, arg_1736, arg_1737) }; var members__12 any; if

















	jrt.J2g_Truth(variants_of__3) {
		var root_1766 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any; var tmp5 any = A_arbace_j2g_world_apply_variant_fn__78000184_A_New_O_O_O(variants_of__3, prefix__2, applied__4); var tmp6 *jrt.Class; var fncls__1765 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000184_A_fn_class; if fncls__1765 == nil { var fncls__1765d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_world_apply_variant_fn__78000184_A_fn_class = fncls__1765d; tmp6 = fncls__1765d } else { tmp6 = fncls__1765 }; arg_1769 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1770 any = members__11; if linked_1767 == nil { members__12 = ifn_1768.Invoke_O_O__O(arg_1769, arg_1770) } else { members__12 = linked_1767.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1766, arg_1769, arg_1770) } } else {
//line :189:1
			members__12 = members__11 }; var tmp7 any; var root_1781 any = /*line :155:1*/A_arbace_j2g_world_A_const_67.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1783 lang.IFn; if












































	linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any; var root_1776 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1776, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1778 lang.IFn; if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = A_arbace_j2g_world_A_const_69.GetRawRoot__O(); var arg_1780 any; var root_1771 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = head__7; var arg_1775 any = members__12; if linked_1772 == nil { arg_1780 = ifn_1773.Invoke_O_O__O(arg_1774, arg_1775) } else { arg_1780 = linked_1772.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1771, arg_1774, arg_1775) }; if linked_1777 == nil { arg_1784 = ifn_1778.Invoke_O_O__O(arg_1779, arg_1780) } else { arg_1784 = linked_1777.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1776, arg_1779, arg_1780) }; var arg_1785 any = lang.RT_Meta_O__IPersistentMap_NoInit(cf__0); if linked_1782 == nil { tmp7 = ifn_1783.Invoke_O_O__O(arg_1784, arg_1785) } else { tmp7 = linked_1782.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1781, arg_1784, arg_1785) }; var tmp8 any = tmp7; var tmp9 any; var root_1786 any = /*line :155:1*/A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1788 lang.IFn; if







	linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = counts__10; if linked_1787 == nil { tmp9 = ifn_1788.Invoke_O__O(arg_1789) } else { tmp9 = linked_1787.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1786, arg_1789) }; return /*line :155:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) }
//line :155:1
func (t *A_arbace_j2g_world_apply_variant_A) Invoke_O_O_O__O(self, cf__0, vforms__1 any) any {





	var root_1790 any = A_arbace_j2g_world_A_const_128.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, A_arbace_j2g_world_apply_variant_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = cf__0; var arg_1794 any = vforms__1; var arg_1795 any; var arg_1796 any; var arg_1797 any; if linked_1791 == nil { return ifn_1792.Invoke_O_O_O_O_O__O(arg_1793, arg_1794, arg_1795, arg_1796, arg_1797) } else { return linked_1791.(*A_arbace_j2g_world_apply_variant_A).Invoke_O_O_O_O_O_O__O(root_1790, arg_1793, arg_1794, arg_1795, arg_1796, arg_1797)
	}
}


func A_arbace_j2g_world_apply_variant_fn__78000173_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000173_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000173_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000173_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :166:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000173_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any; var root_1580 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = m__1; if linked_1581 == nil { tmp1 = ifn_1582.Invoke_O__O(arg_1583) } else { tmp1 = linked_1581.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1580, arg_1583) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_4, tmp1) {
												var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_117.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var tmp4 any = A_arbace_j2g_world_A_const_110; var tmp5 any; var root_1584 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1584, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = t.F_n; var arg_1588 any = A_arbace_j2g_world_A_const_119.GetRawRoot__O(); if linked_1585 == nil { tmp5 = ifn_1586.Invoke_O_O__O(arg_1587, arg_1588) } else { tmp5 = linked_1585.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1584, arg_1587, arg_1588) }; return tmp2.Invoke_O_O_O_O__O(m__1, tmp3, tmp4, tmp5) } else {
//line :166:1
		return m__1 } }





func A_arbace_j2g_world_apply_variant_fn__78000175_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000175_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000175_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_A) Ctor_O(c__counts any) { t.F_counts = c__counts }
//line :172:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_A) Invoke_O_O_O__O(self, ms__1, vf__2 any) any { var G__78000176__3_ any; var root_1606 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1608 lang.IFn; if
													linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = vf__2; if linked_1607 == nil { G__78000176__3_ = ifn_1608.Invoke_O__O(arg_1609) } else { G__78000176__3_ = linked_1607.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1606, arg_1609) }; switch lang.Util_Hash_O__I_NoInit(G__78000176__3_) { case 96417: if lang.Util_Equiv_O_O__Z_NoInit(G__78000176__3_, Lit_5) {







		var root_1688 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = t.F_counts; var arg_1692 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var arg_1693 any = A_arbace_j2g_world_A_const_125; var arg_1694 any = A_arbace_j2g_world_A_const_119.GetRawRoot__O(); if linked_1689 == nil { ifn_1690.Invoke_O_O_O_O__O(arg_1691, arg_1692, arg_1693, arg_1694) } else { linked_1689.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1688, arg_1691, arg_1692, arg_1693, arg_1694) }; var root_1615 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1615, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1617 lang.IFn; if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any = ms__1; var arg_1619 any; var root_1611 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = vf__2; if linked_1612 == nil { arg_1619 = ifn_1613.Invoke_O__O(arg_1614) } else { arg_1619 = linked_1612.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1611, arg_1614) }; if linked_1616 == nil { return ifn_1617.Invoke_O_O__O(arg_1618, arg_1619) } else { return linked_1616.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1615, arg_1618, arg_1619) } }
//line :173:1
	case 98882: if lang.Util_Equiv_O_O__Z_NoInit(G__78000176__3_, Lit_6) { var k__4 any; var root_1636 any = A_arbace_j2g_world_A_const_122.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, A_arbace_j2g_world_cut_key_A_fn_class); var ifn_1638 lang.IFn


		if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any; var tmp1 any; var root_1624 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any; var root_1620 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = vf__2; if linked_1621 == nil { arg_1627 = ifn_1622.Invoke_O__O(arg_1623) } else { arg_1627 = linked_1621.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1620, arg_1623) }; if linked_1625 == nil { tmp1 = ifn_1626.Invoke_O__O(arg_1627) } else { tmp1 = linked_1625.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1624, arg_1627) }; if jrt.J2g_Truth(tmp1) { var root_1628 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = vf__2; if linked_1629 == nil { arg_1639 = ifn_1630.Invoke_O__O(arg_1631) } else { arg_1639 = linked_1629.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1628, arg_1631) } } else { var root_1632 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = vf__2; if linked_1633 == nil { arg_1639 = ifn_1634.Invoke_O__O(arg_1635) } else { arg_1639 = linked_1633.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1632, arg_1635) } }; if linked_1637 == nil { k__4 = ifn_1638.Invoke_O__O(arg_1639) } else { k__4 = linked_1637.(*A_arbace_j2g_world_cut_key_A).Invoke_O_O__O(root_1636, arg_1639) }
//line :173:1
		var hit__5 any; var root_1645 any = A_arbace_j2g_world_A_const_123.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1647 lang.IFn



		if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any; var tmp2 any = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_New_O(k__4); var tmp3 *jrt.Class; var fncls__1644 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_fn_class; if fncls__1644 == nil { var fncls__1644d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_fn_class = fncls__1644d; tmp3 = fncls__1644d } else { tmp3 = fncls__1644 }; arg_1648 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1649 any = ms__1; if linked_1646 == nil { hit__5 = ifn_1647.Invoke_O_O__O(arg_1648, arg_1649) } else { hit__5 = linked_1646.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1645, arg_1648, arg_1649) }
		if jrt.J2g_Truth(hit__5) { } else { var tmp4 any; var root_1703 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_8, nil); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_79.GetRawRoot__O()); var tmp7 any; var root_1695 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = vf__2; if linked_1696 == nil { tmp7 = ifn_1697.Invoke_O__O(arg_1698) } else { tmp7 = linked_1696.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1695, arg_1698) }; arg_1706 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6.Invoke_O__O(tmp7))).Ref(); var arg_1707 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1704 == nil { tmp4 = ifn_1705.Invoke_O_O__O(arg_1706, arg_1707) } else { tmp4 = linked_1704.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1703, arg_1706, arg_1707) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) }
		var root_1708 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = t.F_counts; var arg_1712 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var arg_1713 any = A_arbace_j2g_world_A_const_126; var arg_1714 any = A_arbace_j2g_world_A_const_119.GetRawRoot__O(); if linked_1709 == nil { ifn_1710.Invoke_O_O_O_O__O(arg_1711, arg_1712, arg_1713, arg_1714) } else { linked_1709.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1708, arg_1711, arg_1712, arg_1713, arg_1714) }
		var root_1660 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any; var root_1655 any = A_arbace_j2g_world_A_const_77.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1657 lang.IFn; if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any; var tmp8 any = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_New_O(k__4); var tmp9 *jrt.Class; var fncls__1654 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_fn_class; if fncls__1654 == nil { var fncls__1654d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_fn_class = fncls__1654d; tmp9 = fncls__1654d } else { tmp9 = fncls__1654 }; arg_1658 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_1659 any = ms__1; if linked_1656 == nil { arg_1663 = ifn_1657.Invoke_O_O__O(arg_1658, arg_1659) } else { arg_1663 = linked_1656.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1655, arg_1658, arg_1659) }; if linked_1661 == nil { return ifn_1662.Invoke_O__O(arg_1663) } else { return linked_1661.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1660, arg_1663) } }
//line :173:1
	default:}; var k__4_2 any; var root_1664 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1666 lang.IFn; if








	linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = vf__2; if linked_1665 == nil { k__4_2 = ifn_1666.Invoke_O__O(arg_1667) } else { k__4_2 = linked_1665.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1664, arg_1667) }; var i__5 any; var root_1678 any = /*line :173:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1680 lang.IFn; if









	linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any; var root_1673 any = A_arbace_j2g_world_A_const_124.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any; var tmp10 any = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_New_O(k__4_2); var tmp11 *jrt.Class; var fncls__1672 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_fn_class; if fncls__1672 == nil { var fncls__1672d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_fn_class = fncls__1672d; tmp11 = fncls__1672d } else { tmp11 = fncls__1672 }; arg_1676 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1677 any = ms__1; if linked_1674 == nil { arg_1681 = ifn_1675.Invoke_O_O__O(arg_1676, arg_1677) } else { arg_1681 = linked_1674.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_1673, arg_1676, arg_1677) }; if linked_1679 == nil { i__5 = ifn_1680.Invoke_O__O(arg_1681) } else { i__5 = linked_1679.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1678, arg_1681) }; if
	jrt.J2g_Truth(i__5) { } else { var tmp12 any; var root_1719 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_world_A_const_79.GetRawRoot__O()).Invoke_O__O(k__4_2))).Ref(); var arg_1723 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1720 == nil { tmp12 = ifn_1721.Invoke_O_O__O(arg_1722, arg_1723) } else { tmp12 = linked_1720.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1719, arg_1722, arg_1723) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp12))) }; var root_1724 any =
	A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = t.F_counts; var arg_1728 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var arg_1729 any = A_arbace_j2g_world_A_const_127; var arg_1730 any = A_arbace_j2g_world_A_const_119.GetRawRoot__O(); if linked_1725 == nil { ifn_1726.Invoke_O_O_O_O__O(arg_1727, arg_1728, arg_1729, arg_1730) } else { linked_1725.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1724, arg_1727, arg_1728, arg_1729, arg_1730) }; var root_1682 any =
	A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = ms__1; var arg_1686 any = i__5; var arg_1687 any = vf__2; if linked_1683 == nil { return ifn_1684.Invoke_O_O_O__O(arg_1685, arg_1686, arg_1687) } else { return linked_1683.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1682, arg_1685, arg_1686, arg_1687) } }
//line :177:1
func A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :177:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A) Invoke_O_O__O(self, p1__78000168_SHARP___1 any) any { var tmp1 any = t.F_k; var tmp2 any; var root_1640 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = p1__78000168_SHARP___1; if linked_1641 == nil { tmp2 = ifn_1642.Invoke_O__O(arg_1643) } else { tmp2 = linked_1641.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1640, arg_1643) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }


func A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :180:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A) Invoke_O_O__O(self, p1__78000169_SHARP___1 any) any { var tmp1 any = t.F_k; var tmp2 any; var root_1650 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = p1__78000169_SHARP___1; if linked_1651 == nil { tmp2 = ifn_1652.Invoke_O__O(arg_1653) } else { tmp2 = linked_1651.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1650, arg_1653) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }


func A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :183:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A) Invoke_O_O_O__O(self, i__1, m__2 any) any { var tmp1 any = t.F_k; var tmp2 any; var root_1668 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = m__2; if linked_1669 == nil { tmp2 = ifn_1670.Invoke_O__O(arg_1671) } else { tmp2 = linked_1669.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1668, arg_1671) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { return i__1 } else { return nil } }






func A_arbace_j2g_world_apply_variant_fn__78000184_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_apply_variant_fn__78000184_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000184_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :190:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000184_A) Ctor_O_O_O(c__variants_of, c__prefix, c__applied any) { t.F_variants_of = c__variants_of; t.F_prefix = c__prefix; t.F_applied = c__applied }
//line :190:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000184_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var root_1738 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = m__1; if linked_1739 == nil { tmp1 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp1 = linked_1739.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1738, arg_1741) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_12, tmp1) { var nn__2 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil); var tmp3 any = t.F_prefix; var tmp4 any; var root_1746 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1748 lang.IFn
		if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any; var root_1742 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = m__1; if linked_1743 == nil { arg_1749 = ifn_1744.Invoke_O__O(arg_1745) } else { arg_1749 = linked_1743.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1742, arg_1745) }; if linked_1747 == nil { tmp4 = ifn_1748.Invoke_O__O(arg_1749) } else { tmp4 = linked_1747.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1746, arg_1749) }; nn__2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()
//line :191:1
		var vfs__3 any = lang.IFn_Cast(t.F_variants_of).Invoke_O__O(nn__2); var vec__78000185__4 any; var root_1750 any = A_arbace_j2g_world_A_const_128.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, A_arbace_j2g_world_apply_variant_A_fn_class); var ifn_1752 lang.IFn


		if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = m__1; var arg_1754 any; var or__1927000174__auto____4 any = vfs__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_1754 = or__1927000174__auto____4 } else { arg_1754 = lang.PersistentVector_EMPTY.Ref() }; var arg_1755 any = nn__2; var arg_1756 any = t.F_variants_of; var arg_1757 any = t.F_applied; if linked_1751 == nil { vec__78000185__4 = ifn_1752.Invoke_O_O_O_O_O__O(arg_1753, arg_1754, arg_1755, arg_1756, arg_1757) } else { vec__78000185__4 = linked_1751.(*A_arbace_j2g_world_apply_variant_A).Invoke_O_O_O_O_O_O__O(root_1750, arg_1753, arg_1754, arg_1755, arg_1756, arg_1757) }
//line :191:1
		var m2__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000185__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000185__4, lang.RT_IntCast_J__I_NoInit(1), nil)



		if jrt.J2g_Truth(vfs__3) { var root_1758 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = t.F_applied; var arg_1762 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var arg_1763 any = nn__2; var arg_1764 any = c__6; if linked_1759 == nil { ifn_1760.Invoke_O_O_O_O__O(arg_1761, arg_1762, arg_1763, arg_1764) } else { linked_1759.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1758, arg_1761, arg_1762, arg_1763, arg_1764) } }
//line :191:1
		return m2__5 } else { return m__1
		}
}








func A_arbace_j2g_world_read_variants_A_New() *A_arbace_j2g_world_read_variants_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_variants_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_j2g_world_read_variants_A) Ctor() {}
//line :202:1
func (t *A_arbace_j2g_world_read_variants_A) Invoke_O_O__O(self, files__0 any) any {





	var root_1901 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any; var tmp1 any = A_arbace_j2g_world_read_variants_fn__78000190_A_New(); var tmp2 *jrt.Class; var fncls__1900 *jrt.Class = A_arbace_j2g_world_read_variants_fn__78000190_A_fn_class; if fncls__1900 == nil { var fncls__1900d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_j2g_world_read_variants_fn__78000190_A_fn_class = fncls__1900d; tmp2 = fncls__1900d } else { tmp2 = fncls__1900 }; arg_1904 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1905 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1906 any = files__0; if linked_1902 == nil { return ifn_1903.Invoke_O_O_O__O(arg_1904, arg_1905, arg_1906) } else { return linked_1902.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1901, arg_1904, arg_1905, arg_1906) } }
//line :208:1
func A_arbace_j2g_world_read_variants_fn__78000190_A_New() *A_arbace_j2g_world_read_variants_fn__78000190_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_variants_fn__78000190_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_j2g_world_read_variants_fn__78000190_A) Ctor() {}
//line :208:1
func (t *A_arbace_j2g_world_read_variants_fn__78000190_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any { var forms__3 any; var root_1798 any = A_arbace_j2g_world_A_const_129.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, A_arbace_j2g_world_read_forms_A_fn_class); var ifn_1800 lang.IFn; if
													linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = f__2; if linked_1799 == nil { forms__3 = ifn_1800.Invoke_O__O(arg_1801) } else { forms__3 = linked_1799.(*A_arbace_j2g_world_read_forms_A).Invoke_O_O__O(root_1798, arg_1801) }; var nsname__4 any; var root_1802 any = /*line :208:1*/A_arbace_j2g_world_A_const_130.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, A_arbace_j2g_world_ns_of_forms_A_fn_class); var ifn_1804 lang.IFn; if

	linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = forms__3; if linked_1803 == nil { nsname__4 = ifn_1804.Invoke_O__O(arg_1805) } else { nsname__4 = linked_1803.(*A_arbace_j2g_world_ns_of_forms_A).Invoke_O_O__O(root_1802, arg_1805) }; var root_1894 any =
	A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1896 lang.IFn; if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any; var tmp1 any = A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_New_O(nsname__4); var tmp2 *jrt.Class; var fncls__1893 *jrt.Class = A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_fn_class; if fncls__1893 == nil { var fncls__1893d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_fn_class = fncls__1893d; tmp2 = fncls__1893d } else { tmp2 = fncls__1893 }; arg_1897 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1898 any = acc__1; var arg_1899 any = forms__3; if linked_1895 == nil { return ifn_1896.Invoke_O_O_O__O(arg_1897, arg_1898, arg_1899) } else { return linked_1895.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1894, arg_1897, arg_1898, arg_1899) } }
//line :211:1
func A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_New_O(p0 any) *A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A{}; t.Ctor_O(p0); return t }
//line :211:1
func (t *A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :211:1
func (t *A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A) Invoke_O_O_O__O(self, acc__1, fm__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any; var root_1806 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1808 lang.IFn
	if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any = fm__2; if linked_1807 == nil { and__1927000168__auto____3 = ifn_1808.Invoke_O__O(arg_1809) } else { and__1927000168__auto____3 = linked_1807.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1806, arg_1809) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 any; var root_1810 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = fm__2; if linked_1811 == nil { tmp2 = ifn_1812.Invoke_O__O(arg_1813) } else { tmp2 = linked_1811.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1810, arg_1813) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_139, tmp2)).Ref() } else { tmp1 = and__1927000168__auto____3 }
//line :212:1
	if jrt.J2g_Truth(tmp1) { var vec__78000192__3 any = fm__2; var seq__78000193__4 any; var root_1814 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1816 lang.IFn

		if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = vec__78000192__3; if linked_1815 == nil { seq__78000193__4 = ifn_1816.Invoke_O__O(arg_1817) } else { seq__78000193__4 = linked_1815.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1814, arg_1817) }
//line :212:1
		var first__78000194__5 any; var root_1818 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1820 lang.IFn

		if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = seq__78000193__4; if linked_1819 == nil { first__78000194__5 = ifn_1820.Invoke_O__O(arg_1821) } else { first__78000194__5 = linked_1819.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1818, arg_1821) }
//line :212:1
		var seq__78000193__6 any; var root_1822 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1824 lang.IFn

		if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = seq__78000193__4; if linked_1823 == nil { seq__78000193__6 = ifn_1824.Invoke_O__O(arg_1825) } else { seq__78000193__6 = linked_1823.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1822, arg_1825) }
//line :212:1
		var ___7 any = first__78000194__5; var first__78000194__8 any; var root_1826 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1828 lang.IFn; _ = ___7

		if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = seq__78000193__6; if linked_1827 == nil { first__78000194__8 = ifn_1828.Invoke_O__O(arg_1829) } else { first__78000194__8 = linked_1827.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1826, arg_1829) }
//line :212:1
		var seq__78000193__9 any; var root_1830 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1832 lang.IFn

		if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = seq__78000193__6; if linked_1831 == nil { seq__78000193__9 = ifn_1832.Invoke_O__O(arg_1833) } else { seq__78000193__9 = linked_1831.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1830, arg_1833) }
//line :212:1
		var cls__10 any = first__78000194__8; var members__11 any = seq__78000193__9; var n__12 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140, nil); var tmp4 any; var root_1842 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1844 lang.IFn


		if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any; var root_1838 any = A_arbace_j2g_world_A_const_89.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_1840 lang.IFn; if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any; var root_1834 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = t.F_nsname; if linked_1835 == nil { arg_1841 = ifn_1836.Invoke_O__O(arg_1837) } else { arg_1841 = linked_1835.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1834, arg_1837) }; if linked_1839 == nil { arg_1845 = ifn_1840.Invoke_O__O(arg_1841) } else { arg_1845 = linked_1839.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_1838, arg_1841) }; var arg_1846 any = Lit_141; var arg_1847 any = Lit_140; if linked_1843 == nil { tmp4 = ifn_1844.Invoke_O_O_O__O(arg_1845, arg_1846, arg_1847) } else { tmp4 = linked_1843.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1842, arg_1845, arg_1846, arg_1847) }; var tmp5 any = tmp4; var tmp6 any; var root_1848 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = cls__10; if linked_1849 == nil { tmp6 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp6 = linked_1849.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1848, arg_1851) }; n__12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, tmp6)).Ref()
		var root_1857 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = acc__1; var arg_1861 any = n__12; var arg_1862 any; var root_1852 any = A_arbace_j2g_world_A_const_131.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_1856 any = lang.PersistentVector_EMPTY.Ref(); if linked_1853 == nil { arg_1862 = ifn_1854.Invoke_O_O__O(arg_1855, arg_1856) } else { arg_1862 = linked_1853.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1852, arg_1855, arg_1856) }; var arg_1863 any = members__11; if linked_1858 == nil { return ifn_1859.Invoke_O_O_O_O__O(arg_1860, arg_1861, arg_1862, arg_1863) } else { return linked_1858.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1857, arg_1860, arg_1861, arg_1862, arg_1863) } } else {
//line :212:1
			var tmp7 any; var and__1927000168__auto____3_2 any; var root_1864 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1866 lang.IFn




			if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = fm__2; if linked_1865 == nil { and__1927000168__auto____3_2 = ifn_1866.Invoke_O__O(arg_1867) } else { and__1927000168__auto____3_2 = linked_1865.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1864, arg_1867) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp8 any; var root_1868 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1868, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1870 lang.IFn; if linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any = fm__2; if linked_1869 == nil { tmp8 = ifn_1870.Invoke_O__O(arg_1871) } else { tmp8 = linked_1869.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1868, arg_1871) }; tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_142, tmp8)).Ref() } else { tmp7 = and__1927000168__auto____3_2 }
//line :212:1
			if jrt.J2g_Truth(tmp7) {





				var root_1886 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1888 lang.IFn; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any = acc__1; var arg_1890 any = A_arbace_j2g_world_A_const_132; var arg_1891 any; var root_1872 any = A_arbace_j2g_world_A_const_131.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_1876 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1873 == nil { arg_1891 = ifn_1874.Invoke_O_O__O(arg_1875, arg_1876) } else { arg_1891 = linked_1873.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1872, arg_1875, arg_1876) }; var arg_1892 any; var root_1881 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var arg_1885 any; var root_1877 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = fm__2; if linked_1878 == nil { arg_1885 = ifn_1879.Invoke_O__O(arg_1880) } else { arg_1885 = linked_1878.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1877, arg_1880) }; if linked_1882 == nil { arg_1892 = ifn_1883.Invoke_O_O__O(arg_1884, arg_1885) } else { arg_1892 = linked_1882.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1881, arg_1884, arg_1885) }; if linked_1887 == nil { return ifn_1888.Invoke_O_O_O_O__O(arg_1889, arg_1890, arg_1891, arg_1892) } else { return linked_1887.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1886, arg_1889, arg_1890, arg_1891, arg_1892) } } else {
//line :212:1
					if A_arbace_j2g_world_A_const_88 != nil { return acc__1 } else { return nil
					}
				}
		}
}






func A_arbace_j2g_world_new_unit_A_New() *A_arbace_j2g_world_new_unit_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_new_unit_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_j2g_world_new_unit_A) Ctor() {}
//line :223:1
func (t *A_arbace_j2g_world_new_unit_A) Invoke_O__O(self any) any { var tmp1 any = A_arbace_j2g_world_A_const_133; var tmp2 any; var root_1907 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1909 lang.IFn; if
									linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = lang.PersistentVector_EMPTY.Ref(); if linked_1908 == nil { tmp2 = ifn_1909.Invoke_O__O(arg_1910) } else { tmp2 = linked_1908.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1907, arg_1910) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_j2g_world_A_const_134; var tmp5 any; var root_1911 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1913 lang.IFn; if
									linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1912 == nil { tmp5 = ifn_1913.Invoke_O__O(arg_1914) } else { tmp5 = linked_1912.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1911, arg_1914) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_j2g_world_A_const_135; var tmp8 any; var root_1915 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1917 lang.IFn; if
									linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1916 == nil { tmp8 = ifn_1917.Invoke_O__O(arg_1918) } else { tmp8 = linked_1916.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1915, arg_1918) }; var tmp9 any = tmp8; var tmp10 any = A_arbace_j2g_world_A_const_136; var tmp11 any; var root_1919 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1921 lang.IFn; if
									linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1920 == nil { tmp11 = ifn_1921.Invoke_O__O(arg_1922) } else { tmp11 = linked_1920.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1919, arg_1922) }; var tmp12 any = tmp11; var tmp13 any = A_arbace_j2g_world_A_const_137; var tmp14 any; var root_1923 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1925 lang.IFn; if

	linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1924 == nil { tmp14 = ifn_1925.Invoke_O__O(arg_1926) } else { tmp14 = linked_1924.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1923, arg_1926) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_j2g_world_A_const_138; var tmp17 any; var root_1927 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1929 lang.IFn; if

	linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1928 == nil { tmp17 = ifn_1929.Invoke_O__O(arg_1930) } else { tmp17 = linked_1928.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1927, arg_1930) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_j2g_world_A_const_139; var tmp20 any; var root_1931 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1931, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1933 lang.IFn; if

	linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1932 == nil { tmp20 = ifn_1933.Invoke_O__O(arg_1934) } else { tmp20 = linked_1932.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1931, arg_1934) }; return /*line :223:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp6, tmp7, tmp9, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp20)) }








func A_arbace_j2g_world_id_space_A_New() *A_arbace_j2g_world_id_space_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_id_space_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_j2g_world_id_space_A) Ctor() {}
//line :232:1
func (t *A_arbace_j2g_world_id_space_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	{ var tmp2 any; var root_1935 any = A_arbace_j2g_world_A_const_114.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_identity_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any = A_arbace_j2g_world_A_const_140; if linked_1936 == nil { tmp2 = ifn_1937.Invoke_O__O(arg_1938) } else { tmp2 = linked_1936.(*aot_arbace_core.A_arbace_core_identity_A).Invoke_O_O__O(root_1935, arg_1938) }; tmp1 = jrt.NN(jrt.NN(jrt.Class_Cast(tmp2)).GetField_String__Field(Lit_22)).Get_O__O(nil) }
//line :232:1
	return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_world_parse_member_classes_A_New() *A_arbace_j2g_world_parse_member_classes_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_parse_member_classes_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_world_parse_member_classes_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_world_parse_member_classes_A) Invoke_O_O__O(self, pc__0 any) any {





	var root_2028 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_New_O(pc__0); var tmp2 *jrt.Class; var fncls__2027 *jrt.Class = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_fn_class; if fncls__2027 == nil { var fncls__2027d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_fn_class = fncls__2027d; tmp2 = fncls__2027d } else { tmp2 = fncls__2027 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_2031 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(A_arbace_j2g_world_A_const_149.Invoke_O__O(pc__0)); if linked_2029 == nil { return ifn_2030.Invoke_O__O(arg_2031) } else { return linked_2029.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2028, arg_2031) } }
//line :246:1
func A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_New_O(p0 any) *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A) Ctor_O(c__pc any) { t.F_pc = c__pc }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A) Invoke_O_O__O(self, s__78000201__1 any) any { var tmp1 any = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_New_O_O_O(t.F_pc, s__78000201__1, self); var tmp2 *jrt.Class; var fncls__2026 *jrt.Class = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_fn_class; if fncls__2026 == nil { var fncls__2026d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_fn_class = fncls__2026d; tmp2 = fncls__2026d } else { tmp2 = fncls__2026 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :246:1
func A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A) Ctor_O_O_O(c__pc, c__s__78000201, c__iter__78000200 any) { t.F_pc = c__pc; t.F_s__78000201 = c__s__78000201; t.F_iter__78000200 = c__iter__78000200 }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A) Invoke_O__O(self any) any { { var s__78000201__1 any; var t_ any = t.F_s__78000201; t.F_s__78000201 = nil; s__78000201__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1939 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = s__78000201__1; if linked_1940 == nil { temp__1927000414__auto____2 = ifn_1941.Invoke_O__O(arg_1942) } else { temp__1927000414__auto____2 = linked_1940.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1939, arg_1942) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000201__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1943 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1943, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1945 lang.IFn; if linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = s__78000201__3; if linked_1944 == nil { tmp1 = ifn_1945.Invoke_O__O(arg_1946) } else { tmp1 = linked_1944.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1943, arg_1946) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1947 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1949 lang.IFn; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = s__78000201__3; if linked_1948 == nil { c__1927001037__auto____4 = ifn_1949.Invoke_O__O(arg_1950) } else { c__1927001037__auto____4 = linked_1948.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1947, arg_1950) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000203__6 any; var root_1951 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1952 == nil { b__78000203__6 = ifn_1953.Invoke_O__O(arg_1954) } else { b__78000203__6 = linked_1952.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1951, arg_1954) }; var tmp2 any = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_New_O_O_I_O(b__78000203__6, t.F_pc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1973 *jrt.Class = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_fn_class; if fncls__1973 == nil { var fncls__1973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_fn_class = fncls__1973d; tmp3 = fncls__1973d } else { tmp3 = fncls__1973 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1982 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any; var root_1974 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = b__78000203__6; if linked_1975 == nil { arg_1985 = ifn_1976.Invoke_O__O(arg_1977) } else { arg_1985 = linked_1975.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1974, arg_1977) }; var arg_1986 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000200); var tmp5 any; var root_1978 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = s__78000201__3; if linked_1979 == nil { tmp5 = ifn_1980.Invoke_O__O(arg_1981) } else { tmp5 = linked_1979.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1978, arg_1981) }; arg_1986 = tmp4.Invoke_O__O(tmp5); if linked_1983 == nil { return ifn_1984.Invoke_O_O__O(arg_1985, arg_1986) } else { return linked_1983.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1982, arg_1985, arg_1986) } } else { var root_1991 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1993 lang.IFn; if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any; var root_1987 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = b__78000203__6; if linked_1988 == nil { arg_1994 = ifn_1989.Invoke_O__O(arg_1990) } else { arg_1994 = linked_1988.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1987, arg_1990) }; var arg_1995 any; if linked_1992 == nil { return ifn_1993.Invoke_O_O__O(arg_1994, arg_1995) } else { return linked_1992.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1991, arg_1994, arg_1995) } } } else { var m__4 any; var root_1996 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = s__78000201__3; if linked_1997 == nil { m__4 = ifn_1998.Invoke_O__O(arg_1999) } else { m__4 = linked_1997.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1996, arg_1999) }; var tmp6 any = A_arbace_j2g_world_A_const_76; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_j2g_world_A_const_141.Invoke_O__O(m__4)) { var root_2017 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2019 lang.IFn; if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any; var mpc__5 any; var root_2004 any = A_arbace_j2g_world_A_const_142.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_2006 lang.IFn
															if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var tmp7 any = A_arbace_j2g_world_A_const_143; var arg_2007 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, A_arbace_j2g_world_A_const_143.Invoke_O__O(t.F_pc), A_arbace_j2g_world_A_const_144, A_arbace_j2g_world_A_const_145, A_arbace_j2g_world_A_const_146, t.F_pc)); var arg_2008 any; var root_2000 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = A_arbace_j2g_world_A_const_147.Invoke_O__O(m__4); if linked_2001 == nil { arg_2008 = ifn_2002.Invoke_O__O(arg_2003) } else { arg_2008 = linked_2001.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2000, arg_2003) }; if linked_2005 == nil { mpc__5 = ifn_2006.Invoke_O_O__O(arg_2007, arg_2008) } else { mpc__5 = linked_2005.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_2004, arg_2007, arg_2008) }
//line :246:1
	var tmp8 any = A_arbace_j2g_world_A_const_148; var tmp9 any = A_arbace_j2g_world_A_const_149; var tmp10 any; var root_2009 any = A_arbace_j2g_world_A_const_150.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, A_arbace_j2g_world_parse_member_classes_A_fn_class); var ifn_2011 lang.IFn

	if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = mpc__5; if linked_2010 == nil { tmp10 = ifn_2011.Invoke_O__O(arg_2012) } else { tmp10 = linked_2010.(*A_arbace_j2g_world_parse_member_classes_A).Invoke_O_O__O(root_2009, arg_2012) }
//line :246:1
	arg_2020 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, mpc__5, tmp9, tmp10)); var arg_2021 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__78000200); var tmp12 any; var root_2013 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = s__78000201__3; if linked_2014 == nil { tmp12 = ifn_2015.Invoke_O__O(arg_2016) } else { tmp12 = linked_2014.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2013, arg_2016) }; arg_2021 = tmp11.Invoke_O__O(tmp12); if linked_2018 == nil { return ifn_2019.Invoke_O_O__O(arg_2020, arg_2021) } else { return linked_2018.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2017, arg_2020, arg_2021) } } else { var tmp13 any; var root_2022 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = s__78000201__3; if linked_2023 == nil { tmp13 = ifn_2024.Invoke_O__O(arg_2025) } else { tmp13 = linked_2023.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2022, arg_2025) }; s__78000201__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :246:1
func A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A) Ctor_O_O_I_O(c__b__78000203, c__pc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000203 = c__b__78000203; t.F_pc = c__pc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A) Invoke_O__O(self any) any { { var i__78000202__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000202__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000202__1)); var tmp2 any = A_arbace_j2g_world_A_const_76; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_world_A_const_141.Invoke_O__O(m__2)) { var root_1968 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = t.F_b__78000203; var arg_1972 any; var mpc__3 any; var root_1959 any = A_arbace_j2g_world_A_const_142.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_1961 lang.IFn
																	if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var tmp3 any = A_arbace_j2g_world_A_const_143; var arg_1962 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, A_arbace_j2g_world_A_const_143.Invoke_O__O(t.F_pc), A_arbace_j2g_world_A_const_144, A_arbace_j2g_world_A_const_145, A_arbace_j2g_world_A_const_146, t.F_pc)); var arg_1963 any; var root_1955 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = A_arbace_j2g_world_A_const_147.Invoke_O__O(m__2); if linked_1956 == nil { arg_1963 = ifn_1957.Invoke_O__O(arg_1958) } else { arg_1963 = linked_1956.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1955, arg_1958) }; if linked_1960 == nil { mpc__3 = ifn_1961.Invoke_O_O__O(arg_1962, arg_1963) } else { mpc__3 = linked_1960.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_1959, arg_1962, arg_1963) }
//line :246:1
	var tmp4 any = A_arbace_j2g_world_A_const_148; var tmp5 any = A_arbace_j2g_world_A_const_149; var tmp6 any; var root_1964 any = A_arbace_j2g_world_A_const_150.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, A_arbace_j2g_world_parse_member_classes_A_fn_class); var ifn_1966 lang.IFn

	if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = mpc__3; if linked_1965 == nil { tmp6 = ifn_1966.Invoke_O__O(arg_1967) } else { tmp6 = linked_1965.(*A_arbace_j2g_world_parse_member_classes_A).Invoke_O_O__O(root_1964, arg_1967) }
//line :246:1
	arg_1972 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, mpc__3, tmp5, tmp6)); if linked_1969 == nil { ifn_1970.Invoke_O_O__O(arg_1971, arg_1972) } else { linked_1969.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1968, arg_1971, arg_1972) }; i__78000202__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000202__1); continue L1 } else { i__78000202__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000202__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_world_levels_A_New() *A_arbace_j2g_world_levels_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_levels_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_j2g_world_levels_A) Ctor() {}
//line :250:1
func (t *A_arbace_j2g_world_levels_A) Invoke_O_O_O__O(self, names__0, deps__1 any) any { var in__3 any; var root_2032 any = A_arbace_j2g_world_A_const_151.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2034 lang.IFn; if




	linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = names__0; if linked_2033 == nil { in__3 = ifn_2034.Invoke_O__O(arg_2035) } else { in__3 = linked_2033.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2032, arg_2035) }; var memo__4 any = /*line :250:1*/jrt.HashMap_New(); var lvl__5 any; var tmp1 any = A_arbace_j2g_world_levels_lvl__78000211_A_New_O_O_O(in__3, deps__1, memo__4); var tmp2 *jrt.Class; var fncls__2054 *jrt.Class = A_arbace_j2g_world_levels_lvl__78000211_A_fn_class; if






	fncls__2054 == nil { var fncls__2054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_world_levels_lvl__78000211_A_fn_class = fncls__2054d; tmp2 = fncls__2054d } else { tmp2 = fncls__2054 }; lvl__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_2068 any =





	A_arbace_j2g_world_A_const_153.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2070 lang.IFn; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any; var root_2063 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_154.GetRawRoot__O()).Invoke__O(); var arg_2067 any; var root_2058 any = A_arbace_j2g_world_A_const_155.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = lvl__5; var arg_2062 any = names__0; if linked_2059 == nil { arg_2067 = ifn_2060.Invoke_O_O__O(arg_2061, arg_2062) } else { arg_2067 = linked_2059.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2058, arg_2061, arg_2062) }; if linked_2064 == nil { arg_2071 = ifn_2065.Invoke_O_O__O(arg_2066, arg_2067) } else { arg_2071 = linked_2064.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2063, arg_2066, arg_2067) }; if linked_2069 == nil { return ifn_2070.Invoke_O__O(arg_2071) } else { return linked_2069.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2068, arg_2071) } }
//line :257:1
func A_arbace_j2g_world_levels_lvl__78000211_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_levels_lvl__78000211_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_levels_lvl__78000211_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_j2g_world_levels_lvl__78000211_A) Ctor_O_O_O(c__in, c__deps, c__memo any) { t.F_in = c__in; t.F_deps = c__deps; t.F_memo = c__memo }
//line :257:1
func (t *A_arbace_j2g_world_levels_lvl__78000211_A) Invoke_O_O__O(self, n__1 any) any { var or__1927000174__auto____2 any = jrt.HashMap_Cast(t.F_memo).Get_O__O(n__1); if
											jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
												jrt.HashMap_Cast(t.F_memo).Put_O_O__O(n__1, A_arbace_j2g_world_A_const_111)
//line :258:1
		var l__3 any; var na_2036 any; var root_2047 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2047, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2049 lang.IFn

		if linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any = A_arbace_j2g_world_A_const_152.GetRawRoot__O(); var arg_2051 any = A_arbace_j2g_world_A_const_116; var arg_2052 any; var root_2042 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = self; var arg_2046 any; var root_2037 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = t.F_in; var arg_2041 any = lang.IFn_Cast(t.F_deps).Invoke_O__O(n__1); if linked_2038 == nil { arg_2046 = ifn_2039.Invoke_O_O__O(arg_2040, arg_2041) } else { arg_2046 = linked_2038.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2037, arg_2040, arg_2041) }; if linked_2043 == nil { arg_2052 = ifn_2044.Invoke_O_O__O(arg_2045, arg_2046) } else { arg_2052 = linked_2043.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2042, arg_2045, arg_2046) }; if linked_2048 == nil { na_2036 = ifn_2049.Invoke_O_O_O__O(arg_2050, arg_2051, arg_2052) } else { na_2036 = linked_2048.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2047, arg_2050, arg_2051, arg_2052) }; if jrt.Long_InstanceOf(na_2036) { var n0_2053 int64 = jrt.NN(jrt.Long_Cast(na_2036)).LongValue__J(); if n0_2053 == 9223372036854775807 { l__3 = lang.Numbers_Inc_O__Number_NoInit(na_2036) } else { l__3 = jrt.Long_ValueOf_J__Long_NoInit(n0_2053 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_2036) { var n0_2053_2 float64 = jrt.NN(jrt.Double_Cast(na_2036)).DoubleValue__D(); l__3 = jrt.Double_ValueOf_D__Double_NoInit(n0_2053_2 + 1.0).Ref() } else { l__3 = lang.Numbers_Inc_O__Number_NoInit(na_2036) } }
		jrt.HashMap_Cast(t.F_memo).Put_O_O__O(n__1, l__3)
//line :258:1
		return l__3 } }






func A_arbace_j2g_world_supers_of_A_New() *A_arbace_j2g_world_supers_of_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_supers_of_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_j2g_world_supers_of_A) Ctor() {}
//line :265:1
func (t *A_arbace_j2g_world_supers_of_A) Invoke_O_O__O(self, n__0 any) any { var d__2 any; var root_2072 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2074 lang.IFn; if


	linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any = n__0; if linked_2073 == nil { d__2 = ifn_2074.Invoke_O__O(arg_2075) } else { d__2 = linked_2073.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2072, arg_2075) }; var root_2076 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = A_arbace_j2g_world_A_const_157.Invoke_O__O(d__2); var arg_2080 any = A_arbace_j2g_world_A_const_158.Invoke_O__O(d__2); if linked_2077 == nil { return ifn_2078.Invoke_O_O__O(arg_2079, arg_2080) } else { return linked_2077.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2076, arg_2079, arg_2080) } }

func A_arbace_j2g_world_par_levels_A_New() *A_arbace_j2g_world_par_levels_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_par_levels_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_j2g_world_par_levels_A) Ctor() {}
//line :270:1
func (t *A_arbace_j2g_world_par_levels_A) Invoke_O_O_O_O__O(self, names__0, deps__1, f__2 any) any { { var seq_78000215__4 any; var root_2086 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2088 lang.IFn


	if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any; var root_2081 any = A_arbace_j2g_world_A_const_159.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, A_arbace_j2g_world_levels_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = names__0; var arg_2085 any = deps__1; if linked_2082 == nil { arg_2089 = ifn_2083.Invoke_O_O__O(arg_2084, arg_2085) } else { arg_2089 = linked_2082.(*A_arbace_j2g_world_levels_A).Invoke_O_O_O__O(root_2081, arg_2084, arg_2085) }; if linked_2087 == nil { seq_78000215__4 = ifn_2088.Invoke_O__O(arg_2089) } else { seq_78000215__4 = linked_2087.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2086, arg_2089) }
//line :270:1
	var chunk_78000216__5 any; var count_78000217__6 int64 = 0; var i_78000218__7 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_78000218__7, count_78000217__6) { var l__8 any = lang.Indexed_Cast(chunk_78000216__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000218__7)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp2 any; var root_2106 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2108 lang.IFn
			if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; if linked_2107 == nil { tmp2 = ifn_2108.Invoke__O() } else { tmp2 = linked_2107.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2106) }; tmp1.Invoke_O_O_O__O(tmp2, f__2, l__8)
//line :273:1
			seq_78000215__4, chunk_78000216__5, count_78000217__6, i_78000218__7 = seq_78000215__4, chunk_78000216__5, count_78000217__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000218__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_2090 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = seq_78000215__4; if linked_2091 == nil { temp__1927000414__auto____8 = ifn_2092.Invoke_O__O(arg_2093) } else { temp__1927000414__auto____8 = linked_2091.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2090, arg_2093) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_78000215__9 any = temp__1927000414__auto____8; var tmp3 any; var root_2094 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = seq_78000215__9; if linked_2095 == nil { tmp3 = ifn_2096.Invoke_O__O(arg_2097) } else { tmp3 = linked_2095.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2094, arg_2097) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_2098 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = seq_78000215__9; if linked_2099 == nil { c__1927000678__auto____10 = ifn_2100.Invoke_O__O(arg_2101) } else { c__1927000678__auto____10 = linked_2099.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2098, arg_2101) }; var tmp4 any; var root_2115 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = seq_78000215__9; if linked_2116 == nil { tmp4 = ifn_2117.Invoke_O__O(arg_2118) } else { tmp4 = linked_2116.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2115, arg_2118) }; seq_78000215__4, chunk_78000216__5, count_78000217__6, i_78000218__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__10 any; var root_2102 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = seq_78000215__9; if linked_2103 == nil { l__10 = ifn_2104.Invoke_O__O(arg_2105) } else { l__10 = linked_2103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2102, arg_2105) }
				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp6 any; var root_2119 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2119, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2121 lang.IFn; if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; if linked_2120 == nil { tmp6 = ifn_2121.Invoke__O() } else { tmp6 = linked_2120.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2119) }; tmp5.Invoke_O_O_O__O(tmp6, f__2, l__10)
//line :273:1
				var tmp7 any; var root_2128 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = seq_78000215__9; if linked_2129 == nil { tmp7 = ifn_2130.Invoke_O__O(arg_2131) } else { tmp7 = linked_2129.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2128, arg_2131) }; seq_78000215__4, chunk_78000216__5, count_78000217__6, i_78000218__7 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :270:1*/panic("j2g: unreachable") }





func A_arbace_j2g_world_load_world_A_New() *A_arbace_j2g_world_load_world_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_j2g_world_load_world_A) Ctor() {}
//line :276:1
func (t *A_arbace_j2g_world_load_world_A) DoInvoke_O_O_O__O(self, inputs__0, p__78000225__1 any) any { var map__78000226__3 any = p__78000225__1; var map__78000226__4 any; if lang.ISeq_InstanceOf(map__78000226__3) { var tmp1 any; var root_2132 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = map__78000226__3; if linked_2133 == nil { tmp1 = ifn_2134.Invoke_O__O(arg_2135) } else { tmp1 = linked_2133.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2132, arg_2135) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2136 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = map__78000226__3; if linked_2137 == nil { tmp2 = ifn_2138.Invoke_O__O(arg_2139) } else { tmp2 = linked_2137.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2136, arg_2139) }; map__78000226__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2140 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2142 lang.IFn; if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = map__78000226__3; if linked_2141 == nil { tmp3 = ifn_2142.Invoke_O__O(arg_2143) } else { tmp3 = linked_2141.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2140, arg_2143) }; if jrt.J2g_Truth(tmp3) { var root_2144 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2146 lang.IFn; if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any = map__78000226__3; if linked_2145 == nil { map__78000226__4 = ifn_2146.Invoke_O__O(arg_2147) } else { map__78000226__4 = linked_2145.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2144, arg_2147) } } else { map__78000226__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000226__4 = map__78000226__3 }; var variant_files__5 any = lang.RT_Get_O_O__O_NoInit(map__78000226__4, A_arbace_j2g_world_A_const_162); var late_inputs__6 any = lang.RT_Get_O_O__O_NoInit(map__78000226__4, A_arbace_j2g_world_A_const_163); var wait__7 any = lang.RT_Get_O_O__O_NoInit(map__78000226__4, A_arbace_j2g_world_A_const_164); var variants__8 any; var root_2148 any = A_arbace_j2g_world_A_const_165.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, A_arbace_j2g_world_read_variants_A_fn_class); var ifn_2150 lang.IFn; if













	linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = variant_files__5; if linked_2149 == nil { variants__8 = ifn_2150.Invoke_O__O(arg_2151) } else { variants__8 = linked_2149.(*A_arbace_j2g_world_read_variants_A).Invoke_O_O__O(root_2148, arg_2151) }; var erased__9 any = /*line :276:1*/lang.RT_Get_O_O_O__O_NoInit(variants__8, A_arbace_j2g_world_A_const_132, lang.PersistentHashSet_EMPTY.Ref()); var variants__10 any; var root_2152 any = A_arbace_j2g_world_A_const_72.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_2154 lang.IFn; if















	linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = variants__8; var arg_2156 any = A_arbace_j2g_world_A_const_132; if linked_2153 == nil { variants__10 = ifn_2154.Invoke_O_O__O(arg_2155, arg_2156) } else { variants__10 = linked_2153.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_2152, arg_2155, arg_2156) }; var applied__11 any; var root_2157 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2159 lang.IFn; if
















	linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2158 == nil { applied__11 = ifn_2159.Invoke_O__O(arg_2160) } else { applied__11 = linked_2158.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2157, arg_2160) }; var parse__12 any; var tmp4 any = /*line :276:1*/A_arbace_j2g_world_load_world_parse__78000228_A_New(); var tmp5 *jrt.Class; var fncls__2207 *jrt.Class = A_arbace_j2g_world_load_world_parse__78000228_A_fn_class; if




















	fncls__2207 == nil { var fncls__2207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_world_load_world_parse__78000228_A_fn_class = fncls__2207d; tmp5 = fncls__2207d } else { tmp5 = fncls__2207 }; parse__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var parsed__13 any; var root_2208 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2210 lang.IFn; if


























	linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = lang.IFn_Cast(parse__12).Invoke_O__O(inputs__0); if linked_2209 == nil { parsed__13 = ifn_2210.Invoke_O__O(arg_2211) } else { parsed__13 = linked_2209.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2208, arg_2211) }; var top_set__14 any; var tmp6 any = /*line :276:1*/A_arbace_j2g_world_load_world_top_set__78000234_A_New(); var tmp7 *jrt.Class; var fncls__2243 *jrt.Class = A_arbace_j2g_world_load_world_top_set__78000234_A_fn_class; if



























	fncls__2243 == nil { var fncls__2243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_world_load_world_top_set__78000234_A_fn_class = fncls__2243d; tmp7 = fncls__2243d } else { tmp7 = fncls__2243 }; top_set__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tops__15 any; var root_2248 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2250 lang.IFn; if




























	linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any; var tmp8 lang.IFn = lang.IFn_Cast(top_set__14); var tmp9 any; var root_2244 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2244, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2246 lang.IFn; if linked_2245 == nil { ifn_2246 = lang.IFn_Cast(root_2244) } else { ifn_2246 = nil }; var arg_2247 any = parsed__13; if linked_2245 == nil { tmp9 = ifn_2246.Invoke_O__O(arg_2247) } else { tmp9 = linked_2245.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2244, arg_2247) }; arg_2251 = tmp8.Invoke_O__O(tmp9); if linked_2249 == nil { tops__15 = ifn_2250.Invoke_O__O(arg_2251) } else { tops__15 = linked_2249.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2248, arg_2251) }; var top_of__16 any; var tmp10 any = /*line :276:1*/A_arbace_j2g_world_load_world_top_of__78000241_A_New(); var tmp11 *jrt.Class; var fncls__2258 *jrt.Class = A_arbace_j2g_world_load_world_top_of__78000241_A_fn_class; if





























	fncls__2258 == nil { var fncls__2258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_world_load_world_top_of__78000241_A_fn_class = fncls__2258d; tmp11 = fncls__2258d } else { tmp11 = fncls__2258 }; top_of__16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var from_source__17 any; var tmp12 any = /*line :276:1*/A_arbace_j2g_world_load_world_from_source__78000243_A_New_O_O(tops__15, top_of__16); var tmp13 *jrt.Class; var fncls__2268 *jrt.Class = A_arbace_j2g_world_load_world_from_source__78000243_A_fn_class; if






























	fncls__2268 == nil { var fncls__2268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_world_load_world_from_source__78000243_A_fn_class = fncls__2268d; tmp13 = fncls__2268d } else { tmp13 = fncls__2268 }; from_source__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var cs__18 any; var root_2269 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2269, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2271 lang.IFn; if































	linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2270 == nil { cs__18 = ifn_2271.Invoke_O__O(arg_2272) } else { cs__18 = linked_2270.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2269, arg_2272) }; var unit__19 any; var root_2273 any = /*line :276:1*/A_arbace_j2g_world_A_const_171.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, A_arbace_j2g_world_new_unit_A_fn_class); var ifn_2275 lang.IFn; if
































	linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; if linked_2274 == nil { unit__19 = ifn_2275.Invoke__O() } else { unit__19 = linked_2274.(*A_arbace_j2g_world_new_unit_A).Invoke_O__O(root_2273) }; var failed__20 any; var root_2276 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2276, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2278 lang.IFn; if

































	linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any = lang.PersistentVector_EMPTY.Ref(); if linked_2277 == nil { failed__20 = ifn_2278.Invoke_O__O(arg_2279) } else { failed__20 = linked_2277.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2276, arg_2279) }; var root_4170 any =
	A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_4171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4170, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4172 lang.IFn; if linked_4171 == nil { ifn_4172 = lang.IFn_Cast(root_4170) } else { ifn_4172 = nil }; var arg_4173 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_j2g_world_A_const_227, cs__18, A_arbace_j2g_world_A_const_209, unit__19, A_arbace_j2g_world_A_const_228, from_source__17); if linked_4171 == nil { ifn_4172.Invoke_O__O(arg_4173) } else { linked_4171.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4170, arg_4173) }; var tmp14 any = A_arbace_j2g_world_load_world_fn__78000245_A_New_O_O_O_O_O_O_O_O_O_O(parsed__13, variants__10, parse__12, failed__20, top_set__14, wait__7, tops__15, unit__19, applied__11, late_inputs__6); var tmp15 *jrt.Class; var fncls__4110 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_A_fn_class; if fncls__4110 == nil { var fncls__4110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_world_load_world_fn__78000245_A_fn_class = fncls__4110d; tmp15 = fncls__4110d } else { tmp15 = fncls__4110 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O(); var seq_78000467__21 any; var root_4115 any = /*line :276:1*/A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4115, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4117 lang.IFn; if



























































































































































































































	linked_4116 == nil { ifn_4117 = lang.IFn_Cast(root_4115) } else { ifn_4117 = nil }; var arg_4118 any; var root_4111 any = A_arbace_j2g_world_A_const_78.GetRawRoot__O(); var linked_4112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4111, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_4113 lang.IFn; if linked_4112 == nil { ifn_4113 = lang.IFn_Cast(root_4111) } else { ifn_4113 = nil }; var arg_4114 any = variants__10; if linked_4112 == nil { arg_4118 = ifn_4113.Invoke_O__O(arg_4114) } else { arg_4118 = linked_4112.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_4111, arg_4114) }; if linked_4116 == nil { seq_78000467__21 = ifn_4117.Invoke_O__O(arg_4118) } else { seq_78000467__21 = linked_4116.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4115, arg_4118) }; var chunk_78000468__22 any; var count_78000469__23 int64 = 0; var i_78000470__24 int64 = 0; L1:
//line :276:1
	for {



























































































































































































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_78000470__24, count_78000469__23) { var n__25 any = lang.Indexed_Cast(chunk_78000468__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000470__24)); var tmp16 any; var root_4128 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_4129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4128, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4130 lang.IFn; if linked_4129 == nil { ifn_4130 = lang.IFn_Cast(root_4128) } else { ifn_4130 = nil }; var arg_4131 any; var root_4123 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_4124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4123, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_4125 lang.IFn; if linked_4124 == nil { ifn_4125 = lang.IFn_Cast(root_4123) } else { ifn_4125 = nil }; var arg_4126 any; var root_4119 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_4120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4119, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4121 lang.IFn; if linked_4120 == nil { ifn_4121 = lang.IFn_Cast(root_4119) } else { ifn_4121 = nil }; var arg_4122 any = applied__11; if linked_4120 == nil { arg_4126 = ifn_4121.Invoke_O__O(arg_4122) } else { arg_4126 = linked_4120.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4119, arg_4122) }; var arg_4127 any = n__25; if linked_4124 == nil { arg_4131 = ifn_4125.Invoke_O_O__O(arg_4126, arg_4127) } else { arg_4131 = linked_4124.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_4123, arg_4126, arg_4127) }; if linked_4129 == nil { tmp16 = ifn_4130.Invoke_O__O(arg_4131) } else { tmp16 = linked_4129.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4128, arg_4131) }; if jrt.J2g_Truth(tmp16) {
			var root_4174 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_4175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4174, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4176 lang.IFn; if linked_4175 == nil { ifn_4176 = lang.IFn_Cast(root_4174) } else { ifn_4176 = nil }; var arg_4177 any = failed__20; var arg_4178 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_4179 any = lang.Tuple_Create_O_O__IPersistentVector(n__25, Lit_42); if linked_4175 == nil { ifn_4176.Invoke_O_O_O__O(arg_4177, arg_4178, arg_4179) } else { linked_4175.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_4174, arg_4177, arg_4178, arg_4179) }
//line :496:1
			seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = seq_78000467__21, chunk_78000468__22, count_78000469__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000470__24); continue L1 } else { seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = seq_78000467__21, chunk_78000468__22, count_78000469__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000470__24); continue L1 } } else { var temp__1927000414__auto____25 any; var root_4132 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4134 lang.IFn; if linked_4133 == nil { ifn_4134 = lang.IFn_Cast(root_4132) } else { ifn_4134 = nil }; var arg_4135 any = seq_78000467__21; if linked_4133 == nil { temp__1927000414__auto____25 = ifn_4134.Invoke_O__O(arg_4135) } else { temp__1927000414__auto____25 = linked_4133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4132, arg_4135) }; if jrt.J2g_Truth(temp__1927000414__auto____25) { var seq_78000467__26 any = temp__1927000414__auto____25; var tmp17 any; var root_4136 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_4137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4136, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4138 lang.IFn; if linked_4137 == nil { ifn_4138 = lang.IFn_Cast(root_4136) } else { ifn_4138 = nil }; var arg_4139 any = seq_78000467__26; if linked_4137 == nil { tmp17 = ifn_4138.Invoke_O__O(arg_4139) } else { tmp17 = linked_4137.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4136, arg_4139) }; if jrt.J2g_Truth(tmp17) { var c__1927000678__auto____27 any; var root_4140 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_4141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4140, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4142 lang.IFn; if linked_4141 == nil { ifn_4142 = lang.IFn_Cast(root_4140) } else { ifn_4142 = nil }; var arg_4143 any = seq_78000467__26; if linked_4141 == nil { c__1927000678__auto____27 = ifn_4142.Invoke_O__O(arg_4143) } else { c__1927000678__auto____27 = linked_4141.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4140, arg_4143) }; var tmp18 any; var root_4180 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_4181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4180, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4182 lang.IFn; if linked_4181 == nil { ifn_4182 = lang.IFn_Cast(root_4180) } else { ifn_4182 = nil }; var arg_4183 any = seq_78000467__26; if linked_4181 == nil { tmp18 = ifn_4182.Invoke_O__O(arg_4183) } else { tmp18 = linked_4181.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4180, arg_4183) }; seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = tmp18, c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__27 any; var root_4144 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_4145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4144, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4146 lang.IFn; if linked_4145 == nil { ifn_4146 = lang.IFn_Cast(root_4144) } else { ifn_4146 = nil }; var arg_4147 any = seq_78000467__26; if linked_4145 == nil { n__27 = ifn_4146.Invoke_O__O(arg_4147) } else { n__27 = linked_4145.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4144, arg_4147) }; var tmp19 any; var root_4157 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_4158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4157, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4159 lang.IFn; if linked_4158 == nil { ifn_4159 = lang.IFn_Cast(root_4157) } else { ifn_4159 = nil }; var arg_4160 any; var root_4152 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_4153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4152, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_4154 lang.IFn; if linked_4153 == nil { ifn_4154 = lang.IFn_Cast(root_4152) } else { ifn_4154 = nil }; var arg_4155 any; var root_4148 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_4149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4148, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4150 lang.IFn; if linked_4149 == nil { ifn_4150 = lang.IFn_Cast(root_4148) } else { ifn_4150 = nil }; var arg_4151 any = applied__11; if linked_4149 == nil { arg_4155 = ifn_4150.Invoke_O__O(arg_4151) } else { arg_4155 = linked_4149.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4148, arg_4151) }; var arg_4156 any = n__27; if linked_4153 == nil { arg_4160 = ifn_4154.Invoke_O_O__O(arg_4155, arg_4156) } else { arg_4160 = linked_4153.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_4152, arg_4155, arg_4156) }; if linked_4158 == nil { tmp19 = ifn_4159.Invoke_O__O(arg_4160) } else { tmp19 = linked_4158.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4157, arg_4160) }; if jrt.J2g_Truth(tmp19) {
				var root_4184 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_4185 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4184, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4186 lang.IFn; if linked_4185 == nil { ifn_4186 = lang.IFn_Cast(root_4184) } else { ifn_4186 = nil }; var arg_4187 any = failed__20; var arg_4188 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_4189 any = lang.Tuple_Create_O_O__IPersistentVector(n__27, Lit_42); if linked_4185 == nil { ifn_4186.Invoke_O_O_O__O(arg_4187, arg_4188, arg_4189) } else { linked_4185.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_4184, arg_4187, arg_4188, arg_4189) }
//line :496:1
				var tmp20 any; var root_4190 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_4191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4190, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4192 lang.IFn; if linked_4191 == nil { ifn_4192 = lang.IFn_Cast(root_4190) } else { ifn_4192 = nil }; var arg_4193 any = seq_78000467__26; if linked_4191 == nil { tmp20 = ifn_4192.Invoke_O__O(arg_4193) } else { tmp20 = linked_4191.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4190, arg_4193) }; seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = tmp20, nil, 0, 0; continue L1 } else { var tmp21 any; var root_4194 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_4195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4194, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4196 lang.IFn; if linked_4195 == nil { ifn_4196 = lang.IFn_Cast(root_4194) } else { ifn_4196 = nil }; var arg_4197 any = seq_78000467__26; if linked_4195 == nil { tmp21 = ifn_4196.Invoke_O__O(arg_4197) } else { tmp21 = linked_4195.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4194, arg_4197) }; seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = tmp21, nil, 0, 0; continue L1 } } } }
//line :276:1
		break L1 }; var tmp22 any = A_arbace_j2g_world_A_const_172; var tmp23 any = A_arbace_j2g_world_A_const_173; var tmp24 any = A_arbace_j2g_world_A_const_174; var tmp25 any = A_arbace_j2g_world_A_const_94; var tmp26 any; var root_2284 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2284, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2286 lang.IFn; if





























































































































































































































	linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any = A_arbace_j2g_world_A_const_168; var arg_2288 any; var root_2280 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2282 lang.IFn; if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any = parsed__13; if linked_2281 == nil { arg_2288 = ifn_2282.Invoke_O__O(arg_2283) } else { arg_2288 = linked_2281.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2280, arg_2283) }; if linked_2285 == nil { tmp26 = ifn_2286.Invoke_O_O__O(arg_2287, arg_2288) } else { tmp26 = linked_2285.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2284, arg_2287, arg_2288) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_j2g_world_A_const_175; var tmp29 any; var root_2289 any = /*line :276:1*/A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2291 lang.IFn; if













	linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = tops__15; if linked_2290 == nil { tmp29 = ifn_2291.Invoke_O__O(arg_2292) } else { tmp29 = linked_2290.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2289, arg_2292) }; var tmp30 any = tmp29; var tmp31 any = A_arbace_j2g_world_A_const_176; var tmp32 any; var root_2416 any = /*line :276:1*/A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2418 lang.IFn; if































































































































































































































	linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2420 any; var iter__1927001039__auto____21 any; var tmp33 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_A_New(); var tmp34 *jrt.Class; var fncls__2411 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_A_fn_class; if fncls__2411 == nil { var fncls__2411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_A_fn_class = fncls__2411d; tmp34 = fncls__2411d } else { tmp34 = fncls__2411 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var tmp35 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____21); var tmp36 any; var root_2412 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2414 lang.IFn; if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = parsed__13; if linked_2413 == nil { tmp36 = ifn_2414.Invoke_O__O(arg_2415) } else { tmp36 = linked_2413.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2412, arg_2415) }; arg_2420 = tmp35.Invoke_O__O(tmp36); if linked_2417 == nil { tmp32 = ifn_2418.Invoke_O_O__O(arg_2419, arg_2420) } else { tmp32 = linked_2417.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2416, arg_2419, arg_2420) }; var tmp37 any = tmp32; var tmp38 any = A_arbace_j2g_world_A_const_177; var tmp39 any; var root_2435 any = /*line :276:1*/A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2437 lang.IFn; if


































































































































































































































	linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any; var root_2430 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_2431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2430, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2432 lang.IFn; if linked_2431 == nil { ifn_2432 = lang.IFn_Cast(root_2430) } else { ifn_2432 = nil }; var arg_2433 any; var root_2421 any = A_arbace_j2g_world_A_const_178.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2423 lang.IFn; if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var arg_2425 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); if linked_2422 == nil { arg_2433 = ifn_2423.Invoke_O_O__O(arg_2424, arg_2425) } else { arg_2433 = linked_2422.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2421, arg_2424, arg_2425) }; var arg_2434 any; var root_2426 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2426, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2428 lang.IFn; if linked_2427 == nil { ifn_2428 = lang.IFn_Cast(root_2426) } else { ifn_2428 = nil }; var arg_2429 any = failed__20; if linked_2427 == nil { arg_2434 = ifn_2428.Invoke_O__O(arg_2429) } else { arg_2434 = linked_2427.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2426, arg_2429) }; if linked_2431 == nil { arg_2438 = ifn_2432.Invoke_O_O__O(arg_2433, arg_2434) } else { arg_2438 = linked_2431.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2430, arg_2433, arg_2434) }; if linked_2436 == nil { tmp39 = ifn_2437.Invoke_O__O(arg_2438) } else { tmp39 = linked_2436.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2435, arg_2438) }; var tmp40 any = tmp39; var tmp41 any = A_arbace_j2g_world_A_const_179; var tmp42 any; var root_2439 any = /*line :276:1*/A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2441 lang.IFn; if













	linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = applied__11; if linked_2440 == nil { tmp42 = ifn_2441.Invoke_O__O(arg_2442) } else { tmp42 = linked_2440.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2439, arg_2442) }; return /*line :276:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, cs__18, tmp23, unit__19, tmp24, from_source__17, tmp25, tmp27, tmp28, tmp30, tmp31, tmp37, tmp38, tmp40, tmp41, tmp42, A_arbace_j2g_world_A_const_180, erased__9)) }




















func A_arbace_j2g_world_load_world_parse__78000228_A_New() *A_arbace_j2g_world_load_world_parse__78000228_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_parse__78000228_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_A) Ctor() {}
//line :297:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_A) Invoke_O_O__O(self, ins__1 any) any { var fs__2 any; var root_2166 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2168 lang.IFn; if
												linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_world_A_const_166.GetRawRoot__O(), ins__1); if linked_2167 == nil { fs__2 = ifn_2168.Invoke_O__O(arg_2169) } else { fs__2 = linked_2167.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2166, arg_2169) }; var root_2203 any =
												A_arbace_j2g_world_A_const_167.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, A_arbace_j2g_world_join_continued_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp2 any; var root_2170 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2172 lang.IFn; if
												linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; if linked_2171 == nil { tmp2 = ifn_2172.Invoke__O() } else { tmp2 = linked_2171.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2170) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_New(); var tmp5 *jrt.Class; var fncls__2181 *jrt.Class = A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_fn_class; if fncls__2181 == nil { var fncls__2181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_fn_class = fncls__2181d; tmp5 = fncls__2181d } else { tmp5 = fncls__2181 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any; var root_2191 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2193 lang.IFn; if

	linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any; var tmp8 any = A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_New_O(fs__2); var tmp9 *jrt.Class; var fncls__2186 *jrt.Class = A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_fn_class; if fncls__2186 == nil { var fncls__2186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_fn_class = fncls__2186d; tmp9 = fncls__2186d } else { tmp9 = fncls__2186 }; arg_2194 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_2195 any; var root_2187 any = A_arbace_j2g_world_A_const_65.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(fs__2)).Ref(); if linked_2188 == nil { arg_2195 = ifn_2189.Invoke_O__O(arg_2190) } else { arg_2195 = linked_2188.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2187, arg_2190) }; if linked_2192 == nil { tmp7 = ifn_2193.Invoke_O_O__O(arg_2194, arg_2195) } else { tmp7 = linked_2192.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2191, arg_2194, arg_2195) }; arg_2206 = /*line :300:1*/tmp1.Invoke_O_O_O_O__O(tmp3, tmp6, fs__2, tmp7); if /*line :299:1*/ linked_2204 == nil { return ifn_2205.Invoke_O__O(arg_2206) } else { return linked_2204.(*A_arbace_j2g_world_join_continued_A).Invoke_O_O__O(root_2203, arg_2206) } }
func A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_New() *A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A) Ctor() {}
//line :300:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A) Invoke_O_O__O(self, f__1 any) any { var forms__2 any; var root_2173 any = A_arbace_j2g_world_A_const_129.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, A_arbace_j2g_world_read_forms_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = f__1; if linked_2174 == nil { forms__2 = ifn_2175.Invoke_O__O(arg_2176) } else { forms__2 = linked_2174.(*A_arbace_j2g_world_read_forms_A).Invoke_O_O__O(root_2173, arg_2176) }; var tmp1 any = A_arbace_j2g_world_A_const_168; var tmp2 any = A_arbace_j2g_world_A_const_50; var tmp3 any = A_arbace_j2g_world_A_const_143; var tmp4 any; var root_2177 any = A_arbace_j2g_world_A_const_130.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, A_arbace_j2g_world_ns_of_forms_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = forms__2; if linked_2178 == nil { tmp4 = ifn_2179.Invoke_O__O(arg_2180) } else { tmp4 = linked_2178.(*A_arbace_j2g_world_ns_of_forms_A).Invoke_O_O__O(root_2177, arg_2180) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, f__1, tmp2, forms__2, tmp3, tmp4)) }

func A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_New_O(p0 any) *A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :302:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A) Invoke_O_O__O(self, p1__78000220_SHARP___1 any) any { var tmp1 any; var root_2182 any = A_arbace_j2g_world_A_const_95.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2182, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_2184 lang.IFn; if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var tmp2 any = t.F_fs; var arg_2185 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(p1__78000220_SHARP___1)); if linked_2183 == nil { tmp1 = ifn_2184.Invoke_O__O(arg_2185) } else { tmp1 = linked_2183.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_2182, arg_2185) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(jrt.NN(jrt.File_Cast(tmp1)).Length__J())).Ref() }

func A_arbace_j2g_world_load_world_top_set__78000234_A_New() *A_arbace_j2g_world_load_world_top_set__78000234_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_top_set__78000234_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_j2g_world_load_world_top_set__78000234_A) Ctor() {}
//line :304:1
func (t *A_arbace_j2g_world_load_world_top_set__78000234_A) Invoke_O_O__O(self, ps__1 any) any { var root_2239 any = A_arbace_j2g_world_A_const_151.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_New(); var tmp3 *jrt.Class; var fncls__2233 *jrt.Class = A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_fn_class; if fncls__2233 == nil { var fncls__2233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_fn_class = fncls__2233d; tmp3 = fncls__2233d } else { tmp3 = fncls__2233 }; arg_2242 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ps__1); if linked_2240 == nil { return ifn_2241.Invoke_O__O(arg_2242) } else { return linked_2240.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2239, arg_2242) } }
//line :304:1
func A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_New() *A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A) Ctor() {}
//line :304:1
func (t *A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A) Invoke_O_O__O(self, p__78000235__1 any) any { var map__78000237__2 any = p__78000235__1; var map__78000237__3 any; if lang.ISeq_InstanceOf(map__78000237__2) { var tmp1 any; var root_2212 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = map__78000237__2; if linked_2213 == nil { tmp1 = ifn_2214.Invoke_O__O(arg_2215) } else { tmp1 = linked_2213.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2212, arg_2215) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2216 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = map__78000237__2; if linked_2217 == nil { tmp2 = ifn_2218.Invoke_O__O(arg_2219) } else { tmp2 = linked_2217.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2216, arg_2219) }; map__78000237__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2220 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = map__78000237__2; if linked_2221 == nil { tmp3 = ifn_2222.Invoke_O__O(arg_2223) } else { tmp3 = linked_2221.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2220, arg_2223) }; if jrt.J2g_Truth(tmp3) { var root_2224 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = map__78000237__2; if linked_2225 == nil { map__78000237__3 = ifn_2226.Invoke_O__O(arg_2227) } else { map__78000237__3 = linked_2225.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2224, arg_2227) } } else { map__78000237__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000237__3 = map__78000237__2 }; var ns__4 any = lang.RT_Get_O_O__O_NoInit(map__78000237__3, A_arbace_j2g_world_A_const_143); var forms__5 any = lang.RT_Get_O_O__O_NoInit(map__78000237__3, A_arbace_j2g_world_A_const_50); if jrt.J2g_Truth(ns__4) { var root_2228 any = A_arbace_j2g_world_A_const_169.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, A_arbace_j2g_world_top_names_A_fn_class); var ifn_2230 lang.IFn; if linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any = ns__4; var arg_2232 any = forms__5; if linked_2229 == nil { return ifn_2230.Invoke_O_O__O(arg_2231, arg_2232) } else { return linked_2229.(*A_arbace_j2g_world_top_names_A).Invoke_O_O_O__O(root_2228, arg_2231, arg_2232) } } else { return nil } }

func A_arbace_j2g_world_load_world_top_of__78000241_A_New() *A_arbace_j2g_world_load_world_top_of__78000241_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_top_of__78000241_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_j2g_world_load_world_top_of__78000241_A) Ctor() {}
//line :306:1
func (t *A_arbace_j2g_world_load_world_top_of__78000241_A) Invoke_O_O__O(self, n__1 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__1)).IndexOf_String__I(Lit_13); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__1 } else { var root_2252 any = A_arbace_j2g_world_A_const_170.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2254 lang.IFn; if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = n__1; var arg_2256 any = A_arbace_j2g_world_A_const_111; var arg_2257 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_2253 == nil { return ifn_2254.Invoke_O_O_O__O(arg_2255, arg_2256, arg_2257) } else { return linked_2253.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2252, arg_2255, arg_2256, arg_2257) } } }
func A_arbace_j2g_world_load_world_from_source__78000243_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_from_source__78000243_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_from_source__78000243_A{}; t.Ctor_O_O(p0, p1); return t }
//line :307:1
func (t *A_arbace_j2g_world_load_world_from_source__78000243_A) Ctor_O_O(c__tops, c__top_of any) { t.F_tops = c__tops; t.F_top_of = c__top_of }
//line :307:1
func (t *A_arbace_j2g_world_load_world_from_source__78000243_A) Invoke_O_O__O(self, n__1 any) any { var root_2263 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_2264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2263, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2265 lang.IFn; if linked_2264 == nil { ifn_2265 = lang.IFn_Cast(root_2263) } else { ifn_2265 = nil }; var arg_2266 any; var root_2259 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2259, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2261 lang.IFn; if linked_2260 == nil { ifn_2261 = lang.IFn_Cast(root_2259) } else { ifn_2261 = nil }; var arg_2262 any = t.F_tops; if linked_2260 == nil { arg_2266 = ifn_2261.Invoke_O__O(arg_2262) } else { arg_2266 = linked_2260.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2259, arg_2262) }; var arg_2267 any = lang.IFn_Cast(t.F_top_of).Invoke_O__O(n__1); if linked_2264 == nil { return ifn_2265.Invoke_O_O__O(arg_2266, arg_2267) } else { return linked_2264.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2263, arg_2266, arg_2267) } }



func A_arbace_j2g_world_load_world_fn__78000245_A_New_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9 any) *A_arbace_j2g_world_load_world_fn__78000245_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :311:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_A) Ctor_O_O_O_O_O_O_O_O_O_O(c__parsed, c__variants, c__parse, c__failed, c__top_set, c__wait, c__tops, c__unit, c__applied, c__late_inputs any) { t.F_parsed = c__parsed; t.F_variants = c__variants; t.F_parse = c__parse; t.F_failed = c__failed; t.F_top_set = c__top_set; t.F_wait = c__wait; t.F_tops = c__tops; t.F_unit = c__unit; t.F_applied = c__applied; t.F_late_inputs = c__late_inputs }
//line :311:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_A) Invoke_O__O(self any) any { var tmp1 any; tmp85 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var temp__1927000414__auto____3 any; var root_3684 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_3685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3684, A_arbace_j2g_world_id_space_A_fn_class); var ifn_3686 lang.IFn






	if linked_3685 == nil { ifn_3686 = lang.IFn_Cast(root_3684) } else { ifn_3686 = nil }; if linked_3685 == nil { temp__1927000414__auto____3 = ifn_3686.Invoke__O() } else { temp__1927000414__auto____3 = linked_3685.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_3684) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var space__4 any = temp__1927000414__auto____3
		jrt.ThreadLocal_Cast(space__4).Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_j2g_world_A_const_214.GetRawRoot__O()))) }
//line :311:1
	var t__3 any; var root_2443 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2443, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2445 lang.IFn








	if linked_2444 == nil { ifn_2445 = lang.IFn_Cast(root_2443) } else { ifn_2445 = nil }; var arg_2446 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref(); if linked_2444 == nil { t__3 = ifn_2445.Invoke_O__O(arg_2446) } else { t__3 = linked_2444.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2443, arg_2446) }
//line :311:1
	var laps__4 any; var root_2447 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2448 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2447, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2449 lang.IFn









	if linked_2448 == nil { ifn_2449 = lang.IFn_Cast(root_2447) } else { ifn_2449 = nil }; var arg_2450 any = lang.PersistentVector_EMPTY.Ref(); if linked_2448 == nil { laps__4 = ifn_2449.Invoke_O__O(arg_2450) } else { laps__4 = linked_2448.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2447, arg_2450) }
//line :311:1
	var lap__5 any; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_New_O_O(t__3, laps__4); var tmp3 *jrt.Class
	var fncls__2471 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_fn_class










	if fncls__2471 == nil { var fncls__2471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_fn_class = fncls__2471d; tmp3 = fncls__2471d } else { tmp3 = fncls__2471 }; lap__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :311:1
	var enter_BANG___6 any; var tmp4 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_New_O_O_O(t.F_variants, t.F_failed, t.F_applied); var tmp5 *jrt.Class
	var fncls__2840 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_fn_class
















	if fncls__2840 == nil { var fncls__2840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_fn_class = fncls__2840d; tmp5 = fncls__2840d } else { tmp5 = fncls__2840 }; enter_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :311:1
	var resolve_BANG___7 any; var tmp6 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_New_O_O(t.F_failed, lap__5); var tmp7 *jrt.Class
	var fncls__2947 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_fn_class





















































	if fncls__2947 == nil { var fncls__2947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_fn_class = fncls__2947d; tmp7 = fncls__2947d } else { tmp7 = fncls__2947 }; resolve_BANG___7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :311:1
	var analyze_BANG___8 any; var tmp8 any = A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_New_O(t.F_failed); var tmp9 *jrt.Class
	var fncls__2969 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_fn_class






































































	if fncls__2969 == nil { var fncls__2969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_fn_class = fncls__2969d; tmp9 = fncls__2969d } else { tmp9 = fncls__2969 }; analyze_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :311:1
	var ___9 any; var tmp10 lang.IFn = lang.IFn_Cast(enter_BANG___6); var tmp11 any; var root_3687 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3687, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3689 lang.IFn; _ = ___9












































































	if linked_3688 == nil { ifn_3689 = lang.IFn_Cast(root_3687) } else { ifn_3689 = nil }; var arg_3690 any = t.F_parsed; if linked_3688 == nil { tmp11 = ifn_3689.Invoke_O__O(arg_3690) } else { tmp11 = linked_3688.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3687, arg_3690) }; ___9 = tmp10.Invoke_O__O(tmp11)
//line :311:1
	var names1__10 any; var root_2970 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2970, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2972 lang.IFn








	if linked_2971 == nil { ifn_2972 = lang.IFn_Cast(root_2970) } else { ifn_2972 = nil }; var arg_2973 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); if linked_2971 == nil { names1__10 = ifn_2972.Invoke_O__O(arg_2973) } else { names1__10 = linked_2971.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2970, arg_2973) }
//line :311:1
	var ___11 any = lang.IFn_Cast(resolve_BANG___7).Invoke_O__O(names1__10); var rt_start__12 any; var G__78000328__12_ any; var root_2974 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_2975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2974, A_arbace_j2g_world_id_space_A_fn_class); var ifn_2976 lang.IFn; _ = ___11























































































	if linked_2975 == nil { ifn_2976 = lang.IFn_Cast(root_2974) } else { ifn_2976 = nil }; if linked_2975 == nil { G__78000328__12_ = ifn_2976.Invoke__O() } else { G__78000328__12_ = linked_2975.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_2974) }
//line :311:1
	var G__78000328__13_ any























































































	if lang.Util_Identical_O_O__Z_NoInit(G__78000328__12_, nil) { G__78000328__13_ = nil } else { G__78000328__13_ = jrt.ThreadLocal_Cast(G__78000328__12_).Get__O() }; if lang.Util_Identical_O_O__Z_NoInit(G__78000328__13_, nil) { rt_start__12 = nil } else { rt_start__12 = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.AtomicInteger_Cast(G__78000328__13_)).Get__I()).Ref() }
//line :311:1
	var rt_order__13 any; var root_2977 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2979 lang.IFn
























































































	if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any = names1__10; if linked_2978 == nil { rt_order__13 = ifn_2979.Invoke_O__O(arg_2980) } else { rt_order__13 = linked_2978.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2977, arg_2980) }
//line :311:1
	var runtime__14 any

























































































	if jrt.J2g_Truth(rt_start__12) {
		var root_3011 any = A_arbace_j2g_world_A_const_207.GetRawRoot__O(); var linked_3012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3011, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3013 lang.IFn; if linked_3012 == nil { ifn_3013 = lang.IFn_Cast(root_3011) } else { ifn_3013 = nil }; var arg_3014 any; var tmp12 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_New_O_O_O_O_O(rt_order__13, analyze_BANG___8, t.F_unit, rt_start__12, names1__10); var tmp13 *jrt.Class; var fncls__3010 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_fn_class; if fncls__3010 == nil { var fncls__3010d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_fn_class = fncls__3010d; tmp13 = fncls__3010d } else { tmp13 = fncls__3010 }; arg_3014 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); if linked_3012 == nil { runtime__14 = ifn_3013.Invoke_O__O(arg_3014) } else { runtime__14 = linked_3012.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3011, arg_3014) } } else {





			var root_3711 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_3712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3711, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3713 lang.IFn; if linked_3712 == nil { ifn_3713 = lang.IFn_Cast(root_3711) } else { ifn_3713 = nil }; var arg_3714 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_world_A_const_209; var tmp16 any; var root_3700 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_3701 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3700, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3702 lang.IFn; if linked_3701 == nil { ifn_3702 = lang.IFn_Cast(root_3700) } else { ifn_3702 = nil }; var arg_3703 any = t.F_unit; var arg_3704 any = A_arbace_j2g_world_A_const_133; var arg_3705 any = rt_order__13; if linked_3701 == nil { tmp16 = ifn_3702.Invoke_O_O_O__O(arg_3703, arg_3704, arg_3705) } else { tmp16 = linked_3701.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3700, arg_3703, arg_3704, arg_3705) }; arg_3714 = tmp14.Invoke_O_O__O(tmp15, tmp16); if linked_3712 == nil { ifn_3713.Invoke_O__O(arg_3714) } else { linked_3712.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3711, arg_3714) }; var tmp17 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_New_O_O(analyze_BANG___8, names1__10); var tmp18 *jrt.Class; var fncls__3699 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_fn_class; if fncls__3699 == nil { var fncls__3699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_fn_class = fncls__3699d; tmp18 = fncls__3699d } else { tmp18 = fncls__3699 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :401:1
			runtime__14 = nil }
//line :311:1
	var ___15 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_215); var ___16 any; _ = ___15; _ = ___16


































































































	if jrt.J2g_Truth(t.F_wait) { var tmp19 any; var t_ any = t.F_wait; t.F_wait = nil; tmp19 = t_; ___16 = lang.IFn_Cast(tmp19).Invoke__O() } else { ___16 = nil }
//line :311:1
	var ___17 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_164); var parsed2__18 any; var tmp20 any; var t__2 any = t.F_parse; _ = ___17




































































































	t.F_parse = nil; tmp20 = t__2; var tmp21 lang.IFn = lang.IFn_Cast(tmp20); var tmp22 any; var t__4 any = t.F_late_inputs; t.F_late_inputs = nil; tmp22 = t__4; parsed2__18 = tmp21.Invoke_O__O(tmp22)
//line :311:1
	var ___19 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_216); var ___20 any; var root_3015 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_3016 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3015, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3017 lang.IFn; _ = ___19; _ = ___20






































































































	if linked_3016 == nil { ifn_3017 = lang.IFn_Cast(root_3015) } else { ifn_3017 = nil }; var arg_3018 any; var t__5 any = t.F_tops; t.F_tops = nil; arg_3018 = t__5; var arg_3019 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_3020 any; var tmp23 any; var t__6 any = t.F_top_set; t.F_top_set = nil; tmp23 = t__6; arg_3020 = lang.IFn_Cast(tmp23).Invoke_O__O(parsed2__18); if linked_3016 == nil { ___20 = ifn_3017.Invoke_O_O_O__O(arg_3018, arg_3019, arg_3020) } else { ___20 = linked_3016.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3015, arg_3018, arg_3019, arg_3020) }
//line :311:1
	var ___21 any; var root_3021 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_3022 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3021, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3023 lang.IFn; _ = ___21







































































































	if linked_3022 == nil { ifn_3023 = lang.IFn_Cast(root_3021) } else { ifn_3023 = nil }; var arg_3024 any; var t__7 any = t.F_parsed; t.F_parsed = nil; arg_3024 = t__7; var arg_3025 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_3026 any = parsed2__18; if linked_3022 == nil { ___21 = ifn_3023.Invoke_O_O_O__O(arg_3024, arg_3025, arg_3026) } else { ___21 = linked_3022.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3021, arg_3024, arg_3025, arg_3026) }
//line :311:1
	var ___22 any = lang.IFn_Cast(enter_BANG___6).Invoke_O__O(parsed2__18); var names2__23 any; var root_3036 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3036, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3038 lang.IFn; _ = ___22









































































































	if linked_3037 == nil { ifn_3038 = lang.IFn_Cast(root_3036) } else { ifn_3038 = nil }; var arg_3039 any; var root_3031 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_3032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3031, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_3033 lang.IFn; if linked_3032 == nil { ifn_3033 = lang.IFn_Cast(root_3031) } else { ifn_3033 = nil }; var arg_3034 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names1__10)).Ref(); var arg_3035 any; var root_3027 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3027, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3029 lang.IFn; if linked_3028 == nil { ifn_3029 = lang.IFn_Cast(root_3027) } else { ifn_3029 = nil }; var arg_3030 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); if linked_3028 == nil { arg_3035 = ifn_3029.Invoke_O__O(arg_3030) } else { arg_3035 = linked_3028.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3027, arg_3030) }; if linked_3032 == nil { arg_3039 = ifn_3033.Invoke_O_O__O(arg_3034, arg_3035) } else { arg_3039 = linked_3032.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_3031, arg_3034, arg_3035) }; if linked_3037 == nil { names2__23 = ifn_3038.Invoke_O__O(arg_3039) } else { names2__23 = linked_3037.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3036, arg_3039) }
//line :311:1
	var ___24 any = lang.IFn_Cast(resolve_BANG___7).Invoke_O__O(names2__23); var tops_QMARK___25 any; var tmp24 any = A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_New(); var tmp25 *jrt.Class; var fncls__3049 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_fn_class; _ = ___24

























































































































	if fncls__3049 == nil { var fncls__3049d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_fn_class = fncls__3049d; tmp25 = fncls__3049d } else { tmp25 = fncls__3049 }; tops_QMARK___25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil)
//line :311:1
	var heights__26 any; var root_3050 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3052 lang.IFn


























































































































	if linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3051 == nil { heights__26 = ifn_3052.Invoke_O__O(arg_3053) } else { heights__26 = linked_3051.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3050, arg_3053) }
//line :311:1
	var height__27 any; var tmp26 any = A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_New_O(heights__26); var tmp27 *jrt.Class
	var fncls__3099 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_fn_class



























































































































	if fncls__3099 == nil { var fncls__3099d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_fn_class = fncls__3099d; tmp27 = fncls__3099d } else { tmp27 = fncls__3099 }; height__27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil)
//line :311:1
	var levels__28 any; var root_3100 any = A_arbace_j2g_world_A_const_155.GetRawRoot__O(); var linked_3101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3100, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_3102 lang.IFn

































































































































	if linked_3101 == nil { ifn_3102 = lang.IFn_Cast(root_3100) } else { ifn_3102 = nil }; var arg_3103 any = height__27; var arg_3104 any = names2__23; if linked_3101 == nil { levels__28 = ifn_3102.Invoke_O_O__O(arg_3103, arg_3104) } else { levels__28 = linked_3101.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_3100, arg_3103, arg_3104) }
//line :311:1
	var groups__29 any; var root_3252 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3252, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3254 lang.IFn


































































































































	if linked_3253 == nil { ifn_3254 = lang.IFn_Cast(root_3252) } else { ifn_3254 = nil }; var arg_3255 any; var root_3247 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_3248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3247, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3249 lang.IFn; if linked_3248 == nil { ifn_3249 = lang.IFn_Cast(root_3247) } else { ifn_3249 = nil }; var arg_3250 any; var iter__1927001039__auto____29 any; var tmp28 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_New_O_O(tops_QMARK___25, height__27); var tmp29 *jrt.Class; var fncls__3171 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_fn_class; if fncls__3171 == nil { var fncls__3171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_fn_class = fncls__3171d; tmp29 = fncls__3171d } else { tmp29 = fncls__3171 }; iter__1927001039__auto____29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); arg_3250 = lang.IFn_Cast(iter__1927001039__auto____29).Invoke_O__O(names2__23); var arg_3251 any; var iter__1927001039__auto____29_2 any; var tmp30 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_New_O_O(tops_QMARK___25, height__27); var tmp31 *jrt.Class; var fncls__3246 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_fn_class
	if fncls__3246 == nil { var fncls__3246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_fn_class = fncls__3246d; tmp31 = fncls__3246d } else { tmp31 = fncls__3246 }; iter__1927001039__auto____29_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil); arg_3251 = lang.IFn_Cast(iter__1927001039__auto____29_2).Invoke_O__O(names2__23)
//line :442:1
	if linked_3248 == nil { arg_3255 = ifn_3249.Invoke_O_O__O(arg_3250, arg_3251) } else { arg_3255 = linked_3248.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3247, arg_3250, arg_3251) }; if linked_3253 == nil { groups__29 = ifn_3254.Invoke_O__O(arg_3255) } else { groups__29 = linked_3253.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3252, arg_3255) }
//line :311:1
	var top_groups__30 any; var iter__1927001039__auto____30 any; var tmp32 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_New_O_O(tops_QMARK___25, levels__28); var tmp33 *jrt.Class
	var fncls__3600 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_fn_class




































































































































	if fncls__3600 == nil { var fncls__3600d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_fn_class = fncls__3600d; tmp33 = fncls__3600d } else { tmp33 = fncls__3600 }; iter__1927001039__auto____30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var tmp34 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____30); var tmp35 any; var root_3724 any = A_arbace_j2g_world_A_const_80.GetRawRoot__O(); var linked_3725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3724, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3726 lang.IFn; if linked_3725 == nil { ifn_3726 = lang.IFn_Cast(root_3724) } else { ifn_3726 = nil }; var arg_3727 any; var root_3719 any = A_arbace_j2g_world_A_const_77.GetRawRoot__O(); var linked_3720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3719, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3721 lang.IFn; if linked_3720 == nil { ifn_3721 = lang.IFn_Cast(root_3719) } else { ifn_3721 = nil }; var arg_3722 any = A_arbace_j2g_world_A_const_217.GetRawRoot__O(); var arg_3723 any; var root_3715 any = A_arbace_j2g_world_A_const_78.GetRawRoot__O(); var linked_3716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3715, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_3717 lang.IFn; if linked_3716 == nil { ifn_3717 = lang.IFn_Cast(root_3715) } else { ifn_3717 = nil }; var arg_3718 any = levels__28; if linked_3716 == nil { arg_3723 = ifn_3717.Invoke_O__O(arg_3718) } else { arg_3723 = linked_3716.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_3715, arg_3718) }; if linked_3720 == nil { arg_3727 = ifn_3721.Invoke_O_O__O(arg_3722, arg_3723) } else { arg_3727 = linked_3720.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3719, arg_3722, arg_3723) }; if linked_3725 == nil { tmp35 = ifn_3726.Invoke_O__O(arg_3727) } else { tmp35 = linked_3725.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3724, arg_3727) }; top_groups__30 = tmp34.Invoke_O__O(tmp35)







	var tmp36 any; var root_3728 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3728, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3730 lang.IFn; if linked_3729 == nil { ifn_3730 = lang.IFn_Cast(root_3728) } else { ifn_3730 = nil }; var arg_3731 any = names2__23; if linked_3729 == nil { tmp36 = ifn_3730.Invoke_O__O(arg_3731) } else { tmp36 = linked_3729.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3728, arg_3731) }; if jrt.J2g_Truth(tmp36) { var space__31 any; var root_3732 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_3733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3732, A_arbace_j2g_world_id_space_A_fn_class); var ifn_3734 lang.IFn
		if linked_3733 == nil { ifn_3734 = lang.IFn_Cast(root_3732) } else { ifn_3734 = nil }; if linked_3733 == nil { space__31 = ifn_3734.Invoke__O() } else { space__31 = linked_3733.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_3732) }
//line :452:1
		var prev__32 any
		var G__78000409__32_ any = space__31
		if lang.Util_Identical_O_O__Z_NoInit(G__78000409__32_, nil) { prev__32 = nil } else { prev__32 = jrt.ThreadLocal_Cast(G__78000409__32_).Get__O() }
//line :452:1
		var G__78000410__33_ any = space__31


		if lang.Util_Identical_O_O__Z_NoInit(G__78000410__33_, nil) { } else { jrt.ThreadLocal_Cast(G__78000410__33_).Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_j2g_world_A_const_214.GetRawRoot__O()))) }
		var tmp37 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_New_O_O(space__31, prev__32); var tmp38 *jrt.Class; var fncls__3739 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_fn_class; if fncls__3739 == nil { var fncls__3739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_fn_class = fncls__3739d; tmp38 = fncls__3739d } else { tmp38 = fncls__3739 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil).Invoke__O() }
//line :311:1
	var temp__1927000408__auto____31 any; var root_3740 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_3741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3740, A_arbace_j2g_world_id_space_A_fn_class); var ifn_3742 lang.IFn


















































































































































	if linked_3741 == nil { ifn_3742 = lang.IFn_Cast(root_3740) } else { ifn_3742 = nil }; if linked_3741 == nil { temp__1927000408__auto____31 = ifn_3742.Invoke__O() } else { temp__1927000408__auto____31 = linked_3741.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_3740) }; if jrt.J2g_Truth(temp__1927000408__auto____31) { var space__32 any = temp__1927000408__auto____31; var seq_78000413__33 any; var root_3748 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3748, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3750 lang.IFn
		if linked_3749 == nil { ifn_3750 = lang.IFn_Cast(root_3748) } else { ifn_3750 = nil }; var arg_3751 any; var root_3743 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3743, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3745 lang.IFn; if linked_3744 == nil { ifn_3745 = lang.IFn_Cast(root_3743) } else { ifn_3745 = nil }; var arg_3746 any = groups__29; var arg_3747 any = top_groups__30; if linked_3744 == nil { arg_3751 = ifn_3745.Invoke_O_O__O(arg_3746, arg_3747) } else { arg_3751 = linked_3744.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3743, arg_3746, arg_3747) }; if linked_3749 == nil { seq_78000413__33 = ifn_3750.Invoke_O__O(arg_3751) } else { seq_78000413__33 = linked_3749.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3748, arg_3751) }
//line :458:1
		var chunk_78000414__34 any; var count_78000415__35 int64 = 0; var i_78000416__36 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_78000416__36, count_78000415__35) { var gs__37 any = lang.Indexed_Cast(chunk_78000414__34).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000416__36)); var t0__38 int64 = jrt.System_NanoTime__J(); var rs__39 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp40 any; var root_3814 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_3815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3814, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3816 lang.IFn







				if linked_3815 == nil { ifn_3816 = lang.IFn_Cast(root_3814) } else { ifn_3816 = nil }; if linked_3815 == nil { tmp40 = ifn_3816.Invoke__O() } else { tmp40 = linked_3815.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3814) }; var tmp41 any = tmp40; var tmp42 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_New_O_O_O(space__32, analyze_BANG___8, t.F_unit); var tmp43 *jrt.Class; var fncls__3853 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_fn_class
				if fncls__3853 == nil { var fncls__3853d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_fn_class = fncls__3853d; tmp43 = fncls__3853d } else { tmp43 = fncls__3853 }
//line :467:1
				rs__39 = tmp39.Invoke_O_O_O__O(tmp41, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil), gs__37)
//line :459:1
				var ___40 any; var root_3866 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_3867 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3866, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3868 lang.IFn; _ = ___40
















				if linked_3867 == nil { ifn_3868 = lang.IFn_Cast(root_3866) } else { ifn_3868 = nil }; var arg_3869 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); var arg_3870 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_3871 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()); var tmp45 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_New(); var tmp46 *jrt.Class; var fncls__3860 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_fn_class; if fncls__3860 == nil { var fncls__3860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_fn_class = fncls__3860d; tmp46 = fncls__3860d } else { tmp46 = fncls__3860 }; arg_3871 = tmp44.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil), rs__39); if linked_3867 == nil { ___40 = ifn_3868.Invoke_O_O_O__O(arg_3869, arg_3870, arg_3871) } else { ___40 = linked_3867.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3866, arg_3869, arg_3870, arg_3871)
				}
				if jrt.System_Getenv_String__String(Lit_58) != nil {
					var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()); var tmp49 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__39)).Ref(); var tmp50 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__38), 1.0e9)).Ref(); var tmp51 any; var root_3912 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_3913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3912, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3914 lang.IFn
					if linked_3913 == nil { ifn_3914 = lang.IFn_Cast(root_3912) } else { ifn_3914 = nil }; var arg_3915 any = A_arbace_j2g_world_A_const_224.GetRawRoot__O(); var arg_3916 any; var root_3907 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_3908 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3907, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3909 lang.IFn; if linked_3908 == nil { ifn_3909 = lang.IFn_Cast(root_3907) } else { ifn_3909 = nil }; var arg_3910 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var arg_3911 any = rs__39; if linked_3908 == nil { arg_3916 = ifn_3909.Invoke_O_O__O(arg_3910, arg_3911) } else { arg_3916 = linked_3908.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3907, arg_3910, arg_3911) }; if linked_3913 == nil { tmp51 = ifn_3914.Invoke_O_O__O(arg_3915, arg_3916) } else { tmp51 = linked_3913.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3912, arg_3915, arg_3916) }
//line :479:1
					tmp47.Invoke_O__O(tmp48.Invoke_O_O_O_O__O(Lit_59, tmp49, tmp50, jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp51)).Ref()))
//line :478:1
					var seq_78000423__41 any; var root_3887 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3887, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3889 lang.IFn


					if linked_3888 == nil { ifn_3889 = lang.IFn_Cast(root_3887) } else { ifn_3889 = nil }; var arg_3890 any; var root_3882 any = A_arbace_j2g_world_A_const_219.GetRawRoot__O(); var linked_3883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3882, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_3884 lang.IFn; if linked_3883 == nil { ifn_3884 = lang.IFn_Cast(root_3882) } else { ifn_3884 = nil }; var arg_3885 any = A_arbace_j2g_world_A_const_220; var arg_3886 any; var root_3877 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_3878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3877, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3879 lang.IFn; if linked_3878 == nil { ifn_3879 = lang.IFn_Cast(root_3877) } else { ifn_3879 = nil }; var arg_3880 any; var root_3872 any = A_arbace_j2g_world_A_const_221.GetRawRoot__O(); var linked_3873 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3872, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_3874 lang.IFn; if linked_3873 == nil { ifn_3874 = lang.IFn_Cast(root_3872) } else { ifn_3874 = nil }; var arg_3875 any = A_arbace_j2g_world_A_const_222.GetRawRoot__O(); var arg_3876 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); if linked_3873 == nil { arg_3880 = ifn_3874.Invoke_O_O__O(arg_3875, arg_3876) } else { arg_3880 = linked_3873.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_3872, arg_3875, arg_3876) }; var arg_3881 any = rs__39; if linked_3878 == nil { arg_3886 = ifn_3879.Invoke_O_O__O(arg_3880, arg_3881) } else { arg_3886 = linked_3878.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3877, arg_3880, arg_3881) }; if linked_3883 == nil { arg_3890 = ifn_3884.Invoke_O_O__O(arg_3885, arg_3886) } else { arg_3890 = linked_3883.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_3882, arg_3885, arg_3886) }; if linked_3888 == nil { seq_78000423__41 = ifn_3889.Invoke_O__O(arg_3890) } else { seq_78000423__41 = linked_3888.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3887, arg_3890) }
//line :478:1
					var chunk_78000424__42 any; var count_78000425__43 int64 = 0; var i_78000426__44 int64 = 0; L2: for {


						if lang.Numbers_Lt_J_J__Z_NoInit(i_78000426__44, count_78000425__43) { var vec__78000427__45 any = lang.Indexed_Cast(chunk_78000424__42).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000426__44)); var n__46 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000427__45, lang.RT_IntCast_J__I_NoInit(0), nil); var d__47 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000427__45, lang.RT_IntCast_J__I_NoInit(1), nil)
							lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, d__47, n__46))
//line :481:1
							seq_78000423__41, chunk_78000424__42, count_78000425__43, i_78000426__44 = seq_78000423__41, chunk_78000424__42, count_78000425__43, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000426__44); continue L2 } else { var temp__1927000414__auto____45 any; var root_3891 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3891, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3893 lang.IFn; if linked_3892 == nil { ifn_3893 = lang.IFn_Cast(root_3891) } else { ifn_3893 = nil }; var arg_3894 any = seq_78000423__41; if linked_3892 == nil { temp__1927000414__auto____45 = ifn_3893.Invoke_O__O(arg_3894) } else { temp__1927000414__auto____45 = linked_3892.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3891, arg_3894) }; if jrt.J2g_Truth(temp__1927000414__auto____45) { var seq_78000423__46 any = temp__1927000414__auto____45; var tmp52 any; var root_3895 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3895, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3897 lang.IFn; if linked_3896 == nil { ifn_3897 = lang.IFn_Cast(root_3895) } else { ifn_3897 = nil }; var arg_3898 any = seq_78000423__46; if linked_3896 == nil { tmp52 = ifn_3897.Invoke_O__O(arg_3898) } else { tmp52 = linked_3896.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3895, arg_3898) }; if jrt.J2g_Truth(tmp52) { var c__1927000678__auto____47 any; var root_3899 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3899, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3901 lang.IFn; if linked_3900 == nil { ifn_3901 = lang.IFn_Cast(root_3899) } else { ifn_3901 = nil }; var arg_3902 any = seq_78000423__46; if linked_3900 == nil { c__1927000678__auto____47 = ifn_3901.Invoke_O__O(arg_3902) } else { c__1927000678__auto____47 = linked_3900.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3899, arg_3902) }; var tmp53 any; var root_3938 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3938, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3940 lang.IFn; if linked_3939 == nil { ifn_3940 = lang.IFn_Cast(root_3938) } else { ifn_3940 = nil }; var arg_3941 any = seq_78000423__46; if linked_3939 == nil { tmp53 = ifn_3940.Invoke_O__O(arg_3941) } else { tmp53 = linked_3939.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3938, arg_3941) }; seq_78000423__41, chunk_78000424__42, count_78000425__43, i_78000426__44 = tmp53, c__1927000678__auto____47, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____47))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__78000430__47 any; var root_3903 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3903, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3905 lang.IFn; if linked_3904 == nil { ifn_3905 = lang.IFn_Cast(root_3903) } else { ifn_3905 = nil }; var arg_3906 any = seq_78000423__46; if linked_3904 == nil { vec__78000430__47 = ifn_3905.Invoke_O__O(arg_3906) } else { vec__78000430__47 = linked_3904.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3903, arg_3906) }; var n__48 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000430__47, lang.RT_IntCast_J__I_NoInit(0), nil); var d__49 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000430__47, lang.RT_IntCast_J__I_NoInit(1), nil)
								lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, d__49, n__48))
//line :481:1
								var tmp54 any; var root_3952 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_3953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3952, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3954 lang.IFn; if linked_3953 == nil { ifn_3954 = lang.IFn_Cast(root_3952) } else { ifn_3954 = nil }; var arg_3955 any = seq_78000423__46; if linked_3953 == nil { tmp54 = ifn_3954.Invoke_O__O(arg_3955) } else { tmp54 = linked_3953.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3952, arg_3955) }; seq_78000423__41, chunk_78000424__42, count_78000425__43, i_78000426__44 = tmp54, nil, 0, 0; continue L2 } } }
//line :478:1
						break L2 } }
//line :459:1
				seq_78000413__33, chunk_78000414__34, count_78000415__35, i_78000416__36 = seq_78000413__33, chunk_78000414__34, count_78000415__35, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000416__36); continue L1 } else { var temp__1927000414__auto____37 any; var root_3752 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3752, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3754 lang.IFn; if linked_3753 == nil { ifn_3754 = lang.IFn_Cast(root_3752) } else { ifn_3754 = nil }; var arg_3755 any = seq_78000413__33; if linked_3753 == nil { temp__1927000414__auto____37 = ifn_3754.Invoke_O__O(arg_3755) } else { temp__1927000414__auto____37 = linked_3753.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3752, arg_3755) }; if jrt.J2g_Truth(temp__1927000414__auto____37) { var seq_78000413__38 any = temp__1927000414__auto____37; var tmp55 any; var root_3756 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3756, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3758 lang.IFn; if linked_3757 == nil { ifn_3758 = lang.IFn_Cast(root_3756) } else { ifn_3758 = nil }; var arg_3759 any = seq_78000413__38; if linked_3757 == nil { tmp55 = ifn_3758.Invoke_O__O(arg_3759) } else { tmp55 = linked_3757.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3756, arg_3759) }; if jrt.J2g_Truth(tmp55) { var c__1927000678__auto____39 any; var root_3760 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3760, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3762 lang.IFn; if linked_3761 == nil { ifn_3762 = lang.IFn_Cast(root_3760) } else { ifn_3762 = nil }; var arg_3763 any = seq_78000413__38; if linked_3761 == nil { c__1927000678__auto____39 = ifn_3762.Invoke_O__O(arg_3763) } else { c__1927000678__auto____39 = linked_3761.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3760, arg_3763) }; var tmp56 any; var root_3956 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3956, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3958 lang.IFn; if linked_3957 == nil { ifn_3958 = lang.IFn_Cast(root_3956) } else { ifn_3958 = nil }; var arg_3959 any = seq_78000413__38; if linked_3957 == nil { tmp56 = ifn_3958.Invoke_O__O(arg_3959) } else { tmp56 = linked_3957.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3956, arg_3959) }; seq_78000413__33, chunk_78000414__34, count_78000415__35, i_78000416__36 = tmp56, c__1927000678__auto____39, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____39))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var gs__39 any; var root_3764 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3764, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3766 lang.IFn; if linked_3765 == nil { ifn_3766 = lang.IFn_Cast(root_3764) } else { ifn_3766 = nil }; var arg_3767 any = seq_78000413__38; if linked_3765 == nil { gs__39 = ifn_3766.Invoke_O__O(arg_3767) } else { gs__39 = linked_3765.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3764, arg_3767) }; var t0__40 int64 = jrt.System_NanoTime__J(); var rs__41 any; var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp58 any; var root_3960 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_3961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3960, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3962 lang.IFn







					if linked_3961 == nil { ifn_3962 = lang.IFn_Cast(root_3960) } else { ifn_3962 = nil }; if linked_3961 == nil { tmp58 = ifn_3962.Invoke__O() } else { tmp58 = linked_3961.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3960) }; var tmp59 any = tmp58; var tmp60 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_New_O_O_O(space__32, analyze_BANG___8, t.F_unit); var tmp61 *jrt.Class; var fncls__3999 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_fn_class
					if fncls__3999 == nil { var fncls__3999d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_fn_class = fncls__3999d; tmp61 = fncls__3999d } else { tmp61 = fncls__3999 }
//line :467:1
					rs__41 = tmp57.Invoke_O_O_O__O(tmp59, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil), gs__39)
//line :459:1
					var ___42 any; var root_4012 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_4013 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4012, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4014 lang.IFn; _ = ___42
















					if linked_4013 == nil { ifn_4014 = lang.IFn_Cast(root_4012) } else { ifn_4014 = nil }; var arg_4015 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); var arg_4016 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_4017 any; var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()); var tmp63 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_New(); var tmp64 *jrt.Class; var fncls__4006 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_fn_class; if fncls__4006 == nil { var fncls__4006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_fn_class = fncls__4006d; tmp64 = fncls__4006d } else { tmp64 = fncls__4006 }; arg_4017 = tmp62.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp63, tmp64, nil), rs__41); if linked_4013 == nil { ___42 = ifn_4014.Invoke_O_O_O__O(arg_4015, arg_4016, arg_4017) } else { ___42 = linked_4013.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_4012, arg_4015, arg_4016, arg_4017)
					}
					if jrt.System_Getenv_String__String(Lit_58) != nil {
						var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()); var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()); var tmp67 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__41)).Ref(); var tmp68 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__40), 1.0e9)).Ref(); var tmp69 any; var root_4058 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_4059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4058, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_4060 lang.IFn
						if linked_4059 == nil { ifn_4060 = lang.IFn_Cast(root_4058) } else { ifn_4060 = nil }; var arg_4061 any = A_arbace_j2g_world_A_const_224.GetRawRoot__O(); var arg_4062 any; var root_4053 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_4054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4053, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4055 lang.IFn; if linked_4054 == nil { ifn_4055 = lang.IFn_Cast(root_4053) } else { ifn_4055 = nil }; var arg_4056 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var arg_4057 any = rs__41; if linked_4054 == nil { arg_4062 = ifn_4055.Invoke_O_O__O(arg_4056, arg_4057) } else { arg_4062 = linked_4054.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4053, arg_4056, arg_4057) }; if linked_4059 == nil { tmp69 = ifn_4060.Invoke_O_O__O(arg_4061, arg_4062) } else { tmp69 = linked_4059.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_4058, arg_4061, arg_4062) }
//line :479:1
						tmp65.Invoke_O__O(tmp66.Invoke_O_O_O_O__O(Lit_59, tmp67, tmp68, jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp69)).Ref()))
//line :478:1
						var seq_78000439__43 any; var root_4033 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4033, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4035 lang.IFn


						if linked_4034 == nil { ifn_4035 = lang.IFn_Cast(root_4033) } else { ifn_4035 = nil }; var arg_4036 any; var root_4028 any = A_arbace_j2g_world_A_const_219.GetRawRoot__O(); var linked_4029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4028, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_4030 lang.IFn; if linked_4029 == nil { ifn_4030 = lang.IFn_Cast(root_4028) } else { ifn_4030 = nil }; var arg_4031 any = A_arbace_j2g_world_A_const_220; var arg_4032 any; var root_4023 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_4024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4023, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_4025 lang.IFn; if linked_4024 == nil { ifn_4025 = lang.IFn_Cast(root_4023) } else { ifn_4025 = nil }; var arg_4026 any; var root_4018 any = A_arbace_j2g_world_A_const_221.GetRawRoot__O(); var linked_4019 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4018, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_4020 lang.IFn; if linked_4019 == nil { ifn_4020 = lang.IFn_Cast(root_4018) } else { ifn_4020 = nil }; var arg_4021 any = A_arbace_j2g_world_A_const_222.GetRawRoot__O(); var arg_4022 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); if linked_4019 == nil { arg_4026 = ifn_4020.Invoke_O_O__O(arg_4021, arg_4022) } else { arg_4026 = linked_4019.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_4018, arg_4021, arg_4022) }; var arg_4027 any = rs__41; if linked_4024 == nil { arg_4032 = ifn_4025.Invoke_O_O__O(arg_4026, arg_4027) } else { arg_4032 = linked_4024.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_4023, arg_4026, arg_4027) }; if linked_4029 == nil { arg_4036 = ifn_4030.Invoke_O_O__O(arg_4031, arg_4032) } else { arg_4036 = linked_4029.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_4028, arg_4031, arg_4032) }; if linked_4034 == nil { seq_78000439__43 = ifn_4035.Invoke_O__O(arg_4036) } else { seq_78000439__43 = linked_4034.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4033, arg_4036) }
//line :478:1
						var chunk_78000440__44 any; var count_78000441__45 int64 = 0; var i_78000442__46 int64 = 0; L3: for {


							if lang.Numbers_Lt_J_J__Z_NoInit(i_78000442__46, count_78000441__45) { var vec__78000443__47 any = lang.Indexed_Cast(chunk_78000440__44).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000442__46)); var n__48_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000443__47, lang.RT_IntCast_J__I_NoInit(0), nil); var d__49_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000443__47, lang.RT_IntCast_J__I_NoInit(1), nil)
								lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, d__49_2, n__48_2))
//line :481:1
								seq_78000439__43, chunk_78000440__44, count_78000441__45, i_78000442__46 = seq_78000439__43, chunk_78000440__44, count_78000441__45, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000442__46); continue L3 } else { var temp__1927000414__auto____47 any; var root_4037 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4037, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4039 lang.IFn; if linked_4038 == nil { ifn_4039 = lang.IFn_Cast(root_4037) } else { ifn_4039 = nil }; var arg_4040 any = seq_78000439__43; if linked_4038 == nil { temp__1927000414__auto____47 = ifn_4039.Invoke_O__O(arg_4040) } else { temp__1927000414__auto____47 = linked_4038.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4037, arg_4040) }; if jrt.J2g_Truth(temp__1927000414__auto____47) { var seq_78000439__48 any = temp__1927000414__auto____47; var tmp70 any; var root_4041 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_4042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4041, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4043 lang.IFn; if linked_4042 == nil { ifn_4043 = lang.IFn_Cast(root_4041) } else { ifn_4043 = nil }; var arg_4044 any = seq_78000439__48; if linked_4042 == nil { tmp70 = ifn_4043.Invoke_O__O(arg_4044) } else { tmp70 = linked_4042.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4041, arg_4044) }; if jrt.J2g_Truth(tmp70) { var c__1927000678__auto____49 any; var root_4045 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_4046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4045, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4047 lang.IFn; if linked_4046 == nil { ifn_4047 = lang.IFn_Cast(root_4045) } else { ifn_4047 = nil }; var arg_4048 any = seq_78000439__48; if linked_4046 == nil { c__1927000678__auto____49 = ifn_4047.Invoke_O__O(arg_4048) } else { c__1927000678__auto____49 = linked_4046.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4045, arg_4048) }; var tmp71 any; var root_4084 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_4085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4084, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4086 lang.IFn; if linked_4085 == nil { ifn_4086 = lang.IFn_Cast(root_4084) } else { ifn_4086 = nil }; var arg_4087 any = seq_78000439__48; if linked_4085 == nil { tmp71 = ifn_4086.Invoke_O__O(arg_4087) } else { tmp71 = linked_4085.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4084, arg_4087) }; seq_78000439__43, chunk_78000440__44, count_78000441__45, i_78000442__46 = tmp71, c__1927000678__auto____49, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____49))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__78000446__49 any; var root_4049 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_4050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4049, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4051 lang.IFn; if linked_4050 == nil { ifn_4051 = lang.IFn_Cast(root_4049) } else { ifn_4051 = nil }; var arg_4052 any = seq_78000439__48; if linked_4050 == nil { vec__78000446__49 = ifn_4051.Invoke_O__O(arg_4052) } else { vec__78000446__49 = linked_4050.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4049, arg_4052) }; var n__50 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000446__49, lang.RT_IntCast_J__I_NoInit(0), nil); var d__51 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000446__49, lang.RT_IntCast_J__I_NoInit(1), nil)
									lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, d__51, n__50))
//line :481:1
									var tmp72 any; var root_4098 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_4099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4098, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4100 lang.IFn; if linked_4099 == nil { ifn_4100 = lang.IFn_Cast(root_4098) } else { ifn_4100 = nil }; var arg_4101 any = seq_78000439__48; if linked_4099 == nil { tmp72 = ifn_4100.Invoke_O__O(arg_4101) } else { tmp72 = linked_4099.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4098, arg_4101) }; seq_78000439__43, chunk_78000440__44, count_78000441__45, i_78000442__46 = tmp72, nil, 0, 0; continue L3 } } }
//line :478:1
							break L3 } }
//line :459:1
					var tmp73 any; var root_4102 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_4103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4102, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4104 lang.IFn; if linked_4103 == nil { ifn_4104 = lang.IFn_Cast(root_4102) } else { ifn_4104 = nil }; var arg_4105 any = seq_78000413__38; if linked_4103 == nil { tmp73 = ifn_4104.Invoke_O__O(arg_4105) } else { tmp73 = linked_4103.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4102, arg_4105) }; seq_78000413__33, chunk_78000414__34, count_78000415__35, i_78000416__36 = tmp73, nil, 0, 0; continue L1 } } }
//line :458:1
			break L1 } } else {

























				var root_3768 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_3769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3768, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3770 lang.IFn; if linked_3769 == nil { ifn_3770 = lang.IFn_Cast(root_3768) } else { ifn_3770 = nil }; var arg_3771 any = analyze_BANG___8; var arg_3772 any = names2__23; if linked_3769 == nil { ifn_3770.Invoke_O_O__O(arg_3771, arg_3772) } else { linked_3769.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3768, arg_3771, arg_3772) } }
	lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_225)
//line :311:1
	var G__78000449__31_ any = runtime__14














































































































































































	if lang.Util_Identical_O_O__Z_NoInit(G__78000449__31_, nil) { } else { var root_3773 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3775 lang.IFn; if linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any = G__78000449__31_; if linked_3774 == nil { ifn_3775.Invoke_O__O(arg_3776) } else { linked_3774.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3773, arg_3776) } }
//line :311:1
	var main__31 any; var root_3777 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3777, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3779 lang.IFn

















































































































































































	if linked_3778 == nil { ifn_3779 = lang.IFn_Cast(root_3777) } else { ifn_3779 = nil }; var arg_3780 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); if linked_3778 == nil { main__31 = ifn_3779.Invoke_O__O(arg_3780) } else { main__31 = linked_3778.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3777, arg_3780) }
//line :311:1
	var late__32 any; var root_3781 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_3782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3781, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_3783 lang.IFn


















































































































































































	if linked_3782 == nil { ifn_3783 = lang.IFn_Cast(root_3781) } else { ifn_3783 = nil }; var arg_3784 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(names1__10)), int64(lang.RT_Count_O__I_NoInit(names2__23)))).Ref(); var arg_3785 any = main__31; if linked_3782 == nil { late__32 = ifn_3783.Invoke_O_O__O(arg_3784, arg_3785) } else { late__32 = linked_3782.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_3781, arg_3784, arg_3785) }
	lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_64), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(late__32)).Ref(), nil)).Ref())
	var root_3806 any = A_arbace_j2g_world_A_const_181.GetRawRoot__O(); var linked_3807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3806, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_3808 lang.IFn; if linked_3807 == nil { ifn_3808 = lang.IFn_Cast(root_3806) } else { ifn_3808 = nil }; var arg_3809 any; var tmp74 *lang.Keyword = A_arbace_j2g_world_A_const_133; var tmp75 any; var t__8 any = t.F_unit; t.F_unit = nil; tmp75 = t__8; arg_3809 = tmp74.Invoke_O__O(tmp75); var arg_3810 any; var root_3802 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3802, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3804 lang.IFn; if linked_3803 == nil { ifn_3804 = lang.IFn_Cast(root_3802) } else { ifn_3804 = nil }; var arg_3805 any; var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()); var tmp77 any; var root_3790 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_3791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3790, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_3792 lang.IFn; if linked_3791 == nil { ifn_3792 = lang.IFn_Cast(root_3790) } else { ifn_3792 = nil }; var arg_3793 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names1__10)).Ref(); var arg_3794 any; var root_3786 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3786, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3788 lang.IFn; if linked_3787 == nil { ifn_3788 = lang.IFn_Cast(root_3786) } else { ifn_3788 = nil }; var arg_3789 any = rt_order__13; if linked_3787 == nil { arg_3794 = ifn_3788.Invoke_O__O(arg_3789) } else { arg_3794 = linked_3787.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3786, arg_3789) }; if linked_3791 == nil { tmp77 = ifn_3792.Invoke_O_O__O(arg_3793, arg_3794) } else { tmp77 = linked_3791.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_3790, arg_3793, arg_3794) }; arg_3805 = tmp76.Invoke_O_O_O_O__O(names1__10, names2__23, tmp77, late__32); if linked_3803 == nil { arg_3810 = ifn_3804.Invoke_O__O(arg_3805) } else { arg_3810 = linked_3803.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3802, arg_3805) }; if linked_3807 == nil { ifn_3808.Invoke_O_O__O(arg_3809, arg_3810) } else { linked_3807.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_3806, arg_3809, arg_3810) }
//line :311:1
	var temp__1927000414__auto____31 any; var root_3811 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, A_arbace_j2g_world_id_space_A_fn_class); var ifn_3813 lang.IFn





















































































































































































	if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; if linked_3812 == nil { temp__1927000414__auto____31 = ifn_3813.Invoke__O() } else { temp__1927000414__auto____31 = linked_3812.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_3811) }; if jrt.J2g_Truth(temp__1927000414__auto____31) { var space__32_2 any = temp__1927000414__auto____31; jrt.ThreadLocal_Cast(space__32_2).Remove__V() }
	lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_226)
	var tmp78 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()); var tmp79 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil); var tmp80 any; var root_3672 any = A_arbace_j2g_world_A_const_213.GetRawRoot__O(); var linked_3673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3672, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3674 lang.IFn; if linked_3673 == nil { ifn_3674 = lang.IFn_Cast(root_3672) } else { ifn_3674 = nil }; var arg_3675 any = Lit_66; var arg_3676 any; var iter__1927001039__auto____33 any; var tmp81 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_New(); var tmp82 *jrt.Class; var fncls__3667 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_fn_class; if fncls__3667 == nil { var fncls__3667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_fn_class = fncls__3667d; tmp82 = fncls__3667d } else { tmp82 = fncls__3667 }; iter__1927001039__auto____33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp81, tmp82, nil); var tmp83 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____33); var tmp84 any; var root_3668 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3668, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3670 lang.IFn; if linked_3669 == nil { ifn_3670 = lang.IFn_Cast(root_3668) } else { ifn_3670 = nil }; var arg_3671 any = laps__4; if linked_3669 == nil { tmp84 = ifn_3670.Invoke_O__O(arg_3671) } else { tmp84 = linked_3669.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3668, arg_3671) }; arg_3676 = tmp83.Invoke_O__O(tmp84); if linked_3673 == nil { tmp80 = ifn_3674.Invoke_O_O__O(arg_3675, arg_3676) } else { tmp80 = linked_3673.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3672, arg_3675, arg_3676) }; tmp1 = tmp78.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp79, jrt.RefArrayOf(jrt.Object_class, nil, tmp80)).Ref()) }; return nil }(); var root_3681 any = /*line :311:1*/A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_3682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3681, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3683 lang.IFn; if linked_3682 == nil { ifn_3683 = lang.IFn_Cast(root_3681) } else { ifn_3683 = nil }; if linked_3682 == nil { ifn_3683.Invoke__O() } else { linked_3682.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3681) }; if tmp85 != nil { panic(tmp85) }; return tmp1 }










func A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A{}; t.Ctor_O_O(p0, p1); return t }
//line :322:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A) Ctor_O_O(c__t, c__laps any) { t.F_t = c__t; t.F_laps = c__laps }
//line :322:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var root_2465 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2465, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2467 lang.IFn; if linked_2466 == nil { ifn_2467 = lang.IFn_Cast(root_2465) } else { ifn_2467 = nil }; var arg_2468 any = t.F_laps; var arg_2469 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2470 any; var tmp1 jrt.Number_I; var na_2456 int64 = x__2; var na_2457 any; var root_2458 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2458, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2460 lang.IFn; if linked_2459 == nil { ifn_2460 = lang.IFn_Cast(root_2458) } else { ifn_2460 = nil }; var arg_2461 any = t.F_t; if linked_2459 == nil { na_2457 = ifn_2460.Invoke_O__O(arg_2461) } else { na_2457 = linked_2459.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2458, arg_2461) }; if jrt.Long_InstanceOf(na_2457) { var n0_2462 int64 = na_2456; var n1_2463 int64 = jrt.NN(jrt.Long_Cast(na_2457)).LongValue__J(); var nr_2464 int64 = n0_2462 - n1_2463; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_2463 == -9223372036854775808); if tmp3 { tmp3 = (n0_2462^n1_2463)&(n0_2462^nr_2464) >= 0 }; tmp2 = tmp3; if tmp2 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2464)) } else { tmp1 = lang.Numbers_Minus_J_O__Number_NoInit(na_2456, na_2457) } } else { tmp1 = lang.Numbers_Minus_J_O__Number_NoInit(na_2456, na_2457) }; arg_2470 = lang.Tuple_Create_O_O__IPersistentVector(k__1, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D_NoInit(tmp1, 1.0e7)), 100.0)).Ref()); if linked_2466 == nil { ifn_2467.Invoke_O_O_O__O(arg_2468, arg_2469, arg_2470) } else { linked_2466.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2465, arg_2468, arg_2469, arg_2470) }; var root_2451 any = A_arbace_j2g_world_A_const_181.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = t.F_t; var arg_2455 any = jrt.Long_ValueOf_J__Long_NoInit(x__2).Ref(); if linked_2452 == nil { return ifn_2453.Invoke_O_O__O(arg_2454, arg_2455) } else { return linked_2452.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_2451, arg_2454, arg_2455) } }





func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :328:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A) Ctor_O_O_O(c__variants, c__failed, c__applied any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_applied = c__applied }
//line :328:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A) Invoke_O_O__O(self, ps__1 any) any { { var units__2 any; var root_2653 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2655 lang.IFn
														if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any; var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_New(); var tmp2 *jrt.Class; var fncls__2652 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_fn_class; if fncls__2652 == nil { var fncls__2652d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_fn_class = fncls__2652d; tmp2 = fncls__2652d } else { tmp2 = fncls__2652 }; arg_2656 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2657 any = lang.PersistentVector_EMPTY.Ref(); var arg_2658 any = ps__1; if linked_2654 == nil { units__2 = ifn_2655.Invoke_O_O_O__O(arg_2656, arg_2657, arg_2658) } else { units__2 = linked_2654.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2653, arg_2656, arg_2657, arg_2658) }
//line :328:1
	var parsed__3 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp4 any; var root_2659 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_2660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2659, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2661 lang.IFn










	if linked_2660 == nil { ifn_2661 = lang.IFn_Cast(root_2659) } else { ifn_2661 = nil }; if linked_2660 == nil { tmp4 = ifn_2661.Invoke__O() } else { tmp4 = linked_2660.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2659) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_New_O_O(t.F_variants, t.F_applied); var tmp7 *jrt.Class; var fncls__2705 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_fn_class
	if fncls__2705 == nil { var fncls__2705d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_fn_class = fncls__2705d; tmp7 = fncls__2705d } else { tmp7 = fncls__2705 }
//line :339:1
	parsed__3 = tmp3.Invoke_O_O_O__O(tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), units__2)
//line :328:1
	var seq_78000281__4 any; var root_2718 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2718, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2720 lang.IFn























	if linked_2719 == nil { ifn_2720 = lang.IFn_Cast(root_2718) } else { ifn_2720 = nil }; var arg_2721 any; var root_2712 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_2713 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2712, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2714 lang.IFn; if linked_2713 == nil { ifn_2714 = lang.IFn_Cast(root_2712) } else { ifn_2714 = nil }; var arg_2715 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var arg_2716 any = units__2; var arg_2717 any = parsed__3; if linked_2713 == nil { arg_2721 = ifn_2714.Invoke_O_O_O__O(arg_2715, arg_2716, arg_2717) } else { arg_2721 = linked_2713.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_2712, arg_2715, arg_2716, arg_2717) }; if linked_2719 == nil { seq_78000281__4 = ifn_2720.Invoke_O__O(arg_2721) } else { seq_78000281__4 = linked_2719.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2718, arg_2721) }
//line :328:1
	var chunk_78000282__5 any; var count_78000283__6 int64 = 0; var i_78000284__7 int64 = 0; L1: for {























		if lang.Numbers_Lt_J_J__Z_NoInit(i_78000284__7, count_78000283__6) { var vec__78000285__8 any = lang.Indexed_Cast(chunk_78000282__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000284__7)); var vec__78000288__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000285__8, lang.RT_IntCast_J__I_NoInit(0), nil); var file__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000288__9, lang.RT_IntCast_J__I_NoInit(0), nil); var map__78000291__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000285__8, lang.RT_IntCast_J__I_NoInit(1), nil); var map__78000291__12 any; if lang.ISeq_InstanceOf(map__78000291__11) { var tmp8 any; var root_2722 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2722, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2724 lang.IFn; if linked_2723 == nil { ifn_2724 = lang.IFn_Cast(root_2722) } else { ifn_2724 = nil }; var arg_2725 any = map__78000291__11; if linked_2723 == nil { tmp8 = ifn_2724.Invoke_O__O(arg_2725) } else { tmp8 = linked_2723.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2722, arg_2725) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_2726 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2726, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2728 lang.IFn; if linked_2727 == nil { ifn_2728 = lang.IFn_Cast(root_2726) } else { ifn_2728 = nil }; var arg_2729 any = map__78000291__11; if linked_2727 == nil { tmp9 = ifn_2728.Invoke_O__O(arg_2729) } else { tmp9 = linked_2727.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2726, arg_2729) }; map__78000291__12 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp9, jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 any; var root_2730 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2732 lang.IFn; if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = map__78000291__11; if linked_2731 == nil { tmp10 = ifn_2732.Invoke_O__O(arg_2733) } else { tmp10 = linked_2731.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2730, arg_2733) }; if jrt.J2g_Truth(tmp10) { var root_2734 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2734, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2736 lang.IFn; if linked_2735 == nil { ifn_2736 = lang.IFn_Cast(root_2734) } else { ifn_2736 = nil }; var arg_2737 any = map__78000291__11; if linked_2735 == nil { map__78000291__12 = ifn_2736.Invoke_O__O(arg_2737) } else { map__78000291__12 = linked_2735.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2734, arg_2737) } } else { map__78000291__12 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000291__12 = map__78000291__11 }; var pc__13 any = lang.RT_Get_O_O__O_NoInit(map__78000291__12, A_arbace_j2g_world_A_const_187); var nsobj__14 any = lang.RT_Get_O_O__O_NoInit(map__78000291__12, A_arbace_j2g_world_A_const_188); var members__15 any = lang.RT_Get_O_O__O_NoInit(map__78000291__12, A_arbace_j2g_world_A_const_149); var error__16 any = lang.RT_Get_O_O__O_NoInit(map__78000291__12, A_arbace_j2g_world_A_const_189)
			if jrt.J2g_Truth(error__16) {
				var root_2770 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2772 lang.IFn; if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = t.F_failed; var arg_2774 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2775 any = error__16; if linked_2771 == nil { ifn_2772.Invoke_O_O_O__O(arg_2773, arg_2774, arg_2775) } else { linked_2771.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2770, arg_2773, arg_2774, arg_2775) } } else {
					var tmp11 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_New_O_O_O_O_O(nsobj__14, pc__13, t.F_failed, members__15, file__10); var tmp12 *jrt.Class; var fncls__2800 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_fn_class; if fncls__2800 == nil { var fncls__2800d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_fn_class = fncls__2800d; tmp12 = fncls__2800d } else { tmp12 = fncls__2800 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O() }
//line :352:1
			seq_78000281__4, chunk_78000282__5, count_78000283__6, i_78000284__7 = seq_78000281__4, chunk_78000282__5, count_78000283__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000284__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_2738 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2740 lang.IFn; if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var arg_2741 any = seq_78000281__4; if linked_2739 == nil { temp__1927000414__auto____8 = ifn_2740.Invoke_O__O(arg_2741) } else { temp__1927000414__auto____8 = linked_2739.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2738, arg_2741) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_78000281__9 any = temp__1927000414__auto____8; var tmp13 any; var root_2742 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any = seq_78000281__9; if linked_2743 == nil { tmp13 = ifn_2744.Invoke_O__O(arg_2745) } else { tmp13 = linked_2743.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2742, arg_2745) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____10 any; var root_2746 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2746, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2748 lang.IFn; if linked_2747 == nil { ifn_2748 = lang.IFn_Cast(root_2746) } else { ifn_2748 = nil }; var arg_2749 any = seq_78000281__9; if linked_2747 == nil { c__1927000678__auto____10 = ifn_2748.Invoke_O__O(arg_2749) } else { c__1927000678__auto____10 = linked_2747.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2746, arg_2749) }; var tmp14 any; var root_2801 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2801, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2803 lang.IFn; if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any = seq_78000281__9; if linked_2802 == nil { tmp14 = ifn_2803.Invoke_O__O(arg_2804) } else { tmp14 = linked_2802.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2801, arg_2804) }; seq_78000281__4, chunk_78000282__5, count_78000283__6, i_78000284__7 = tmp14, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__78000295__10 any; var root_2750 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2750, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2752 lang.IFn; if linked_2751 == nil { ifn_2752 = lang.IFn_Cast(root_2750) } else { ifn_2752 = nil }; var arg_2753 any = seq_78000281__9; if linked_2751 == nil { vec__78000295__10 = ifn_2752.Invoke_O__O(arg_2753) } else { vec__78000295__10 = linked_2751.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2750, arg_2753) }; var vec__78000298__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000295__10, lang.RT_IntCast_J__I_NoInit(0), nil); var file__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000298__11, lang.RT_IntCast_J__I_NoInit(0), nil); var map__78000301__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000295__10, lang.RT_IntCast_J__I_NoInit(1), nil); var map__78000301__14 any; if lang.ISeq_InstanceOf(map__78000301__13) { var tmp15 any; var root_2754 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2754, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2756 lang.IFn; if linked_2755 == nil { ifn_2756 = lang.IFn_Cast(root_2754) } else { ifn_2756 = nil }; var arg_2757 any = map__78000301__13; if linked_2755 == nil { tmp15 = ifn_2756.Invoke_O__O(arg_2757) } else { tmp15 = linked_2755.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2754, arg_2757) }; if jrt.J2g_Truth(tmp15) { var tmp16 any; var root_2758 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2758, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2760 lang.IFn; if linked_2759 == nil { ifn_2760 = lang.IFn_Cast(root_2758) } else { ifn_2760 = nil }; var arg_2761 any = map__78000301__13; if linked_2759 == nil { tmp16 = ifn_2760.Invoke_O__O(arg_2761) } else { tmp16 = linked_2759.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2758, arg_2761) }; map__78000301__14 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp16, jrt.Object_class.ArrayClass())).Ref() } else { var tmp17 any; var root_2762 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = map__78000301__13; if linked_2763 == nil { tmp17 = ifn_2764.Invoke_O__O(arg_2765) } else { tmp17 = linked_2763.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2762, arg_2765) }; if jrt.J2g_Truth(tmp17) { var root_2766 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2768 lang.IFn; if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any = map__78000301__13; if linked_2767 == nil { map__78000301__14 = ifn_2768.Invoke_O__O(arg_2769) } else { map__78000301__14 = linked_2767.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2766, arg_2769) } } else { map__78000301__14 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000301__14 = map__78000301__13 }; var pc__15 any = lang.RT_Get_O_O__O_NoInit(map__78000301__14, A_arbace_j2g_world_A_const_187); var nsobj__16 any = lang.RT_Get_O_O__O_NoInit(map__78000301__14, A_arbace_j2g_world_A_const_188); var members__17 any = lang.RT_Get_O_O__O_NoInit(map__78000301__14, A_arbace_j2g_world_A_const_149); var error__18 any = lang.RT_Get_O_O__O_NoInit(map__78000301__14, A_arbace_j2g_world_A_const_189)
				if jrt.J2g_Truth(error__18) {
					var root_2805 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2807 lang.IFn; if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any = t.F_failed; var arg_2809 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2810 any = error__18; if linked_2806 == nil { ifn_2807.Invoke_O_O_O__O(arg_2808, arg_2809, arg_2810) } else { linked_2806.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2805, arg_2808, arg_2809, arg_2810) } } else {
						var tmp18 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_New_O_O_O_O_O(nsobj__16, pc__15, members__17, t.F_failed, file__12); var tmp19 *jrt.Class; var fncls__2835 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_fn_class; if fncls__2835 == nil { var fncls__2835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_fn_class = fncls__2835d; tmp19 = fncls__2835d } else { tmp19 = fncls__2835 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O() }
//line :352:1
				var tmp20 any; var root_2836 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2836, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2838 lang.IFn; if linked_2837 == nil { ifn_2838 = lang.IFn_Cast(root_2836) } else { ifn_2838 = nil }; var arg_2839 any = seq_78000281__9; if linked_2837 == nil { tmp20 = ifn_2838.Invoke_O__O(arg_2839) } else { tmp20 = linked_2837.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2836, arg_2839) }; seq_78000281__4, chunk_78000282__5, count_78000283__6, i_78000284__7 = tmp20, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :328:1*/panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_New() *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A) Ctor() {}
//line :329:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A) Invoke_O_O_O__O(self, acc__1, p__78000249__2 any) any { var map__78000251__3 any = p__78000249__2; var map__78000251__4 any; if lang.ISeq_InstanceOf(map__78000251__3) { var tmp1 any; var root_2472 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = map__78000251__3; if linked_2473 == nil { tmp1 = ifn_2474.Invoke_O__O(arg_2475) } else { tmp1 = linked_2473.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2472, arg_2475) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2476 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = map__78000251__3; if linked_2477 == nil { tmp2 = ifn_2478.Invoke_O__O(arg_2479) } else { tmp2 = linked_2477.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2476, arg_2479) }; map__78000251__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2480 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = map__78000251__3; if linked_2481 == nil { tmp3 = ifn_2482.Invoke_O__O(arg_2483) } else { tmp3 = linked_2481.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2480, arg_2483) }; if jrt.J2g_Truth(tmp3) { var root_2484 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2486 lang.IFn; if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = map__78000251__3; if linked_2485 == nil { map__78000251__4 = ifn_2486.Invoke_O__O(arg_2487) } else { map__78000251__4 = linked_2485.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2484, arg_2487) } } else { map__78000251__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000251__4 = map__78000251__3 }; var file__5 any = lang.RT_Get_O_O__O_NoInit(map__78000251__4, A_arbace_j2g_world_A_const_168); var forms__6 any = lang.RT_Get_O_O__O_NoInit(map__78000251__4, A_arbace_j2g_world_A_const_50); var ns__7 any = lang.RT_Get_O_O__O_NoInit(map__78000251__4, A_arbace_j2g_world_A_const_143); var tmp4 any; var root_2488 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2488, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2490 lang.IFn; if
																		linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = ns__7; if linked_2489 == nil { tmp4 = ifn_2490.Invoke_O__O(arg_2491) } else { tmp4 = linked_2489.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2488, arg_2491) }; if jrt.J2g_Truth(tmp4) { return acc__1 } else {

		var root_2568 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_world_A_const_182; var arg_2571 any = tmp5.Invoke_O_O__O(tmp6, A_arbace_j2g_world_A_const_182.Get__O()); if linked_2569 == nil { ifn_2570.Invoke_O__O(arg_2571) } else { linked_2569.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2568, arg_2571) }
//line :330:1
		var tmp7 any; tmp22 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_78000253__10 any; var root_2572 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2574 lang.IFn


			if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = forms__6; if linked_2573 == nil { seq_78000253__10 = ifn_2574.Invoke_O__O(arg_2575) } else { seq_78000253__10 = linked_2573.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2572, arg_2575) }
//line :330:1
			var chunk_78000254__11 any; var count_78000255__12 int64 = 0; var i_78000256__13 int64 = 0; L1: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i_78000256__13, count_78000255__12) { var fm__14 any = lang.Indexed_Cast(chunk_78000254__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000256__13)); var tmp8 any; var and__1927000168__auto____15 any; var root_2576 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_2578 lang.IFn
					if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = fm__14; if linked_2577 == nil { and__1927000168__auto____15 = ifn_2578.Invoke_O__O(arg_2579) } else { and__1927000168__auto____15 = linked_2577.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_2576, arg_2579) }; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_2584 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_2586 lang.IFn; if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any; var root_2580 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2582 lang.IFn; if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = fm__14; if linked_2581 == nil { arg_2587 = ifn_2582.Invoke_O__O(arg_2583) } else { arg_2587 = linked_2581.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2580, arg_2583) }; if linked_2585 == nil { and__1927000168__auto____16 = ifn_2586.Invoke_O__O(arg_2587) } else { and__1927000168__auto____16 = linked_2585.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_2584, arg_2587) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_183); var tmp10 any; var root_2620 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any; var root_2616 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = fm__14; if linked_2617 == nil { arg_2623 = ifn_2618.Invoke_O__O(arg_2619) } else { arg_2623 = linked_2617.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2616, arg_2619) }; if linked_2621 == nil { tmp10 = ifn_2622.Invoke_O__O(arg_2623) } else { tmp10 = linked_2621.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2620, arg_2623) }; tmp8 = tmp9.Invoke_O__O(tmp10) } else { tmp8 = and__1927000168__auto____16 } } else { tmp8 = and__1927000168__auto____15 }
//line :333:1
					if jrt.J2g_Truth(tmp8) {

						var root_2624 any = A_arbace_j2g_world_A_const_185.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_classes_analyze.A_arbace_classes_analyze_eval_ns_form_BANG__A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any = fm__14; if linked_2625 == nil { ifn_2626.Invoke_O__O(arg_2627) } else { linked_2625.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_eval_ns_form_BANG__A).Invoke_O_O__O(root_2624, arg_2627) }
//line :333:1
						seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = seq_78000253__10, chunk_78000254__11, count_78000255__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000256__13); continue L1 } else { seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = seq_78000253__10, chunk_78000254__11, count_78000255__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000256__13); continue L1 } } else { var temp__1927000414__auto____14 any; var root_2588 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2588, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2590 lang.IFn; if linked_2589 == nil { ifn_2590 = lang.IFn_Cast(root_2588) } else { ifn_2590 = nil }; var arg_2591 any = seq_78000253__10; if linked_2589 == nil { temp__1927000414__auto____14 = ifn_2590.Invoke_O__O(arg_2591) } else { temp__1927000414__auto____14 = linked_2589.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2588, arg_2591) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_78000253__15 any = temp__1927000414__auto____14; var tmp11 any; var root_2592 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2592, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = seq_78000253__15; if linked_2593 == nil { tmp11 = ifn_2594.Invoke_O__O(arg_2595) } else { tmp11 = linked_2593.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2592, arg_2595) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____16 any; var root_2596 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2596, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2598 lang.IFn; if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any = seq_78000253__15; if linked_2597 == nil { c__1927000678__auto____16 = ifn_2598.Invoke_O__O(arg_2599) } else { c__1927000678__auto____16 = linked_2597.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2596, arg_2599) }; var tmp12 any; var root_2628 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2628, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2630 lang.IFn; if linked_2629 == nil { ifn_2630 = lang.IFn_Cast(root_2628) } else { ifn_2630 = nil }; var arg_2631 any = seq_78000253__15; if linked_2629 == nil { tmp12 = ifn_2630.Invoke_O__O(arg_2631) } else { tmp12 = linked_2629.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2628, arg_2631) }; seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = tmp12, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fm__16 any; var root_2600 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2602 lang.IFn; if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = seq_78000253__15; if linked_2601 == nil { fm__16 = ifn_2602.Invoke_O__O(arg_2603) } else { fm__16 = linked_2601.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2600, arg_2603) }; var tmp13 any; var and__1927000168__auto____17 any; var root_2604 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_2606 lang.IFn
							if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any = fm__16; if linked_2605 == nil { and__1927000168__auto____17 = ifn_2606.Invoke_O__O(arg_2607) } else { and__1927000168__auto____17 = linked_2605.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_2604, arg_2607) }; if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18 any; var root_2612 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any; var root_2608 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = fm__16; if linked_2609 == nil { arg_2615 = ifn_2610.Invoke_O__O(arg_2611) } else { arg_2615 = linked_2609.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2608, arg_2611) }; if linked_2613 == nil { and__1927000168__auto____18 = ifn_2614.Invoke_O__O(arg_2615) } else { and__1927000168__auto____18 = linked_2613.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_2612, arg_2615) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_184); var tmp15 any; var root_2636 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any; var root_2632 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = fm__16; if linked_2633 == nil { arg_2639 = ifn_2634.Invoke_O__O(arg_2635) } else { arg_2639 = linked_2633.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2632, arg_2635) }; if linked_2637 == nil { tmp15 = ifn_2638.Invoke_O__O(arg_2639) } else { tmp15 = linked_2637.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2636, arg_2639) }; tmp13 = tmp14.Invoke_O__O(tmp15) } else { tmp13 = and__1927000168__auto____18 } } else { tmp13 = and__1927000168__auto____17 }
//line :333:1
							if jrt.J2g_Truth(tmp13) {

								var root_2640 any = A_arbace_j2g_world_A_const_185.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, aot_arbace_classes_analyze.A_arbace_classes_analyze_eval_ns_form_BANG__A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any = fm__16; if linked_2641 == nil { ifn_2642.Invoke_O__O(arg_2643) } else { linked_2641.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_eval_ns_form_BANG__A).Invoke_O_O__O(root_2640, arg_2643) }
//line :333:1
								var tmp16 any; var root_2644 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any = seq_78000253__15; if linked_2645 == nil { tmp16 = ifn_2646.Invoke_O__O(arg_2647) } else { tmp16 = linked_2645.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2644, arg_2647) }; seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = tmp16, nil, 0, 0; continue L1 } else { var tmp17 any; var root_2648 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any = seq_78000253__15; if linked_2649 == nil { tmp17 = ifn_2650.Invoke_O__O(arg_2651) } else { tmp17 = linked_2649.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2648, arg_2651) }; seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = tmp17, nil, 0, 0; continue L1 } } } }
//line :330:1
				break L1 }; var nsobj__10 any = A_arbace_j2g_world_A_const_182.Get__O(); var root_2555 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2557 lang.IFn






			if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = acc__1; var arg_2559 any; var iter__1927001039__auto____11 any; var tmp18 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_New_O_O_O(nsobj__10, file__5, ns__7); var tmp19 *jrt.Class; var fncls__2550 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_fn_class; if fncls__2550 == nil { var fncls__2550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_fn_class = fncls__2550d; tmp19 = fncls__2550d } else { tmp19 = fncls__2550 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp20 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11); var tmp21 any; var root_2551 any = A_arbace_j2g_world_A_const_90.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, A_arbace_j2g_world_class_forms_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = forms__6; if linked_2552 == nil { tmp21 = ifn_2553.Invoke_O__O(arg_2554) } else { tmp21 = linked_2552.(*A_arbace_j2g_world_class_forms_A).Invoke_O_O__O(root_2551, arg_2554) }; arg_2559 = tmp20.Invoke_O__O(tmp21); if linked_2556 == nil { tmp7 = ifn_2557.Invoke_O_O__O(arg_2558, arg_2559) } else { tmp7 = linked_2556.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2555, arg_2558, arg_2559) } }; return nil }()
//line :330:1
		var root_2560 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2562 lang.IFn

		if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; if linked_2561 == nil { ifn_2562.Invoke__O() } else { linked_2561.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2560) }
//line :330:1
		if tmp22 != nil { panic(tmp22) }; return tmp7 } }






func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A) Ctor_O_O_O(c__nsobj, c__file, c__ns any) { t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A) Invoke_O_O__O(self, s__78000258__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_New_O_O_O_O_O(t.F_nsobj, t.F_file, s__78000258__1, self, t.F_ns); var tmp2 *jrt.Class; var fncls__2549 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_fn_class; if fncls__2549 == nil { var fncls__2549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_fn_class = fncls__2549d; tmp2 = fncls__2549d } else { tmp2 = fncls__2549 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A) Ctor_O_O_O_O_O(c__nsobj, c__file, c__s__78000258, c__iter__78000257, c__ns any) { t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_s__78000258 = c__s__78000258; t.F_iter__78000257 = c__iter__78000257; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A) Invoke_O__O(self any) any { { var s__78000258__1 any; var t_ any = t.F_s__78000258; t.F_s__78000258 = nil; s__78000258__1 = t_; for { var temp__1927000414__auto____2 any; var root_2492 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2492, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2494 lang.IFn; if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = s__78000258__1; if linked_2493 == nil { temp__1927000414__auto____2 = ifn_2494.Invoke_O__O(arg_2495) } else { temp__1927000414__auto____2 = linked_2493.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2492, arg_2495) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000258__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2496 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2496, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2498 lang.IFn; if linked_2497 == nil { ifn_2498 = lang.IFn_Cast(root_2496) } else { ifn_2498 = nil }; var arg_2499 any = s__78000258__3; if linked_2497 == nil { tmp1 = ifn_2498.Invoke_O__O(arg_2499) } else { tmp1 = linked_2497.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2496, arg_2499) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2500 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2500, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2502 lang.IFn; if linked_2501 == nil { ifn_2502 = lang.IFn_Cast(root_2500) } else { ifn_2502 = nil }; var arg_2503 any = s__78000258__3; if linked_2501 == nil { c__1927001037__auto____4 = ifn_2502.Invoke_O__O(arg_2503) } else { c__1927001037__auto____4 = linked_2501.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2500, arg_2503) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000260__6 any; var root_2504 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2506 lang.IFn; if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2505 == nil { b__78000260__6 = ifn_2506.Invoke_O__O(arg_2507) } else { b__78000260__6 = linked_2505.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2504, arg_2507) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_New_O_O_O_I_O_O(t.F_nsobj, t.F_file, b__78000260__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_ns); var tmp3 *jrt.Class; var fncls__2513 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_fn_class; if fncls__2513 == nil { var fncls__2513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_fn_class = fncls__2513d; tmp3 = fncls__2513d } else { tmp3 = fncls__2513 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2522 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_2523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2522, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2524 lang.IFn; if linked_2523 == nil { ifn_2524 = lang.IFn_Cast(root_2522) } else { ifn_2524 = nil }; var arg_2525 any; var root_2514 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = b__78000260__6; if linked_2515 == nil { arg_2525 = ifn_2516.Invoke_O__O(arg_2517) } else { arg_2525 = linked_2515.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2514, arg_2517) }; var arg_2526 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000257); var tmp5 any; var root_2518 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2520 lang.IFn; if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any = s__78000258__3; if linked_2519 == nil { tmp5 = ifn_2520.Invoke_O__O(arg_2521) } else { tmp5 = linked_2519.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2518, arg_2521) }; arg_2526 = tmp4.Invoke_O__O(tmp5); if linked_2523 == nil { return ifn_2524.Invoke_O_O__O(arg_2525, arg_2526) } else { return linked_2523.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2522, arg_2525, arg_2526) } } else { var root_2531 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any; var root_2527 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any = b__78000260__6; if linked_2528 == nil { arg_2534 = ifn_2529.Invoke_O__O(arg_2530) } else { arg_2534 = linked_2528.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2527, arg_2530) }; var arg_2535 any; if linked_2532 == nil { return ifn_2533.Invoke_O_O__O(arg_2534, arg_2535) } else { return linked_2532.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2531, arg_2534, arg_2535) } } } else { var cf__4 any; var root_2536 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = s__78000258__3; if linked_2537 == nil { cf__4 = ifn_2538.Invoke_O__O(arg_2539) } else { cf__4 = linked_2537.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2536, arg_2539) }; var root_2544 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(t.F_file, t.F_ns, t.F_nsobj, cf__4); var arg_2548 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__78000257); var tmp7 any; var root_2540 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = s__78000258__3; if linked_2541 == nil { tmp7 = ifn_2542.Invoke_O__O(arg_2543) } else { tmp7 = linked_2541.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2540, arg_2543) }; arg_2548 = tmp6.Invoke_O__O(tmp7); if linked_2545 == nil { return ifn_2546.Invoke_O_O__O(arg_2547, arg_2548) } else { return linked_2545.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2544, arg_2547, arg_2548) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :337:1
func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A) Ctor_O_O_O_I_O_O(c__nsobj, c__file, c__b__78000260 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__ns any) { t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_b__78000260 = c__b__78000260; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A) Invoke_O__O(self any) any { { var i__78000259__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000259__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000259__1)); var root_2508 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2508, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2510 lang.IFn; if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any = t.F_b__78000260; var arg_2512 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(t.F_file, t.F_ns, t.F_nsobj, cf__2); if linked_2509 == nil { ifn_2510.Invoke_O_O__O(arg_2511, arg_2512) } else { linked_2509.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2508, arg_2511, arg_2512) }; i__78000259__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000259__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A{}; t.Ctor_O_O(p0, p1); return t }
//line :340:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A) Ctor_O_O(c__variants, c__applied any) { t.F_variants = c__variants; t.F_applied = c__applied }
//line :340:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A) Invoke_O_O__O(self, p__78000268__1 any) any { var vec__78000270__2 any = p__78000268__1; var file__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000270__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ns__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000270__2, lang.RT_IntCast_J__I_NoInit(1), nil); var nsobj__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000270__2, lang.RT_IntCast_J__I_NoInit(2), nil); var cf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000270__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__9 any; var root_2667 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2667, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2669 lang.IFn

	if linked_2668 == nil { ifn_2669 = lang.IFn_Cast(root_2667) } else { ifn_2669 = nil }; var arg_2670 any; var root_2662 any = A_arbace_j2g_world_A_const_169.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, A_arbace_j2g_world_top_names_A_fn_class); var ifn_2664 lang.IFn; if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = ns__4; var arg_2666 any = lang.Tuple_Create_O__IPersistentVector(cf__6); if linked_2663 == nil { arg_2670 = ifn_2664.Invoke_O_O__O(arg_2665, arg_2666) } else { arg_2670 = linked_2663.(*A_arbace_j2g_world_top_names_A).Invoke_O_O_O__O(root_2662, arg_2665, arg_2666) }; if linked_2668 == nil { n__9 = ifn_2669.Invoke_O__O(arg_2670) } else { n__9 = linked_2668.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2667, arg_2670) }
//line :340:1
	var vfs__10 any = lang.RT_Get_O_O__O_NoInit(t.F_variants, n__9); var vec__78000273__11 any; var root_2672 any = A_arbace_j2g_world_A_const_128.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2672, A_arbace_j2g_world_apply_variant_A_fn_class); var ifn_2674 lang.IFn



	if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any = cf__6; var arg_2676 any; var or__1927000174__auto____11 any = vfs__10; if jrt.J2g_Truth(or__1927000174__auto____11) { arg_2676 = or__1927000174__auto____11 } else { arg_2676 = lang.PersistentVector_EMPTY.Ref() }; var arg_2677 any = n__9; var arg_2678 any; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_New_O(t.F_variants); var tmp3 *jrt.Class; var fncls__2671 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_fn_class; if fncls__2671 == nil { var fncls__2671d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_fn_class = fncls__2671d; tmp3 = fncls__2671d } else { tmp3 = fncls__2671 }; arg_2678 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_2679 any = t.F_applied; if linked_2673 == nil { vec__78000273__11 = ifn_2674.Invoke_O_O_O_O_O__O(arg_2675, arg_2676, arg_2677, arg_2678, arg_2679) } else { vec__78000273__11 = linked_2673.(*A_arbace_j2g_world_apply_variant_A).Invoke_O_O_O_O_O_O__O(root_2672, arg_2675, arg_2676, arg_2677, arg_2678, arg_2679) }
//line :340:1
	var cf__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000273__11, lang.RT_IntCast_J__I_NoInit(0), nil); var counts__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000273__11, lang.RT_IntCast_J__I_NoInit(1), nil); var ___14 any; _ = ___14




	if jrt.J2g_Truth(vfs__10) { var root_2680 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any = t.F_applied; var arg_2684 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var arg_2685 any = n__9; var arg_2686 any = counts__13; if linked_2681 == nil { ___14 = ifn_2682.Invoke_O_O_O_O__O(arg_2683, arg_2684, arg_2685, arg_2686) } else { ___14 = linked_2681.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2680, arg_2683, arg_2684, arg_2685, arg_2686) } } else { ___14 = nil }
//line :340:1
	var pc__15 any; var root_2691 any = A_arbace_j2g_world_A_const_142.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_2693 lang.IFn





	if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_143, nsobj__5, A_arbace_j2g_world_A_const_144, A_arbace_j2g_world_A_const_186)); var arg_2695 any; var root_2687 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2687, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2689 lang.IFn; if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; var arg_2690 any = cf__12; if linked_2688 == nil { arg_2695 = ifn_2689.Invoke_O__O(arg_2690) } else { arg_2695 = linked_2688.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2687, arg_2690) }; if linked_2692 == nil { pc__15 = ifn_2693.Invoke_O_O__O(arg_2694, arg_2695) } else { pc__15 = linked_2692.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_2691, arg_2694, arg_2695) }
//line :340:1
	var tmp4 any = A_arbace_j2g_world_A_const_187; var tmp5 any = A_arbace_j2g_world_A_const_188; var tmp6 any = A_arbace_j2g_world_A_const_149; var tmp7 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_New_O(pc__15); var tmp8 *jrt.Class
	var fncls__2700 /*line :340:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_fn_class







	if fncls__2700 == nil { var fncls__2700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_fn_class = fncls__2700d; tmp8 = fncls__2700d } else { tmp8 = fncls__2700 }
//line :340:1
	tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, pc__15, tmp5, nsobj__5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O())) }; return nil }(); if tmp9 != nil { if true { var e__9 jrt.Throwable_I = tmp9; var tmp10 any = A_arbace_j2g_world_A_const_189; var tmp11 any; var root_2701 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2701, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2703 lang.IFn









		if linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = file__3; if linked_2702 == nil { tmp11 = ifn_2703.Invoke_O__O(arg_2704) } else { tmp11 = linked_2702.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2701, arg_2704) }
//line :340:1
		tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Tuple_Create_O_O__IPersistentVector(tmp11, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_79, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__9.GetMessage__String().Ref())).Ref()))) } }; return tmp1 }



func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A{}; t.Ctor_O(p0); return t }
//line :344:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :344:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A) Invoke_O_O__O(self, p1__78000221_SHARP___1 any) any { return lang.RT_Get_O_O__O_NoInit(t.F_variants, p1__78000221_SHARP___1) }



func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A{}; t.Ctor_O(p0); return t }
//line :348:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A) Ctor_O(c__pc any) { t.F_pc = c__pc }
//line :348:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2696 any = A_arbace_j2g_world_A_const_150.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2696, A_arbace_j2g_world_parse_member_classes_A_fn_class); var ifn_2698 lang.IFn; if linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any; var t_ any = t.F_pc; t.F_pc = nil; arg_2699 = t_; if linked_2697 == nil { tmp1 = ifn_2698.Invoke_O__O(arg_2699) } else { tmp1 = linked_2697.(*A_arbace_j2g_world_parse_member_classes_A).Invoke_O_O__O(root_2696, arg_2699) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }






func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :355:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A) Ctor_O_O_O_O_O(c__nsobj, c__pc, c__failed, c__members, c__file any) { t.F_nsobj = c__nsobj; t.F_pc = c__pc; t.F_failed = c__failed; t.F_members = c__members; t.F_file = c__file }
//line :355:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															{ var tmp2 any; var root_2781 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2781, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2783 lang.IFn; if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any; var root_2776 any = A_arbace_j2g_world_A_const_190.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, aot_arbace_classes_analyze.A_arbace_classes_analyze_top_name_A_fn_class); var ifn_2778 lang.IFn; if linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any; var t_ any = t.F_nsobj; t.F_nsobj = nil; arg_2779 = t_; var arg_2780 any = t.F_pc; if linked_2777 == nil { arg_2784 = ifn_2778.Invoke_O_O__O(arg_2779, arg_2780) } else { arg_2784 = linked_2777.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_top_name_A).Invoke_O_O_O__O(root_2776, arg_2779, arg_2780) }; if linked_2782 == nil { tmp2 = ifn_2783.Invoke_O__O(arg_2784) } else { tmp2 = linked_2782.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2781, arg_2784) }; if jrt.J2g_Truth(tmp2) { tmp1 = nil } else {
																var root_2785 any = A_arbace_j2g_world_A_const_191.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_2787 lang.IFn; if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any; var tmp3 any = A_arbace_j2g_world_A_const_144; var tmp4 any = A_arbace_j2g_world_A_const_186; var tmp5 any = A_arbace_j2g_world_A_const_192; var tmp6 any; var t__2 any = t.F_members; t.F_members = nil; tmp6 = t__2; arg_2788 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6)); var arg_2789 any; var t__3 any = t.F_pc; t.F_pc = nil; arg_2789 = t__3; if linked_2786 == nil { tmp1 = ifn_2787.Invoke_O_O__O(arg_2788, arg_2789) } else { tmp1 = linked_2786.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_2785, arg_2788, arg_2789) } } }
//line :355:1
	return nil }(); if tmp7 != nil { if true { var e__3 jrt.Throwable_I = tmp7; var root_2794 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2795 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2794, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2796 lang.IFn



		if linked_2795 == nil { ifn_2796 = lang.IFn_Cast(root_2794) } else { ifn_2796 = nil }; var arg_2797 any; var t__4 any = t.F_failed; t.F_failed = nil; arg_2797 = t__4; var arg_2798 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2799 any; var tmp8 any; var root_2790 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2792 lang.IFn; if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any; var t__5 any = t.F_file; t.F_file = nil; arg_2793 = t__5; if linked_2791 == nil { tmp8 = ifn_2792.Invoke_O__O(arg_2793) } else { tmp8 = linked_2791.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2790, arg_2793) }; arg_2799 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_79, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref()); if linked_2795 == nil { tmp1 = ifn_2796.Invoke_O_O_O__O(arg_2797, arg_2798, arg_2799) } else { tmp1 = linked_2795.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2794, arg_2797, arg_2798, arg_2799) } } }; return tmp1 }
//line :355:1
func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :355:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A) Ctor_O_O_O_O_O(c__nsobj, c__pc, c__members, c__failed, c__file any) { t.F_nsobj = c__nsobj; t.F_pc = c__pc; t.F_members = c__members; t.F_failed = c__failed; t.F_file = c__file }
//line :355:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															{ var tmp2 any; var root_2816 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2816, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2818 lang.IFn; if linked_2817 == nil { ifn_2818 = lang.IFn_Cast(root_2816) } else { ifn_2818 = nil }; var arg_2819 any; var root_2811 any = A_arbace_j2g_world_A_const_190.GetRawRoot__O(); var linked_2812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2811, aot_arbace_classes_analyze.A_arbace_classes_analyze_top_name_A_fn_class); var ifn_2813 lang.IFn; if linked_2812 == nil { ifn_2813 = lang.IFn_Cast(root_2811) } else { ifn_2813 = nil }; var arg_2814 any; var t_ any = t.F_nsobj; t.F_nsobj = nil; arg_2814 = t_; var arg_2815 any = t.F_pc; if linked_2812 == nil { arg_2819 = ifn_2813.Invoke_O_O__O(arg_2814, arg_2815) } else { arg_2819 = linked_2812.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_top_name_A).Invoke_O_O_O__O(root_2811, arg_2814, arg_2815) }; if linked_2817 == nil { tmp2 = ifn_2818.Invoke_O__O(arg_2819) } else { tmp2 = linked_2817.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2816, arg_2819) }; if jrt.J2g_Truth(tmp2) { tmp1 = nil } else {
																var root_2820 any = A_arbace_j2g_world_A_const_191.GetRawRoot__O(); var linked_2821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2820, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_2822 lang.IFn; if linked_2821 == nil { ifn_2822 = lang.IFn_Cast(root_2820) } else { ifn_2822 = nil }; var arg_2823 any; var tmp3 any = A_arbace_j2g_world_A_const_144; var tmp4 any = A_arbace_j2g_world_A_const_186; var tmp5 any = A_arbace_j2g_world_A_const_192; var tmp6 any; var t__2 any = t.F_members; t.F_members = nil; tmp6 = t__2; arg_2823 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6)); var arg_2824 any; var t__3 any = t.F_pc; t.F_pc = nil; arg_2824 = t__3; if linked_2821 == nil { tmp1 = ifn_2822.Invoke_O_O__O(arg_2823, arg_2824) } else { tmp1 = linked_2821.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_2820, arg_2823, arg_2824) } } }
//line :355:1
	return nil }(); if tmp7 != nil { if true { var e__3 jrt.Throwable_I = tmp7; var root_2829 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2831 lang.IFn



		if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any; var t__4 any = t.F_failed; t.F_failed = nil; arg_2832 = t__4; var arg_2833 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2834 any; var tmp8 any; var root_2825 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any; var t__5 any = t.F_file; t.F_file = nil; arg_2828 = t__5; if linked_2826 == nil { tmp8 = ifn_2827.Invoke_O__O(arg_2828) } else { tmp8 = linked_2826.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2825, arg_2828) }; arg_2834 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_79, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref()); if linked_2830 == nil { tmp1 = ifn_2831.Invoke_O_O_O__O(arg_2832, arg_2833, arg_2834) } else { tmp1 = linked_2830.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2829, arg_2832, arg_2833, arg_2834) } } }; return tmp1 }





func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :365:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A) Ctor_O_O(c__failed, c__lap any) { t.F_failed = c__failed; t.F_lap = c__lap }
//line :365:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A) Invoke_O_O__O(self, names__1 any) any {
	lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_j2g_world_A_const_199)
	{ var root_2885 any = A_arbace_j2g_world_A_const_193.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, A_arbace_j2g_world_par_levels_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = names__1; var arg_2889 any; var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_New(); var tmp2 *jrt.Class; var fncls__2869 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_fn_class; if fncls__2869 == nil { var fncls__2869d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_fn_class = fncls__2869d; tmp2 = fncls__2869d } else { tmp2 = fncls__2869 }; arg_2889 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2890 any; var tmp3 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_New_O(t.F_failed); var tmp4 *jrt.Class; var fncls__2884 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_fn_class
		if fncls__2884 == nil { var fncls__2884d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_fn_class = fncls__2884d; tmp4 = fncls__2884d } else { tmp4 = fncls__2884 }; arg_2890 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :367:1
		if linked_2886 == nil { ifn_2887.Invoke_O_O_O__O(arg_2888, arg_2889, arg_2890) } else { linked_2886.(*A_arbace_j2g_world_par_levels_A).Invoke_O_O_O_O__O(root_2885, arg_2888, arg_2889, arg_2890)
		}


		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_j2g_world_A_const_200)
		var root_2902 any = A_arbace_j2g_world_A_const_193.GetRawRoot__O(); var linked_2903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2902, A_arbace_j2g_world_par_levels_A_fn_class); var ifn_2904 lang.IFn; if linked_2903 == nil { ifn_2904 = lang.IFn_Cast(root_2902) } else { ifn_2904 = nil }; var arg_2905 any = names__1; var arg_2906 any = A_arbace_j2g_world_A_const_196.GetRawRoot__O(); var arg_2907 any; var tmp5 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_New_O(t.F_failed); var tmp6 *jrt.Class; var fncls__2901 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_fn_class
		if fncls__2901 == nil { var fncls__2901d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_fn_class = fncls__2901d; tmp6 = fncls__2901d } else { tmp6 = fncls__2901 }; arg_2907 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
//line :372:1
		if linked_2903 == nil { ifn_2904.Invoke_O_O_O__O(arg_2905, arg_2906, arg_2907) } else { linked_2903.(*A_arbace_j2g_world_par_levels_A).Invoke_O_O_O_O__O(root_2902, arg_2905, arg_2906, arg_2907)
		}

		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_j2g_world_A_const_149)
		var root_2919 any = A_arbace_j2g_world_A_const_193.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2919, A_arbace_j2g_world_par_levels_A_fn_class); var ifn_2921 lang.IFn; if linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any = names__1; var arg_2923 any = A_arbace_j2g_world_A_const_196.GetRawRoot__O(); var arg_2924 any; var tmp7 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_New_O(t.F_failed); var tmp8 *jrt.Class; var fncls__2918 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_fn_class
		if fncls__2918 == nil { var fncls__2918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_fn_class = fncls__2918d; tmp8 = fncls__2918d } else { tmp8 = fncls__2918 }; arg_2924 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :376:1
		if linked_2920 == nil { ifn_2921.Invoke_O_O_O__O(arg_2922, arg_2923, arg_2924) } else { linked_2920.(*A_arbace_j2g_world_par_levels_A).Invoke_O_O_O_O__O(root_2919, arg_2922, arg_2923, arg_2924)
		}

		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_j2g_world_A_const_201)
//line :365:1
		var seq_78000316__2 any; var root_2841 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2841, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2843 lang.IFn














		if linked_2842 == nil { ifn_2843 = lang.IFn_Cast(root_2841) } else { ifn_2843 = nil }; var arg_2844 any = names__1; if linked_2842 == nil { seq_78000316__2 = ifn_2843.Invoke_O__O(arg_2844) } else { seq_78000316__2 = linked_2842.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2841, arg_2844) }
//line :365:1
		var chunk_78000317__3 any; var count_78000318__4 int64 = 0; var i_78000319__5 int64 = 0; L1: for {














			if lang.Numbers_Lt_J_J__Z_NoInit(i_78000319__5, count_78000318__4) { var n__6 any = lang.Indexed_Cast(chunk_78000317__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000319__5)); var tmp9 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_New_O_O(n__6, t.F_failed); var tmp10 *jrt.Class; var fncls__2931 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_fn_class
				if fncls__2931 == nil { var fncls__2931d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_fn_class = fncls__2931d; tmp10 = fncls__2931d } else { tmp10 = fncls__2931 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :380:1
				seq_78000316__2, chunk_78000317__3, count_78000318__4, i_78000319__5 = seq_78000316__2, chunk_78000317__3, count_78000318__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000319__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_2845 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2845, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2847 lang.IFn; if linked_2846 == nil { ifn_2847 = lang.IFn_Cast(root_2845) } else { ifn_2847 = nil }; var arg_2848 any = seq_78000316__2; if linked_2846 == nil { temp__1927000414__auto____6 = ifn_2847.Invoke_O__O(arg_2848) } else { temp__1927000414__auto____6 = linked_2846.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2845, arg_2848) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_78000316__7 any = temp__1927000414__auto____6; var tmp11 any; var root_2849 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2849, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2851 lang.IFn; if linked_2850 == nil { ifn_2851 = lang.IFn_Cast(root_2849) } else { ifn_2851 = nil }; var arg_2852 any = seq_78000316__7; if linked_2850 == nil { tmp11 = ifn_2851.Invoke_O__O(arg_2852) } else { tmp11 = linked_2850.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2849, arg_2852) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8 any; var root_2853 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2853, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2855 lang.IFn; if linked_2854 == nil { ifn_2855 = lang.IFn_Cast(root_2853) } else { ifn_2855 = nil }; var arg_2856 any = seq_78000316__7; if linked_2854 == nil { c__1927000678__auto____8 = ifn_2855.Invoke_O__O(arg_2856) } else { c__1927000678__auto____8 = linked_2854.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2853, arg_2856) }; var tmp12 any; var root_2932 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2932, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2934 lang.IFn; if linked_2933 == nil { ifn_2934 = lang.IFn_Cast(root_2932) } else { ifn_2934 = nil }; var arg_2935 any = seq_78000316__7; if linked_2933 == nil { tmp12 = ifn_2934.Invoke_O__O(arg_2935) } else { tmp12 = linked_2933.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2932, arg_2935) }; seq_78000316__2, chunk_78000317__3, count_78000318__4, i_78000319__5 = tmp12, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_2857 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2857, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2859 lang.IFn; if linked_2858 == nil { ifn_2859 = lang.IFn_Cast(root_2857) } else { ifn_2859 = nil }; var arg_2860 any = seq_78000316__7; if linked_2858 == nil { n__8 = ifn_2859.Invoke_O__O(arg_2860) } else { n__8 = linked_2858.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2857, arg_2860) }
					var tmp13 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_New_O_O(n__8, t.F_failed); var tmp14 *jrt.Class; var fncls__2942 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_fn_class; if fncls__2942 == nil { var fncls__2942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_fn_class = fncls__2942d; tmp14 = fncls__2942d } else { tmp14 = fncls__2942 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O()
//line :380:1
					var tmp15 any; var root_2943 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any = seq_78000316__7; if linked_2944 == nil { tmp15 = ifn_2945.Invoke_O__O(arg_2946) } else { tmp15 = linked_2944.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2943, arg_2946) }; seq_78000316__2, chunk_78000317__3, count_78000318__4, i_78000319__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }
//line :365:1
	panic("j2g: unreachable")
}
func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_New() *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A) Ctor() {}
//line :367:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A) Invoke_O_O__O(self, p1__78000222_SHARP___1 any) any { var G__78000308__2_ any; var root_2861 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2861, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2863 lang.IFn; if linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any = p1__78000222_SHARP___1; if linked_2862 == nil { G__78000308__2_ = ifn_2863.Invoke_O__O(arg_2864) } else { G__78000308__2_ = linked_2862.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2861, arg_2864) }; var G__78000308__3_ any; if lang.Util_Identical_O_O__Z_NoInit(G__78000308__2_, nil) { G__78000308__3_ = nil } else { G__78000308__3_ = A_arbace_j2g_world_A_const_146.Invoke_O__O(G__78000308__2_) }; if lang.Util_Identical_O_O__Z_NoInit(G__78000308__3_, nil) { return nil } else { var root_2865 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var linked_2866 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2865, aot_arbace_core.A_arbace_core_vector_A_fn_class); var ifn_2867 lang.IFn; if linked_2866 == nil { ifn_2867 = lang.IFn_Cast(root_2865) } else { ifn_2867 = nil }; var arg_2868 any = G__78000308__3_; if linked_2866 == nil { return ifn_2867.Invoke_O__O(arg_2868) } else { return linked_2866.(*aot_arbace_core.A_arbace_core_vector_A).Invoke_O_O__O(root_2865, arg_2868) } } }
func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A{}; t.Ctor_O(p0); return t }
//line :368:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :368:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A) Invoke_O_O__O(self, n__1 any) any {
	var tmp1 *lang.Keyword = A_arbace_j2g_world_A_const_194; var tmp2 any; var root_2870 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2870, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2872 lang.IFn; if linked_2871 == nil { ifn_2872 = lang.IFn_Cast(root_2870) } else { ifn_2872 = nil }; var arg_2873 any = n__1; if linked_2871 == nil { tmp2 = ifn_2872.Invoke_O__O(arg_2873) } else { tmp2 = linked_2871.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2870, arg_2873) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { return nil } else { var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_2874 any = A_arbace_j2g_world_A_const_195.GetRawRoot__O(); var linked_2875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2874, aot_arbace_classes_analyze.A_arbace_classes_analyze_resolve_header_BANG__A_fn_class); var ifn_2876 lang.IFn; if linked_2875 == nil { ifn_2876 = lang.IFn_Cast(root_2874) } else { ifn_2876 = nil }; var arg_2877 any = n__1; if linked_2875 == nil { tmp3 = ifn_2876.Invoke_O__O(arg_2877) } else { tmp3 = linked_2875.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_resolve_header_BANG__A).Invoke_O_O__O(root_2874, arg_2877) } }
//line :369:1
		return nil }(); if tmp4 != nil { if true { var e__4 jrt.Throwable_I = tmp4; var root_2878 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2879 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2878, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2880 lang.IFn
			if linked_2879 == nil { ifn_2880 = lang.IFn_Cast(root_2878) } else { ifn_2880 = nil }; var arg_2881 any = t.F_failed; var arg_2882 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2883 any = lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref()); if linked_2879 == nil { tmp3 = ifn_2880.Invoke_O_O_O__O(arg_2881, arg_2882, arg_2883) } else { tmp3 = linked_2879.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2878, arg_2881, arg_2882, arg_2883) } } }
//line :369:1
		return tmp3
	}
}

func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A{}; t.Ctor_O(p0); return t }
//line :373:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :373:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var root_2891 any = A_arbace_j2g_world_A_const_197.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2891, aot_arbace_classes_analyze.A_arbace_classes_analyze_resolve_members_BANG__A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var arg_2894 any = n__1; if linked_2892 == nil { tmp1 = ifn_2893.Invoke_O__O(arg_2894) } else { tmp1 = linked_2892.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_resolve_members_BANG__A).Invoke_O_O__O(root_2891, arg_2894) } }
//line :373:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var root_2895 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2895, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2897 lang.IFn
		if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = t.F_failed; var arg_2899 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2900 any = lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref()); if linked_2896 == nil { tmp1 = ifn_2897.Invoke_O_O_O__O(arg_2898, arg_2899, arg_2900) } else { tmp1 = linked_2896.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2895, arg_2898, arg_2899, arg_2900) } } }; return tmp1 }


func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A{}; t.Ctor_O(p0); return t }
//line :377:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :377:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var root_2908 any = A_arbace_j2g_world_A_const_198.GetRawRoot__O(); var linked_2909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2908, aot_arbace_classes_analyze.A_arbace_classes_analyze_add_bridges_BANG__A_fn_class); var ifn_2910 lang.IFn; if linked_2909 == nil { ifn_2910 = lang.IFn_Cast(root_2908) } else { ifn_2910 = nil }; var arg_2911 any = n__1; if linked_2909 == nil { tmp1 = ifn_2910.Invoke_O__O(arg_2911) } else { tmp1 = linked_2909.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_add_bridges_BANG__A).Invoke_O_O__O(root_2908, arg_2911) } }
//line :377:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var root_2912 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2913 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2912, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2914 lang.IFn
		if linked_2913 == nil { ifn_2914 = lang.IFn_Cast(root_2912) } else { ifn_2914 = nil }; var arg_2915 any = t.F_failed; var arg_2916 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2917 any = lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_112, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref()); if linked_2913 == nil { tmp1 = ifn_2914.Invoke_O_O_O__O(arg_2915, arg_2916, arg_2917) } else { tmp1 = linked_2913.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2912, arg_2915, arg_2916, arg_2917) } } }; return tmp1 }


func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A{}; t.Ctor_O_O(p0, p1); return t }
//line :381:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :381:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_j2g_world_A_const_202.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var root_2925 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2925, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2927 lang.IFn; if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any; var t_ any = t.F_failed; t.F_failed = nil; arg_2928 = t_; var arg_2929 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2930 any; var tmp3 any; var t__2 any = t.F_n; t.F_n = nil; tmp3 = t__2; arg_2930 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref()); if linked_2926 == nil { tmp1 = ifn_2927.Invoke_O_O_O__O(arg_2928, arg_2929, arg_2930) } else { tmp1 = linked_2926.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2925, arg_2928, arg_2929, arg_2930) } } }; return tmp1 }
//line :381:1
func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A{}; t.Ctor_O_O(p0, p1); return t }
//line :381:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :381:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_j2g_world_A_const_202.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var root_2936 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2937 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2936, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2938 lang.IFn; if linked_2937 == nil { ifn_2938 = lang.IFn_Cast(root_2936) } else { ifn_2938 = nil }; var arg_2939 any; var t_ any = t.F_failed; t.F_failed = nil; arg_2939 = t_; var arg_2940 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2941 any; var tmp3 any; var t__2 any = t.F_n; t.F_n = nil; tmp3 = t__2; arg_2941 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref()); if linked_2937 == nil { tmp1 = ifn_2938.Invoke_O_O_O__O(arg_2939, arg_2940, arg_2941) } else { tmp1 = linked_2937.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2936, arg_2939, arg_2940, arg_2941) } } }; return tmp1 }
func A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A{}; t.Ctor_O(p0); return t }
//line :382:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :382:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															{ var root_2948 any = A_arbace_j2g_world_A_const_203.GetRawRoot__O(); var linked_2949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2948, aot_arbace_classes_analyze.A_arbace_classes_analyze_analyze_class_BANG__A_fn_class); var ifn_2950 lang.IFn; if linked_2949 == nil { ifn_2950 = lang.IFn_Cast(root_2948) } else { ifn_2950 = nil }; var arg_2951 any = n__1; if linked_2949 == nil { tmp1 = ifn_2950.Invoke_O__O(arg_2951) } else { tmp1 = linked_2949.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_analyze_class_BANG__A).Invoke_O_O__O(root_2948, arg_2951) } }
//line :382:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var root_2962 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2963 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2962, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2964 lang.IFn


		if linked_2963 == nil { ifn_2964 = lang.IFn_Cast(root_2962) } else { ifn_2964 = nil }; var arg_2965 any; var tmp3 *lang.Keyword = A_arbace_j2g_world_A_const_204; var tmp4 any; var root_2958 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2958, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2960 lang.IFn; if linked_2959 == nil { ifn_2960 = lang.IFn_Cast(root_2958) } else { ifn_2960 = nil }; var arg_2961 any = n__1; if linked_2959 == nil { tmp4 = ifn_2960.Invoke_O__O(arg_2961) } else { tmp4 = linked_2959.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2958, arg_2961) }; arg_2965 = tmp3.Invoke_O__O(tmp4); var arg_2966 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var arg_2967 any = A_arbace_j2g_world_A_const_205; var arg_2968 any = e__4.GetMessage__String().Ref(); if linked_2963 == nil { ifn_2964.Invoke_O_O_O_O__O(arg_2965, arg_2966, arg_2967, arg_2968) } else { linked_2963.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2962, arg_2965, arg_2966, arg_2967, arg_2968) }
		var root_2952 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2953 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2952, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2954 lang.IFn; if linked_2953 == nil { ifn_2954 = lang.IFn_Cast(root_2952) } else { ifn_2954 = nil }; var arg_2955 any = t.F_failed; var arg_2956 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2957 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil, nil); var tmp6 any = e__4.GetMessage__String().Ref(); var tmp7 *jrt.String; var G__78000326__8_ any = e__4.GetCause__Throwable(); var G__78000326__9_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__78000326__8_, nil) { G__78000326__9_ = nil } else { G__78000326__9_ = jrt.Throwable_Cast(G__78000326__8_).GetMessage__String().Ref() }; if lang.Util_Identical_O_O__Z_NoInit(G__78000326__9_, nil) { tmp7 = nil } else { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_69, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__78000326__9_)) }
//line :386:1
		arg_2957 = lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, tmp7.Ref())).Ref()); if linked_2953 == nil { tmp1 = ifn_2954.Invoke_O_O_O__O(arg_2955, arg_2956, arg_2957) } else { tmp1 = linked_2953.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2952, arg_2955, arg_2956, arg_2957) } } }; return tmp1 }















func A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :402:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A) Ctor_O_O_O_O_O(c__rt_order, c__analyze_BANG_, c__unit, c__rt_start, c__names1 any) { t.F_rt_order = c__rt_order; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit; t.F_rt_start = c__rt_start; t.F_names1 = c__names1 }
//line :402:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_2992 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, A_arbace_j2g_world_id_space_A_fn_class); var ifn_2994 lang.IFn; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; if linked_2993 == nil { tmp1 = ifn_2994.Invoke__O() } else { tmp1 = linked_2993.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_2992) }; var tmp2 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(tmp1); var tmp3 any; var t_ any = t.F_rt_start; t.F_rt_start = nil; tmp3 = t_; tmp2.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(tmp3)))
//line :402:1
	var tmp4 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_3006 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_3007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3006, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3008 lang.IFn; if linked_3007 == nil { ifn_3008 = lang.IFn_Cast(root_3006) } else { ifn_3008 = nil }; var arg_3009 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_world_A_const_209; var tmp7 any; var root_2995 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2995, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2997 lang.IFn; if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any; var t__2 any = t.F_unit; t.F_unit = nil; arg_2998 = t__2; var arg_2999 any = A_arbace_j2g_world_A_const_133; var arg_3000 any; var t__3 any = t.F_rt_order; t.F_rt_order = nil; arg_3000 = t__3; if linked_2996 == nil { tmp7 = ifn_2997.Invoke_O_O_O__O(arg_2998, arg_2999, arg_3000) } else { tmp7 = linked_2996.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2995, arg_2998, arg_2999, arg_3000) }; arg_3009 = tmp5.Invoke_O_O__O(tmp6, tmp7); if linked_3007 == nil { ifn_3008.Invoke_O__O(arg_3009) } else { linked_3007.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3006, arg_3009) }; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var root_2981 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_2982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2981, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_2983 lang.IFn; if linked_2982 == nil { ifn_2983 = lang.IFn_Cast(root_2981) } else { ifn_2983 = nil }; var arg_2984 any; var t__4 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; arg_2984 = t__4; var arg_2985 any; var t__5 any = t.F_names1; t.F_names1 = nil; arg_2985 = t__5; if linked_2982 == nil { tmp4 = ifn_2983.Invoke_O_O__O(arg_2984, arg_2985) } else { tmp4 = linked_2982.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_2981, arg_2984, arg_2985) } }
//line :404:1
			return nil }(); var root_2986 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2988 lang.IFn; if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; if linked_2987 == nil { ifn_2988.Invoke__O() } else { linked_2987.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2986) }
//line :402:1
			if tmp8 != nil { panic(tmp8) } }; return nil }(); var tmp10 any; var root_2989 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_2990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2989, A_arbace_j2g_world_id_space_A_fn_class); var ifn_2991 lang.IFn



	if linked_2990 == nil { ifn_2991 = lang.IFn_Cast(root_2989) } else { ifn_2991 = nil }; if linked_2990 == nil { tmp10 = ifn_2991.Invoke__O() } else { tmp10 = linked_2990.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_2989) }; jrt.ThreadLocal_Cast(tmp10).Remove__V()
//line :402:1
	if tmp9 != nil { panic(tmp9) }; return tmp4
}




func A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A{}; t.Ctor_O_O(p0, p1); return t }
//line :408:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A) Ctor_O_O(c__analyze_BANG_, c__names1 any) { t.F_analyze_BANG_ = c__analyze_BANG_; t.F_names1 = c__names1 }
//line :408:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3691 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_3692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3691, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3693 lang.IFn; if linked_3692 == nil { ifn_3693 = lang.IFn_Cast(root_3691) } else { ifn_3693 = nil }; var arg_3694 any; var t_ any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; arg_3694 = t_; var arg_3695 any; var t__2 any = t.F_names1; t.F_names1 = nil; arg_3695 = t__2; if linked_3692 == nil { tmp1 = ifn_3693.Invoke_O_O__O(arg_3694, arg_3695) } else { tmp1 = linked_3692.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3691, arg_3694, arg_3695) } }; return nil }(); var root_3696 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_3697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3696, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3698 lang.IFn; if linked_3697 == nil { ifn_3698 = lang.IFn_Cast(root_3696) } else { ifn_3698 = nil }; if linked_3697 == nil { ifn_3698.Invoke__O() } else { linked_3697.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3696) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }
























func A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_New() *A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A{}; t.Ctor(); return t }
//line :433:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A) Ctor() {}
//line :433:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A) Invoke_O_O__O(self, n__1 any) any { var root_3045 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3045, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3047 lang.IFn; if linked_3046 == nil { ifn_3047 = lang.IFn_Cast(root_3045) } else { ifn_3047 = nil }; var arg_3048 any; var root_3040 any = A_arbace_j2g_world_A_const_87.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any = n__1; var arg_3044 any = Lit_13; if linked_3041 == nil { arg_3048 = ifn_3042.Invoke_O_O__O(arg_3043, arg_3044) } else { arg_3048 = linked_3041.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_3040, arg_3043, arg_3044) }; if linked_3046 == nil { return ifn_3047.Invoke_O__O(arg_3048) } else { return linked_3046.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3045, arg_3048) } }

func A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A{}; t.Ctor_O(p0); return t }
//line :435:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A) Ctor_O(c__heights any) { t.F_heights = c__heights }
//line :435:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A) Invoke_O_O__O(self, n__1 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3054 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3054, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3056 lang.IFn; if
														linked_3055 == nil { ifn_3056 = lang.IFn_Cast(root_3054) } else { ifn_3056 = nil }; var arg_3057 any = t.F_heights; if linked_3055 == nil { tmp1 = ifn_3056.Invoke_O__O(arg_3057) } else { tmp1 = linked_3055.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3054, arg_3057) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, n__1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var ms__3 any; var root_3071 any = A_arbace_j2g_world_A_const_210.GetRawRoot__O(); var linked_3072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3071, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3073 lang.IFn
															if linked_3072 == nil { ifn_3073 = lang.IFn_Cast(root_3071) } else { ifn_3073 = nil }; var arg_3074 any; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_New(); var tmp3 *jrt.Class; var fncls__3062 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_fn_class; if fncls__3062 == nil { var fncls__3062d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_fn_class = fncls__3062d; tmp3 = fncls__3062d } else { tmp3 = fncls__3062 }; arg_3074 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_3075 any; var root_3067 any = A_arbace_j2g_world_A_const_153.GetRawRoot__O(); var linked_3068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3067, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_3069 lang.IFn; if linked_3068 == nil { ifn_3069 = lang.IFn_Cast(root_3067) } else { ifn_3069 = nil }; var arg_3070 any; var tmp4 *lang.Keyword = A_arbace_j2g_world_A_const_211; var tmp5 any; var root_3063 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_3064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3063, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3065 lang.IFn; if linked_3064 == nil { ifn_3065 = lang.IFn_Cast(root_3063) } else { ifn_3065 = nil }; var arg_3066 any = n__1; if linked_3064 == nil { tmp5 = ifn_3065.Invoke_O__O(arg_3066) } else { tmp5 = linked_3064.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3063, arg_3066) }; arg_3070 = tmp4.Invoke_O__O(tmp5); if linked_3068 == nil { arg_3075 = ifn_3069.Invoke_O__O(arg_3070) } else { arg_3075 = linked_3068.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_3067, arg_3070) }; if linked_3072 == nil { ms__3 = ifn_3073.Invoke_O_O__O(arg_3074, arg_3075) } else { ms__3 = linked_3072.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3071, arg_3074, arg_3075) }
//line :436:1
		var h__4 any; var tmp6 any; var root_3076 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3078 lang.IFn

		if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any = ms__3; if linked_3077 == nil { tmp6 = ifn_3078.Invoke_O__O(arg_3079) } else { tmp6 = linked_3077.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3076, arg_3079) }; if jrt.J2g_Truth(tmp6) { var na_3080 any; var root_3086 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3086, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3088 lang.IFn; if linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any = A_arbace_j2g_world_A_const_152.GetRawRoot__O(); var arg_3090 any; var root_3081 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = self; var arg_3085 any = ms__3; if linked_3082 == nil { arg_3090 = ifn_3083.Invoke_O_O__O(arg_3084, arg_3085) } else { arg_3090 = linked_3082.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3081, arg_3084, arg_3085) }; if linked_3087 == nil { na_3080 = ifn_3088.Invoke_O_O__O(arg_3089, arg_3090) } else { na_3080 = linked_3087.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3086, arg_3089, arg_3090) }; if jrt.Long_InstanceOf(na_3080) { var n0_3091 int64 = jrt.NN(jrt.Long_Cast(na_3080)).LongValue__J(); if n0_3091 == 9223372036854775807 { h__4 = lang.Numbers_Inc_O__Number_NoInit(na_3080) } else { h__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_3091 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_3080) { var n0_3091_2 float64 = jrt.NN(jrt.Double_Cast(na_3080)).DoubleValue__D(); h__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_3091_2 + 1.0).Ref() } else { h__4 = lang.Numbers_Inc_O__Number_NoInit(na_3080) } } } else { h__4 = A_arbace_j2g_world_A_const_111 }
		var root_3092 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_3093 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3092, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3094 lang.IFn; if linked_3093 == nil { ifn_3094 = lang.IFn_Cast(root_3092) } else { ifn_3094 = nil }; var arg_3095 any = t.F_heights; var arg_3096 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var arg_3097 any = n__1; var arg_3098 any = h__4; if linked_3093 == nil { ifn_3094.Invoke_O_O_O_O__O(arg_3095, arg_3096, arg_3097, arg_3098) } else { linked_3093.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3092, arg_3095, arg_3096, arg_3097, arg_3098) }
//line :436:1
		return h__4 } }
func A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_New() *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A) Ctor() {}
//line :437:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A) Invoke_O_O__O(self, p1__78000223_SHARP___1 any) any { var tmp1 any; var root_3058 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_3059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3058, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3060 lang.IFn; if linked_3059 == nil { ifn_3060 = lang.IFn_Cast(root_3058) } else { ifn_3060 = nil }; var arg_3061 any = p1__78000223_SHARP___1; if linked_3059 == nil { tmp1 = ifn_3060.Invoke_O__O(arg_3061) } else { tmp1 = linked_3059.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3058, arg_3061) }; if jrt.J2g_Truth(tmp1) { return p1__78000223_SHARP___1 } else { return nil } }




func A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A{}; t.Ctor_O_O(p0, p1); return t }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A) Ctor_O_O(c__tops_QMARK_, c__height any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A) Invoke_O_O__O(self, s__78000340__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_New_O_O_O_O(self, t.F_tops_QMARK_, t.F_height, s__78000340__1); var tmp2 *jrt.Class; var fncls__3170 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_fn_class; if fncls__3170 == nil { var fncls__3170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_fn_class = fncls__3170d; tmp2 = fncls__3170d } else { tmp2 = fncls__3170 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :442:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A) Ctor_O_O_O_O(c__iter__78000339, c__tops_QMARK_, c__height, c__s__78000340 any) { t.F_iter__78000339 = c__iter__78000339; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height; t.F_s__78000340 = c__s__78000340 }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A) Invoke_O__O(self any) any { { var s__78000340__1 any; var t_ any = t.F_s__78000340; t.F_s__78000340 = nil; s__78000340__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3105 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3105, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3107 lang.IFn; if linked_3106 == nil { ifn_3107 = lang.IFn_Cast(root_3105) } else { ifn_3107 = nil }; var arg_3108 any = s__78000340__1; if linked_3106 == nil { temp__1927000414__auto____2 = ifn_3107.Invoke_O__O(arg_3108) } else { temp__1927000414__auto____2 = linked_3106.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3105, arg_3108) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000340__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3109 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3109, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3111 lang.IFn; if linked_3110 == nil { ifn_3111 = lang.IFn_Cast(root_3109) } else { ifn_3111 = nil }; var arg_3112 any = s__78000340__3; if linked_3110 == nil { tmp1 = ifn_3111.Invoke_O__O(arg_3112) } else { tmp1 = linked_3110.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3109, arg_3112) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3113 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3113, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3115 lang.IFn; if linked_3114 == nil { ifn_3115 = lang.IFn_Cast(root_3113) } else { ifn_3115 = nil }; var arg_3116 any = s__78000340__3; if linked_3114 == nil { c__1927001037__auto____4 = ifn_3115.Invoke_O__O(arg_3116) } else { c__1927001037__auto____4 = linked_3114.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3113, arg_3116) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000342__6 any; var root_3117 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3117, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3119 lang.IFn; if linked_3118 == nil { ifn_3119 = lang.IFn_Cast(root_3117) } else { ifn_3119 = nil }; var arg_3120 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3118 == nil { b__78000342__6 = ifn_3119.Invoke_O__O(arg_3120) } else { b__78000342__6 = linked_3118.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3117, arg_3120) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_New_O_O_I_O_O(t.F_tops_QMARK_, t.F_height, size__1927001038__auto____5, c__1927001037__auto____4, b__78000342__6); var tmp3 *jrt.Class; var fncls__3128 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_fn_class; if fncls__3128 == nil { var fncls__3128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_fn_class = fncls__3128d; tmp3 = fncls__3128d } else { tmp3 = fncls__3128 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3137 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3137, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3139 lang.IFn; if linked_3138 == nil { ifn_3139 = lang.IFn_Cast(root_3137) } else { ifn_3139 = nil }; var arg_3140 any; var root_3129 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3129, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3131 lang.IFn; if linked_3130 == nil { ifn_3131 = lang.IFn_Cast(root_3129) } else { ifn_3131 = nil }; var arg_3132 any = b__78000342__6; if linked_3130 == nil { arg_3140 = ifn_3131.Invoke_O__O(arg_3132) } else { arg_3140 = linked_3130.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3129, arg_3132) }; var arg_3141 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000339); var tmp5 any; var root_3133 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3133, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3135 lang.IFn; if linked_3134 == nil { ifn_3135 = lang.IFn_Cast(root_3133) } else { ifn_3135 = nil }; var arg_3136 any = s__78000340__3; if linked_3134 == nil { tmp5 = ifn_3135.Invoke_O__O(arg_3136) } else { tmp5 = linked_3134.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3133, arg_3136) }; arg_3141 = tmp4.Invoke_O__O(tmp5); if linked_3138 == nil { return ifn_3139.Invoke_O_O__O(arg_3140, arg_3141) } else { return linked_3138.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3137, arg_3140, arg_3141) } } else { var root_3146 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3146, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3148 lang.IFn; if linked_3147 == nil { ifn_3148 = lang.IFn_Cast(root_3146) } else { ifn_3148 = nil }; var arg_3149 any; var root_3142 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3142, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3144 lang.IFn; if linked_3143 == nil { ifn_3144 = lang.IFn_Cast(root_3142) } else { ifn_3144 = nil }; var arg_3145 any = b__78000342__6; if linked_3143 == nil { arg_3149 = ifn_3144.Invoke_O__O(arg_3145) } else { arg_3149 = linked_3143.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3142, arg_3145) }; var arg_3150 any; if linked_3147 == nil { return ifn_3148.Invoke_O_O__O(arg_3149, arg_3150) } else { return linked_3147.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3146, arg_3149, arg_3150) } } } else { var n__4 any; var root_3151 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3151, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3153 lang.IFn; if linked_3152 == nil { ifn_3153 = lang.IFn_Cast(root_3151) } else { ifn_3153 = nil }; var arg_3154 any = s__78000340__3; if linked_3152 == nil { n__4 = ifn_3153.Invoke_O__O(arg_3154) } else { n__4 = linked_3152.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3151, arg_3154) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 bool; var na_3155 any = lang.IFn_Cast(t.F_height).Invoke_O__O(n__4); if jrt.Long_InstanceOf(na_3155) { var n0_3156 int64 = jrt.NN(jrt.Long_Cast(na_3155)).LongValue__J(); tmp7 = n0_3156 == 0 } else { if jrt.Double_InstanceOf(na_3155) { var n0_3156_2 float64 = jrt.NN(jrt.Double_Cast(na_3155)).DoubleValue__D(); tmp7 = n0_3156_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_3155) } }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp7).Ref() } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_3161 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3161, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3163 lang.IFn; if linked_3162 == nil { ifn_3163 = lang.IFn_Cast(root_3161) } else { ifn_3163 = nil }; var arg_3164 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3165 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000339); var tmp9 any; var root_3157 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3157, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3159 lang.IFn; if linked_3158 == nil { ifn_3159 = lang.IFn_Cast(root_3157) } else { ifn_3159 = nil }; var arg_3160 any = s__78000340__3; if linked_3158 == nil { tmp9 = ifn_3159.Invoke_O__O(arg_3160) } else { tmp9 = linked_3158.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3157, arg_3160) }; arg_3165 = tmp8.Invoke_O__O(tmp9); if linked_3162 == nil { return ifn_3163.Invoke_O_O__O(arg_3164, arg_3165) } else { return linked_3162.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3161, arg_3164, arg_3165) } } else { var tmp10 any; var root_3166 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3166, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3168 lang.IFn; if linked_3167 == nil { ifn_3168 = lang.IFn_Cast(root_3166) } else { ifn_3168 = nil }; var arg_3169 any = s__78000340__3; if linked_3167 == nil { tmp10 = ifn_3168.Invoke_O__O(arg_3169) } else { tmp10 = linked_3167.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3166, arg_3169) }; s__78000340__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :442:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A) Ctor_O_O_I_O_O(c__tops_QMARK_, c__height any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__78000342 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__78000342 = c__b__78000342 }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A) Invoke_O__O(self any) any { { var i__78000341__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000341__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000341__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 bool; var na_3121 any = lang.IFn_Cast(t.F_height).Invoke_O__O(n__2); if jrt.Long_InstanceOf(na_3121) { var n0_3122 int64 = jrt.NN(jrt.Long_Cast(na_3121)).LongValue__J(); tmp3 = n0_3122 == 0 } else { if jrt.Double_InstanceOf(na_3121) { var n0_3122_2 float64 = jrt.NN(jrt.Double_Cast(na_3121)).DoubleValue__D(); tmp3 = n0_3122_2 == 0.0 } else { tmp3 = lang.Numbers_IsZero_O__Z_NoInit(na_3121) } }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_3123 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3123, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3125 lang.IFn; if linked_3124 == nil { ifn_3125 = lang.IFn_Cast(root_3123) } else { ifn_3125 = nil }; var arg_3126 any = t.F_b__78000342; var arg_3127 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3124 == nil { ifn_3125.Invoke_O_O__O(arg_3126, arg_3127) } else { linked_3124.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3123, arg_3126, arg_3127) }; i__78000341__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000341__1); continue L1 } else { i__78000341__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000341__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A{}; t.Ctor_O_O(p0, p1); return t }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A) Ctor_O_O(c__tops_QMARK_, c__height any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A) Invoke_O_O__O(self, s__78000350__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_New_O_O_O_O(self, t.F_tops_QMARK_, t.F_height, s__78000350__1); var tmp2 *jrt.Class; var fncls__3245 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_fn_class; if fncls__3245 == nil { var fncls__3245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_fn_class = fncls__3245d; tmp2 = fncls__3245d } else { tmp2 = fncls__3245 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :443:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A) Ctor_O_O_O_O(c__iter__78000349, c__tops_QMARK_, c__height, c__s__78000350 any) { t.F_iter__78000349 = c__iter__78000349; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height; t.F_s__78000350 = c__s__78000350 }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A) Invoke_O__O(self any) any { { var s__78000350__1 any; var t_ any = t.F_s__78000350; t.F_s__78000350 = nil; s__78000350__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3172 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3172, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3174 lang.IFn; if linked_3173 == nil { ifn_3174 = lang.IFn_Cast(root_3172) } else { ifn_3174 = nil }; var arg_3175 any = s__78000350__1; if linked_3173 == nil { temp__1927000414__auto____2 = ifn_3174.Invoke_O__O(arg_3175) } else { temp__1927000414__auto____2 = linked_3173.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3172, arg_3175) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000350__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3176 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3176, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3178 lang.IFn; if linked_3177 == nil { ifn_3178 = lang.IFn_Cast(root_3176) } else { ifn_3178 = nil }; var arg_3179 any = s__78000350__3; if linked_3177 == nil { tmp1 = ifn_3178.Invoke_O__O(arg_3179) } else { tmp1 = linked_3177.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3176, arg_3179) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3180 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3180, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3182 lang.IFn; if linked_3181 == nil { ifn_3182 = lang.IFn_Cast(root_3180) } else { ifn_3182 = nil }; var arg_3183 any = s__78000350__3; if linked_3181 == nil { c__1927001037__auto____4 = ifn_3182.Invoke_O__O(arg_3183) } else { c__1927001037__auto____4 = linked_3181.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3180, arg_3183) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000352__6 any; var root_3184 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3184, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3186 lang.IFn; if linked_3185 == nil { ifn_3186 = lang.IFn_Cast(root_3184) } else { ifn_3186 = nil }; var arg_3187 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3185 == nil { b__78000352__6 = ifn_3186.Invoke_O__O(arg_3187) } else { b__78000352__6 = linked_3185.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3184, arg_3187) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_New_O_O_I_O_O(t.F_tops_QMARK_, t.F_height, size__1927001038__auto____5, b__78000352__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3199 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_fn_class; if fncls__3199 == nil { var fncls__3199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_fn_class = fncls__3199d; tmp3 = fncls__3199d } else { tmp3 = fncls__3199 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3208 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3208, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3210 lang.IFn; if linked_3209 == nil { ifn_3210 = lang.IFn_Cast(root_3208) } else { ifn_3210 = nil }; var arg_3211 any; var root_3200 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3200, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3202 lang.IFn; if linked_3201 == nil { ifn_3202 = lang.IFn_Cast(root_3200) } else { ifn_3202 = nil }; var arg_3203 any = b__78000352__6; if linked_3201 == nil { arg_3211 = ifn_3202.Invoke_O__O(arg_3203) } else { arg_3211 = linked_3201.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3200, arg_3203) }; var arg_3212 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000349); var tmp5 any; var root_3204 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3204, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3206 lang.IFn; if linked_3205 == nil { ifn_3206 = lang.IFn_Cast(root_3204) } else { ifn_3206 = nil }; var arg_3207 any = s__78000350__3; if linked_3205 == nil { tmp5 = ifn_3206.Invoke_O__O(arg_3207) } else { tmp5 = linked_3205.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3204, arg_3207) }; arg_3212 = tmp4.Invoke_O__O(tmp5); if linked_3209 == nil { return ifn_3210.Invoke_O_O__O(arg_3211, arg_3212) } else { return linked_3209.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3208, arg_3211, arg_3212) } } else { var root_3217 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3217, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3219 lang.IFn; if linked_3218 == nil { ifn_3219 = lang.IFn_Cast(root_3217) } else { ifn_3219 = nil }; var arg_3220 any; var root_3213 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3215 lang.IFn; if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = b__78000352__6; if linked_3214 == nil { arg_3220 = ifn_3215.Invoke_O__O(arg_3216) } else { arg_3220 = linked_3214.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3213, arg_3216) }; var arg_3221 any; if linked_3218 == nil { return ifn_3219.Invoke_O_O__O(arg_3220, arg_3221) } else { return linked_3218.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3217, arg_3220, arg_3221) } } } else { var n__4 any; var root_3222 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3222, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3224 lang.IFn; if linked_3223 == nil { ifn_3224 = lang.IFn_Cast(root_3222) } else { ifn_3224 = nil }; var arg_3225 any = s__78000350__3; if linked_3223 == nil { n__4 = ifn_3224.Invoke_O__O(arg_3225) } else { n__4 = linked_3223.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3222, arg_3225) }; var tmp6 any; var and__1927000168__auto____5 any; var root_3226 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3226, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3228 lang.IFn; if linked_3227 == nil { ifn_3228 = lang.IFn_Cast(root_3226) } else { ifn_3228 = nil }; var arg_3229 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if linked_3227 == nil { and__1927000168__auto____5 = ifn_3228.Invoke_O__O(arg_3229) } else { and__1927000168__auto____5 = linked_3227.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3226, arg_3229) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 bool; var na_3230 any = lang.IFn_Cast(t.F_height).Invoke_O__O(n__4); if jrt.Long_InstanceOf(na_3230) { var n0_3231 int64 = jrt.NN(jrt.Long_Cast(na_3230)).LongValue__J(); tmp7 = n0_3231 == 0 } else { if jrt.Double_InstanceOf(na_3230) { var n0_3231_2 float64 = jrt.NN(jrt.Double_Cast(na_3230)).DoubleValue__D(); tmp7 = n0_3231_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_3230) } }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp7).Ref() } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_3236 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3236, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3238 lang.IFn; if linked_3237 == nil { ifn_3238 = lang.IFn_Cast(root_3236) } else { ifn_3238 = nil }; var arg_3239 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3240 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000349); var tmp9 any; var root_3232 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3232, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3234 lang.IFn; if linked_3233 == nil { ifn_3234 = lang.IFn_Cast(root_3232) } else { ifn_3234 = nil }; var arg_3235 any = s__78000350__3; if linked_3233 == nil { tmp9 = ifn_3234.Invoke_O__O(arg_3235) } else { tmp9 = linked_3233.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3232, arg_3235) }; arg_3240 = tmp8.Invoke_O__O(tmp9); if linked_3237 == nil { return ifn_3238.Invoke_O_O__O(arg_3239, arg_3240) } else { return linked_3237.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3236, arg_3239, arg_3240) } } else { var tmp10 any; var root_3241 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3241, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3243 lang.IFn; if linked_3242 == nil { ifn_3243 = lang.IFn_Cast(root_3241) } else { ifn_3243 = nil }; var arg_3244 any = s__78000350__3; if linked_3242 == nil { tmp10 = ifn_3243.Invoke_O__O(arg_3244) } else { tmp10 = linked_3242.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3241, arg_3244) }; s__78000350__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :443:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A) Ctor_O_O_I_O_O(c__tops_QMARK_, c__height any, c__size__1927001038__auto__ int32, c__b__78000352, c__c__1927001037__auto__ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__78000352 = c__b__78000352; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A) Invoke_O__O(self any) any { { var i__78000351__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000351__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000351__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_3188 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3188, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3190 lang.IFn; if linked_3189 == nil { ifn_3190 = lang.IFn_Cast(root_3188) } else { ifn_3190 = nil }; var arg_3191 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if linked_3189 == nil { and__1927000168__auto____3 = ifn_3190.Invoke_O__O(arg_3191) } else { and__1927000168__auto____3 = linked_3189.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3188, arg_3191) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 bool; var na_3192 any = lang.IFn_Cast(t.F_height).Invoke_O__O(n__2); if jrt.Long_InstanceOf(na_3192) { var n0_3193 int64 = jrt.NN(jrt.Long_Cast(na_3192)).LongValue__J(); tmp3 = n0_3193 == 0 } else { if jrt.Double_InstanceOf(na_3192) { var n0_3193_2 float64 = jrt.NN(jrt.Double_Cast(na_3192)).DoubleValue__D(); tmp3 = n0_3193_2 == 0.0 } else { tmp3 = lang.Numbers_IsZero_O__Z_NoInit(na_3192) } }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_3194 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3194, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3196 lang.IFn; if linked_3195 == nil { ifn_3196 = lang.IFn_Cast(root_3194) } else { ifn_3196 = nil }; var arg_3197 any = t.F_b__78000352; var arg_3198 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3195 == nil { ifn_3196.Invoke_O_O__O(arg_3197, arg_3198) } else { linked_3195.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3194, arg_3197, arg_3198) }; i__78000351__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000351__1); continue L1 } else { i__78000351__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000351__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A) Ctor_O_O(c__tops_QMARK_, c__levels any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_levels = c__levels }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A) Invoke_O_O__O(self, s__78000360__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_New_O_O_O_O(self, t.F_tops_QMARK_, s__78000360__1, t.F_levels); var tmp2 *jrt.Class; var fncls__3599 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_fn_class; if fncls__3599 == nil { var fncls__3599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_fn_class = fncls__3599d; tmp2 = fncls__3599d } else { tmp2 = fncls__3599 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :444:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A) Ctor_O_O_O_O(c__iter__78000359, c__tops_QMARK_, c__s__78000360, c__levels any) { t.F_iter__78000359 = c__iter__78000359; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000360 = c__s__78000360; t.F_levels = c__levels }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A) Invoke_O__O(self any) any { { var s__78000360__1 any; var t_ any = t.F_s__78000360; t.F_s__78000360 = nil; s__78000360__1 = t_; for { var temp__1927000414__auto____2 any; var root_3256 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3256, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3258 lang.IFn; if linked_3257 == nil { ifn_3258 = lang.IFn_Cast(root_3256) } else { ifn_3258 = nil }; var arg_3259 any = s__78000360__1; if linked_3257 == nil { temp__1927000414__auto____2 = ifn_3258.Invoke_O__O(arg_3259) } else { temp__1927000414__auto____2 = linked_3257.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3256, arg_3259) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000360__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3260 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3260, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3262 lang.IFn; if linked_3261 == nil { ifn_3262 = lang.IFn_Cast(root_3260) } else { ifn_3262 = nil }; var arg_3263 any = s__78000360__3; if linked_3261 == nil { tmp1 = ifn_3262.Invoke_O__O(arg_3263) } else { tmp1 = linked_3261.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3260, arg_3263) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3264 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3264, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3266 lang.IFn; if linked_3265 == nil { ifn_3266 = lang.IFn_Cast(root_3264) } else { ifn_3266 = nil }; var arg_3267 any = s__78000360__3; if linked_3265 == nil { c__1927001037__auto____4 = ifn_3266.Invoke_O__O(arg_3267) } else { c__1927001037__auto____4 = linked_3265.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3264, arg_3267) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000362__6 any; var root_3268 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3268, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3270 lang.IFn; if linked_3269 == nil { ifn_3270 = lang.IFn_Cast(root_3268) } else { ifn_3270 = nil }; var arg_3271 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3269 == nil { b__78000362__6 = ifn_3270.Invoke_O__O(arg_3271) } else { b__78000362__6 = linked_3269.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3268, arg_3271) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_New_O_O_I_O_O(t.F_tops_QMARK_, t.F_levels, size__1927001038__auto____5, b__78000362__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3420 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_fn_class; if fncls__3420 == nil { var fncls__3420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_fn_class = fncls__3420d; tmp3 = fncls__3420d } else { tmp3 = fncls__3420 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3429 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3429, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3431 lang.IFn; if linked_3430 == nil { ifn_3431 = lang.IFn_Cast(root_3429) } else { ifn_3431 = nil }; var arg_3432 any; var root_3421 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3421, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3423 lang.IFn; if linked_3422 == nil { ifn_3423 = lang.IFn_Cast(root_3421) } else { ifn_3423 = nil }; var arg_3424 any = b__78000362__6; if linked_3422 == nil { arg_3432 = ifn_3423.Invoke_O__O(arg_3424) } else { arg_3432 = linked_3422.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3421, arg_3424) }; var arg_3433 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000359); var tmp5 any; var root_3425 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3425, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3427 lang.IFn; if linked_3426 == nil { ifn_3427 = lang.IFn_Cast(root_3425) } else { ifn_3427 = nil }; var arg_3428 any = s__78000360__3; if linked_3426 == nil { tmp5 = ifn_3427.Invoke_O__O(arg_3428) } else { tmp5 = linked_3426.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3425, arg_3428) }; arg_3433 = tmp4.Invoke_O__O(tmp5); if linked_3430 == nil { return ifn_3431.Invoke_O_O__O(arg_3432, arg_3433) } else { return linked_3430.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3429, arg_3432, arg_3433) } } else { var root_3438 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3438, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3440 lang.IFn; if linked_3439 == nil { ifn_3440 = lang.IFn_Cast(root_3438) } else { ifn_3440 = nil }; var arg_3441 any; var root_3434 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3434, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3436 lang.IFn; if linked_3435 == nil { ifn_3436 = lang.IFn_Cast(root_3434) } else { ifn_3436 = nil }; var arg_3437 any = b__78000362__6; if linked_3435 == nil { arg_3441 = ifn_3436.Invoke_O__O(arg_3437) } else { arg_3441 = linked_3435.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3434, arg_3437) }; var arg_3442 any; if linked_3439 == nil { return ifn_3440.Invoke_O_O__O(arg_3441, arg_3442) } else { return linked_3439.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3438, arg_3441, arg_3442) } } } else { var h__4 any; var root_3443 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3443, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3445 lang.IFn; if linked_3444 == nil { ifn_3445 = lang.IFn_Cast(root_3443) } else { ifn_3445 = nil }; var arg_3446 any = s__78000360__3; if linked_3444 == nil { h__4 = ifn_3445.Invoke_O__O(arg_3446) } else { h__4 = linked_3444.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3443, arg_3446) }; var root_3594 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3594, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3596 lang.IFn; if linked_3595 == nil { ifn_3596 = lang.IFn_Cast(root_3594) } else { ifn_3596 = nil }; var arg_3597 any; var root_3586 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3586, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3588 lang.IFn
															if linked_3587 == nil { ifn_3588 = lang.IFn_Cast(root_3586) } else { ifn_3588 = nil }; var arg_3589 any; var root_3581 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_3582 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3581, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3583 lang.IFn; if linked_3582 == nil { ifn_3583 = lang.IFn_Cast(root_3581) } else { ifn_3583 = nil }; var arg_3584 any; var iter__1927001039__auto____5 any; var tmp6 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_New_O(t.F_tops_QMARK_); var tmp7 *jrt.Class; var fncls__3517 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_fn_class; if fncls__3517 == nil { var fncls__3517d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_fn_class = fncls__3517d; tmp7 = fncls__3517d } else { tmp7 = fncls__3517 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_3584 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(t.F_levels, h__4)); var arg_3585 any; var iter__1927001039__auto____5_2 any; var tmp8 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_New_O(t.F_tops_QMARK_); var tmp9 *jrt.Class; var fncls__3580 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_fn_class
															if fncls__3580 == nil { var fncls__3580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_fn_class = fncls__3580d; tmp9 = fncls__3580d } else { tmp9 = fncls__3580 }; iter__1927001039__auto____5_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_3585 = lang.IFn_Cast(iter__1927001039__auto____5_2).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(t.F_levels, h__4))
//line :445:1
	if linked_3582 == nil { arg_3589 = ifn_3583.Invoke_O_O__O(arg_3584, arg_3585) } else { arg_3589 = linked_3582.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3581, arg_3584, arg_3585) }; if linked_3587 == nil { arg_3597 = ifn_3588.Invoke_O__O(arg_3589) } else { arg_3597 = linked_3587.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3586, arg_3589) }
//line :444:1
	var arg_3598 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__78000359); var tmp11 any; var root_3590 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3590, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3592 lang.IFn; if linked_3591 == nil { ifn_3592 = lang.IFn_Cast(root_3590) } else { ifn_3592 = nil }; var arg_3593 any = s__78000360__3; if linked_3591 == nil { tmp11 = ifn_3592.Invoke_O__O(arg_3593) } else { tmp11 = linked_3591.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3590, arg_3593) }; arg_3598 = tmp10.Invoke_O__O(tmp11); if linked_3595 == nil { return ifn_3596.Invoke_O_O__O(arg_3597, arg_3598) } else { return linked_3595.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3594, arg_3597, arg_3598) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :444:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A) Ctor_O_O_I_O_O(c__tops_QMARK_, c__levels any, c__size__1927001038__auto__ int32, c__b__78000362, c__c__1927001037__auto__ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_levels = c__levels; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__78000362 = c__b__78000362; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A) Invoke_O__O(self any) any { { var i__78000361__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000361__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var h__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000361__1)); var root_3415 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3415, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3417 lang.IFn; if linked_3416 == nil { ifn_3417 = lang.IFn_Cast(root_3415) } else { ifn_3417 = nil }; var arg_3418 any = t.F_b__78000362; var arg_3419 any; var root_3411 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3411, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3413 lang.IFn
																	if linked_3412 == nil { ifn_3413 = lang.IFn_Cast(root_3411) } else { ifn_3413 = nil }; var arg_3414 any; var root_3406 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_3407 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3406, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3408 lang.IFn; if linked_3407 == nil { ifn_3408 = lang.IFn_Cast(root_3406) } else { ifn_3408 = nil }; var arg_3409 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_New_O(t.F_tops_QMARK_); var tmp3 *jrt.Class; var fncls__3342 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_fn_class; if fncls__3342 == nil { var fncls__3342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_fn_class = fncls__3342d; tmp3 = fncls__3342d } else { tmp3 = fncls__3342 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_3409 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(t.F_levels, h__2)); var arg_3410 any; var iter__1927001039__auto____3_2 any; var tmp4 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_New_O(t.F_tops_QMARK_); var tmp5 *jrt.Class; var fncls__3405 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_fn_class
																	if fncls__3405 == nil { var fncls__3405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_fn_class = fncls__3405d; tmp5 = fncls__3405d } else { tmp5 = fncls__3405 }; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_3410 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(t.F_levels, h__2))
//line :445:1
	if linked_3407 == nil { arg_3414 = ifn_3408.Invoke_O_O__O(arg_3409, arg_3410) } else { arg_3414 = linked_3407.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3406, arg_3409, arg_3410) }; if linked_3412 == nil { arg_3419 = ifn_3413.Invoke_O__O(arg_3414) } else { arg_3419 = linked_3412.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3411, arg_3414) }
//line :444:1
	if linked_3416 == nil { ifn_3417.Invoke_O_O__O(arg_3418, arg_3419) } else { linked_3416.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3415, arg_3418, arg_3419) }; i__78000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000361__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A{}; t.Ctor_O(p0); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A) Invoke_O_O__O(self, s__78000367__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_New_O_O_O(t.F_tops_QMARK_, s__78000367__1, self); var tmp2 *jrt.Class; var fncls__3341 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_fn_class; if fncls__3341 == nil { var fncls__3341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_fn_class = fncls__3341d; tmp2 = fncls__3341d } else { tmp2 = fncls__3341 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A) Ctor_O_O_O(c__tops_QMARK_, c__s__78000367, c__iter__78000366 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000367 = c__s__78000367; t.F_iter__78000366 = c__iter__78000366 }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A) Invoke_O__O(self any) any { { var s__78000367__1 any; var t_ any = t.F_s__78000367; t.F_s__78000367 = nil; s__78000367__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3272 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3272, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3274 lang.IFn; if linked_3273 == nil { ifn_3274 = lang.IFn_Cast(root_3272) } else { ifn_3274 = nil }; var arg_3275 any = s__78000367__1; if linked_3273 == nil { temp__1927000414__auto____2 = ifn_3274.Invoke_O__O(arg_3275) } else { temp__1927000414__auto____2 = linked_3273.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3272, arg_3275) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000367__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3276 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3276, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3278 lang.IFn; if linked_3277 == nil { ifn_3278 = lang.IFn_Cast(root_3276) } else { ifn_3278 = nil }; var arg_3279 any = s__78000367__3; if linked_3277 == nil { tmp1 = ifn_3278.Invoke_O__O(arg_3279) } else { tmp1 = linked_3277.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3276, arg_3279) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3280 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3280, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3282 lang.IFn; if linked_3281 == nil { ifn_3282 = lang.IFn_Cast(root_3280) } else { ifn_3282 = nil }; var arg_3283 any = s__78000367__3; if linked_3281 == nil { c__1927001037__auto____4 = ifn_3282.Invoke_O__O(arg_3283) } else { c__1927001037__auto____4 = linked_3281.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3280, arg_3283) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000369__6 any; var root_3284 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3284, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3286 lang.IFn; if linked_3285 == nil { ifn_3286 = lang.IFn_Cast(root_3284) } else { ifn_3286 = nil }; var arg_3287 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3285 == nil { b__78000369__6 = ifn_3286.Invoke_O__O(arg_3287) } else { b__78000369__6 = linked_3285.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3284, arg_3287) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_New_O_O_I_O(b__78000369__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3297 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_fn_class; if fncls__3297 == nil { var fncls__3297d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_fn_class = fncls__3297d; tmp3 = fncls__3297d } else { tmp3 = fncls__3297 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3306 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3306, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3308 lang.IFn; if linked_3307 == nil { ifn_3308 = lang.IFn_Cast(root_3306) } else { ifn_3308 = nil }; var arg_3309 any; var root_3298 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3298, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3300 lang.IFn; if linked_3299 == nil { ifn_3300 = lang.IFn_Cast(root_3298) } else { ifn_3300 = nil }; var arg_3301 any = b__78000369__6; if linked_3299 == nil { arg_3309 = ifn_3300.Invoke_O__O(arg_3301) } else { arg_3309 = linked_3299.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3298, arg_3301) }; var arg_3310 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000366); var tmp5 any; var root_3302 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3302, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3304 lang.IFn; if linked_3303 == nil { ifn_3304 = lang.IFn_Cast(root_3302) } else { ifn_3304 = nil }; var arg_3305 any = s__78000367__3; if linked_3303 == nil { tmp5 = ifn_3304.Invoke_O__O(arg_3305) } else { tmp5 = linked_3303.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3302, arg_3305) }; arg_3310 = tmp4.Invoke_O__O(tmp5); if linked_3307 == nil { return ifn_3308.Invoke_O_O__O(arg_3309, arg_3310) } else { return linked_3307.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3306, arg_3309, arg_3310) } } else { var root_3315 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3315, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3317 lang.IFn; if linked_3316 == nil { ifn_3317 = lang.IFn_Cast(root_3315) } else { ifn_3317 = nil }; var arg_3318 any; var root_3311 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3311, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3313 lang.IFn; if linked_3312 == nil { ifn_3313 = lang.IFn_Cast(root_3311) } else { ifn_3313 = nil }; var arg_3314 any = b__78000369__6; if linked_3312 == nil { arg_3318 = ifn_3313.Invoke_O__O(arg_3314) } else { arg_3318 = linked_3312.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3311, arg_3314) }; var arg_3319 any; if linked_3316 == nil { return ifn_3317.Invoke_O_O__O(arg_3318, arg_3319) } else { return linked_3316.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3315, arg_3318, arg_3319) } } } else { var n__4 any; var root_3320 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3320, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3322 lang.IFn; if linked_3321 == nil { ifn_3322 = lang.IFn_Cast(root_3320) } else { ifn_3322 = nil }; var arg_3323 any = s__78000367__3; if linked_3321 == nil { n__4 = ifn_3322.Invoke_O__O(arg_3323) } else { n__4 = linked_3321.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3320, arg_3323) }; var tmp6 any; var root_3324 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3324, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3326 lang.IFn; if linked_3325 == nil { ifn_3326 = lang.IFn_Cast(root_3324) } else { ifn_3326 = nil }; var arg_3327 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if linked_3325 == nil { tmp6 = ifn_3326.Invoke_O__O(arg_3327) } else { tmp6 = linked_3325.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3324, arg_3327) }; if jrt.J2g_Truth(tmp6) { var root_3332 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3332, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3334 lang.IFn; if linked_3333 == nil { ifn_3334 = lang.IFn_Cast(root_3332) } else { ifn_3334 = nil }; var arg_3335 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3336 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000366); var tmp8 any; var root_3328 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3328, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3330 lang.IFn; if linked_3329 == nil { ifn_3330 = lang.IFn_Cast(root_3328) } else { ifn_3330 = nil }; var arg_3331 any = s__78000367__3; if linked_3329 == nil { tmp8 = ifn_3330.Invoke_O__O(arg_3331) } else { tmp8 = linked_3329.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3328, arg_3331) }; arg_3336 = tmp7.Invoke_O__O(tmp8); if linked_3333 == nil { return ifn_3334.Invoke_O_O__O(arg_3335, arg_3336) } else { return linked_3333.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3332, arg_3335, arg_3336) } } else { var tmp9 any; var root_3337 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3337, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3339 lang.IFn; if linked_3338 == nil { ifn_3339 = lang.IFn_Cast(root_3337) } else { ifn_3339 = nil }; var arg_3340 any = s__78000367__3; if linked_3338 == nil { tmp9 = ifn_3339.Invoke_O__O(arg_3340) } else { tmp9 = linked_3338.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3337, arg_3340) }; s__78000367__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A) Ctor_O_O_I_O(c__b__78000369, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000369 = c__b__78000369; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A) Invoke_O__O(self any) any { { var i__78000368__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000368__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000368__1)); var tmp2 any; var root_3288 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3290 lang.IFn; if linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if linked_3289 == nil { tmp2 = ifn_3290.Invoke_O__O(arg_3291) } else { tmp2 = linked_3289.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3288, arg_3291) }; if jrt.J2g_Truth(tmp2) { var root_3292 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3292, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3294 lang.IFn; if linked_3293 == nil { ifn_3294 = lang.IFn_Cast(root_3292) } else { ifn_3294 = nil }; var arg_3295 any = t.F_b__78000369; var arg_3296 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3293 == nil { ifn_3294.Invoke_O_O__O(arg_3295, arg_3296) } else { linked_3293.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3292, arg_3295, arg_3296) }; i__78000368__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000368__1); continue L1 } else { i__78000368__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000368__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A{}; t.Ctor_O(p0); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A) Invoke_O_O__O(self, s__78000388__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_New_O_O_O(t.F_tops_QMARK_, s__78000388__1, self); var tmp2 *jrt.Class; var fncls__3516 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_fn_class; if fncls__3516 == nil { var fncls__3516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_fn_class = fncls__3516d; tmp2 = fncls__3516d } else { tmp2 = fncls__3516 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A) Ctor_O_O_O(c__tops_QMARK_, c__s__78000388, c__iter__78000387 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000388 = c__s__78000388; t.F_iter__78000387 = c__iter__78000387 }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A) Invoke_O__O(self any) any { { var s__78000388__1 any; var t_ any = t.F_s__78000388; t.F_s__78000388 = nil; s__78000388__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3447 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3449 lang.IFn; if linked_3448 == nil { ifn_3449 = lang.IFn_Cast(root_3447) } else { ifn_3449 = nil }; var arg_3450 any = s__78000388__1; if linked_3448 == nil { temp__1927000414__auto____2 = ifn_3449.Invoke_O__O(arg_3450) } else { temp__1927000414__auto____2 = linked_3448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3447, arg_3450) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000388__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3451 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3453 lang.IFn; if linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any = s__78000388__3; if linked_3452 == nil { tmp1 = ifn_3453.Invoke_O__O(arg_3454) } else { tmp1 = linked_3452.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3451, arg_3454) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3455 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3457 lang.IFn; if linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any = s__78000388__3; if linked_3456 == nil { c__1927001037__auto____4 = ifn_3457.Invoke_O__O(arg_3458) } else { c__1927001037__auto____4 = linked_3456.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3455, arg_3458) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000390__6 any; var root_3459 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3459, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3461 lang.IFn; if linked_3460 == nil { ifn_3461 = lang.IFn_Cast(root_3459) } else { ifn_3461 = nil }; var arg_3462 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3460 == nil { b__78000390__6 = ifn_3461.Invoke_O__O(arg_3462) } else { b__78000390__6 = linked_3460.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3459, arg_3462) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_New_O_O_I_O(t.F_tops_QMARK_, b__78000390__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3472 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_fn_class; if fncls__3472 == nil { var fncls__3472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_fn_class = fncls__3472d; tmp3 = fncls__3472d } else { tmp3 = fncls__3472 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3481 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3481, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3483 lang.IFn; if linked_3482 == nil { ifn_3483 = lang.IFn_Cast(root_3481) } else { ifn_3483 = nil }; var arg_3484 any; var root_3473 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3473, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3475 lang.IFn; if linked_3474 == nil { ifn_3475 = lang.IFn_Cast(root_3473) } else { ifn_3475 = nil }; var arg_3476 any = b__78000390__6; if linked_3474 == nil { arg_3484 = ifn_3475.Invoke_O__O(arg_3476) } else { arg_3484 = linked_3474.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3473, arg_3476) }; var arg_3485 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000387); var tmp5 any; var root_3477 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3477, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3479 lang.IFn; if linked_3478 == nil { ifn_3479 = lang.IFn_Cast(root_3477) } else { ifn_3479 = nil }; var arg_3480 any = s__78000388__3; if linked_3478 == nil { tmp5 = ifn_3479.Invoke_O__O(arg_3480) } else { tmp5 = linked_3478.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3477, arg_3480) }; arg_3485 = tmp4.Invoke_O__O(tmp5); if linked_3482 == nil { return ifn_3483.Invoke_O_O__O(arg_3484, arg_3485) } else { return linked_3482.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3481, arg_3484, arg_3485) } } else { var root_3490 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3490, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3492 lang.IFn; if linked_3491 == nil { ifn_3492 = lang.IFn_Cast(root_3490) } else { ifn_3492 = nil }; var arg_3493 any; var root_3486 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3486, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3488 lang.IFn; if linked_3487 == nil { ifn_3488 = lang.IFn_Cast(root_3486) } else { ifn_3488 = nil }; var arg_3489 any = b__78000390__6; if linked_3487 == nil { arg_3493 = ifn_3488.Invoke_O__O(arg_3489) } else { arg_3493 = linked_3487.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3486, arg_3489) }; var arg_3494 any; if linked_3491 == nil { return ifn_3492.Invoke_O_O__O(arg_3493, arg_3494) } else { return linked_3491.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3490, arg_3493, arg_3494) } } } else { var n__4 any; var root_3495 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3495, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3497 lang.IFn; if linked_3496 == nil { ifn_3497 = lang.IFn_Cast(root_3495) } else { ifn_3497 = nil }; var arg_3498 any = s__78000388__3; if linked_3496 == nil { n__4 = ifn_3497.Invoke_O__O(arg_3498) } else { n__4 = linked_3496.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3495, arg_3498) }; var tmp6 any; var root_3499 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3499, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3501 lang.IFn; if linked_3500 == nil { ifn_3501 = lang.IFn_Cast(root_3499) } else { ifn_3501 = nil }; var arg_3502 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if linked_3500 == nil { tmp6 = ifn_3501.Invoke_O__O(arg_3502) } else { tmp6 = linked_3500.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3499, arg_3502) }; if jrt.J2g_Truth(tmp6) { var root_3507 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3507, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3509 lang.IFn; if linked_3508 == nil { ifn_3509 = lang.IFn_Cast(root_3507) } else { ifn_3509 = nil }; var arg_3510 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3511 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000387); var tmp8 any; var root_3503 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3503, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3505 lang.IFn; if linked_3504 == nil { ifn_3505 = lang.IFn_Cast(root_3503) } else { ifn_3505 = nil }; var arg_3506 any = s__78000388__3; if linked_3504 == nil { tmp8 = ifn_3505.Invoke_O__O(arg_3506) } else { tmp8 = linked_3504.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3503, arg_3506) }; arg_3511 = tmp7.Invoke_O__O(tmp8); if linked_3508 == nil { return ifn_3509.Invoke_O_O__O(arg_3510, arg_3511) } else { return linked_3508.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3507, arg_3510, arg_3511) } } else { var tmp9 any; var root_3512 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3512, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3514 lang.IFn; if linked_3513 == nil { ifn_3514 = lang.IFn_Cast(root_3512) } else { ifn_3514 = nil }; var arg_3515 any = s__78000388__3; if linked_3513 == nil { tmp9 = ifn_3514.Invoke_O__O(arg_3515) } else { tmp9 = linked_3513.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3512, arg_3515) }; s__78000388__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A) Ctor_O_O_I_O(c__tops_QMARK_, c__b__78000390 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_b__78000390 = c__b__78000390; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A) Invoke_O__O(self any) any { { var i__78000389__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000389__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000389__1)); var tmp2 any; var root_3463 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3463, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3465 lang.IFn; if linked_3464 == nil { ifn_3465 = lang.IFn_Cast(root_3463) } else { ifn_3465 = nil }; var arg_3466 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if linked_3464 == nil { tmp2 = ifn_3465.Invoke_O__O(arg_3466) } else { tmp2 = linked_3464.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3463, arg_3466) }; if jrt.J2g_Truth(tmp2) { var root_3467 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3467, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3469 lang.IFn; if linked_3468 == nil { ifn_3469 = lang.IFn_Cast(root_3467) } else { ifn_3469 = nil }; var arg_3470 any = t.F_b__78000390; var arg_3471 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3468 == nil { ifn_3469.Invoke_O_O__O(arg_3470, arg_3471) } else { linked_3468.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3467, arg_3470, arg_3471) }; i__78000389__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000389__1); continue L1 } else { i__78000389__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000389__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A{}; t.Ctor_O(p0); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A) Invoke_O_O__O(self, s__78000377__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_New_O_O_O(t.F_tops_QMARK_, s__78000377__1, self); var tmp2 *jrt.Class; var fncls__3404 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_fn_class; if fncls__3404 == nil { var fncls__3404d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_fn_class = fncls__3404d; tmp2 = fncls__3404d } else { tmp2 = fncls__3404 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A) Ctor_O_O_O(c__tops_QMARK_, c__s__78000377, c__iter__78000376 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000377 = c__s__78000377; t.F_iter__78000376 = c__iter__78000376 }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A) Invoke_O__O(self any) any { { var s__78000377__1 any; var t_ any = t.F_s__78000377; t.F_s__78000377 = nil; s__78000377__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3343 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3343, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3345 lang.IFn; if linked_3344 == nil { ifn_3345 = lang.IFn_Cast(root_3343) } else { ifn_3345 = nil }; var arg_3346 any = s__78000377__1; if linked_3344 == nil { temp__1927000414__auto____2 = ifn_3345.Invoke_O__O(arg_3346) } else { temp__1927000414__auto____2 = linked_3344.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3343, arg_3346) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000377__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3347 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3347, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3349 lang.IFn; if linked_3348 == nil { ifn_3349 = lang.IFn_Cast(root_3347) } else { ifn_3349 = nil }; var arg_3350 any = s__78000377__3; if linked_3348 == nil { tmp1 = ifn_3349.Invoke_O__O(arg_3350) } else { tmp1 = linked_3348.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3347, arg_3350) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3351 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3351, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3353 lang.IFn; if linked_3352 == nil { ifn_3353 = lang.IFn_Cast(root_3351) } else { ifn_3353 = nil }; var arg_3354 any = s__78000377__3; if linked_3352 == nil { c__1927001037__auto____4 = ifn_3353.Invoke_O__O(arg_3354) } else { c__1927001037__auto____4 = linked_3352.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3351, arg_3354) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000379__6 any; var root_3355 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3355, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3357 lang.IFn; if linked_3356 == nil { ifn_3357 = lang.IFn_Cast(root_3355) } else { ifn_3357 = nil }; var arg_3358 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3356 == nil { b__78000379__6 = ifn_3357.Invoke_O__O(arg_3358) } else { b__78000379__6 = linked_3356.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3355, arg_3358) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_New_O_O_I_O(b__78000379__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3364 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_fn_class; if fncls__3364 == nil { var fncls__3364d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_fn_class = fncls__3364d; tmp3 = fncls__3364d } else { tmp3 = fncls__3364 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3373 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3373, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3375 lang.IFn; if linked_3374 == nil { ifn_3375 = lang.IFn_Cast(root_3373) } else { ifn_3375 = nil }; var arg_3376 any; var root_3365 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3365, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3367 lang.IFn; if linked_3366 == nil { ifn_3367 = lang.IFn_Cast(root_3365) } else { ifn_3367 = nil }; var arg_3368 any = b__78000379__6; if linked_3366 == nil { arg_3376 = ifn_3367.Invoke_O__O(arg_3368) } else { arg_3376 = linked_3366.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3365, arg_3368) }; var arg_3377 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000376); var tmp5 any; var root_3369 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3369, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3371 lang.IFn; if linked_3370 == nil { ifn_3371 = lang.IFn_Cast(root_3369) } else { ifn_3371 = nil }; var arg_3372 any = s__78000377__3; if linked_3370 == nil { tmp5 = ifn_3371.Invoke_O__O(arg_3372) } else { tmp5 = linked_3370.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3369, arg_3372) }; arg_3377 = tmp4.Invoke_O__O(tmp5); if linked_3374 == nil { return ifn_3375.Invoke_O_O__O(arg_3376, arg_3377) } else { return linked_3374.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3373, arg_3376, arg_3377) } } else { var root_3382 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3382, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3384 lang.IFn; if linked_3383 == nil { ifn_3384 = lang.IFn_Cast(root_3382) } else { ifn_3384 = nil }; var arg_3385 any; var root_3378 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3378, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3380 lang.IFn; if linked_3379 == nil { ifn_3380 = lang.IFn_Cast(root_3378) } else { ifn_3380 = nil }; var arg_3381 any = b__78000379__6; if linked_3379 == nil { arg_3385 = ifn_3380.Invoke_O__O(arg_3381) } else { arg_3385 = linked_3379.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3378, arg_3381) }; var arg_3386 any; if linked_3383 == nil { return ifn_3384.Invoke_O_O__O(arg_3385, arg_3386) } else { return linked_3383.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3382, arg_3385, arg_3386) } } } else { var n__4 any; var root_3387 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3387, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3389 lang.IFn; if linked_3388 == nil { ifn_3389 = lang.IFn_Cast(root_3387) } else { ifn_3389 = nil }; var arg_3390 any = s__78000377__3; if linked_3388 == nil { n__4 = ifn_3389.Invoke_O__O(arg_3390) } else { n__4 = linked_3388.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3387, arg_3390) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4)) { var root_3395 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3397 lang.IFn; if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3399 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__78000376); var tmp7 any; var root_3391 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3391, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3393 lang.IFn; if linked_3392 == nil { ifn_3393 = lang.IFn_Cast(root_3391) } else { ifn_3393 = nil }; var arg_3394 any = s__78000377__3; if linked_3392 == nil { tmp7 = ifn_3393.Invoke_O__O(arg_3394) } else { tmp7 = linked_3392.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3391, arg_3394) }; arg_3399 = tmp6.Invoke_O__O(tmp7); if linked_3396 == nil { return ifn_3397.Invoke_O_O__O(arg_3398, arg_3399) } else { return linked_3396.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3395, arg_3398, arg_3399) } } else { var tmp8 any; var root_3400 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3400, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3402 lang.IFn; if linked_3401 == nil { ifn_3402 = lang.IFn_Cast(root_3400) } else { ifn_3402 = nil }; var arg_3403 any = s__78000377__3; if linked_3401 == nil { tmp8 = ifn_3402.Invoke_O__O(arg_3403) } else { tmp8 = linked_3401.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3400, arg_3403) }; s__78000377__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A) Ctor_O_O_I_O(c__b__78000379, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000379 = c__b__78000379; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A) Invoke_O__O(self any) any { { var i__78000378__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000378__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000378__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2)) { var root_3359 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3359, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3361 lang.IFn; if linked_3360 == nil { ifn_3361 = lang.IFn_Cast(root_3359) } else { ifn_3361 = nil }; var arg_3362 any = t.F_b__78000379; var arg_3363 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3360 == nil { ifn_3361.Invoke_O_O__O(arg_3362, arg_3363) } else { linked_3360.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3359, arg_3362, arg_3363) }; i__78000378__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000378__1); continue L1 } else { i__78000378__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000378__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A{}; t.Ctor_O(p0); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A) Invoke_O_O__O(self, s__78000398__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_New_O_O_O(t.F_tops_QMARK_, s__78000398__1, self); var tmp2 *jrt.Class; var fncls__3579 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_fn_class; if fncls__3579 == nil { var fncls__3579d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_fn_class = fncls__3579d; tmp2 = fncls__3579d } else { tmp2 = fncls__3579 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A) Ctor_O_O_O(c__tops_QMARK_, c__s__78000398, c__iter__78000397 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000398 = c__s__78000398; t.F_iter__78000397 = c__iter__78000397 }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A) Invoke_O__O(self any) any { { var s__78000398__1 any; var t_ any = t.F_s__78000398; t.F_s__78000398 = nil; s__78000398__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3518 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3518, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3520 lang.IFn; if linked_3519 == nil { ifn_3520 = lang.IFn_Cast(root_3518) } else { ifn_3520 = nil }; var arg_3521 any = s__78000398__1; if linked_3519 == nil { temp__1927000414__auto____2 = ifn_3520.Invoke_O__O(arg_3521) } else { temp__1927000414__auto____2 = linked_3519.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3518, arg_3521) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000398__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3522 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3522, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3524 lang.IFn; if linked_3523 == nil { ifn_3524 = lang.IFn_Cast(root_3522) } else { ifn_3524 = nil }; var arg_3525 any = s__78000398__3; if linked_3523 == nil { tmp1 = ifn_3524.Invoke_O__O(arg_3525) } else { tmp1 = linked_3523.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3522, arg_3525) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3526 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3526, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3528 lang.IFn; if linked_3527 == nil { ifn_3528 = lang.IFn_Cast(root_3526) } else { ifn_3528 = nil }; var arg_3529 any = s__78000398__3; if linked_3527 == nil { c__1927001037__auto____4 = ifn_3528.Invoke_O__O(arg_3529) } else { c__1927001037__auto____4 = linked_3527.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3526, arg_3529) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000400__6 any; var root_3530 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3530, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3532 lang.IFn; if linked_3531 == nil { ifn_3532 = lang.IFn_Cast(root_3530) } else { ifn_3532 = nil }; var arg_3533 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3531 == nil { b__78000400__6 = ifn_3532.Invoke_O__O(arg_3533) } else { b__78000400__6 = linked_3531.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3530, arg_3533) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_New_O_O_I_O(b__78000400__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3539 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_fn_class; if fncls__3539 == nil { var fncls__3539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_fn_class = fncls__3539d; tmp3 = fncls__3539d } else { tmp3 = fncls__3539 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3548 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3548, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3550 lang.IFn; if linked_3549 == nil { ifn_3550 = lang.IFn_Cast(root_3548) } else { ifn_3550 = nil }; var arg_3551 any; var root_3540 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3540, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3542 lang.IFn; if linked_3541 == nil { ifn_3542 = lang.IFn_Cast(root_3540) } else { ifn_3542 = nil }; var arg_3543 any = b__78000400__6; if linked_3541 == nil { arg_3551 = ifn_3542.Invoke_O__O(arg_3543) } else { arg_3551 = linked_3541.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3540, arg_3543) }; var arg_3552 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000397); var tmp5 any; var root_3544 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3544, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3546 lang.IFn; if linked_3545 == nil { ifn_3546 = lang.IFn_Cast(root_3544) } else { ifn_3546 = nil }; var arg_3547 any = s__78000398__3; if linked_3545 == nil { tmp5 = ifn_3546.Invoke_O__O(arg_3547) } else { tmp5 = linked_3545.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3544, arg_3547) }; arg_3552 = tmp4.Invoke_O__O(tmp5); if linked_3549 == nil { return ifn_3550.Invoke_O_O__O(arg_3551, arg_3552) } else { return linked_3549.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3548, arg_3551, arg_3552) } } else { var root_3557 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3557, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any; var root_3553 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3553, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3555 lang.IFn; if linked_3554 == nil { ifn_3555 = lang.IFn_Cast(root_3553) } else { ifn_3555 = nil }; var arg_3556 any = b__78000400__6; if linked_3554 == nil { arg_3560 = ifn_3555.Invoke_O__O(arg_3556) } else { arg_3560 = linked_3554.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3553, arg_3556) }; var arg_3561 any; if linked_3558 == nil { return ifn_3559.Invoke_O_O__O(arg_3560, arg_3561) } else { return linked_3558.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3557, arg_3560, arg_3561) } } } else { var n__4 any; var root_3562 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3562, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3564 lang.IFn; if linked_3563 == nil { ifn_3564 = lang.IFn_Cast(root_3562) } else { ifn_3564 = nil }; var arg_3565 any = s__78000398__3; if linked_3563 == nil { n__4 = ifn_3564.Invoke_O__O(arg_3565) } else { n__4 = linked_3563.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3562, arg_3565) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4)) { var root_3570 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3570, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3572 lang.IFn; if linked_3571 == nil { ifn_3572 = lang.IFn_Cast(root_3570) } else { ifn_3572 = nil }; var arg_3573 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3574 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__78000397); var tmp7 any; var root_3566 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3566, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3568 lang.IFn; if linked_3567 == nil { ifn_3568 = lang.IFn_Cast(root_3566) } else { ifn_3568 = nil }; var arg_3569 any = s__78000398__3; if linked_3567 == nil { tmp7 = ifn_3568.Invoke_O__O(arg_3569) } else { tmp7 = linked_3567.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3566, arg_3569) }; arg_3574 = tmp6.Invoke_O__O(tmp7); if linked_3571 == nil { return ifn_3572.Invoke_O_O__O(arg_3573, arg_3574) } else { return linked_3571.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3570, arg_3573, arg_3574) } } else { var tmp8 any; var root_3575 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3575, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3577 lang.IFn; if linked_3576 == nil { ifn_3577 = lang.IFn_Cast(root_3575) } else { ifn_3577 = nil }; var arg_3578 any = s__78000398__3; if linked_3576 == nil { tmp8 = ifn_3577.Invoke_O__O(arg_3578) } else { tmp8 = linked_3576.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3575, arg_3578) }; s__78000398__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A) Ctor_O_O_I_O(c__b__78000400, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000400 = c__b__78000400; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A) Invoke_O__O(self any) any { { var i__78000399__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000399__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000399__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2)) { var root_3534 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3534, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3536 lang.IFn; if linked_3535 == nil { ifn_3536 = lang.IFn_Cast(root_3534) } else { ifn_3536 = nil }; var arg_3537 any = t.F_b__78000400; var arg_3538 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3535 == nil { ifn_3536.Invoke_O_O__O(arg_3537, arg_3538) } else { linked_3535.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3534, arg_3537, arg_3538) }; i__78000399__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000399__1); continue L1 } else { i__78000399__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000399__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A{}; t.Ctor_O_O(p0, p1); return t }
//line :456:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A) Ctor_O_O(c__space, c__prev any) { t.F_space = c__space; t.F_prev = c__prev }
//line :456:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_j2g_world_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_218); return nil }(); if
												jrt.J2g_Truth(t.F_space) { if jrt.J2g_Truth(t.F_prev) { var tmp3 any; var t_ any = t.F_space; t.F_space = nil; tmp3 = t_; var tmp4 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(tmp3); var tmp5 any; var t__2 any = t.F_prev; t.F_prev = nil; tmp5 = t__2; tmp4.Set_O__V(tmp5) } else { var tmp6 any; var t__3 any = t.F_space; t.F_space = nil; tmp6 = t__3; jrt.ThreadLocal_Cast(tmp6).Remove__V() } }; if /*line :456:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }











func A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :468:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A) Ctor_O_O_O(c__space, c__analyze_BANG_, c__unit any) { t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit }
//line :468:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A) Invoke_O_O__O(self, g__1 any) any { var s__2 int64 = jrt.System_NanoTime__J(); var order__3 any; var root_3817 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_3818 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3817, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3819 lang.IFn; if

	linked_3818 == nil { ifn_3819 = lang.IFn_Cast(root_3817) } else { ifn_3819 = nil }; var arg_3820 any = lang.PersistentVector_EMPTY.Ref(); if linked_3818 == nil { order__3 = ifn_3819.Invoke_O__O(arg_3820) } else { order__3 = linked_3818.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3817, arg_3820) }; var tmp1 jrt.ThreadLocal_I =
	jrt.ThreadLocal_Cast(t.F_space); tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_j2g_world_A_const_214.GetRawRoot__O()))); var tmp2 any =
	A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_New_O_O_O_O_O(g__1, t.F_space, order__3, t.F_analyze_BANG_, t.F_unit); var tmp3 *jrt.Class; var fncls__3844 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_fn_class; if fncls__3844 == nil { var fncls__3844d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_fn_class = fncls__3844d; tmp3 = fncls__3844d } else { tmp3 = fncls__3844 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); var tmp4 any; var root_3845 any = /*line :468:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3845, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3847 lang.IFn; if





	linked_3846 == nil { ifn_3847 = lang.IFn_Cast(root_3845) } else { ifn_3847 = nil }; var arg_3848 any = g__1; if linked_3846 == nil { tmp4 = ifn_3847.Invoke_O__O(arg_3848) } else { tmp4 = linked_3846.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3845, arg_3848) }; var tmp5 any = tmp4; var tmp6 any = /*line :468:1*/jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), s__2), 1.0e9)).Ref(); var tmp7 any; var root_3849 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3849, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3851 lang.IFn; if
	linked_3850 == nil { ifn_3851 = lang.IFn_Cast(root_3849) } else { ifn_3851 = nil }; var arg_3852 any = order__3; if linked_3850 == nil { tmp7 = ifn_3851.Invoke_O__O(arg_3852) } else { tmp7 = linked_3850.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3849, arg_3852) }; return /*line :468:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) }
//line :468:1
func A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :468:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A) Ctor_O_O_O(c__space, c__analyze_BANG_, c__unit any) { t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit }
//line :468:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A) Invoke_O_O__O(self, g__1 any) any { var s__2 int64 = jrt.System_NanoTime__J(); var order__3 any; var root_3963 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_3964 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3963, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3965 lang.IFn; if

	linked_3964 == nil { ifn_3965 = lang.IFn_Cast(root_3963) } else { ifn_3965 = nil }; var arg_3966 any = lang.PersistentVector_EMPTY.Ref(); if linked_3964 == nil { order__3 = ifn_3965.Invoke_O__O(arg_3966) } else { order__3 = linked_3964.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3963, arg_3966) }; var tmp1 jrt.ThreadLocal_I =
	jrt.ThreadLocal_Cast(t.F_space); tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_j2g_world_A_const_214.GetRawRoot__O()))); var tmp2 any =
	A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_New_O_O_O_O_O(g__1, t.F_space, order__3, t.F_analyze_BANG_, t.F_unit); var tmp3 *jrt.Class; var fncls__3990 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_fn_class; if fncls__3990 == nil { var fncls__3990d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_fn_class = fncls__3990d; tmp3 = fncls__3990d } else { tmp3 = fncls__3990 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); var tmp4 any; var root_3991 any = /*line :468:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3991, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3993 lang.IFn; if





	linked_3992 == nil { ifn_3993 = lang.IFn_Cast(root_3991) } else { ifn_3993 = nil }; var arg_3994 any = g__1; if linked_3992 == nil { tmp4 = ifn_3993.Invoke_O__O(arg_3994) } else { tmp4 = linked_3992.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3991, arg_3994) }; var tmp5 any = tmp4; var tmp6 any = /*line :468:1*/jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), s__2), 1.0e9)).Ref(); var tmp7 any; var root_3995 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3995, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3997 lang.IFn; if
	linked_3996 == nil { ifn_3997 = lang.IFn_Cast(root_3995) } else { ifn_3997 = nil }; var arg_3998 any = order__3; if linked_3996 == nil { tmp7 = ifn_3997.Invoke_O__O(arg_3998) } else { tmp7 = linked_3996.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3995, arg_3998) }; return /*line :468:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) }



func A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :472:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A) Ctor_O_O_O_O_O(c__g, c__space, c__order, c__analyze_BANG_, c__unit any) { t.F_g = c__g; t.F_space = c__space; t.F_order = c__order; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit }
//line :472:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3840 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_3841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3840, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3842 lang.IFn; if linked_3841 == nil { ifn_3842 = lang.IFn_Cast(root_3840) } else { ifn_3842 = nil }; var arg_3843 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_world_A_const_209; var tmp4 any; var root_3829 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_3830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3829, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3831 lang.IFn; if linked_3830 == nil { ifn_3831 = lang.IFn_Cast(root_3829) } else { ifn_3831 = nil }; var arg_3832 any; var t_ any = t.F_unit; t.F_unit = nil; arg_3832 = t_; var arg_3833 any = A_arbace_j2g_world_A_const_133; var arg_3834 any; var t__2 any = t.F_order; t.F_order = nil; arg_3834 = t__2; if linked_3830 == nil { tmp4 = ifn_3831.Invoke_O_O_O__O(arg_3832, arg_3833, arg_3834) } else { tmp4 = linked_3830.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3829, arg_3832, arg_3833, arg_3834) }; arg_3843 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_3841 == nil { ifn_3842.Invoke_O__O(arg_3843) } else { linked_3841.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3840, arg_3843) }; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3821 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_3822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3821, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3823 lang.IFn; if linked_3822 == nil { ifn_3823 = lang.IFn_Cast(root_3821) } else { ifn_3823 = nil }; var arg_3824 any; var t__3 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; arg_3824 = t__3; var arg_3825 any; var t__4 any = t.F_g; t.F_g = nil; arg_3825 = t__4; if linked_3822 == nil { tmp1 = ifn_3823.Invoke_O_O__O(arg_3824, arg_3825) } else { tmp1 = linked_3822.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3821, arg_3824, arg_3825) } }; return nil }(); var root_3826 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_3827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3826, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3828 lang.IFn; if linked_3827 == nil { ifn_3828 = lang.IFn_Cast(root_3826) } else { ifn_3828 = nil }; if linked_3827 == nil { ifn_3828.Invoke__O() } else { linked_3827.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3826) }; if tmp5 != nil { panic(tmp5) } }; return nil }(); var tmp7 any; var t__5 any = t.F_space;
														t.F_space = nil; tmp7 = t__5; jrt.ThreadLocal_Cast(tmp7).Remove__V(); if /*line :472:1*/ tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :472:1
func A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :472:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A) Ctor_O_O_O_O_O(c__g, c__space, c__order, c__analyze_BANG_, c__unit any) { t.F_g = c__g; t.F_space = c__space; t.F_order = c__order; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit }
//line :472:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3986 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_3987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3986, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3988 lang.IFn; if linked_3987 == nil { ifn_3988 = lang.IFn_Cast(root_3986) } else { ifn_3988 = nil }; var arg_3989 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_world_A_const_209; var tmp4 any; var root_3975 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_3976 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3975, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3977 lang.IFn; if linked_3976 == nil { ifn_3977 = lang.IFn_Cast(root_3975) } else { ifn_3977 = nil }; var arg_3978 any; var t_ any = t.F_unit; t.F_unit = nil; arg_3978 = t_; var arg_3979 any = A_arbace_j2g_world_A_const_133; var arg_3980 any; var t__2 any = t.F_order; t.F_order = nil; arg_3980 = t__2; if linked_3976 == nil { tmp4 = ifn_3977.Invoke_O_O_O__O(arg_3978, arg_3979, arg_3980) } else { tmp4 = linked_3976.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3975, arg_3978, arg_3979, arg_3980) }; arg_3989 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_3987 == nil { ifn_3988.Invoke_O__O(arg_3989) } else { linked_3987.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3986, arg_3989) }; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3967 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_3968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3967, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3969 lang.IFn; if linked_3968 == nil { ifn_3969 = lang.IFn_Cast(root_3967) } else { ifn_3969 = nil }; var arg_3970 any; var t__3 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; arg_3970 = t__3; var arg_3971 any; var t__4 any = t.F_g; t.F_g = nil; arg_3971 = t__4; if linked_3968 == nil { tmp1 = ifn_3969.Invoke_O_O__O(arg_3970, arg_3971) } else { tmp1 = linked_3968.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3967, arg_3970, arg_3971) } }; return nil }(); var root_3972 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_3973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3972, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3974 lang.IFn; if linked_3973 == nil { ifn_3974 = lang.IFn_Cast(root_3972) } else { ifn_3974 = nil }; if linked_3973 == nil { ifn_3974.Invoke__O() } else { linked_3973.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3972) }; if tmp5 != nil { panic(tmp5) } }; return nil }(); var tmp7 any; var t__5 any = t.F_space;
														t.F_space = nil; tmp7 = t__5; jrt.ThreadLocal_Cast(tmp7).Remove__V(); if /*line :472:1*/ tmp6 != nil { panic(tmp6) }; return tmp1 }



func A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_New() *A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A) Ctor() {}
//line :476:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A) Invoke_O_O__O(self, p1__78000224_SHARP___1 any) any { return lang.RT_Nth_O_I__O_NoInit(p1__78000224_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)) }
//line :476:1
func A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_New() *A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A) Ctor() {}
//line :476:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A) Invoke_O_O__O(self, p1__78000224_SHARP___1 any) any { return lang.RT_Nth_O_I__O_NoInit(p1__78000224_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)) }


















func A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_New() *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A) Ctor() {}
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A) Invoke_O_O__O(self, s__78000451__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_New_O_O(s__78000451__1, self); var tmp2 *jrt.Class; var fncls__3666 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_fn_class; if fncls__3666 == nil { var fncls__3666d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_fn_class = fncls__3666d; tmp2 = fncls__3666d } else { tmp2 = fncls__3666 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :495:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A{}; t.Ctor_O_O(p0, p1); return t }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A) Ctor_O_O(c__s__78000451, c__iter__78000450 any) { t.F_s__78000451 = c__s__78000451; t.F_iter__78000450 = c__iter__78000450 }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A) Invoke_O__O(self any) any { { var s__78000451__1 any; var t_ any = t.F_s__78000451; t.F_s__78000451 = nil; s__78000451__1 = t_; for { var temp__1927000414__auto____2 any; var root_3601 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3601, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3603 lang.IFn; if linked_3602 == nil { ifn_3603 = lang.IFn_Cast(root_3601) } else { ifn_3603 = nil }; var arg_3604 any = s__78000451__1; if linked_3602 == nil { temp__1927000414__auto____2 = ifn_3603.Invoke_O__O(arg_3604) } else { temp__1927000414__auto____2 = linked_3602.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3601, arg_3604) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000451__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3605 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3605, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3607 lang.IFn; if linked_3606 == nil { ifn_3607 = lang.IFn_Cast(root_3605) } else { ifn_3607 = nil }; var arg_3608 any = s__78000451__3; if linked_3606 == nil { tmp1 = ifn_3607.Invoke_O__O(arg_3608) } else { tmp1 = linked_3606.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3605, arg_3608) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3609 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3609, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3611 lang.IFn; if linked_3610 == nil { ifn_3611 = lang.IFn_Cast(root_3609) } else { ifn_3611 = nil }; var arg_3612 any = s__78000451__3; if linked_3610 == nil { c__1927001037__auto____4 = ifn_3611.Invoke_O__O(arg_3612) } else { c__1927001037__auto____4 = linked_3610.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3609, arg_3612) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000453__6 any; var root_3613 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3613, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3615 lang.IFn; if linked_3614 == nil { ifn_3615 = lang.IFn_Cast(root_3613) } else { ifn_3615 = nil }; var arg_3616 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3614 == nil { b__78000453__6 = ifn_3615.Invoke_O__O(arg_3616) } else { b__78000453__6 = linked_3614.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3613, arg_3616) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__78000453__6); var tmp3 *jrt.Class; var fncls__3626 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_fn_class; if fncls__3626 == nil { var fncls__3626d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_fn_class = fncls__3626d; tmp3 = fncls__3626d } else { tmp3 = fncls__3626 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3635 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3635, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3637 lang.IFn; if linked_3636 == nil { ifn_3637 = lang.IFn_Cast(root_3635) } else { ifn_3637 = nil }; var arg_3638 any; var root_3627 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3627, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3629 lang.IFn; if linked_3628 == nil { ifn_3629 = lang.IFn_Cast(root_3627) } else { ifn_3629 = nil }; var arg_3630 any = b__78000453__6; if linked_3628 == nil { arg_3638 = ifn_3629.Invoke_O__O(arg_3630) } else { arg_3638 = linked_3628.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3627, arg_3630) }; var arg_3639 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000450); var tmp5 any; var root_3631 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3631, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3633 lang.IFn; if linked_3632 == nil { ifn_3633 = lang.IFn_Cast(root_3631) } else { ifn_3633 = nil }; var arg_3634 any = s__78000451__3; if linked_3632 == nil { tmp5 = ifn_3633.Invoke_O__O(arg_3634) } else { tmp5 = linked_3632.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3631, arg_3634) }; arg_3639 = tmp4.Invoke_O__O(tmp5); if linked_3636 == nil { return ifn_3637.Invoke_O_O__O(arg_3638, arg_3639) } else { return linked_3636.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3635, arg_3638, arg_3639) } } else { var root_3644 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3644, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3646 lang.IFn; if linked_3645 == nil { ifn_3646 = lang.IFn_Cast(root_3644) } else { ifn_3646 = nil }; var arg_3647 any; var root_3640 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3640, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3642 lang.IFn; if linked_3641 == nil { ifn_3642 = lang.IFn_Cast(root_3640) } else { ifn_3642 = nil }; var arg_3643 any = b__78000453__6; if linked_3641 == nil { arg_3647 = ifn_3642.Invoke_O__O(arg_3643) } else { arg_3647 = linked_3641.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3640, arg_3643) }; var arg_3648 any; if linked_3645 == nil { return ifn_3646.Invoke_O_O__O(arg_3647, arg_3648) } else { return linked_3645.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3644, arg_3647, arg_3648) } } } else { var vec__78000461__4 any; var root_3649 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3649, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3651 lang.IFn; if linked_3650 == nil { ifn_3651 = lang.IFn_Cast(root_3649) } else { ifn_3651 = nil }; var arg_3652 any = s__78000451__3; if linked_3650 == nil { vec__78000461__4 = ifn_3651.Invoke_O__O(arg_3652) } else { vec__78000461__4 = linked_3650.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3649, arg_3652) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000461__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000461__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3661 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3661, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3663 lang.IFn; if linked_3662 == nil { ifn_3663 = lang.IFn_Cast(root_3661) } else { ifn_3663 = nil }; var arg_3664 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil); var tmp7 any; var root_3653 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_3654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3653, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3655 lang.IFn; if linked_3654 == nil { ifn_3655 = lang.IFn_Cast(root_3653) } else { ifn_3655 = nil }; var arg_3656 any = k__5; if linked_3654 == nil { tmp7 = ifn_3655.Invoke_O__O(arg_3656) } else { tmp7 = linked_3654.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3653, arg_3656) }; arg_3664 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, v__6)).Ref(); var arg_3665 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000450); var tmp9 any; var root_3657 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3657, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3659 lang.IFn; if linked_3658 == nil { ifn_3659 = lang.IFn_Cast(root_3657) } else { ifn_3659 = nil }; var arg_3660 any = s__78000451__3; if linked_3658 == nil { tmp9 = ifn_3659.Invoke_O__O(arg_3660) } else { tmp9 = linked_3658.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3657, arg_3660) }; arg_3665 = tmp8.Invoke_O__O(tmp9); if linked_3662 == nil { return ifn_3663.Invoke_O_O__O(arg_3664, arg_3665) } else { return linked_3662.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3661, arg_3664, arg_3665) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :495:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__78000453 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__78000453 = c__b__78000453 }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A) Invoke_O__O(self any) any { { var i__78000452__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000452__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__78000457__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000452__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000457__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000457__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3621 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3621, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3623 lang.IFn; if linked_3622 == nil { ifn_3623 = lang.IFn_Cast(root_3621) } else { ifn_3623 = nil }; var arg_3624 any = t.F_b__78000453; var arg_3625 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil); var tmp3 any; var root_3617 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_3618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3617, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3619 lang.IFn; if linked_3618 == nil { ifn_3619 = lang.IFn_Cast(root_3617) } else { ifn_3619 = nil }; var arg_3620 any = k__3; if linked_3618 == nil { tmp3 = ifn_3619.Invoke_O__O(arg_3620) } else { tmp3 = linked_3618.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3617, arg_3620) }; arg_3625 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, v__4)).Ref(); if linked_3622 == nil { ifn_3623.Invoke_O_O__O(arg_3624, arg_3625) } else { linked_3622.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3621, arg_3624, arg_3625) }; i__78000452__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000452__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_world_load_world_iter__78000471__78000477_A_New() *A_arbace_j2g_world_load_world_iter__78000471__78000477_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_A) Ctor() {}
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_A) Invoke_O_O__O(self, s__78000472__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_New_O_O(s__78000472__1, self); var tmp2 *jrt.Class; var fncls__2410 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_fn_class; if fncls__2410 == nil { var fncls__2410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_fn_class = fncls__2410d; tmp2 = fncls__2410d } else { tmp2 = fncls__2410 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :500:1
func A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A{}; t.Ctor_O_O(p0, p1); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A) Ctor_O_O(c__s__78000472, c__iter__78000471 any) { t.F_s__78000472 = c__s__78000472; t.F_iter__78000471 = c__iter__78000471 }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A) Invoke_O__O(self any) any { { var s__78000472__1 any; var t_ any = t.F_s__78000472; t.F_s__78000472 = nil; s__78000472__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2293 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = s__78000472__1; if linked_2294 == nil { temp__1927000414__auto____2 = ifn_2295.Invoke_O__O(arg_2296) } else { temp__1927000414__auto____2 = linked_2294.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2293, arg_2296) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__78000479__4 any; var root_2297 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = xs__1927001018__auto____3; if linked_2298 == nil { map__78000479__4 = ifn_2299.Invoke_O__O(arg_2300) } else { map__78000479__4 = linked_2298.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2297, arg_2300) }; var map__78000479__5 any; if lang.ISeq_InstanceOf(map__78000479__4) { var tmp1 any; var root_2301 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = map__78000479__4; if linked_2302 == nil { tmp1 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp1 = linked_2302.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2301, arg_2304) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2305 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = map__78000479__4; if linked_2306 == nil { tmp2 = ifn_2307.Invoke_O__O(arg_2308) } else { tmp2 = linked_2306.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2305, arg_2308) }; map__78000479__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2309 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2311 lang.IFn; if linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any = map__78000479__4; if linked_2310 == nil { tmp3 = ifn_2311.Invoke_O__O(arg_2312) } else { tmp3 = linked_2310.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2309, arg_2312) }; if jrt.J2g_Truth(tmp3) { var root_2313 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2313, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any = map__78000479__4; if linked_2314 == nil { map__78000479__5 = ifn_2315.Invoke_O__O(arg_2316) } else { map__78000479__5 = linked_2314.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2313, arg_2316) } } else { map__78000479__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000479__5 = map__78000479__4 }; var file__6 any = lang.RT_Get_O_O__O_NoInit(map__78000479__5, A_arbace_j2g_world_A_const_168); var ns__7 any = lang.RT_Get_O_O__O_NoInit(map__78000479__5, A_arbace_j2g_world_A_const_143); var forms__8 any = lang.RT_Get_O_O__O_NoInit(map__78000479__5, A_arbace_j2g_world_A_const_50); if jrt.J2g_Truth(ns__7) { var iterys__1927001035__auto____9 any; var tmp4 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_New_O(file__6); var tmp5 *jrt.Class; var fncls__2383 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_fn_class; if fncls__2383 == nil { var fncls__2383d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_fn_class = fncls__2383d; tmp5 = fncls__2383d } else { tmp5 = fncls__2383 }; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____10 any; var root_2389 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____9); var tmp7 any; var root_2384 any = A_arbace_j2g_world_A_const_169.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, A_arbace_j2g_world_top_names_A_fn_class); var ifn_2386 lang.IFn
														if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = ns__7; var arg_2388 any = forms__8; if linked_2385 == nil { tmp7 = ifn_2386.Invoke_O_O__O(arg_2387, arg_2388) } else { tmp7 = linked_2385.(*A_arbace_j2g_world_top_names_A).Invoke_O_O_O__O(root_2384, arg_2387, arg_2388) }
//line :500:1
	arg_2392 = tmp6.Invoke_O__O(tmp7); if linked_2390 == nil { fs__1927001036__auto____10 = ifn_2391.Invoke_O__O(arg_2392) } else { fs__1927001036__auto____10 = linked_2390.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2389, arg_2392) }; if jrt.J2g_Truth(fs__1927001036__auto____10) { var root_2397 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2397, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2399 lang.IFn; if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = fs__1927001036__auto____10; var arg_2401 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000471); var tmp9 any; var root_2393 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = s__78000472__1; if linked_2394 == nil { tmp9 = ifn_2395.Invoke_O__O(arg_2396) } else { tmp9 = linked_2394.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2393, arg_2396) }; arg_2401 = tmp8.Invoke_O__O(tmp9); if linked_2398 == nil { return ifn_2399.Invoke_O_O__O(arg_2400, arg_2401) } else { return linked_2398.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2397, arg_2400, arg_2401) } } else { var tmp10 any; var root_2402 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2402, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2404 lang.IFn; if linked_2403 == nil { ifn_2404 = lang.IFn_Cast(root_2402) } else { ifn_2404 = nil }; var arg_2405 any = s__78000472__1; if linked_2403 == nil { tmp10 = ifn_2404.Invoke_O__O(arg_2405) } else { tmp10 = linked_2403.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2402, arg_2405) }; s__78000472__1 = tmp10; continue L1 } } else { var tmp11 any; var root_2406 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2406, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2408 lang.IFn; if linked_2407 == nil { ifn_2408 = lang.IFn_Cast(root_2406) } else { ifn_2408 = nil }; var arg_2409 any = s__78000472__1; if linked_2407 == nil { tmp11 = ifn_2408.Invoke_O__O(arg_2409) } else { tmp11 = linked_2407.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2406, arg_2409) }; s__78000472__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :500:1
func A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_New_O(p0 any) *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A{}; t.Ctor_O(p0); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A) Ctor_O(c__file any) { t.F_file = c__file }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A) Invoke_O_O__O(self, s__78000474__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_New_O_O_O(s__78000474__1, t.F_file, self); var tmp2 *jrt.Class; var fncls__2382 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_fn_class; if fncls__2382 == nil { var fncls__2382d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_fn_class = fncls__2382d; tmp2 = fncls__2382d } else { tmp2 = fncls__2382 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :500:1
func A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A) Ctor_O_O_O(c__s__78000474, c__file, c__iter__78000473 any) { t.F_s__78000474 = c__s__78000474; t.F_file = c__file; t.F_iter__78000473 = c__iter__78000473 }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A) Invoke_O__O(self any) any { { var s__78000474__1 any; var t_ any = t.F_s__78000474; t.F_s__78000474 = nil; s__78000474__1 = t_; for { var temp__1927000414__auto____2 any; var root_2317 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2317, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2319 lang.IFn; if linked_2318 == nil { ifn_2319 = lang.IFn_Cast(root_2317) } else { ifn_2319 = nil }; var arg_2320 any = s__78000474__1; if linked_2318 == nil { temp__1927000414__auto____2 = ifn_2319.Invoke_O__O(arg_2320) } else { temp__1927000414__auto____2 = linked_2318.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2317, arg_2320) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000474__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2321 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2323 lang.IFn; if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = s__78000474__3; if linked_2322 == nil { tmp1 = ifn_2323.Invoke_O__O(arg_2324) } else { tmp1 = linked_2322.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2321, arg_2324) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2325 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = s__78000474__3; if linked_2326 == nil { c__1927001037__auto____4 = ifn_2327.Invoke_O__O(arg_2328) } else { c__1927001037__auto____4 = linked_2326.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2325, arg_2328) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000476__6 any; var root_2329 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2330 == nil { b__78000476__6 = ifn_2331.Invoke_O__O(arg_2332) } else { b__78000476__6 = linked_2330.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2329, arg_2332) }; var tmp2 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_New_O_O_I_O(b__78000476__6, t.F_file, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2342 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_fn_class; if fncls__2342 == nil { var fncls__2342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_fn_class = fncls__2342d; tmp3 = fncls__2342d } else { tmp3 = fncls__2342 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2351 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_2352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2351, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2353 lang.IFn; if linked_2352 == nil { ifn_2353 = lang.IFn_Cast(root_2351) } else { ifn_2353 = nil }; var arg_2354 any; var root_2343 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = b__78000476__6; if linked_2344 == nil { arg_2354 = ifn_2345.Invoke_O__O(arg_2346) } else { arg_2354 = linked_2344.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2343, arg_2346) }; var arg_2355 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000473); var tmp5 any; var root_2347 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = s__78000474__3; if linked_2348 == nil { tmp5 = ifn_2349.Invoke_O__O(arg_2350) } else { tmp5 = linked_2348.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2347, arg_2350) }; arg_2355 = tmp4.Invoke_O__O(tmp5); if linked_2352 == nil { return ifn_2353.Invoke_O_O__O(arg_2354, arg_2355) } else { return linked_2352.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2351, arg_2354, arg_2355) } } else { var root_2360 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_2361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2360, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2362 lang.IFn; if linked_2361 == nil { ifn_2362 = lang.IFn_Cast(root_2360) } else { ifn_2362 = nil }; var arg_2363 any; var root_2356 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = b__78000476__6; if linked_2357 == nil { arg_2363 = ifn_2358.Invoke_O__O(arg_2359) } else { arg_2363 = linked_2357.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2356, arg_2359) }; var arg_2364 any; if linked_2361 == nil { return ifn_2362.Invoke_O_O__O(arg_2363, arg_2364) } else { return linked_2361.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2360, arg_2363, arg_2364) } } } else { var n__4 any; var root_2365 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = s__78000474__3; if linked_2366 == nil { n__4 = ifn_2367.Invoke_O__O(arg_2368) } else { n__4 = linked_2366.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2365, arg_2368) }; var root_2377 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_2378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2377, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2379 lang.IFn; if linked_2378 == nil { ifn_2379 = lang.IFn_Cast(root_2377) } else { ifn_2379 = nil }; var arg_2380 any; var tmp6 any; var root_2369 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2370 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2369, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2371 lang.IFn

	if linked_2370 == nil { ifn_2371 = lang.IFn_Cast(root_2369) } else { ifn_2371 = nil }; var arg_2372 any = t.F_file; if linked_2370 == nil { tmp6 = ifn_2371.Invoke_O__O(arg_2372) } else { tmp6 = linked_2370.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2369, arg_2372) }
//line :500:1
	arg_2380 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp6); var arg_2381 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000473); var tmp8 any; var root_2373 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2373, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2375 lang.IFn; if linked_2374 == nil { ifn_2375 = lang.IFn_Cast(root_2373) } else { ifn_2375 = nil }; var arg_2376 any = s__78000474__3; if linked_2374 == nil { tmp8 = ifn_2375.Invoke_O__O(arg_2376) } else { tmp8 = linked_2374.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2373, arg_2376) }; arg_2381 = tmp7.Invoke_O__O(tmp8); if linked_2378 == nil { return ifn_2379.Invoke_O_O__O(arg_2380, arg_2381) } else { return linked_2378.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2377, arg_2380, arg_2381) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :500:1
func A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A) Ctor_O_O_I_O(c__b__78000476, c__file any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000476 = c__b__78000476; t.F_file = c__file; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A) Invoke_O__O(self any) any { { var i__78000475__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000475__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000475__1)); var root_2337 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2337, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2339 lang.IFn; if linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any = t.F_b__78000476; var arg_2341 any; var tmp2 any; var root_2333 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2334 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2333, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2335 lang.IFn

	if linked_2334 == nil { ifn_2335 = lang.IFn_Cast(root_2333) } else { ifn_2335 = nil }; var arg_2336 any = t.F_file; if linked_2334 == nil { tmp2 = ifn_2335.Invoke_O__O(arg_2336) } else { tmp2 = linked_2334.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2333, arg_2336) }
//line :500:1
	arg_2341 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp2); if linked_2338 == nil { ifn_2339.Invoke_O_O__O(arg_2340, arg_2341) } else { linked_2338.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2337, arg_2340, arg_2341) }; i__78000475__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000475__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_world_with_world_A_New() *A_arbace_j2g_world_with_world_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_with_world_A{}; t.Ctor(); return t }
//line :505:1
func (t *A_arbace_j2g_world_with_world_A) Ctor() {}
//line :505:1
func (t *A_arbace_j2g_world_with_world_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, w__2, body__3 any) any { var root_4273 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4275 lang.IFn; if linked_4274 == nil { ifn_4275 = lang.IFn_Cast(root_4273) } else { ifn_4275 = nil }; var arg_4276 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_229); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp4 any; var root_4207 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_4208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4207, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_4209 lang.IFn; if linked_4208 == nil { ifn_4209 = lang.IFn_Cast(root_4207) } else { ifn_4209 = nil }; var arg_4210 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var arg_4211 any; var root_4203 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4205 lang.IFn; if linked_4204 == nil { ifn_4205 = lang.IFn_Cast(root_4203) } else { ifn_4205 = nil }; var arg_4206 any; var root_4198 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_4199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4198, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4200 lang.IFn; if linked_4199 == nil { ifn_4200 = lang.IFn_Cast(root_4198) } else { ifn_4200 = nil }; var arg_4201 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_230); var arg_4202 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(w__2); if linked_4199 == nil { arg_4206 = ifn_4200.Invoke_O_O__O(arg_4201, arg_4202) } else { arg_4206 = linked_4199.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4198, arg_4201, arg_4202) }; if linked_4204 == nil { arg_4211 = ifn_4205.Invoke_O__O(arg_4206) } else { arg_4211 = linked_4204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4203, arg_4206) }; if linked_4208 == nil { tmp4 = ifn_4209.Invoke_O_O__O(arg_4210, arg_4211) } else { tmp4 = linked_4208.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_4207, arg_4210, arg_4211) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp7 any; var root_4263 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4263, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4265 lang.IFn; if linked_4264 == nil { ifn_4265 = lang.IFn_Cast(root_4263) } else { ifn_4265 = nil }; var arg_4266 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_231); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp11 any; var root_4252 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_4253 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4252, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_4254 lang.IFn; if linked_4253 == nil { ifn_4254 = lang.IFn_Cast(root_4252) } else { ifn_4254 = nil }; var arg_4255 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var arg_4256 any; var root_4248 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4248, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4250 lang.IFn; if linked_4249 == nil { ifn_4250 = lang.IFn_Cast(root_4248) } else { ifn_4250 = nil }; var arg_4251 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_232); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp15 any; var root_4217 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4219 lang.IFn; if linked_4218 == nil { ifn_4219 = lang.IFn_Cast(root_4217) } else { ifn_4219 = nil }; var arg_4220 any; var root_4212 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_4213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4212, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4214 lang.IFn; if linked_4213 == nil { ifn_4214 = lang.IFn_Cast(root_4212) } else { ifn_4214 = nil }; var arg_4215 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_172); var arg_4216 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_230); if linked_4213 == nil { arg_4220 = ifn_4214.Invoke_O_O__O(arg_4215, arg_4216) } else { arg_4220 = linked_4213.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4212, arg_4215, arg_4216) }; if linked_4218 == nil { tmp15 = ifn_4219.Invoke_O__O(arg_4220) } else { tmp15 = linked_4218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4217, arg_4220) }; var tmp16 any = tmp14.Invoke_O__O(tmp15); var tmp17 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_233); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp19 any; var root_4226 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4228 lang.IFn; if linked_4227 == nil { ifn_4228 = lang.IFn_Cast(root_4226) } else { ifn_4228 = nil }; var arg_4229 any; var root_4221 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_4222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4221, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4223 lang.IFn; if linked_4222 == nil { ifn_4223 = lang.IFn_Cast(root_4221) } else { ifn_4223 = nil }; var arg_4224 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_173); var arg_4225 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_230); if linked_4222 == nil { arg_4229 = ifn_4223.Invoke_O_O__O(arg_4224, arg_4225) } else { arg_4229 = linked_4222.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4221, arg_4224, arg_4225) }; if linked_4227 == nil { tmp19 = ifn_4228.Invoke_O__O(arg_4229) } else { tmp19 = linked_4227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4226, arg_4229) }; var tmp20 any = tmp18.Invoke_O__O(tmp19); var tmp21 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_234); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp23 any; var root_4235 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4235, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4237 lang.IFn; if linked_4236 == nil { ifn_4237 = lang.IFn_Cast(root_4235) } else { ifn_4237 = nil }; var arg_4238 any; var root_4230 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_4231 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4230, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4232 lang.IFn; if linked_4231 == nil { ifn_4232 = lang.IFn_Cast(root_4230) } else { ifn_4232 = nil }; var arg_4233 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_174); var arg_4234 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_230); if linked_4231 == nil { arg_4238 = ifn_4232.Invoke_O_O__O(arg_4233, arg_4234) } else { arg_4238 = linked_4231.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4230, arg_4233, arg_4234) }; if linked_4236 == nil { tmp23 = ifn_4237.Invoke_O__O(arg_4238) } else { tmp23 = linked_4236.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4235, arg_4238) }; arg_4251 = tmp12.Invoke_O_O_O_O_O_O__O(tmp13, tmp16, tmp17, tmp20, tmp21, tmp22.Invoke_O__O(tmp23)); if linked_4249 == nil { arg_4256 = ifn_4250.Invoke_O__O(arg_4251) } else { arg_4256 = linked_4249.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4248, arg_4251) }; if linked_4253 == nil { tmp11 = ifn_4254.Invoke_O_O__O(arg_4255, arg_4256) } else { tmp11 = linked_4253.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_4252, arg_4255, arg_4256) }; arg_4266 = tmp8.Invoke_O_O_O__O(tmp9, tmp10.Invoke_O__O(tmp11), body__3); if linked_4264 == nil { tmp7 = ifn_4265.Invoke_O__O(arg_4266) } else { tmp7 = linked_4264.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4263, arg_4266) }; arg_4276 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_4274 == nil { return ifn_4275.Invoke_O__O(arg_4276) } else { return linked_4274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4273, arg_4276) } }





























































































































































































































































































































































type A_arbace_j2g_world_A struct{ jrt.Object }

var A_arbace_j2g_world_A_const_pool *jrt.RefArray

var A_arbace_j2g_world_A_const_0 *lang.Var

var A_arbace_j2g_world_A_const_1 any

var A_arbace_j2g_world_A_const_2 *lang.Var

var A_arbace_j2g_world_A_const_3 any

var A_arbace_j2g_world_A_const_4 any

var A_arbace_j2g_world_A_const_5 any

var A_arbace_j2g_world_A_const_6 any

var A_arbace_j2g_world_A_const_7 any

var A_arbace_j2g_world_A_const_8 any

var A_arbace_j2g_world_A_const_9 any

var A_arbace_j2g_world_A_const_10 any

var A_arbace_j2g_world_A_const_11 *lang.Var

var A_arbace_j2g_world_A_const_12 *lang.Var

var A_arbace_j2g_world_A_const_13 *lang.Var

var A_arbace_j2g_world_A_const_14 *lang.Var

var A_arbace_j2g_world_A_const_15 any

var A_arbace_j2g_world_A_const_16 *lang.Var

var A_arbace_j2g_world_A_const_17 *lang.Var

var A_arbace_j2g_world_A_const_18 *lang.Var

var A_arbace_j2g_world_A_const_19 *lang.Var

var A_arbace_j2g_world_A_const_20 *lang.Keyword

var A_arbace_j2g_world_A_const_21 *lang.Var

var A_arbace_j2g_world_A_const_22 *lang.Var

var A_arbace_j2g_world_A_const_23 any

var A_arbace_j2g_world_A_const_24 *lang.Var

var A_arbace_j2g_world_A_const_25 *lang.Var

var A_arbace_j2g_world_A_const_26 *lang.Var

var A_arbace_j2g_world_A_const_27 *lang.Var

var A_arbace_j2g_world_A_const_28 any

var A_arbace_j2g_world_A_const_29 *lang.Var

var A_arbace_j2g_world_A_const_30 *lang.Var

var A_arbace_j2g_world_A_const_31 *lang.Var

var A_arbace_j2g_world_A_const_32 *lang.Var

var A_arbace_j2g_world_A_const_33 *lang.Var

var A_arbace_j2g_world_A_const_34 *lang.Var

var A_arbace_j2g_world_A_const_35 *lang.Var

var A_arbace_j2g_world_A_const_36 *lang.Var

var A_arbace_j2g_world_A_const_37 *lang.Var

var A_arbace_j2g_world_A_const_38 *lang.Var

var A_arbace_j2g_world_A_const_39 *lang.Var

var A_arbace_j2g_world_A_const_40 *lang.Var

var A_arbace_j2g_world_A_const_41 *lang.Var

var A_arbace_j2g_world_A_const_42 *lang.Var

var A_arbace_j2g_world_A_const_43 *lang.Var

var A_arbace_j2g_world_A_const_44 any

var A_arbace_j2g_world_A_const_45 *lang.Var

var A_arbace_j2g_world_A_const_46 any

var A_arbace_j2g_world_A_const_47 *lang.Var

var A_arbace_j2g_world_A_const_48 *lang.Var

var A_arbace_j2g_world_A_const_49 *lang.Var

var A_arbace_j2g_world_A_const_50 *lang.Keyword

var A_arbace_j2g_world_A_const_51 *lang.Var

var A_arbace_j2g_world_A_const_52 *lang.Var

var A_arbace_j2g_world_A_const_53 any

var A_arbace_j2g_world_A_const_54 *lang.Var

var A_arbace_j2g_world_A_const_55 *lang.Var

var A_arbace_j2g_world_A_const_56 *lang.Var

var A_arbace_j2g_world_A_const_57 *lang.Var

var A_arbace_j2g_world_A_const_58 *lang.Var

var A_arbace_j2g_world_A_const_59 *lang.Var

var A_arbace_j2g_world_A_const_60 *lang.Var

var A_arbace_j2g_world_A_const_61 *lang.Keyword

var A_arbace_j2g_world_A_const_62 *lang.Var

var A_arbace_j2g_world_A_const_63 *lang.Var

var A_arbace_j2g_world_A_const_64 *lang.Var

var A_arbace_j2g_world_A_const_65 *lang.Var

var A_arbace_j2g_world_A_const_66 any

var A_arbace_j2g_world_A_const_67 *lang.Var

var A_arbace_j2g_world_A_const_68 *lang.Var

var A_arbace_j2g_world_A_const_69 *lang.Var

var A_arbace_j2g_world_A_const_70 *lang.Var

var A_arbace_j2g_world_A_const_71 *lang.Var

var A_arbace_j2g_world_A_const_72 *lang.Var

var A_arbace_j2g_world_A_const_73 *lang.Var

var A_arbace_j2g_world_A_const_74 *lang.Var

var A_arbace_j2g_world_A_const_75 *lang.Var

var A_arbace_j2g_world_A_const_76 *lang.Keyword

var A_arbace_j2g_world_A_const_77 *lang.Var

var A_arbace_j2g_world_A_const_78 *lang.Var

var A_arbace_j2g_world_A_const_79 *lang.Var

var A_arbace_j2g_world_A_const_80 *lang.Var

var A_arbace_j2g_world_A_const_81 *lang.Var

var A_arbace_j2g_world_A_const_82 *lang.Var

var A_arbace_j2g_world_A_const_83 *lang.Keyword

var A_arbace_j2g_world_A_const_84 *lang.Var

var A_arbace_j2g_world_A_const_85 *lang.Var

var A_arbace_j2g_world_A_const_86 *lang.Var

var A_arbace_j2g_world_A_const_87 *lang.Var

var A_arbace_j2g_world_A_const_88 *lang.Keyword

var A_arbace_j2g_world_A_const_89 *lang.Var

var A_arbace_j2g_world_A_const_90 *lang.Var

var A_arbace_j2g_world_A_const_91 *lang.Keyword

var A_arbace_j2g_world_A_const_92 *lang.Keyword

var A_arbace_j2g_world_A_const_93 *lang.Keyword

var A_arbace_j2g_world_A_const_94 *lang.Keyword

var A_arbace_j2g_world_A_const_95 *lang.Var

var A_arbace_j2g_world_A_const_96 *lang.Var

var A_arbace_j2g_world_A_const_97 *lang.Var

var A_arbace_j2g_world_A_const_98 any

var A_arbace_j2g_world_A_const_99 *lang.Var

var A_arbace_j2g_world_A_const_100 *lang.Var

var A_arbace_j2g_world_A_const_101 *lang.Var

var A_arbace_j2g_world_A_const_102 *lang.Keyword

var A_arbace_j2g_world_A_const_103 any

var A_arbace_j2g_world_A_const_104 *lang.Keyword

var A_arbace_j2g_world_A_const_105 *lang.Keyword

var A_arbace_j2g_world_A_const_106 *lang.Keyword

var A_arbace_j2g_world_A_const_107 *lang.Keyword

var A_arbace_j2g_world_A_const_108 *lang.Keyword

var A_arbace_j2g_world_A_const_109 *lang.Keyword

var A_arbace_j2g_world_A_const_110 *lang.Keyword

var A_arbace_j2g_world_A_const_111 any

var A_arbace_j2g_world_A_const_112 *lang.Var

var A_arbace_j2g_world_A_const_113 any

var A_arbace_j2g_world_A_const_114 *lang.Var

var A_arbace_j2g_world_A_const_115 *lang.Var

var A_arbace_j2g_world_A_const_116 any

var A_arbace_j2g_world_A_const_117 *lang.Var

var A_arbace_j2g_world_A_const_118 *lang.Var

var A_arbace_j2g_world_A_const_119 *lang.Var

var A_arbace_j2g_world_A_const_120 any

var A_arbace_j2g_world_A_const_121 *lang.Var

var A_arbace_j2g_world_A_const_122 *lang.Var

var A_arbace_j2g_world_A_const_123 *lang.Var

var A_arbace_j2g_world_A_const_124 *lang.Var

var A_arbace_j2g_world_A_const_125 *lang.Keyword

var A_arbace_j2g_world_A_const_126 *lang.Keyword

var A_arbace_j2g_world_A_const_127 *lang.Keyword

var A_arbace_j2g_world_A_const_128 *lang.Var

var A_arbace_j2g_world_A_const_129 *lang.Var

var A_arbace_j2g_world_A_const_130 *lang.Var

var A_arbace_j2g_world_A_const_131 *lang.Var

var A_arbace_j2g_world_A_const_132 *lang.Keyword

var A_arbace_j2g_world_A_const_133 *lang.Keyword

var A_arbace_j2g_world_A_const_134 *lang.Keyword

var A_arbace_j2g_world_A_const_135 *lang.Keyword

var A_arbace_j2g_world_A_const_136 *lang.Keyword

var A_arbace_j2g_world_A_const_137 *lang.Keyword

var A_arbace_j2g_world_A_const_138 *lang.Keyword

var A_arbace_j2g_world_A_const_139 *lang.Keyword

var A_arbace_j2g_world_A_const_140 *jrt.Class

var A_arbace_j2g_world_A_const_141 *lang.Keyword

var A_arbace_j2g_world_A_const_142 *lang.Var

var A_arbace_j2g_world_A_const_143 *lang.Keyword

var A_arbace_j2g_world_A_const_144 *lang.Keyword

var A_arbace_j2g_world_A_const_145 *lang.Keyword

var A_arbace_j2g_world_A_const_146 *lang.Keyword

var A_arbace_j2g_world_A_const_147 *lang.Keyword

var A_arbace_j2g_world_A_const_148 *lang.Keyword

var A_arbace_j2g_world_A_const_149 *lang.Keyword

var A_arbace_j2g_world_A_const_150 *lang.Var

var A_arbace_j2g_world_A_const_151 *lang.Var

var A_arbace_j2g_world_A_const_152 *lang.Var

var A_arbace_j2g_world_A_const_153 *lang.Var

var A_arbace_j2g_world_A_const_154 *lang.Var

var A_arbace_j2g_world_A_const_155 *lang.Var

var A_arbace_j2g_world_A_const_156 *lang.Var

var A_arbace_j2g_world_A_const_157 *lang.Keyword

var A_arbace_j2g_world_A_const_158 *lang.Keyword

var A_arbace_j2g_world_A_const_159 *lang.Var

var A_arbace_j2g_world_A_const_160 *lang.Var

var A_arbace_j2g_world_A_const_161 *lang.Var

var A_arbace_j2g_world_A_const_162 *lang.Keyword

var A_arbace_j2g_world_A_const_163 *lang.Keyword

var A_arbace_j2g_world_A_const_164 *lang.Keyword

var A_arbace_j2g_world_A_const_165 *lang.Var

var A_arbace_j2g_world_A_const_166 *lang.Var

var A_arbace_j2g_world_A_const_167 *lang.Var

var A_arbace_j2g_world_A_const_168 *lang.Keyword

var A_arbace_j2g_world_A_const_169 *lang.Var

var A_arbace_j2g_world_A_const_170 *lang.Var

var A_arbace_j2g_world_A_const_171 *lang.Var

var A_arbace_j2g_world_A_const_172 *lang.Keyword

var A_arbace_j2g_world_A_const_173 *lang.Keyword

var A_arbace_j2g_world_A_const_174 *lang.Keyword

var A_arbace_j2g_world_A_const_175 *lang.Keyword

var A_arbace_j2g_world_A_const_176 *lang.Keyword

var A_arbace_j2g_world_A_const_177 *lang.Keyword

var A_arbace_j2g_world_A_const_178 *lang.Var

var A_arbace_j2g_world_A_const_179 *lang.Keyword

var A_arbace_j2g_world_A_const_180 *lang.Keyword

var A_arbace_j2g_world_A_const_181 *lang.Var

var A_arbace_j2g_world_A_const_182 *lang.Var

var A_arbace_j2g_world_A_const_183 any

var A_arbace_j2g_world_A_const_184 any

var A_arbace_j2g_world_A_const_185 *lang.Var

var A_arbace_j2g_world_A_const_186 *lang.Keyword

var A_arbace_j2g_world_A_const_187 *lang.Keyword

var A_arbace_j2g_world_A_const_188 *lang.Keyword

var A_arbace_j2g_world_A_const_189 *lang.Keyword

var A_arbace_j2g_world_A_const_190 *lang.Var

var A_arbace_j2g_world_A_const_191 *lang.Var

var A_arbace_j2g_world_A_const_192 *lang.Keyword

var A_arbace_j2g_world_A_const_193 *lang.Var

var A_arbace_j2g_world_A_const_194 *lang.Keyword

var A_arbace_j2g_world_A_const_195 *lang.Var

var A_arbace_j2g_world_A_const_196 *lang.Var

var A_arbace_j2g_world_A_const_197 *lang.Var

var A_arbace_j2g_world_A_const_198 *lang.Var

var A_arbace_j2g_world_A_const_199 *lang.Keyword

var A_arbace_j2g_world_A_const_200 *lang.Keyword

var A_arbace_j2g_world_A_const_201 *lang.Keyword

var A_arbace_j2g_world_A_const_202 *lang.Var

var A_arbace_j2g_world_A_const_203 *lang.Var

var A_arbace_j2g_world_A_const_204 *lang.Keyword

var A_arbace_j2g_world_A_const_205 *lang.Keyword

var A_arbace_j2g_world_A_const_206 *lang.Var

var A_arbace_j2g_world_A_const_207 *lang.Var

var A_arbace_j2g_world_A_const_208 *lang.Var

var A_arbace_j2g_world_A_const_209 *lang.Var

var A_arbace_j2g_world_A_const_210 *lang.Var

var A_arbace_j2g_world_A_const_211 *lang.Keyword

var A_arbace_j2g_world_A_const_212 *lang.Var

var A_arbace_j2g_world_A_const_213 *lang.Var

var A_arbace_j2g_world_A_const_214 *lang.Var

var A_arbace_j2g_world_A_const_215 *lang.Keyword

var A_arbace_j2g_world_A_const_216 *lang.Keyword

var A_arbace_j2g_world_A_const_217 *lang.Var

var A_arbace_j2g_world_A_const_218 any

var A_arbace_j2g_world_A_const_219 *lang.Var

var A_arbace_j2g_world_A_const_220 any

var A_arbace_j2g_world_A_const_221 *lang.Var

var A_arbace_j2g_world_A_const_222 *lang.Var

var A_arbace_j2g_world_A_const_223 *lang.Var

var A_arbace_j2g_world_A_const_224 *lang.Var

var A_arbace_j2g_world_A_const_225 *lang.Keyword

var A_arbace_j2g_world_A_const_226 *lang.Keyword

var A_arbace_j2g_world_A_const_227 *lang.Var

var A_arbace_j2g_world_A_const_228 *lang.Var

var A_arbace_j2g_world_A_const_229 any

var A_arbace_j2g_world_A_const_230 any

var A_arbace_j2g_world_A_const_231 any

var A_arbace_j2g_world_A_const_232 any

var A_arbace_j2g_world_A_const_233 any

var A_arbace_j2g_world_A_const_234 any

var A_arbace_j2g_world_A_init jrt.ClassInit

func A_arbace_j2g_world_A_Init() { if !A_arbace_j2g_world_A_init.Done() { A_arbace_j2g_world_A_init.Run(A_arbace_j2g_world_A_clinit) } }

func A_arbace_j2g_world_A_clinit() { A_arbace_j2g_world_A_clinit_p0(); A_arbace_j2g_world_A_clinit_p1(); A_arbace_j2g_world_A_clinit_p2(); A_arbace_j2g_world_A_clinit_p3(); A_arbace_j2g_world_A_clinit_p4(); A_arbace_j2g_world_A_clinit_p5(); A_arbace_j2g_world_A_clinit_p6(); A_arbace_j2g_world_A_clinit_p7(); A_arbace_j2g_world_A_clinit_p8(); A_arbace_j2g_world_A_clinit_p9(); A_arbace_j2g_world_A_clinit_p10(); A_arbace_j2g_world_A_clinit_p11(); A_arbace_j2g_world_A_clinit_p12(); A_arbace_j2g_world_A_clinit_p13(); A_arbace_j2g_world_A_clinit_p14(); A_arbace_j2g_world_A_clinit_p15(); A_arbace_j2g_world_A_clinit_p16(); A_arbace_j2g_world_A_clinit_p17(); A_arbace_j2g_world_A_clinit_p18(); A_arbace_j2g_world_A_clinit_p19() }

func A_arbace_j2g_world_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_world_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 335); A_arbace_j2g_world_A_const_0 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[100]); A_arbace_j2g_world_A_const_1 = A_arbace_j2g_world_A_const_pool.A[101]; A_arbace_j2g_world_A_const_2 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[102]); A_arbace_j2g_world_A_const_3 = A_arbace_j2g_world_A_const_pool.A[103]; A_arbace_j2g_world_A_const_4 = A_arbace_j2g_world_A_const_pool.A[104]; A_arbace_j2g_world_A_const_5 = A_arbace_j2g_world_A_const_pool.A[105]; A_arbace_j2g_world_A_const_6 = A_arbace_j2g_world_A_const_pool.A[106]; A_arbace_j2g_world_A_const_7 = A_arbace_j2g_world_A_const_pool.A[107]; A_arbace_j2g_world_A_const_8 = A_arbace_j2g_world_A_const_pool.A[108]; A_arbace_j2g_world_A_const_9 = A_arbace_j2g_world_A_const_pool.A[109]; A_arbace_j2g_world_A_const_10 = A_arbace_j2g_world_A_const_pool.A[110]; A_arbace_j2g_world_A_const_11 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[111]); A_arbace_j2g_world_A_const_12 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[112]) }

func A_arbace_j2g_world_A_clinit_p1() { A_arbace_j2g_world_A_const_13 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[113]); A_arbace_j2g_world_A_const_14 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[114]); A_arbace_j2g_world_A_const_15 = A_arbace_j2g_world_A_const_pool.A[115]; A_arbace_j2g_world_A_const_16 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[116]); A_arbace_j2g_world_A_const_17 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[117]); A_arbace_j2g_world_A_const_18 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[118]); A_arbace_j2g_world_A_const_19 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[119]); A_arbace_j2g_world_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[120]); A_arbace_j2g_world_A_const_21 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[121]); A_arbace_j2g_world_A_const_22 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[122]); A_arbace_j2g_world_A_const_23 = A_arbace_j2g_world_A_const_pool.A[123]; A_arbace_j2g_world_A_const_24 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[124]) }

func A_arbace_j2g_world_A_clinit_p2() { A_arbace_j2g_world_A_const_25 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[125]); A_arbace_j2g_world_A_const_26 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[126]); A_arbace_j2g_world_A_const_27 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[127]); A_arbace_j2g_world_A_const_28 = A_arbace_j2g_world_A_const_pool.A[128]; A_arbace_j2g_world_A_const_29 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[129]); A_arbace_j2g_world_A_const_30 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[130]); A_arbace_j2g_world_A_const_31 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[131]); A_arbace_j2g_world_A_const_32 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[132]); A_arbace_j2g_world_A_const_33 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[133]); A_arbace_j2g_world_A_const_34 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[134]); A_arbace_j2g_world_A_const_35 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[135]); A_arbace_j2g_world_A_const_36 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[136]) }

func A_arbace_j2g_world_A_clinit_p3() { A_arbace_j2g_world_A_const_37 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[137]); A_arbace_j2g_world_A_const_38 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[138]); A_arbace_j2g_world_A_const_39 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[139]); A_arbace_j2g_world_A_const_40 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[140]); A_arbace_j2g_world_A_const_41 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[141]); A_arbace_j2g_world_A_const_42 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[142]); A_arbace_j2g_world_A_const_43 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[143]); A_arbace_j2g_world_A_const_44 = A_arbace_j2g_world_A_const_pool.A[144]; A_arbace_j2g_world_A_const_45 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[145]); A_arbace_j2g_world_A_const_46 = A_arbace_j2g_world_A_const_pool.A[146]; A_arbace_j2g_world_A_const_47 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[147]); A_arbace_j2g_world_A_const_48 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[148]) }

func A_arbace_j2g_world_A_clinit_p4() { A_arbace_j2g_world_A_const_49 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[149]); A_arbace_j2g_world_A_const_50 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[150]); A_arbace_j2g_world_A_const_51 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[151]); A_arbace_j2g_world_A_const_52 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[152]); A_arbace_j2g_world_A_const_53 = A_arbace_j2g_world_A_const_pool.A[153]; A_arbace_j2g_world_A_const_54 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[154]); A_arbace_j2g_world_A_const_55 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[155]); A_arbace_j2g_world_A_const_56 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[156]); A_arbace_j2g_world_A_const_57 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[157]); A_arbace_j2g_world_A_const_58 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[158]); A_arbace_j2g_world_A_const_59 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[159]); A_arbace_j2g_world_A_const_60 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[160]) }

func A_arbace_j2g_world_A_clinit_p5() { A_arbace_j2g_world_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[161]); A_arbace_j2g_world_A_const_62 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[162]); A_arbace_j2g_world_A_const_63 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[163]); A_arbace_j2g_world_A_const_64 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[164]); A_arbace_j2g_world_A_const_65 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[165]); A_arbace_j2g_world_A_const_66 = A_arbace_j2g_world_A_const_pool.A[166]; A_arbace_j2g_world_A_const_67 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[167]); A_arbace_j2g_world_A_const_68 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[168]); A_arbace_j2g_world_A_const_69 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[169]); A_arbace_j2g_world_A_const_70 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[170]); A_arbace_j2g_world_A_const_71 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[171]); A_arbace_j2g_world_A_const_72 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[172]) }

func A_arbace_j2g_world_A_clinit_p6() { A_arbace_j2g_world_A_const_73 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[173]); A_arbace_j2g_world_A_const_74 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[174]); A_arbace_j2g_world_A_const_75 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[175]); A_arbace_j2g_world_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[176]); A_arbace_j2g_world_A_const_77 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[177]); A_arbace_j2g_world_A_const_78 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[178]); A_arbace_j2g_world_A_const_79 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[179]); A_arbace_j2g_world_A_const_80 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[180]); A_arbace_j2g_world_A_const_81 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[181]); A_arbace_j2g_world_A_const_82 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[182]); A_arbace_j2g_world_A_const_83 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[183]); A_arbace_j2g_world_A_const_84 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[184]) }

func A_arbace_j2g_world_A_clinit_p7() { A_arbace_j2g_world_A_const_85 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[185]); A_arbace_j2g_world_A_const_86 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[186]); A_arbace_j2g_world_A_const_87 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[187]); A_arbace_j2g_world_A_const_88 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[188]); A_arbace_j2g_world_A_const_89 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[189]); A_arbace_j2g_world_A_const_90 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[190]); A_arbace_j2g_world_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[191]); A_arbace_j2g_world_A_const_92 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[192]); A_arbace_j2g_world_A_const_93 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[193]); A_arbace_j2g_world_A_const_94 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[194]); A_arbace_j2g_world_A_const_95 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[195]); A_arbace_j2g_world_A_const_96 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[196]) }

func A_arbace_j2g_world_A_clinit_p8() { A_arbace_j2g_world_A_const_97 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[197]); A_arbace_j2g_world_A_const_98 = A_arbace_j2g_world_A_const_pool.A[198]; A_arbace_j2g_world_A_const_99 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[199]); A_arbace_j2g_world_A_const_100 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[200]); A_arbace_j2g_world_A_const_101 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[201]); A_arbace_j2g_world_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[202]); A_arbace_j2g_world_A_const_103 = A_arbace_j2g_world_A_const_pool.A[203]; A_arbace_j2g_world_A_const_104 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[204]); A_arbace_j2g_world_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[205]); A_arbace_j2g_world_A_const_106 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[206]); A_arbace_j2g_world_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[207]); A_arbace_j2g_world_A_const_108 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[208]) }

func A_arbace_j2g_world_A_clinit_p9() { A_arbace_j2g_world_A_const_109 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[209]); A_arbace_j2g_world_A_const_110 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[210]); A_arbace_j2g_world_A_const_111 = A_arbace_j2g_world_A_const_pool.A[211]; A_arbace_j2g_world_A_const_112 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[212]); A_arbace_j2g_world_A_const_113 = A_arbace_j2g_world_A_const_pool.A[213]; A_arbace_j2g_world_A_const_114 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[214]); A_arbace_j2g_world_A_const_115 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[215]); A_arbace_j2g_world_A_const_116 = A_arbace_j2g_world_A_const_pool.A[216]; A_arbace_j2g_world_A_const_117 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[217]); A_arbace_j2g_world_A_const_118 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[218]); A_arbace_j2g_world_A_const_119 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[219]); A_arbace_j2g_world_A_const_120 = A_arbace_j2g_world_A_const_pool.A[220]; A_arbace_j2g_world_A_const_121 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[221]) }

func A_arbace_j2g_world_A_clinit_p10() { A_arbace_j2g_world_A_const_122 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[222]); A_arbace_j2g_world_A_const_123 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[223]); A_arbace_j2g_world_A_const_124 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[224]); A_arbace_j2g_world_A_const_125 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[225]); A_arbace_j2g_world_A_const_126 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[226]); A_arbace_j2g_world_A_const_127 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[227]); A_arbace_j2g_world_A_const_128 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[228]); A_arbace_j2g_world_A_const_129 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[229]); A_arbace_j2g_world_A_const_130 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[230]); A_arbace_j2g_world_A_const_131 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[231]); A_arbace_j2g_world_A_const_132 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[232]); A_arbace_j2g_world_A_const_133 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[233]) }

func A_arbace_j2g_world_A_clinit_p11() { A_arbace_j2g_world_A_const_134 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[234]); A_arbace_j2g_world_A_const_135 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[235]); A_arbace_j2g_world_A_const_136 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[236]); A_arbace_j2g_world_A_const_137 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[237]); A_arbace_j2g_world_A_const_138 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[238]); A_arbace_j2g_world_A_const_139 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[239]); A_arbace_j2g_world_A_const_140 = jrt.Class_Cast(A_arbace_j2g_world_A_const_pool.A[240]); A_arbace_j2g_world_A_const_141 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[241]); A_arbace_j2g_world_A_const_142 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[242]); A_arbace_j2g_world_A_const_143 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[243]); A_arbace_j2g_world_A_const_144 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[244]); A_arbace_j2g_world_A_const_145 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[245]) }

func A_arbace_j2g_world_A_clinit_p12() { A_arbace_j2g_world_A_const_146 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[246]); A_arbace_j2g_world_A_const_147 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[247]); A_arbace_j2g_world_A_const_148 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[248]); A_arbace_j2g_world_A_const_149 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[249]); A_arbace_j2g_world_A_const_150 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[250]); A_arbace_j2g_world_A_const_151 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[251]); A_arbace_j2g_world_A_const_152 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[252]); A_arbace_j2g_world_A_const_153 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[253]); A_arbace_j2g_world_A_const_154 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[254]); A_arbace_j2g_world_A_const_155 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[255]); A_arbace_j2g_world_A_const_156 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[256]); A_arbace_j2g_world_A_const_157 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[257]) }

func A_arbace_j2g_world_A_clinit_p13() { A_arbace_j2g_world_A_const_158 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[258]); A_arbace_j2g_world_A_const_159 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[259]); A_arbace_j2g_world_A_const_160 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[260]); A_arbace_j2g_world_A_const_161 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[261]); A_arbace_j2g_world_A_const_162 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[262]); A_arbace_j2g_world_A_const_163 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[263]); A_arbace_j2g_world_A_const_164 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[264]); A_arbace_j2g_world_A_const_165 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[265]); A_arbace_j2g_world_A_const_166 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[266]); A_arbace_j2g_world_A_const_167 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[267]); A_arbace_j2g_world_A_const_168 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[268]); A_arbace_j2g_world_A_const_169 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[269]) }

func A_arbace_j2g_world_A_clinit_p14() { A_arbace_j2g_world_A_const_170 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[270]); A_arbace_j2g_world_A_const_171 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[271]); A_arbace_j2g_world_A_const_172 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[272]); A_arbace_j2g_world_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[273]); A_arbace_j2g_world_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[274]); A_arbace_j2g_world_A_const_175 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[275]); A_arbace_j2g_world_A_const_176 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[276]); A_arbace_j2g_world_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[277]); A_arbace_j2g_world_A_const_178 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[278]); A_arbace_j2g_world_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[279]); A_arbace_j2g_world_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[280]); A_arbace_j2g_world_A_const_181 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[281]) }

func A_arbace_j2g_world_A_clinit_p15() { A_arbace_j2g_world_A_const_182 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[282]); A_arbace_j2g_world_A_const_183 = A_arbace_j2g_world_A_const_pool.A[283]; A_arbace_j2g_world_A_const_184 = A_arbace_j2g_world_A_const_pool.A[284]; A_arbace_j2g_world_A_const_185 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[285]); A_arbace_j2g_world_A_const_186 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[286]); A_arbace_j2g_world_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[287]); A_arbace_j2g_world_A_const_188 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[288]); A_arbace_j2g_world_A_const_189 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[289]); A_arbace_j2g_world_A_const_190 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[290]); A_arbace_j2g_world_A_const_191 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[291]); A_arbace_j2g_world_A_const_192 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[292]); A_arbace_j2g_world_A_const_193 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[293]) }

func A_arbace_j2g_world_A_clinit_p16() { A_arbace_j2g_world_A_const_194 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[294]); A_arbace_j2g_world_A_const_195 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[295]); A_arbace_j2g_world_A_const_196 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[296]); A_arbace_j2g_world_A_const_197 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[297]); A_arbace_j2g_world_A_const_198 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[298]); A_arbace_j2g_world_A_const_199 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[299]); A_arbace_j2g_world_A_const_200 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[300]); A_arbace_j2g_world_A_const_201 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[301]); A_arbace_j2g_world_A_const_202 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[302]); A_arbace_j2g_world_A_const_203 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[303]); A_arbace_j2g_world_A_const_204 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[304]); A_arbace_j2g_world_A_const_205 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[305]) }

func A_arbace_j2g_world_A_clinit_p17() { A_arbace_j2g_world_A_const_206 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[306]); A_arbace_j2g_world_A_const_207 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[307]); A_arbace_j2g_world_A_const_208 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[308]); A_arbace_j2g_world_A_const_209 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[309]); A_arbace_j2g_world_A_const_210 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[310]); A_arbace_j2g_world_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[311]); A_arbace_j2g_world_A_const_212 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[312]); A_arbace_j2g_world_A_const_213 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[313]); A_arbace_j2g_world_A_const_214 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[314]); A_arbace_j2g_world_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[315]); A_arbace_j2g_world_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[316]); A_arbace_j2g_world_A_const_217 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[317]) }

func A_arbace_j2g_world_A_clinit_p18() { A_arbace_j2g_world_A_const_218 = A_arbace_j2g_world_A_const_pool.A[318]; A_arbace_j2g_world_A_const_219 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[319]); A_arbace_j2g_world_A_const_220 = A_arbace_j2g_world_A_const_pool.A[320]; A_arbace_j2g_world_A_const_221 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[321]); A_arbace_j2g_world_A_const_222 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[322]); A_arbace_j2g_world_A_const_223 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[323]); A_arbace_j2g_world_A_const_224 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[324]); A_arbace_j2g_world_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[325]); A_arbace_j2g_world_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[326]); A_arbace_j2g_world_A_const_227 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[327]); A_arbace_j2g_world_A_const_228 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[328]); A_arbace_j2g_world_A_const_229 = A_arbace_j2g_world_A_const_pool.A[329]; A_arbace_j2g_world_A_const_230 = A_arbace_j2g_world_A_const_pool.A[330] }

func A_arbace_j2g_world_A_clinit_p19() { A_arbace_j2g_world_A_const_231 = A_arbace_j2g_world_A_const_pool.A[331]; A_arbace_j2g_world_A_const_232 = A_arbace_j2g_world_A_const_pool.A[332]; A_arbace_j2g_world_A_const_233 = A_arbace_j2g_world_A_const_pool.A[333]; A_arbace_j2g_world_A_const_234 = A_arbace_j2g_world_A_const_pool.A[334] }

func A_arbace_j2g_world_A_New() *A_arbace_j2g_world_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_world_A) Ctor() {}

func (t *A_arbace_j2g_world_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_world_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_world_A_class }

func (t *A_arbace_j2g_world_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_world_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_world_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_world_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_world_A); return ok }

func A_arbace_j2g_world_A_Cast(x any) *A_arbace_j2g_world_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_world_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_world_A_class)) }; return v }



type A_arbace_j2g_world_apply_variant_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_apply_variant_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000173_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_world_apply_variant_fn__78000173_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000175_A struct{ j2g_header uint64; F_counts any }

var A_arbace_j2g_world_apply_variant_fn__78000175_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000184_A struct{ j2g_header uint64; F_variants_of, F_prefix, F_applied any }

var A_arbace_j2g_world_apply_variant_fn__78000184_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_form_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_forms_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A struct{ j2g_header uint64; F_s__78000021, F_iter__78000020 any }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A struct{ j2g_header uint64; F_s__78000023, F_iter__78000022 any }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A struct{ j2g_header uint64; F_b__78000025 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_parts_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_parts_A_fn_class *jrt.Class



type A_arbace_j2g_world_continued_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_world_continued_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_world_cut_key_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_cut_key_A_fn_class *jrt.Class



type A_arbace_j2g_world_eval78000004_A struct{ jrt.Object }

func A_arbace_j2g_world_eval78000004_A_New() *A_arbace_j2g_world_eval78000004_A { t := &A_arbace_j2g_world_eval78000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_world_eval78000004_A) Ctor() {}

func (t *A_arbace_j2g_world_eval78000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_world_eval78000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_world_eval78000004_A_class }

func (t *A_arbace_j2g_world_eval78000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_world_eval78000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_world_eval78000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_world_eval78000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_world_eval78000004_A); return ok }

func A_arbace_j2g_world_eval78000004_A_Cast(x any) *A_arbace_j2g_world_eval78000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_world_eval78000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_world_eval78000004_A_class)) }; return v }



type A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A_fn_class *jrt.Class



type A_arbace_j2g_world_eval78000008_A struct{ jrt.Object }

func A_arbace_j2g_world_eval78000008_A_New() *A_arbace_j2g_world_eval78000008_A { t := &A_arbace_j2g_world_eval78000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_world_eval78000008_A) Ctor() {}

func (t *A_arbace_j2g_world_eval78000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_world_eval78000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_world_eval78000008_A_class }

func (t *A_arbace_j2g_world_eval78000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_world_eval78000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_world_eval78000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_world_eval78000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_world_eval78000008_A); return ok }

func A_arbace_j2g_world_eval78000008_A_Cast(x any) *A_arbace_j2g_world_eval78000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_world_eval78000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_world_eval78000008_A_class)) }; return v }



type A_arbace_j2g_world_eval78000008_fn__78000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_eval78000008_fn__78000009_A_fn_class *jrt.Class



type A_arbace_j2g_world_first_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_first_form_A_fn_class *jrt.Class



type A_arbace_j2g_world_head_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_head_name_A_fn_class *jrt.Class



type A_arbace_j2g_world_id_space_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_id_space_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_join_continued_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_A struct{ j2g_header uint64; F_claimed, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A struct{ j2g_header uint64; F_claimed, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A struct{ j2g_header uint64; F_claimed, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A struct{ j2g_header uint64; F_s__78000060, F_claimed, F_iter__78000059, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A struct{ j2g_header uint64; F_claimed, F_b__78000062 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A struct{ j2g_header uint64; F_c any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A struct{ j2g_header uint64; F_c any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A struct{ j2g_header uint64; F_s__78000040, F_iter__78000039 any }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A struct{ j2g_header uint64; F_s__78000042, F_iter__78000041 any }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__78000044, F_c__1927001037__auto__ any }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_fn_class *jrt.Class



type A_arbace_j2g_world_levels_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_levels_A_fn_class *jrt.Class



type A_arbace_j2g_world_levels_lvl__78000211_A struct{ j2g_header uint64; F_in, F_deps, F_memo any }

var A_arbace_j2g_world_levels_lvl__78000211_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_A struct{ j2g_header uint64; F_parsed, F_variants, F_parse, F_failed, F_top_set, F_wait, F_tops, F_unit, F_applied, F_late_inputs any }

var A_arbace_j2g_world_load_world_fn__78000245_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A struct{ j2g_header uint64; F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A struct{ j2g_header uint64; F_variants, F_failed, F_applied any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A struct{ j2g_header uint64; F_nsobj, F_file, F_ns any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A struct{ j2g_header uint64; F_nsobj, F_file, F_s__78000258, F_iter__78000257, F_ns any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A struct{ j2g_header uint64; F_nsobj, F_file, F_b__78000260 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_ns any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A struct{ j2g_header uint64; F_variants, F_applied any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A struct{ j2g_header uint64; F_variants any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A struct{ j2g_header uint64; F_pc any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A struct{ j2g_header uint64; F_nsobj, F_pc, F_failed, F_members, F_file any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A struct{ j2g_header uint64; F_nsobj, F_pc, F_members, F_failed, F_file any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A struct{ j2g_header uint64; F_rt_order, F_analyze_BANG_, F_unit, F_rt_start, F_names1 any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A struct{ j2g_header uint64; F_analyze_BANG_, F_names1 any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A struct{ j2g_header uint64; F_space, F_prev any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A struct{ j2g_header uint64; F_space, F_analyze_BANG_, F_unit any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A struct{ j2g_header uint64; F_g, F_space, F_order, F_analyze_BANG_, F_unit any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A struct{ j2g_header uint64; F_space, F_analyze_BANG_, F_unit any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A struct{ j2g_header uint64; F_g, F_space, F_order, F_analyze_BANG_, F_unit any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A struct{ j2g_header uint64; F_heights any }

var A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A struct{ j2g_header uint64; F_tops_QMARK_, F_height any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A struct{ j2g_header uint64; F_iter__78000339, F_tops_QMARK_, F_height, F_s__78000340 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A struct{ j2g_header uint64; F_tops_QMARK_, F_height any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__78000342 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A struct{ j2g_header uint64; F_tops_QMARK_, F_height any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A struct{ j2g_header uint64; F_iter__78000349, F_tops_QMARK_, F_height, F_s__78000350 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A struct{ j2g_header uint64; F_tops_QMARK_, F_height any; F_size__1927001038__auto__ int32; F_b__78000352, F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A struct{ j2g_header uint64; F_tops_QMARK_, F_levels any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A struct{ j2g_header uint64; F_iter__78000359, F_tops_QMARK_, F_s__78000360, F_levels any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A struct{ j2g_header uint64; F_tops_QMARK_, F_levels any; F_size__1927001038__auto__ int32; F_b__78000362, F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A struct{ j2g_header uint64; F_tops_QMARK_ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A struct{ j2g_header uint64; F_tops_QMARK_, F_s__78000367, F_iter__78000366 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A struct{ j2g_header uint64; F_b__78000369, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A struct{ j2g_header uint64; F_tops_QMARK_ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A struct{ j2g_header uint64; F_tops_QMARK_, F_s__78000377, F_iter__78000376 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A struct{ j2g_header uint64; F_b__78000379, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A struct{ j2g_header uint64; F_tops_QMARK_ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A struct{ j2g_header uint64; F_tops_QMARK_, F_s__78000388, F_iter__78000387 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A struct{ j2g_header uint64; F_tops_QMARK_, F_b__78000390 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A struct{ j2g_header uint64; F_tops_QMARK_ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A struct{ j2g_header uint64; F_tops_QMARK_, F_s__78000398, F_iter__78000397 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A struct{ j2g_header uint64; F_b__78000400, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A struct{ j2g_header uint64; F_s__78000451, F_iter__78000450 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__78000453 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A struct{ j2g_header uint64; F_t, F_laps any }

var A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A struct{ j2g_header uint64; F_failed, F_lap any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A struct{ j2g_header uint64; F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A struct{ j2g_header uint64; F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A struct{ j2g_header uint64; F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A struct{ j2g_header uint64; F_n, F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A struct{ j2g_header uint64; F_n, F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_from_source__78000243_A struct{ j2g_header uint64; F_tops, F_top_of any }

var A_arbace_j2g_world_load_world_from_source__78000243_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A struct{ j2g_header uint64; F_s__78000472, F_iter__78000471 any }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A struct{ j2g_header uint64; F_file any }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A struct{ j2g_header uint64; F_s__78000474, F_file, F_iter__78000473 any }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A struct{ j2g_header uint64; F_b__78000476, F_file any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_parse__78000228_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_parse__78000228_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_top_of__78000241_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_top_of__78000241_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_top_set__78000234_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_top_set__78000234_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_fn_class *jrt.Class



type A_arbace_j2g_world_new_unit_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_new_unit_A_fn_class *jrt.Class



type A_arbace_j2g_world_ns_of_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_ns_of_forms_A_fn_class *jrt.Class



type A_arbace_j2g_world_ns_of_forms_fn__78000085_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_ns_of_forms_fn__78000085_A_fn_class *jrt.Class



type A_arbace_j2g_world_par_levels_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_par_levels_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_param_key_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000138_A struct{ j2g_header uint64; F_more any }

var A_arbace_j2g_world_param_key_fn__78000138_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000140_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_param_key_fn__78000140_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000146_A struct{ j2g_header uint64; F_more any }

var A_arbace_j2g_world_param_key_fn__78000146_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000148_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_param_key_fn__78000148_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000151_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_world_param_key_fn__78000151_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_param_key_fn__78000153_A_fn_class *jrt.Class



type A_arbace_j2g_world_parse_member_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_parse_member_classes_A_fn_class *jrt.Class



type A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A struct{ j2g_header uint64; F_pc any }

var A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_fn_class *jrt.Class



type A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A struct{ j2g_header uint64; F_pc, F_s__78000201, F_iter__78000200 any }

var A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_fn_class *jrt.Class



type A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A struct{ j2g_header uint64; F_b__78000203, F_pc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_read_forms_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_forms_fn__78000013_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_read_forms_fn__78000013_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_forms_fn__78000015_A struct{ j2g_header uint64; F_r any }

var A_arbace_j2g_world_read_forms_fn__78000015_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_variants_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_read_variants_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_variants_fn__78000190_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_read_variants_fn__78000190_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A struct{ j2g_header uint64; F_nsname any }

var A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_source_files_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_fn__78000110_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_source_files_fn__78000110_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_fn__78000112_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_source_files_fn__78000112_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_A struct{ j2g_header uint64; F_root any }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A struct{ j2g_header uint64; F_s__78000115, F_iter__78000114, F_root any }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A struct{ j2g_header uint64; F_s__78000117, F_iter__78000116 any }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A struct{ j2g_header uint64; F_b__78000119 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_fn_class *jrt.Class



type A_arbace_j2g_world_supers_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_supers_of_A_fn_class *jrt.Class



type A_arbace_j2g_world_top_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_top_names_A_fn_class *jrt.Class



type A_arbace_j2g_world_top_names_iter__78000088__78000092_A struct{ j2g_header uint64; F_nsname any }

var A_arbace_j2g_world_top_names_iter__78000088__78000092_A_fn_class *jrt.Class



type A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A struct{ j2g_header uint64; F_nsname, F_s__78000089, F_iter__78000088 any }

var A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_fn_class *jrt.Class



type A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A struct{ j2g_header uint64; F_nsname, F_b__78000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_fn_class *jrt.Class



type A_arbace_j2g_world_with_world_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_with_world_A_fn_class *jrt.Class
