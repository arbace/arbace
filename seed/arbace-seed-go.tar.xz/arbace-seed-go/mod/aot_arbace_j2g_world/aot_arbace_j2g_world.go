//line aot_arbace_j2g_world.ae:1
package aot_arbace_j2g_world

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_parse"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A_New() *A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_world_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_1); lang.IFn_Cast(A_arbace_j2g_world_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_world_A_const_3, A_arbace_j2g_world_A_const_4, A_arbace_j2g_world_A_const_5, A_arbace_j2g_world_A_const_6, A_arbace_j2g_world_A_const_7, A_arbace_j2g_world_A_const_8, A_arbace_j2g_world_A_const_9, A_arbace_j2g_world_A_const_10); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_world_eval78000008_fn__78000009_A_New() *A_arbace_j2g_world_eval78000008_fn__78000009_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_eval78000008_fn__78000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_world_eval78000008_fn__78000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_world_eval78000008_fn__78000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_world_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_world_A_const_14.GetRawRoot__O(), A_arbace_j2g_world_A_const_15) }















func A_arbace_j2g_world_read_forms_A_New() *A_arbace_j2g_world_read_forms_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_forms_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_world_read_forms_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_world_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_j2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_58 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_world_A_const_27, jrt.Boolean_FALSE.Ref()); if linked_59 == nil { ifn_60.Invoke_O__O(arg_61) } else { linked_59.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_58, arg_61) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_30 any = A_arbace_j2g_world_A_const_17.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var root_34 any = A_arbace_j2g_world_A_const_18.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var tmp2 any = A_arbace_j2g_world_read_forms_fn__78000013_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_j2g_world_read_forms_fn__78000013_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_j2g_world_read_forms_fn__78000013_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; arg_37 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_38 any; var root_45 any = A_arbace_j2g_world_A_const_21.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any; var tmp4 any = A_arbace_j2g_world_read_forms_fn__78000015_A_New_O(r__2); var tmp5 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_j2g_world_read_forms_fn__78000015_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_j2g_world_read_forms_fn__78000015_A_fn_class = fncls__54d; tmp5 = fncls__54d } else { tmp5 = fncls__54 }; arg_48 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_46 == nil { arg_38 = ifn_47.Invoke_O__O(arg_48) } else { arg_38 = linked_46.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O__O(root_45, arg_48) }; if linked_35 == nil { arg_33 = ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { arg_33 = linked_35.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_34, arg_37, arg_38) }; if linked_31 == nil { tmp1 = ifn_32.Invoke_O__O(arg_33) } else { tmp1 = linked_31.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_30, arg_33) } }
//line :19:1
		return nil }(); var root_55 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; if linked_56 == nil { ifn_57.Invoke__O() } else { linked_56.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_55) }
//line :17:1
		if tmp6 != nil { panic(tmp6) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :17:1*/ tmp7 != nil { panic(tmp7) }; return tmp1 }


func A_arbace_j2g_world_read_forms_fn__78000013_A_New() *A_arbace_j2g_world_read_forms_fn__78000013_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_forms_fn__78000013_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_j2g_world_read_forms_fn__78000013_A) Ctor() {}
//line :20:1
func (t *A_arbace_j2g_world_read_forms_fn__78000013_A) Invoke_O_O__O(self, p1__78000012_SHARP___1 any) any { var root_39 any = A_arbace_j2g_world_A_const_19.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = p1__78000012_SHARP___1; var arg_43 any = A_arbace_j2g_world_A_const_20; if linked_40 == nil { return ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { return linked_40.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_39, arg_42, arg_43) } }
//line :20:1
func A_arbace_j2g_world_read_forms_fn__78000015_A_New_O(p0 any) *A_arbace_j2g_world_read_forms_fn__78000015_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_forms_fn__78000015_A{}; t.Ctor_O(p0); return t }
//line :20:1
func (t *A_arbace_j2g_world_read_forms_fn__78000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :20:1
func (t *A_arbace_j2g_world_read_forms_fn__78000015_A) Invoke_O__O(self any) any { var root_49 any = A_arbace_j2g_world_A_const_22.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = A_arbace_j2g_world_A_const_23; var arg_53 any = t.F_r; if linked_50 == nil { return ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { return linked_50.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_49, arg_52, arg_53) } }

func A_arbace_j2g_world_first_form_A_New() *A_arbace_j2g_world_first_form_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_first_form_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_j2g_world_first_form_A) Ctor() {}
//line :22:1
func (t *A_arbace_j2g_world_first_form_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_j2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var root_79 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_world_A_const_27, jrt.Boolean_FALSE.Ref()); if linked_80 == nil { ifn_81.Invoke_O__O(arg_82) } else { linked_80.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_79, arg_82) }; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :22:1
		{ var x__7 any; var root_71 any = A_arbace_j2g_world_A_const_22.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_73 lang.IFn




			if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_j2g_world_A_const_28; var arg_75 any = r__2; if linked_72 == nil { x__7 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { x__7 = linked_72.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }
			if lang.Util_Equiv_O_O__Z_NoInit(x__7, A_arbace_j2g_world_A_const_20) { tmp1 = nil } else { tmp1 = x__7 } }
//line :26:1
		return nil }(); var root_76 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; if linked_77 == nil { ifn_78.Invoke__O() } else { linked_77.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_76) }
//line :22:1
		if tmp2 != nil { panic(tmp2) } }; return nil }();


	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :22:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }







func A_arbace_j2g_world_class_form_QMARK__A_New() *A_arbace_j2g_world_class_form_QMARK__A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_form_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_j2g_world_class_form_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_j2g_world_class_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any; var root_88 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = f__0; if linked_89 == nil { and__1927000168__auto____2 = ifn_90.Invoke_O__O(arg_91) } else { and__1927000168__auto____2 = linked_89.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_88, arg_91) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_92 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var root_96 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = f__0; if linked_97 == nil { arg_95 = ifn_98.Invoke_O__O(arg_99) } else { arg_95 = linked_97.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_96, arg_99) }; if linked_93 == nil { and__1927000168__auto____3 = ifn_94.Invoke_O__O(arg_95) } else { and__1927000168__auto____3 = linked_93.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_92, arg_95) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any; var root_100 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any; var root_104 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = f__0; if linked_105 == nil { arg_103 = ifn_106.Invoke_O__O(arg_107) } else { arg_103 = linked_105.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_104, arg_107) }; if linked_101 == nil { tmp1 = ifn_102.Invoke_O__O(arg_103) } else { tmp1 = linked_101.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_100, arg_103) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_12, tmp1)).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_world_class_forms_A_New() *A_arbace_j2g_world_class_forms_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_j2g_world_class_forms_A) Ctor() {}
//line :32:1
func (t *A_arbace_j2g_world_class_forms_A) Invoke_O_O__O(self, forms__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_New(); var tmp2 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_fn_class; if
											fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_fn_class = fncls__217d; tmp2 = fncls__217d } else { tmp2 = fncls__217 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0) }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_New() *A_arbace_j2g_world_class_forms_iter__78000020__78000026_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_A) Ctor() {}
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_A) Invoke_O_O__O(self, s__78000021__1 any) any { var tmp1 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_New_O_O(s__78000021__1, self); var tmp2 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_fn_class = fncls__216d; tmp2 = fncls__216d } else { tmp2 = fncls__216 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A) Ctor_O_O(c__s__78000021, c__iter__78000020 any) { t.F_s__78000021 = c__s__78000021; t.F_iter__78000020 = c__iter__78000020 }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A) Invoke_O__O(self any) any { { var s__78000021__1 any; var t_ any = t.F_s__78000021; t.F_s__78000021 = nil; s__78000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_108 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = s__78000021__1; if linked_109 == nil { temp__1927000414__auto____2 = ifn_110.Invoke_O__O(arg_111) } else { temp__1927000414__auto____2 = linked_109.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_108, arg_111) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_112 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = xs__1927001018__auto____3; if linked_113 == nil { f__4 = ifn_114.Invoke_O__O(arg_115) } else { f__4 = linked_113.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_112, arg_115) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_New(); var tmp2 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_fn_class = fncls__186d; tmp2 = fncls__186d } else { tmp2 = fncls__186 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_187 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var tmp5 any; var and__1927000168__auto____6 any; var root_191 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_193 lang.IFn
														if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = f__4; if linked_192 == nil { and__1927000168__auto____6 = ifn_193.Invoke_O__O(arg_194) } else { and__1927000168__auto____6 = linked_192.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_191, arg_194) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp6 any = A_arbace_j2g_world_A_const_44; var tmp7 any; var root_195 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = f__4; if linked_196 == nil { tmp7 = ifn_197.Invoke_O__O(arg_198) } else { tmp7 = linked_196.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_195, arg_198) }; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7)).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { var root_199 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = f__4; if linked_200 == nil { tmp4 = ifn_201.Invoke_O__O(arg_202) } else { tmp4 = linked_200.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_199, arg_202) } } else { tmp4 = lang.Tuple_Create_O__IPersistentVector(f__4) }
//line :33:1
	arg_190 = tmp3.Invoke_O__O(tmp4); if linked_188 == nil { fs__1927001036__auto____6 = ifn_189.Invoke_O__O(arg_190) } else { fs__1927001036__auto____6 = linked_188.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_187, arg_190) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_203 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = fs__1927001036__auto____6; var arg_207 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000020); var tmp9 any; var root_208 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = s__78000021__1; if linked_209 == nil { tmp9 = ifn_210.Invoke_O__O(arg_211) } else { tmp9 = linked_209.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_208, arg_211) }; arg_207 = tmp8.Invoke_O__O(tmp9); if linked_204 == nil { return ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { return linked_204.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) } } else { var tmp10 any; var root_212 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = s__78000021__1; if linked_213 == nil { tmp10 = ifn_214.Invoke_O__O(arg_215) } else { tmp10 = linked_213.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_212, arg_215) }; s__78000021__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_New() *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A) Ctor() {}
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A) Invoke_O_O__O(self, s__78000023__1 any) any { var tmp1 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_New_O_O(s__78000023__1, self); var tmp2 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_fn_class; if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_fn_class = fncls__185d; tmp2 = fncls__185d } else { tmp2 = fncls__185 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A) Ctor_O_O(c__s__78000023, c__iter__78000022 any) { t.F_s__78000023 = c__s__78000023; t.F_iter__78000022 = c__iter__78000022 }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A) Invoke_O__O(self any) any { { var s__78000023__1 any; var t_ any = t.F_s__78000023; t.F_s__78000023 = nil; s__78000023__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_116 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = s__78000023__1; if linked_117 == nil { temp__1927000414__auto____2 = ifn_118.Invoke_O__O(arg_119) } else { temp__1927000414__auto____2 = linked_117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000023__3 any = temp__1927000414__auto____2; var tmp1 any; var root_120 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__78000023__3; if linked_121 == nil { tmp1 = ifn_122.Invoke_O__O(arg_123) } else { tmp1 = linked_121.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_120, arg_123) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_124 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__78000023__3; if linked_125 == nil { c__1927001037__auto____4 = ifn_126.Invoke_O__O(arg_127) } else { c__1927001037__auto____4 = linked_125.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_124, arg_127) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000025__6 any; var root_128 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_129 == nil { b__78000025__6 = ifn_130.Invoke_O__O(arg_131) } else { b__78000025__6 = linked_129.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_128, arg_131) }; var tmp2 any = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_New_O_I_O(b__78000025__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_142 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_147 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = b__78000025__6; if linked_148 == nil { arg_145 = ifn_149.Invoke_O__O(arg_150) } else { arg_145 = linked_148.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_147, arg_150) }; var arg_146 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000022); var tmp5 any; var root_151 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__78000023__3; if linked_152 == nil { tmp5 = ifn_153.Invoke_O__O(arg_154) } else { tmp5 = linked_152.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_151, arg_154) }; arg_146 = tmp4.Invoke_O__O(tmp5); if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } } else { var root_155 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var root_160 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = b__78000025__6; if linked_161 == nil { arg_158 = ifn_162.Invoke_O__O(arg_163) } else { arg_158 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_160, arg_163) }; var arg_159 any; if linked_156 == nil { return ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { return linked_156.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_155, arg_158, arg_159) } } } else { var f__4 any; var root_164 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = s__78000023__3; if linked_165 == nil { f__4 = ifn_166.Invoke_O__O(arg_167) } else { f__4 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; var tmp6 any; var root_168 any = A_arbace_j2g_world_A_const_37.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_j2g_world_class_form_QMARK__A_fn_class); var ifn_170 lang.IFn

	if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = f__4; if linked_169 == nil { tmp6 = ifn_170.Invoke_O__O(arg_171) } else { tmp6 = linked_169.(*A_arbace_j2g_world_class_form_QMARK__A).Invoke_O_O__O(root_168, arg_171) }
//line :33:1
	if jrt.J2g_Truth(tmp6) { var root_172 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = f__4; var arg_176 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000022); var tmp8 any; var root_177 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = s__78000023__3; if linked_178 == nil { tmp8 = ifn_179.Invoke_O__O(arg_180) } else { tmp8 = linked_178.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_177, arg_180) }; arg_176 = tmp7.Invoke_O__O(tmp8); if linked_173 == nil { return ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { return linked_173.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) } } else { var tmp9 any; var root_181 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = s__78000023__3; if linked_182 == nil { tmp9 = ifn_183.Invoke_O__O(arg_184) } else { tmp9 = linked_182.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_181, arg_184) }; s__78000023__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :33:1
func A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A) Ctor_O_I_O(c__b__78000025 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000025 = c__b__78000025; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :33:1
func (t *A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A) Invoke_O__O(self any) any { { var i__78000024__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000024__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000024__1)); var tmp2 any; var root_132 any = A_arbace_j2g_world_A_const_37.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_j2g_world_class_form_QMARK__A_fn_class); var ifn_134 lang.IFn

	if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__2; if linked_133 == nil { tmp2 = ifn_134.Invoke_O__O(arg_135) } else { tmp2 = linked_133.(*A_arbace_j2g_world_class_form_QMARK__A).Invoke_O_O__O(root_132, arg_135) }
//line :33:1
	if jrt.J2g_Truth(tmp2) { var root_136 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t.F_b__78000025; var arg_140 any = f__2; if linked_137 == nil { ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { linked_137.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; i__78000024__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000024__1); continue L1 } else { i__78000024__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000024__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_world_continued_QMARK__A_New() *A_arbace_j2g_world_continued_QMARK__A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_continued_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_j2g_world_continued_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_j2g_world_continued_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any; var root_218 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = f__0; if linked_219 == nil { and__1927000168__auto____2 = ifn_220.Invoke_O__O(arg_221) } else { and__1927000168__auto____2 = linked_219.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_218, arg_221) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_j2g_world_A_const_46; var tmp2 any; var root_222 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = f__0; if linked_223 == nil { tmp2 = ifn_224.Invoke_O__O(arg_225) } else { tmp2 = linked_223.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_222, arg_225) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_world_join_continued_A_New() *A_arbace_j2g_world_join_continued_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_j2g_world_join_continued_A) Ctor() {}
//line :40:1
func (t *A_arbace_j2g_world_join_continued_A) Invoke_O_O__O(self, ps__0 any) any { var conts__2 any; var root_226 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_228 lang.IFn; if








	linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_230 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_New(); var tmp2 *jrt.Class; var fncls__362 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_fn_class; if fncls__362 == nil { var fncls__362d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_fn_class = fncls__362d; tmp2 = fncls__362d } else { tmp2 = fncls__362 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_230 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ps__0); if linked_227 == nil { conts__2 = ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { conts__2 = linked_227.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_226, arg_229, arg_230) }; var tmp3 any; var root_363 any =

	A_arbace_j2g_world_A_const_55.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = conts__2; if linked_364 == nil { tmp3 = ifn_365.Invoke_O__O(arg_366) } else { tmp3 = linked_364.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_363, arg_366) }; if jrt.J2g_Truth(tmp3) { return ps__0 } else { var claimed__3 any; var root_367 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_369 lang.IFn

		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_368 == nil { claimed__3 = ifn_369.Invoke_O__O(arg_370) } else { claimed__3 = linked_368.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_367, arg_370) }
//line :51:1
		var ps__4 any; var root_371 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_373 lang.IFn


		if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var tmp4 any = A_arbace_j2g_world_join_continued_fn__78000057_A_New_O_O(claimed__3, conts__2); var tmp5 *jrt.Class; var fncls__732 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_A_fn_class; if fncls__732 == nil { var fncls__732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_world_join_continued_fn__78000057_A_fn_class = fncls__732d; tmp5 = fncls__732d } else { tmp5 = fncls__732 }; arg_374 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_375 any = ps__0; if linked_372 == nil { ps__4 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { ps__4 = linked_372.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }
//line :51:1
		var temp__1927000414__auto____5 any; var root_733 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_735 lang.IFn

















		if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any; var root_737 any = A_arbace_j2g_world_A_const_77.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any; var root_742 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = claimed__3; if linked_743 == nil { arg_740 = ifn_744.Invoke_O__O(arg_745) } else { arg_740 = linked_743.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_742, arg_745) }; var arg_741 any; var root_746 any = A_arbace_j2g_world_A_const_78.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = conts__2; if linked_747 == nil { arg_741 = ifn_748.Invoke_O__O(arg_749) } else { arg_741 = linked_747.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_746, arg_749) }; if linked_738 == nil { arg_736 = ifn_739.Invoke_O_O__O(arg_740, arg_741) } else { arg_736 = linked_738.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_737, arg_740, arg_741) }; if linked_734 == nil { temp__1927000414__auto____5 = ifn_735.Invoke_O__O(arg_736) } else { temp__1927000414__auto____5 = linked_734.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_733, arg_736) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var u__6 any = temp__1927000414__auto____5; var tmp6 any; var root_750 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_752 lang.IFn
			if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_79.GetRawRoot__O()); var tmp9 any; var root_759 any = A_arbace_j2g_world_A_const_80.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = u__6; if linked_760 == nil { tmp9 = ifn_761.Invoke_O__O(arg_762) } else { tmp9 = linked_760.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_759, arg_762) }; arg_753 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))).Ref(); var arg_754 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_751 == nil { tmp6 = ifn_752.Invoke_O_O__O(arg_753, arg_754) } else { tmp6 = linked_751.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_750, arg_753, arg_754) }
//line :69:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) }
//line :51:1
		return ps__4 } }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_New() *A_arbace_j2g_world_join_continued_iter__78000039__78000045_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_A) Invoke_O_O__O(self, s__78000040__1 any) any { var tmp1 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_New_O_O(s__78000040__1, self); var tmp2 *jrt.Class; var fncls__361 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_fn_class; if fncls__361 == nil { var fncls__361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_fn_class = fncls__361d; tmp2 = fncls__361d } else { tmp2 = fncls__361 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A) Ctor_O_O(c__s__78000040, c__iter__78000039 any) { t.F_s__78000040 = c__s__78000040; t.F_iter__78000039 = c__iter__78000039 }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A) Invoke_O__O(self any) any { { var s__78000040__1 any; var t_ any = t.F_s__78000040; t.F_s__78000040 = nil; s__78000040__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_231 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = s__78000040__1; if linked_232 == nil { temp__1927000414__auto____2 = ifn_233.Invoke_O__O(arg_234) } else { temp__1927000414__auto____2 = linked_232.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_231, arg_234) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__78000047__4 any; var root_235 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = xs__1927001018__auto____3; if linked_236 == nil { map__78000047__4 = ifn_237.Invoke_O__O(arg_238) } else { map__78000047__4 = linked_236.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_235, arg_238) }; var map__78000047__5 any; if lang.ISeq_InstanceOf(map__78000047__4) { var tmp1 any; var root_239 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = map__78000047__4; if linked_240 == nil { tmp1 = ifn_241.Invoke_O__O(arg_242) } else { tmp1 = linked_240.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_239, arg_242) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_243 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = map__78000047__4; if linked_244 == nil { tmp2 = ifn_245.Invoke_O__O(arg_246) } else { tmp2 = linked_244.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_243, arg_246) }; map__78000047__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_247 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = map__78000047__4; if linked_248 == nil { tmp3 = ifn_249.Invoke_O__O(arg_250) } else { tmp3 = linked_248.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_247, arg_250) }; if jrt.J2g_Truth(tmp3) { var root_251 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = map__78000047__4; if linked_252 == nil { map__78000047__5 = ifn_253.Invoke_O__O(arg_254) } else { map__78000047__5 = linked_252.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_251, arg_254) } } else { map__78000047__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000047__5 = map__78000047__4 }; var forms__6 any = lang.RT_Get_O_O__O_NoInit(map__78000047__5, A_arbace_j2g_world_A_const_50); var iterys__1927001035__auto____7 any; var tmp4 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_New(); var tmp5 *jrt.Class; var fncls__343 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_fn_class; if fncls__343 == nil { var fncls__343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_fn_class = fncls__343d; tmp5 = fncls__343d } else { tmp5 = fncls__343 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____8 any; var root_344 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(forms__6); if linked_345 == nil { fs__1927001036__auto____8 = ifn_346.Invoke_O__O(arg_347) } else { fs__1927001036__auto____8 = linked_345.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_344, arg_347) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_348 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = fs__1927001036__auto____8; var arg_352 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__78000039); var tmp7 any; var root_353 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = s__78000040__1; if linked_354 == nil { tmp7 = ifn_355.Invoke_O__O(arg_356) } else { tmp7 = linked_354.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_353, arg_356) }; arg_352 = tmp6.Invoke_O__O(tmp7); if linked_349 == nil { return ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { return linked_349.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) } } else { var tmp8 any; var root_357 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = s__78000040__1; if linked_358 == nil { tmp8 = ifn_359.Invoke_O__O(arg_360) } else { tmp8 = linked_358.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_357, arg_360) }; s__78000040__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_New() *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A) Invoke_O_O__O(self, s__78000042__1 any) any { var tmp1 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_New_O_O(s__78000042__1, self); var tmp2 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_fn_class; if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_fn_class = fncls__342d; tmp2 = fncls__342d } else { tmp2 = fncls__342 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A{}; t.Ctor_O_O(p0, p1); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A) Ctor_O_O(c__s__78000042, c__iter__78000041 any) { t.F_s__78000042 = c__s__78000042; t.F_iter__78000041 = c__iter__78000041 }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A) Invoke_O__O(self any) any { { var s__78000042__1 any; var t_ any = t.F_s__78000042; t.F_s__78000042 = nil; s__78000042__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_255 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = s__78000042__1; if linked_256 == nil { temp__1927000414__auto____2 = ifn_257.Invoke_O__O(arg_258) } else { temp__1927000414__auto____2 = linked_256.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_255, arg_258) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000042__3 any = temp__1927000414__auto____2; var tmp1 any; var root_259 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = s__78000042__3; if linked_260 == nil { tmp1 = ifn_261.Invoke_O__O(arg_262) } else { tmp1 = linked_260.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_259, arg_262) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_263 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = s__78000042__3; if linked_264 == nil { c__1927001037__auto____4 = ifn_265.Invoke_O__O(arg_266) } else { c__1927001037__auto____4 = linked_264.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_263, arg_266) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000044__6 any; var root_267 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_268 == nil { b__78000044__6 = ifn_269.Invoke_O__O(arg_270) } else { b__78000044__6 = linked_268.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_267, arg_270) }; var tmp2 any = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_New_I_O_O(size__1927001038__auto____5, b__78000044__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__289 *jrt.Class = A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_fn_class; if fncls__289 == nil { var fncls__289d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_fn_class = fncls__289d; tmp3 = fncls__289d } else { tmp3 = fncls__289 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_290 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any; var root_295 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = b__78000044__6; if linked_296 == nil { arg_293 = ifn_297.Invoke_O__O(arg_298) } else { arg_293 = linked_296.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_295, arg_298) }; var arg_294 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000041); var tmp5 any; var root_299 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = s__78000042__3; if linked_300 == nil { tmp5 = ifn_301.Invoke_O__O(arg_302) } else { tmp5 = linked_300.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_299, arg_302) }; arg_294 = tmp4.Invoke_O__O(tmp5); if linked_291 == nil { return ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { return linked_291.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) } } else { var root_303 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var root_308 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = b__78000044__6; if linked_309 == nil { arg_306 = ifn_310.Invoke_O__O(arg_311) } else { arg_306 = linked_309.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_308, arg_311) }; var arg_307 any; if linked_304 == nil { return ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { return linked_304.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } } } else { var f__4 any; var root_312 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = s__78000042__3; if linked_313 == nil { f__4 = ifn_314.Invoke_O__O(arg_315) } else { f__4 = linked_313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_312, arg_315) }; var tmp6 any; var root_316 any = A_arbace_j2g_world_A_const_51.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, A_arbace_j2g_world_continued_QMARK__A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = f__4; if linked_317 == nil { tmp6 = ifn_318.Invoke_O__O(arg_319) } else { tmp6 = linked_317.(*A_arbace_j2g_world_continued_QMARK__A).Invoke_O_O__O(root_316, arg_319) }; if jrt.J2g_Truth(tmp6) { var root_320 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any; var tmp7 any; var root_330 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_332 lang.IFn
																			if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = lang.RT_Nth_O_I__O_NoInit(f__4, lang.RT_IntCast_J__I_NoInit(1)); if linked_331 == nil { tmp7 = ifn_332.Invoke_O__O(arg_333) } else { tmp7 = linked_331.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_330, arg_333) }
//line :49:1
	var tmp8 any = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.RT_Nth_O_I__O_NoInit(f__4, lang.RT_IntCast_J__I_NoInit(2))); var tmp9 any; var root_325 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_325, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_327 lang.IFn
	if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_329 any = f__4; if linked_326 == nil { tmp9 = ifn_327.Invoke_O_O__O(A_arbace_j2g_world_A_const_53, arg_329) } else { tmp9 = linked_326.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_325, 3, A_arbace_j2g_world_A_const_53, arg_329) }
//line :49:1
	arg_323 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); var arg_324 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__78000041); var tmp11 any; var root_334 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = s__78000042__3; if linked_335 == nil { tmp11 = ifn_336.Invoke_O__O(arg_337) } else { tmp11 = linked_335.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_334, arg_337) }; arg_324 = tmp10.Invoke_O__O(tmp11); if linked_321 == nil { return ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { return linked_321.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } } else { var tmp12 any; var root_338 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = s__78000042__3; if linked_339 == nil { tmp12 = ifn_340.Invoke_O__O(arg_341) } else { tmp12 = linked_339.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_338, arg_341) }; s__78000042__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :49:1
func A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__78000044, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__78000044 = c__b__78000044; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :49:1
func (t *A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A) Invoke_O__O(self any) any { { var i__78000043__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000043__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000043__1)); var tmp2 any; var root_271 any = A_arbace_j2g_world_A_const_51.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_j2g_world_continued_QMARK__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = f__2; if linked_272 == nil { tmp2 = ifn_273.Invoke_O__O(arg_274) } else { tmp2 = linked_272.(*A_arbace_j2g_world_continued_QMARK__A).Invoke_O_O__O(root_271, arg_274) }; if jrt.J2g_Truth(tmp2) { var root_275 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = t.F_b__78000044; var arg_279 any; var tmp3 any; var root_285 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_287 lang.IFn
																					if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = lang.RT_Nth_O_I__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_286 == nil { tmp3 = ifn_287.Invoke_O__O(arg_288) } else { tmp3 = linked_286.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_285, arg_288) }
//line :49:1
	var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.RT_Nth_O_I__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(2))); var tmp5 any; var root_280 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_280, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_282 lang.IFn
	if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_284 any = f__2; if linked_281 == nil { tmp5 = ifn_282.Invoke_O_O__O(A_arbace_j2g_world_A_const_53, arg_284) } else { tmp5 = linked_281.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_280, 3, A_arbace_j2g_world_A_const_53, arg_284) }
//line :49:1
	arg_279 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5); if linked_276 == nil { ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { linked_276.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) }; i__78000043__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000043__1); continue L1 } else { i__78000043__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000043__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_world_join_continued_fn__78000057_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_fn__78000057_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :54:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :54:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_A) Invoke_O_O__O(self, p__1 any) any {
	var root_376 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = p__1; var arg_380 any = A_arbace_j2g_world_A_const_50; var arg_381 any; var tmp1 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_New_O_O(t.F_claimed, t.F_conts); var tmp2 *jrt.Class; var fncls__731 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_fn_class
	if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_fn_class = fncls__731d; tmp2 = fncls__731d } else { tmp2 = fncls__731 }; arg_381 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :55:1
	if linked_377 == nil { return ifn_378.Invoke_O_O_O__O(arg_379, arg_380, arg_381) } else { return linked_377.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_376, arg_379, arg_380, arg_381) } }
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A{}; t.Ctor_O_O(p0, p1); return t }
//line :56:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :56:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A) Invoke_O_O__O(self, forms__1 any) any {
	var root_382 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_New_O_O(t.F_claimed, t.F_conts); var tmp2 *jrt.Class; var fncls__730 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_fn_class; if fncls__730 == nil { var fncls__730d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_fn_class = fncls__730d; tmp2 = fncls__730d } else { tmp2 = fncls__730 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_385 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__1); if linked_383 == nil { return ifn_384.Invoke_O__O(arg_385) } else { return linked_383.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_382, arg_385) } }
//line :57:1
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A) Invoke_O_O__O(self, s__78000060__1 any) any { var tmp1 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_New_O_O_O_O(s__78000060__1, t.F_claimed, self, t.F_conts); var tmp2 *jrt.Class; var fncls__729 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_fn_class; if fncls__729 == nil { var fncls__729d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_fn_class = fncls__729d; tmp2 = fncls__729d } else { tmp2 = fncls__729 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :57:1
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A) Ctor_O_O_O_O(c__s__78000060, c__claimed, c__iter__78000059, c__conts any) { t.F_s__78000060 = c__s__78000060; t.F_claimed = c__claimed; t.F_iter__78000059 = c__iter__78000059; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A) Invoke_O__O(self any) any { { var s__78000060__1 any; var t_ any = t.F_s__78000060; t.F_s__78000060 = nil; s__78000060__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_386 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = s__78000060__1; if linked_387 == nil { temp__1927000414__auto____2 = ifn_388.Invoke_O__O(arg_389) } else { temp__1927000414__auto____2 = linked_387.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_386, arg_389) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000060__3 any = temp__1927000414__auto____2; var tmp1 any; var root_390 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = s__78000060__3; if linked_391 == nil { tmp1 = ifn_392.Invoke_O__O(arg_393) } else { tmp1 = linked_391.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_390, arg_393) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_394 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = s__78000060__3; if linked_395 == nil { c__1927001037__auto____4 = ifn_396.Invoke_O__O(arg_397) } else { c__1927001037__auto____4 = linked_395.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_394, arg_397) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000062__6 any; var root_398 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_399 == nil { b__78000062__6 = ifn_400.Invoke_O__O(arg_401) } else { b__78000062__6 = linked_399.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_398, arg_401) }; var tmp2 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_New_O_O_I_O_O(t.F_claimed, b__78000062__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_conts); var tmp3 *jrt.Class; var fncls__548 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_fn_class; if fncls__548 == nil { var fncls__548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_fn_class = fncls__548d; tmp3 = fncls__548d } else { tmp3 = fncls__548 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_549 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any; var root_554 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = b__78000062__6; if linked_555 == nil { arg_552 = ifn_556.Invoke_O__O(arg_557) } else { arg_552 = linked_555.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_554, arg_557) }; var arg_553 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000059); var tmp5 any; var root_558 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = s__78000060__3; if linked_559 == nil { tmp5 = ifn_560.Invoke_O__O(arg_561) } else { tmp5 = linked_559.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_558, arg_561) }; arg_553 = tmp4.Invoke_O__O(tmp5); if linked_550 == nil { return ifn_551.Invoke_O_O__O(arg_552, arg_553) } else { return linked_550.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_549, arg_552, arg_553) } } else { var root_562 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any; var root_567 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = b__78000062__6; if linked_568 == nil { arg_565 = ifn_569.Invoke_O__O(arg_570) } else { arg_565 = linked_568.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_567, arg_570) }; var arg_566 any; if linked_563 == nil { return ifn_564.Invoke_O_O__O(arg_565, arg_566) } else { return linked_563.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_562, arg_565, arg_566) } } } else { var f__4 any; var root_571 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = s__78000060__3; if linked_572 == nil { f__4 = ifn_573.Invoke_O__O(arg_574) } else { f__4 = linked_572.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_571, arg_574) }; var tmp6 any; var root_575 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var root_579 any = A_arbace_j2g_world_A_const_51.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, A_arbace_j2g_world_continued_QMARK__A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = f__4; if linked_580 == nil { arg_578 = ifn_581.Invoke_O__O(arg_582) } else { arg_578 = linked_580.(*A_arbace_j2g_world_continued_QMARK__A).Invoke_O_O__O(root_579, arg_582) }; if linked_576 == nil { tmp6 = ifn_577.Invoke_O__O(arg_578) } else { tmp6 = linked_576.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_575, arg_578) }; if jrt.J2g_Truth(tmp6) { var root_583 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any; var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any; var root_588 any = A_arbace_j2g_world_A_const_37.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, A_arbace_j2g_world_class_form_QMARK__A_fn_class); var ifn_590 lang.IFn
																	if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = f__4; if linked_589 == nil { and__1927000168__auto____5 = ifn_590.Invoke_O__O(arg_591) } else { and__1927000168__auto____5 = linked_589.(*A_arbace_j2g_world_class_form_QMARK__A).Invoke_O_O__O(root_588, arg_591) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 *lang.Keyword = A_arbace_j2g_world_A_const_61; temp__1927000408__auto____5 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__4)) } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5; var c__7 any; var root_592 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_594 lang.IFn
																		if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any; var root_596 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = f__4; if linked_597 == nil { arg_595 = ifn_598.Invoke_O__O(arg_599) } else { arg_595 = linked_597.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_596, arg_599) }; if linked_593 == nil { c__7 = ifn_594.Invoke_O__O(arg_595) } else { c__7 = linked_593.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_592, arg_595) }
//line :58:1
		var ks__8 any; var root_600 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_602 lang.IFn

		if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any; var tmp8 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_New_O(c__7); var tmp9 *jrt.Class; var fncls__610 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_fn_class; if fncls__610 == nil { var fncls__610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_fn_class = fncls__610d; tmp9 = fncls__610d } else { tmp9 = fncls__610 }; arg_603 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_604 any; var root_611 any = A_arbace_j2g_world_A_const_65.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = A_arbace_j2g_world_A_const_66; var arg_615 any; var na_616 any = n__6; if jrt.Long_InstanceOf(na_616) { var n0_617 int64 = jrt.NN(jrt.Long_Cast(na_616)).LongValue__J(); if n0_617 == 9223372036854775807 { arg_615 = lang.Numbers_Inc_O__Number_NoInit(na_616) } else { arg_615 = jrt.Long_ValueOf_J__Long_NoInit(n0_617 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_616) { var n0_617_2 float64 = jrt.NN(jrt.Double_Cast(na_616)).DoubleValue__D(); arg_615 = jrt.Double_ValueOf_D__Double_NoInit(n0_617_2 + 1.0).Ref() } else { arg_615 = lang.Numbers_Inc_O__Number_NoInit(na_616) } }; if linked_612 == nil { arg_604 = ifn_613.Invoke_O_O__O(arg_614, arg_615) } else { arg_604 = linked_612.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_611, arg_614, arg_615) }; if linked_601 == nil { ks__8 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { ks__8 = linked_601.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) }
//line :58:1
		var seq_78000075__9 any; var root_647 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_649 lang.IFn


		if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = ks__8; if linked_648 == nil { seq_78000075__9 = ifn_649.Invoke_O__O(arg_650) } else { seq_78000075__9 = linked_648.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_647, arg_650) }
//line :58:1
		var chunk_78000076__10 any; var count_78000077__11 int64 = 0; var i_78000078__12 int64 = 0; L2: for {


			if lang.Numbers_Lt_J_J__Z_NoInit(i_78000078__12, count_78000077__11) { var k__13 any = lang.Indexed_Cast(chunk_78000076__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000078__12)); var tmp10 any; var root_651 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any; var root_655 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = t.F_conts; var arg_659 any = k__13; if linked_656 == nil { arg_654 = ifn_657.Invoke_O_O__O(arg_658, arg_659) } else { arg_654 = linked_656.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_655, arg_658, arg_659) }; if linked_652 == nil { tmp10 = ifn_653.Invoke_O__O(arg_654) } else { tmp10 = linked_652.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_651, arg_654) }; if jrt.J2g_Truth(tmp10) { var tmp11 any; var root_691 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_693 lang.IFn
				if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any; var tmp12 *jrt.RefArray = jrt.ConstRefArray("[0,7,s5:j2g: ns7:: part ns4: of ns23: missing (c2j/continue)", []*jrt.Class{jrt.String_class}); var tmp13 any; var root_696 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = k__13; if linked_697 == nil { tmp13 = ifn_698.Invoke_O__O(arg_699) } else { tmp13 = linked_697.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_696, arg_699) }; arg_694 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, c__7, nil, tmp13, nil, n__6, nil)).Ref(); var arg_695 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_76, c__7)); if linked_692 == nil { tmp11 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { tmp11 = linked_692.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }
//line :61:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp11))); seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = seq_78000075__9, chunk_78000076__10, count_78000077__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000078__12); continue L2 } else { seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = seq_78000075__9, chunk_78000076__10, count_78000077__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000078__12); continue L2 } } else { var temp__1927000414__auto____13 any; var root_660 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = seq_78000075__9; if linked_661 == nil { temp__1927000414__auto____13 = ifn_662.Invoke_O__O(arg_663) } else { temp__1927000414__auto____13 = linked_661.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_660, arg_663) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_78000075__14 any = temp__1927000414__auto____13; var tmp14 any; var root_664 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = seq_78000075__14; if linked_665 == nil { tmp14 = ifn_666.Invoke_O__O(arg_667) } else { tmp14 = linked_665.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_664, arg_667) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____15 any; var root_668 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = seq_78000075__14; if linked_669 == nil { c__1927000678__auto____15 = ifn_670.Invoke_O__O(arg_671) } else { c__1927000678__auto____15 = linked_669.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_668, arg_671) }; var tmp15 any; var root_700 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = seq_78000075__14; if linked_701 == nil { tmp15 = ifn_702.Invoke_O__O(arg_703) } else { tmp15 = linked_701.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_700, arg_703) }; seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = tmp15, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var k__15 any; var root_672 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = seq_78000075__14; if linked_673 == nil { k__15 = ifn_674.Invoke_O__O(arg_675) } else { k__15 = linked_673.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_672, arg_675) }; var tmp16 any; var root_676 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any; var root_680 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = t.F_conts; var arg_684 any = k__15; if linked_681 == nil { arg_679 = ifn_682.Invoke_O_O__O(arg_683, arg_684) } else { arg_679 = linked_681.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_680, arg_683, arg_684) }; if linked_677 == nil { tmp16 = ifn_678.Invoke_O__O(arg_679) } else { tmp16 = linked_677.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_676, arg_679) }; if jrt.J2g_Truth(tmp16) { var tmp17 any; var root_704 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_706 lang.IFn
					if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any; var tmp18 *jrt.RefArray = jrt.ConstRefArray("[0,7,s5:j2g: ns7:: part ns4: of ns23: missing (c2j/continue)", []*jrt.Class{jrt.String_class}); var tmp19 any; var root_709 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = k__15; if linked_710 == nil { tmp19 = ifn_711.Invoke_O__O(arg_712) } else { tmp19 = linked_710.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_709, arg_712) }; arg_707 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, c__7, nil, tmp19, nil, n__6, nil)).Ref(); var arg_708 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_76, c__7)); if linked_705 == nil { tmp17 = ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { tmp17 = linked_705.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_704, arg_707, arg_708) }
//line :61:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))); var tmp20 any; var root_713 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seq_78000075__14; if linked_714 == nil { tmp20 = ifn_715.Invoke_O__O(arg_716) } else { tmp20 = linked_714.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_713, arg_716) }; seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = tmp20, nil, 0, 0; continue L2 } else { var tmp21 any; var root_717 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq_78000075__14; if linked_718 == nil { tmp21 = ifn_719.Invoke_O__O(arg_720) } else { tmp21 = linked_718.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_717, arg_720) }; seq_78000075__9, chunk_78000076__10, count_78000077__11, i_78000078__12 = tmp21, nil, 0, 0; continue L2 } } } }
//line :58:1
			break L2
		}




		var root_685 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = t.F_claimed; var arg_689 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_690 any = ks__8; if linked_686 == nil { ifn_687.Invoke_O_O_O__O(arg_688, arg_689, arg_690) } else { linked_686.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_685, arg_688, arg_689, arg_690) }
		var root_618 any = A_arbace_j2g_world_A_const_67.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any; var root_623 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = A_arbace_j2g_world_A_const_69.GetRawRoot__O(); var arg_627 any; var root_628 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = f__4; var arg_632 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, ks__8); if linked_629 == nil { arg_627 = ifn_630.Invoke_O_O__O(arg_631, arg_632) } else { arg_627 = linked_629.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_628, arg_631, arg_632) }; if linked_624 == nil { arg_621 = ifn_625.Invoke_O_O__O(arg_626, arg_627) } else { arg_621 = linked_624.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_623, arg_626, arg_627) }; var arg_622 any; var root_638 any = A_arbace_j2g_world_A_const_71.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_640 lang.IFn
		if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any; var root_642 any = A_arbace_j2g_world_A_const_72.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__4); var arg_646 any = A_arbace_j2g_world_A_const_61; if linked_643 == nil { arg_641 = ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { arg_641 = linked_643.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) }; if linked_639 == nil { arg_622 = ifn_640.Invoke_O__O(arg_641) } else { arg_622 = linked_639.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_638, arg_641) }
//line :65:1
		if linked_619 == nil { arg_586 = ifn_620.Invoke_O_O__O(arg_621, arg_622) } else { arg_586 = linked_619.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_618, arg_621, arg_622) } } else {
//line :58:1
			arg_586 = f__4 }
//line :57:1
	var arg_587 any; var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__78000059); var tmp23 any; var root_721 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = s__78000060__3; if linked_722 == nil { tmp23 = ifn_723.Invoke_O__O(arg_724) } else { tmp23 = linked_722.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_721, arg_724) }; arg_587 = tmp22.Invoke_O__O(tmp23); if linked_584 == nil { return ifn_585.Invoke_O_O__O(arg_586, arg_587) } else { return linked_584.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_583, arg_586, arg_587) } } else { var tmp24 any; var root_725 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = s__78000060__3; if linked_726 == nil { tmp24 = ifn_727.Invoke_O__O(arg_728) } else { tmp24 = linked_726.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_725, arg_728) }; s__78000060__1 = tmp24; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :57:1
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A) Ctor_O_O_I_O_O(c__claimed, c__b__78000062 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__conts any) { t.F_claimed = c__claimed; t.F_b__78000062 = c__b__78000062; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A) Invoke_O__O(self any) any { { var i__78000061__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000061__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000061__1)); var tmp2 any; var root_402 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_406 any = A_arbace_j2g_world_A_const_51.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_j2g_world_continued_QMARK__A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = f__2; if linked_407 == nil { arg_405 = ifn_408.Invoke_O__O(arg_409) } else { arg_405 = linked_407.(*A_arbace_j2g_world_continued_QMARK__A).Invoke_O_O__O(root_406, arg_409) }; if linked_403 == nil { tmp2 = ifn_404.Invoke_O__O(arg_405) } else { tmp2 = linked_403.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_402, arg_405) }; if jrt.J2g_Truth(tmp2) { var root_410 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = t.F_b__78000062; var arg_414 any; var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any; var root_415 any = A_arbace_j2g_world_A_const_37.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, A_arbace_j2g_world_class_form_QMARK__A_fn_class); var ifn_417 lang.IFn
																			if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = f__2; if linked_416 == nil { and__1927000168__auto____3 = ifn_417.Invoke_O__O(arg_418) } else { and__1927000168__auto____3 = linked_416.(*A_arbace_j2g_world_class_form_QMARK__A).Invoke_O_O__O(root_415, arg_418) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Keyword = A_arbace_j2g_world_A_const_61; temp__1927000408__auto____3 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__2)) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; var c__5 any; var root_419 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_421 lang.IFn
																				if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any; var root_423 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = f__2; if linked_424 == nil { arg_422 = ifn_425.Invoke_O__O(arg_426) } else { arg_422 = linked_424.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_423, arg_426) }; if linked_420 == nil { c__5 = ifn_421.Invoke_O__O(arg_422) } else { c__5 = linked_420.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_419, arg_422) }
//line :58:1
		var ks__6 any; var root_427 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_429 lang.IFn

		if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var tmp4 any = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_New_O(c__5); var tmp5 *jrt.Class; var fncls__437 *jrt.Class = A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_fn_class; if fncls__437 == nil { var fncls__437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_fn_class = fncls__437d; tmp5 = fncls__437d } else { tmp5 = fncls__437 }; arg_430 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_431 any; var root_438 any = A_arbace_j2g_world_A_const_65.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_j2g_world_A_const_66; var arg_442 any; var na_443 any = n__4; if jrt.Long_InstanceOf(na_443) { var n0_444 int64 = jrt.NN(jrt.Long_Cast(na_443)).LongValue__J(); if n0_444 == 9223372036854775807 { arg_442 = lang.Numbers_Inc_O__Number_NoInit(na_443) } else { arg_442 = jrt.Long_ValueOf_J__Long_NoInit(n0_444 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_443) { var n0_444_2 float64 = jrt.NN(jrt.Double_Cast(na_443)).DoubleValue__D(); arg_442 = jrt.Double_ValueOf_D__Double_NoInit(n0_444_2 + 1.0).Ref() } else { arg_442 = lang.Numbers_Inc_O__Number_NoInit(na_443) } }; if linked_439 == nil { arg_431 = ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { arg_431 = linked_439.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) }; if linked_428 == nil { ks__6 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { ks__6 = linked_428.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }
//line :58:1
		var seq_78000068__7 any; var root_474 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_476 lang.IFn


		if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = ks__6; if linked_475 == nil { seq_78000068__7 = ifn_476.Invoke_O__O(arg_477) } else { seq_78000068__7 = linked_475.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_474, arg_477) }
//line :58:1
		var chunk_78000069__8 any; var count_78000070__9 int64 = 0; var i_78000071__10 int64 = 0; L2: for {


			if lang.Numbers_Lt_J_J__Z_NoInit(i_78000071__10, count_78000070__9) { var k__11 any = lang.Indexed_Cast(chunk_78000069__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000071__10)); var tmp6 any; var root_478 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any; var root_482 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = t.F_conts; var arg_486 any = k__11; if linked_483 == nil { arg_481 = ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { arg_481 = linked_483.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_482, arg_485, arg_486) }; if linked_479 == nil { tmp6 = ifn_480.Invoke_O__O(arg_481) } else { tmp6 = linked_479.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_478, arg_481) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_518 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_520 lang.IFn
				if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any; var tmp8 *jrt.RefArray = jrt.ConstRefArray("[0,7,s5:j2g: ns7:: part ns4: of ns23: missing (c2j/continue)", []*jrt.Class{jrt.String_class}); var tmp9 any; var root_523 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = k__11; if linked_524 == nil { tmp9 = ifn_525.Invoke_O__O(arg_526) } else { tmp9 = linked_524.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_523, arg_526) }; arg_521 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, c__5, nil, tmp9, nil, n__4, nil)).Ref(); var arg_522 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_76, c__5)); if linked_519 == nil { tmp7 = ifn_520.Invoke_O_O__O(arg_521, arg_522) } else { tmp7 = linked_519.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_518, arg_521, arg_522) }
//line :61:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp7))); seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = seq_78000068__7, chunk_78000069__8, count_78000070__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000071__10); continue L2 } else { seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = seq_78000068__7, chunk_78000069__8, count_78000070__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000071__10); continue L2 } } else { var temp__1927000414__auto____11 any; var root_487 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = seq_78000068__7; if linked_488 == nil { temp__1927000414__auto____11 = ifn_489.Invoke_O__O(arg_490) } else { temp__1927000414__auto____11 = linked_488.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_487, arg_490) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_78000068__12 any = temp__1927000414__auto____11; var tmp10 any; var root_491 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = seq_78000068__12; if linked_492 == nil { tmp10 = ifn_493.Invoke_O__O(arg_494) } else { tmp10 = linked_492.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_491, arg_494) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____13 any; var root_495 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = seq_78000068__12; if linked_496 == nil { c__1927000678__auto____13 = ifn_497.Invoke_O__O(arg_498) } else { c__1927000678__auto____13 = linked_496.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_495, arg_498) }; var tmp11 any; var root_527 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = seq_78000068__12; if linked_528 == nil { tmp11 = ifn_529.Invoke_O__O(arg_530) } else { tmp11 = linked_528.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_527, arg_530) }; seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = tmp11, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var k__13 any; var root_499 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = seq_78000068__12; if linked_500 == nil { k__13 = ifn_501.Invoke_O__O(arg_502) } else { k__13 = linked_500.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_499, arg_502) }; var tmp12 any; var root_503 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_507 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = t.F_conts; var arg_511 any = k__13; if linked_508 == nil { arg_506 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { arg_506 = linked_508.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }; if linked_504 == nil { tmp12 = ifn_505.Invoke_O__O(arg_506) } else { tmp12 = linked_504.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(tmp12) { var tmp13 any; var root_531 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_533 lang.IFn
					if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any; var tmp14 *jrt.RefArray = jrt.ConstRefArray("[0,7,s5:j2g: ns7:: part ns4: of ns23: missing (c2j/continue)", []*jrt.Class{jrt.String_class}); var tmp15 any; var root_536 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = k__13; if linked_537 == nil { tmp15 = ifn_538.Invoke_O__O(arg_539) } else { tmp15 = linked_537.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_536, arg_539) }; arg_534 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, c__5, nil, tmp15, nil, n__4, nil)).Ref(); var arg_535 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_76, c__5)); if linked_532 == nil { tmp13 = ifn_533.Invoke_O_O__O(arg_534, arg_535) } else { tmp13 = linked_532.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_531, arg_534, arg_535) }
//line :61:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp13))); var tmp16 any; var root_540 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = seq_78000068__12; if linked_541 == nil { tmp16 = ifn_542.Invoke_O__O(arg_543) } else { tmp16 = linked_541.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_540, arg_543) }; seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = tmp16, nil, 0, 0; continue L2 } else { var tmp17 any; var root_544 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = seq_78000068__12; if linked_545 == nil { tmp17 = ifn_546.Invoke_O__O(arg_547) } else { tmp17 = linked_545.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_544, arg_547) }; seq_78000068__7, chunk_78000069__8, count_78000070__9, i_78000071__10 = tmp17, nil, 0, 0; continue L2 } } } }
//line :58:1
			break L2
		}




		var root_512 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = t.F_claimed; var arg_516 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_517 any = ks__6; if linked_513 == nil { ifn_514.Invoke_O_O_O__O(arg_515, arg_516, arg_517) } else { linked_513.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_512, arg_515, arg_516, arg_517) }
		var root_445 any = A_arbace_j2g_world_A_const_67.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var root_450 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = A_arbace_j2g_world_A_const_69.GetRawRoot__O(); var arg_454 any; var root_455 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = f__2; var arg_459 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, ks__6); if linked_456 == nil { arg_454 = ifn_457.Invoke_O_O__O(arg_458, arg_459) } else { arg_454 = linked_456.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_455, arg_458, arg_459) }; if linked_451 == nil { arg_448 = ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { arg_448 = linked_451.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) }; var arg_449 any; var root_465 any = A_arbace_j2g_world_A_const_71.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_467 lang.IFn
		if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any; var root_469 any = A_arbace_j2g_world_A_const_72.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__2); var arg_473 any = A_arbace_j2g_world_A_const_61; if linked_470 == nil { arg_468 = ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { arg_468 = linked_470.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) }; if linked_466 == nil { arg_449 = ifn_467.Invoke_O__O(arg_468) } else { arg_449 = linked_466.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_465, arg_468) }
//line :65:1
		if linked_446 == nil { arg_414 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { arg_414 = linked_446.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) } } else {
//line :58:1
			arg_414 = f__2 }
//line :57:1
	if linked_411 == nil { ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { linked_411.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) }; i__78000061__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000061__1); continue L1 } else { i__78000061__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000061__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_New_O(p0 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :60:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A) Invoke_O_O__O(self, p1__78000038_SHARP___1 any) any { var root_432 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_vector_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = t.F_c; var arg_436 any = p1__78000038_SHARP___1; if linked_433 == nil { return ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { return linked_433.(*aot_arbace_core.A_arbace_core_vector_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) } }
//line :60:1
func A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_New_O(p0 any) *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :60:1
func (t *A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A) Invoke_O_O__O(self, p1__78000038_SHARP___1 any) any { var root_605 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_vector_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = t.F_c; var arg_609 any = p1__78000038_SHARP___1; if linked_606 == nil { return ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { return linked_606.(*aot_arbace_core.A_arbace_core_vector_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) } }












func A_arbace_j2g_world_ns_of_forms_A_New() *A_arbace_j2g_world_ns_of_forms_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_ns_of_forms_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_world_ns_of_forms_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_world_ns_of_forms_A) Invoke_O_O__O(self, forms__0 any) any { var f__2 any; var root_763 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_765 lang.IFn; if
											linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any; var root_767 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any; var tmp1 any = A_arbace_j2g_world_ns_of_forms_fn__78000085_A_New(); var tmp2 *jrt.Class; var fncls__792 *jrt.Class = A_arbace_j2g_world_ns_of_forms_fn__78000085_A_fn_class; if fncls__792 == nil { var fncls__792d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_j2g_world_ns_of_forms_fn__78000085_A_fn_class = fncls__792d; tmp2 = fncls__792d } else { tmp2 = fncls__792 }; arg_770 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_771 any = forms__0; if linked_768 == nil { arg_766 = ifn_769.Invoke_O_O__O(arg_770, arg_771) } else { arg_766 = linked_768.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_767, arg_770, arg_771) }; if linked_764 == nil { f__2 = ifn_765.Invoke_O__O(arg_766) } else { f__2 = linked_764.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_763, arg_766) }; if
											jrt.J2g_Truth(f__2) { var n__3 any; var root_793 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = f__2; if linked_794 == nil { n__3 = ifn_795.Invoke_O__O(arg_796) } else { n__3 = linked_794.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_793, arg_796) }; var tmp3 any; var root_797 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = n__3; if linked_798 == nil { tmp3 = ifn_799.Invoke_O__O(arg_800) } else { tmp3 = linked_798.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_797, arg_800) }; if jrt.J2g_Truth(tmp3) { var root_801 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = n__3; if linked_802 == nil { return ifn_803.Invoke_O__O(arg_804) } else { return linked_802.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_801, arg_804) } } else { return n__3 } } else { return nil } }
//line :74:1
func A_arbace_j2g_world_ns_of_forms_fn__78000085_A_New() *A_arbace_j2g_world_ns_of_forms_fn__78000085_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_ns_of_forms_fn__78000085_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_j2g_world_ns_of_forms_fn__78000085_A) Ctor() {}
//line :74:1
func (t *A_arbace_j2g_world_ns_of_forms_fn__78000085_A) Invoke_O_O__O(self, p1__78000084_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_772 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = p1__78000084_SHARP___1; if linked_773 == nil { and__1927000168__auto____2 = ifn_774.Invoke_O__O(arg_775) } else { and__1927000168__auto____2 = linked_773.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_772, arg_775) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_776 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var root_780 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = p1__78000084_SHARP___1; if linked_781 == nil { arg_779 = ifn_782.Invoke_O__O(arg_783) } else { arg_779 = linked_781.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_780, arg_783) }; if linked_777 == nil { and__1927000168__auto____3 = ifn_778.Invoke_O__O(arg_779) } else { and__1927000168__auto____3 = linked_777.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_776, arg_779) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any; var root_784 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any; var root_788 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = p1__78000084_SHARP___1; if linked_789 == nil { arg_787 = ifn_790.Invoke_O__O(arg_791) } else { arg_787 = linked_789.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_788, arg_791) }; if linked_785 == nil { tmp1 = ifn_786.Invoke_O__O(arg_787) } else { tmp1 = linked_785.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_784, arg_787) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_122, tmp1)).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_world_top_names_A_New() *A_arbace_j2g_world_top_names_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_top_names_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_j2g_world_top_names_A) Ctor() {}
//line :77:1
func (t *A_arbace_j2g_world_top_names_A) Invoke_O_O_O__O(self, nsname__0, forms__1 any) any { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_world_top_names_iter__78000088__78000092_A_New_O(nsname__0); var tmp2 *jrt.Class; var fncls__1037 *jrt.Class = A_arbace_j2g_world_top_names_iter__78000088__78000092_A_fn_class; if


	fncls__1037 == nil { var fncls__1037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_j2g_world_top_names_iter__78000088__78000092_A_fn_class = fncls__1037d; tmp2 = fncls__1037d } else { tmp2 = fncls__1037 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1038 any = A_arbace_j2g_world_A_const_90.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, A_arbace_j2g_world_class_forms_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = forms__1; if linked_1039 == nil { tmp4 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp4 = linked_1039.(*A_arbace_j2g_world_class_forms_A).Invoke_O_O__O(root_1038, arg_1041) }; return tmp3.Invoke_O__O(tmp4) }
//line :80:1
func A_arbace_j2g_world_top_names_iter__78000088__78000092_A_New_O(p0 any) *A_arbace_j2g_world_top_names_iter__78000088__78000092_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_top_names_iter__78000088__78000092_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_A) Invoke_O_O__O(self, s__78000089__1 any) any { var tmp1 any = A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_New_O_O_O(t.F_nsname, s__78000089__1, self); var tmp2 *jrt.Class; var fncls__1036 *jrt.Class = A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_fn_class; if fncls__1036 == nil { var fncls__1036d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_fn_class = fncls__1036d; tmp2 = fncls__1036d } else { tmp2 = fncls__1036 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :80:1
func A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A) Ctor_O_O_O(c__nsname, c__s__78000089, c__iter__78000088 any) { t.F_nsname = c__nsname; t.F_s__78000089 = c__s__78000089; t.F_iter__78000088 = c__iter__78000088 }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A) Invoke_O__O(self any) any { { var s__78000089__1 any; var t_ any = t.F_s__78000089; t.F_s__78000089 = nil; s__78000089__1 = t_; for { var temp__1927000414__auto____2 any; var root_805 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = s__78000089__1; if linked_806 == nil { temp__1927000414__auto____2 = ifn_807.Invoke_O__O(arg_808) } else { temp__1927000414__auto____2 = linked_806.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_805, arg_808) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000089__3 any = temp__1927000414__auto____2; var tmp1 any; var root_809 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = s__78000089__3; if linked_810 == nil { tmp1 = ifn_811.Invoke_O__O(arg_812) } else { tmp1 = linked_810.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_809, arg_812) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_813 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = s__78000089__3; if linked_814 == nil { c__1927001037__auto____4 = ifn_815.Invoke_O__O(arg_816) } else { c__1927001037__auto____4 = linked_814.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_813, arg_816) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000091__6 any; var root_817 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_818 == nil { b__78000091__6 = ifn_819.Invoke_O__O(arg_820) } else { b__78000091__6 = linked_818.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_817, arg_820) }; var tmp2 any = A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_New_O_O_I_O(t.F_nsname, b__78000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__913 *jrt.Class = A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_fn_class; if fncls__913 == nil { var fncls__913d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_fn_class = fncls__913d; tmp3 = fncls__913d } else { tmp3 = fncls__913 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_914 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any; var root_919 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = b__78000091__6; if linked_920 == nil { arg_917 = ifn_921.Invoke_O__O(arg_922) } else { arg_917 = linked_920.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_919, arg_922) }; var arg_918 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000088); var tmp5 any; var root_923 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = s__78000089__3; if linked_924 == nil { tmp5 = ifn_925.Invoke_O__O(arg_926) } else { tmp5 = linked_924.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_923, arg_926) }; arg_918 = tmp4.Invoke_O__O(tmp5); if linked_915 == nil { return ifn_916.Invoke_O_O__O(arg_917, arg_918) } else { return linked_915.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_914, arg_917, arg_918) } } else { var root_927 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any; var root_932 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = b__78000091__6; if linked_933 == nil { arg_930 = ifn_934.Invoke_O__O(arg_935) } else { arg_930 = linked_933.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_932, arg_935) }; var arg_931 any; if linked_928 == nil { return ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { return linked_928.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_927, arg_930, arg_931) } } } else { var cf__4 any; var root_936 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = s__78000089__3; if linked_937 == nil { cf__4 = ifn_938.Invoke_O__O(arg_939) } else { cf__4 = linked_937.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_936, arg_939) }; var vec__78000099__5 any; var root_940 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_942 lang.IFn
														if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = cf__4; if linked_941 == nil { vec__78000099__5 = ifn_942.Invoke_O__O(arg_943) } else { vec__78000099__5 = linked_941.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_940, arg_943) }
//line :80:1
	var seq__78000100__6 any; var root_944 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = vec__78000099__5; if linked_945 == nil { seq__78000100__6 = ifn_946.Invoke_O__O(arg_947) } else { seq__78000100__6 = linked_945.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_944, arg_947) }; var first__78000101__7 any; var root_948 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = seq__78000100__6; if linked_949 == nil { first__78000101__7 = ifn_950.Invoke_O__O(arg_951) } else { first__78000101__7 = linked_949.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_948, arg_951) }; var seq__78000100__8 any; var root_952 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = seq__78000100__6; if linked_953 == nil { seq__78000100__8 = ifn_954.Invoke_O__O(arg_955) } else { seq__78000100__8 = linked_953.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_952, arg_955) }; var nm__9 any = first__78000101__7; var more__10 any = seq__78000100__8; var more__11 any; var tmp6 any; var root_956 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_958 lang.IFn

	if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any; var root_960 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = more__10; if linked_961 == nil { arg_959 = ifn_962.Invoke_O__O(arg_963) } else { arg_959 = linked_961.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_960, arg_963) }; if linked_957 == nil { tmp6 = ifn_958.Invoke_O__O(arg_959) } else { tmp6 = linked_957.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_956, arg_959) }; if jrt.J2g_Truth(tmp6) { var root_964 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = more__10; if linked_965 == nil { more__11 = ifn_966.Invoke_O__O(arg_967) } else { more__11 = linked_965.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_964, arg_967) } } else { more__11 = more__10 }
//line :80:1
	var pkg__12 any; var tmp7 *lang.Keyword = A_arbace_j2g_world_A_const_83; var tmp8 any; var root_968 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_970 lang.IFn


	if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any; var root_972 any = A_arbace_j2g_world_A_const_84.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = more__11; if linked_973 == nil { arg_971 = ifn_974.Invoke_O__O(arg_975) } else { arg_971 = linked_973.(*aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A).Invoke_O_O__O(root_972, arg_975) }; if linked_969 == nil { tmp8 = ifn_970.Invoke_O__O(arg_971) } else { tmp8 = linked_969.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_968, arg_971) }; pkg__12 = tmp7.Invoke_O__O(tmp8)
//line :80:1
	var s__13 any; var root_976 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_978 lang.IFn



	if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = nm__9; if linked_977 == nil { s__13 = ifn_978.Invoke_O__O(arg_979) } else { s__13 = linked_977.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_976, arg_979) }
//line :80:1
	var root_980 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any; var tmp9 any; var root_985 any = A_arbace_j2g_world_A_const_85.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_987 lang.IFn




	if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = pkg__12; if linked_986 == nil { tmp9 = ifn_987.Invoke_O__O(arg_988) } else { tmp9 = linked_986.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_985, arg_988) }; if jrt.J2g_Truth(tmp9) { var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp11 *jrt.String; var tmp12 any; var root_989 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any; var root_993 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = pkg__12; if linked_994 == nil { arg_992 = ifn_995.Invoke_O__O(arg_996) } else { arg_992 = linked_994.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_993, arg_996) }; if linked_990 == nil { tmp12 = ifn_991.Invoke_O__O(arg_992) } else { tmp12 = linked_990.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_989, arg_992) }; if jrt.J2g_Truth(tmp12) { var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140); var tmp14 any; var root_997 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any; var root_1003 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1003, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = pkg__12; if linked_1004 == nil { arg_1000 = ifn_1005.Invoke_O__O(arg_1006) } else { arg_1000 = linked_1004.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1003, arg_1006) }; var arg_1001 any = Lit_141; var arg_1002 any = Lit_140; if linked_998 == nil { tmp14 = ifn_999.Invoke_O_O_O__O(arg_1000, arg_1001, arg_1002) } else { tmp14 = linked_998.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_997, arg_1000, arg_1001, arg_1002) }; tmp11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, tmp14, nil)) } else { tmp11 = nil }; arg_983 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11.Ref(), s__13)).Ref() } else { var tmp15 any; var root_1007 any = A_arbace_j2g_world_A_const_87.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1009 lang.IFn
		if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = s__13; var arg_1011 any = Lit_141; if linked_1008 == nil { tmp15 = ifn_1009.Invoke_O_O__O(arg_1010, arg_1011) } else { tmp15 = linked_1008.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1007, arg_1010, arg_1011) }
//line :85:1
		if jrt.J2g_Truth(tmp15) {
			var root_1012 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = s__13; var arg_1016 any = Lit_141; var arg_1017 any = Lit_140; if linked_1013 == nil { arg_983 = ifn_1014.Invoke_O_O_O__O(arg_1015, arg_1016, arg_1017) } else { arg_983 = linked_1013.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1012, arg_1015, arg_1016, arg_1017) } } else {
//line :85:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140, nil); var tmp17 any; var root_1018 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any; var root_1024 any = A_arbace_j2g_world_A_const_89.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any; var root_1028 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = t.F_nsname; if linked_1029 == nil { arg_1027 = ifn_1030.Invoke_O__O(arg_1031) } else { arg_1027 = linked_1029.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1028, arg_1031) }; if linked_1025 == nil { arg_1021 = ifn_1026.Invoke_O__O(arg_1027) } else { arg_1021 = linked_1025.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_1024, arg_1027) }; var arg_1022 any = Lit_141; var arg_1023 any = Lit_140; if linked_1019 == nil { tmp17 = ifn_1020.Invoke_O_O_O__O(arg_1021, arg_1022, arg_1023) } else { tmp17 = linked_1019.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1018, arg_1021, arg_1022, arg_1023) }; arg_983 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, nil, s__13)).Ref() } else {
//line :85:1
						arg_983 = nil } } }
//line :80:1
	var arg_984 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__78000088); var tmp19 any; var root_1032 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = s__78000089__3; if linked_1033 == nil { tmp19 = ifn_1034.Invoke_O__O(arg_1035) } else { tmp19 = linked_1033.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1032, arg_1035) }; arg_984 = tmp18.Invoke_O__O(tmp19); if linked_981 == nil { return ifn_982.Invoke_O_O__O(arg_983, arg_984) } else { return linked_981.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_980, arg_983, arg_984) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A) Ctor_O_O_I_O(c__nsname, c__b__78000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_nsname = c__nsname; t.F_b__78000091 = c__b__78000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A) Invoke_O__O(self any) any { { var i__78000090__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000090__1)); var vec__78000095__3 any; var root_821 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_823 lang.IFn
															if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = cf__2; if linked_822 == nil { vec__78000095__3 = ifn_823.Invoke_O__O(arg_824) } else { vec__78000095__3 = linked_822.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_821, arg_824) }
//line :80:1
	var seq__78000096__4 any; var root_825 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = vec__78000095__3; if linked_826 == nil { seq__78000096__4 = ifn_827.Invoke_O__O(arg_828) } else { seq__78000096__4 = linked_826.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_825, arg_828) }; var first__78000097__5 any; var root_829 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = seq__78000096__4; if linked_830 == nil { first__78000097__5 = ifn_831.Invoke_O__O(arg_832) } else { first__78000097__5 = linked_830.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_829, arg_832) }; var seq__78000096__6 any; var root_833 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = seq__78000096__4; if linked_834 == nil { seq__78000096__6 = ifn_835.Invoke_O__O(arg_836) } else { seq__78000096__6 = linked_834.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_833, arg_836) }; var nm__7 any = first__78000097__5; var more__8 any = seq__78000096__6; var more__9 any; var tmp2 any; var root_837 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_839 lang.IFn

	if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any; var root_841 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = more__8; if linked_842 == nil { arg_840 = ifn_843.Invoke_O__O(arg_844) } else { arg_840 = linked_842.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_841, arg_844) }; if linked_838 == nil { tmp2 = ifn_839.Invoke_O__O(arg_840) } else { tmp2 = linked_838.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_837, arg_840) }; if jrt.J2g_Truth(tmp2) { var root_845 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = more__8; if linked_846 == nil { more__9 = ifn_847.Invoke_O__O(arg_848) } else { more__9 = linked_846.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_845, arg_848) } } else { more__9 = more__8 }
//line :80:1
	var pkg__10 any; var tmp3 *lang.Keyword = A_arbace_j2g_world_A_const_83; var tmp4 any; var root_849 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_851 lang.IFn


	if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any; var root_853 any = A_arbace_j2g_world_A_const_84.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = more__9; if linked_854 == nil { arg_852 = ifn_855.Invoke_O__O(arg_856) } else { arg_852 = linked_854.(*aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A).Invoke_O_O__O(root_853, arg_856) }; if linked_850 == nil { tmp4 = ifn_851.Invoke_O__O(arg_852) } else { tmp4 = linked_850.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_849, arg_852) }; pkg__10 = tmp3.Invoke_O__O(tmp4)
//line :80:1
	var s__11 any; var root_857 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_859 lang.IFn



	if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = nm__7; if linked_858 == nil { s__11 = ifn_859.Invoke_O__O(arg_860) } else { s__11 = linked_858.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_857, arg_860) }
//line :80:1
	var root_861 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = t.F_b__78000091; var arg_865 any; var tmp5 any; var root_866 any = A_arbace_j2g_world_A_const_85.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_868 lang.IFn




	if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = pkg__10; if linked_867 == nil { tmp5 = ifn_868.Invoke_O__O(arg_869) } else { tmp5 = linked_867.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_866, arg_869) }; if jrt.J2g_Truth(tmp5) { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; var tmp8 any; var root_870 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var root_874 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = pkg__10; if linked_875 == nil { arg_873 = ifn_876.Invoke_O__O(arg_877) } else { arg_873 = linked_875.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_874, arg_877) }; if linked_871 == nil { tmp8 = ifn_872.Invoke_O__O(arg_873) } else { tmp8 = linked_871.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_870, arg_873) }; if jrt.J2g_Truth(tmp8) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140); var tmp10 any; var root_878 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any; var root_884 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = pkg__10; if linked_885 == nil { arg_881 = ifn_886.Invoke_O__O(arg_887) } else { arg_881 = linked_885.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_884, arg_887) }; var arg_882 any = Lit_141; var arg_883 any = Lit_140; if linked_879 == nil { tmp10 = ifn_880.Invoke_O_O_O__O(arg_881, arg_882, arg_883) } else { tmp10 = linked_879.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_878, arg_881, arg_882, arg_883) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10, nil)) } else { tmp7 = nil }; arg_865 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), s__11)).Ref() } else { var tmp11 any; var root_888 any = A_arbace_j2g_world_A_const_87.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_890 lang.IFn
		if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = s__11; var arg_892 any = Lit_141; if linked_889 == nil { tmp11 = ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { tmp11 = linked_889.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_888, arg_891, arg_892) }
//line :85:1
		if jrt.J2g_Truth(tmp11) {
			var root_893 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = s__11; var arg_897 any = Lit_141; var arg_898 any = Lit_140; if linked_894 == nil { arg_865 = ifn_895.Invoke_O_O_O__O(arg_896, arg_897, arg_898) } else { arg_865 = linked_894.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_893, arg_896, arg_897, arg_898) } } else {
//line :85:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140, nil); var tmp13 any; var root_899 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any; var root_905 any = A_arbace_j2g_world_A_const_89.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any; var root_909 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = t.F_nsname; if linked_910 == nil { arg_908 = ifn_911.Invoke_O__O(arg_912) } else { arg_908 = linked_910.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_909, arg_912) }; if linked_906 == nil { arg_902 = ifn_907.Invoke_O__O(arg_908) } else { arg_902 = linked_906.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_905, arg_908) }; var arg_903 any = Lit_141; var arg_904 any = Lit_140; if linked_900 == nil { tmp13 = ifn_901.Invoke_O_O_O__O(arg_902, arg_903, arg_904) } else { tmp13 = linked_900.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_899, arg_902, arg_903, arg_904) }; arg_865 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, s__11)).Ref() } else {
//line :85:1
						arg_865 = nil } } }
//line :80:1
	if linked_862 == nil { ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { linked_862.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_861, arg_864, arg_865) }; i__78000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000090__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_world_source_files_A_New() *A_arbace_j2g_world_source_files_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_j2g_world_source_files_A) Ctor() {}
//line :89:1
func (t *A_arbace_j2g_world_source_files_A) Invoke_O_O__O(self, p__78000107__0 any) any { var map__78000108__2 any = p__78000107__0; var map__78000108__3 any; if lang.ISeq_InstanceOf(map__78000108__2) { var tmp1 any; var root_1042 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = map__78000108__2; if linked_1043 == nil { tmp1 = ifn_1044.Invoke_O__O(arg_1045) } else { tmp1 = linked_1043.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1042, arg_1045) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1046 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = map__78000108__2; if linked_1047 == nil { tmp2 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp2 = linked_1047.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1046, arg_1049) }; map__78000108__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1050 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = map__78000108__2; if linked_1051 == nil { tmp3 = ifn_1052.Invoke_O__O(arg_1053) } else { tmp3 = linked_1051.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1050, arg_1053) }; if jrt.J2g_Truth(tmp3) { var root_1054 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = map__78000108__2; if linked_1055 == nil { map__78000108__3 = ifn_1056.Invoke_O__O(arg_1057) } else { map__78000108__3 = linked_1055.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1054, arg_1057) } } else { map__78000108__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000108__3 = map__78000108__2 }; var root__4 any = lang.RT_Get_O_O__O_NoInit(map__78000108__3, A_arbace_j2g_world_A_const_91); var dirs__5 any = lang.RT_Get_O_O__O_NoInit(map__78000108__3, A_arbace_j2g_world_A_const_92); var tree__6 any = lang.RT_Get_O_O__O_NoInit(map__78000108__3, A_arbace_j2g_world_A_const_93); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__78000108__3, A_arbace_j2g_world_A_const_94); if



	jrt.J2g_Truth(files__7) {
		var root_1058 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = A_arbace_j2g_world_A_const_95.GetRawRoot__O(); var arg_1062 any = files__7; if linked_1059 == nil { return ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { return linked_1059.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) } } else {
//line :93:1
			if jrt.J2g_Truth(tree__6) {






				var root_1063 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var arg_1067 any; var root_1068 any = A_arbace_j2g_world_A_const_77.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1070 lang.IFn
//line :99:1
				if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any; var tmp4 any = A_arbace_j2g_world_source_files_fn__78000110_A_New(); var tmp5 *jrt.Class; var fncls__1085 *jrt.Class = A_arbace_j2g_world_source_files_fn__78000110_A_fn_class; if fncls__1085 == nil { var fncls__1085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_j2g_world_source_files_fn__78000110_A_fn_class = fncls__1085d; tmp5 = fncls__1085d } else { tmp5 = fncls__1085 }; arg_1071 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1072 any; var root_1086 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1088 lang.IFn
//line :96:1
				if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any; var tmp6 any = A_arbace_j2g_world_source_files_fn__78000112_A_New(); var tmp7 *jrt.Class; var fncls__1096 *jrt.Class = A_arbace_j2g_world_source_files_fn__78000112_A_fn_class; if fncls__1096 == nil { var fncls__1096d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_j2g_world_source_files_fn__78000112_A_fn_class = fncls__1096d; tmp7 = fncls__1096d } else { tmp7 = fncls__1096 }; arg_1089 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1090 any; var root_1097 any = A_arbace_j2g_world_A_const_100.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1099 lang.IFn
//line :95:1
				if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any; var root_1101 any = A_arbace_j2g_world_A_const_95.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1101, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = root__4; if linked_1102 == nil { arg_1100 = ifn_1103.Invoke_O__O(arg_1104) } else { arg_1100 = linked_1102.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1101, arg_1104) }; if linked_1098 == nil { arg_1090 = ifn_1099.Invoke_O__O(arg_1100) } else { arg_1090 = linked_1098.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1097, arg_1100) }
				if linked_1087 == nil { arg_1072 = ifn_1088.Invoke_O_O__O(arg_1089, arg_1090) } else { arg_1072 = linked_1087.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1086, arg_1089, arg_1090)
				}

				if linked_1069 == nil { arg_1067 = ifn_1070.Invoke_O_O__O(arg_1071, arg_1072) } else { arg_1067 = linked_1069.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1068, arg_1071, arg_1072) }
				if linked_1064 == nil { return ifn_1065.Invoke_O_O__O(arg_1066, arg_1067) } else { return linked_1064.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1063, arg_1066, arg_1067) } } else {
//line :93:1
					if A_arbace_j2g_world_A_const_88 != nil {










						var root_1105 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var arg_1109 any; var iter__1927001039__auto____8 any; var tmp8 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_A_New_O(root__4); var tmp9 *jrt.Class; var fncls__1214 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_A_fn_class
//line :101:1
						if fncls__1214 == nil { var fncls__1214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_A_fn_class = fncls__1214d; tmp9 = fncls__1214d } else { tmp9 = fncls__1214 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_1109 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(dirs__5)


						if linked_1106 == nil { return ifn_1107.Invoke_O_O__O(arg_1108, arg_1109) } else { return linked_1106.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1105, arg_1108, arg_1109) } } else {
//line :93:1
							return nil } } } }


func A_arbace_j2g_world_source_files_fn__78000112_A_New() *A_arbace_j2g_world_source_files_fn__78000112_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_fn__78000112_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_j2g_world_source_files_fn__78000112_A) Ctor() {}
//line :96:1
func (t *A_arbace_j2g_world_source_files_fn__78000112_A) Invoke_O_O__O(self, p1__78000105_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__78000105_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var root_1091 any = A_arbace_j2g_world_A_const_99.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = jrt.NN(jrt.File_Cast(p1__78000105_SHARP___1)).GetName__String().Ref(); var arg_1095 any = Lit_146; if linked_1092 == nil { return ifn_1093.Invoke_O_O__O(arg_1094, arg_1095) } else { return linked_1092.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1091, arg_1094, arg_1095) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }


func A_arbace_j2g_world_source_files_fn__78000110_A_New() *A_arbace_j2g_world_source_files_fn__78000110_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_fn__78000110_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_j2g_world_source_files_fn__78000110_A) Ctor() {}
//line :99:1
func (t *A_arbace_j2g_world_source_files_fn__78000110_A) Invoke_O_O__O(self, p1__78000106_SHARP___1 any) any { var f__2 any; var root_1073 any = A_arbace_j2g_world_A_const_97.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, A_arbace_j2g_world_first_form_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = p1__78000106_SHARP___1; if linked_1074 == nil { f__2 = ifn_1075.Invoke_O__O(arg_1076) } else { f__2 = linked_1074.(*A_arbace_j2g_world_first_form_A).Invoke_O_O__O(root_1073, arg_1076) }; var and__1927000168__auto____3 any; var root_1077 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = f__2; if linked_1078 == nil { and__1927000168__auto____3 = ifn_1079.Invoke_O__O(arg_1080) } else { and__1927000168__auto____3 = linked_1078.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1077, arg_1080) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_j2g_world_A_const_98; var tmp2 any; var root_1081 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = f__2; if linked_1082 == nil { tmp2 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp2 = linked_1082.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1081, arg_1084) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____3 } }

func A_arbace_j2g_world_source_files_iter__78000114__78000120_A_New_O(p0 any) *A_arbace_j2g_world_source_files_iter__78000114__78000120_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_A) Invoke_O_O__O(self, s__78000115__1 any) any { var tmp1 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_New_O_O_O(s__78000115__1, self, t.F_root); var tmp2 *jrt.Class; var fncls__1213 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_fn_class; if fncls__1213 == nil { var fncls__1213d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_fn_class = fncls__1213d; tmp2 = fncls__1213d } else { tmp2 = fncls__1213 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :101:1
func A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A) Ctor_O_O_O(c__s__78000115, c__iter__78000114, c__root any) { t.F_s__78000115 = c__s__78000115; t.F_iter__78000114 = c__iter__78000114; t.F_root = c__root }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A) Invoke_O__O(self any) any { { var s__78000115__1 any; var t_ any = t.F_s__78000115; t.F_s__78000115 = nil; s__78000115__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1110 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = s__78000115__1; if linked_1111 == nil { temp__1927000414__auto____2 = ifn_1112.Invoke_O__O(arg_1113) } else { temp__1927000414__auto____2 = linked_1111.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1110, arg_1113) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any; var root_1114 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = xs__1927001018__auto____3; if linked_1115 == nil { d__4 = ifn_1116.Invoke_O__O(arg_1117) } else { d__4 = linked_1115.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1114, arg_1117) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_New(); var tmp2 *jrt.Class; var fncls__1190 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_fn_class; if fncls__1190 == nil { var fncls__1190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_fn_class = fncls__1190d; tmp2 = fncls__1190d } else { tmp2 = fncls__1190 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_1191 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1195 any = A_arbace_j2g_world_A_const_95.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1195, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = t.F_root; var arg_1199 any = d__4; if linked_1196 == nil { tmp4 = ifn_1197.Invoke_O_O__O(arg_1198, arg_1199) } else { tmp4 = linked_1196.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1195, arg_1198, arg_1199) }; arg_1194 = tmp3.Invoke_O__O(jrt.NN(jrt.File_Cast(tmp4)).ListFiles__File1().Ref()); if linked_1192 == nil { fs__1927001036__auto____6 = ifn_1193.Invoke_O__O(arg_1194) } else { fs__1927001036__auto____6 = linked_1192.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1191, arg_1194) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1200 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = fs__1927001036__auto____6; var arg_1204 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__78000114); var tmp6 any; var root_1205 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = s__78000115__1; if linked_1206 == nil { tmp6 = ifn_1207.Invoke_O__O(arg_1208) } else { tmp6 = linked_1206.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1205, arg_1208) }; arg_1204 = tmp5.Invoke_O__O(tmp6); if linked_1201 == nil { return ifn_1202.Invoke_O_O__O(arg_1203, arg_1204) } else { return linked_1201.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1200, arg_1203, arg_1204) } } else { var tmp7 any; var root_1209 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = s__78000115__1; if linked_1210 == nil { tmp7 = ifn_1211.Invoke_O__O(arg_1212) } else { tmp7 = linked_1210.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1209, arg_1212) }; s__78000115__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :101:1
func A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_New() *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A) Ctor() {}
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A) Invoke_O_O__O(self, s__78000117__1 any) any { var tmp1 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_New_O_O(s__78000117__1, self); var tmp2 *jrt.Class; var fncls__1189 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_fn_class; if fncls__1189 == nil { var fncls__1189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_fn_class = fncls__1189d; tmp2 = fncls__1189d } else { tmp2 = fncls__1189 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :101:1
func A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A{}; t.Ctor_O_O(p0, p1); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A) Ctor_O_O(c__s__78000117, c__iter__78000116 any) { t.F_s__78000117 = c__s__78000117; t.F_iter__78000116 = c__iter__78000116 }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A) Invoke_O__O(self any) any { { var s__78000117__1 any; var t_ any = t.F_s__78000117; t.F_s__78000117 = nil; s__78000117__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1118 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = s__78000117__1; if linked_1119 == nil { temp__1927000414__auto____2 = ifn_1120.Invoke_O__O(arg_1121) } else { temp__1927000414__auto____2 = linked_1119.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1118, arg_1121) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000117__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1122 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1124 lang.IFn; if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = s__78000117__3; if linked_1123 == nil { tmp1 = ifn_1124.Invoke_O__O(arg_1125) } else { tmp1 = linked_1123.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1122, arg_1125) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1126 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any = s__78000117__3; if linked_1127 == nil { c__1927001037__auto____4 = ifn_1128.Invoke_O__O(arg_1129) } else { c__1927001037__auto____4 = linked_1127.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1126, arg_1129) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000119__6 any; var root_1130 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1131 == nil { b__78000119__6 = ifn_1132.Invoke_O__O(arg_1133) } else { b__78000119__6 = linked_1131.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1130, arg_1133) }; var tmp2 any = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_New_O_I_O(b__78000119__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1144 *jrt.Class = A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_fn_class; if fncls__1144 == nil { var fncls__1144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_fn_class = fncls__1144d; tmp3 = fncls__1144d } else { tmp3 = fncls__1144 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1145 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any; var root_1150 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = b__78000119__6; if linked_1151 == nil { arg_1148 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1148 = linked_1151.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1150, arg_1153) }; var arg_1149 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000116); var tmp5 any; var root_1154 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = s__78000117__3; if linked_1155 == nil { tmp5 = ifn_1156.Invoke_O__O(arg_1157) } else { tmp5 = linked_1155.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1154, arg_1157) }; arg_1149 = tmp4.Invoke_O__O(tmp5); if linked_1146 == nil { return ifn_1147.Invoke_O_O__O(arg_1148, arg_1149) } else { return linked_1146.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1145, arg_1148, arg_1149) } } else { var root_1158 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var root_1163 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = b__78000119__6; if linked_1164 == nil { arg_1161 = ifn_1165.Invoke_O__O(arg_1166) } else { arg_1161 = linked_1164.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1163, arg_1166) }; var arg_1162 any; if linked_1159 == nil { return ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { return linked_1159.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) } } } else { var f__4 any; var root_1167 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = s__78000117__3; if linked_1168 == nil { f__4 = ifn_1169.Invoke_O__O(arg_1170) } else { f__4 = linked_1168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1167, arg_1170) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
																			if and__1927000168__auto____5 { var root_1171 any = A_arbace_j2g_world_A_const_99.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_1175 any = Lit_146; if linked_1172 == nil { tmp6 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { tmp6 = linked_1172.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :101:1
	if jrt.J2g_Truth(tmp6) { var root_1176 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = f__4; var arg_1180 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000116); var tmp8 any; var root_1181 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = s__78000117__3; if linked_1182 == nil { tmp8 = ifn_1183.Invoke_O__O(arg_1184) } else { tmp8 = linked_1182.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1181, arg_1184) }; arg_1180 = tmp7.Invoke_O__O(tmp8); if linked_1177 == nil { return ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { return linked_1177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) } } else { var tmp9 any; var root_1185 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = s__78000117__3; if linked_1186 == nil { tmp9 = ifn_1187.Invoke_O__O(arg_1188) } else { tmp9 = linked_1186.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1185, arg_1188) }; s__78000117__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :101:1
func A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A) Ctor_O_I_O(c__b__78000119 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000119 = c__b__78000119; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :101:1
func (t *A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A) Invoke_O__O(self any) any { { var i__78000118__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000118__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000118__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																				if and__1927000168__auto____3 { var root_1134 any = A_arbace_j2g_world_A_const_99.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_1138 any = Lit_146; if linked_1135 == nil { tmp2 = ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { tmp2 = linked_1135.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :101:1
	if jrt.J2g_Truth(tmp2) { var root_1139 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = t.F_b__78000119; var arg_1143 any = f__2; if linked_1140 == nil { ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { linked_1140.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) }; i__78000118__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000118__1); continue L1 } else { i__78000118__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000118__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_world_head_name_A_New() *A_arbace_j2g_world_head_name_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_head_name_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_j2g_world_head_name_A) Ctor() {}
//line :110:1
func (t *A_arbace_j2g_world_head_name_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_1215 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = f__0; if linked_1216 == nil { and__1927000168__auto____2 = ifn_1217.Invoke_O__O(arg_1218) } else { and__1927000168__auto____2 = linked_1216.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1215, arg_1218) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1219 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any; var root_1223 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any = f__0; if linked_1224 == nil { arg_1222 = ifn_1225.Invoke_O__O(arg_1226) } else { arg_1222 = linked_1224.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1223, arg_1226) }; if linked_1220 == nil { tmp1 = ifn_1221.Invoke_O__O(arg_1222) } else { tmp1 = linked_1220.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1219, arg_1222) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_1227 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any; var root_1231 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = f__0; if linked_1232 == nil { arg_1230 = ifn_1233.Invoke_O__O(arg_1234) } else { arg_1230 = linked_1232.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1231, arg_1234) }; if linked_1228 == nil { return ifn_1229.Invoke_O__O(arg_1230) } else { return linked_1228.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1227, arg_1230) } } else { return nil } }

func A_arbace_j2g_world_param_key_A_New() *A_arbace_j2g_world_param_key_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_j2g_world_param_key_A) Ctor() {}
//line :112:1
func (t *A_arbace_j2g_world_param_key_A) Invoke_O_O__O(self, f__0 any) any { var h__2 any; var root_1235 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1237 lang.IFn; if


	linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = f__0; if linked_1236 == nil { h__2 = ifn_1237.Invoke_O__O(arg_1238) } else { h__2 = linked_1236.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1235, arg_1238) }; var G__78000134__3_ any = h__2; switch
	lang.Util_Hash_O__I_NoInit(G__78000134__3_) >> 17 & 15 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_123) { var vec__78000135__4 any = f__0; var seq__78000136__5 any; var root_1240 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1242 lang.IFn

		if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = vec__78000135__4; if linked_1241 == nil { seq__78000136__5 = ifn_1242.Invoke_O__O(arg_1243) } else { seq__78000136__5 = linked_1241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1240, arg_1243) }
//line :116:1
		var first__78000137__6 any; var root_1244 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1246 lang.IFn

		if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = seq__78000136__5; if linked_1245 == nil { first__78000137__6 = ifn_1246.Invoke_O__O(arg_1247) } else { first__78000137__6 = linked_1245.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1244, arg_1247) }
//line :116:1
		var seq__78000136__7 any; var root_1248 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1250 lang.IFn

		if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = seq__78000136__5; if linked_1249 == nil { seq__78000136__7 = ifn_1250.Invoke_O__O(arg_1251) } else { seq__78000136__7 = linked_1249.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1248, arg_1251) }
//line :116:1
		var ___8 any = first__78000137__6; var first__78000137__9 any; var root_1252 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1254 lang.IFn; _ = ___8

		if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = seq__78000136__7; if linked_1253 == nil { first__78000137__9 = ifn_1254.Invoke_O__O(arg_1255) } else { first__78000137__9 = linked_1253.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1252, arg_1255) }
//line :116:1
		var seq__78000136__10 any; var root_1256 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1258 lang.IFn

		if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = seq__78000136__7; if linked_1257 == nil { seq__78000136__10 = ifn_1258.Invoke_O__O(arg_1259) } else { seq__78000136__10 = linked_1257.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1256, arg_1259) }
//line :116:1
		var nm__11 any = first__78000137__9; var more__12 any = seq__78000136__10; var more__13 any; var tmp1 any = A_arbace_j2g_world_param_key_fn__78000138_A_New_O(more__12); var tmp2 *jrt.Class
		var fncls__1286 /*line :116:1*/*jrt.Class = A_arbace_j2g_world_param_key_fn__78000138_A_fn_class



		if fncls__1286 == nil { var fncls__1286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_j2g_world_param_key_fn__78000138_A_fn_class = fncls__1286d; tmp2 = fncls__1286d } else { tmp2 = fncls__1286 }; more__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :116:1
		var params__14 any; var root_1287 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1289 lang.IFn







		if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any; var root_1291 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var arg_1295 any = more__13; if linked_1292 == nil { arg_1290 = ifn_1293.Invoke_O_O__O(arg_1294, arg_1295) } else { arg_1290 = linked_1292.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1291, arg_1294, arg_1295) }; if linked_1288 == nil { params__14 = ifn_1289.Invoke_O__O(arg_1290) } else { params__14 = linked_1288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1287, arg_1290) }
//line :116:1
		var tmp3 *lang.Keyword = A_arbace_j2g_world_A_const_104; var static__15 bool = lang.RT_BooleanCast_O__Z_NoInit(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__11))); var ps__16 any









		if static__15 { ps__16 = params__14 } else { var root_1296 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = params__14; if linked_1297 == nil { ps__16 = ifn_1298.Invoke_O__O(arg_1299) } else { ps__16 = linked_1297.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1296, arg_1299) } }
//line :116:1
		var tmp4 any = A_arbace_j2g_world_A_const_105; var tmp5 any; var root_1413 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1415 lang.IFn










		if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = nm__11; if linked_1414 == nil { tmp5 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp5 = linked_1414.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1413, arg_1416) }
//line :116:1
		var tmp6 any = tmp5; var tmp7 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(static__15).Ref(); var tmp8 any; var root_1417 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1419 lang.IFn










		if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any; var tmp9 any = A_arbace_j2g_world_param_key_fn__78000140_A_New(); var tmp10 *jrt.Class; var fncls__1426 *jrt.Class = A_arbace_j2g_world_param_key_fn__78000140_A_fn_class; if fncls__1426 == nil { var fncls__1426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_j2g_world_param_key_fn__78000140_A_fn_class = fncls__1426d; tmp10 = fncls__1426d } else { tmp10 = fncls__1426 }; arg_1420 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1421 any = ps__16; if linked_1418 == nil { tmp8 = ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { tmp8 = linked_1418.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }
//line :116:1
		return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp4, tmp6, tmp7, tmp8) }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_126) { var vec__78000143__4 any = f__0; var seq__78000144__5 any; var root_1300 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1302 lang.IFn

			if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = vec__78000143__4; if linked_1301 == nil { seq__78000144__5 = ifn_1302.Invoke_O__O(arg_1303) } else { seq__78000144__5 = linked_1301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1300, arg_1303) }
//line :116:1
			var first__78000145__6 any; var root_1304 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1306 lang.IFn

			if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = seq__78000144__5; if linked_1305 == nil { first__78000145__6 = ifn_1306.Invoke_O__O(arg_1307) } else { first__78000145__6 = linked_1305.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1304, arg_1307) }
//line :116:1
			var seq__78000144__7 any; var root_1308 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1310 lang.IFn

			if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = seq__78000144__5; if linked_1309 == nil { seq__78000144__7 = ifn_1310.Invoke_O__O(arg_1311) } else { seq__78000144__7 = linked_1309.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1308, arg_1311) }
//line :116:1
			var ___8_2 any = first__78000145__6; var first__78000145__9 any; var root_1312 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1314 lang.IFn; _ = ___8_2

			if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = seq__78000144__7; if linked_1313 == nil { first__78000145__9 = ifn_1314.Invoke_O__O(arg_1315) } else { first__78000145__9 = linked_1313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1312, arg_1315) }
//line :116:1
			var seq__78000144__10 any; var root_1316 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1318 lang.IFn

			if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = seq__78000144__7; if linked_1317 == nil { seq__78000144__10 = ifn_1318.Invoke_O__O(arg_1319) } else { seq__78000144__10 = linked_1317.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1316, arg_1319) }
//line :116:1
			var nm__11_2 any = first__78000145__9; var more__12_2 any = seq__78000144__10; var more__13_2 any; var tmp11 any = A_arbace_j2g_world_param_key_fn__78000146_A_New_O(more__12_2); var tmp12 *jrt.Class
			var fncls__1346 /*line :116:1*/*jrt.Class = A_arbace_j2g_world_param_key_fn__78000146_A_fn_class



			if fncls__1346 == nil { var fncls__1346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_j2g_world_param_key_fn__78000146_A_fn_class = fncls__1346d; tmp12 = fncls__1346d } else { tmp12 = fncls__1346 }; more__13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :116:1
			var params__14_2 any; var root_1347 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1349 lang.IFn







			if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any; var root_1351 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var arg_1355 any = more__13_2; if linked_1352 == nil { arg_1350 = ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { arg_1350 = linked_1352.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) }; if linked_1348 == nil { params__14_2 = ifn_1349.Invoke_O__O(arg_1350) } else { params__14_2 = linked_1348.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1347, arg_1350) }
//line :116:1
			var tmp13 *lang.Keyword = A_arbace_j2g_world_A_const_104; var static__15_2 bool = lang.RT_BooleanCast_O__Z_NoInit(tmp13.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__11_2))); var ps__16_2 any









			if static__15_2 { ps__16_2 = params__14_2 } else { var root_1356 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = params__14_2; if linked_1357 == nil { ps__16_2 = ifn_1358.Invoke_O__O(arg_1359) } else { ps__16_2 = linked_1357.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1356, arg_1359) } }
//line :116:1
			var tmp14 any = A_arbace_j2g_world_A_const_105; var tmp15 any; var root_1427 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1429 lang.IFn










			if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = nm__11_2; if linked_1428 == nil { tmp15 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp15 = linked_1428.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1427, arg_1430) }
//line :116:1
			var tmp16 any = tmp15; var tmp17 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(static__15_2).Ref(); var tmp18 any; var root_1431 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1433 lang.IFn










			if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any; var tmp19 any = A_arbace_j2g_world_param_key_fn__78000148_A_New(); var tmp20 *jrt.Class; var fncls__1440 *jrt.Class = A_arbace_j2g_world_param_key_fn__78000148_A_fn_class; if fncls__1440 == nil { var fncls__1440d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_j2g_world_param_key_fn__78000148_A_fn_class = fncls__1440d; tmp20 = fncls__1440d } else { tmp20 = fncls__1440 }; arg_1434 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_1435 any = ps__16_2; if linked_1432 == nil { tmp18 = ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { tmp18 = linked_1432.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) }
//line :116:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, tmp18) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_19) { var nm__4 any; var root_1360 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1362 lang.IFn

















				if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any; var root_1364 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var arg_1368 any; var root_1369 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = f__0; if linked_1370 == nil { arg_1368 = ifn_1371.Invoke_O__O(arg_1372) } else { arg_1368 = linked_1370.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1369, arg_1372) }; if linked_1365 == nil { arg_1363 = ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { arg_1363 = linked_1365.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) }; if linked_1361 == nil { nm__4 = ifn_1362.Invoke_O__O(arg_1363) } else { nm__4 = linked_1361.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1360, arg_1363) }
//line :116:1
				var tmp21 any = A_arbace_j2g_world_A_const_107; var tmp22 any; var root_1441 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1443 lang.IFn

















				if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = nm__4; if linked_1442 == nil { tmp22 = ifn_1443.Invoke_O__O(arg_1444) } else { tmp22 = linked_1442.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1441, arg_1444) }
//line :116:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp22) }; case 9: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_129) { var params__4 any; var root_1373 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1375 lang.IFn












					if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any; var root_1377 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var arg_1381 any; var tmp23 any = A_arbace_j2g_world_param_key_fn__78000151_A_New_O(f__0); var tmp24 *jrt.Class; var fncls__1412 *jrt.Class = A_arbace_j2g_world_param_key_fn__78000151_A_fn_class; if fncls__1412 == nil { var fncls__1412d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_j2g_world_param_key_fn__78000151_A_fn_class = fncls__1412d; tmp24 = fncls__1412d } else { tmp24 = fncls__1412 }; arg_1381 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O(); if linked_1378 == nil { arg_1376 = ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { arg_1376 = linked_1378.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) }; if linked_1374 == nil { params__4 = ifn_1375.Invoke_O__O(arg_1376) } else { params__4 = linked_1374.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1373, arg_1376) }
//line :116:1
					var tmp25 any = A_arbace_j2g_world_A_const_108; var tmp26 any; var root_1445 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1447 lang.IFn
















					if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any; var tmp27 any = A_arbace_j2g_world_param_key_fn__78000153_A_New(); var tmp28 *jrt.Class; var fncls__1454 *jrt.Class = A_arbace_j2g_world_param_key_fn__78000153_A_fn_class; if fncls__1454 == nil { var fncls__1454d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_j2g_world_param_key_fn__78000153_A_fn_class = fncls__1454d; tmp28 = fncls__1454d } else { tmp28 = fncls__1454 }; arg_1448 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_1449 any; var root_1455 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = params__4; if linked_1456 == nil { arg_1449 = ifn_1457.Invoke_O__O(arg_1458) } else { arg_1449 = linked_1456.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1455, arg_1458) }; if linked_1446 == nil { tmp26 = ifn_1447.Invoke_O_O__O(arg_1448, arg_1449) } else { tmp26 = linked_1446.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1445, arg_1448, arg_1449) }
//line :116:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp25, tmp26) }; case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_4) { var tmp29 any = A_arbace_j2g_world_A_const_109; var tmp30 any; var tmp31 *lang.Keyword = A_arbace_j2g_world_A_const_110; var or__1927000174__auto____4 any = tmp31.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0))


















						if jrt.J2g_Truth(or__1927000174__auto____4) { tmp30 = or__1927000174__auto____4 } else { tmp30 = A_arbace_j2g_world_A_const_111 }
//line :116:1
						return lang.Tuple_Create_O_O__IPersistentVector(tmp29, tmp30) }; case 15: if lang.Util_Equiv_O_O__Z_NoInit(G__78000134__3_, Lit_12) { var tmp32 any = A_arbace_j2g_world_A_const_76; var tmp33 any; var root_1459 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1461 lang.IFn



















							if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any; var root_1463 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = f__0; if linked_1464 == nil { arg_1462 = ifn_1465.Invoke_O__O(arg_1466) } else { arg_1462 = linked_1464.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1463, arg_1466) }; if linked_1460 == nil { tmp33 = ifn_1461.Invoke_O__O(arg_1462) } else { tmp33 = linked_1460.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1459, arg_1462) }
//line :116:1
							return lang.Tuple_Create_O_O__IPersistentVector(tmp32, tmp33) }; default:}; return nil }



func A_arbace_j2g_world_param_key_fn__78000138_A_New_O(p0 any) *A_arbace_j2g_world_param_key_fn__78000138_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000138_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_j2g_world_param_key_fn__78000138_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :120:1
func (t *A_arbace_j2g_world_param_key_fn__78000138_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
										var tmp1 any; var root_1260 any = A_arbace_j2g_world_A_const_55.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = xs__1; if linked_1261 == nil { tmp1 = ifn_1262.Invoke_O__O(arg_1263) } else { tmp1 = linked_1261.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1260, arg_1263) }; if jrt.J2g_Truth(tmp1) { return acc__2 } else { var tmp2 any = A_arbace_j2g_world_A_const_102; var tmp3 any; var root_1264 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1266 lang.IFn
											if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = xs__1; if linked_1265 == nil { tmp3 = ifn_1266.Invoke_O__O(arg_1267) } else { tmp3 = linked_1265.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1264, arg_1267) }
//line :121:1
		if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) {
			var tmp4 any; var root_1268 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1272 any = xs__1; if linked_1269 == nil { tmp4 = ifn_1270.Invoke_O_O__O(A_arbace_j2g_world_A_const_103, arg_1272) } else { tmp4 = linked_1269.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1268, 2, A_arbace_j2g_world_A_const_103, arg_1272) }; xs__1, acc__2 = tmp4, acc__2; continue L1 } else {
//line :121:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp5 any; var root_1273 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = xs__1; if linked_1274 == nil { tmp5 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp5 = linked_1274.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1273, arg_1276) }; var tmp6 any = tmp5; var tmp7 any; var root_1277 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = acc__2; var arg_1281 any; var root_1282 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any = xs__1; if linked_1283 == nil { arg_1281 = ifn_1284.Invoke_O__O(arg_1285) } else { arg_1281 = linked_1283.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1282, arg_1285) }; if linked_1278 == nil { tmp7 = ifn_1279.Invoke_O_O__O(arg_1280, arg_1281) } else { tmp7 = linked_1278.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1277, arg_1280, arg_1281) }; xs__1, acc__2 = tmp6, tmp7; continue L1 } else {
//line :121:1
						return nil } } } } }; /*line :120:1*/panic("j2g: unreachable") }
//line :120:1
func A_arbace_j2g_world_param_key_fn__78000146_A_New_O(p0 any) *A_arbace_j2g_world_param_key_fn__78000146_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000146_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_j2g_world_param_key_fn__78000146_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :120:1
func (t *A_arbace_j2g_world_param_key_fn__78000146_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
										var tmp1 any; var root_1320 any = A_arbace_j2g_world_A_const_55.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = xs__1; if linked_1321 == nil { tmp1 = ifn_1322.Invoke_O__O(arg_1323) } else { tmp1 = linked_1321.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1320, arg_1323) }; if jrt.J2g_Truth(tmp1) { return acc__2 } else { var tmp2 any = A_arbace_j2g_world_A_const_102; var tmp3 any; var root_1324 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1326 lang.IFn
											if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = xs__1; if linked_1325 == nil { tmp3 = ifn_1326.Invoke_O__O(arg_1327) } else { tmp3 = linked_1325.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1324, arg_1327) }
//line :121:1
		if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) {
			var tmp4 any; var root_1328 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1332 any = xs__1; if linked_1329 == nil { tmp4 = ifn_1330.Invoke_O_O__O(A_arbace_j2g_world_A_const_103, arg_1332) } else { tmp4 = linked_1329.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1328, 2, A_arbace_j2g_world_A_const_103, arg_1332) }; xs__1, acc__2 = tmp4, acc__2; continue L1 } else {
//line :121:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp5 any; var root_1333 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = xs__1; if linked_1334 == nil { tmp5 = ifn_1335.Invoke_O__O(arg_1336) } else { tmp5 = linked_1334.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1333, arg_1336) }; var tmp6 any = tmp5; var tmp7 any; var root_1337 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = acc__2; var arg_1341 any; var root_1342 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = xs__1; if linked_1343 == nil { arg_1341 = ifn_1344.Invoke_O__O(arg_1345) } else { arg_1341 = linked_1343.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1342, arg_1345) }; if linked_1338 == nil { tmp7 = ifn_1339.Invoke_O_O__O(arg_1340, arg_1341) } else { tmp7 = linked_1338.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1337, arg_1340, arg_1341) }; xs__1, acc__2 = tmp6, tmp7; continue L1 } else {
//line :121:1
						return nil } } } } }; /*line :120:1*/panic("j2g: unreachable") }






func A_arbace_j2g_world_param_key_fn__78000140_A_New() *A_arbace_j2g_world_param_key_fn__78000140_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000140_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_world_param_key_fn__78000140_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_world_param_key_fn__78000140_A) Invoke_O_O__O(self, p1__78000132_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_world_A_const_106; var G__78000141__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__78000132_SHARP___1)); if lang.Util_Identical_O_O__Z_NoInit(G__78000141__2_, nil) { return nil } else { var root_1422 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = G__78000141__2_; if linked_1423 == nil { return ifn_1424.Invoke_O__O(arg_1425) } else { return linked_1423.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1422, arg_1425) } } }
//line :127:1
func A_arbace_j2g_world_param_key_fn__78000148_A_New() *A_arbace_j2g_world_param_key_fn__78000148_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000148_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_world_param_key_fn__78000148_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_world_param_key_fn__78000148_A) Invoke_O_O__O(self, p1__78000132_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_world_A_const_106; var G__78000149__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__78000132_SHARP___1)); if lang.Util_Identical_O_O__Z_NoInit(G__78000149__2_, nil) { return nil } else { var root_1436 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = G__78000149__2_; if linked_1437 == nil { return ifn_1438.Invoke_O__O(arg_1439) } else { return linked_1437.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1436, arg_1439) } } }

func A_arbace_j2g_world_param_key_fn__78000151_A_New_O(p0 any) *A_arbace_j2g_world_param_key_fn__78000151_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000151_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_j2g_world_param_key_fn__78000151_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :129:1
func (t *A_arbace_j2g_world_param_key_fn__78000151_A) Invoke_O__O(self any) any { { var xs__1 any; var root_1382 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any; var t_ any = t.F_f; t.F_f = nil; arg_1385 = t_; if linked_1383 == nil { xs__1 = ifn_1384.Invoke_O__O(arg_1385) } else { xs__1 = linked_1383.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1382, arg_1385) }; var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
										var tmp1 any; var root_1386 any = A_arbace_j2g_world_A_const_55.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = xs__1; if linked_1387 == nil { tmp1 = ifn_1388.Invoke_O__O(arg_1389) } else { tmp1 = linked_1387.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1386, arg_1389) }; if jrt.J2g_Truth(tmp1) { return acc__2 } else { var tmp2 any = A_arbace_j2g_world_A_const_102; var tmp3 any; var root_1390 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1392 lang.IFn
											if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = xs__1; if linked_1391 == nil { tmp3 = ifn_1392.Invoke_O__O(arg_1393) } else { tmp3 = linked_1391.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1390, arg_1393) }
//line :130:1
		if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) {
			var tmp4 any; var root_1394 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1398 any = xs__1; if linked_1395 == nil { tmp4 = ifn_1396.Invoke_O_O__O(A_arbace_j2g_world_A_const_103, arg_1398) } else { tmp4 = linked_1395.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1394, 2, A_arbace_j2g_world_A_const_103, arg_1398) }; xs__1, acc__2 = tmp4, acc__2; continue L1 } else {
//line :130:1
				if A_arbace_j2g_world_A_const_88 != nil {

					var tmp5 any; var root_1399 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = xs__1; if linked_1400 == nil { tmp5 = ifn_1401.Invoke_O__O(arg_1402) } else { tmp5 = linked_1400.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1399, arg_1402) }; var tmp6 any = tmp5; var tmp7 any; var root_1403 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = acc__2; var arg_1407 any; var root_1408 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = xs__1; if linked_1409 == nil { arg_1407 = ifn_1410.Invoke_O__O(arg_1411) } else { arg_1407 = linked_1409.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1408, arg_1411) }; if linked_1404 == nil { tmp7 = ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { tmp7 = linked_1404.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) }; xs__1, acc__2 = tmp6, tmp7; continue L1 } else {
//line :130:1
						return nil } } } } }; /*line :129:1*/panic("j2g: unreachable") }



func A_arbace_j2g_world_param_key_fn__78000153_A_New() *A_arbace_j2g_world_param_key_fn__78000153_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_param_key_fn__78000153_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_j2g_world_param_key_fn__78000153_A) Ctor() {}
//line :133:1
func (t *A_arbace_j2g_world_param_key_fn__78000153_A) Invoke_O_O__O(self, p1__78000133_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_world_A_const_106; var G__78000154__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__78000133_SHARP___1)); if lang.Util_Identical_O_O__Z_NoInit(G__78000154__2_, nil) { return nil } else { var root_1450 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = G__78000154__2_; if linked_1451 == nil { return ifn_1452.Invoke_O__O(arg_1453) } else { return linked_1451.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1450, arg_1453) } } }





func A_arbace_j2g_world_cut_key_A_New() *A_arbace_j2g_world_cut_key_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_cut_key_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_world_cut_key_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_world_cut_key_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1467 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1469 lang.IFn
	if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = x__0; if linked_1468 == nil { and__1927000168__auto____2 = ifn_1469.Invoke_O__O(arg_1470) } else { and__1927000168__auto____2 = linked_1468.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1467, arg_1470) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_1471 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = x__0; if linked_1472 == nil { tmp2 = ifn_1473.Invoke_O__O(arg_1474) } else { tmp2 = linked_1472.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1471, arg_1474) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_19, tmp2)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :140:1
	if jrt.J2g_Truth(tmp1) {
		var root_1475 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = x__0; if linked_1476 == nil { return ifn_1477.Invoke_O__O(arg_1478) } else { return linked_1476.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1475, arg_1478) } } else {
//line :140:1
			var tmp3 any; var and__1927000168__auto____2_2 any; var root_1479 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1481 lang.IFn


			if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = x__0; if linked_1480 == nil { and__1927000168__auto____2_2 = ifn_1481.Invoke_O__O(arg_1482) } else { and__1927000168__auto____2_2 = linked_1480.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1479, arg_1482) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp4 any; var root_1483 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = x__0; if linked_1484 == nil { tmp4 = ifn_1485.Invoke_O__O(arg_1486) } else { tmp4 = linked_1484.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1483, arg_1486) }; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_4, tmp4)).Ref() } else { tmp3 = and__1927000168__auto____2_2 }
//line :140:1
			if jrt.J2g_Truth(tmp3) { var tmp5 any = A_arbace_j2g_world_A_const_109; var tmp6 any; var or__1927000174__auto____2 any; var root_1513 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1515 lang.IFn


				if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = x__0; if linked_1514 == nil { or__1927000174__auto____2 = ifn_1515.Invoke_O__O(arg_1516) } else { or__1927000174__auto____2 = linked_1514.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1513, arg_1516) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp6 = or__1927000174__auto____2 } else { tmp6 = A_arbace_j2g_world_A_const_111 }
//line :140:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6) } else { var tmp7 any; var root_1487 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1489 lang.IFn



					if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any; var root_1491 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = x__0; if linked_1492 == nil { arg_1490 = ifn_1493.Invoke_O__O(arg_1494) } else { arg_1490 = linked_1492.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1491, arg_1494) }; if linked_1488 == nil { tmp7 = ifn_1489.Invoke_O__O(arg_1490) } else { tmp7 = linked_1488.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1487, arg_1490) }
//line :140:1
					if jrt.J2g_Truth(tmp7) {



						var root_1495 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any; var root_1499 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = A_arbace_j2g_world_A_const_113; var arg_1503 any = x__0; if linked_1500 == nil { arg_1498 = ifn_1501.Invoke_O_O__O(arg_1502, arg_1503) } else { arg_1498 = linked_1500.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1499, arg_1502, arg_1503) }; if linked_1496 == nil { return ifn_1497.Invoke_O__O(arg_1498) } else { return linked_1496.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1495, arg_1498) } } else {
//line :140:1
							if A_arbace_j2g_world_A_const_88 != nil { var tmp8 any; var root_1504 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1506 lang.IFn




								if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_world_A_const_79.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var arg_1508 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1505 == nil { tmp8 = ifn_1506.Invoke_O_O__O(arg_1507, arg_1508) } else { tmp8 = linked_1505.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1504, arg_1507, arg_1508) }
//line :140:1
								panic(jrt.Thrown(jrt.Throwable_Cast(tmp8))) } else { return nil
								}
						}
				}
		}
}

func A_arbace_j2g_world_class_parts_A_New() *A_arbace_j2g_world_class_parts_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_class_parts_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_j2g_world_class_parts_A) Ctor() {}
//line :147:1
func (t *A_arbace_j2g_world_class_parts_A) Invoke_O_O__O(self, cf__0 any) any { var vec__78000158__2 any = cf__0; var seq__78000159__3 any; var root_1517 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1519 lang.IFn; if


	linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = vec__78000158__2; if linked_1518 == nil { seq__78000159__3 = ifn_1519.Invoke_O__O(arg_1520) } else { seq__78000159__3 = linked_1518.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1517, arg_1520) }; var first__78000160__4 any; var root_1521 any = /*line :147:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1523 lang.IFn; if


	linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = seq__78000159__3; if linked_1522 == nil { first__78000160__4 = ifn_1523.Invoke_O__O(arg_1524) } else { first__78000160__4 = linked_1522.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1521, arg_1524) }; var seq__78000159__5 any; var root_1525 any = /*line :147:1*/A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1527 lang.IFn; if


	linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = seq__78000159__3; if linked_1526 == nil { seq__78000159__5 = ifn_1527.Invoke_O__O(arg_1528) } else { seq__78000159__5 = linked_1526.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1525, arg_1528) }; var dc__6 any = first__78000160__4; var first__78000160__7 any; var root_1529 any = /*line :147:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1531 lang.IFn; if


	linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any = seq__78000159__5; if linked_1530 == nil { first__78000160__7 = ifn_1531.Invoke_O__O(arg_1532) } else { first__78000160__7 = linked_1530.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1529, arg_1532) }; var seq__78000159__8 any; var root_1533 any = /*line :147:1*/A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1535 lang.IFn; if


	linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = seq__78000159__5; if linked_1534 == nil { seq__78000159__8 = ifn_1535.Invoke_O__O(arg_1536) } else { seq__78000159__8 = linked_1534.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1533, arg_1536) }; var nm__9 any = first__78000160__7; var more__10 any = seq__78000159__8; var vec__78000161__11 any; var tmp1 any; var root_1537 any = /*line :147:1*/A_arbace_j2g_world_A_const_82.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1539 lang.IFn; if



	linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any; var root_1541 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = more__10; if linked_1542 == nil { arg_1540 = ifn_1543.Invoke_O__O(arg_1544) } else { arg_1540 = linked_1542.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1541, arg_1544) }; if linked_1538 == nil { tmp1 = ifn_1539.Invoke_O__O(arg_1540) } else { tmp1 = linked_1538.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1537, arg_1540) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1553 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = more__10; if linked_1554 == nil { tmp2 = ifn_1555.Invoke_O__O(arg_1556) } else { tmp2 = linked_1554.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1553, arg_1556) }; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(tmp2); var tmp4 any; var root_1549 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = more__10; if linked_1550 == nil { tmp4 = ifn_1551.Invoke_O__O(arg_1552) } else { tmp4 = linked_1550.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1549, arg_1552) }; vec__78000161__11 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { vec__78000161__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.PersistentVector_EMPTY.Ref(), more__10) }; var comps__12 any = /*line :147:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__78000161__11, lang.RT_IntCast_J__I_NoInit(0), nil); var more__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000161__11, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__78000164__14 any; var root_1545 any = A_arbace_j2g_world_A_const_84.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A_fn_class); var ifn_1547 lang.IFn; if




	linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = more__13; if linked_1546 == nil { vec__78000164__14 = ifn_1547.Invoke_O__O(arg_1548) } else { vec__78000164__14 = linked_1546.(*aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A).Invoke_O_O__O(root_1545, arg_1548) }; var opts__15 any = /*line :147:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__78000164__14, lang.RT_IntCast_J__I_NoInit(0), nil); var members__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000164__14, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(dc__6, nm__9), comps__12, lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_world_A_const_114.GetRawRoot__O(), opts__15)); var tmp6 any; var root_1568 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1570 lang.IFn; if





	linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = members__16; if linked_1569 == nil { tmp6 = ifn_1570.Invoke_O__O(arg_1571) } else { tmp6 = linked_1569.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1568, arg_1571) }; return /*line :147:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6) }







func A_arbace_j2g_world_apply_variant_A_New() *A_arbace_j2g_world_apply_variant_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_j2g_world_apply_variant_A) Ctor() {}
//line :155:1
func (t *A_arbace_j2g_world_apply_variant_A) Invoke_O_O_O_O_O_O__O(self, cf__0, vforms__1, prefix__2, variants_of__3, applied__4 any) any { var vec__78000170__6 any; var root_1572 any = A_arbace_j2g_world_A_const_115.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, A_arbace_j2g_world_class_parts_A_fn_class); var ifn_1574 lang.IFn; if







	linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = cf__0; if linked_1573 == nil { vec__78000170__6 = ifn_1574.Invoke_O__O(arg_1575) } else { vec__78000170__6 = linked_1573.(*A_arbace_j2g_world_class_parts_A).Invoke_O_O__O(root_1572, arg_1575) }; var head__7 any = /*line :155:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__78000170__6, lang.RT_IntCast_J__I_NoInit(0), nil); var members__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000170__6, lang.RT_IntCast_J__I_NoInit(1), nil); var members__9 any; var n__9 any; var root_1576 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1578 lang.IFn; if









	linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = A_arbace_j2g_world_A_const_116; if linked_1577 == nil { n__9 = ifn_1578.Invoke_O__O(arg_1579) } else { n__9 = linked_1577.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1576, arg_1579) }; var root_1580 any =
	A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any; var tmp1 any = A_arbace_j2g_world_apply_variant_fn__78000173_A_New_O(n__9); var tmp2 *jrt.Class; var fncls__1601 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000173_A_fn_class; if fncls__1601 == nil { var fncls__1601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_j2g_world_apply_variant_fn__78000173_A_fn_class = fncls__1601d; tmp2 = fncls__1601d } else { tmp2 = fncls__1601 }; arg_1583 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1584 any = members__8; if linked_1581 == nil { members__9 = ifn_1582.Invoke_O_O__O(arg_1583, arg_1584) } else { members__9 = linked_1581.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1580, arg_1583, arg_1584) }; var counts__10 any; var root_1602 any = /*line :155:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1604 lang.IFn; if














	linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = A_arbace_j2g_world_A_const_120; if linked_1603 == nil { counts__10 = ifn_1604.Invoke_O__O(arg_1605) } else { counts__10 = linked_1603.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1602, arg_1605) }; var members__11 any; var root_1606 any = /*line :155:1*/A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1608 lang.IFn; if















	linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any; var tmp3 any = A_arbace_j2g_world_apply_variant_fn__78000175_A_New_O(counts__10); var tmp4 *jrt.Class; var fncls__1737 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000175_A_fn_class; if
	fncls__1737 == nil { var fncls__1737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_world_apply_variant_fn__78000175_A_fn_class = fncls__1737d; tmp4 = fncls__1737d } else { tmp4 = fncls__1737 }; arg_1609 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1610 any = members__9; var arg_1611 any = vforms__1; if /*line :171:1*/ linked_1607 == nil { members__11 = ifn_1608.Invoke_O_O_O__O(arg_1609, arg_1610, arg_1611) } else { members__11 = linked_1607.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1606, arg_1609, arg_1610, arg_1611) }; var members__12 any; if

















	jrt.J2g_Truth(variants_of__3) {
		var root_1738 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any; var tmp5 any = A_arbace_j2g_world_apply_variant_fn__78000184_A_New_O_O_O(variants_of__3, prefix__2, applied__4); var tmp6 *jrt.Class; var fncls__1770 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000184_A_fn_class; if fncls__1770 == nil { var fncls__1770d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_world_apply_variant_fn__78000184_A_fn_class = fncls__1770d; tmp6 = fncls__1770d } else { tmp6 = fncls__1770 }; arg_1741 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1742 any = members__11; if linked_1739 == nil { members__12 = ifn_1740.Invoke_O_O__O(arg_1741, arg_1742) } else { members__12 = linked_1739.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1738, arg_1741, arg_1742) } } else {
//line :189:1
			members__12 = members__11 }; var tmp7 any; var root_1771 any = /*line :155:1*/A_arbace_j2g_world_A_const_67.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1773 lang.IFn; if












































	linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any; var root_1776 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1776, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1778 lang.IFn; if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = A_arbace_j2g_world_A_const_69.GetRawRoot__O(); var arg_1780 any; var root_1781 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = head__7; var arg_1785 any = members__12; if linked_1782 == nil { arg_1780 = ifn_1783.Invoke_O_O__O(arg_1784, arg_1785) } else { arg_1780 = linked_1782.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1781, arg_1784, arg_1785) }; if linked_1777 == nil { arg_1774 = ifn_1778.Invoke_O_O__O(arg_1779, arg_1780) } else { arg_1774 = linked_1777.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1776, arg_1779, arg_1780) }; var arg_1775 any = lang.RT_Meta_O__IPersistentMap_NoInit(cf__0); if linked_1772 == nil { tmp7 = ifn_1773.Invoke_O_O__O(arg_1774, arg_1775) } else { tmp7 = linked_1772.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1771, arg_1774, arg_1775) }; var tmp8 any = tmp7; var tmp9 any; var root_1786 any = /*line :155:1*/A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1788 lang.IFn; if







	linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = counts__10; if linked_1787 == nil { tmp9 = ifn_1788.Invoke_O__O(arg_1789) } else { tmp9 = linked_1787.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1786, arg_1789) }; return /*line :155:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) }
//line :155:1
func (t *A_arbace_j2g_world_apply_variant_A) Invoke_O_O_O__O(self, cf__0, vforms__1 any) any {





	var root_1790 any = A_arbace_j2g_world_A_const_128.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, A_arbace_j2g_world_apply_variant_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = cf__0; var arg_1794 any = vforms__1; var arg_1795 any; var arg_1796 any; var arg_1797 any; if linked_1791 == nil { return ifn_1792.Invoke_O_O_O_O_O__O(arg_1793, arg_1794, arg_1795, arg_1796, arg_1797) } else { return linked_1791.(*A_arbace_j2g_world_apply_variant_A).Invoke_O_O_O_O_O_O__O(root_1790, arg_1793, arg_1794, arg_1795, arg_1796, arg_1797)
	}
}


func A_arbace_j2g_world_apply_variant_fn__78000173_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000173_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000173_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000173_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :166:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000173_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any; var root_1585 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = m__1; if linked_1586 == nil { tmp1 = ifn_1587.Invoke_O__O(arg_1588) } else { tmp1 = linked_1586.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1585, arg_1588) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_4, tmp1) {
												var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_117.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var tmp4 any = A_arbace_j2g_world_A_const_110; var tmp5 any; var root_1596 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = t.F_n; var arg_1600 any = A_arbace_j2g_world_A_const_119.GetRawRoot__O(); if linked_1597 == nil { tmp5 = ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { tmp5 = linked_1597.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) }; return tmp2.Invoke_O_O_O_O__O(m__1, tmp3, tmp4, tmp5) } else {
//line :166:1
		return m__1 } }





func A_arbace_j2g_world_apply_variant_fn__78000175_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000175_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000175_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_A) Ctor_O(c__counts any) { t.F_counts = c__counts }
//line :172:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_A) Invoke_O_O_O__O(self, ms__1, vf__2 any) any { var G__78000176__3_ any; var root_1612 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1614 lang.IFn; if
													linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = vf__2; if linked_1613 == nil { G__78000176__3_ = ifn_1614.Invoke_O__O(arg_1615) } else { G__78000176__3_ = linked_1613.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1612, arg_1615) }; switch lang.Util_Hash_O__I_NoInit(G__78000176__3_) { case 96417: if lang.Util_Equiv_O_O__Z_NoInit(G__78000176__3_, Lit_5) {







		var root_1694 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1694, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any = t.F_counts; var arg_1698 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var arg_1699 any = A_arbace_j2g_world_A_const_125; var arg_1700 any = A_arbace_j2g_world_A_const_119.GetRawRoot__O(); if linked_1695 == nil { ifn_1696.Invoke_O_O_O_O__O(arg_1697, arg_1698, arg_1699, arg_1700) } else { linked_1695.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1694, arg_1697, arg_1698, arg_1699, arg_1700) }; var root_1617 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = ms__1; var arg_1621 any; var root_1622 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = vf__2; if linked_1623 == nil { arg_1621 = ifn_1624.Invoke_O__O(arg_1625) } else { arg_1621 = linked_1623.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1622, arg_1625) }; if linked_1618 == nil { return ifn_1619.Invoke_O_O__O(arg_1620, arg_1621) } else { return linked_1618.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1617, arg_1620, arg_1621) } }
//line :173:1
	case 98882: if lang.Util_Equiv_O_O__Z_NoInit(G__78000176__3_, Lit_6) { var k__4 any; var root_1626 any = A_arbace_j2g_world_A_const_122.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, A_arbace_j2g_world_cut_key_A_fn_class); var ifn_1628 lang.IFn


		if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any; var tmp1 any; var root_1630 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any; var root_1634 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1636 lang.IFn; if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = vf__2; if linked_1635 == nil { arg_1633 = ifn_1636.Invoke_O__O(arg_1637) } else { arg_1633 = linked_1635.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1634, arg_1637) }; if linked_1631 == nil { tmp1 = ifn_1632.Invoke_O__O(arg_1633) } else { tmp1 = linked_1631.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1630, arg_1633) }; if jrt.J2g_Truth(tmp1) { var root_1638 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1640 lang.IFn; if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = vf__2; if linked_1639 == nil { arg_1629 = ifn_1640.Invoke_O__O(arg_1641) } else { arg_1629 = linked_1639.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1638, arg_1641) } } else { var root_1642 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = vf__2; if linked_1643 == nil { arg_1629 = ifn_1644.Invoke_O__O(arg_1645) } else { arg_1629 = linked_1643.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1642, arg_1645) } }; if linked_1627 == nil { k__4 = ifn_1628.Invoke_O__O(arg_1629) } else { k__4 = linked_1627.(*A_arbace_j2g_world_cut_key_A).Invoke_O_O__O(root_1626, arg_1629) }
//line :173:1
		var hit__5 any; var root_1646 any = A_arbace_j2g_world_A_const_123.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1648 lang.IFn



		if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any; var tmp2 any = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_New_O(k__4); var tmp3 *jrt.Class; var fncls__1655 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_fn_class; if fncls__1655 == nil { var fncls__1655d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_fn_class = fncls__1655d; tmp3 = fncls__1655d } else { tmp3 = fncls__1655 }; arg_1649 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1650 any = ms__1; if linked_1647 == nil { hit__5 = ifn_1648.Invoke_O_O__O(arg_1649, arg_1650) } else { hit__5 = linked_1647.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1646, arg_1649, arg_1650) }
		if jrt.J2g_Truth(hit__5) { } else { var tmp4 any; var root_1701 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_8, nil); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_79.GetRawRoot__O()); var tmp7 any; var root_1710 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = vf__2; if linked_1711 == nil { tmp7 = ifn_1712.Invoke_O__O(arg_1713) } else { tmp7 = linked_1711.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1710, arg_1713) }; arg_1704 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6.Invoke_O__O(tmp7))).Ref(); var arg_1705 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1702 == nil { tmp4 = ifn_1703.Invoke_O_O__O(arg_1704, arg_1705) } else { tmp4 = linked_1702.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1701, arg_1704, arg_1705) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) }
		var root_1714 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any = t.F_counts; var arg_1718 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var arg_1719 any = A_arbace_j2g_world_A_const_126; var arg_1720 any = A_arbace_j2g_world_A_const_119.GetRawRoot__O(); if linked_1715 == nil { ifn_1716.Invoke_O_O_O_O__O(arg_1717, arg_1718, arg_1719, arg_1720) } else { linked_1715.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1714, arg_1717, arg_1718, arg_1719, arg_1720) }
		var root_1656 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any; var root_1660 any = A_arbace_j2g_world_A_const_77.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any; var tmp8 any = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_New_O(k__4); var tmp9 *jrt.Class; var fncls__1669 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_fn_class; if fncls__1669 == nil { var fncls__1669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_fn_class = fncls__1669d; tmp9 = fncls__1669d } else { tmp9 = fncls__1669 }; arg_1663 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_1664 any = ms__1; if linked_1661 == nil { arg_1659 = ifn_1662.Invoke_O_O__O(arg_1663, arg_1664) } else { arg_1659 = linked_1661.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1660, arg_1663, arg_1664) }; if linked_1657 == nil { return ifn_1658.Invoke_O__O(arg_1659) } else { return linked_1657.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1656, arg_1659) } }
//line :173:1
	default:}; var k__4_2 any; var root_1670 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1672 lang.IFn; if








	linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = vf__2; if linked_1671 == nil { k__4_2 = ifn_1672.Invoke_O__O(arg_1673) } else { k__4_2 = linked_1671.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1670, arg_1673) }; var i__5 any; var root_1674 any = /*line :173:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1676 lang.IFn; if









	linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any; var root_1678 any = A_arbace_j2g_world_A_const_124.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any; var tmp10 any = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_New_O(k__4_2); var tmp11 *jrt.Class; var fncls__1687 *jrt.Class = A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_fn_class; if fncls__1687 == nil { var fncls__1687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_fn_class = fncls__1687d; tmp11 = fncls__1687d } else { tmp11 = fncls__1687 }; arg_1681 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1682 any = ms__1; if linked_1679 == nil { arg_1677 = ifn_1680.Invoke_O_O__O(arg_1681, arg_1682) } else { arg_1677 = linked_1679.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_1678, arg_1681, arg_1682) }; if linked_1675 == nil { i__5 = ifn_1676.Invoke_O__O(arg_1677) } else { i__5 = linked_1675.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1674, arg_1677) }; if
	jrt.J2g_Truth(i__5) { } else { var tmp12 any; var root_1721 any = A_arbace_j2g_world_A_const_75.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_world_A_const_79.GetRawRoot__O()).Invoke_O__O(k__4_2))).Ref(); var arg_1725 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1722 == nil { tmp12 = ifn_1723.Invoke_O_O__O(arg_1724, arg_1725) } else { tmp12 = linked_1722.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1721, arg_1724, arg_1725) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp12))) }; var root_1730 any =
	A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = t.F_counts; var arg_1734 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var arg_1735 any = A_arbace_j2g_world_A_const_127; var arg_1736 any = A_arbace_j2g_world_A_const_119.GetRawRoot__O(); if linked_1731 == nil { ifn_1732.Invoke_O_O_O_O__O(arg_1733, arg_1734, arg_1735, arg_1736) } else { linked_1731.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1730, arg_1733, arg_1734, arg_1735, arg_1736) }; var root_1688 any =
	A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = ms__1; var arg_1692 any = i__5; var arg_1693 any = vf__2; if linked_1689 == nil { return ifn_1690.Invoke_O_O_O__O(arg_1691, arg_1692, arg_1693) } else { return linked_1689.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1688, arg_1691, arg_1692, arg_1693) } }
//line :177:1
func A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :177:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A) Invoke_O_O__O(self, p1__78000168_SHARP___1 any) any { var tmp1 any = t.F_k; var tmp2 any; var root_1651 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1653 lang.IFn; if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any = p1__78000168_SHARP___1; if linked_1652 == nil { tmp2 = ifn_1653.Invoke_O__O(arg_1654) } else { tmp2 = linked_1652.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1651, arg_1654) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }


func A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :180:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A) Invoke_O_O__O(self, p1__78000169_SHARP___1 any) any { var tmp1 any = t.F_k; var tmp2 any; var root_1665 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = p1__78000169_SHARP___1; if linked_1666 == nil { tmp2 = ifn_1667.Invoke_O__O(arg_1668) } else { tmp2 = linked_1666.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1665, arg_1668) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }


func A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_New_O(p0 any) *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :183:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A) Invoke_O_O_O__O(self, i__1, m__2 any) any { var tmp1 any = t.F_k; var tmp2 any; var root_1683 any = A_arbace_j2g_world_A_const_112.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, A_arbace_j2g_world_param_key_A_fn_class); var ifn_1685 lang.IFn; if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any = m__2; if linked_1684 == nil { tmp2 = ifn_1685.Invoke_O__O(arg_1686) } else { tmp2 = linked_1684.(*A_arbace_j2g_world_param_key_A).Invoke_O_O__O(root_1683, arg_1686) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { return i__1 } else { return nil } }






func A_arbace_j2g_world_apply_variant_fn__78000184_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_apply_variant_fn__78000184_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_apply_variant_fn__78000184_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :190:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000184_A) Ctor_O_O_O(c__variants_of, c__prefix, c__applied any) { t.F_variants_of = c__variants_of; t.F_prefix = c__prefix; t.F_applied = c__applied }
//line :190:1
func (t *A_arbace_j2g_world_apply_variant_fn__78000184_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var root_1743 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1743, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1745 lang.IFn; if linked_1744 == nil { ifn_1745 = lang.IFn_Cast(root_1743) } else { ifn_1745 = nil }; var arg_1746 any = m__1; if linked_1744 == nil { tmp1 = ifn_1745.Invoke_O__O(arg_1746) } else { tmp1 = linked_1744.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1743, arg_1746) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_12, tmp1) { var nn__2 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil); var tmp3 any = t.F_prefix; var tmp4 any; var root_1747 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1749 lang.IFn
		if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any; var root_1751 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1753 lang.IFn; if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = m__1; if linked_1752 == nil { arg_1750 = ifn_1753.Invoke_O__O(arg_1754) } else { arg_1750 = linked_1752.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1751, arg_1754) }; if linked_1748 == nil { tmp4 = ifn_1749.Invoke_O__O(arg_1750) } else { tmp4 = linked_1748.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1747, arg_1750) }; nn__2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()
//line :191:1
		var vfs__3 any = lang.IFn_Cast(t.F_variants_of).Invoke_O__O(nn__2); var vec__78000185__4 any; var root_1755 any = A_arbace_j2g_world_A_const_128.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, A_arbace_j2g_world_apply_variant_A_fn_class); var ifn_1757 lang.IFn


		if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = m__1; var arg_1759 any; var or__1927000174__auto____4 any = vfs__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_1759 = or__1927000174__auto____4 } else { arg_1759 = lang.PersistentVector_EMPTY.Ref() }; var arg_1760 any = nn__2; var arg_1761 any = t.F_variants_of; var arg_1762 any = t.F_applied; if linked_1756 == nil { vec__78000185__4 = ifn_1757.Invoke_O_O_O_O_O__O(arg_1758, arg_1759, arg_1760, arg_1761, arg_1762) } else { vec__78000185__4 = linked_1756.(*A_arbace_j2g_world_apply_variant_A).Invoke_O_O_O_O_O_O__O(root_1755, arg_1758, arg_1759, arg_1760, arg_1761, arg_1762) }
//line :191:1
		var m2__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000185__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000185__4, lang.RT_IntCast_J__I_NoInit(1), nil)



		if jrt.J2g_Truth(vfs__3) { var root_1763 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = t.F_applied; var arg_1767 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var arg_1768 any = nn__2; var arg_1769 any = c__6; if linked_1764 == nil { ifn_1765.Invoke_O_O_O_O__O(arg_1766, arg_1767, arg_1768, arg_1769) } else { linked_1764.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1763, arg_1766, arg_1767, arg_1768, arg_1769) } }
//line :191:1
		return m2__5 } else { return m__1
		}
}








func A_arbace_j2g_world_read_variants_A_New() *A_arbace_j2g_world_read_variants_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_variants_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_j2g_world_read_variants_A) Ctor() {}
//line :202:1
func (t *A_arbace_j2g_world_read_variants_A) Invoke_O_O__O(self, files__0 any) any {





	var root_1798 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any; var tmp1 any = A_arbace_j2g_world_read_variants_fn__78000190_A_New(); var tmp2 *jrt.Class; var fncls__1906 *jrt.Class = A_arbace_j2g_world_read_variants_fn__78000190_A_fn_class; if fncls__1906 == nil { var fncls__1906d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_j2g_world_read_variants_fn__78000190_A_fn_class = fncls__1906d; tmp2 = fncls__1906d } else { tmp2 = fncls__1906 }; arg_1801 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1802 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1803 any = files__0; if linked_1799 == nil { return ifn_1800.Invoke_O_O_O__O(arg_1801, arg_1802, arg_1803) } else { return linked_1799.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1798, arg_1801, arg_1802, arg_1803) } }
//line :208:1
func A_arbace_j2g_world_read_variants_fn__78000190_A_New() *A_arbace_j2g_world_read_variants_fn__78000190_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_variants_fn__78000190_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_j2g_world_read_variants_fn__78000190_A) Ctor() {}
//line :208:1
func (t *A_arbace_j2g_world_read_variants_fn__78000190_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any { var forms__3 any; var root_1804 any = A_arbace_j2g_world_A_const_129.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, A_arbace_j2g_world_read_forms_A_fn_class); var ifn_1806 lang.IFn; if
													linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any = f__2; if linked_1805 == nil { forms__3 = ifn_1806.Invoke_O__O(arg_1807) } else { forms__3 = linked_1805.(*A_arbace_j2g_world_read_forms_A).Invoke_O_O__O(root_1804, arg_1807) }; var nsname__4 any; var root_1808 any = /*line :208:1*/A_arbace_j2g_world_A_const_130.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1808, A_arbace_j2g_world_ns_of_forms_A_fn_class); var ifn_1810 lang.IFn; if

	linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any = forms__3; if linked_1809 == nil { nsname__4 = ifn_1810.Invoke_O__O(arg_1811) } else { nsname__4 = linked_1809.(*A_arbace_j2g_world_ns_of_forms_A).Invoke_O_O__O(root_1808, arg_1811) }; var root_1812 any =
	A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1814 lang.IFn; if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any; var tmp1 any = A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_New_O(nsname__4); var tmp2 *jrt.Class; var fncls__1905 *jrt.Class = A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_fn_class; if fncls__1905 == nil { var fncls__1905d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_fn_class = fncls__1905d; tmp2 = fncls__1905d } else { tmp2 = fncls__1905 }; arg_1815 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1816 any = acc__1; var arg_1817 any = forms__3; if linked_1813 == nil { return ifn_1814.Invoke_O_O_O__O(arg_1815, arg_1816, arg_1817) } else { return linked_1813.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1812, arg_1815, arg_1816, arg_1817) } }
//line :211:1
func A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_New_O(p0 any) *A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A{}; t.Ctor_O(p0); return t }
//line :211:1
func (t *A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :211:1
func (t *A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A) Invoke_O_O_O__O(self, acc__1, fm__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any; var root_1818 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1820 lang.IFn
	if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = fm__2; if linked_1819 == nil { and__1927000168__auto____3 = ifn_1820.Invoke_O__O(arg_1821) } else { and__1927000168__auto____3 = linked_1819.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1818, arg_1821) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 any; var root_1822 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = fm__2; if linked_1823 == nil { tmp2 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp2 = linked_1823.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1822, arg_1825) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_139, tmp2)).Ref() } else { tmp1 = and__1927000168__auto____3 }
//line :212:1
	if jrt.J2g_Truth(tmp1) { var vec__78000192__3 any = fm__2; var seq__78000193__4 any; var root_1826 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1828 lang.IFn

		if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = vec__78000192__3; if linked_1827 == nil { seq__78000193__4 = ifn_1828.Invoke_O__O(arg_1829) } else { seq__78000193__4 = linked_1827.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1826, arg_1829) }
//line :212:1
		var first__78000194__5 any; var root_1830 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1832 lang.IFn

		if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = seq__78000193__4; if linked_1831 == nil { first__78000194__5 = ifn_1832.Invoke_O__O(arg_1833) } else { first__78000194__5 = linked_1831.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1830, arg_1833) }
//line :212:1
		var seq__78000193__6 any; var root_1834 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1836 lang.IFn

		if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = seq__78000193__4; if linked_1835 == nil { seq__78000193__6 = ifn_1836.Invoke_O__O(arg_1837) } else { seq__78000193__6 = linked_1835.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1834, arg_1837) }
//line :212:1
		var ___7 any = first__78000194__5; var first__78000194__8 any; var root_1838 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1840 lang.IFn; _ = ___7

		if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any = seq__78000193__6; if linked_1839 == nil { first__78000194__8 = ifn_1840.Invoke_O__O(arg_1841) } else { first__78000194__8 = linked_1839.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1838, arg_1841) }
//line :212:1
		var seq__78000193__9 any; var root_1842 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1844 lang.IFn

		if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = seq__78000193__6; if linked_1843 == nil { seq__78000193__9 = ifn_1844.Invoke_O__O(arg_1845) } else { seq__78000193__9 = linked_1843.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1842, arg_1845) }
//line :212:1
		var cls__10 any = first__78000194__8; var members__11 any = seq__78000193__9; var n__12 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140, nil); var tmp4 any; var root_1846 any = A_arbace_j2g_world_A_const_86.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1848 lang.IFn


		if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any; var root_1852 any = A_arbace_j2g_world_A_const_89.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any; var root_1856 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = t.F_nsname; if linked_1857 == nil { arg_1855 = ifn_1858.Invoke_O__O(arg_1859) } else { arg_1855 = linked_1857.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1856, arg_1859) }; if linked_1853 == nil { arg_1849 = ifn_1854.Invoke_O__O(arg_1855) } else { arg_1849 = linked_1853.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_1852, arg_1855) }; var arg_1850 any = Lit_141; var arg_1851 any = Lit_140; if linked_1847 == nil { tmp4 = ifn_1848.Invoke_O_O_O__O(arg_1849, arg_1850, arg_1851) } else { tmp4 = linked_1847.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1846, arg_1849, arg_1850, arg_1851) }; var tmp5 any = tmp4; var tmp6 any; var root_1860 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = cls__10; if linked_1861 == nil { tmp6 = ifn_1862.Invoke_O__O(arg_1863) } else { tmp6 = linked_1861.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1860, arg_1863) }; n__12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, tmp6)).Ref()
		var root_1864 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = acc__1; var arg_1868 any = n__12; var arg_1869 any; var root_1871 any = A_arbace_j2g_world_A_const_131.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1873 lang.IFn; if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_1875 any = lang.PersistentVector_EMPTY.Ref(); if linked_1872 == nil { arg_1869 = ifn_1873.Invoke_O_O__O(arg_1874, arg_1875) } else { arg_1869 = linked_1872.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1871, arg_1874, arg_1875) }; var arg_1870 any = members__11; if linked_1865 == nil { return ifn_1866.Invoke_O_O_O_O__O(arg_1867, arg_1868, arg_1869, arg_1870) } else { return linked_1865.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1864, arg_1867, arg_1868, arg_1869, arg_1870) } } else {
//line :212:1
			var tmp7 any; var and__1927000168__auto____3_2 any; var root_1876 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1878 lang.IFn




			if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = fm__2; if linked_1877 == nil { and__1927000168__auto____3_2 = ifn_1878.Invoke_O__O(arg_1879) } else { and__1927000168__auto____3_2 = linked_1877.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1876, arg_1879) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp8 any; var root_1880 any = A_arbace_j2g_world_A_const_101.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, A_arbace_j2g_world_head_name_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = fm__2; if linked_1881 == nil { tmp8 = ifn_1882.Invoke_O__O(arg_1883) } else { tmp8 = linked_1881.(*A_arbace_j2g_world_head_name_A).Invoke_O_O__O(root_1880, arg_1883) }; tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_142, tmp8)).Ref() } else { tmp7 = and__1927000168__auto____3_2 }
//line :212:1
			if jrt.J2g_Truth(tmp7) {





				var root_1884 any = A_arbace_j2g_world_A_const_58.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1884, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any = acc__1; var arg_1888 any = A_arbace_j2g_world_A_const_132; var arg_1889 any; var root_1891 any = A_arbace_j2g_world_A_const_131.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_1895 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1892 == nil { arg_1889 = ifn_1893.Invoke_O_O__O(arg_1894, arg_1895) } else { arg_1889 = linked_1892.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1891, arg_1894, arg_1895) }; var arg_1890 any; var root_1896 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var arg_1900 any; var root_1901 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = fm__2; if linked_1902 == nil { arg_1900 = ifn_1903.Invoke_O__O(arg_1904) } else { arg_1900 = linked_1902.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1901, arg_1904) }; if linked_1897 == nil { arg_1890 = ifn_1898.Invoke_O_O__O(arg_1899, arg_1900) } else { arg_1890 = linked_1897.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1896, arg_1899, arg_1900) }; if linked_1885 == nil { return ifn_1886.Invoke_O_O_O_O__O(arg_1887, arg_1888, arg_1889, arg_1890) } else { return linked_1885.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1884, arg_1887, arg_1888, arg_1889, arg_1890) } } else {
//line :212:1
					if A_arbace_j2g_world_A_const_88 != nil { return acc__1 } else { return nil
					}
				}
		}
}






func A_arbace_j2g_world_new_unit_A_New() *A_arbace_j2g_world_new_unit_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_new_unit_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_j2g_world_new_unit_A) Ctor() {}
//line :223:1
func (t *A_arbace_j2g_world_new_unit_A) Invoke_O__O(self any) any { var tmp1 any = A_arbace_j2g_world_A_const_133; var tmp2 any; var root_1907 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1909 lang.IFn; if
									linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = lang.PersistentVector_EMPTY.Ref(); if linked_1908 == nil { tmp2 = ifn_1909.Invoke_O__O(arg_1910) } else { tmp2 = linked_1908.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1907, arg_1910) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_j2g_world_A_const_134; var tmp5 any; var root_1911 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1913 lang.IFn; if
									linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1912 == nil { tmp5 = ifn_1913.Invoke_O__O(arg_1914) } else { tmp5 = linked_1912.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1911, arg_1914) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_j2g_world_A_const_135; var tmp8 any; var root_1915 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1917 lang.IFn; if
									linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1916 == nil { tmp8 = ifn_1917.Invoke_O__O(arg_1918) } else { tmp8 = linked_1916.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1915, arg_1918) }; var tmp9 any = tmp8; var tmp10 any = A_arbace_j2g_world_A_const_136; var tmp11 any; var root_1919 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1921 lang.IFn; if
									linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1920 == nil { tmp11 = ifn_1921.Invoke_O__O(arg_1922) } else { tmp11 = linked_1920.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1919, arg_1922) }; var tmp12 any = tmp11; var tmp13 any = A_arbace_j2g_world_A_const_137; var tmp14 any; var root_1923 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1925 lang.IFn; if

	linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1924 == nil { tmp14 = ifn_1925.Invoke_O__O(arg_1926) } else { tmp14 = linked_1924.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1923, arg_1926) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_j2g_world_A_const_138; var tmp17 any; var root_1927 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1929 lang.IFn; if

	linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1928 == nil { tmp17 = ifn_1929.Invoke_O__O(arg_1930) } else { tmp17 = linked_1928.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1927, arg_1930) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_j2g_world_A_const_139; var tmp20 any; var root_1931 any = /*line :223:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1931, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1933 lang.IFn; if

	linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1932 == nil { tmp20 = ifn_1933.Invoke_O__O(arg_1934) } else { tmp20 = linked_1932.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1931, arg_1934) }; return /*line :223:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp6, tmp7, tmp9, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp20)) }








func A_arbace_j2g_world_id_space_A_New() *A_arbace_j2g_world_id_space_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_id_space_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_j2g_world_id_space_A) Ctor() {}
//line :232:1
func (t *A_arbace_j2g_world_id_space_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	{ var tmp2 any; var root_1935 any = A_arbace_j2g_world_A_const_114.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_identity_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any = A_arbace_j2g_world_A_const_140; if linked_1936 == nil { tmp2 = ifn_1937.Invoke_O__O(arg_1938) } else { tmp2 = linked_1936.(*aot_arbace_core.A_arbace_core_identity_A).Invoke_O_O__O(root_1935, arg_1938) }; tmp1 = jrt.NN(jrt.NN(jrt.Class_Cast(tmp2)).GetField_String__Field(Lit_22)).Get_O__O(nil) }
//line :232:1
	return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_j2g_world_parse_member_classes_A_New() *A_arbace_j2g_world_parse_member_classes_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_parse_member_classes_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_world_parse_member_classes_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_world_parse_member_classes_A) Invoke_O_O__O(self, pc__0 any) any {





	var root_1939 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_New_O(pc__0); var tmp2 *jrt.Class; var fncls__2031 *jrt.Class = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_fn_class; if fncls__2031 == nil { var fncls__2031d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_fn_class = fncls__2031d; tmp2 = fncls__2031d } else { tmp2 = fncls__2031 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1942 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(A_arbace_j2g_world_A_const_149.Invoke_O__O(pc__0)); if linked_1940 == nil { return ifn_1941.Invoke_O__O(arg_1942) } else { return linked_1940.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1939, arg_1942) } }
//line :246:1
func A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_New_O(p0 any) *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A) Ctor_O(c__pc any) { t.F_pc = c__pc }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A) Invoke_O_O__O(self, s__78000201__1 any) any { var tmp1 any = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_New_O_O_O(t.F_pc, s__78000201__1, self); var tmp2 *jrt.Class; var fncls__2030 *jrt.Class = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_fn_class; if fncls__2030 == nil { var fncls__2030d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_fn_class = fncls__2030d; tmp2 = fncls__2030d } else { tmp2 = fncls__2030 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :246:1
func A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A) Ctor_O_O_O(c__pc, c__s__78000201, c__iter__78000200 any) { t.F_pc = c__pc; t.F_s__78000201 = c__s__78000201; t.F_iter__78000200 = c__iter__78000200 }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A) Invoke_O__O(self any) any { { var s__78000201__1 any; var t_ any = t.F_s__78000201; t.F_s__78000201 = nil; s__78000201__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1943 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1943, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1945 lang.IFn; if linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = s__78000201__1; if linked_1944 == nil { temp__1927000414__auto____2 = ifn_1945.Invoke_O__O(arg_1946) } else { temp__1927000414__auto____2 = linked_1944.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1943, arg_1946) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000201__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1947 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1949 lang.IFn; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = s__78000201__3; if linked_1948 == nil { tmp1 = ifn_1949.Invoke_O__O(arg_1950) } else { tmp1 = linked_1948.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1947, arg_1950) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1951 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = s__78000201__3; if linked_1952 == nil { c__1927001037__auto____4 = ifn_1953.Invoke_O__O(arg_1954) } else { c__1927001037__auto____4 = linked_1952.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1951, arg_1954) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000203__6 any; var root_1955 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1956 == nil { b__78000203__6 = ifn_1957.Invoke_O__O(arg_1958) } else { b__78000203__6 = linked_1956.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1955, arg_1958) }; var tmp2 any = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_New_O_O_I_O(b__78000203__6, t.F_pc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1977 *jrt.Class = A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_fn_class; if fncls__1977 == nil { var fncls__1977d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_fn_class = fncls__1977d; tmp3 = fncls__1977d } else { tmp3 = fncls__1977 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1978 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any; var root_1983 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = b__78000203__6; if linked_1984 == nil { arg_1981 = ifn_1985.Invoke_O__O(arg_1986) } else { arg_1981 = linked_1984.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1983, arg_1986) }; var arg_1982 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000200); var tmp5 any; var root_1987 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = s__78000201__3; if linked_1988 == nil { tmp5 = ifn_1989.Invoke_O__O(arg_1990) } else { tmp5 = linked_1988.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1987, arg_1990) }; arg_1982 = tmp4.Invoke_O__O(tmp5); if linked_1979 == nil { return ifn_1980.Invoke_O_O__O(arg_1981, arg_1982) } else { return linked_1979.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1978, arg_1981, arg_1982) } } else { var root_1991 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1993 lang.IFn; if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any; var root_1996 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = b__78000203__6; if linked_1997 == nil { arg_1994 = ifn_1998.Invoke_O__O(arg_1999) } else { arg_1994 = linked_1997.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1996, arg_1999) }; var arg_1995 any; if linked_1992 == nil { return ifn_1993.Invoke_O_O__O(arg_1994, arg_1995) } else { return linked_1992.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1991, arg_1994, arg_1995) } } } else { var m__4 any; var root_2000 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = s__78000201__3; if linked_2001 == nil { m__4 = ifn_2002.Invoke_O__O(arg_2003) } else { m__4 = linked_2001.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2000, arg_2003) }; var tmp6 any = A_arbace_j2g_world_A_const_76; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_j2g_world_A_const_141.Invoke_O__O(m__4)) { var root_2004 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any; var mpc__5 any; var root_2009 any = A_arbace_j2g_world_A_const_142.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_2011 lang.IFn
															if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var tmp7 any = A_arbace_j2g_world_A_const_143; var arg_2012 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, A_arbace_j2g_world_A_const_143.Invoke_O__O(t.F_pc), A_arbace_j2g_world_A_const_144, A_arbace_j2g_world_A_const_145, A_arbace_j2g_world_A_const_146, t.F_pc)); var arg_2013 any; var root_2014 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = A_arbace_j2g_world_A_const_147.Invoke_O__O(m__4); if linked_2015 == nil { arg_2013 = ifn_2016.Invoke_O__O(arg_2017) } else { arg_2013 = linked_2015.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2014, arg_2017) }; if linked_2010 == nil { mpc__5 = ifn_2011.Invoke_O_O__O(arg_2012, arg_2013) } else { mpc__5 = linked_2010.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_2009, arg_2012, arg_2013) }
//line :246:1
	var tmp8 any = A_arbace_j2g_world_A_const_148; var tmp9 any = A_arbace_j2g_world_A_const_149; var tmp10 any; var root_2018 any = A_arbace_j2g_world_A_const_150.GetRawRoot__O(); var linked_2019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2018, A_arbace_j2g_world_parse_member_classes_A_fn_class); var ifn_2020 lang.IFn

	if linked_2019 == nil { ifn_2020 = lang.IFn_Cast(root_2018) } else { ifn_2020 = nil }; var arg_2021 any = mpc__5; if linked_2019 == nil { tmp10 = ifn_2020.Invoke_O__O(arg_2021) } else { tmp10 = linked_2019.(*A_arbace_j2g_world_parse_member_classes_A).Invoke_O_O__O(root_2018, arg_2021) }
//line :246:1
	arg_2007 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, mpc__5, tmp9, tmp10)); var arg_2008 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__78000200); var tmp12 any; var root_2022 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = s__78000201__3; if linked_2023 == nil { tmp12 = ifn_2024.Invoke_O__O(arg_2025) } else { tmp12 = linked_2023.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2022, arg_2025) }; arg_2008 = tmp11.Invoke_O__O(tmp12); if linked_2005 == nil { return ifn_2006.Invoke_O_O__O(arg_2007, arg_2008) } else { return linked_2005.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2004, arg_2007, arg_2008) } } else { var tmp13 any; var root_2026 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = s__78000201__3; if linked_2027 == nil { tmp13 = ifn_2028.Invoke_O__O(arg_2029) } else { tmp13 = linked_2027.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2026, arg_2029) }; s__78000201__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :246:1
func A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A) Ctor_O_O_I_O(c__b__78000203, c__pc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000203 = c__b__78000203; t.F_pc = c__pc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :246:1
func (t *A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A) Invoke_O__O(self any) any { { var i__78000202__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000202__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000202__1)); var tmp2 any = A_arbace_j2g_world_A_const_76; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_world_A_const_141.Invoke_O__O(m__2)) { var root_1959 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = t.F_b__78000203; var arg_1963 any; var mpc__3 any; var root_1964 any = A_arbace_j2g_world_A_const_142.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_1966 lang.IFn
																	if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var tmp3 any = A_arbace_j2g_world_A_const_143; var arg_1967 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, A_arbace_j2g_world_A_const_143.Invoke_O__O(t.F_pc), A_arbace_j2g_world_A_const_144, A_arbace_j2g_world_A_const_145, A_arbace_j2g_world_A_const_146, t.F_pc)); var arg_1968 any; var root_1969 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = A_arbace_j2g_world_A_const_147.Invoke_O__O(m__2); if linked_1970 == nil { arg_1968 = ifn_1971.Invoke_O__O(arg_1972) } else { arg_1968 = linked_1970.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1969, arg_1972) }; if linked_1965 == nil { mpc__3 = ifn_1966.Invoke_O_O__O(arg_1967, arg_1968) } else { mpc__3 = linked_1965.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_1964, arg_1967, arg_1968) }
//line :246:1
	var tmp4 any = A_arbace_j2g_world_A_const_148; var tmp5 any = A_arbace_j2g_world_A_const_149; var tmp6 any; var root_1973 any = A_arbace_j2g_world_A_const_150.GetRawRoot__O(); var linked_1974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1973, A_arbace_j2g_world_parse_member_classes_A_fn_class); var ifn_1975 lang.IFn

	if linked_1974 == nil { ifn_1975 = lang.IFn_Cast(root_1973) } else { ifn_1975 = nil }; var arg_1976 any = mpc__3; if linked_1974 == nil { tmp6 = ifn_1975.Invoke_O__O(arg_1976) } else { tmp6 = linked_1974.(*A_arbace_j2g_world_parse_member_classes_A).Invoke_O_O__O(root_1973, arg_1976) }
//line :246:1
	arg_1963 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, mpc__3, tmp5, tmp6)); if linked_1960 == nil { ifn_1961.Invoke_O_O__O(arg_1962, arg_1963) } else { linked_1960.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1959, arg_1962, arg_1963) }; i__78000202__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000202__1); continue L1 } else { i__78000202__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000202__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_world_levels_A_New() *A_arbace_j2g_world_levels_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_levels_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_j2g_world_levels_A) Ctor() {}
//line :250:1
func (t *A_arbace_j2g_world_levels_A) Invoke_O_O_O__O(self, names__0, deps__1 any) any { var in__3 any; var root_2032 any = A_arbace_j2g_world_A_const_151.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2034 lang.IFn; if




	linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = names__0; if linked_2033 == nil { in__3 = ifn_2034.Invoke_O__O(arg_2035) } else { in__3 = linked_2033.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2032, arg_2035) }; var memo__4 any = /*line :250:1*/jrt.HashMap_New(); var lvl__5 any; var tmp1 any = A_arbace_j2g_world_levels_lvl__78000211_A_New_O_O_O(in__3, deps__1, memo__4); var tmp2 *jrt.Class; var fncls__2054 *jrt.Class = A_arbace_j2g_world_levels_lvl__78000211_A_fn_class; if






	fncls__2054 == nil { var fncls__2054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_world_levels_lvl__78000211_A_fn_class = fncls__2054d; tmp2 = fncls__2054d } else { tmp2 = fncls__2054 }; lvl__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_2055 any =





	A_arbace_j2g_world_A_const_153.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2055, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2057 lang.IFn; if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any; var root_2059 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_154.GetRawRoot__O()).Invoke__O(); var arg_2063 any; var root_2067 any = A_arbace_j2g_world_A_const_155.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = lvl__5; var arg_2071 any = names__0; if linked_2068 == nil { arg_2063 = ifn_2069.Invoke_O_O__O(arg_2070, arg_2071) } else { arg_2063 = linked_2068.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2067, arg_2070, arg_2071) }; if linked_2060 == nil { arg_2058 = ifn_2061.Invoke_O_O__O(arg_2062, arg_2063) } else { arg_2058 = linked_2060.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2059, arg_2062, arg_2063) }; if linked_2056 == nil { return ifn_2057.Invoke_O__O(arg_2058) } else { return linked_2056.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2055, arg_2058) } }
//line :257:1
func A_arbace_j2g_world_levels_lvl__78000211_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_levels_lvl__78000211_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_levels_lvl__78000211_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_j2g_world_levels_lvl__78000211_A) Ctor_O_O_O(c__in, c__deps, c__memo any) { t.F_in = c__in; t.F_deps = c__deps; t.F_memo = c__memo }
//line :257:1
func (t *A_arbace_j2g_world_levels_lvl__78000211_A) Invoke_O_O__O(self, n__1 any) any { var or__1927000174__auto____2 any = jrt.HashMap_Cast(t.F_memo).Get_O__O(n__1); if
											jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
												jrt.HashMap_Cast(t.F_memo).Put_O_O__O(n__1, A_arbace_j2g_world_A_const_111)
//line :258:1
		var l__3 any; var na_2036 any; var root_2037 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2039 lang.IFn

		if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = A_arbace_j2g_world_A_const_152.GetRawRoot__O(); var arg_2041 any = A_arbace_j2g_world_A_const_116; var arg_2042 any; var root_2043 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = self; var arg_2047 any; var root_2048 any = A_arbace_j2g_world_A_const_81.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = t.F_in; var arg_2052 any = lang.IFn_Cast(t.F_deps).Invoke_O__O(n__1); if linked_2049 == nil { arg_2047 = ifn_2050.Invoke_O_O__O(arg_2051, arg_2052) } else { arg_2047 = linked_2049.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2048, arg_2051, arg_2052) }; if linked_2044 == nil { arg_2042 = ifn_2045.Invoke_O_O__O(arg_2046, arg_2047) } else { arg_2042 = linked_2044.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2043, arg_2046, arg_2047) }; if linked_2038 == nil { na_2036 = ifn_2039.Invoke_O_O_O__O(arg_2040, arg_2041, arg_2042) } else { na_2036 = linked_2038.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2037, arg_2040, arg_2041, arg_2042) }; if jrt.Long_InstanceOf(na_2036) { var n0_2053 int64 = jrt.NN(jrt.Long_Cast(na_2036)).LongValue__J(); if n0_2053 == 9223372036854775807 { l__3 = lang.Numbers_Inc_O__Number_NoInit(na_2036) } else { l__3 = jrt.Long_ValueOf_J__Long_NoInit(n0_2053 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_2036) { var n0_2053_2 float64 = jrt.NN(jrt.Double_Cast(na_2036)).DoubleValue__D(); l__3 = jrt.Double_ValueOf_D__Double_NoInit(n0_2053_2 + 1.0).Ref() } else { l__3 = lang.Numbers_Inc_O__Number_NoInit(na_2036) } }
		jrt.HashMap_Cast(t.F_memo).Put_O_O__O(n__1, l__3)
//line :258:1
		return l__3 } }






func A_arbace_j2g_world_supers_of_A_New() *A_arbace_j2g_world_supers_of_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_supers_of_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_j2g_world_supers_of_A) Ctor() {}
//line :265:1
func (t *A_arbace_j2g_world_supers_of_A) Invoke_O_O__O(self, n__0 any) any { var d__2 any; var root_2072 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2074 lang.IFn; if


	linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any = n__0; if linked_2073 == nil { d__2 = ifn_2074.Invoke_O__O(arg_2075) } else { d__2 = linked_2073.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2072, arg_2075) }; var root_2076 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = A_arbace_j2g_world_A_const_157.Invoke_O__O(d__2); var arg_2080 any = A_arbace_j2g_world_A_const_158.Invoke_O__O(d__2); if linked_2077 == nil { return ifn_2078.Invoke_O_O__O(arg_2079, arg_2080) } else { return linked_2077.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2076, arg_2079, arg_2080) } }

func A_arbace_j2g_world_par_levels_A_New() *A_arbace_j2g_world_par_levels_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_par_levels_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_j2g_world_par_levels_A) Ctor() {}
//line :270:1
func (t *A_arbace_j2g_world_par_levels_A) Invoke_O_O_O_O__O(self, names__0, deps__1, f__2 any) any { { var seq_78000215__4 any; var root_2081 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2083 lang.IFn


	if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any; var root_2085 any = A_arbace_j2g_world_A_const_159.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, A_arbace_j2g_world_levels_A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = names__0; var arg_2089 any = deps__1; if linked_2086 == nil { arg_2084 = ifn_2087.Invoke_O_O__O(arg_2088, arg_2089) } else { arg_2084 = linked_2086.(*A_arbace_j2g_world_levels_A).Invoke_O_O_O__O(root_2085, arg_2088, arg_2089) }; if linked_2082 == nil { seq_78000215__4 = ifn_2083.Invoke_O__O(arg_2084) } else { seq_78000215__4 = linked_2082.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2081, arg_2084) }
//line :270:1
	var chunk_78000216__5 any; var count_78000217__6 int64 = 0; var i_78000218__7 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_78000218__7, count_78000217__6) { var l__8 any = lang.Indexed_Cast(chunk_78000216__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000218__7)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp2 any; var root_2112 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2114 lang.IFn
			if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; if linked_2113 == nil { tmp2 = ifn_2114.Invoke__O() } else { tmp2 = linked_2113.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2112) }; tmp1.Invoke_O_O_O__O(tmp2, f__2, l__8)
//line :273:1
			seq_78000215__4, chunk_78000216__5, count_78000217__6, i_78000218__7 = seq_78000215__4, chunk_78000216__5, count_78000217__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000218__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_2090 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = seq_78000215__4; if linked_2091 == nil { temp__1927000414__auto____8 = ifn_2092.Invoke_O__O(arg_2093) } else { temp__1927000414__auto____8 = linked_2091.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2090, arg_2093) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_78000215__9 any = temp__1927000414__auto____8; var tmp3 any; var root_2094 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = seq_78000215__9; if linked_2095 == nil { tmp3 = ifn_2096.Invoke_O__O(arg_2097) } else { tmp3 = linked_2095.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2094, arg_2097) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_2098 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = seq_78000215__9; if linked_2099 == nil { c__1927000678__auto____10 = ifn_2100.Invoke_O__O(arg_2101) } else { c__1927000678__auto____10 = linked_2099.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2098, arg_2101) }; var tmp4 any; var root_2115 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = seq_78000215__9; if linked_2116 == nil { tmp4 = ifn_2117.Invoke_O__O(arg_2118) } else { tmp4 = linked_2116.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2115, arg_2118) }; seq_78000215__4, chunk_78000216__5, count_78000217__6, i_78000218__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__10 any; var root_2102 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = seq_78000215__9; if linked_2103 == nil { l__10 = ifn_2104.Invoke_O__O(arg_2105) } else { l__10 = linked_2103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2102, arg_2105) }
				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp6 any; var root_2125 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; if linked_2126 == nil { tmp6 = ifn_2127.Invoke__O() } else { tmp6 = linked_2126.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2125) }; tmp5.Invoke_O_O_O__O(tmp6, f__2, l__10)
//line :273:1
				var tmp7 any; var root_2128 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = seq_78000215__9; if linked_2129 == nil { tmp7 = ifn_2130.Invoke_O__O(arg_2131) } else { tmp7 = linked_2129.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2128, arg_2131) }; seq_78000215__4, chunk_78000216__5, count_78000217__6, i_78000218__7 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :270:1*/panic("j2g: unreachable") }





func A_arbace_j2g_world_load_world_A_New() *A_arbace_j2g_world_load_world_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_j2g_world_load_world_A) Ctor() {}
//line :276:1
func (t *A_arbace_j2g_world_load_world_A) DoInvoke_O_O_O__O(self, inputs__0, p__78000225__1 any) any { var map__78000226__3 any = p__78000225__1; var map__78000226__4 any; if lang.ISeq_InstanceOf(map__78000226__3) { var tmp1 any; var root_2132 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = map__78000226__3; if linked_2133 == nil { tmp1 = ifn_2134.Invoke_O__O(arg_2135) } else { tmp1 = linked_2133.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2132, arg_2135) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2136 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = map__78000226__3; if linked_2137 == nil { tmp2 = ifn_2138.Invoke_O__O(arg_2139) } else { tmp2 = linked_2137.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2136, arg_2139) }; map__78000226__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2140 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2142 lang.IFn; if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = map__78000226__3; if linked_2141 == nil { tmp3 = ifn_2142.Invoke_O__O(arg_2143) } else { tmp3 = linked_2141.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2140, arg_2143) }; if jrt.J2g_Truth(tmp3) { var root_2144 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2146 lang.IFn; if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any = map__78000226__3; if linked_2145 == nil { map__78000226__4 = ifn_2146.Invoke_O__O(arg_2147) } else { map__78000226__4 = linked_2145.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2144, arg_2147) } } else { map__78000226__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000226__4 = map__78000226__3 }; var variant_files__5 any = lang.RT_Get_O_O__O_NoInit(map__78000226__4, A_arbace_j2g_world_A_const_162); var late_inputs__6 any = lang.RT_Get_O_O__O_NoInit(map__78000226__4, A_arbace_j2g_world_A_const_163); var wait__7 any = lang.RT_Get_O_O__O_NoInit(map__78000226__4, A_arbace_j2g_world_A_const_164); var variants__8 any; var root_2148 any = A_arbace_j2g_world_A_const_165.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, A_arbace_j2g_world_read_variants_A_fn_class); var ifn_2150 lang.IFn; if













	linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = variant_files__5; if linked_2149 == nil { variants__8 = ifn_2150.Invoke_O__O(arg_2151) } else { variants__8 = linked_2149.(*A_arbace_j2g_world_read_variants_A).Invoke_O_O__O(root_2148, arg_2151) }; var erased__9 any = /*line :276:1*/lang.RT_Get_O_O_O__O_NoInit(variants__8, A_arbace_j2g_world_A_const_132, lang.PersistentHashSet_EMPTY.Ref()); var variants__10 any; var root_2152 any = A_arbace_j2g_world_A_const_72.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_2154 lang.IFn; if















	linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = variants__8; var arg_2156 any = A_arbace_j2g_world_A_const_132; if linked_2153 == nil { variants__10 = ifn_2154.Invoke_O_O__O(arg_2155, arg_2156) } else { variants__10 = linked_2153.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_2152, arg_2155, arg_2156) }; var applied__11 any; var root_2157 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2159 lang.IFn; if
















	linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2158 == nil { applied__11 = ifn_2159.Invoke_O__O(arg_2160) } else { applied__11 = linked_2158.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2157, arg_2160) }; var parse__12 any; var tmp4 any = /*line :276:1*/A_arbace_j2g_world_load_world_parse__78000228_A_New(); var tmp5 *jrt.Class; var fncls__2207 *jrt.Class = A_arbace_j2g_world_load_world_parse__78000228_A_fn_class; if




















	fncls__2207 == nil { var fncls__2207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_world_load_world_parse__78000228_A_fn_class = fncls__2207d; tmp5 = fncls__2207d } else { tmp5 = fncls__2207 }; parse__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var parsed__13 any; var root_2208 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2210 lang.IFn; if


























	linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = lang.IFn_Cast(parse__12).Invoke_O__O(inputs__0); if linked_2209 == nil { parsed__13 = ifn_2210.Invoke_O__O(arg_2211) } else { parsed__13 = linked_2209.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2208, arg_2211) }; var top_set__14 any; var tmp6 any = /*line :276:1*/A_arbace_j2g_world_load_world_top_set__78000234_A_New(); var tmp7 *jrt.Class; var fncls__2243 *jrt.Class = A_arbace_j2g_world_load_world_top_set__78000234_A_fn_class; if



























	fncls__2243 == nil { var fncls__2243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_world_load_world_top_set__78000234_A_fn_class = fncls__2243d; tmp7 = fncls__2243d } else { tmp7 = fncls__2243 }; top_set__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tops__15 any; var root_2244 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2244, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2246 lang.IFn; if




























	linked_2245 == nil { ifn_2246 = lang.IFn_Cast(root_2244) } else { ifn_2246 = nil }; var arg_2247 any; var tmp8 lang.IFn = lang.IFn_Cast(top_set__14); var tmp9 any; var root_2248 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2250 lang.IFn; if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any = parsed__13; if linked_2249 == nil { tmp9 = ifn_2250.Invoke_O__O(arg_2251) } else { tmp9 = linked_2249.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2248, arg_2251) }; arg_2247 = tmp8.Invoke_O__O(tmp9); if linked_2245 == nil { tops__15 = ifn_2246.Invoke_O__O(arg_2247) } else { tops__15 = linked_2245.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2244, arg_2247) }; var top_of__16 any; var tmp10 any = /*line :276:1*/A_arbace_j2g_world_load_world_top_of__78000241_A_New(); var tmp11 *jrt.Class; var fncls__2258 *jrt.Class = A_arbace_j2g_world_load_world_top_of__78000241_A_fn_class; if





























	fncls__2258 == nil { var fncls__2258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_world_load_world_top_of__78000241_A_fn_class = fncls__2258d; tmp11 = fncls__2258d } else { tmp11 = fncls__2258 }; top_of__16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var from_source__17 any; var tmp12 any = /*line :276:1*/A_arbace_j2g_world_load_world_from_source__78000243_A_New_O_O(tops__15, top_of__16); var tmp13 *jrt.Class; var fncls__2268 *jrt.Class = A_arbace_j2g_world_load_world_from_source__78000243_A_fn_class; if






























	fncls__2268 == nil { var fncls__2268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_world_load_world_from_source__78000243_A_fn_class = fncls__2268d; tmp13 = fncls__2268d } else { tmp13 = fncls__2268 }; from_source__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var cs__18 any; var root_2269 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2269, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2271 lang.IFn; if































	linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2270 == nil { cs__18 = ifn_2271.Invoke_O__O(arg_2272) } else { cs__18 = linked_2270.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2269, arg_2272) }; var unit__19 any; var root_2273 any = /*line :276:1*/A_arbace_j2g_world_A_const_171.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, A_arbace_j2g_world_new_unit_A_fn_class); var ifn_2275 lang.IFn; if
































	linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; if linked_2274 == nil { unit__19 = ifn_2275.Invoke__O() } else { unit__19 = linked_2274.(*A_arbace_j2g_world_new_unit_A).Invoke_O__O(root_2273) }; var failed__20 any; var root_2276 any = /*line :276:1*/A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2276, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2278 lang.IFn; if

































	linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any = lang.PersistentVector_EMPTY.Ref(); if linked_2277 == nil { failed__20 = ifn_2278.Invoke_O__O(arg_2279) } else { failed__20 = linked_2277.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2276, arg_2279) }; var root_4161 any =
	A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_4162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4161, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4163 lang.IFn; if linked_4162 == nil { ifn_4163 = lang.IFn_Cast(root_4161) } else { ifn_4163 = nil }; var arg_4164 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_j2g_world_A_const_227, cs__18, A_arbace_j2g_world_A_const_209, unit__19, A_arbace_j2g_world_A_const_228, from_source__17); if linked_4162 == nil { ifn_4163.Invoke_O__O(arg_4164) } else { linked_4162.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4161, arg_4164) }; var tmp14 any = A_arbace_j2g_world_load_world_fn__78000245_A_New_O_O_O_O_O_O_O_O_O_O(parsed__13, variants__10, parse__12, failed__20, top_set__14, wait__7, tops__15, unit__19, applied__11, late_inputs__6); var tmp15 *jrt.Class; var fncls__4110 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_A_fn_class; if fncls__4110 == nil { var fncls__4110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_world_load_world_fn__78000245_A_fn_class = fncls__4110d; tmp15 = fncls__4110d } else { tmp15 = fncls__4110 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O(); var seq_78000467__21 any; var root_4111 any = /*line :276:1*/A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4111, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4113 lang.IFn; if



























































































































































































































	linked_4112 == nil { ifn_4113 = lang.IFn_Cast(root_4111) } else { ifn_4113 = nil }; var arg_4114 any; var root_4115 any = A_arbace_j2g_world_A_const_78.GetRawRoot__O(); var linked_4116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4115, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_4117 lang.IFn; if linked_4116 == nil { ifn_4117 = lang.IFn_Cast(root_4115) } else { ifn_4117 = nil }; var arg_4118 any = variants__10; if linked_4116 == nil { arg_4114 = ifn_4117.Invoke_O__O(arg_4118) } else { arg_4114 = linked_4116.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_4115, arg_4118) }; if linked_4112 == nil { seq_78000467__21 = ifn_4113.Invoke_O__O(arg_4114) } else { seq_78000467__21 = linked_4112.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4111, arg_4114) }; var chunk_78000468__22 any; var count_78000469__23 int64 = 0; var i_78000470__24 int64 = 0; L1:
//line :276:1
	for {



























































































































































































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_78000470__24, count_78000469__23) { var n__25 any = lang.Indexed_Cast(chunk_78000468__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000470__24)); var tmp16 any; var root_4119 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_4120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4119, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4121 lang.IFn; if linked_4120 == nil { ifn_4121 = lang.IFn_Cast(root_4119) } else { ifn_4121 = nil }; var arg_4122 any; var root_4123 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_4124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4123, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_4125 lang.IFn; if linked_4124 == nil { ifn_4125 = lang.IFn_Cast(root_4123) } else { ifn_4125 = nil }; var arg_4126 any; var root_4128 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_4129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4128, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4130 lang.IFn; if linked_4129 == nil { ifn_4130 = lang.IFn_Cast(root_4128) } else { ifn_4130 = nil }; var arg_4131 any = applied__11; if linked_4129 == nil { arg_4126 = ifn_4130.Invoke_O__O(arg_4131) } else { arg_4126 = linked_4129.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4128, arg_4131) }; var arg_4127 any = n__25; if linked_4124 == nil { arg_4122 = ifn_4125.Invoke_O_O__O(arg_4126, arg_4127) } else { arg_4122 = linked_4124.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_4123, arg_4126, arg_4127) }; if linked_4120 == nil { tmp16 = ifn_4121.Invoke_O__O(arg_4122) } else { tmp16 = linked_4120.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4119, arg_4122) }; if jrt.J2g_Truth(tmp16) {
			var root_4174 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_4175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4174, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4176 lang.IFn; if linked_4175 == nil { ifn_4176 = lang.IFn_Cast(root_4174) } else { ifn_4176 = nil }; var arg_4177 any = failed__20; var arg_4178 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_4179 any = lang.Tuple_Create_O_O__IPersistentVector(n__25, Lit_42); if linked_4175 == nil { ifn_4176.Invoke_O_O_O__O(arg_4177, arg_4178, arg_4179) } else { linked_4175.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_4174, arg_4177, arg_4178, arg_4179) }
//line :496:1
			seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = seq_78000467__21, chunk_78000468__22, count_78000469__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000470__24); continue L1 } else { seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = seq_78000467__21, chunk_78000468__22, count_78000469__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000470__24); continue L1 } } else { var temp__1927000414__auto____25 any; var root_4132 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4134 lang.IFn; if linked_4133 == nil { ifn_4134 = lang.IFn_Cast(root_4132) } else { ifn_4134 = nil }; var arg_4135 any = seq_78000467__21; if linked_4133 == nil { temp__1927000414__auto____25 = ifn_4134.Invoke_O__O(arg_4135) } else { temp__1927000414__auto____25 = linked_4133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4132, arg_4135) }; if jrt.J2g_Truth(temp__1927000414__auto____25) { var seq_78000467__26 any = temp__1927000414__auto____25; var tmp17 any; var root_4136 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_4137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4136, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4138 lang.IFn; if linked_4137 == nil { ifn_4138 = lang.IFn_Cast(root_4136) } else { ifn_4138 = nil }; var arg_4139 any = seq_78000467__26; if linked_4137 == nil { tmp17 = ifn_4138.Invoke_O__O(arg_4139) } else { tmp17 = linked_4137.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4136, arg_4139) }; if jrt.J2g_Truth(tmp17) { var c__1927000678__auto____27 any; var root_4140 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_4141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4140, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4142 lang.IFn; if linked_4141 == nil { ifn_4142 = lang.IFn_Cast(root_4140) } else { ifn_4142 = nil }; var arg_4143 any = seq_78000467__26; if linked_4141 == nil { c__1927000678__auto____27 = ifn_4142.Invoke_O__O(arg_4143) } else { c__1927000678__auto____27 = linked_4141.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4140, arg_4143) }; var tmp18 any; var root_4180 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_4181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4180, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4182 lang.IFn; if linked_4181 == nil { ifn_4182 = lang.IFn_Cast(root_4180) } else { ifn_4182 = nil }; var arg_4183 any = seq_78000467__26; if linked_4181 == nil { tmp18 = ifn_4182.Invoke_O__O(arg_4183) } else { tmp18 = linked_4181.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4180, arg_4183) }; seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = tmp18, c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__27 any; var root_4144 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_4145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4144, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4146 lang.IFn; if linked_4145 == nil { ifn_4146 = lang.IFn_Cast(root_4144) } else { ifn_4146 = nil }; var arg_4147 any = seq_78000467__26; if linked_4145 == nil { n__27 = ifn_4146.Invoke_O__O(arg_4147) } else { n__27 = linked_4145.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4144, arg_4147) }; var tmp19 any; var root_4148 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_4149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4148, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4150 lang.IFn; if linked_4149 == nil { ifn_4150 = lang.IFn_Cast(root_4148) } else { ifn_4150 = nil }; var arg_4151 any; var root_4152 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_4153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4152, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_4154 lang.IFn; if linked_4153 == nil { ifn_4154 = lang.IFn_Cast(root_4152) } else { ifn_4154 = nil }; var arg_4155 any; var root_4157 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_4158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4157, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4159 lang.IFn; if linked_4158 == nil { ifn_4159 = lang.IFn_Cast(root_4157) } else { ifn_4159 = nil }; var arg_4160 any = applied__11; if linked_4158 == nil { arg_4155 = ifn_4159.Invoke_O__O(arg_4160) } else { arg_4155 = linked_4158.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4157, arg_4160) }; var arg_4156 any = n__27; if linked_4153 == nil { arg_4151 = ifn_4154.Invoke_O_O__O(arg_4155, arg_4156) } else { arg_4151 = linked_4153.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_4152, arg_4155, arg_4156) }; if linked_4149 == nil { tmp19 = ifn_4150.Invoke_O__O(arg_4151) } else { tmp19 = linked_4149.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4148, arg_4151) }; if jrt.J2g_Truth(tmp19) {
				var root_4184 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_4185 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4184, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4186 lang.IFn; if linked_4185 == nil { ifn_4186 = lang.IFn_Cast(root_4184) } else { ifn_4186 = nil }; var arg_4187 any = failed__20; var arg_4188 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_4189 any = lang.Tuple_Create_O_O__IPersistentVector(n__27, Lit_42); if linked_4185 == nil { ifn_4186.Invoke_O_O_O__O(arg_4187, arg_4188, arg_4189) } else { linked_4185.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_4184, arg_4187, arg_4188, arg_4189) }
//line :496:1
				var tmp20 any; var root_4190 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_4191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4190, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4192 lang.IFn; if linked_4191 == nil { ifn_4192 = lang.IFn_Cast(root_4190) } else { ifn_4192 = nil }; var arg_4193 any = seq_78000467__26; if linked_4191 == nil { tmp20 = ifn_4192.Invoke_O__O(arg_4193) } else { tmp20 = linked_4191.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4190, arg_4193) }; seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = tmp20, nil, 0, 0; continue L1 } else { var tmp21 any; var root_4194 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_4195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4194, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4196 lang.IFn; if linked_4195 == nil { ifn_4196 = lang.IFn_Cast(root_4194) } else { ifn_4196 = nil }; var arg_4197 any = seq_78000467__26; if linked_4195 == nil { tmp21 = ifn_4196.Invoke_O__O(arg_4197) } else { tmp21 = linked_4195.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4194, arg_4197) }; seq_78000467__21, chunk_78000468__22, count_78000469__23, i_78000470__24 = tmp21, nil, 0, 0; continue L1 } } } }
//line :276:1
		break L1 }; var tmp22 any = A_arbace_j2g_world_A_const_172; var tmp23 any = A_arbace_j2g_world_A_const_173; var tmp24 any = A_arbace_j2g_world_A_const_174; var tmp25 any = A_arbace_j2g_world_A_const_94; var tmp26 any; var root_2280 any = A_arbace_j2g_world_A_const_57.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2282 lang.IFn; if





























































































































































































































	linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any = A_arbace_j2g_world_A_const_168; var arg_2284 any; var root_2285 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = parsed__13; if linked_2286 == nil { arg_2284 = ifn_2287.Invoke_O__O(arg_2288) } else { arg_2284 = linked_2286.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2285, arg_2288) }; if linked_2281 == nil { tmp26 = ifn_2282.Invoke_O_O__O(arg_2283, arg_2284) } else { tmp26 = linked_2281.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2280, arg_2283, arg_2284) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_j2g_world_A_const_175; var tmp29 any; var root_2289 any = /*line :276:1*/A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2291 lang.IFn; if













	linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = tops__15; if linked_2290 == nil { tmp29 = ifn_2291.Invoke_O__O(arg_2292) } else { tmp29 = linked_2290.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2289, arg_2292) }; var tmp30 any = tmp29; var tmp31 any = A_arbace_j2g_world_A_const_176; var tmp32 any; var root_2293 any = /*line :276:1*/A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2295 lang.IFn; if































































































































































































































	linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2297 any; var iter__1927001039__auto____21 any; var tmp33 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_A_New(); var tmp34 *jrt.Class; var fncls__2416 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_A_fn_class; if fncls__2416 == nil { var fncls__2416d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_A_fn_class = fncls__2416d; tmp34 = fncls__2416d } else { tmp34 = fncls__2416 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var tmp35 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____21); var tmp36 any; var root_2417 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2417, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2419 lang.IFn; if linked_2418 == nil { ifn_2419 = lang.IFn_Cast(root_2417) } else { ifn_2419 = nil }; var arg_2420 any = parsed__13; if linked_2418 == nil { tmp36 = ifn_2419.Invoke_O__O(arg_2420) } else { tmp36 = linked_2418.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2417, arg_2420) }; arg_2297 = tmp35.Invoke_O__O(tmp36); if linked_2294 == nil { tmp32 = ifn_2295.Invoke_O_O__O(arg_2296, arg_2297) } else { tmp32 = linked_2294.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2293, arg_2296, arg_2297) }; var tmp37 any = tmp32; var tmp38 any = A_arbace_j2g_world_A_const_177; var tmp39 any; var root_2421 any = /*line :276:1*/A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2423 lang.IFn; if


































































































































































































































	linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any; var root_2425 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2427 lang.IFn; if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any; var root_2430 any = A_arbace_j2g_world_A_const_178.GetRawRoot__O(); var linked_2431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2430, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2432 lang.IFn; if linked_2431 == nil { ifn_2432 = lang.IFn_Cast(root_2430) } else { ifn_2432 = nil }; var arg_2433 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var arg_2434 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); if linked_2431 == nil { arg_2428 = ifn_2432.Invoke_O_O__O(arg_2433, arg_2434) } else { arg_2428 = linked_2431.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2430, arg_2433, arg_2434) }; var arg_2429 any; var root_2435 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = failed__20; if linked_2436 == nil { arg_2429 = ifn_2437.Invoke_O__O(arg_2438) } else { arg_2429 = linked_2436.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2435, arg_2438) }; if linked_2426 == nil { arg_2424 = ifn_2427.Invoke_O_O__O(arg_2428, arg_2429) } else { arg_2424 = linked_2426.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2425, arg_2428, arg_2429) }; if linked_2422 == nil { tmp39 = ifn_2423.Invoke_O__O(arg_2424) } else { tmp39 = linked_2422.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2421, arg_2424) }; var tmp40 any = tmp39; var tmp41 any = A_arbace_j2g_world_A_const_179; var tmp42 any; var root_2439 any = /*line :276:1*/A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2441 lang.IFn; if













	linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = applied__11; if linked_2440 == nil { tmp42 = ifn_2441.Invoke_O__O(arg_2442) } else { tmp42 = linked_2440.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2439, arg_2442) }; return /*line :276:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, cs__18, tmp23, unit__19, tmp24, from_source__17, tmp25, tmp27, tmp28, tmp30, tmp31, tmp37, tmp38, tmp40, tmp41, tmp42, A_arbace_j2g_world_A_const_180, erased__9)) }




















func A_arbace_j2g_world_load_world_parse__78000228_A_New() *A_arbace_j2g_world_load_world_parse__78000228_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_parse__78000228_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_A) Ctor() {}
//line :297:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_A) Invoke_O_O__O(self, ins__1 any) any { var fs__2 any; var root_2161 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2163 lang.IFn; if
												linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_world_A_const_166.GetRawRoot__O(), ins__1); if linked_2162 == nil { fs__2 = ifn_2163.Invoke_O__O(arg_2164) } else { fs__2 = linked_2162.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2161, arg_2164) }; var root_2170 any =
												A_arbace_j2g_world_A_const_167.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, A_arbace_j2g_world_join_continued_A_fn_class); var ifn_2172 lang.IFn; if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp2 any; var root_2181 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2183 lang.IFn; if
												linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; if linked_2182 == nil { tmp2 = ifn_2183.Invoke__O() } else { tmp2 = linked_2182.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2181) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_New(); var tmp5 *jrt.Class; var fncls__2192 *jrt.Class = A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_fn_class; if fncls__2192 == nil { var fncls__2192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_fn_class = fncls__2192d; tmp5 = fncls__2192d } else { tmp5 = fncls__2192 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any; var root_2193 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2195 lang.IFn; if

	linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any; var tmp8 any = A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_New_O(fs__2); var tmp9 *jrt.Class; var fncls__2202 *jrt.Class = A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_fn_class; if fncls__2202 == nil { var fncls__2202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_fn_class = fncls__2202d; tmp9 = fncls__2202d } else { tmp9 = fncls__2202 }; arg_2196 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_2197 any; var root_2203 any = A_arbace_j2g_world_A_const_65.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(fs__2)).Ref(); if linked_2204 == nil { arg_2197 = ifn_2205.Invoke_O__O(arg_2206) } else { arg_2197 = linked_2204.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2203, arg_2206) }; if linked_2194 == nil { tmp7 = ifn_2195.Invoke_O_O__O(arg_2196, arg_2197) } else { tmp7 = linked_2194.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2193, arg_2196, arg_2197) }; arg_2173 = /*line :300:1*/tmp1.Invoke_O_O_O_O__O(tmp3, tmp6, fs__2, tmp7); if /*line :299:1*/ linked_2171 == nil { return ifn_2172.Invoke_O__O(arg_2173) } else { return linked_2171.(*A_arbace_j2g_world_join_continued_A).Invoke_O_O__O(root_2170, arg_2173) } }
func A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_New() *A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A) Ctor() {}
//line :300:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A) Invoke_O_O__O(self, f__1 any) any { var forms__2 any; var root_2184 any = A_arbace_j2g_world_A_const_129.GetRawRoot__O(); var linked_2185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2184, A_arbace_j2g_world_read_forms_A_fn_class); var ifn_2186 lang.IFn; if linked_2185 == nil { ifn_2186 = lang.IFn_Cast(root_2184) } else { ifn_2186 = nil }; var arg_2187 any = f__1; if linked_2185 == nil { forms__2 = ifn_2186.Invoke_O__O(arg_2187) } else { forms__2 = linked_2185.(*A_arbace_j2g_world_read_forms_A).Invoke_O_O__O(root_2184, arg_2187) }; var tmp1 any = A_arbace_j2g_world_A_const_168; var tmp2 any = A_arbace_j2g_world_A_const_50; var tmp3 any = A_arbace_j2g_world_A_const_143; var tmp4 any; var root_2188 any = A_arbace_j2g_world_A_const_130.GetRawRoot__O(); var linked_2189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2188, A_arbace_j2g_world_ns_of_forms_A_fn_class); var ifn_2190 lang.IFn; if linked_2189 == nil { ifn_2190 = lang.IFn_Cast(root_2188) } else { ifn_2190 = nil }; var arg_2191 any = forms__2; if linked_2189 == nil { tmp4 = ifn_2190.Invoke_O__O(arg_2191) } else { tmp4 = linked_2189.(*A_arbace_j2g_world_ns_of_forms_A).Invoke_O_O__O(root_2188, arg_2191) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, f__1, tmp2, forms__2, tmp3, tmp4)) }

func A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_New_O(p0 any) *A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :302:1
func (t *A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A) Invoke_O_O__O(self, p1__78000220_SHARP___1 any) any { var tmp1 any; var root_2198 any = A_arbace_j2g_world_A_const_95.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2198, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_2200 lang.IFn; if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var tmp2 any = t.F_fs; var arg_2201 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(p1__78000220_SHARP___1)); if linked_2199 == nil { tmp1 = ifn_2200.Invoke_O__O(arg_2201) } else { tmp1 = linked_2199.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_2198, arg_2201) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(jrt.NN(jrt.File_Cast(tmp1)).Length__J())).Ref() }

func A_arbace_j2g_world_load_world_top_set__78000234_A_New() *A_arbace_j2g_world_load_world_top_set__78000234_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_top_set__78000234_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_j2g_world_load_world_top_set__78000234_A) Ctor() {}
//line :304:1
func (t *A_arbace_j2g_world_load_world_top_set__78000234_A) Invoke_O_O__O(self, ps__1 any) any { var root_2212 any = A_arbace_j2g_world_A_const_151.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_New(); var tmp3 *jrt.Class; var fncls__2242 *jrt.Class = A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_fn_class; if fncls__2242 == nil { var fncls__2242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_fn_class = fncls__2242d; tmp3 = fncls__2242d } else { tmp3 = fncls__2242 }; arg_2215 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ps__1); if linked_2213 == nil { return ifn_2214.Invoke_O__O(arg_2215) } else { return linked_2213.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2212, arg_2215) } }
//line :304:1
func A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_New() *A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A) Ctor() {}
//line :304:1
func (t *A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A) Invoke_O_O__O(self, p__78000235__1 any) any { var map__78000237__2 any = p__78000235__1; var map__78000237__3 any; if lang.ISeq_InstanceOf(map__78000237__2) { var tmp1 any; var root_2221 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = map__78000237__2; if linked_2222 == nil { tmp1 = ifn_2223.Invoke_O__O(arg_2224) } else { tmp1 = linked_2222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2221, arg_2224) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2225 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = map__78000237__2; if linked_2226 == nil { tmp2 = ifn_2227.Invoke_O__O(arg_2228) } else { tmp2 = linked_2226.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2225, arg_2228) }; map__78000237__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2229 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = map__78000237__2; if linked_2230 == nil { tmp3 = ifn_2231.Invoke_O__O(arg_2232) } else { tmp3 = linked_2230.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2229, arg_2232) }; if jrt.J2g_Truth(tmp3) { var root_2233 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = map__78000237__2; if linked_2234 == nil { map__78000237__3 = ifn_2235.Invoke_O__O(arg_2236) } else { map__78000237__3 = linked_2234.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2233, arg_2236) } } else { map__78000237__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000237__3 = map__78000237__2 }; var ns__4 any = lang.RT_Get_O_O__O_NoInit(map__78000237__3, A_arbace_j2g_world_A_const_143); var forms__5 any = lang.RT_Get_O_O__O_NoInit(map__78000237__3, A_arbace_j2g_world_A_const_50); if jrt.J2g_Truth(ns__4) { var root_2237 any = A_arbace_j2g_world_A_const_169.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, A_arbace_j2g_world_top_names_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = ns__4; var arg_2241 any = forms__5; if linked_2238 == nil { return ifn_2239.Invoke_O_O__O(arg_2240, arg_2241) } else { return linked_2238.(*A_arbace_j2g_world_top_names_A).Invoke_O_O_O__O(root_2237, arg_2240, arg_2241) } } else { return nil } }

func A_arbace_j2g_world_load_world_top_of__78000241_A_New() *A_arbace_j2g_world_load_world_top_of__78000241_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_top_of__78000241_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_j2g_world_load_world_top_of__78000241_A) Ctor() {}
//line :306:1
func (t *A_arbace_j2g_world_load_world_top_of__78000241_A) Invoke_O_O__O(self, n__1 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__1)).IndexOf_String__I(Lit_13); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__1 } else { var root_2252 any = A_arbace_j2g_world_A_const_170.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2254 lang.IFn; if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = n__1; var arg_2256 any = A_arbace_j2g_world_A_const_111; var arg_2257 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_2253 == nil { return ifn_2254.Invoke_O_O_O__O(arg_2255, arg_2256, arg_2257) } else { return linked_2253.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2252, arg_2255, arg_2256, arg_2257) } } }
func A_arbace_j2g_world_load_world_from_source__78000243_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_from_source__78000243_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_from_source__78000243_A{}; t.Ctor_O_O(p0, p1); return t }
//line :307:1
func (t *A_arbace_j2g_world_load_world_from_source__78000243_A) Ctor_O_O(c__tops, c__top_of any) { t.F_tops = c__tops; t.F_top_of = c__top_of }
//line :307:1
func (t *A_arbace_j2g_world_load_world_from_source__78000243_A) Invoke_O_O__O(self, n__1 any) any { var root_2259 any = A_arbace_j2g_world_A_const_73.GetRawRoot__O(); var linked_2260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2259, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2261 lang.IFn; if linked_2260 == nil { ifn_2261 = lang.IFn_Cast(root_2259) } else { ifn_2261 = nil }; var arg_2262 any; var root_2264 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2264, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2266 lang.IFn; if linked_2265 == nil { ifn_2266 = lang.IFn_Cast(root_2264) } else { ifn_2266 = nil }; var arg_2267 any = t.F_tops; if linked_2265 == nil { arg_2262 = ifn_2266.Invoke_O__O(arg_2267) } else { arg_2262 = linked_2265.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2264, arg_2267) }; var arg_2263 any = lang.IFn_Cast(t.F_top_of).Invoke_O__O(n__1); if linked_2260 == nil { return ifn_2261.Invoke_O_O__O(arg_2262, arg_2263) } else { return linked_2260.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2259, arg_2262, arg_2263) } }



func A_arbace_j2g_world_load_world_fn__78000245_A_New_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9 any) *A_arbace_j2g_world_load_world_fn__78000245_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :311:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_A) Ctor_O_O_O_O_O_O_O_O_O_O(c__parsed, c__variants, c__parse, c__failed, c__top_set, c__wait, c__tops, c__unit, c__applied, c__late_inputs any) { t.F_parsed = c__parsed; t.F_variants = c__variants; t.F_parse = c__parse; t.F_failed = c__failed; t.F_top_set = c__top_set; t.F_wait = c__wait; t.F_tops = c__tops; t.F_unit = c__unit; t.F_applied = c__applied; t.F_late_inputs = c__late_inputs }
//line :311:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_A) Invoke_O__O(self any) any { var tmp1 any; tmp85 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var temp__1927000414__auto____3 any; var root_3684 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_3685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3684, A_arbace_j2g_world_id_space_A_fn_class); var ifn_3686 lang.IFn






	if linked_3685 == nil { ifn_3686 = lang.IFn_Cast(root_3684) } else { ifn_3686 = nil }; if linked_3685 == nil { temp__1927000414__auto____3 = ifn_3686.Invoke__O() } else { temp__1927000414__auto____3 = linked_3685.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_3684) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var space__4 any = temp__1927000414__auto____3
		jrt.ThreadLocal_Cast(space__4).Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_j2g_world_A_const_214.GetRawRoot__O()))) }
//line :311:1
	var t__3 any; var root_2443 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2443, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2445 lang.IFn








	if linked_2444 == nil { ifn_2445 = lang.IFn_Cast(root_2443) } else { ifn_2445 = nil }; var arg_2446 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref(); if linked_2444 == nil { t__3 = ifn_2445.Invoke_O__O(arg_2446) } else { t__3 = linked_2444.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2443, arg_2446) }
//line :311:1
	var laps__4 any; var root_2447 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2448 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2447, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2449 lang.IFn









	if linked_2448 == nil { ifn_2449 = lang.IFn_Cast(root_2447) } else { ifn_2449 = nil }; var arg_2450 any = lang.PersistentVector_EMPTY.Ref(); if linked_2448 == nil { laps__4 = ifn_2449.Invoke_O__O(arg_2450) } else { laps__4 = linked_2448.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2447, arg_2450) }
//line :311:1
	var lap__5 any; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_New_O_O(t__3, laps__4); var tmp3 *jrt.Class
	var fncls__2471 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_fn_class










	if fncls__2471 == nil { var fncls__2471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_fn_class = fncls__2471d; tmp3 = fncls__2471d } else { tmp3 = fncls__2471 }; lap__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :311:1
	var enter_BANG___6 any; var tmp4 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_New_O_O_O(t.F_variants, t.F_failed, t.F_applied); var tmp5 *jrt.Class
	var fncls__2840 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_fn_class
















	if fncls__2840 == nil { var fncls__2840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_fn_class = fncls__2840d; tmp5 = fncls__2840d } else { tmp5 = fncls__2840 }; enter_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :311:1
	var resolve_BANG___7 any; var tmp6 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_New_O_O(t.F_failed, lap__5); var tmp7 *jrt.Class
	var fncls__2947 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_fn_class





















































	if fncls__2947 == nil { var fncls__2947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_fn_class = fncls__2947d; tmp7 = fncls__2947d } else { tmp7 = fncls__2947 }; resolve_BANG___7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :311:1
	var analyze_BANG___8 any; var tmp8 any = A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_New_O(t.F_failed); var tmp9 *jrt.Class
	var fncls__2969 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_fn_class






































































	if fncls__2969 == nil { var fncls__2969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_fn_class = fncls__2969d; tmp9 = fncls__2969d } else { tmp9 = fncls__2969 }; analyze_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :311:1
	var ___9 any; var tmp10 lang.IFn = lang.IFn_Cast(enter_BANG___6); var tmp11 any; var root_3687 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3687, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3689 lang.IFn; _ = ___9












































































	if linked_3688 == nil { ifn_3689 = lang.IFn_Cast(root_3687) } else { ifn_3689 = nil }; var arg_3690 any = t.F_parsed; if linked_3688 == nil { tmp11 = ifn_3689.Invoke_O__O(arg_3690) } else { tmp11 = linked_3688.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3687, arg_3690) }; ___9 = tmp10.Invoke_O__O(tmp11)
//line :311:1
	var names1__10 any; var root_2970 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2970, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2972 lang.IFn








	if linked_2971 == nil { ifn_2972 = lang.IFn_Cast(root_2970) } else { ifn_2972 = nil }; var arg_2973 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); if linked_2971 == nil { names1__10 = ifn_2972.Invoke_O__O(arg_2973) } else { names1__10 = linked_2971.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2970, arg_2973) }
//line :311:1
	var ___11 any = lang.IFn_Cast(resolve_BANG___7).Invoke_O__O(names1__10); var rt_start__12 any; var G__78000328__12_ any; var root_2974 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_2975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2974, A_arbace_j2g_world_id_space_A_fn_class); var ifn_2976 lang.IFn; _ = ___11























































































	if linked_2975 == nil { ifn_2976 = lang.IFn_Cast(root_2974) } else { ifn_2976 = nil }; if linked_2975 == nil { G__78000328__12_ = ifn_2976.Invoke__O() } else { G__78000328__12_ = linked_2975.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_2974) }
//line :311:1
	var G__78000328__13_ any























































































	if lang.Util_Identical_O_O__Z_NoInit(G__78000328__12_, nil) { G__78000328__13_ = nil } else { G__78000328__13_ = jrt.ThreadLocal_Cast(G__78000328__12_).Get__O() }; if lang.Util_Identical_O_O__Z_NoInit(G__78000328__13_, nil) { rt_start__12 = nil } else { rt_start__12 = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.AtomicInteger_Cast(G__78000328__13_)).Get__I()).Ref() }
//line :311:1
	var rt_order__13 any; var root_2977 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2979 lang.IFn
























































































	if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any = names1__10; if linked_2978 == nil { rt_order__13 = ifn_2979.Invoke_O__O(arg_2980) } else { rt_order__13 = linked_2978.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2977, arg_2980) }
//line :311:1
	var runtime__14 any

























































































	if jrt.J2g_Truth(rt_start__12) {
		var root_2981 any = A_arbace_j2g_world_A_const_207.GetRawRoot__O(); var linked_2982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2981, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2983 lang.IFn; if linked_2982 == nil { ifn_2983 = lang.IFn_Cast(root_2981) } else { ifn_2983 = nil }; var arg_2984 any; var tmp12 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_New_O_O_O_O_O(rt_order__13, analyze_BANG___8, t.F_unit, rt_start__12, names1__10); var tmp13 *jrt.Class; var fncls__3014 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_fn_class; if fncls__3014 == nil { var fncls__3014d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_fn_class = fncls__3014d; tmp13 = fncls__3014d } else { tmp13 = fncls__3014 }; arg_2984 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); if linked_2982 == nil { runtime__14 = ifn_2983.Invoke_O__O(arg_2984) } else { runtime__14 = linked_2982.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2981, arg_2984) } } else {





			var root_3700 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_3701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3700, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3702 lang.IFn; if linked_3701 == nil { ifn_3702 = lang.IFn_Cast(root_3700) } else { ifn_3702 = nil }; var arg_3703 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_world_A_const_209; var tmp16 any; var root_3709 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_3710 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3709, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3711 lang.IFn; if linked_3710 == nil { ifn_3711 = lang.IFn_Cast(root_3709) } else { ifn_3711 = nil }; var arg_3712 any = t.F_unit; var arg_3713 any = A_arbace_j2g_world_A_const_133; var arg_3714 any = rt_order__13; if linked_3710 == nil { tmp16 = ifn_3711.Invoke_O_O_O__O(arg_3712, arg_3713, arg_3714) } else { tmp16 = linked_3710.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3709, arg_3712, arg_3713, arg_3714) }; arg_3703 = tmp14.Invoke_O_O__O(tmp15, tmp16); if linked_3701 == nil { ifn_3702.Invoke_O__O(arg_3703) } else { linked_3701.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3700, arg_3703) }; var tmp17 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_New_O_O(analyze_BANG___8, names1__10); var tmp18 *jrt.Class; var fncls__3699 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_fn_class; if fncls__3699 == nil { var fncls__3699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_fn_class = fncls__3699d; tmp18 = fncls__3699d } else { tmp18 = fncls__3699 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :401:1
			runtime__14 = nil }
//line :311:1
	var ___15 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_215); var ___16 any; _ = ___15; _ = ___16


































































































	if jrt.J2g_Truth(t.F_wait) { var tmp19 any; var t_ any = t.F_wait; t.F_wait = nil; tmp19 = t_; ___16 = lang.IFn_Cast(tmp19).Invoke__O() } else { ___16 = nil }
//line :311:1
	var ___17 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_164); var parsed2__18 any; var tmp20 any; var t__2 any = t.F_parse; _ = ___17




































































































	t.F_parse = nil; tmp20 = t__2; var tmp21 lang.IFn = lang.IFn_Cast(tmp20); var tmp22 any; var t__4 any = t.F_late_inputs; t.F_late_inputs = nil; tmp22 = t__4; parsed2__18 = tmp21.Invoke_O__O(tmp22)
//line :311:1
	var ___19 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_216); var ___20 any; var root_3015 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_3016 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3015, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3017 lang.IFn; _ = ___19; _ = ___20






































































































	if linked_3016 == nil { ifn_3017 = lang.IFn_Cast(root_3015) } else { ifn_3017 = nil }; var arg_3018 any; var t__5 any = t.F_tops; t.F_tops = nil; arg_3018 = t__5; var arg_3019 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_3020 any; var tmp23 any; var t__6 any = t.F_top_set; t.F_top_set = nil; tmp23 = t__6; arg_3020 = lang.IFn_Cast(tmp23).Invoke_O__O(parsed2__18); if linked_3016 == nil { ___20 = ifn_3017.Invoke_O_O_O__O(arg_3018, arg_3019, arg_3020) } else { ___20 = linked_3016.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3015, arg_3018, arg_3019, arg_3020) }
//line :311:1
	var ___21 any; var root_3021 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_3022 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3021, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3023 lang.IFn; _ = ___21







































































































	if linked_3022 == nil { ifn_3023 = lang.IFn_Cast(root_3021) } else { ifn_3023 = nil }; var arg_3024 any; var t__7 any = t.F_parsed; t.F_parsed = nil; arg_3024 = t__7; var arg_3025 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_3026 any = parsed2__18; if linked_3022 == nil { ___21 = ifn_3023.Invoke_O_O_O__O(arg_3024, arg_3025, arg_3026) } else { ___21 = linked_3022.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3021, arg_3024, arg_3025, arg_3026) }
//line :311:1
	var ___22 any = lang.IFn_Cast(enter_BANG___6).Invoke_O__O(parsed2__18); var names2__23 any; var root_3027 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3027, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3029 lang.IFn; _ = ___22









































































































	if linked_3028 == nil { ifn_3029 = lang.IFn_Cast(root_3027) } else { ifn_3029 = nil }; var arg_3030 any; var root_3031 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_3032 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3031, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_3033 lang.IFn; if linked_3032 == nil { ifn_3033 = lang.IFn_Cast(root_3031) } else { ifn_3033 = nil }; var arg_3034 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names1__10)).Ref(); var arg_3035 any; var root_3036 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3036, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3038 lang.IFn; if linked_3037 == nil { ifn_3038 = lang.IFn_Cast(root_3036) } else { ifn_3038 = nil }; var arg_3039 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); if linked_3037 == nil { arg_3035 = ifn_3038.Invoke_O__O(arg_3039) } else { arg_3035 = linked_3037.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3036, arg_3039) }; if linked_3032 == nil { arg_3030 = ifn_3033.Invoke_O_O__O(arg_3034, arg_3035) } else { if jrt.Long_InstanceOf(arg_3034) { arg_3030 = linked_3032.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_3031, jrt.NN(jrt.Long_Cast(arg_3034)).LongValue__J(), arg_3034, arg_3035) } else { arg_3030 = linked_3032.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_3031, arg_3034, arg_3035) } }; if linked_3028 == nil { names2__23 = ifn_3029.Invoke_O__O(arg_3030) } else { names2__23 = linked_3028.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3027, arg_3030) }
//line :311:1
	var ___24 any = lang.IFn_Cast(resolve_BANG___7).Invoke_O__O(names2__23); var tops_QMARK___25 any; var tmp24 any = A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_New(); var tmp25 *jrt.Class; var fncls__3049 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_fn_class; _ = ___24

























































































































	if fncls__3049 == nil { var fncls__3049d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_fn_class = fncls__3049d; tmp25 = fncls__3049d } else { tmp25 = fncls__3049 }; tops_QMARK___25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil)
//line :311:1
	var heights__26 any; var root_3050 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3052 lang.IFn


























































































































	if linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3051 == nil { heights__26 = ifn_3052.Invoke_O__O(arg_3053) } else { heights__26 = linked_3051.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3050, arg_3053) }
//line :311:1
	var height__27 any; var tmp26 any = A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_New_O(heights__26); var tmp27 *jrt.Class
	var fncls__3099 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_fn_class



























































































































	if fncls__3099 == nil { var fncls__3099d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_fn_class = fncls__3099d; tmp27 = fncls__3099d } else { tmp27 = fncls__3099 }; height__27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil)
//line :311:1
	var levels__28 any; var root_3100 any = A_arbace_j2g_world_A_const_155.GetRawRoot__O(); var linked_3101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3100, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_3102 lang.IFn

































































































































	if linked_3101 == nil { ifn_3102 = lang.IFn_Cast(root_3100) } else { ifn_3102 = nil }; var arg_3103 any = height__27; var arg_3104 any = names2__23; if linked_3101 == nil { levels__28 = ifn_3102.Invoke_O_O__O(arg_3103, arg_3104) } else { levels__28 = linked_3101.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_3100, arg_3103, arg_3104) }
//line :311:1
	var groups__29 any; var root_3105 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3105, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3107 lang.IFn


































































































































	if linked_3106 == nil { ifn_3107 = lang.IFn_Cast(root_3105) } else { ifn_3107 = nil }; var arg_3108 any; var root_3109 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_3110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3109, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3111 lang.IFn; if linked_3110 == nil { ifn_3111 = lang.IFn_Cast(root_3109) } else { ifn_3111 = nil }; var arg_3112 any; var iter__1927001039__auto____29 any; var tmp28 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_New_O_O(tops_QMARK___25, height__27); var tmp29 *jrt.Class; var fncls__3180 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_fn_class; if fncls__3180 == nil { var fncls__3180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_fn_class = fncls__3180d; tmp29 = fncls__3180d } else { tmp29 = fncls__3180 }; iter__1927001039__auto____29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); arg_3112 = lang.IFn_Cast(iter__1927001039__auto____29).Invoke_O__O(names2__23); var arg_3113 any; var iter__1927001039__auto____29_2 any; var tmp30 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_New_O_O(tops_QMARK___25, height__27); var tmp31 *jrt.Class; var fncls__3255 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_fn_class
	if fncls__3255 == nil { var fncls__3255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_fn_class = fncls__3255d; tmp31 = fncls__3255d } else { tmp31 = fncls__3255 }; iter__1927001039__auto____29_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil); arg_3113 = lang.IFn_Cast(iter__1927001039__auto____29_2).Invoke_O__O(names2__23)
//line :442:1
	if linked_3110 == nil { arg_3108 = ifn_3111.Invoke_O_O__O(arg_3112, arg_3113) } else { arg_3108 = linked_3110.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3109, arg_3112, arg_3113) }; if linked_3106 == nil { groups__29 = ifn_3107.Invoke_O__O(arg_3108) } else { groups__29 = linked_3106.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3105, arg_3108) }
//line :311:1
	var top_groups__30 any; var iter__1927001039__auto____30 any; var tmp32 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_New_O_O(tops_QMARK___25, levels__28); var tmp33 *jrt.Class
	var fncls__3600 /*line :311:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_fn_class




































































































































	if fncls__3600 == nil { var fncls__3600d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_fn_class = fncls__3600d; tmp33 = fncls__3600d } else { tmp33 = fncls__3600 }; iter__1927001039__auto____30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var tmp34 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____30); var tmp35 any; var root_3715 any = A_arbace_j2g_world_A_const_80.GetRawRoot__O(); var linked_3716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3715, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3717 lang.IFn; if linked_3716 == nil { ifn_3717 = lang.IFn_Cast(root_3715) } else { ifn_3717 = nil }; var arg_3718 any; var root_3719 any = A_arbace_j2g_world_A_const_77.GetRawRoot__O(); var linked_3720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3719, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3721 lang.IFn; if linked_3720 == nil { ifn_3721 = lang.IFn_Cast(root_3719) } else { ifn_3721 = nil }; var arg_3722 any = A_arbace_j2g_world_A_const_217.GetRawRoot__O(); var arg_3723 any; var root_3724 any = A_arbace_j2g_world_A_const_78.GetRawRoot__O(); var linked_3725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3724, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_3726 lang.IFn; if linked_3725 == nil { ifn_3726 = lang.IFn_Cast(root_3724) } else { ifn_3726 = nil }; var arg_3727 any = levels__28; if linked_3725 == nil { arg_3723 = ifn_3726.Invoke_O__O(arg_3727) } else { arg_3723 = linked_3725.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_3724, arg_3727) }; if linked_3720 == nil { arg_3718 = ifn_3721.Invoke_O_O__O(arg_3722, arg_3723) } else { arg_3718 = linked_3720.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3719, arg_3722, arg_3723) }; if linked_3716 == nil { tmp35 = ifn_3717.Invoke_O__O(arg_3718) } else { tmp35 = linked_3716.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3715, arg_3718) }; top_groups__30 = tmp34.Invoke_O__O(tmp35)







	var tmp36 any; var root_3728 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3728, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3730 lang.IFn; if linked_3729 == nil { ifn_3730 = lang.IFn_Cast(root_3728) } else { ifn_3730 = nil }; var arg_3731 any = names2__23; if linked_3729 == nil { tmp36 = ifn_3730.Invoke_O__O(arg_3731) } else { tmp36 = linked_3729.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3728, arg_3731) }; if jrt.J2g_Truth(tmp36) { var space__31 any; var root_3732 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_3733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3732, A_arbace_j2g_world_id_space_A_fn_class); var ifn_3734 lang.IFn
		if linked_3733 == nil { ifn_3734 = lang.IFn_Cast(root_3732) } else { ifn_3734 = nil }; if linked_3733 == nil { space__31 = ifn_3734.Invoke__O() } else { space__31 = linked_3733.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_3732) }
//line :452:1
		var prev__32 any
		var G__78000409__32_ any = space__31
		if lang.Util_Identical_O_O__Z_NoInit(G__78000409__32_, nil) { prev__32 = nil } else { prev__32 = jrt.ThreadLocal_Cast(G__78000409__32_).Get__O() }
//line :452:1
		var G__78000410__33_ any = space__31


		if lang.Util_Identical_O_O__Z_NoInit(G__78000410__33_, nil) { } else { jrt.ThreadLocal_Cast(G__78000410__33_).Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_j2g_world_A_const_214.GetRawRoot__O()))) }
		var tmp37 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_New_O_O(space__31, prev__32); var tmp38 *jrt.Class; var fncls__3739 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_fn_class; if fncls__3739 == nil { var fncls__3739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_fn_class = fncls__3739d; tmp38 = fncls__3739d } else { tmp38 = fncls__3739 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil).Invoke__O() }
//line :311:1
	var temp__1927000408__auto____31 any; var root_3740 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_3741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3740, A_arbace_j2g_world_id_space_A_fn_class); var ifn_3742 lang.IFn


















































































































































	if linked_3741 == nil { ifn_3742 = lang.IFn_Cast(root_3740) } else { ifn_3742 = nil }; if linked_3741 == nil { temp__1927000408__auto____31 = ifn_3742.Invoke__O() } else { temp__1927000408__auto____31 = linked_3741.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_3740) }; if jrt.J2g_Truth(temp__1927000408__auto____31) { var space__32 any = temp__1927000408__auto____31; var seq_78000413__33 any; var root_3743 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3743, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3745 lang.IFn
		if linked_3744 == nil { ifn_3745 = lang.IFn_Cast(root_3743) } else { ifn_3745 = nil }; var arg_3746 any; var root_3747 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3747, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3749 lang.IFn; if linked_3748 == nil { ifn_3749 = lang.IFn_Cast(root_3747) } else { ifn_3749 = nil }; var arg_3750 any = groups__29; var arg_3751 any = top_groups__30; if linked_3748 == nil { arg_3746 = ifn_3749.Invoke_O_O__O(arg_3750, arg_3751) } else { arg_3746 = linked_3748.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3747, arg_3750, arg_3751) }; if linked_3744 == nil { seq_78000413__33 = ifn_3745.Invoke_O__O(arg_3746) } else { seq_78000413__33 = linked_3744.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3743, arg_3746) }
//line :458:1
		var chunk_78000414__34 any; var count_78000415__35 int64 = 0; var i_78000416__36 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_78000416__36, count_78000415__35) { var gs__37 any = lang.Indexed_Cast(chunk_78000414__34).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000416__36)); var t0__38 int64 = jrt.System_NanoTime__J(); var rs__39 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp40 any; var root_3820 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_3821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3820, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3822 lang.IFn







				if linked_3821 == nil { ifn_3822 = lang.IFn_Cast(root_3820) } else { ifn_3822 = nil }; if linked_3821 == nil { tmp40 = ifn_3822.Invoke__O() } else { tmp40 = linked_3821.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3820) }; var tmp41 any = tmp40; var tmp42 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_New_O_O_O(space__32, analyze_BANG___8, t.F_unit); var tmp43 *jrt.Class; var fncls__3859 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_fn_class
				if fncls__3859 == nil { var fncls__3859d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_fn_class = fncls__3859d; tmp43 = fncls__3859d } else { tmp43 = fncls__3859 }
//line :467:1
				rs__39 = tmp39.Invoke_O_O_O__O(tmp41, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil), gs__37)
//line :459:1
				var ___40 any; var root_3860 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_3861 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3860, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3862 lang.IFn; _ = ___40
















				if linked_3861 == nil { ifn_3862 = lang.IFn_Cast(root_3860) } else { ifn_3862 = nil }; var arg_3863 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); var arg_3864 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_3865 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()); var tmp45 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_New(); var tmp46 *jrt.Class; var fncls__3871 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_fn_class; if fncls__3871 == nil { var fncls__3871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_fn_class = fncls__3871d; tmp46 = fncls__3871d } else { tmp46 = fncls__3871 }; arg_3865 = tmp44.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil), rs__39); if linked_3861 == nil { ___40 = ifn_3862.Invoke_O_O_O__O(arg_3863, arg_3864, arg_3865) } else { ___40 = linked_3861.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3860, arg_3863, arg_3864, arg_3865)
				}
				if jrt.System_Getenv_String__String(Lit_58) != nil {
					var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()); var tmp49 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__39)).Ref(); var tmp50 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__38), 1.0e9)).Ref(); var tmp51 any; var root_3918 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_3919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3918, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3920 lang.IFn
					if linked_3919 == nil { ifn_3920 = lang.IFn_Cast(root_3918) } else { ifn_3920 = nil }; var arg_3921 any = A_arbace_j2g_world_A_const_224.GetRawRoot__O(); var arg_3922 any; var root_3923 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_3924 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3923, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3925 lang.IFn; if linked_3924 == nil { ifn_3925 = lang.IFn_Cast(root_3923) } else { ifn_3925 = nil }; var arg_3926 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var arg_3927 any = rs__39; if linked_3924 == nil { arg_3922 = ifn_3925.Invoke_O_O__O(arg_3926, arg_3927) } else { arg_3922 = linked_3924.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3923, arg_3926, arg_3927) }; if linked_3919 == nil { tmp51 = ifn_3920.Invoke_O_O__O(arg_3921, arg_3922) } else { tmp51 = linked_3919.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3918, arg_3921, arg_3922) }
//line :479:1
					tmp47.Invoke_O__O(tmp48.Invoke_O_O_O_O__O(Lit_59, tmp49, tmp50, jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp51)).Ref()))
//line :478:1
					var seq_78000423__41 any; var root_3872 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3872, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3874 lang.IFn


					if linked_3873 == nil { ifn_3874 = lang.IFn_Cast(root_3872) } else { ifn_3874 = nil }; var arg_3875 any; var root_3876 any = A_arbace_j2g_world_A_const_219.GetRawRoot__O(); var linked_3877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3876, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_3878 lang.IFn; if linked_3877 == nil { ifn_3878 = lang.IFn_Cast(root_3876) } else { ifn_3878 = nil }; var arg_3879 any = A_arbace_j2g_world_A_const_220; var arg_3880 any; var root_3881 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_3882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3881, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3883 lang.IFn; if linked_3882 == nil { ifn_3883 = lang.IFn_Cast(root_3881) } else { ifn_3883 = nil }; var arg_3884 any; var root_3886 any = A_arbace_j2g_world_A_const_221.GetRawRoot__O(); var linked_3887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3886, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_3888 lang.IFn; if linked_3887 == nil { ifn_3888 = lang.IFn_Cast(root_3886) } else { ifn_3888 = nil }; var arg_3889 any = A_arbace_j2g_world_A_const_222.GetRawRoot__O(); var arg_3890 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); if linked_3887 == nil { arg_3884 = ifn_3888.Invoke_O_O__O(arg_3889, arg_3890) } else { arg_3884 = linked_3887.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_3886, arg_3889, arg_3890) }; var arg_3885 any = rs__39; if linked_3882 == nil { arg_3880 = ifn_3883.Invoke_O_O__O(arg_3884, arg_3885) } else { arg_3880 = linked_3882.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3881, arg_3884, arg_3885) }; if linked_3877 == nil { arg_3875 = ifn_3878.Invoke_O_O__O(arg_3879, arg_3880) } else { arg_3875 = linked_3877.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_3876, arg_3879, arg_3880) }; if linked_3873 == nil { seq_78000423__41 = ifn_3874.Invoke_O__O(arg_3875) } else { seq_78000423__41 = linked_3873.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3872, arg_3875) }
//line :478:1
					var chunk_78000424__42 any; var count_78000425__43 int64 = 0; var i_78000426__44 int64 = 0; L2: for {


						if lang.Numbers_Lt_J_J__Z_NoInit(i_78000426__44, count_78000425__43) { var vec__78000427__45 any = lang.Indexed_Cast(chunk_78000424__42).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000426__44)); var n__46 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000427__45, lang.RT_IntCast_J__I_NoInit(0), nil); var d__47 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000427__45, lang.RT_IntCast_J__I_NoInit(1), nil)
							lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, d__47, n__46))
//line :481:1
							seq_78000423__41, chunk_78000424__42, count_78000425__43, i_78000426__44 = seq_78000423__41, chunk_78000424__42, count_78000425__43, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000426__44); continue L2 } else { var temp__1927000414__auto____45 any; var root_3891 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3891, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3893 lang.IFn; if linked_3892 == nil { ifn_3893 = lang.IFn_Cast(root_3891) } else { ifn_3893 = nil }; var arg_3894 any = seq_78000423__41; if linked_3892 == nil { temp__1927000414__auto____45 = ifn_3893.Invoke_O__O(arg_3894) } else { temp__1927000414__auto____45 = linked_3892.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3891, arg_3894) }; if jrt.J2g_Truth(temp__1927000414__auto____45) { var seq_78000423__46 any = temp__1927000414__auto____45; var tmp52 any; var root_3895 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3895, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3897 lang.IFn; if linked_3896 == nil { ifn_3897 = lang.IFn_Cast(root_3895) } else { ifn_3897 = nil }; var arg_3898 any = seq_78000423__46; if linked_3896 == nil { tmp52 = ifn_3897.Invoke_O__O(arg_3898) } else { tmp52 = linked_3896.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3895, arg_3898) }; if jrt.J2g_Truth(tmp52) { var c__1927000678__auto____47 any; var root_3899 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3899, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3901 lang.IFn; if linked_3900 == nil { ifn_3901 = lang.IFn_Cast(root_3899) } else { ifn_3901 = nil }; var arg_3902 any = seq_78000423__46; if linked_3900 == nil { c__1927000678__auto____47 = ifn_3901.Invoke_O__O(arg_3902) } else { c__1927000678__auto____47 = linked_3900.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3899, arg_3902) }; var tmp53 any; var root_3938 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3938, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3940 lang.IFn; if linked_3939 == nil { ifn_3940 = lang.IFn_Cast(root_3938) } else { ifn_3940 = nil }; var arg_3941 any = seq_78000423__46; if linked_3939 == nil { tmp53 = ifn_3940.Invoke_O__O(arg_3941) } else { tmp53 = linked_3939.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3938, arg_3941) }; seq_78000423__41, chunk_78000424__42, count_78000425__43, i_78000426__44 = tmp53, c__1927000678__auto____47, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____47))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__78000430__47 any; var root_3903 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3903, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3905 lang.IFn; if linked_3904 == nil { ifn_3905 = lang.IFn_Cast(root_3903) } else { ifn_3905 = nil }; var arg_3906 any = seq_78000423__46; if linked_3904 == nil { vec__78000430__47 = ifn_3905.Invoke_O__O(arg_3906) } else { vec__78000430__47 = linked_3904.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3903, arg_3906) }; var n__48 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000430__47, lang.RT_IntCast_J__I_NoInit(0), nil); var d__49 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000430__47, lang.RT_IntCast_J__I_NoInit(1), nil)
								lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, d__49, n__48))
//line :481:1
								var tmp54 any; var root_3952 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_3953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3952, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3954 lang.IFn; if linked_3953 == nil { ifn_3954 = lang.IFn_Cast(root_3952) } else { ifn_3954 = nil }; var arg_3955 any = seq_78000423__46; if linked_3953 == nil { tmp54 = ifn_3954.Invoke_O__O(arg_3955) } else { tmp54 = linked_3953.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3952, arg_3955) }; seq_78000423__41, chunk_78000424__42, count_78000425__43, i_78000426__44 = tmp54, nil, 0, 0; continue L2 } } }
//line :478:1
						break L2 } }
//line :459:1
				seq_78000413__33, chunk_78000414__34, count_78000415__35, i_78000416__36 = seq_78000413__33, chunk_78000414__34, count_78000415__35, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000416__36); continue L1 } else { var temp__1927000414__auto____37 any; var root_3752 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3752, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3754 lang.IFn; if linked_3753 == nil { ifn_3754 = lang.IFn_Cast(root_3752) } else { ifn_3754 = nil }; var arg_3755 any = seq_78000413__33; if linked_3753 == nil { temp__1927000414__auto____37 = ifn_3754.Invoke_O__O(arg_3755) } else { temp__1927000414__auto____37 = linked_3753.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3752, arg_3755) }; if jrt.J2g_Truth(temp__1927000414__auto____37) { var seq_78000413__38 any = temp__1927000414__auto____37; var tmp55 any; var root_3756 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3756, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3758 lang.IFn; if linked_3757 == nil { ifn_3758 = lang.IFn_Cast(root_3756) } else { ifn_3758 = nil }; var arg_3759 any = seq_78000413__38; if linked_3757 == nil { tmp55 = ifn_3758.Invoke_O__O(arg_3759) } else { tmp55 = linked_3757.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3756, arg_3759) }; if jrt.J2g_Truth(tmp55) { var c__1927000678__auto____39 any; var root_3760 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3760, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3762 lang.IFn; if linked_3761 == nil { ifn_3762 = lang.IFn_Cast(root_3760) } else { ifn_3762 = nil }; var arg_3763 any = seq_78000413__38; if linked_3761 == nil { c__1927000678__auto____39 = ifn_3762.Invoke_O__O(arg_3763) } else { c__1927000678__auto____39 = linked_3761.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3760, arg_3763) }; var tmp56 any; var root_3956 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3956, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3958 lang.IFn; if linked_3957 == nil { ifn_3958 = lang.IFn_Cast(root_3956) } else { ifn_3958 = nil }; var arg_3959 any = seq_78000413__38; if linked_3957 == nil { tmp56 = ifn_3958.Invoke_O__O(arg_3959) } else { tmp56 = linked_3957.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3956, arg_3959) }; seq_78000413__33, chunk_78000414__34, count_78000415__35, i_78000416__36 = tmp56, c__1927000678__auto____39, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____39))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var gs__39 any; var root_3764 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3764, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3766 lang.IFn; if linked_3765 == nil { ifn_3766 = lang.IFn_Cast(root_3764) } else { ifn_3766 = nil }; var arg_3767 any = seq_78000413__38; if linked_3765 == nil { gs__39 = ifn_3766.Invoke_O__O(arg_3767) } else { gs__39 = linked_3765.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3764, arg_3767) }; var t0__40 int64 = jrt.System_NanoTime__J(); var rs__41 any; var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp58 any; var root_3966 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_3967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3966, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3968 lang.IFn







					if linked_3967 == nil { ifn_3968 = lang.IFn_Cast(root_3966) } else { ifn_3968 = nil }; if linked_3967 == nil { tmp58 = ifn_3968.Invoke__O() } else { tmp58 = linked_3967.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3966) }; var tmp59 any = tmp58; var tmp60 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_New_O_O_O(space__32, analyze_BANG___8, t.F_unit); var tmp61 *jrt.Class; var fncls__4005 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_fn_class
					if fncls__4005 == nil { var fncls__4005d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_fn_class = fncls__4005d; tmp61 = fncls__4005d } else { tmp61 = fncls__4005 }
//line :467:1
					rs__41 = tmp57.Invoke_O_O_O__O(tmp59, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil), gs__39)
//line :459:1
					var ___42 any; var root_4006 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_4007 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4006, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4008 lang.IFn; _ = ___42
















					if linked_4007 == nil { ifn_4008 = lang.IFn_Cast(root_4006) } else { ifn_4008 = nil }; var arg_4009 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); var arg_4010 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var arg_4011 any; var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_70.GetRawRoot__O()); var tmp63 any = A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_New(); var tmp64 *jrt.Class; var fncls__4017 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_fn_class; if fncls__4017 == nil { var fncls__4017d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_fn_class = fncls__4017d; tmp64 = fncls__4017d } else { tmp64 = fncls__4017 }; arg_4011 = tmp62.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp63, tmp64, nil), rs__41); if linked_4007 == nil { ___42 = ifn_4008.Invoke_O_O_O__O(arg_4009, arg_4010, arg_4011) } else { ___42 = linked_4007.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_4006, arg_4009, arg_4010, arg_4011)
					}
					if jrt.System_Getenv_String__String(Lit_58) != nil {
						var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()); var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()); var tmp67 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__41)).Ref(); var tmp68 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__40), 1.0e9)).Ref(); var tmp69 any; var root_4064 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_4065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4064, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_4066 lang.IFn
						if linked_4065 == nil { ifn_4066 = lang.IFn_Cast(root_4064) } else { ifn_4066 = nil }; var arg_4067 any = A_arbace_j2g_world_A_const_224.GetRawRoot__O(); var arg_4068 any; var root_4069 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_4070 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4069, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4071 lang.IFn; if linked_4070 == nil { ifn_4071 = lang.IFn_Cast(root_4069) } else { ifn_4071 = nil }; var arg_4072 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); var arg_4073 any = rs__41; if linked_4070 == nil { arg_4068 = ifn_4071.Invoke_O_O__O(arg_4072, arg_4073) } else { arg_4068 = linked_4070.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4069, arg_4072, arg_4073) }; if linked_4065 == nil { tmp69 = ifn_4066.Invoke_O_O__O(arg_4067, arg_4068) } else { tmp69 = linked_4065.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_4064, arg_4067, arg_4068) }
//line :479:1
						tmp65.Invoke_O__O(tmp66.Invoke_O_O_O_O__O(Lit_59, tmp67, tmp68, jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp69)).Ref()))
//line :478:1
						var seq_78000439__43 any; var root_4018 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4018, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4020 lang.IFn


						if linked_4019 == nil { ifn_4020 = lang.IFn_Cast(root_4018) } else { ifn_4020 = nil }; var arg_4021 any; var root_4022 any = A_arbace_j2g_world_A_const_219.GetRawRoot__O(); var linked_4023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4022, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_4024 lang.IFn; if linked_4023 == nil { ifn_4024 = lang.IFn_Cast(root_4022) } else { ifn_4024 = nil }; var arg_4025 any = A_arbace_j2g_world_A_const_220; var arg_4026 any; var root_4027 any = A_arbace_j2g_world_A_const_96.GetRawRoot__O(); var linked_4028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4027, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_4029 lang.IFn; if linked_4028 == nil { ifn_4029 = lang.IFn_Cast(root_4027) } else { ifn_4029 = nil }; var arg_4030 any; var root_4032 any = A_arbace_j2g_world_A_const_221.GetRawRoot__O(); var linked_4033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4032, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_4034 lang.IFn; if linked_4033 == nil { ifn_4034 = lang.IFn_Cast(root_4032) } else { ifn_4034 = nil }; var arg_4035 any = A_arbace_j2g_world_A_const_222.GetRawRoot__O(); var arg_4036 any = A_arbace_j2g_world_A_const_62.GetRawRoot__O(); if linked_4033 == nil { arg_4030 = ifn_4034.Invoke_O_O__O(arg_4035, arg_4036) } else { arg_4030 = linked_4033.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_4032, arg_4035, arg_4036) }; var arg_4031 any = rs__41; if linked_4028 == nil { arg_4026 = ifn_4029.Invoke_O_O__O(arg_4030, arg_4031) } else { arg_4026 = linked_4028.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_4027, arg_4030, arg_4031) }; if linked_4023 == nil { arg_4021 = ifn_4024.Invoke_O_O__O(arg_4025, arg_4026) } else { arg_4021 = linked_4023.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_4022, arg_4025, arg_4026) }; if linked_4019 == nil { seq_78000439__43 = ifn_4020.Invoke_O__O(arg_4021) } else { seq_78000439__43 = linked_4019.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4018, arg_4021) }
//line :478:1
						var chunk_78000440__44 any; var count_78000441__45 int64 = 0; var i_78000442__46 int64 = 0; L3: for {


							if lang.Numbers_Lt_J_J__Z_NoInit(i_78000442__46, count_78000441__45) { var vec__78000443__47 any = lang.Indexed_Cast(chunk_78000440__44).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000442__46)); var n__48_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000443__47, lang.RT_IntCast_J__I_NoInit(0), nil); var d__49_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000443__47, lang.RT_IntCast_J__I_NoInit(1), nil)
								lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, d__49_2, n__48_2))
//line :481:1
								seq_78000439__43, chunk_78000440__44, count_78000441__45, i_78000442__46 = seq_78000439__43, chunk_78000440__44, count_78000441__45, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000442__46); continue L3 } else { var temp__1927000414__auto____47 any; var root_4037 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4037, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4039 lang.IFn; if linked_4038 == nil { ifn_4039 = lang.IFn_Cast(root_4037) } else { ifn_4039 = nil }; var arg_4040 any = seq_78000439__43; if linked_4038 == nil { temp__1927000414__auto____47 = ifn_4039.Invoke_O__O(arg_4040) } else { temp__1927000414__auto____47 = linked_4038.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4037, arg_4040) }; if jrt.J2g_Truth(temp__1927000414__auto____47) { var seq_78000439__48 any = temp__1927000414__auto____47; var tmp70 any; var root_4041 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_4042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4041, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4043 lang.IFn; if linked_4042 == nil { ifn_4043 = lang.IFn_Cast(root_4041) } else { ifn_4043 = nil }; var arg_4044 any = seq_78000439__48; if linked_4042 == nil { tmp70 = ifn_4043.Invoke_O__O(arg_4044) } else { tmp70 = linked_4042.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4041, arg_4044) }; if jrt.J2g_Truth(tmp70) { var c__1927000678__auto____49 any; var root_4045 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_4046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4045, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4047 lang.IFn; if linked_4046 == nil { ifn_4047 = lang.IFn_Cast(root_4045) } else { ifn_4047 = nil }; var arg_4048 any = seq_78000439__48; if linked_4046 == nil { c__1927000678__auto____49 = ifn_4047.Invoke_O__O(arg_4048) } else { c__1927000678__auto____49 = linked_4046.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4045, arg_4048) }; var tmp71 any; var root_4084 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_4085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4084, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4086 lang.IFn; if linked_4085 == nil { ifn_4086 = lang.IFn_Cast(root_4084) } else { ifn_4086 = nil }; var arg_4087 any = seq_78000439__48; if linked_4085 == nil { tmp71 = ifn_4086.Invoke_O__O(arg_4087) } else { tmp71 = linked_4085.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4084, arg_4087) }; seq_78000439__43, chunk_78000440__44, count_78000441__45, i_78000442__46 = tmp71, c__1927000678__auto____49, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____49))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__78000446__49 any; var root_4049 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_4050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4049, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4051 lang.IFn; if linked_4050 == nil { ifn_4051 = lang.IFn_Cast(root_4049) } else { ifn_4051 = nil }; var arg_4052 any = seq_78000439__48; if linked_4050 == nil { vec__78000446__49 = ifn_4051.Invoke_O__O(arg_4052) } else { vec__78000446__49 = linked_4050.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4049, arg_4052) }; var n__50 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000446__49, lang.RT_IntCast_J__I_NoInit(0), nil); var d__51 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000446__49, lang.RT_IntCast_J__I_NoInit(1), nil)
									lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_world_A_const_223.GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, d__51, n__50))
//line :481:1
									var tmp72 any; var root_4098 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_4099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4098, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4100 lang.IFn; if linked_4099 == nil { ifn_4100 = lang.IFn_Cast(root_4098) } else { ifn_4100 = nil }; var arg_4101 any = seq_78000439__48; if linked_4099 == nil { tmp72 = ifn_4100.Invoke_O__O(arg_4101) } else { tmp72 = linked_4099.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4098, arg_4101) }; seq_78000439__43, chunk_78000440__44, count_78000441__45, i_78000442__46 = tmp72, nil, 0, 0; continue L3 } } }
//line :478:1
							break L3 } }
//line :459:1
					var tmp73 any; var root_4102 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_4103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4102, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4104 lang.IFn; if linked_4103 == nil { ifn_4104 = lang.IFn_Cast(root_4102) } else { ifn_4104 = nil }; var arg_4105 any = seq_78000413__38; if linked_4103 == nil { tmp73 = ifn_4104.Invoke_O__O(arg_4105) } else { tmp73 = linked_4103.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4102, arg_4105) }; seq_78000413__33, chunk_78000414__34, count_78000415__35, i_78000416__36 = tmp73, nil, 0, 0; continue L1 } } }
//line :458:1
			break L1 } } else {

























				var root_3768 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_3769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3768, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3770 lang.IFn; if linked_3769 == nil { ifn_3770 = lang.IFn_Cast(root_3768) } else { ifn_3770 = nil }; var arg_3771 any = analyze_BANG___8; var arg_3772 any = names2__23; if linked_3769 == nil { ifn_3770.Invoke_O_O__O(arg_3771, arg_3772) } else { linked_3769.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3768, arg_3771, arg_3772) } }
	lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_225)
//line :311:1
	var G__78000449__31_ any = runtime__14














































































































































































	if lang.Util_Identical_O_O__Z_NoInit(G__78000449__31_, nil) { } else { var root_3773 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3775 lang.IFn; if linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any = G__78000449__31_; if linked_3774 == nil { ifn_3775.Invoke_O__O(arg_3776) } else { linked_3774.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3773, arg_3776) } }
//line :311:1
	var main__31 any; var root_3777 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3777, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3779 lang.IFn

















































































































































































	if linked_3778 == nil { ifn_3779 = lang.IFn_Cast(root_3777) } else { ifn_3779 = nil }; var arg_3780 any = A_arbace_j2g_world_A_const_133.Invoke_O__O(t.F_unit); if linked_3778 == nil { main__31 = ifn_3779.Invoke_O__O(arg_3780) } else { main__31 = linked_3778.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3777, arg_3780) }
//line :311:1
	var late__32 any; var root_3781 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_3782 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3781, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_3783 lang.IFn


















































































































































































	if linked_3782 == nil { ifn_3783 = lang.IFn_Cast(root_3781) } else { ifn_3783 = nil }; var arg_3784 int64 = lang.Numbers_Add_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(names1__10)), int64(lang.RT_Count_O__I_NoInit(names2__23))); var arg_3785 any = main__31; if linked_3782 == nil { late__32 = ifn_3783.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_3784).Ref(), arg_3785) } else { late__32 = linked_3782.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_3781, arg_3784, nil, arg_3785) }
	lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_64), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(late__32)).Ref(), nil)).Ref())
	var root_3786 any = A_arbace_j2g_world_A_const_181.GetRawRoot__O(); var linked_3787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3786, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_3788 lang.IFn; if linked_3787 == nil { ifn_3788 = lang.IFn_Cast(root_3786) } else { ifn_3788 = nil }; var arg_3789 any; var tmp74 *lang.Keyword = A_arbace_j2g_world_A_const_133; var tmp75 any; var t__8 any = t.F_unit; t.F_unit = nil; tmp75 = t__8; arg_3789 = tmp74.Invoke_O__O(tmp75); var arg_3790 any; var root_3791 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3791, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3793 lang.IFn; if linked_3792 == nil { ifn_3793 = lang.IFn_Cast(root_3791) } else { ifn_3793 = nil }; var arg_3794 any; var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()); var tmp77 any; var root_3802 any = A_arbace_j2g_world_A_const_52.GetRawRoot__O(); var linked_3803 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3802, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_3804 lang.IFn; if linked_3803 == nil { ifn_3804 = lang.IFn_Cast(root_3802) } else { ifn_3804 = nil }; var arg_3805 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names1__10)).Ref(); var arg_3806 any; var root_3807 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3809 lang.IFn; if linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any = rt_order__13; if linked_3808 == nil { arg_3806 = ifn_3809.Invoke_O__O(arg_3810) } else { arg_3806 = linked_3808.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3807, arg_3810) }; if linked_3803 == nil { tmp77 = ifn_3804.Invoke_O_O__O(arg_3805, arg_3806) } else { if jrt.Long_InstanceOf(arg_3805) { tmp77 = linked_3803.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_3802, jrt.NN(jrt.Long_Cast(arg_3805)).LongValue__J(), arg_3805, arg_3806) } else { tmp77 = linked_3803.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_3802, arg_3805, arg_3806) } }; arg_3794 = tmp76.Invoke_O_O_O_O__O(names1__10, names2__23, tmp77, late__32); if linked_3792 == nil { arg_3790 = ifn_3793.Invoke_O__O(arg_3794) } else { arg_3790 = linked_3792.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3791, arg_3794) }; if linked_3787 == nil { ifn_3788.Invoke_O_O__O(arg_3789, arg_3790) } else { linked_3787.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_3786, arg_3789, arg_3790) }
//line :311:1
	var temp__1927000414__auto____31 any; var root_3811 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, A_arbace_j2g_world_id_space_A_fn_class); var ifn_3813 lang.IFn





















































































































































































	if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; if linked_3812 == nil { temp__1927000414__auto____31 = ifn_3813.Invoke__O() } else { temp__1927000414__auto____31 = linked_3812.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_3811) }; if jrt.J2g_Truth(temp__1927000414__auto____31) { var space__32_2 any = temp__1927000414__auto____31; jrt.ThreadLocal_Cast(space__32_2).Remove__V() }
	lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_j2g_world_A_const_226)
	var tmp78 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_212.GetRawRoot__O()); var tmp79 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil); var tmp80 any; var root_3605 any = A_arbace_j2g_world_A_const_213.GetRawRoot__O(); var linked_3606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3605, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3607 lang.IFn; if linked_3606 == nil { ifn_3607 = lang.IFn_Cast(root_3605) } else { ifn_3607 = nil }; var arg_3608 any = Lit_66; var arg_3609 any; var iter__1927001039__auto____33 any; var tmp81 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_New(); var tmp82 *jrt.Class; var fncls__3676 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_fn_class; if fncls__3676 == nil { var fncls__3676d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_fn_class = fncls__3676d; tmp82 = fncls__3676d } else { tmp82 = fncls__3676 }; iter__1927001039__auto____33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp81, tmp82, nil); var tmp83 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____33); var tmp84 any; var root_3677 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3677, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3679 lang.IFn; if linked_3678 == nil { ifn_3679 = lang.IFn_Cast(root_3677) } else { ifn_3679 = nil }; var arg_3680 any = laps__4; if linked_3678 == nil { tmp84 = ifn_3679.Invoke_O__O(arg_3680) } else { tmp84 = linked_3678.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3677, arg_3680) }; arg_3609 = tmp83.Invoke_O__O(tmp84); if linked_3606 == nil { tmp80 = ifn_3607.Invoke_O_O__O(arg_3608, arg_3609) } else { tmp80 = linked_3606.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3605, arg_3608, arg_3609) }; tmp1 = tmp78.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp79, jrt.RefArrayOf(jrt.Object_class, nil, tmp80)).Ref()) }; return nil }(); var root_3681 any = /*line :311:1*/A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_3682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3681, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3683 lang.IFn; if linked_3682 == nil { ifn_3683 = lang.IFn_Cast(root_3681) } else { ifn_3683 = nil }; if linked_3682 == nil { ifn_3683.Invoke__O() } else { linked_3682.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3681) }; if tmp85 != nil { panic(tmp85) }; return tmp1 }










func A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A{}; t.Ctor_O_O(p0, p1); return t }
//line :322:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A) Ctor_O_O(c__t, c__laps any) { t.F_t = c__t; t.F_laps = c__laps }
//line :322:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var root_2456 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2456, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2458 lang.IFn; if linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any = t.F_laps; var arg_2460 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2461 any; var tmp1 jrt.Number_I; var na_2462 int64 = x__2; var na_2463 any; var root_2464 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_2465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2464, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2466 lang.IFn; if linked_2465 == nil { ifn_2466 = lang.IFn_Cast(root_2464) } else { ifn_2466 = nil }; var arg_2467 any = t.F_t; if linked_2465 == nil { na_2463 = ifn_2466.Invoke_O__O(arg_2467) } else { na_2463 = linked_2465.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2464, arg_2467) }; if jrt.Long_InstanceOf(na_2463) { var n0_2468 int64 = na_2462; var n1_2469 int64 = jrt.NN(jrt.Long_Cast(na_2463)).LongValue__J(); var nr_2470 int64 = n0_2468 - n1_2469; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_2469 == -9223372036854775808); if tmp3 { tmp3 = (n0_2468^n1_2469)&(n0_2468^nr_2470) >= 0 }; tmp2 = tmp3; if tmp2 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2470)) } else { tmp1 = lang.Numbers_Minus_J_O__Number_NoInit(na_2462, na_2463) } } else { tmp1 = lang.Numbers_Minus_J_O__Number_NoInit(na_2462, na_2463) }; arg_2461 = lang.Tuple_Create_O_O__IPersistentVector(k__1, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D_NoInit(tmp1, 1.0e7)), 100.0)).Ref()); if linked_2457 == nil { ifn_2458.Invoke_O_O_O__O(arg_2459, arg_2460, arg_2461) } else { linked_2457.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2456, arg_2459, arg_2460, arg_2461) }; var root_2451 any = A_arbace_j2g_world_A_const_181.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = t.F_t; var arg_2455 any = jrt.Long_ValueOf_J__Long_NoInit(x__2).Ref(); if linked_2452 == nil { return ifn_2453.Invoke_O_O__O(arg_2454, arg_2455) } else { return linked_2452.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_2451, arg_2454, arg_2455) } }





func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :328:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A) Ctor_O_O_O(c__variants, c__failed, c__applied any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_applied = c__applied }
//line :328:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A) Invoke_O_O__O(self, ps__1 any) any { { var units__2 any; var root_2472 any = A_arbace_j2g_world_A_const_121.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2474 lang.IFn
														if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any; var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_New(); var tmp2 *jrt.Class; var fncls__2658 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_fn_class; if fncls__2658 == nil { var fncls__2658d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_fn_class = fncls__2658d; tmp2 = fncls__2658d } else { tmp2 = fncls__2658 }; arg_2475 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2476 any = lang.PersistentVector_EMPTY.Ref(); var arg_2477 any = ps__1; if linked_2473 == nil { units__2 = ifn_2474.Invoke_O_O_O__O(arg_2475, arg_2476, arg_2477) } else { units__2 = linked_2473.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2472, arg_2475, arg_2476, arg_2477) }
//line :328:1
	var parsed__3 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_160.GetRawRoot__O()); var tmp4 any; var root_2665 any = A_arbace_j2g_world_A_const_161.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2667 lang.IFn










	if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; if linked_2666 == nil { tmp4 = ifn_2667.Invoke__O() } else { tmp4 = linked_2666.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2665) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_New_O_O(t.F_variants, t.F_applied); var tmp7 *jrt.Class; var fncls__2711 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_fn_class
	if fncls__2711 == nil { var fncls__2711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_fn_class = fncls__2711d; tmp7 = fncls__2711d } else { tmp7 = fncls__2711 }
//line :339:1
	parsed__3 = tmp3.Invoke_O_O_O__O(tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), units__2)
//line :328:1
	var seq_78000281__4 any; var root_2712 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2712, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2714 lang.IFn























	if linked_2713 == nil { ifn_2714 = lang.IFn_Cast(root_2712) } else { ifn_2714 = nil }; var arg_2715 any; var root_2716 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2718 lang.IFn; if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var arg_2720 any = units__2; var arg_2721 any = parsed__3; if linked_2717 == nil { arg_2715 = ifn_2718.Invoke_O_O_O__O(arg_2719, arg_2720, arg_2721) } else { arg_2715 = linked_2717.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_2716, arg_2719, arg_2720, arg_2721) }; if linked_2713 == nil { seq_78000281__4 = ifn_2714.Invoke_O__O(arg_2715) } else { seq_78000281__4 = linked_2713.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2712, arg_2715) }
//line :328:1
	var chunk_78000282__5 any; var count_78000283__6 int64 = 0; var i_78000284__7 int64 = 0; L1: for {























		if lang.Numbers_Lt_J_J__Z_NoInit(i_78000284__7, count_78000283__6) { var vec__78000285__8 any = lang.Indexed_Cast(chunk_78000282__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000284__7)); var vec__78000288__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000285__8, lang.RT_IntCast_J__I_NoInit(0), nil); var file__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000288__9, lang.RT_IntCast_J__I_NoInit(0), nil); var map__78000291__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000285__8, lang.RT_IntCast_J__I_NoInit(1), nil); var map__78000291__12 any; if lang.ISeq_InstanceOf(map__78000291__11) { var tmp8 any; var root_2722 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2722, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2724 lang.IFn; if linked_2723 == nil { ifn_2724 = lang.IFn_Cast(root_2722) } else { ifn_2724 = nil }; var arg_2725 any = map__78000291__11; if linked_2723 == nil { tmp8 = ifn_2724.Invoke_O__O(arg_2725) } else { tmp8 = linked_2723.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2722, arg_2725) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_2726 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2726, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2728 lang.IFn; if linked_2727 == nil { ifn_2728 = lang.IFn_Cast(root_2726) } else { ifn_2728 = nil }; var arg_2729 any = map__78000291__11; if linked_2727 == nil { tmp9 = ifn_2728.Invoke_O__O(arg_2729) } else { tmp9 = linked_2727.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2726, arg_2729) }; map__78000291__12 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp9)).Ref() } else { var tmp10 any; var root_2730 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2732 lang.IFn; if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = map__78000291__11; if linked_2731 == nil { tmp10 = ifn_2732.Invoke_O__O(arg_2733) } else { tmp10 = linked_2731.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2730, arg_2733) }; if jrt.J2g_Truth(tmp10) { var root_2734 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2734, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2736 lang.IFn; if linked_2735 == nil { ifn_2736 = lang.IFn_Cast(root_2734) } else { ifn_2736 = nil }; var arg_2737 any = map__78000291__11; if linked_2735 == nil { map__78000291__12 = ifn_2736.Invoke_O__O(arg_2737) } else { map__78000291__12 = linked_2735.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2734, arg_2737) } } else { map__78000291__12 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000291__12 = map__78000291__11 }; var pc__13 any = lang.RT_Get_O_O__O_NoInit(map__78000291__12, A_arbace_j2g_world_A_const_187); var nsobj__14 any = lang.RT_Get_O_O__O_NoInit(map__78000291__12, A_arbace_j2g_world_A_const_188); var members__15 any = lang.RT_Get_O_O__O_NoInit(map__78000291__12, A_arbace_j2g_world_A_const_149); var error__16 any = lang.RT_Get_O_O__O_NoInit(map__78000291__12, A_arbace_j2g_world_A_const_189)
			if jrt.J2g_Truth(error__16) {
				var root_2770 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2772 lang.IFn; if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = t.F_failed; var arg_2774 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2775 any = error__16; if linked_2771 == nil { ifn_2772.Invoke_O_O_O__O(arg_2773, arg_2774, arg_2775) } else { linked_2771.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2770, arg_2773, arg_2774, arg_2775) } } else {
					var tmp11 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_New_O_O_O_O_O(nsobj__14, pc__13, t.F_failed, members__15, file__10); var tmp12 *jrt.Class; var fncls__2800 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_fn_class; if fncls__2800 == nil { var fncls__2800d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_fn_class = fncls__2800d; tmp12 = fncls__2800d } else { tmp12 = fncls__2800 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O() }
//line :352:1
			seq_78000281__4, chunk_78000282__5, count_78000283__6, i_78000284__7 = seq_78000281__4, chunk_78000282__5, count_78000283__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000284__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_2738 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2740 lang.IFn; if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var arg_2741 any = seq_78000281__4; if linked_2739 == nil { temp__1927000414__auto____8 = ifn_2740.Invoke_O__O(arg_2741) } else { temp__1927000414__auto____8 = linked_2739.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2738, arg_2741) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_78000281__9 any = temp__1927000414__auto____8; var tmp13 any; var root_2742 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any = seq_78000281__9; if linked_2743 == nil { tmp13 = ifn_2744.Invoke_O__O(arg_2745) } else { tmp13 = linked_2743.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2742, arg_2745) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____10 any; var root_2746 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2746, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2748 lang.IFn; if linked_2747 == nil { ifn_2748 = lang.IFn_Cast(root_2746) } else { ifn_2748 = nil }; var arg_2749 any = seq_78000281__9; if linked_2747 == nil { c__1927000678__auto____10 = ifn_2748.Invoke_O__O(arg_2749) } else { c__1927000678__auto____10 = linked_2747.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2746, arg_2749) }; var tmp14 any; var root_2801 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2801, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2803 lang.IFn; if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any = seq_78000281__9; if linked_2802 == nil { tmp14 = ifn_2803.Invoke_O__O(arg_2804) } else { tmp14 = linked_2802.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2801, arg_2804) }; seq_78000281__4, chunk_78000282__5, count_78000283__6, i_78000284__7 = tmp14, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__78000295__10 any; var root_2750 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2750, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2752 lang.IFn; if linked_2751 == nil { ifn_2752 = lang.IFn_Cast(root_2750) } else { ifn_2752 = nil }; var arg_2753 any = seq_78000281__9; if linked_2751 == nil { vec__78000295__10 = ifn_2752.Invoke_O__O(arg_2753) } else { vec__78000295__10 = linked_2751.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2750, arg_2753) }; var vec__78000298__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000295__10, lang.RT_IntCast_J__I_NoInit(0), nil); var file__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000298__11, lang.RT_IntCast_J__I_NoInit(0), nil); var map__78000301__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000295__10, lang.RT_IntCast_J__I_NoInit(1), nil); var map__78000301__14 any; if lang.ISeq_InstanceOf(map__78000301__13) { var tmp15 any; var root_2754 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2754, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2756 lang.IFn; if linked_2755 == nil { ifn_2756 = lang.IFn_Cast(root_2754) } else { ifn_2756 = nil }; var arg_2757 any = map__78000301__13; if linked_2755 == nil { tmp15 = ifn_2756.Invoke_O__O(arg_2757) } else { tmp15 = linked_2755.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2754, arg_2757) }; if jrt.J2g_Truth(tmp15) { var tmp16 any; var root_2758 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2758, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2760 lang.IFn; if linked_2759 == nil { ifn_2760 = lang.IFn_Cast(root_2758) } else { ifn_2760 = nil }; var arg_2761 any = map__78000301__13; if linked_2759 == nil { tmp16 = ifn_2760.Invoke_O__O(arg_2761) } else { tmp16 = linked_2759.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2758, arg_2761) }; map__78000301__14 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp16)).Ref() } else { var tmp17 any; var root_2762 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = map__78000301__13; if linked_2763 == nil { tmp17 = ifn_2764.Invoke_O__O(arg_2765) } else { tmp17 = linked_2763.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2762, arg_2765) }; if jrt.J2g_Truth(tmp17) { var root_2766 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2768 lang.IFn; if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any = map__78000301__13; if linked_2767 == nil { map__78000301__14 = ifn_2768.Invoke_O__O(arg_2769) } else { map__78000301__14 = linked_2767.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2766, arg_2769) } } else { map__78000301__14 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000301__14 = map__78000301__13 }; var pc__15 any = lang.RT_Get_O_O__O_NoInit(map__78000301__14, A_arbace_j2g_world_A_const_187); var nsobj__16 any = lang.RT_Get_O_O__O_NoInit(map__78000301__14, A_arbace_j2g_world_A_const_188); var members__17 any = lang.RT_Get_O_O__O_NoInit(map__78000301__14, A_arbace_j2g_world_A_const_149); var error__18 any = lang.RT_Get_O_O__O_NoInit(map__78000301__14, A_arbace_j2g_world_A_const_189)
				if jrt.J2g_Truth(error__18) {
					var root_2805 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2807 lang.IFn; if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any = t.F_failed; var arg_2809 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2810 any = error__18; if linked_2806 == nil { ifn_2807.Invoke_O_O_O__O(arg_2808, arg_2809, arg_2810) } else { linked_2806.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2805, arg_2808, arg_2809, arg_2810) } } else {
						var tmp18 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_New_O_O_O_O_O(nsobj__16, pc__15, members__17, t.F_failed, file__12); var tmp19 *jrt.Class; var fncls__2835 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_fn_class; if fncls__2835 == nil { var fncls__2835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_fn_class = fncls__2835d; tmp19 = fncls__2835d } else { tmp19 = fncls__2835 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O() }
//line :352:1
				var tmp20 any; var root_2836 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2836, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2838 lang.IFn; if linked_2837 == nil { ifn_2838 = lang.IFn_Cast(root_2836) } else { ifn_2838 = nil }; var arg_2839 any = seq_78000281__9; if linked_2837 == nil { tmp20 = ifn_2838.Invoke_O__O(arg_2839) } else { tmp20 = linked_2837.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2836, arg_2839) }; seq_78000281__4, chunk_78000282__5, count_78000283__6, i_78000284__7 = tmp20, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :328:1*/panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_New() *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A) Ctor() {}
//line :329:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A) Invoke_O_O_O__O(self, acc__1, p__78000249__2 any) any { var map__78000251__3 any = p__78000249__2; var map__78000251__4 any; if lang.ISeq_InstanceOf(map__78000251__3) { var tmp1 any; var root_2478 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2478, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2480 lang.IFn; if linked_2479 == nil { ifn_2480 = lang.IFn_Cast(root_2478) } else { ifn_2480 = nil }; var arg_2481 any = map__78000251__3; if linked_2479 == nil { tmp1 = ifn_2480.Invoke_O__O(arg_2481) } else { tmp1 = linked_2479.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2478, arg_2481) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2482 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2482, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2484 lang.IFn; if linked_2483 == nil { ifn_2484 = lang.IFn_Cast(root_2482) } else { ifn_2484 = nil }; var arg_2485 any = map__78000251__3; if linked_2483 == nil { tmp2 = ifn_2484.Invoke_O__O(arg_2485) } else { tmp2 = linked_2483.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2482, arg_2485) }; map__78000251__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2486 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2486, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2488 lang.IFn; if linked_2487 == nil { ifn_2488 = lang.IFn_Cast(root_2486) } else { ifn_2488 = nil }; var arg_2489 any = map__78000251__3; if linked_2487 == nil { tmp3 = ifn_2488.Invoke_O__O(arg_2489) } else { tmp3 = linked_2487.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2486, arg_2489) }; if jrt.J2g_Truth(tmp3) { var root_2490 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any = map__78000251__3; if linked_2491 == nil { map__78000251__4 = ifn_2492.Invoke_O__O(arg_2493) } else { map__78000251__4 = linked_2491.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2490, arg_2493) } } else { map__78000251__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000251__4 = map__78000251__3 }; var file__5 any = lang.RT_Get_O_O__O_NoInit(map__78000251__4, A_arbace_j2g_world_A_const_168); var forms__6 any = lang.RT_Get_O_O__O_NoInit(map__78000251__4, A_arbace_j2g_world_A_const_50); var ns__7 any = lang.RT_Get_O_O__O_NoInit(map__78000251__4, A_arbace_j2g_world_A_const_143); var tmp4 any; var root_2494 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2496 lang.IFn; if
																		linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = ns__7; if linked_2495 == nil { tmp4 = ifn_2496.Invoke_O__O(arg_2497) } else { tmp4 = linked_2495.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2494, arg_2497) }; if jrt.J2g_Truth(tmp4) { return acc__1 } else {

		var root_2569 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2569, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2571 lang.IFn; if linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_world_A_const_182; var arg_2572 any = tmp5.Invoke_O_O__O(tmp6, A_arbace_j2g_world_A_const_182.Get__O()); if linked_2570 == nil { ifn_2571.Invoke_O__O(arg_2572) } else { linked_2570.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2569, arg_2572) }
//line :330:1
		var tmp7 any; tmp22 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_78000253__10 any; var root_2578 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2578, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2580 lang.IFn


			if linked_2579 == nil { ifn_2580 = lang.IFn_Cast(root_2578) } else { ifn_2580 = nil }; var arg_2581 any = forms__6; if linked_2579 == nil { seq_78000253__10 = ifn_2580.Invoke_O__O(arg_2581) } else { seq_78000253__10 = linked_2579.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2578, arg_2581) }
//line :330:1
			var chunk_78000254__11 any; var count_78000255__12 int64 = 0; var i_78000256__13 int64 = 0; L1: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i_78000256__13, count_78000255__12) { var fm__14 any = lang.Indexed_Cast(chunk_78000254__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000256__13)); var tmp8 any; var and__1927000168__auto____15 any; var root_2582 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_2583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2582, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_2584 lang.IFn
					if linked_2583 == nil { ifn_2584 = lang.IFn_Cast(root_2582) } else { ifn_2584 = nil }; var arg_2585 any = fm__14; if linked_2583 == nil { and__1927000168__auto____15 = ifn_2584.Invoke_O__O(arg_2585) } else { and__1927000168__auto____15 = linked_2583.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_2582, arg_2585) }; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_2586 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_2588 lang.IFn; if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any; var root_2590 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2592 lang.IFn; if linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any = fm__14; if linked_2591 == nil { arg_2589 = ifn_2592.Invoke_O__O(arg_2593) } else { arg_2589 = linked_2591.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2590, arg_2593) }; if linked_2587 == nil { and__1927000168__auto____16 = ifn_2588.Invoke_O__O(arg_2589) } else { and__1927000168__auto____16 = linked_2587.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_2586, arg_2589) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_183); var tmp10 any; var root_2622 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any; var root_2626 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2626, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2628 lang.IFn; if linked_2627 == nil { ifn_2628 = lang.IFn_Cast(root_2626) } else { ifn_2628 = nil }; var arg_2629 any = fm__14; if linked_2627 == nil { arg_2625 = ifn_2628.Invoke_O__O(arg_2629) } else { arg_2625 = linked_2627.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2626, arg_2629) }; if linked_2623 == nil { tmp10 = ifn_2624.Invoke_O__O(arg_2625) } else { tmp10 = linked_2623.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2622, arg_2625) }; tmp8 = tmp9.Invoke_O__O(tmp10) } else { tmp8 = and__1927000168__auto____16 } } else { tmp8 = and__1927000168__auto____15 }
//line :333:1
					if jrt.J2g_Truth(tmp8) {

						var root_2630 any = A_arbace_j2g_world_A_const_185.GetRawRoot__O(); var linked_2631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2630, aot_arbace_classes_analyze.A_arbace_classes_analyze_eval_ns_form_BANG__A_fn_class); var ifn_2632 lang.IFn; if linked_2631 == nil { ifn_2632 = lang.IFn_Cast(root_2630) } else { ifn_2632 = nil }; var arg_2633 any = fm__14; if linked_2631 == nil { ifn_2632.Invoke_O__O(arg_2633) } else { linked_2631.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_eval_ns_form_BANG__A).Invoke_O_O__O(root_2630, arg_2633) }
//line :333:1
						seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = seq_78000253__10, chunk_78000254__11, count_78000255__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000256__13); continue L1 } else { seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = seq_78000253__10, chunk_78000254__11, count_78000255__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000256__13); continue L1 } } else { var temp__1927000414__auto____14 any; var root_2594 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2596 lang.IFn; if linked_2595 == nil { ifn_2596 = lang.IFn_Cast(root_2594) } else { ifn_2596 = nil }; var arg_2597 any = seq_78000253__10; if linked_2595 == nil { temp__1927000414__auto____14 = ifn_2596.Invoke_O__O(arg_2597) } else { temp__1927000414__auto____14 = linked_2595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2594, arg_2597) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_78000253__15 any = temp__1927000414__auto____14; var tmp11 any; var root_2598 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2598, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2600 lang.IFn; if linked_2599 == nil { ifn_2600 = lang.IFn_Cast(root_2598) } else { ifn_2600 = nil }; var arg_2601 any = seq_78000253__15; if linked_2599 == nil { tmp11 = ifn_2600.Invoke_O__O(arg_2601) } else { tmp11 = linked_2599.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2598, arg_2601) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____16 any; var root_2602 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2602, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2604 lang.IFn; if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any = seq_78000253__15; if linked_2603 == nil { c__1927000678__auto____16 = ifn_2604.Invoke_O__O(arg_2605) } else { c__1927000678__auto____16 = linked_2603.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2602, arg_2605) }; var tmp12 any; var root_2634 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2634, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2636 lang.IFn; if linked_2635 == nil { ifn_2636 = lang.IFn_Cast(root_2634) } else { ifn_2636 = nil }; var arg_2637 any = seq_78000253__15; if linked_2635 == nil { tmp12 = ifn_2636.Invoke_O__O(arg_2637) } else { tmp12 = linked_2635.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2634, arg_2637) }; seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = tmp12, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fm__16 any; var root_2606 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2608 lang.IFn; if linked_2607 == nil { ifn_2608 = lang.IFn_Cast(root_2606) } else { ifn_2608 = nil }; var arg_2609 any = seq_78000253__15; if linked_2607 == nil { fm__16 = ifn_2608.Invoke_O__O(arg_2609) } else { fm__16 = linked_2607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2606, arg_2609) }; var tmp13 any; var and__1927000168__auto____17 any; var root_2610 any = A_arbace_j2g_world_A_const_29.GetRawRoot__O(); var linked_2611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2610, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_2612 lang.IFn
							if linked_2611 == nil { ifn_2612 = lang.IFn_Cast(root_2610) } else { ifn_2612 = nil }; var arg_2613 any = fm__16; if linked_2611 == nil { and__1927000168__auto____17 = ifn_2612.Invoke_O__O(arg_2613) } else { and__1927000168__auto____17 = linked_2611.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_2610, arg_2613) }; if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18 any; var root_2614 any = A_arbace_j2g_world_A_const_30.GetRawRoot__O(); var linked_2615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2614, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_2616 lang.IFn; if linked_2615 == nil { ifn_2616 = lang.IFn_Cast(root_2614) } else { ifn_2616 = nil }; var arg_2617 any; var root_2618 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2618, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2620 lang.IFn; if linked_2619 == nil { ifn_2620 = lang.IFn_Cast(root_2618) } else { ifn_2620 = nil }; var arg_2621 any = fm__16; if linked_2619 == nil { arg_2617 = ifn_2620.Invoke_O__O(arg_2621) } else { arg_2617 = linked_2619.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2618, arg_2621) }; if linked_2615 == nil { and__1927000168__auto____18 = ifn_2616.Invoke_O__O(arg_2617) } else { and__1927000168__auto____18 = linked_2615.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_2614, arg_2617) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_184); var tmp15 any; var root_2638 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_2639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2638, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2640 lang.IFn; if linked_2639 == nil { ifn_2640 = lang.IFn_Cast(root_2638) } else { ifn_2640 = nil }; var arg_2641 any; var root_2642 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2644 lang.IFn; if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any = fm__16; if linked_2643 == nil { arg_2641 = ifn_2644.Invoke_O__O(arg_2645) } else { arg_2641 = linked_2643.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2642, arg_2645) }; if linked_2639 == nil { tmp15 = ifn_2640.Invoke_O__O(arg_2641) } else { tmp15 = linked_2639.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2638, arg_2641) }; tmp13 = tmp14.Invoke_O__O(tmp15) } else { tmp13 = and__1927000168__auto____18 } } else { tmp13 = and__1927000168__auto____17 }
//line :333:1
							if jrt.J2g_Truth(tmp13) {

								var root_2646 any = A_arbace_j2g_world_A_const_185.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_classes_analyze.A_arbace_classes_analyze_eval_ns_form_BANG__A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = fm__16; if linked_2647 == nil { ifn_2648.Invoke_O__O(arg_2649) } else { linked_2647.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_eval_ns_form_BANG__A).Invoke_O_O__O(root_2646, arg_2649) }
//line :333:1
								var tmp16 any; var root_2650 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2650, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2652 lang.IFn; if linked_2651 == nil { ifn_2652 = lang.IFn_Cast(root_2650) } else { ifn_2652 = nil }; var arg_2653 any = seq_78000253__15; if linked_2651 == nil { tmp16 = ifn_2652.Invoke_O__O(arg_2653) } else { tmp16 = linked_2651.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2650, arg_2653) }; seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = tmp16, nil, 0, 0; continue L1 } else { var tmp17 any; var root_2654 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2654, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2656 lang.IFn; if linked_2655 == nil { ifn_2656 = lang.IFn_Cast(root_2654) } else { ifn_2656 = nil }; var arg_2657 any = seq_78000253__15; if linked_2655 == nil { tmp17 = ifn_2656.Invoke_O__O(arg_2657) } else { tmp17 = linked_2655.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2654, arg_2657) }; seq_78000253__10, chunk_78000254__11, count_78000255__12, i_78000256__13 = tmp17, nil, 0, 0; continue L1 } } } }
//line :330:1
				break L1 }; var nsobj__10 any = A_arbace_j2g_world_A_const_182.Get__O(); var root_2498 any = A_arbace_j2g_world_A_const_47.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2500 lang.IFn






			if linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any = acc__1; var arg_2502 any; var iter__1927001039__auto____11 any; var tmp18 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_New_O_O_O(nsobj__10, file__5, ns__7); var tmp19 *jrt.Class; var fncls__2561 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_fn_class; if fncls__2561 == nil { var fncls__2561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_fn_class = fncls__2561d; tmp19 = fncls__2561d } else { tmp19 = fncls__2561 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp20 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11); var tmp21 any; var root_2562 any = A_arbace_j2g_world_A_const_90.GetRawRoot__O(); var linked_2563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2562, A_arbace_j2g_world_class_forms_A_fn_class); var ifn_2564 lang.IFn; if linked_2563 == nil { ifn_2564 = lang.IFn_Cast(root_2562) } else { ifn_2564 = nil }; var arg_2565 any = forms__6; if linked_2563 == nil { tmp21 = ifn_2564.Invoke_O__O(arg_2565) } else { tmp21 = linked_2563.(*A_arbace_j2g_world_class_forms_A).Invoke_O_O__O(root_2562, arg_2565) }; arg_2502 = tmp20.Invoke_O__O(tmp21); if linked_2499 == nil { tmp7 = ifn_2500.Invoke_O_O__O(arg_2501, arg_2502) } else { tmp7 = linked_2499.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2498, arg_2501, arg_2502) } }; return nil }()
//line :330:1
		var root_2566 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_2567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2566, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2568 lang.IFn

		if linked_2567 == nil { ifn_2568 = lang.IFn_Cast(root_2566) } else { ifn_2568 = nil }; if linked_2567 == nil { ifn_2568.Invoke__O() } else { linked_2567.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2566) }
//line :330:1
		if tmp22 != nil { panic(tmp22) }; return tmp7 } }






func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A) Ctor_O_O_O(c__nsobj, c__file, c__ns any) { t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A) Invoke_O_O__O(self, s__78000258__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_New_O_O_O_O_O(t.F_nsobj, t.F_file, s__78000258__1, self, t.F_ns); var tmp2 *jrt.Class; var fncls__2560 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_fn_class; if fncls__2560 == nil { var fncls__2560d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_fn_class = fncls__2560d; tmp2 = fncls__2560d } else { tmp2 = fncls__2560 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A) Ctor_O_O_O_O_O(c__nsobj, c__file, c__s__78000258, c__iter__78000257, c__ns any) { t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_s__78000258 = c__s__78000258; t.F_iter__78000257 = c__iter__78000257; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A) Invoke_O__O(self any) any { { var s__78000258__1 any; var t_ any = t.F_s__78000258; t.F_s__78000258 = nil; s__78000258__1 = t_; for { var temp__1927000414__auto____2 any; var root_2503 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2505 lang.IFn; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any = s__78000258__1; if linked_2504 == nil { temp__1927000414__auto____2 = ifn_2505.Invoke_O__O(arg_2506) } else { temp__1927000414__auto____2 = linked_2504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2503, arg_2506) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000258__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2507 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2509 lang.IFn; if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any = s__78000258__3; if linked_2508 == nil { tmp1 = ifn_2509.Invoke_O__O(arg_2510) } else { tmp1 = linked_2508.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2507, arg_2510) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2511 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2511, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2513 lang.IFn; if linked_2512 == nil { ifn_2513 = lang.IFn_Cast(root_2511) } else { ifn_2513 = nil }; var arg_2514 any = s__78000258__3; if linked_2512 == nil { c__1927001037__auto____4 = ifn_2513.Invoke_O__O(arg_2514) } else { c__1927001037__auto____4 = linked_2512.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2511, arg_2514) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000260__6 any; var root_2515 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_2516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2515, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2517 lang.IFn; if linked_2516 == nil { ifn_2517 = lang.IFn_Cast(root_2515) } else { ifn_2517 = nil }; var arg_2518 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2516 == nil { b__78000260__6 = ifn_2517.Invoke_O__O(arg_2518) } else { b__78000260__6 = linked_2516.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2515, arg_2518) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_New_O_O_O_I_O_O(t.F_nsobj, t.F_file, b__78000260__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_ns); var tmp3 *jrt.Class; var fncls__2524 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_fn_class; if fncls__2524 == nil { var fncls__2524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_fn_class = fncls__2524d; tmp3 = fncls__2524d } else { tmp3 = fncls__2524 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2525 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2527 lang.IFn; if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any; var root_2530 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2532 lang.IFn; if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any = b__78000260__6; if linked_2531 == nil { arg_2528 = ifn_2532.Invoke_O__O(arg_2533) } else { arg_2528 = linked_2531.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2530, arg_2533) }; var arg_2529 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000257); var tmp5 any; var root_2534 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any = s__78000258__3; if linked_2535 == nil { tmp5 = ifn_2536.Invoke_O__O(arg_2537) } else { tmp5 = linked_2535.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2534, arg_2537) }; arg_2529 = tmp4.Invoke_O__O(tmp5); if linked_2526 == nil { return ifn_2527.Invoke_O_O__O(arg_2528, arg_2529) } else { return linked_2526.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2525, arg_2528, arg_2529) } } else { var root_2538 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_2539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2538, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2540 lang.IFn; if linked_2539 == nil { ifn_2540 = lang.IFn_Cast(root_2538) } else { ifn_2540 = nil }; var arg_2541 any; var root_2543 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_2544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2543, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2545 lang.IFn; if linked_2544 == nil { ifn_2545 = lang.IFn_Cast(root_2543) } else { ifn_2545 = nil }; var arg_2546 any = b__78000260__6; if linked_2544 == nil { arg_2541 = ifn_2545.Invoke_O__O(arg_2546) } else { arg_2541 = linked_2544.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2543, arg_2546) }; var arg_2542 any; if linked_2539 == nil { return ifn_2540.Invoke_O_O__O(arg_2541, arg_2542) } else { return linked_2539.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2538, arg_2541, arg_2542) } } } else { var cf__4 any; var root_2547 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2547, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2549 lang.IFn; if linked_2548 == nil { ifn_2549 = lang.IFn_Cast(root_2547) } else { ifn_2549 = nil }; var arg_2550 any = s__78000258__3; if linked_2548 == nil { cf__4 = ifn_2549.Invoke_O__O(arg_2550) } else { cf__4 = linked_2548.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2547, arg_2550) }; var root_2551 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(t.F_file, t.F_ns, t.F_nsobj, cf__4); var arg_2555 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__78000257); var tmp7 any; var root_2556 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = s__78000258__3; if linked_2557 == nil { tmp7 = ifn_2558.Invoke_O__O(arg_2559) } else { tmp7 = linked_2557.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2556, arg_2559) }; arg_2555 = tmp6.Invoke_O__O(tmp7); if linked_2552 == nil { return ifn_2553.Invoke_O_O__O(arg_2554, arg_2555) } else { return linked_2552.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2551, arg_2554, arg_2555) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :337:1
func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A) Ctor_O_O_O_I_O_O(c__nsobj, c__file, c__b__78000260 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__ns any) { t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_b__78000260 = c__b__78000260; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A) Invoke_O__O(self any) any { { var i__78000259__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000259__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000259__1)); var root_2519 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2521 lang.IFn; if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any = t.F_b__78000260; var arg_2523 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(t.F_file, t.F_ns, t.F_nsobj, cf__2); if linked_2520 == nil { ifn_2521.Invoke_O_O__O(arg_2522, arg_2523) } else { linked_2520.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2519, arg_2522, arg_2523) }; i__78000259__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000259__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A{}; t.Ctor_O_O(p0, p1); return t }
//line :340:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A) Ctor_O_O(c__variants, c__applied any) { t.F_variants = c__variants; t.F_applied = c__applied }
//line :340:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A) Invoke_O_O__O(self, p__78000268__1 any) any { var vec__78000270__2 any = p__78000268__1; var file__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000270__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ns__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000270__2, lang.RT_IntCast_J__I_NoInit(1), nil); var nsobj__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000270__2, lang.RT_IntCast_J__I_NoInit(2), nil); var cf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000270__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__9 any; var root_2668 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2670 lang.IFn

	if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any; var root_2672 any = A_arbace_j2g_world_A_const_169.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2672, A_arbace_j2g_world_top_names_A_fn_class); var ifn_2674 lang.IFn; if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any = ns__4; var arg_2676 any = lang.Tuple_Create_O__IPersistentVector(cf__6); if linked_2673 == nil { arg_2671 = ifn_2674.Invoke_O_O__O(arg_2675, arg_2676) } else { arg_2671 = linked_2673.(*A_arbace_j2g_world_top_names_A).Invoke_O_O_O__O(root_2672, arg_2675, arg_2676) }; if linked_2669 == nil { n__9 = ifn_2670.Invoke_O__O(arg_2671) } else { n__9 = linked_2669.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2668, arg_2671) }
//line :340:1
	var vfs__10 any = lang.RT_Get_O_O__O_NoInit(t.F_variants, n__9); var vec__78000273__11 any; var root_2677 any = A_arbace_j2g_world_A_const_128.GetRawRoot__O(); var linked_2678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2677, A_arbace_j2g_world_apply_variant_A_fn_class); var ifn_2679 lang.IFn



	if linked_2678 == nil { ifn_2679 = lang.IFn_Cast(root_2677) } else { ifn_2679 = nil }; var arg_2680 any = cf__6; var arg_2681 any; var or__1927000174__auto____11 any = vfs__10; if jrt.J2g_Truth(or__1927000174__auto____11) { arg_2681 = or__1927000174__auto____11 } else { arg_2681 = lang.PersistentVector_EMPTY.Ref() }; var arg_2682 any = n__9; var arg_2683 any; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_New_O(t.F_variants); var tmp3 *jrt.Class; var fncls__2685 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_fn_class; if fncls__2685 == nil { var fncls__2685d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_fn_class = fncls__2685d; tmp3 = fncls__2685d } else { tmp3 = fncls__2685 }; arg_2683 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_2684 any = t.F_applied; if linked_2678 == nil { vec__78000273__11 = ifn_2679.Invoke_O_O_O_O_O__O(arg_2680, arg_2681, arg_2682, arg_2683, arg_2684) } else { vec__78000273__11 = linked_2678.(*A_arbace_j2g_world_apply_variant_A).Invoke_O_O_O_O_O_O__O(root_2677, arg_2680, arg_2681, arg_2682, arg_2683, arg_2684) }
//line :340:1
	var cf__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000273__11, lang.RT_IntCast_J__I_NoInit(0), nil); var counts__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000273__11, lang.RT_IntCast_J__I_NoInit(1), nil); var ___14 any; _ = ___14




	if jrt.J2g_Truth(vfs__10) { var root_2686 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2687 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2686, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2688 lang.IFn; if linked_2687 == nil { ifn_2688 = lang.IFn_Cast(root_2686) } else { ifn_2688 = nil }; var arg_2689 any = t.F_applied; var arg_2690 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var arg_2691 any = n__9; var arg_2692 any = counts__13; if linked_2687 == nil { ___14 = ifn_2688.Invoke_O_O_O_O__O(arg_2689, arg_2690, arg_2691, arg_2692) } else { ___14 = linked_2687.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2686, arg_2689, arg_2690, arg_2691, arg_2692) } } else { ___14 = nil }
//line :340:1
	var pc__15 any; var root_2693 any = A_arbace_j2g_world_A_const_142.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2693, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_2695 lang.IFn





	if linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_world_A_const_143, nsobj__5, A_arbace_j2g_world_A_const_144, A_arbace_j2g_world_A_const_186)); var arg_2697 any; var root_2698 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2700 lang.IFn; if linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any = cf__12; if linked_2699 == nil { arg_2697 = ifn_2700.Invoke_O__O(arg_2701) } else { arg_2697 = linked_2699.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2698, arg_2701) }; if linked_2694 == nil { pc__15 = ifn_2695.Invoke_O_O__O(arg_2696, arg_2697) } else { pc__15 = linked_2694.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_2693, arg_2696, arg_2697) }
//line :340:1
	var tmp4 any = A_arbace_j2g_world_A_const_187; var tmp5 any = A_arbace_j2g_world_A_const_188; var tmp6 any = A_arbace_j2g_world_A_const_149; var tmp7 any = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_New_O(pc__15); var tmp8 *jrt.Class
	var fncls__2706 /*line :340:1*/*jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_fn_class







	if fncls__2706 == nil { var fncls__2706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_fn_class = fncls__2706d; tmp8 = fncls__2706d } else { tmp8 = fncls__2706 }
//line :340:1
	tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, pc__15, tmp5, nsobj__5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O())) }; return nil }(); if tmp9 != nil { if true { var e__9 jrt.Throwable_I = tmp9; var tmp10 any = A_arbace_j2g_world_A_const_189; var tmp11 any; var root_2707 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2709 lang.IFn









		if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = file__3; if linked_2708 == nil { tmp11 = ifn_2709.Invoke_O__O(arg_2710) } else { tmp11 = linked_2708.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2707, arg_2710) }
//line :340:1
		tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Tuple_Create_O_O__IPersistentVector(tmp11, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_79, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__9.GetMessage__String().Ref())).Ref()))) } }; return tmp1 }



func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A{}; t.Ctor_O(p0); return t }
//line :344:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :344:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A) Invoke_O_O__O(self, p1__78000221_SHARP___1 any) any { return lang.RT_Get_O_O__O_NoInit(t.F_variants, p1__78000221_SHARP___1) }



func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A{}; t.Ctor_O(p0); return t }
//line :348:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A) Ctor_O(c__pc any) { t.F_pc = c__pc }
//line :348:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2702 any = A_arbace_j2g_world_A_const_150.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, A_arbace_j2g_world_parse_member_classes_A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any; var t_ any = t.F_pc; t.F_pc = nil; arg_2705 = t_; if linked_2703 == nil { tmp1 = ifn_2704.Invoke_O__O(arg_2705) } else { tmp1 = linked_2703.(*A_arbace_j2g_world_parse_member_classes_A).Invoke_O_O__O(root_2702, arg_2705) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }






func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :355:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A) Ctor_O_O_O_O_O(c__nsobj, c__pc, c__failed, c__members, c__file any) { t.F_nsobj = c__nsobj; t.F_pc = c__pc; t.F_failed = c__failed; t.F_members = c__members; t.F_file = c__file }
//line :355:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															{ var tmp2 any; var root_2776 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2778 lang.IFn; if linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any; var root_2780 any = A_arbace_j2g_world_A_const_190.GetRawRoot__O(); var linked_2781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2780, aot_arbace_classes_analyze.A_arbace_classes_analyze_top_name_A_fn_class); var ifn_2782 lang.IFn; if linked_2781 == nil { ifn_2782 = lang.IFn_Cast(root_2780) } else { ifn_2782 = nil }; var arg_2783 any; var t_ any = t.F_nsobj; t.F_nsobj = nil; arg_2783 = t_; var arg_2784 any = t.F_pc; if linked_2781 == nil { arg_2779 = ifn_2782.Invoke_O_O__O(arg_2783, arg_2784) } else { arg_2779 = linked_2781.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_top_name_A).Invoke_O_O_O__O(root_2780, arg_2783, arg_2784) }; if linked_2777 == nil { tmp2 = ifn_2778.Invoke_O__O(arg_2779) } else { tmp2 = linked_2777.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2776, arg_2779) }; if jrt.J2g_Truth(tmp2) { tmp1 = nil } else {
																var root_2785 any = A_arbace_j2g_world_A_const_191.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_2787 lang.IFn; if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any; var tmp3 any = A_arbace_j2g_world_A_const_144; var tmp4 any = A_arbace_j2g_world_A_const_186; var tmp5 any = A_arbace_j2g_world_A_const_192; var tmp6 any; var t__2 any = t.F_members; t.F_members = nil; tmp6 = t__2; arg_2788 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6)); var arg_2789 any; var t__3 any = t.F_pc; t.F_pc = nil; arg_2789 = t__3; if linked_2786 == nil { tmp1 = ifn_2787.Invoke_O_O__O(arg_2788, arg_2789) } else { tmp1 = linked_2786.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_2785, arg_2788, arg_2789) } } }
//line :355:1
	return nil }(); if tmp7 != nil { if true { var e__3 jrt.Throwable_I = tmp7; var root_2790 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2792 lang.IFn



		if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any; var t__4 any = t.F_failed; t.F_failed = nil; arg_2793 = t__4; var arg_2794 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2795 any; var tmp8 any; var root_2796 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2797 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2796, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2798 lang.IFn; if linked_2797 == nil { ifn_2798 = lang.IFn_Cast(root_2796) } else { ifn_2798 = nil }; var arg_2799 any; var t__5 any = t.F_file; t.F_file = nil; arg_2799 = t__5; if linked_2797 == nil { tmp8 = ifn_2798.Invoke_O__O(arg_2799) } else { tmp8 = linked_2797.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2796, arg_2799) }; arg_2795 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_79, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref()); if linked_2791 == nil { tmp1 = ifn_2792.Invoke_O_O_O__O(arg_2793, arg_2794, arg_2795) } else { tmp1 = linked_2791.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2790, arg_2793, arg_2794, arg_2795) } } }; return tmp1 }
//line :355:1
func A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :355:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A) Ctor_O_O_O_O_O(c__nsobj, c__pc, c__members, c__failed, c__file any) { t.F_nsobj = c__nsobj; t.F_pc = c__pc; t.F_members = c__members; t.F_failed = c__failed; t.F_file = c__file }
//line :355:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															{ var tmp2 any; var root_2811 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2811, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2813 lang.IFn; if linked_2812 == nil { ifn_2813 = lang.IFn_Cast(root_2811) } else { ifn_2813 = nil }; var arg_2814 any; var root_2815 any = A_arbace_j2g_world_A_const_190.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, aot_arbace_classes_analyze.A_arbace_classes_analyze_top_name_A_fn_class); var ifn_2817 lang.IFn; if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any; var t_ any = t.F_nsobj; t.F_nsobj = nil; arg_2818 = t_; var arg_2819 any = t.F_pc; if linked_2816 == nil { arg_2814 = ifn_2817.Invoke_O_O__O(arg_2818, arg_2819) } else { arg_2814 = linked_2816.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_top_name_A).Invoke_O_O_O__O(root_2815, arg_2818, arg_2819) }; if linked_2812 == nil { tmp2 = ifn_2813.Invoke_O__O(arg_2814) } else { tmp2 = linked_2812.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2811, arg_2814) }; if jrt.J2g_Truth(tmp2) { tmp1 = nil } else {
																var root_2820 any = A_arbace_j2g_world_A_const_191.GetRawRoot__O(); var linked_2821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2820, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_2822 lang.IFn; if linked_2821 == nil { ifn_2822 = lang.IFn_Cast(root_2820) } else { ifn_2822 = nil }; var arg_2823 any; var tmp3 any = A_arbace_j2g_world_A_const_144; var tmp4 any = A_arbace_j2g_world_A_const_186; var tmp5 any = A_arbace_j2g_world_A_const_192; var tmp6 any; var t__2 any = t.F_members; t.F_members = nil; tmp6 = t__2; arg_2823 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6)); var arg_2824 any; var t__3 any = t.F_pc; t.F_pc = nil; arg_2824 = t__3; if linked_2821 == nil { tmp1 = ifn_2822.Invoke_O_O__O(arg_2823, arg_2824) } else { tmp1 = linked_2821.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_2820, arg_2823, arg_2824) } } }
//line :355:1
	return nil }(); if tmp7 != nil { if true { var e__3 jrt.Throwable_I = tmp7; var root_2825 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2827 lang.IFn



		if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any; var t__4 any = t.F_failed; t.F_failed = nil; arg_2828 = t__4; var arg_2829 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2830 any; var tmp8 any; var root_2831 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2832 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2831, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2833 lang.IFn; if linked_2832 == nil { ifn_2833 = lang.IFn_Cast(root_2831) } else { ifn_2833 = nil }; var arg_2834 any; var t__5 any = t.F_file; t.F_file = nil; arg_2834 = t__5; if linked_2832 == nil { tmp8 = ifn_2833.Invoke_O__O(arg_2834) } else { tmp8 = linked_2832.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2831, arg_2834) }; arg_2830 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_79, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref()); if linked_2826 == nil { tmp1 = ifn_2827.Invoke_O_O_O__O(arg_2828, arg_2829, arg_2830) } else { tmp1 = linked_2826.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2825, arg_2828, arg_2829, arg_2830) } } }; return tmp1 }





func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :365:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A) Ctor_O_O(c__failed, c__lap any) { t.F_failed = c__failed; t.F_lap = c__lap }
//line :365:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A) Invoke_O_O__O(self, names__1 any) any {
	lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_j2g_world_A_const_199)
	{ var root_2861 any = A_arbace_j2g_world_A_const_193.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2861, A_arbace_j2g_world_par_levels_A_fn_class); var ifn_2863 lang.IFn; if linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any = names__1; var arg_2865 any; var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_New(); var tmp2 *jrt.Class; var fncls__2875 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_fn_class; if fncls__2875 == nil { var fncls__2875d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_fn_class = fncls__2875d; tmp2 = fncls__2875d } else { tmp2 = fncls__2875 }; arg_2865 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2866 any; var tmp3 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_New_O(t.F_failed); var tmp4 *jrt.Class; var fncls__2890 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_fn_class
		if fncls__2890 == nil { var fncls__2890d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_fn_class = fncls__2890d; tmp4 = fncls__2890d } else { tmp4 = fncls__2890 }; arg_2866 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :367:1
		if linked_2862 == nil { ifn_2863.Invoke_O_O_O__O(arg_2864, arg_2865, arg_2866) } else { linked_2862.(*A_arbace_j2g_world_par_levels_A).Invoke_O_O_O_O__O(root_2861, arg_2864, arg_2865, arg_2866)
		}


		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_j2g_world_A_const_200)
		var root_2891 any = A_arbace_j2g_world_A_const_193.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2891, A_arbace_j2g_world_par_levels_A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var arg_2894 any = names__1; var arg_2895 any = A_arbace_j2g_world_A_const_196.GetRawRoot__O(); var arg_2896 any; var tmp5 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_New_O(t.F_failed); var tmp6 *jrt.Class; var fncls__2907 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_fn_class
		if fncls__2907 == nil { var fncls__2907d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_fn_class = fncls__2907d; tmp6 = fncls__2907d } else { tmp6 = fncls__2907 }; arg_2896 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
//line :372:1
		if linked_2892 == nil { ifn_2893.Invoke_O_O_O__O(arg_2894, arg_2895, arg_2896) } else { linked_2892.(*A_arbace_j2g_world_par_levels_A).Invoke_O_O_O_O__O(root_2891, arg_2894, arg_2895, arg_2896)
		}

		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_j2g_world_A_const_149)
		var root_2908 any = A_arbace_j2g_world_A_const_193.GetRawRoot__O(); var linked_2909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2908, A_arbace_j2g_world_par_levels_A_fn_class); var ifn_2910 lang.IFn; if linked_2909 == nil { ifn_2910 = lang.IFn_Cast(root_2908) } else { ifn_2910 = nil }; var arg_2911 any = names__1; var arg_2912 any = A_arbace_j2g_world_A_const_196.GetRawRoot__O(); var arg_2913 any; var tmp7 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_New_O(t.F_failed); var tmp8 *jrt.Class; var fncls__2924 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_fn_class
		if fncls__2924 == nil { var fncls__2924d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_fn_class = fncls__2924d; tmp8 = fncls__2924d } else { tmp8 = fncls__2924 }; arg_2913 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :376:1
		if linked_2909 == nil { ifn_2910.Invoke_O_O_O__O(arg_2911, arg_2912, arg_2913) } else { linked_2909.(*A_arbace_j2g_world_par_levels_A).Invoke_O_O_O_O__O(root_2908, arg_2911, arg_2912, arg_2913)
		}

		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_j2g_world_A_const_201)
//line :365:1
		var seq_78000316__2 any; var root_2841 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2841, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2843 lang.IFn














		if linked_2842 == nil { ifn_2843 = lang.IFn_Cast(root_2841) } else { ifn_2843 = nil }; var arg_2844 any = names__1; if linked_2842 == nil { seq_78000316__2 = ifn_2843.Invoke_O__O(arg_2844) } else { seq_78000316__2 = linked_2842.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2841, arg_2844) }
//line :365:1
		var chunk_78000317__3 any; var count_78000318__4 int64 = 0; var i_78000319__5 int64 = 0; L1: for {














			if lang.Numbers_Lt_J_J__Z_NoInit(i_78000319__5, count_78000318__4) { var n__6 any = lang.Indexed_Cast(chunk_78000317__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_78000319__5)); var tmp9 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_New_O_O(n__6, t.F_failed); var tmp10 *jrt.Class; var fncls__2931 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_fn_class
				if fncls__2931 == nil { var fncls__2931d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_fn_class = fncls__2931d; tmp10 = fncls__2931d } else { tmp10 = fncls__2931 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :380:1
				seq_78000316__2, chunk_78000317__3, count_78000318__4, i_78000319__5 = seq_78000316__2, chunk_78000317__3, count_78000318__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_78000319__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_2845 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2845, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2847 lang.IFn; if linked_2846 == nil { ifn_2847 = lang.IFn_Cast(root_2845) } else { ifn_2847 = nil }; var arg_2848 any = seq_78000316__2; if linked_2846 == nil { temp__1927000414__auto____6 = ifn_2847.Invoke_O__O(arg_2848) } else { temp__1927000414__auto____6 = linked_2846.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2845, arg_2848) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_78000316__7 any = temp__1927000414__auto____6; var tmp11 any; var root_2849 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2849, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2851 lang.IFn; if linked_2850 == nil { ifn_2851 = lang.IFn_Cast(root_2849) } else { ifn_2851 = nil }; var arg_2852 any = seq_78000316__7; if linked_2850 == nil { tmp11 = ifn_2851.Invoke_O__O(arg_2852) } else { tmp11 = linked_2850.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2849, arg_2852) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8 any; var root_2853 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2853, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2855 lang.IFn; if linked_2854 == nil { ifn_2855 = lang.IFn_Cast(root_2853) } else { ifn_2855 = nil }; var arg_2856 any = seq_78000316__7; if linked_2854 == nil { c__1927000678__auto____8 = ifn_2855.Invoke_O__O(arg_2856) } else { c__1927000678__auto____8 = linked_2854.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2853, arg_2856) }; var tmp12 any; var root_2932 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2932, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2934 lang.IFn; if linked_2933 == nil { ifn_2934 = lang.IFn_Cast(root_2932) } else { ifn_2934 = nil }; var arg_2935 any = seq_78000316__7; if linked_2933 == nil { tmp12 = ifn_2934.Invoke_O__O(arg_2935) } else { tmp12 = linked_2933.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2932, arg_2935) }; seq_78000316__2, chunk_78000317__3, count_78000318__4, i_78000319__5 = tmp12, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_2857 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2857, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2859 lang.IFn; if linked_2858 == nil { ifn_2859 = lang.IFn_Cast(root_2857) } else { ifn_2859 = nil }; var arg_2860 any = seq_78000316__7; if linked_2858 == nil { n__8 = ifn_2859.Invoke_O__O(arg_2860) } else { n__8 = linked_2858.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2857, arg_2860) }
					var tmp13 any = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_New_O_O(n__8, t.F_failed); var tmp14 *jrt.Class; var fncls__2942 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_fn_class; if fncls__2942 == nil { var fncls__2942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_fn_class = fncls__2942d; tmp14 = fncls__2942d } else { tmp14 = fncls__2942 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O()
//line :380:1
					var tmp15 any; var root_2943 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any = seq_78000316__7; if linked_2944 == nil { tmp15 = ifn_2945.Invoke_O__O(arg_2946) } else { tmp15 = linked_2944.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2943, arg_2946) }; seq_78000316__2, chunk_78000317__3, count_78000318__4, i_78000319__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }
//line :365:1
	panic("j2g: unreachable")
}
func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_New() *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A) Ctor() {}
//line :367:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A) Invoke_O_O__O(self, p1__78000222_SHARP___1 any) any { var G__78000308__2_ any; var root_2867 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2869 lang.IFn; if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any = p1__78000222_SHARP___1; if linked_2868 == nil { G__78000308__2_ = ifn_2869.Invoke_O__O(arg_2870) } else { G__78000308__2_ = linked_2868.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2867, arg_2870) }; var G__78000308__3_ any; if lang.Util_Identical_O_O__Z_NoInit(G__78000308__2_, nil) { G__78000308__3_ = nil } else { G__78000308__3_ = A_arbace_j2g_world_A_const_146.Invoke_O__O(G__78000308__2_) }; if lang.Util_Identical_O_O__Z_NoInit(G__78000308__3_, nil) { return nil } else { var root_2871 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var linked_2872 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2871, aot_arbace_core.A_arbace_core_vector_A_fn_class); var ifn_2873 lang.IFn; if linked_2872 == nil { ifn_2873 = lang.IFn_Cast(root_2871) } else { ifn_2873 = nil }; var arg_2874 any = G__78000308__3_; if linked_2872 == nil { return ifn_2873.Invoke_O__O(arg_2874) } else { return linked_2872.(*aot_arbace_core.A_arbace_core_vector_A).Invoke_O_O__O(root_2871, arg_2874) } } }
func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A{}; t.Ctor_O(p0); return t }
//line :368:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :368:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A) Invoke_O_O__O(self, n__1 any) any {
	var tmp1 *lang.Keyword = A_arbace_j2g_world_A_const_194; var tmp2 any; var root_2876 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2878 lang.IFn; if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any = n__1; if linked_2877 == nil { tmp2 = ifn_2878.Invoke_O__O(arg_2879) } else { tmp2 = linked_2877.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2876, arg_2879) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { return nil } else { var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_2880 any = A_arbace_j2g_world_A_const_195.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2880, aot_arbace_classes_analyze.A_arbace_classes_analyze_resolve_header_BANG__A_fn_class); var ifn_2882 lang.IFn; if linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any = n__1; if linked_2881 == nil { tmp3 = ifn_2882.Invoke_O__O(arg_2883) } else { tmp3 = linked_2881.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_resolve_header_BANG__A).Invoke_O_O__O(root_2880, arg_2883) } }
//line :369:1
		return nil }(); if tmp4 != nil { if true { var e__4 jrt.Throwable_I = tmp4; var root_2884 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2885 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2884, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2886 lang.IFn
			if linked_2885 == nil { ifn_2886 = lang.IFn_Cast(root_2884) } else { ifn_2886 = nil }; var arg_2887 any = t.F_failed; var arg_2888 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2889 any = lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref()); if linked_2885 == nil { tmp3 = ifn_2886.Invoke_O_O_O__O(arg_2887, arg_2888, arg_2889) } else { tmp3 = linked_2885.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2884, arg_2887, arg_2888, arg_2889) } } }
//line :369:1
		return tmp3
	}
}

func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A{}; t.Ctor_O(p0); return t }
//line :373:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :373:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var root_2897 any = A_arbace_j2g_world_A_const_197.GetRawRoot__O(); var linked_2898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2897, aot_arbace_classes_analyze.A_arbace_classes_analyze_resolve_members_BANG__A_fn_class); var ifn_2899 lang.IFn; if linked_2898 == nil { ifn_2899 = lang.IFn_Cast(root_2897) } else { ifn_2899 = nil }; var arg_2900 any = n__1; if linked_2898 == nil { tmp1 = ifn_2899.Invoke_O__O(arg_2900) } else { tmp1 = linked_2898.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_resolve_members_BANG__A).Invoke_O_O__O(root_2897, arg_2900) } }
//line :373:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var root_2901 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2902 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2901, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2903 lang.IFn
		if linked_2902 == nil { ifn_2903 = lang.IFn_Cast(root_2901) } else { ifn_2903 = nil }; var arg_2904 any = t.F_failed; var arg_2905 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2906 any = lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref()); if linked_2902 == nil { tmp1 = ifn_2903.Invoke_O_O_O__O(arg_2904, arg_2905, arg_2906) } else { tmp1 = linked_2902.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2901, arg_2904, arg_2905, arg_2906) } } }; return tmp1 }


func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A{}; t.Ctor_O(p0); return t }
//line :377:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :377:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var root_2914 any = A_arbace_j2g_world_A_const_198.GetRawRoot__O(); var linked_2915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2914, aot_arbace_classes_analyze.A_arbace_classes_analyze_add_bridges_BANG__A_fn_class); var ifn_2916 lang.IFn; if linked_2915 == nil { ifn_2916 = lang.IFn_Cast(root_2914) } else { ifn_2916 = nil }; var arg_2917 any = n__1; if linked_2915 == nil { tmp1 = ifn_2916.Invoke_O__O(arg_2917) } else { tmp1 = linked_2915.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_add_bridges_BANG__A).Invoke_O_O__O(root_2914, arg_2917) } }
//line :377:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var root_2918 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2919 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2918, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2920 lang.IFn
		if linked_2919 == nil { ifn_2920 = lang.IFn_Cast(root_2918) } else { ifn_2920 = nil }; var arg_2921 any = t.F_failed; var arg_2922 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2923 any = lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_112, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref()); if linked_2919 == nil { tmp1 = ifn_2920.Invoke_O_O_O__O(arg_2921, arg_2922, arg_2923) } else { tmp1 = linked_2919.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2918, arg_2921, arg_2922, arg_2923) } } }; return tmp1 }


func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A{}; t.Ctor_O_O(p0, p1); return t }
//line :381:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :381:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_j2g_world_A_const_202.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var root_2925 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2925, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2927 lang.IFn; if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any; var t_ any = t.F_failed; t.F_failed = nil; arg_2928 = t_; var arg_2929 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2930 any; var tmp3 any; var t__2 any = t.F_n; t.F_n = nil; tmp3 = t__2; arg_2930 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref()); if linked_2926 == nil { tmp1 = ifn_2927.Invoke_O_O_O__O(arg_2928, arg_2929, arg_2930) } else { tmp1 = linked_2926.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2925, arg_2928, arg_2929, arg_2930) } } }; return tmp1 }
//line :381:1
func A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A{}; t.Ctor_O_O(p0, p1); return t }
//line :381:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :381:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_j2g_world_A_const_202.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var root_2936 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2937 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2936, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2938 lang.IFn; if linked_2937 == nil { ifn_2938 = lang.IFn_Cast(root_2936) } else { ifn_2938 = nil }; var arg_2939 any; var t_ any = t.F_failed; t.F_failed = nil; arg_2939 = t_; var arg_2940 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2941 any; var tmp3 any; var t__2 any = t.F_n; t.F_n = nil; tmp3 = t__2; arg_2941 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref()); if linked_2937 == nil { tmp1 = ifn_2938.Invoke_O_O_O__O(arg_2939, arg_2940, arg_2941) } else { tmp1 = linked_2937.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2936, arg_2939, arg_2940, arg_2941) } } }; return tmp1 }
func A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A{}; t.Ctor_O(p0); return t }
//line :382:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :382:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															{ var root_2948 any = A_arbace_j2g_world_A_const_203.GetRawRoot__O(); var linked_2949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2948, aot_arbace_classes_analyze.A_arbace_classes_analyze_analyze_class_BANG__A_fn_class); var ifn_2950 lang.IFn; if linked_2949 == nil { ifn_2950 = lang.IFn_Cast(root_2948) } else { ifn_2950 = nil }; var arg_2951 any = n__1; if linked_2949 == nil { tmp1 = ifn_2950.Invoke_O__O(arg_2951) } else { tmp1 = linked_2949.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_analyze_class_BANG__A).Invoke_O_O__O(root_2948, arg_2951) } }
//line :382:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var root_2958 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2959 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2958, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2960 lang.IFn


		if linked_2959 == nil { ifn_2960 = lang.IFn_Cast(root_2958) } else { ifn_2960 = nil }; var arg_2961 any; var tmp3 *lang.Keyword = A_arbace_j2g_world_A_const_204; var tmp4 any; var root_2965 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_2966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2965, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2967 lang.IFn; if linked_2966 == nil { ifn_2967 = lang.IFn_Cast(root_2965) } else { ifn_2967 = nil }; var arg_2968 any = n__1; if linked_2966 == nil { tmp4 = ifn_2967.Invoke_O__O(arg_2968) } else { tmp4 = linked_2966.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2965, arg_2968) }; arg_2961 = tmp3.Invoke_O__O(tmp4); var arg_2962 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var arg_2963 any = A_arbace_j2g_world_A_const_205; var arg_2964 any = e__4.GetMessage__String().Ref(); if linked_2959 == nil { ifn_2960.Invoke_O_O_O_O__O(arg_2961, arg_2962, arg_2963, arg_2964) } else { linked_2959.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2958, arg_2961, arg_2962, arg_2963, arg_2964) }
		var root_2952 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_2953 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2952, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2954 lang.IFn; if linked_2953 == nil { ifn_2954 = lang.IFn_Cast(root_2952) } else { ifn_2954 = nil }; var arg_2955 any = t.F_failed; var arg_2956 any = A_arbace_j2g_world_A_const_14.GetRawRoot__O(); var arg_2957 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil, nil); var tmp6 any = e__4.GetMessage__String().Ref(); var tmp7 *jrt.String; var G__78000326__8_ any = e__4.GetCause__Throwable(); var G__78000326__9_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__78000326__8_, nil) { G__78000326__9_ = nil } else { G__78000326__9_ = jrt.Throwable_Cast(G__78000326__8_).GetMessage__String().Ref() }; if lang.Util_Identical_O_O__Z_NoInit(G__78000326__9_, nil) { tmp7 = nil } else { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_69, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__78000326__9_)) }
//line :386:1
		arg_2957 = lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, tmp7.Ref())).Ref()); if linked_2953 == nil { tmp1 = ifn_2954.Invoke_O_O_O__O(arg_2955, arg_2956, arg_2957) } else { tmp1 = linked_2953.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2952, arg_2955, arg_2956, arg_2957) } } }; return tmp1 }















func A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :402:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A) Ctor_O_O_O_O_O(c__rt_order, c__analyze_BANG_, c__unit, c__rt_start, c__names1 any) { t.F_rt_order = c__rt_order; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit; t.F_rt_start = c__rt_start; t.F_names1 = c__names1 }
//line :402:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_2996 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_2997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2996, A_arbace_j2g_world_id_space_A_fn_class); var ifn_2998 lang.IFn; if linked_2997 == nil { ifn_2998 = lang.IFn_Cast(root_2996) } else { ifn_2998 = nil }; if linked_2997 == nil { tmp1 = ifn_2998.Invoke__O() } else { tmp1 = linked_2997.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_2996) }; var tmp2 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(tmp1); var tmp3 any; var t_ any = t.F_rt_start; t.F_rt_start = nil; tmp3 = t_; tmp2.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(tmp3)))
//line :402:1
	var tmp4 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_2999 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_3000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2999, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3001 lang.IFn; if linked_3000 == nil { ifn_3001 = lang.IFn_Cast(root_2999) } else { ifn_3001 = nil }; var arg_3002 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_world_A_const_209; var tmp7 any; var root_3008 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_3009 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3008, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3010 lang.IFn; if linked_3009 == nil { ifn_3010 = lang.IFn_Cast(root_3008) } else { ifn_3010 = nil }; var arg_3011 any; var t__2 any = t.F_unit; t.F_unit = nil; arg_3011 = t__2; var arg_3012 any = A_arbace_j2g_world_A_const_133; var arg_3013 any; var t__3 any = t.F_rt_order; t.F_rt_order = nil; arg_3013 = t__3; if linked_3009 == nil { tmp7 = ifn_3010.Invoke_O_O_O__O(arg_3011, arg_3012, arg_3013) } else { tmp7 = linked_3009.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3008, arg_3011, arg_3012, arg_3013) }; arg_3002 = tmp5.Invoke_O_O__O(tmp6, tmp7); if linked_3000 == nil { ifn_3001.Invoke_O__O(arg_3002) } else { linked_3000.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2999, arg_3002) }; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var root_2985 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_2986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2985, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_2987 lang.IFn; if linked_2986 == nil { ifn_2987 = lang.IFn_Cast(root_2985) } else { ifn_2987 = nil }; var arg_2988 any; var t__4 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; arg_2988 = t__4; var arg_2989 any; var t__5 any = t.F_names1; t.F_names1 = nil; arg_2989 = t__5; if linked_2986 == nil { tmp4 = ifn_2987.Invoke_O_O__O(arg_2988, arg_2989) } else { tmp4 = linked_2986.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_2985, arg_2988, arg_2989) } }
//line :404:1
			return nil }(); var root_2990 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_2991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2990, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2992 lang.IFn; if linked_2991 == nil { ifn_2992 = lang.IFn_Cast(root_2990) } else { ifn_2992 = nil }; if linked_2991 == nil { ifn_2992.Invoke__O() } else { linked_2991.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2990) }
//line :402:1
			if tmp8 != nil { panic(tmp8) } }; return nil }(); var tmp10 any; var root_2993 any = A_arbace_j2g_world_A_const_206.GetRawRoot__O(); var linked_2994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2993, A_arbace_j2g_world_id_space_A_fn_class); var ifn_2995 lang.IFn



	if linked_2994 == nil { ifn_2995 = lang.IFn_Cast(root_2993) } else { ifn_2995 = nil }; if linked_2994 == nil { tmp10 = ifn_2995.Invoke__O() } else { tmp10 = linked_2994.(*A_arbace_j2g_world_id_space_A).Invoke_O__O(root_2993) }; jrt.ThreadLocal_Cast(tmp10).Remove__V()
//line :402:1
	if tmp9 != nil { panic(tmp9) }; return tmp4
}




func A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A{}; t.Ctor_O_O(p0, p1); return t }
//line :408:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A) Ctor_O_O(c__analyze_BANG_, c__names1 any) { t.F_analyze_BANG_ = c__analyze_BANG_; t.F_names1 = c__names1 }
//line :408:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3691 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_3692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3691, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3693 lang.IFn; if linked_3692 == nil { ifn_3693 = lang.IFn_Cast(root_3691) } else { ifn_3693 = nil }; var arg_3694 any; var t_ any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; arg_3694 = t_; var arg_3695 any; var t__2 any = t.F_names1; t.F_names1 = nil; arg_3695 = t__2; if linked_3692 == nil { tmp1 = ifn_3693.Invoke_O_O__O(arg_3694, arg_3695) } else { tmp1 = linked_3692.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3691, arg_3694, arg_3695) } }; return nil }(); var root_3696 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_3697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3696, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3698 lang.IFn; if linked_3697 == nil { ifn_3698 = lang.IFn_Cast(root_3696) } else { ifn_3698 = nil }; if linked_3697 == nil { ifn_3698.Invoke__O() } else { linked_3697.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3696) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }
























func A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_New() *A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A{}; t.Ctor(); return t }
//line :433:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A) Ctor() {}
//line :433:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A) Invoke_O_O__O(self, n__1 any) any { var root_3040 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any; var root_3044 any = A_arbace_j2g_world_A_const_87.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_3046 lang.IFn; if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = n__1; var arg_3048 any = Lit_13; if linked_3045 == nil { arg_3043 = ifn_3046.Invoke_O_O__O(arg_3047, arg_3048) } else { arg_3043 = linked_3045.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_3044, arg_3047, arg_3048) }; if linked_3041 == nil { return ifn_3042.Invoke_O__O(arg_3043) } else { return linked_3041.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3040, arg_3043) } }

func A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A{}; t.Ctor_O(p0); return t }
//line :435:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A) Ctor_O(c__heights any) { t.F_heights = c__heights }
//line :435:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A) Invoke_O_O__O(self, n__1 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3054 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3054, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3056 lang.IFn; if
														linked_3055 == nil { ifn_3056 = lang.IFn_Cast(root_3054) } else { ifn_3056 = nil }; var arg_3057 any = t.F_heights; if linked_3055 == nil { tmp1 = ifn_3056.Invoke_O__O(arg_3057) } else { tmp1 = linked_3055.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3054, arg_3057) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, n__1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var ms__3 any; var root_3058 any = A_arbace_j2g_world_A_const_210.GetRawRoot__O(); var linked_3059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3058, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3060 lang.IFn
															if linked_3059 == nil { ifn_3060 = lang.IFn_Cast(root_3058) } else { ifn_3060 = nil }; var arg_3061 any; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_New(); var tmp3 *jrt.Class; var fncls__3067 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_fn_class; if fncls__3067 == nil { var fncls__3067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_fn_class = fncls__3067d; tmp3 = fncls__3067d } else { tmp3 = fncls__3067 }; arg_3061 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_3062 any; var root_3068 any = A_arbace_j2g_world_A_const_153.GetRawRoot__O(); var linked_3069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3068, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_3070 lang.IFn; if linked_3069 == nil { ifn_3070 = lang.IFn_Cast(root_3068) } else { ifn_3070 = nil }; var arg_3071 any; var tmp4 *lang.Keyword = A_arbace_j2g_world_A_const_211; var tmp5 any; var root_3072 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_3073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3072, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3074 lang.IFn; if linked_3073 == nil { ifn_3074 = lang.IFn_Cast(root_3072) } else { ifn_3074 = nil }; var arg_3075 any = n__1; if linked_3073 == nil { tmp5 = ifn_3074.Invoke_O__O(arg_3075) } else { tmp5 = linked_3073.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3072, arg_3075) }; arg_3071 = tmp4.Invoke_O__O(tmp5); if linked_3069 == nil { arg_3062 = ifn_3070.Invoke_O__O(arg_3071) } else { arg_3062 = linked_3069.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_3068, arg_3071) }; if linked_3059 == nil { ms__3 = ifn_3060.Invoke_O_O__O(arg_3061, arg_3062) } else { ms__3 = linked_3059.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3058, arg_3061, arg_3062) }
//line :436:1
		var h__4 any; var tmp6 any; var root_3076 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3078 lang.IFn

		if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any = ms__3; if linked_3077 == nil { tmp6 = ifn_3078.Invoke_O__O(arg_3079) } else { tmp6 = linked_3077.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3076, arg_3079) }; if jrt.J2g_Truth(tmp6) { var na_3080 any; var root_3081 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = A_arbace_j2g_world_A_const_152.GetRawRoot__O(); var arg_3085 any; var root_3086 any = A_arbace_j2g_world_A_const_63.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3086, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3088 lang.IFn; if linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any = self; var arg_3090 any = ms__3; if linked_3087 == nil { arg_3085 = ifn_3088.Invoke_O_O__O(arg_3089, arg_3090) } else { arg_3085 = linked_3087.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3086, arg_3089, arg_3090) }; if linked_3082 == nil { na_3080 = ifn_3083.Invoke_O_O__O(arg_3084, arg_3085) } else { na_3080 = linked_3082.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3081, arg_3084, arg_3085) }; if jrt.Long_InstanceOf(na_3080) { var n0_3091 int64 = jrt.NN(jrt.Long_Cast(na_3080)).LongValue__J(); if n0_3091 == 9223372036854775807 { h__4 = lang.Numbers_Inc_O__Number_NoInit(na_3080) } else { h__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_3091 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_3080) { var n0_3091_2 float64 = jrt.NN(jrt.Double_Cast(na_3080)).DoubleValue__D(); h__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_3091_2 + 1.0).Ref() } else { h__4 = lang.Numbers_Inc_O__Number_NoInit(na_3080) } } } else { h__4 = A_arbace_j2g_world_A_const_111 }
		var root_3092 any = A_arbace_j2g_world_A_const_74.GetRawRoot__O(); var linked_3093 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3092, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3094 lang.IFn; if linked_3093 == nil { ifn_3094 = lang.IFn_Cast(root_3092) } else { ifn_3094 = nil }; var arg_3095 any = t.F_heights; var arg_3096 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var arg_3097 any = n__1; var arg_3098 any = h__4; if linked_3093 == nil { ifn_3094.Invoke_O_O_O_O__O(arg_3095, arg_3096, arg_3097, arg_3098) } else { linked_3093.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3092, arg_3095, arg_3096, arg_3097, arg_3098) }
//line :436:1
		return h__4 } }
func A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_New() *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A) Ctor() {}
//line :437:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A) Invoke_O_O__O(self, p1__78000223_SHARP___1 any) any { var tmp1 any; var root_3063 any = A_arbace_j2g_world_A_const_156.GetRawRoot__O(); var linked_3064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3063, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_3065 lang.IFn; if linked_3064 == nil { ifn_3065 = lang.IFn_Cast(root_3063) } else { ifn_3065 = nil }; var arg_3066 any = p1__78000223_SHARP___1; if linked_3064 == nil { tmp1 = ifn_3065.Invoke_O__O(arg_3066) } else { tmp1 = linked_3064.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_3063, arg_3066) }; if jrt.J2g_Truth(tmp1) { return p1__78000223_SHARP___1 } else { return nil } }




func A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A{}; t.Ctor_O_O(p0, p1); return t }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A) Ctor_O_O(c__tops_QMARK_, c__height any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A) Invoke_O_O__O(self, s__78000340__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_New_O_O_O_O(self, t.F_tops_QMARK_, t.F_height, s__78000340__1); var tmp2 *jrt.Class; var fncls__3179 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_fn_class; if fncls__3179 == nil { var fncls__3179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_fn_class = fncls__3179d; tmp2 = fncls__3179d } else { tmp2 = fncls__3179 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :442:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A) Ctor_O_O_O_O(c__iter__78000339, c__tops_QMARK_, c__height, c__s__78000340 any) { t.F_iter__78000339 = c__iter__78000339; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height; t.F_s__78000340 = c__s__78000340 }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A) Invoke_O__O(self any) any { { var s__78000340__1 any; var t_ any = t.F_s__78000340; t.F_s__78000340 = nil; s__78000340__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3114 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3116 lang.IFn; if linked_3115 == nil { ifn_3116 = lang.IFn_Cast(root_3114) } else { ifn_3116 = nil }; var arg_3117 any = s__78000340__1; if linked_3115 == nil { temp__1927000414__auto____2 = ifn_3116.Invoke_O__O(arg_3117) } else { temp__1927000414__auto____2 = linked_3115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3114, arg_3117) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000340__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3118 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3118, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3120 lang.IFn; if linked_3119 == nil { ifn_3120 = lang.IFn_Cast(root_3118) } else { ifn_3120 = nil }; var arg_3121 any = s__78000340__3; if linked_3119 == nil { tmp1 = ifn_3120.Invoke_O__O(arg_3121) } else { tmp1 = linked_3119.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3118, arg_3121) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3122 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3122, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3124 lang.IFn; if linked_3123 == nil { ifn_3124 = lang.IFn_Cast(root_3122) } else { ifn_3124 = nil }; var arg_3125 any = s__78000340__3; if linked_3123 == nil { c__1927001037__auto____4 = ifn_3124.Invoke_O__O(arg_3125) } else { c__1927001037__auto____4 = linked_3123.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3122, arg_3125) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000342__6 any; var root_3126 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3126, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3128 lang.IFn; if linked_3127 == nil { ifn_3128 = lang.IFn_Cast(root_3126) } else { ifn_3128 = nil }; var arg_3129 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3127 == nil { b__78000342__6 = ifn_3128.Invoke_O__O(arg_3129) } else { b__78000342__6 = linked_3127.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3126, arg_3129) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_New_O_O_I_O_O(t.F_tops_QMARK_, t.F_height, size__1927001038__auto____5, c__1927001037__auto____4, b__78000342__6); var tmp3 *jrt.Class; var fncls__3137 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_fn_class; if fncls__3137 == nil { var fncls__3137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_fn_class = fncls__3137d; tmp3 = fncls__3137d } else { tmp3 = fncls__3137 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3138 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3138, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3140 lang.IFn; if linked_3139 == nil { ifn_3140 = lang.IFn_Cast(root_3138) } else { ifn_3140 = nil }; var arg_3141 any; var root_3143 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3143, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3145 lang.IFn; if linked_3144 == nil { ifn_3145 = lang.IFn_Cast(root_3143) } else { ifn_3145 = nil }; var arg_3146 any = b__78000342__6; if linked_3144 == nil { arg_3141 = ifn_3145.Invoke_O__O(arg_3146) } else { arg_3141 = linked_3144.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3143, arg_3146) }; var arg_3142 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000339); var tmp5 any; var root_3147 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3147, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3149 lang.IFn; if linked_3148 == nil { ifn_3149 = lang.IFn_Cast(root_3147) } else { ifn_3149 = nil }; var arg_3150 any = s__78000340__3; if linked_3148 == nil { tmp5 = ifn_3149.Invoke_O__O(arg_3150) } else { tmp5 = linked_3148.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3147, arg_3150) }; arg_3142 = tmp4.Invoke_O__O(tmp5); if linked_3139 == nil { return ifn_3140.Invoke_O_O__O(arg_3141, arg_3142) } else { return linked_3139.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3138, arg_3141, arg_3142) } } else { var root_3151 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3151, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3153 lang.IFn; if linked_3152 == nil { ifn_3153 = lang.IFn_Cast(root_3151) } else { ifn_3153 = nil }; var arg_3154 any; var root_3156 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3156, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3158 lang.IFn; if linked_3157 == nil { ifn_3158 = lang.IFn_Cast(root_3156) } else { ifn_3158 = nil }; var arg_3159 any = b__78000342__6; if linked_3157 == nil { arg_3154 = ifn_3158.Invoke_O__O(arg_3159) } else { arg_3154 = linked_3157.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3156, arg_3159) }; var arg_3155 any; if linked_3152 == nil { return ifn_3153.Invoke_O_O__O(arg_3154, arg_3155) } else { return linked_3152.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3151, arg_3154, arg_3155) } } } else { var n__4 any; var root_3160 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3160, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3162 lang.IFn; if linked_3161 == nil { ifn_3162 = lang.IFn_Cast(root_3160) } else { ifn_3162 = nil }; var arg_3163 any = s__78000340__3; if linked_3161 == nil { n__4 = ifn_3162.Invoke_O__O(arg_3163) } else { n__4 = linked_3161.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3160, arg_3163) }; var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 bool; var na_3164 any = lang.IFn_Cast(t.F_height).Invoke_O__O(n__4); if jrt.Long_InstanceOf(na_3164) { var n0_3165 int64 = jrt.NN(jrt.Long_Cast(na_3164)).LongValue__J(); tmp7 = n0_3165 == 0 } else { if jrt.Double_InstanceOf(na_3164) { var n0_3165_2 float64 = jrt.NN(jrt.Double_Cast(na_3164)).DoubleValue__D(); tmp7 = n0_3165_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_3164) } }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp7).Ref() } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_3166 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3166, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3168 lang.IFn; if linked_3167 == nil { ifn_3168 = lang.IFn_Cast(root_3166) } else { ifn_3168 = nil }; var arg_3169 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3170 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000339); var tmp9 any; var root_3171 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3171, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3173 lang.IFn; if linked_3172 == nil { ifn_3173 = lang.IFn_Cast(root_3171) } else { ifn_3173 = nil }; var arg_3174 any = s__78000340__3; if linked_3172 == nil { tmp9 = ifn_3173.Invoke_O__O(arg_3174) } else { tmp9 = linked_3172.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3171, arg_3174) }; arg_3170 = tmp8.Invoke_O__O(tmp9); if linked_3167 == nil { return ifn_3168.Invoke_O_O__O(arg_3169, arg_3170) } else { return linked_3167.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3166, arg_3169, arg_3170) } } else { var tmp10 any; var root_3175 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3175, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3177 lang.IFn; if linked_3176 == nil { ifn_3177 = lang.IFn_Cast(root_3175) } else { ifn_3177 = nil }; var arg_3178 any = s__78000340__3; if linked_3176 == nil { tmp10 = ifn_3177.Invoke_O__O(arg_3178) } else { tmp10 = linked_3176.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3175, arg_3178) }; s__78000340__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :442:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A) Ctor_O_O_I_O_O(c__tops_QMARK_, c__height any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__78000342 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__78000342 = c__b__78000342 }
//line :442:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A) Invoke_O__O(self any) any { { var i__78000341__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000341__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000341__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 bool; var na_3130 any = lang.IFn_Cast(t.F_height).Invoke_O__O(n__2); if jrt.Long_InstanceOf(na_3130) { var n0_3131 int64 = jrt.NN(jrt.Long_Cast(na_3130)).LongValue__J(); tmp3 = n0_3131 == 0 } else { if jrt.Double_InstanceOf(na_3130) { var n0_3131_2 float64 = jrt.NN(jrt.Double_Cast(na_3130)).DoubleValue__D(); tmp3 = n0_3131_2 == 0.0 } else { tmp3 = lang.Numbers_IsZero_O__Z_NoInit(na_3130) } }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_3132 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3132, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3134 lang.IFn; if linked_3133 == nil { ifn_3134 = lang.IFn_Cast(root_3132) } else { ifn_3134 = nil }; var arg_3135 any = t.F_b__78000342; var arg_3136 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3133 == nil { ifn_3134.Invoke_O_O__O(arg_3135, arg_3136) } else { linked_3133.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3132, arg_3135, arg_3136) }; i__78000341__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000341__1); continue L1 } else { i__78000341__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000341__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A{}; t.Ctor_O_O(p0, p1); return t }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A) Ctor_O_O(c__tops_QMARK_, c__height any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A) Invoke_O_O__O(self, s__78000350__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_New_O_O_O_O(self, t.F_tops_QMARK_, t.F_height, s__78000350__1); var tmp2 *jrt.Class; var fncls__3254 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_fn_class; if fncls__3254 == nil { var fncls__3254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_fn_class = fncls__3254d; tmp2 = fncls__3254d } else { tmp2 = fncls__3254 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :443:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A) Ctor_O_O_O_O(c__iter__78000349, c__tops_QMARK_, c__height, c__s__78000350 any) { t.F_iter__78000349 = c__iter__78000349; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height; t.F_s__78000350 = c__s__78000350 }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A) Invoke_O__O(self any) any { { var s__78000350__1 any; var t_ any = t.F_s__78000350; t.F_s__78000350 = nil; s__78000350__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3181 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3181, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3183 lang.IFn; if linked_3182 == nil { ifn_3183 = lang.IFn_Cast(root_3181) } else { ifn_3183 = nil }; var arg_3184 any = s__78000350__1; if linked_3182 == nil { temp__1927000414__auto____2 = ifn_3183.Invoke_O__O(arg_3184) } else { temp__1927000414__auto____2 = linked_3182.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3181, arg_3184) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000350__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3185 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3185, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3187 lang.IFn; if linked_3186 == nil { ifn_3187 = lang.IFn_Cast(root_3185) } else { ifn_3187 = nil }; var arg_3188 any = s__78000350__3; if linked_3186 == nil { tmp1 = ifn_3187.Invoke_O__O(arg_3188) } else { tmp1 = linked_3186.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3185, arg_3188) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3189 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3189, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3191 lang.IFn; if linked_3190 == nil { ifn_3191 = lang.IFn_Cast(root_3189) } else { ifn_3191 = nil }; var arg_3192 any = s__78000350__3; if linked_3190 == nil { c__1927001037__auto____4 = ifn_3191.Invoke_O__O(arg_3192) } else { c__1927001037__auto____4 = linked_3190.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3189, arg_3192) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000352__6 any; var root_3193 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3193, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3195 lang.IFn; if linked_3194 == nil { ifn_3195 = lang.IFn_Cast(root_3193) } else { ifn_3195 = nil }; var arg_3196 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3194 == nil { b__78000352__6 = ifn_3195.Invoke_O__O(arg_3196) } else { b__78000352__6 = linked_3194.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3193, arg_3196) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_New_O_O_I_O_O(t.F_tops_QMARK_, t.F_height, size__1927001038__auto____5, b__78000352__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3208 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_fn_class; if fncls__3208 == nil { var fncls__3208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_fn_class = fncls__3208d; tmp3 = fncls__3208d } else { tmp3 = fncls__3208 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3209 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3211 lang.IFn; if linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any; var root_3214 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3214, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3216 lang.IFn; if linked_3215 == nil { ifn_3216 = lang.IFn_Cast(root_3214) } else { ifn_3216 = nil }; var arg_3217 any = b__78000352__6; if linked_3215 == nil { arg_3212 = ifn_3216.Invoke_O__O(arg_3217) } else { arg_3212 = linked_3215.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3214, arg_3217) }; var arg_3213 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000349); var tmp5 any; var root_3218 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3218, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3220 lang.IFn; if linked_3219 == nil { ifn_3220 = lang.IFn_Cast(root_3218) } else { ifn_3220 = nil }; var arg_3221 any = s__78000350__3; if linked_3219 == nil { tmp5 = ifn_3220.Invoke_O__O(arg_3221) } else { tmp5 = linked_3219.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3218, arg_3221) }; arg_3213 = tmp4.Invoke_O__O(tmp5); if linked_3210 == nil { return ifn_3211.Invoke_O_O__O(arg_3212, arg_3213) } else { return linked_3210.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3209, arg_3212, arg_3213) } } else { var root_3222 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3222, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3224 lang.IFn; if linked_3223 == nil { ifn_3224 = lang.IFn_Cast(root_3222) } else { ifn_3224 = nil }; var arg_3225 any; var root_3227 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3227, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3229 lang.IFn; if linked_3228 == nil { ifn_3229 = lang.IFn_Cast(root_3227) } else { ifn_3229 = nil }; var arg_3230 any = b__78000352__6; if linked_3228 == nil { arg_3225 = ifn_3229.Invoke_O__O(arg_3230) } else { arg_3225 = linked_3228.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3227, arg_3230) }; var arg_3226 any; if linked_3223 == nil { return ifn_3224.Invoke_O_O__O(arg_3225, arg_3226) } else { return linked_3223.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3222, arg_3225, arg_3226) } } } else { var n__4 any; var root_3231 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3231, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3233 lang.IFn; if linked_3232 == nil { ifn_3233 = lang.IFn_Cast(root_3231) } else { ifn_3233 = nil }; var arg_3234 any = s__78000350__3; if linked_3232 == nil { n__4 = ifn_3233.Invoke_O__O(arg_3234) } else { n__4 = linked_3232.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3231, arg_3234) }; var tmp6 any; var and__1927000168__auto____5 any; var root_3235 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3235, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3237 lang.IFn; if linked_3236 == nil { ifn_3237 = lang.IFn_Cast(root_3235) } else { ifn_3237 = nil }; var arg_3238 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if linked_3236 == nil { and__1927000168__auto____5 = ifn_3237.Invoke_O__O(arg_3238) } else { and__1927000168__auto____5 = linked_3236.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3235, arg_3238) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 bool; var na_3239 any = lang.IFn_Cast(t.F_height).Invoke_O__O(n__4); if jrt.Long_InstanceOf(na_3239) { var n0_3240 int64 = jrt.NN(jrt.Long_Cast(na_3239)).LongValue__J(); tmp7 = n0_3240 == 0 } else { if jrt.Double_InstanceOf(na_3239) { var n0_3240_2 float64 = jrt.NN(jrt.Double_Cast(na_3239)).DoubleValue__D(); tmp7 = n0_3240_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_3239) } }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp7).Ref() } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_3241 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3241, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3243 lang.IFn; if linked_3242 == nil { ifn_3243 = lang.IFn_Cast(root_3241) } else { ifn_3243 = nil }; var arg_3244 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3245 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000349); var tmp9 any; var root_3246 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3246, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3248 lang.IFn; if linked_3247 == nil { ifn_3248 = lang.IFn_Cast(root_3246) } else { ifn_3248 = nil }; var arg_3249 any = s__78000350__3; if linked_3247 == nil { tmp9 = ifn_3248.Invoke_O__O(arg_3249) } else { tmp9 = linked_3247.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3246, arg_3249) }; arg_3245 = tmp8.Invoke_O__O(tmp9); if linked_3242 == nil { return ifn_3243.Invoke_O_O__O(arg_3244, arg_3245) } else { return linked_3242.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3241, arg_3244, arg_3245) } } else { var tmp10 any; var root_3250 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3250, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3252 lang.IFn; if linked_3251 == nil { ifn_3252 = lang.IFn_Cast(root_3250) } else { ifn_3252 = nil }; var arg_3253 any = s__78000350__3; if linked_3251 == nil { tmp10 = ifn_3252.Invoke_O__O(arg_3253) } else { tmp10 = linked_3251.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3250, arg_3253) }; s__78000350__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :443:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A) Ctor_O_O_I_O_O(c__tops_QMARK_, c__height any, c__size__1927001038__auto__ int32, c__b__78000352, c__c__1927001037__auto__ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_height = c__height; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__78000352 = c__b__78000352; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :443:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A) Invoke_O__O(self any) any { { var i__78000351__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000351__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000351__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_3197 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3197, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3199 lang.IFn; if linked_3198 == nil { ifn_3199 = lang.IFn_Cast(root_3197) } else { ifn_3199 = nil }; var arg_3200 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if linked_3198 == nil { and__1927000168__auto____3 = ifn_3199.Invoke_O__O(arg_3200) } else { and__1927000168__auto____3 = linked_3198.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3197, arg_3200) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 bool; var na_3201 any = lang.IFn_Cast(t.F_height).Invoke_O__O(n__2); if jrt.Long_InstanceOf(na_3201) { var n0_3202 int64 = jrt.NN(jrt.Long_Cast(na_3201)).LongValue__J(); tmp3 = n0_3202 == 0 } else { if jrt.Double_InstanceOf(na_3201) { var n0_3202_2 float64 = jrt.NN(jrt.Double_Cast(na_3201)).DoubleValue__D(); tmp3 = n0_3202_2 == 0.0 } else { tmp3 = lang.Numbers_IsZero_O__Z_NoInit(na_3201) } }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_3203 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3203, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3205 lang.IFn; if linked_3204 == nil { ifn_3205 = lang.IFn_Cast(root_3203) } else { ifn_3205 = nil }; var arg_3206 any = t.F_b__78000352; var arg_3207 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3204 == nil { ifn_3205.Invoke_O_O__O(arg_3206, arg_3207) } else { linked_3204.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3203, arg_3206, arg_3207) }; i__78000351__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000351__1); continue L1 } else { i__78000351__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000351__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A) Ctor_O_O(c__tops_QMARK_, c__levels any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_levels = c__levels }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A) Invoke_O_O__O(self, s__78000360__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_New_O_O_O_O(self, t.F_tops_QMARK_, s__78000360__1, t.F_levels); var tmp2 *jrt.Class; var fncls__3599 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_fn_class; if fncls__3599 == nil { var fncls__3599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_fn_class = fncls__3599d; tmp2 = fncls__3599d } else { tmp2 = fncls__3599 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :444:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A) Ctor_O_O_O_O(c__iter__78000359, c__tops_QMARK_, c__s__78000360, c__levels any) { t.F_iter__78000359 = c__iter__78000359; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000360 = c__s__78000360; t.F_levels = c__levels }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A) Invoke_O__O(self any) any { { var s__78000360__1 any; var t_ any = t.F_s__78000360; t.F_s__78000360 = nil; s__78000360__1 = t_; for { var temp__1927000414__auto____2 any; var root_3256 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3256, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3258 lang.IFn; if linked_3257 == nil { ifn_3258 = lang.IFn_Cast(root_3256) } else { ifn_3258 = nil }; var arg_3259 any = s__78000360__1; if linked_3257 == nil { temp__1927000414__auto____2 = ifn_3258.Invoke_O__O(arg_3259) } else { temp__1927000414__auto____2 = linked_3257.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3256, arg_3259) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000360__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3260 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3260, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3262 lang.IFn; if linked_3261 == nil { ifn_3262 = lang.IFn_Cast(root_3260) } else { ifn_3262 = nil }; var arg_3263 any = s__78000360__3; if linked_3261 == nil { tmp1 = ifn_3262.Invoke_O__O(arg_3263) } else { tmp1 = linked_3261.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3260, arg_3263) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3264 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3264, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3266 lang.IFn; if linked_3265 == nil { ifn_3266 = lang.IFn_Cast(root_3264) } else { ifn_3266 = nil }; var arg_3267 any = s__78000360__3; if linked_3265 == nil { c__1927001037__auto____4 = ifn_3266.Invoke_O__O(arg_3267) } else { c__1927001037__auto____4 = linked_3265.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3264, arg_3267) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000362__6 any; var root_3268 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3268, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3270 lang.IFn; if linked_3269 == nil { ifn_3270 = lang.IFn_Cast(root_3268) } else { ifn_3270 = nil }; var arg_3271 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3269 == nil { b__78000362__6 = ifn_3270.Invoke_O__O(arg_3271) } else { b__78000362__6 = linked_3269.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3268, arg_3271) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_New_O_O_I_O_O(t.F_tops_QMARK_, t.F_levels, size__1927001038__auto____5, b__78000362__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3420 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_fn_class; if fncls__3420 == nil { var fncls__3420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_fn_class = fncls__3420d; tmp3 = fncls__3420d } else { tmp3 = fncls__3420 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3421 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3421, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3423 lang.IFn; if linked_3422 == nil { ifn_3423 = lang.IFn_Cast(root_3421) } else { ifn_3423 = nil }; var arg_3424 any; var root_3426 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3426, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3428 lang.IFn; if linked_3427 == nil { ifn_3428 = lang.IFn_Cast(root_3426) } else { ifn_3428 = nil }; var arg_3429 any = b__78000362__6; if linked_3427 == nil { arg_3424 = ifn_3428.Invoke_O__O(arg_3429) } else { arg_3424 = linked_3427.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3426, arg_3429) }; var arg_3425 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000359); var tmp5 any; var root_3430 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3430, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3432 lang.IFn; if linked_3431 == nil { ifn_3432 = lang.IFn_Cast(root_3430) } else { ifn_3432 = nil }; var arg_3433 any = s__78000360__3; if linked_3431 == nil { tmp5 = ifn_3432.Invoke_O__O(arg_3433) } else { tmp5 = linked_3431.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3430, arg_3433) }; arg_3425 = tmp4.Invoke_O__O(tmp5); if linked_3422 == nil { return ifn_3423.Invoke_O_O__O(arg_3424, arg_3425) } else { return linked_3422.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3421, arg_3424, arg_3425) } } else { var root_3434 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3434, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3436 lang.IFn; if linked_3435 == nil { ifn_3436 = lang.IFn_Cast(root_3434) } else { ifn_3436 = nil }; var arg_3437 any; var root_3439 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3439, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3441 lang.IFn; if linked_3440 == nil { ifn_3441 = lang.IFn_Cast(root_3439) } else { ifn_3441 = nil }; var arg_3442 any = b__78000362__6; if linked_3440 == nil { arg_3437 = ifn_3441.Invoke_O__O(arg_3442) } else { arg_3437 = linked_3440.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3439, arg_3442) }; var arg_3438 any; if linked_3435 == nil { return ifn_3436.Invoke_O_O__O(arg_3437, arg_3438) } else { return linked_3435.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3434, arg_3437, arg_3438) } } } else { var h__4 any; var root_3443 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3443, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3445 lang.IFn; if linked_3444 == nil { ifn_3445 = lang.IFn_Cast(root_3443) } else { ifn_3445 = nil }; var arg_3446 any = s__78000360__3; if linked_3444 == nil { h__4 = ifn_3445.Invoke_O__O(arg_3446) } else { h__4 = linked_3444.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3443, arg_3446) }; var root_3447 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3447, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3449 lang.IFn; if linked_3448 == nil { ifn_3449 = lang.IFn_Cast(root_3447) } else { ifn_3449 = nil }; var arg_3450 any; var root_3452 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3452, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3454 lang.IFn
															if linked_3453 == nil { ifn_3454 = lang.IFn_Cast(root_3452) } else { ifn_3454 = nil }; var arg_3455 any; var root_3456 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_3457 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3456, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3458 lang.IFn; if linked_3457 == nil { ifn_3458 = lang.IFn_Cast(root_3456) } else { ifn_3458 = nil }; var arg_3459 any; var iter__1927001039__auto____5 any; var tmp6 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_New_O(t.F_tops_QMARK_); var tmp7 *jrt.Class; var fncls__3531 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_fn_class; if fncls__3531 == nil { var fncls__3531d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_fn_class = fncls__3531d; tmp7 = fncls__3531d } else { tmp7 = fncls__3531 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_3459 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(t.F_levels, h__4)); var arg_3460 any; var iter__1927001039__auto____5_2 any; var tmp8 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_New_O(t.F_tops_QMARK_); var tmp9 *jrt.Class; var fncls__3594 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_fn_class
															if fncls__3594 == nil { var fncls__3594d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_fn_class = fncls__3594d; tmp9 = fncls__3594d } else { tmp9 = fncls__3594 }; iter__1927001039__auto____5_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_3460 = lang.IFn_Cast(iter__1927001039__auto____5_2).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(t.F_levels, h__4))
//line :445:1
	if linked_3457 == nil { arg_3455 = ifn_3458.Invoke_O_O__O(arg_3459, arg_3460) } else { arg_3455 = linked_3457.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3456, arg_3459, arg_3460) }; if linked_3453 == nil { arg_3450 = ifn_3454.Invoke_O__O(arg_3455) } else { arg_3450 = linked_3453.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3452, arg_3455) }
//line :444:1
	var arg_3451 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__78000359); var tmp11 any; var root_3595 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3595, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3597 lang.IFn; if linked_3596 == nil { ifn_3597 = lang.IFn_Cast(root_3595) } else { ifn_3597 = nil }; var arg_3598 any = s__78000360__3; if linked_3596 == nil { tmp11 = ifn_3597.Invoke_O__O(arg_3598) } else { tmp11 = linked_3596.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3595, arg_3598) }; arg_3451 = tmp10.Invoke_O__O(tmp11); if linked_3448 == nil { return ifn_3449.Invoke_O_O__O(arg_3450, arg_3451) } else { return linked_3448.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3447, arg_3450, arg_3451) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :444:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A) Ctor_O_O_I_O_O(c__tops_QMARK_, c__levels any, c__size__1927001038__auto__ int32, c__b__78000362, c__c__1927001037__auto__ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_levels = c__levels; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__78000362 = c__b__78000362; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :444:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A) Invoke_O__O(self any) any { { var i__78000361__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000361__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var h__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000361__1)); var root_3272 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3272, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3274 lang.IFn; if linked_3273 == nil { ifn_3274 = lang.IFn_Cast(root_3272) } else { ifn_3274 = nil }; var arg_3275 any = t.F_b__78000362; var arg_3276 any; var root_3277 any = A_arbace_j2g_world_A_const_59.GetRawRoot__O(); var linked_3278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3277, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3279 lang.IFn
																	if linked_3278 == nil { ifn_3279 = lang.IFn_Cast(root_3277) } else { ifn_3279 = nil }; var arg_3280 any; var root_3281 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_3282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3281, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3283 lang.IFn; if linked_3282 == nil { ifn_3283 = lang.IFn_Cast(root_3281) } else { ifn_3283 = nil }; var arg_3284 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_New_O(t.F_tops_QMARK_); var tmp3 *jrt.Class; var fncls__3356 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_fn_class; if fncls__3356 == nil { var fncls__3356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_fn_class = fncls__3356d; tmp3 = fncls__3356d } else { tmp3 = fncls__3356 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_3284 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(t.F_levels, h__2)); var arg_3285 any; var iter__1927001039__auto____3_2 any; var tmp4 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_New_O(t.F_tops_QMARK_); var tmp5 *jrt.Class; var fncls__3419 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_fn_class
																	if fncls__3419 == nil { var fncls__3419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_fn_class = fncls__3419d; tmp5 = fncls__3419d } else { tmp5 = fncls__3419 }; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_3285 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(t.F_levels, h__2))
//line :445:1
	if linked_3282 == nil { arg_3280 = ifn_3283.Invoke_O_O__O(arg_3284, arg_3285) } else { arg_3280 = linked_3282.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3281, arg_3284, arg_3285) }; if linked_3278 == nil { arg_3276 = ifn_3279.Invoke_O__O(arg_3280) } else { arg_3276 = linked_3278.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3277, arg_3280) }
//line :444:1
	if linked_3273 == nil { ifn_3274.Invoke_O_O__O(arg_3275, arg_3276) } else { linked_3273.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3272, arg_3275, arg_3276) }; i__78000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000361__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A{}; t.Ctor_O(p0); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A) Invoke_O_O__O(self, s__78000367__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_New_O_O_O(t.F_tops_QMARK_, s__78000367__1, self); var tmp2 *jrt.Class; var fncls__3355 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_fn_class; if fncls__3355 == nil { var fncls__3355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_fn_class = fncls__3355d; tmp2 = fncls__3355d } else { tmp2 = fncls__3355 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A) Ctor_O_O_O(c__tops_QMARK_, c__s__78000367, c__iter__78000366 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000367 = c__s__78000367; t.F_iter__78000366 = c__iter__78000366 }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A) Invoke_O__O(self any) any { { var s__78000367__1 any; var t_ any = t.F_s__78000367; t.F_s__78000367 = nil; s__78000367__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3286 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3286, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3288 lang.IFn; if linked_3287 == nil { ifn_3288 = lang.IFn_Cast(root_3286) } else { ifn_3288 = nil }; var arg_3289 any = s__78000367__1; if linked_3287 == nil { temp__1927000414__auto____2 = ifn_3288.Invoke_O__O(arg_3289) } else { temp__1927000414__auto____2 = linked_3287.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3286, arg_3289) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000367__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3290 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3290, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3292 lang.IFn; if linked_3291 == nil { ifn_3292 = lang.IFn_Cast(root_3290) } else { ifn_3292 = nil }; var arg_3293 any = s__78000367__3; if linked_3291 == nil { tmp1 = ifn_3292.Invoke_O__O(arg_3293) } else { tmp1 = linked_3291.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3290, arg_3293) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3294 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3294, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3296 lang.IFn; if linked_3295 == nil { ifn_3296 = lang.IFn_Cast(root_3294) } else { ifn_3296 = nil }; var arg_3297 any = s__78000367__3; if linked_3295 == nil { c__1927001037__auto____4 = ifn_3296.Invoke_O__O(arg_3297) } else { c__1927001037__auto____4 = linked_3295.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3294, arg_3297) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000369__6 any; var root_3298 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3298, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3300 lang.IFn; if linked_3299 == nil { ifn_3300 = lang.IFn_Cast(root_3298) } else { ifn_3300 = nil }; var arg_3301 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3299 == nil { b__78000369__6 = ifn_3300.Invoke_O__O(arg_3301) } else { b__78000369__6 = linked_3299.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3298, arg_3301) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_New_O_O_I_O(b__78000369__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3311 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_fn_class; if fncls__3311 == nil { var fncls__3311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_fn_class = fncls__3311d; tmp3 = fncls__3311d } else { tmp3 = fncls__3311 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3312 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3312, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3314 lang.IFn; if linked_3313 == nil { ifn_3314 = lang.IFn_Cast(root_3312) } else { ifn_3314 = nil }; var arg_3315 any; var root_3317 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3317, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3319 lang.IFn; if linked_3318 == nil { ifn_3319 = lang.IFn_Cast(root_3317) } else { ifn_3319 = nil }; var arg_3320 any = b__78000369__6; if linked_3318 == nil { arg_3315 = ifn_3319.Invoke_O__O(arg_3320) } else { arg_3315 = linked_3318.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3317, arg_3320) }; var arg_3316 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000366); var tmp5 any; var root_3321 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3321, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3323 lang.IFn; if linked_3322 == nil { ifn_3323 = lang.IFn_Cast(root_3321) } else { ifn_3323 = nil }; var arg_3324 any = s__78000367__3; if linked_3322 == nil { tmp5 = ifn_3323.Invoke_O__O(arg_3324) } else { tmp5 = linked_3322.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3321, arg_3324) }; arg_3316 = tmp4.Invoke_O__O(tmp5); if linked_3313 == nil { return ifn_3314.Invoke_O_O__O(arg_3315, arg_3316) } else { return linked_3313.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3312, arg_3315, arg_3316) } } else { var root_3325 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3325, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3327 lang.IFn; if linked_3326 == nil { ifn_3327 = lang.IFn_Cast(root_3325) } else { ifn_3327 = nil }; var arg_3328 any; var root_3330 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3330, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3332 lang.IFn; if linked_3331 == nil { ifn_3332 = lang.IFn_Cast(root_3330) } else { ifn_3332 = nil }; var arg_3333 any = b__78000369__6; if linked_3331 == nil { arg_3328 = ifn_3332.Invoke_O__O(arg_3333) } else { arg_3328 = linked_3331.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3330, arg_3333) }; var arg_3329 any; if linked_3326 == nil { return ifn_3327.Invoke_O_O__O(arg_3328, arg_3329) } else { return linked_3326.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3325, arg_3328, arg_3329) } } } else { var n__4 any; var root_3334 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3334, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3336 lang.IFn; if linked_3335 == nil { ifn_3336 = lang.IFn_Cast(root_3334) } else { ifn_3336 = nil }; var arg_3337 any = s__78000367__3; if linked_3335 == nil { n__4 = ifn_3336.Invoke_O__O(arg_3337) } else { n__4 = linked_3335.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3334, arg_3337) }; var tmp6 any; var root_3338 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3338, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3340 lang.IFn; if linked_3339 == nil { ifn_3340 = lang.IFn_Cast(root_3338) } else { ifn_3340 = nil }; var arg_3341 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if linked_3339 == nil { tmp6 = ifn_3340.Invoke_O__O(arg_3341) } else { tmp6 = linked_3339.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3338, arg_3341) }; if jrt.J2g_Truth(tmp6) { var root_3342 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3342, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3344 lang.IFn; if linked_3343 == nil { ifn_3344 = lang.IFn_Cast(root_3342) } else { ifn_3344 = nil }; var arg_3345 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3346 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000366); var tmp8 any; var root_3347 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3347, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3349 lang.IFn; if linked_3348 == nil { ifn_3349 = lang.IFn_Cast(root_3347) } else { ifn_3349 = nil }; var arg_3350 any = s__78000367__3; if linked_3348 == nil { tmp8 = ifn_3349.Invoke_O__O(arg_3350) } else { tmp8 = linked_3348.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3347, arg_3350) }; arg_3346 = tmp7.Invoke_O__O(tmp8); if linked_3343 == nil { return ifn_3344.Invoke_O_O__O(arg_3345, arg_3346) } else { return linked_3343.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3342, arg_3345, arg_3346) } } else { var tmp9 any; var root_3351 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3351, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3353 lang.IFn; if linked_3352 == nil { ifn_3353 = lang.IFn_Cast(root_3351) } else { ifn_3353 = nil }; var arg_3354 any = s__78000367__3; if linked_3352 == nil { tmp9 = ifn_3353.Invoke_O__O(arg_3354) } else { tmp9 = linked_3352.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3351, arg_3354) }; s__78000367__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A) Ctor_O_O_I_O(c__b__78000369, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000369 = c__b__78000369; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A) Invoke_O__O(self any) any { { var i__78000368__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000368__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000368__1)); var tmp2 any; var root_3302 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3302, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3304 lang.IFn; if linked_3303 == nil { ifn_3304 = lang.IFn_Cast(root_3302) } else { ifn_3304 = nil }; var arg_3305 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if linked_3303 == nil { tmp2 = ifn_3304.Invoke_O__O(arg_3305) } else { tmp2 = linked_3303.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3302, arg_3305) }; if jrt.J2g_Truth(tmp2) { var root_3306 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3306, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3308 lang.IFn; if linked_3307 == nil { ifn_3308 = lang.IFn_Cast(root_3306) } else { ifn_3308 = nil }; var arg_3309 any = t.F_b__78000369; var arg_3310 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3307 == nil { ifn_3308.Invoke_O_O__O(arg_3309, arg_3310) } else { linked_3307.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3306, arg_3309, arg_3310) }; i__78000368__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000368__1); continue L1 } else { i__78000368__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000368__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A{}; t.Ctor_O(p0); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A) Invoke_O_O__O(self, s__78000388__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_New_O_O_O(t.F_tops_QMARK_, s__78000388__1, self); var tmp2 *jrt.Class; var fncls__3530 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_fn_class; if fncls__3530 == nil { var fncls__3530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_fn_class = fncls__3530d; tmp2 = fncls__3530d } else { tmp2 = fncls__3530 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A) Ctor_O_O_O(c__tops_QMARK_, c__s__78000388, c__iter__78000387 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000388 = c__s__78000388; t.F_iter__78000387 = c__iter__78000387 }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A) Invoke_O__O(self any) any { { var s__78000388__1 any; var t_ any = t.F_s__78000388; t.F_s__78000388 = nil; s__78000388__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3461 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3463 lang.IFn; if linked_3462 == nil { ifn_3463 = lang.IFn_Cast(root_3461) } else { ifn_3463 = nil }; var arg_3464 any = s__78000388__1; if linked_3462 == nil { temp__1927000414__auto____2 = ifn_3463.Invoke_O__O(arg_3464) } else { temp__1927000414__auto____2 = linked_3462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3461, arg_3464) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000388__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3465 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3465, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3467 lang.IFn; if linked_3466 == nil { ifn_3467 = lang.IFn_Cast(root_3465) } else { ifn_3467 = nil }; var arg_3468 any = s__78000388__3; if linked_3466 == nil { tmp1 = ifn_3467.Invoke_O__O(arg_3468) } else { tmp1 = linked_3466.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3465, arg_3468) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3469 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3469, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3471 lang.IFn; if linked_3470 == nil { ifn_3471 = lang.IFn_Cast(root_3469) } else { ifn_3471 = nil }; var arg_3472 any = s__78000388__3; if linked_3470 == nil { c__1927001037__auto____4 = ifn_3471.Invoke_O__O(arg_3472) } else { c__1927001037__auto____4 = linked_3470.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3469, arg_3472) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000390__6 any; var root_3473 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3473, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3475 lang.IFn; if linked_3474 == nil { ifn_3475 = lang.IFn_Cast(root_3473) } else { ifn_3475 = nil }; var arg_3476 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3474 == nil { b__78000390__6 = ifn_3475.Invoke_O__O(arg_3476) } else { b__78000390__6 = linked_3474.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3473, arg_3476) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_New_O_O_I_O(t.F_tops_QMARK_, b__78000390__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3486 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_fn_class; if fncls__3486 == nil { var fncls__3486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_fn_class = fncls__3486d; tmp3 = fncls__3486d } else { tmp3 = fncls__3486 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3487 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3487, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3489 lang.IFn; if linked_3488 == nil { ifn_3489 = lang.IFn_Cast(root_3487) } else { ifn_3489 = nil }; var arg_3490 any; var root_3492 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3492, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3494 lang.IFn; if linked_3493 == nil { ifn_3494 = lang.IFn_Cast(root_3492) } else { ifn_3494 = nil }; var arg_3495 any = b__78000390__6; if linked_3493 == nil { arg_3490 = ifn_3494.Invoke_O__O(arg_3495) } else { arg_3490 = linked_3493.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3492, arg_3495) }; var arg_3491 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000387); var tmp5 any; var root_3496 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3496, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3498 lang.IFn; if linked_3497 == nil { ifn_3498 = lang.IFn_Cast(root_3496) } else { ifn_3498 = nil }; var arg_3499 any = s__78000388__3; if linked_3497 == nil { tmp5 = ifn_3498.Invoke_O__O(arg_3499) } else { tmp5 = linked_3497.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3496, arg_3499) }; arg_3491 = tmp4.Invoke_O__O(tmp5); if linked_3488 == nil { return ifn_3489.Invoke_O_O__O(arg_3490, arg_3491) } else { return linked_3488.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3487, arg_3490, arg_3491) } } else { var root_3500 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3500, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3502 lang.IFn; if linked_3501 == nil { ifn_3502 = lang.IFn_Cast(root_3500) } else { ifn_3502 = nil }; var arg_3503 any; var root_3505 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3505, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3507 lang.IFn; if linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any = b__78000390__6; if linked_3506 == nil { arg_3503 = ifn_3507.Invoke_O__O(arg_3508) } else { arg_3503 = linked_3506.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3505, arg_3508) }; var arg_3504 any; if linked_3501 == nil { return ifn_3502.Invoke_O_O__O(arg_3503, arg_3504) } else { return linked_3501.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3500, arg_3503, arg_3504) } } } else { var n__4 any; var root_3509 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3509, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3511 lang.IFn; if linked_3510 == nil { ifn_3511 = lang.IFn_Cast(root_3509) } else { ifn_3511 = nil }; var arg_3512 any = s__78000388__3; if linked_3510 == nil { n__4 = ifn_3511.Invoke_O__O(arg_3512) } else { n__4 = linked_3510.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3509, arg_3512) }; var tmp6 any; var root_3513 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3513, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3515 lang.IFn; if linked_3514 == nil { ifn_3515 = lang.IFn_Cast(root_3513) } else { ifn_3515 = nil }; var arg_3516 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if linked_3514 == nil { tmp6 = ifn_3515.Invoke_O__O(arg_3516) } else { tmp6 = linked_3514.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3513, arg_3516) }; if jrt.J2g_Truth(tmp6) { var root_3517 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3517, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3519 lang.IFn; if linked_3518 == nil { ifn_3519 = lang.IFn_Cast(root_3517) } else { ifn_3519 = nil }; var arg_3520 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3521 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000387); var tmp8 any; var root_3522 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3522, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3524 lang.IFn; if linked_3523 == nil { ifn_3524 = lang.IFn_Cast(root_3522) } else { ifn_3524 = nil }; var arg_3525 any = s__78000388__3; if linked_3523 == nil { tmp8 = ifn_3524.Invoke_O__O(arg_3525) } else { tmp8 = linked_3523.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3522, arg_3525) }; arg_3521 = tmp7.Invoke_O__O(tmp8); if linked_3518 == nil { return ifn_3519.Invoke_O_O__O(arg_3520, arg_3521) } else { return linked_3518.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3517, arg_3520, arg_3521) } } else { var tmp9 any; var root_3526 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3526, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3528 lang.IFn; if linked_3527 == nil { ifn_3528 = lang.IFn_Cast(root_3526) } else { ifn_3528 = nil }; var arg_3529 any = s__78000388__3; if linked_3527 == nil { tmp9 = ifn_3528.Invoke_O__O(arg_3529) } else { tmp9 = linked_3527.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3526, arg_3529) }; s__78000388__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :445:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A) Ctor_O_O_I_O(c__tops_QMARK_, c__b__78000390 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_b__78000390 = c__b__78000390; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :445:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A) Invoke_O__O(self any) any { { var i__78000389__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000389__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000389__1)); var tmp2 any; var root_3477 any = A_arbace_j2g_world_A_const_60.GetRawRoot__O(); var linked_3478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3477, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3479 lang.IFn; if linked_3478 == nil { ifn_3479 = lang.IFn_Cast(root_3477) } else { ifn_3479 = nil }; var arg_3480 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if linked_3478 == nil { tmp2 = ifn_3479.Invoke_O__O(arg_3480) } else { tmp2 = linked_3478.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3477, arg_3480) }; if jrt.J2g_Truth(tmp2) { var root_3481 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3481, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3483 lang.IFn; if linked_3482 == nil { ifn_3483 = lang.IFn_Cast(root_3481) } else { ifn_3483 = nil }; var arg_3484 any = t.F_b__78000390; var arg_3485 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3482 == nil { ifn_3483.Invoke_O_O__O(arg_3484, arg_3485) } else { linked_3482.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3481, arg_3484, arg_3485) }; i__78000389__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000389__1); continue L1 } else { i__78000389__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000389__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A{}; t.Ctor_O(p0); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A) Invoke_O_O__O(self, s__78000377__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_New_O_O_O(t.F_tops_QMARK_, s__78000377__1, self); var tmp2 *jrt.Class; var fncls__3418 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_fn_class; if fncls__3418 == nil { var fncls__3418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_fn_class = fncls__3418d; tmp2 = fncls__3418d } else { tmp2 = fncls__3418 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A) Ctor_O_O_O(c__tops_QMARK_, c__s__78000377, c__iter__78000376 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000377 = c__s__78000377; t.F_iter__78000376 = c__iter__78000376 }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A) Invoke_O__O(self any) any { { var s__78000377__1 any; var t_ any = t.F_s__78000377; t.F_s__78000377 = nil; s__78000377__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3357 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3357, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3359 lang.IFn; if linked_3358 == nil { ifn_3359 = lang.IFn_Cast(root_3357) } else { ifn_3359 = nil }; var arg_3360 any = s__78000377__1; if linked_3358 == nil { temp__1927000414__auto____2 = ifn_3359.Invoke_O__O(arg_3360) } else { temp__1927000414__auto____2 = linked_3358.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3357, arg_3360) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000377__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3361 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3361, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3363 lang.IFn; if linked_3362 == nil { ifn_3363 = lang.IFn_Cast(root_3361) } else { ifn_3363 = nil }; var arg_3364 any = s__78000377__3; if linked_3362 == nil { tmp1 = ifn_3363.Invoke_O__O(arg_3364) } else { tmp1 = linked_3362.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3361, arg_3364) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3365 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3365, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3367 lang.IFn; if linked_3366 == nil { ifn_3367 = lang.IFn_Cast(root_3365) } else { ifn_3367 = nil }; var arg_3368 any = s__78000377__3; if linked_3366 == nil { c__1927001037__auto____4 = ifn_3367.Invoke_O__O(arg_3368) } else { c__1927001037__auto____4 = linked_3366.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3365, arg_3368) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000379__6 any; var root_3369 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3369, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3371 lang.IFn; if linked_3370 == nil { ifn_3371 = lang.IFn_Cast(root_3369) } else { ifn_3371 = nil }; var arg_3372 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3370 == nil { b__78000379__6 = ifn_3371.Invoke_O__O(arg_3372) } else { b__78000379__6 = linked_3370.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3369, arg_3372) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_New_O_O_I_O(b__78000379__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3378 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_fn_class; if fncls__3378 == nil { var fncls__3378d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_fn_class = fncls__3378d; tmp3 = fncls__3378d } else { tmp3 = fncls__3378 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3379 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3379, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3381 lang.IFn; if linked_3380 == nil { ifn_3381 = lang.IFn_Cast(root_3379) } else { ifn_3381 = nil }; var arg_3382 any; var root_3384 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3384, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3386 lang.IFn; if linked_3385 == nil { ifn_3386 = lang.IFn_Cast(root_3384) } else { ifn_3386 = nil }; var arg_3387 any = b__78000379__6; if linked_3385 == nil { arg_3382 = ifn_3386.Invoke_O__O(arg_3387) } else { arg_3382 = linked_3385.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3384, arg_3387) }; var arg_3383 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000376); var tmp5 any; var root_3388 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3388, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3390 lang.IFn; if linked_3389 == nil { ifn_3390 = lang.IFn_Cast(root_3388) } else { ifn_3390 = nil }; var arg_3391 any = s__78000377__3; if linked_3389 == nil { tmp5 = ifn_3390.Invoke_O__O(arg_3391) } else { tmp5 = linked_3389.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3388, arg_3391) }; arg_3383 = tmp4.Invoke_O__O(tmp5); if linked_3380 == nil { return ifn_3381.Invoke_O_O__O(arg_3382, arg_3383) } else { return linked_3380.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3379, arg_3382, arg_3383) } } else { var root_3392 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3392, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3394 lang.IFn; if linked_3393 == nil { ifn_3394 = lang.IFn_Cast(root_3392) } else { ifn_3394 = nil }; var arg_3395 any; var root_3397 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3397, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3399 lang.IFn; if linked_3398 == nil { ifn_3399 = lang.IFn_Cast(root_3397) } else { ifn_3399 = nil }; var arg_3400 any = b__78000379__6; if linked_3398 == nil { arg_3395 = ifn_3399.Invoke_O__O(arg_3400) } else { arg_3395 = linked_3398.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3397, arg_3400) }; var arg_3396 any; if linked_3393 == nil { return ifn_3394.Invoke_O_O__O(arg_3395, arg_3396) } else { return linked_3393.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3392, arg_3395, arg_3396) } } } else { var n__4 any; var root_3401 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3401, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3403 lang.IFn; if linked_3402 == nil { ifn_3403 = lang.IFn_Cast(root_3401) } else { ifn_3403 = nil }; var arg_3404 any = s__78000377__3; if linked_3402 == nil { n__4 = ifn_3403.Invoke_O__O(arg_3404) } else { n__4 = linked_3402.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3401, arg_3404) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4)) { var root_3405 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3405, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3407 lang.IFn; if linked_3406 == nil { ifn_3407 = lang.IFn_Cast(root_3405) } else { ifn_3407 = nil }; var arg_3408 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3409 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__78000376); var tmp7 any; var root_3410 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3410, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3412 lang.IFn; if linked_3411 == nil { ifn_3412 = lang.IFn_Cast(root_3410) } else { ifn_3412 = nil }; var arg_3413 any = s__78000377__3; if linked_3411 == nil { tmp7 = ifn_3412.Invoke_O__O(arg_3413) } else { tmp7 = linked_3411.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3410, arg_3413) }; arg_3409 = tmp6.Invoke_O__O(tmp7); if linked_3406 == nil { return ifn_3407.Invoke_O_O__O(arg_3408, arg_3409) } else { return linked_3406.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3405, arg_3408, arg_3409) } } else { var tmp8 any; var root_3414 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3414, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3416 lang.IFn; if linked_3415 == nil { ifn_3416 = lang.IFn_Cast(root_3414) } else { ifn_3416 = nil }; var arg_3417 any = s__78000377__3; if linked_3415 == nil { tmp8 = ifn_3416.Invoke_O__O(arg_3417) } else { tmp8 = linked_3415.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3414, arg_3417) }; s__78000377__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A) Ctor_O_O_I_O(c__b__78000379, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000379 = c__b__78000379; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A) Invoke_O__O(self any) any { { var i__78000378__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000378__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000378__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2)) { var root_3373 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3373, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3375 lang.IFn; if linked_3374 == nil { ifn_3375 = lang.IFn_Cast(root_3373) } else { ifn_3375 = nil }; var arg_3376 any = t.F_b__78000379; var arg_3377 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3374 == nil { ifn_3375.Invoke_O_O__O(arg_3376, arg_3377) } else { linked_3374.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3373, arg_3376, arg_3377) }; i__78000378__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000378__1); continue L1 } else { i__78000378__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000378__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_New_O(p0 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A{}; t.Ctor_O(p0); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A) Invoke_O_O__O(self, s__78000398__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_New_O_O_O(t.F_tops_QMARK_, s__78000398__1, self); var tmp2 *jrt.Class; var fncls__3593 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_fn_class; if fncls__3593 == nil { var fncls__3593d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_fn_class = fncls__3593d; tmp2 = fncls__3593d } else { tmp2 = fncls__3593 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A) Ctor_O_O_O(c__tops_QMARK_, c__s__78000398, c__iter__78000397 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__78000398 = c__s__78000398; t.F_iter__78000397 = c__iter__78000397 }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A) Invoke_O__O(self any) any { { var s__78000398__1 any; var t_ any = t.F_s__78000398; t.F_s__78000398 = nil; s__78000398__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3532 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3532, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3534 lang.IFn; if linked_3533 == nil { ifn_3534 = lang.IFn_Cast(root_3532) } else { ifn_3534 = nil }; var arg_3535 any = s__78000398__1; if linked_3533 == nil { temp__1927000414__auto____2 = ifn_3534.Invoke_O__O(arg_3535) } else { temp__1927000414__auto____2 = linked_3533.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3532, arg_3535) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000398__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3536 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3536, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3538 lang.IFn; if linked_3537 == nil { ifn_3538 = lang.IFn_Cast(root_3536) } else { ifn_3538 = nil }; var arg_3539 any = s__78000398__3; if linked_3537 == nil { tmp1 = ifn_3538.Invoke_O__O(arg_3539) } else { tmp1 = linked_3537.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3536, arg_3539) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3540 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3540, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3542 lang.IFn; if linked_3541 == nil { ifn_3542 = lang.IFn_Cast(root_3540) } else { ifn_3542 = nil }; var arg_3543 any = s__78000398__3; if linked_3541 == nil { c__1927001037__auto____4 = ifn_3542.Invoke_O__O(arg_3543) } else { c__1927001037__auto____4 = linked_3541.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3540, arg_3543) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000400__6 any; var root_3544 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3544, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3546 lang.IFn; if linked_3545 == nil { ifn_3546 = lang.IFn_Cast(root_3544) } else { ifn_3546 = nil }; var arg_3547 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3545 == nil { b__78000400__6 = ifn_3546.Invoke_O__O(arg_3547) } else { b__78000400__6 = linked_3545.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3544, arg_3547) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_New_O_O_I_O(b__78000400__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3553 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_fn_class; if fncls__3553 == nil { var fncls__3553d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_fn_class = fncls__3553d; tmp3 = fncls__3553d } else { tmp3 = fncls__3553 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3554 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3554, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3556 lang.IFn; if linked_3555 == nil { ifn_3556 = lang.IFn_Cast(root_3554) } else { ifn_3556 = nil }; var arg_3557 any; var root_3559 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3559, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3561 lang.IFn; if linked_3560 == nil { ifn_3561 = lang.IFn_Cast(root_3559) } else { ifn_3561 = nil }; var arg_3562 any = b__78000400__6; if linked_3560 == nil { arg_3557 = ifn_3561.Invoke_O__O(arg_3562) } else { arg_3557 = linked_3560.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3559, arg_3562) }; var arg_3558 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000397); var tmp5 any; var root_3563 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3563, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3565 lang.IFn; if linked_3564 == nil { ifn_3565 = lang.IFn_Cast(root_3563) } else { ifn_3565 = nil }; var arg_3566 any = s__78000398__3; if linked_3564 == nil { tmp5 = ifn_3565.Invoke_O__O(arg_3566) } else { tmp5 = linked_3564.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3563, arg_3566) }; arg_3558 = tmp4.Invoke_O__O(tmp5); if linked_3555 == nil { return ifn_3556.Invoke_O_O__O(arg_3557, arg_3558) } else { return linked_3555.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3554, arg_3557, arg_3558) } } else { var root_3567 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3567, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3569 lang.IFn; if linked_3568 == nil { ifn_3569 = lang.IFn_Cast(root_3567) } else { ifn_3569 = nil }; var arg_3570 any; var root_3572 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3572, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3574 lang.IFn; if linked_3573 == nil { ifn_3574 = lang.IFn_Cast(root_3572) } else { ifn_3574 = nil }; var arg_3575 any = b__78000400__6; if linked_3573 == nil { arg_3570 = ifn_3574.Invoke_O__O(arg_3575) } else { arg_3570 = linked_3573.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3572, arg_3575) }; var arg_3571 any; if linked_3568 == nil { return ifn_3569.Invoke_O_O__O(arg_3570, arg_3571) } else { return linked_3568.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3567, arg_3570, arg_3571) } } } else { var n__4 any; var root_3576 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3576, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3578 lang.IFn; if linked_3577 == nil { ifn_3578 = lang.IFn_Cast(root_3576) } else { ifn_3578 = nil }; var arg_3579 any = s__78000398__3; if linked_3577 == nil { n__4 = ifn_3578.Invoke_O__O(arg_3579) } else { n__4 = linked_3577.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3576, arg_3579) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4)) { var root_3580 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3580, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3582 lang.IFn; if linked_3581 == nil { ifn_3582 = lang.IFn_Cast(root_3580) } else { ifn_3582 = nil }; var arg_3583 any = lang.Tuple_Create_O__IPersistentVector(n__4); var arg_3584 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__78000397); var tmp7 any; var root_3585 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3585, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3587 lang.IFn; if linked_3586 == nil { ifn_3587 = lang.IFn_Cast(root_3585) } else { ifn_3587 = nil }; var arg_3588 any = s__78000398__3; if linked_3586 == nil { tmp7 = ifn_3587.Invoke_O__O(arg_3588) } else { tmp7 = linked_3586.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3585, arg_3588) }; arg_3584 = tmp6.Invoke_O__O(tmp7); if linked_3581 == nil { return ifn_3582.Invoke_O_O__O(arg_3583, arg_3584) } else { return linked_3581.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3580, arg_3583, arg_3584) } } else { var tmp8 any; var root_3589 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3589, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3591 lang.IFn; if linked_3590 == nil { ifn_3591 = lang.IFn_Cast(root_3589) } else { ifn_3591 = nil }; var arg_3592 any = s__78000398__3; if linked_3590 == nil { tmp8 = ifn_3591.Invoke_O__O(arg_3592) } else { tmp8 = linked_3590.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3589, arg_3592) }; s__78000398__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :446:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A) Ctor_O_O_I_O(c__b__78000400, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000400 = c__b__78000400; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :446:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A) Invoke_O__O(self any) any { { var i__78000399__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000399__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000399__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2)) { var root_3548 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3548, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3550 lang.IFn; if linked_3549 == nil { ifn_3550 = lang.IFn_Cast(root_3548) } else { ifn_3550 = nil }; var arg_3551 any = t.F_b__78000400; var arg_3552 any = lang.Tuple_Create_O__IPersistentVector(n__2); if linked_3549 == nil { ifn_3550.Invoke_O_O__O(arg_3551, arg_3552) } else { linked_3549.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3548, arg_3551, arg_3552) }; i__78000399__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000399__1); continue L1 } else { i__78000399__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000399__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A{}; t.Ctor_O_O(p0, p1); return t }
//line :456:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A) Ctor_O_O(c__space, c__prev any) { t.F_space = c__space; t.F_prev = c__prev }
//line :456:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_j2g_world_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_218); return nil }(); if
												jrt.J2g_Truth(t.F_space) { if jrt.J2g_Truth(t.F_prev) { var tmp3 any; var t_ any = t.F_space; t.F_space = nil; tmp3 = t_; var tmp4 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(tmp3); var tmp5 any; var t__2 any = t.F_prev; t.F_prev = nil; tmp5 = t__2; tmp4.Set_O__V(tmp5) } else { var tmp6 any; var t__3 any = t.F_space; t.F_space = nil; tmp6 = t__3; jrt.ThreadLocal_Cast(tmp6).Remove__V() } }; if /*line :456:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }











func A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :468:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A) Ctor_O_O_O(c__space, c__analyze_BANG_, c__unit any) { t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit }
//line :468:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A) Invoke_O_O__O(self, g__1 any) any { var s__2 int64 = jrt.System_NanoTime__J(); var order__3 any; var root_3823 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_3824 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3823, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3825 lang.IFn; if

	linked_3824 == nil { ifn_3825 = lang.IFn_Cast(root_3823) } else { ifn_3825 = nil }; var arg_3826 any = lang.PersistentVector_EMPTY.Ref(); if linked_3824 == nil { order__3 = ifn_3825.Invoke_O__O(arg_3826) } else { order__3 = linked_3824.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3823, arg_3826) }; var tmp1 jrt.ThreadLocal_I =
	jrt.ThreadLocal_Cast(t.F_space); tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_j2g_world_A_const_214.GetRawRoot__O()))); var tmp2 any =
	A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_New_O_O_O_O_O(g__1, t.F_space, order__3, t.F_analyze_BANG_, t.F_unit); var tmp3 *jrt.Class; var fncls__3850 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_fn_class; if fncls__3850 == nil { var fncls__3850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_fn_class = fncls__3850d; tmp3 = fncls__3850d } else { tmp3 = fncls__3850 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); var tmp4 any; var root_3851 any = /*line :468:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3851, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3853 lang.IFn; if





	linked_3852 == nil { ifn_3853 = lang.IFn_Cast(root_3851) } else { ifn_3853 = nil }; var arg_3854 any = g__1; if linked_3852 == nil { tmp4 = ifn_3853.Invoke_O__O(arg_3854) } else { tmp4 = linked_3852.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3851, arg_3854) }; var tmp5 any = tmp4; var tmp6 any = /*line :468:1*/jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), s__2), 1.0e9)).Ref(); var tmp7 any; var root_3855 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_3856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3855, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3857 lang.IFn; if
	linked_3856 == nil { ifn_3857 = lang.IFn_Cast(root_3855) } else { ifn_3857 = nil }; var arg_3858 any = order__3; if linked_3856 == nil { tmp7 = ifn_3857.Invoke_O__O(arg_3858) } else { tmp7 = linked_3856.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3855, arg_3858) }; return /*line :468:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) }
//line :468:1
func A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :468:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A) Ctor_O_O_O(c__space, c__analyze_BANG_, c__unit any) { t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit }
//line :468:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A) Invoke_O_O__O(self, g__1 any) any { var s__2 int64 = jrt.System_NanoTime__J(); var order__3 any; var root_3969 any = A_arbace_j2g_world_A_const_56.GetRawRoot__O(); var linked_3970 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3969, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3971 lang.IFn; if

	linked_3970 == nil { ifn_3971 = lang.IFn_Cast(root_3969) } else { ifn_3971 = nil }; var arg_3972 any = lang.PersistentVector_EMPTY.Ref(); if linked_3970 == nil { order__3 = ifn_3971.Invoke_O__O(arg_3972) } else { order__3 = linked_3970.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3969, arg_3972) }; var tmp1 jrt.ThreadLocal_I =
	jrt.ThreadLocal_Cast(t.F_space); tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_j2g_world_A_const_214.GetRawRoot__O()))); var tmp2 any =
	A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_New_O_O_O_O_O(g__1, t.F_space, order__3, t.F_analyze_BANG_, t.F_unit); var tmp3 *jrt.Class; var fncls__3996 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_fn_class; if fncls__3996 == nil { var fncls__3996d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_fn_class = fncls__3996d; tmp3 = fncls__3996d } else { tmp3 = fncls__3996 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); var tmp4 any; var root_3997 any = /*line :468:1*/A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3997, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3999 lang.IFn; if





	linked_3998 == nil { ifn_3999 = lang.IFn_Cast(root_3997) } else { ifn_3999 = nil }; var arg_4000 any = g__1; if linked_3998 == nil { tmp4 = ifn_3999.Invoke_O__O(arg_4000) } else { tmp4 = linked_3998.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3997, arg_4000) }; var tmp5 any = tmp4; var tmp6 any = /*line :468:1*/jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), s__2), 1.0e9)).Ref(); var tmp7 any; var root_4001 any = A_arbace_j2g_world_A_const_12.GetRawRoot__O(); var linked_4002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4001, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4003 lang.IFn; if
	linked_4002 == nil { ifn_4003 = lang.IFn_Cast(root_4001) } else { ifn_4003 = nil }; var arg_4004 any = order__3; if linked_4002 == nil { tmp7 = ifn_4003.Invoke_O__O(arg_4004) } else { tmp7 = linked_4002.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4001, arg_4004) }; return /*line :468:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) }



func A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :472:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A) Ctor_O_O_O_O_O(c__g, c__space, c__order, c__analyze_BANG_, c__unit any) { t.F_g = c__g; t.F_space = c__space; t.F_order = c__order; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit }
//line :472:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3835 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_3836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3835, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3837 lang.IFn; if linked_3836 == nil { ifn_3837 = lang.IFn_Cast(root_3835) } else { ifn_3837 = nil }; var arg_3838 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_world_A_const_209; var tmp4 any; var root_3844 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_3845 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3844, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3846 lang.IFn; if linked_3845 == nil { ifn_3846 = lang.IFn_Cast(root_3844) } else { ifn_3846 = nil }; var arg_3847 any; var t_ any = t.F_unit; t.F_unit = nil; arg_3847 = t_; var arg_3848 any = A_arbace_j2g_world_A_const_133; var arg_3849 any; var t__2 any = t.F_order; t.F_order = nil; arg_3849 = t__2; if linked_3845 == nil { tmp4 = ifn_3846.Invoke_O_O_O__O(arg_3847, arg_3848, arg_3849) } else { tmp4 = linked_3845.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3844, arg_3847, arg_3848, arg_3849) }; arg_3838 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_3836 == nil { ifn_3837.Invoke_O__O(arg_3838) } else { linked_3836.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3835, arg_3838) }; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3827 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_3828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3827, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3829 lang.IFn; if linked_3828 == nil { ifn_3829 = lang.IFn_Cast(root_3827) } else { ifn_3829 = nil }; var arg_3830 any; var t__3 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; arg_3830 = t__3; var arg_3831 any; var t__4 any = t.F_g; t.F_g = nil; arg_3831 = t__4; if linked_3828 == nil { tmp1 = ifn_3829.Invoke_O_O__O(arg_3830, arg_3831) } else { tmp1 = linked_3828.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3827, arg_3830, arg_3831) } }; return nil }(); var root_3832 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_3833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3832, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3834 lang.IFn; if linked_3833 == nil { ifn_3834 = lang.IFn_Cast(root_3832) } else { ifn_3834 = nil }; if linked_3833 == nil { ifn_3834.Invoke__O() } else { linked_3833.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3832) }; if tmp5 != nil { panic(tmp5) } }; return nil }(); var tmp7 any; var t__5 any = t.F_space;
														t.F_space = nil; tmp7 = t__5; jrt.ThreadLocal_Cast(tmp7).Remove__V(); if /*line :472:1*/ tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :472:1
func A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :472:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A) Ctor_O_O_O_O_O(c__g, c__space, c__order, c__analyze_BANG_, c__unit any) { t.F_g = c__g; t.F_space = c__space; t.F_order = c__order; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit }
//line :472:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3981 any = A_arbace_j2g_world_A_const_25.GetRawRoot__O(); var linked_3982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3981, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3983 lang.IFn; if linked_3982 == nil { ifn_3983 = lang.IFn_Cast(root_3981) } else { ifn_3983 = nil }; var arg_3984 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_26.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_world_A_const_209; var tmp4 any; var root_3990 any = A_arbace_j2g_world_A_const_118.GetRawRoot__O(); var linked_3991 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3990, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3992 lang.IFn; if linked_3991 == nil { ifn_3992 = lang.IFn_Cast(root_3990) } else { ifn_3992 = nil }; var arg_3993 any; var t_ any = t.F_unit; t.F_unit = nil; arg_3993 = t_; var arg_3994 any = A_arbace_j2g_world_A_const_133; var arg_3995 any; var t__2 any = t.F_order; t.F_order = nil; arg_3995 = t__2; if linked_3991 == nil { tmp4 = ifn_3992.Invoke_O_O_O__O(arg_3993, arg_3994, arg_3995) } else { tmp4 = linked_3991.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3990, arg_3993, arg_3994, arg_3995) }; arg_3984 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_3982 == nil { ifn_3983.Invoke_O__O(arg_3984) } else { linked_3982.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3981, arg_3984) }; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3973 any = A_arbace_j2g_world_A_const_208.GetRawRoot__O(); var linked_3974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3973, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3975 lang.IFn; if linked_3974 == nil { ifn_3975 = lang.IFn_Cast(root_3973) } else { ifn_3975 = nil }; var arg_3976 any; var t__3 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; arg_3976 = t__3; var arg_3977 any; var t__4 any = t.F_g; t.F_g = nil; arg_3977 = t__4; if linked_3974 == nil { tmp1 = ifn_3975.Invoke_O_O__O(arg_3976, arg_3977) } else { tmp1 = linked_3974.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3973, arg_3976, arg_3977) } }; return nil }(); var root_3978 any = A_arbace_j2g_world_A_const_24.GetRawRoot__O(); var linked_3979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3978, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3980 lang.IFn; if linked_3979 == nil { ifn_3980 = lang.IFn_Cast(root_3978) } else { ifn_3980 = nil }; if linked_3979 == nil { ifn_3980.Invoke__O() } else { linked_3979.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3978) }; if tmp5 != nil { panic(tmp5) } }; return nil }(); var tmp7 any; var t__5 any = t.F_space;
														t.F_space = nil; tmp7 = t__5; jrt.ThreadLocal_Cast(tmp7).Remove__V(); if /*line :472:1*/ tmp6 != nil { panic(tmp6) }; return tmp1 }



func A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_New() *A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A) Ctor() {}
//line :476:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A) Invoke_O_O__O(self, p1__78000224_SHARP___1 any) any { return lang.RT_Nth_O_I__O_NoInit(p1__78000224_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)) }
//line :476:1
func A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_New() *A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A) Ctor() {}
//line :476:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A) Invoke_O_O__O(self, p1__78000224_SHARP___1 any) any { return lang.RT_Nth_O_I__O_NoInit(p1__78000224_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)) }


















func A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_New() *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A) Ctor() {}
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A) Invoke_O_O__O(self, s__78000451__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_New_O_O(s__78000451__1, self); var tmp2 *jrt.Class; var fncls__3675 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_fn_class; if fncls__3675 == nil { var fncls__3675d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_fn_class = fncls__3675d; tmp2 = fncls__3675d } else { tmp2 = fncls__3675 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :495:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A{}; t.Ctor_O_O(p0, p1); return t }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A) Ctor_O_O(c__s__78000451, c__iter__78000450 any) { t.F_s__78000451 = c__s__78000451; t.F_iter__78000450 = c__iter__78000450 }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A) Invoke_O__O(self any) any { { var s__78000451__1 any; var t_ any = t.F_s__78000451; t.F_s__78000451 = nil; s__78000451__1 = t_; for { var temp__1927000414__auto____2 any; var root_3610 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_3611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3610, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3612 lang.IFn; if linked_3611 == nil { ifn_3612 = lang.IFn_Cast(root_3610) } else { ifn_3612 = nil }; var arg_3613 any = s__78000451__1; if linked_3611 == nil { temp__1927000414__auto____2 = ifn_3612.Invoke_O__O(arg_3613) } else { temp__1927000414__auto____2 = linked_3611.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3610, arg_3613) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000451__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3614 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_3615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3614, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3616 lang.IFn; if linked_3615 == nil { ifn_3616 = lang.IFn_Cast(root_3614) } else { ifn_3616 = nil }; var arg_3617 any = s__78000451__3; if linked_3615 == nil { tmp1 = ifn_3616.Invoke_O__O(arg_3617) } else { tmp1 = linked_3615.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3614, arg_3617) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3618 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_3619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3618, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3620 lang.IFn; if linked_3619 == nil { ifn_3620 = lang.IFn_Cast(root_3618) } else { ifn_3620 = nil }; var arg_3621 any = s__78000451__3; if linked_3619 == nil { c__1927001037__auto____4 = ifn_3620.Invoke_O__O(arg_3621) } else { c__1927001037__auto____4 = linked_3619.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3618, arg_3621) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000453__6 any; var root_3622 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_3623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3622, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3624 lang.IFn; if linked_3623 == nil { ifn_3624 = lang.IFn_Cast(root_3622) } else { ifn_3624 = nil }; var arg_3625 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3623 == nil { b__78000453__6 = ifn_3624.Invoke_O__O(arg_3625) } else { b__78000453__6 = linked_3623.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3622, arg_3625) }; var tmp2 any = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__78000453__6); var tmp3 *jrt.Class; var fncls__3635 *jrt.Class = A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_fn_class; if fncls__3635 == nil { var fncls__3635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_fn_class = fncls__3635d; tmp3 = fncls__3635d } else { tmp3 = fncls__3635 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3636 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3636, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3638 lang.IFn; if linked_3637 == nil { ifn_3638 = lang.IFn_Cast(root_3636) } else { ifn_3638 = nil }; var arg_3639 any; var root_3641 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3641, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3643 lang.IFn; if linked_3642 == nil { ifn_3643 = lang.IFn_Cast(root_3641) } else { ifn_3643 = nil }; var arg_3644 any = b__78000453__6; if linked_3642 == nil { arg_3639 = ifn_3643.Invoke_O__O(arg_3644) } else { arg_3639 = linked_3642.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3641, arg_3644) }; var arg_3640 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000450); var tmp5 any; var root_3645 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_3646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3645, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3647 lang.IFn; if linked_3646 == nil { ifn_3647 = lang.IFn_Cast(root_3645) } else { ifn_3647 = nil }; var arg_3648 any = s__78000451__3; if linked_3646 == nil { tmp5 = ifn_3647.Invoke_O__O(arg_3648) } else { tmp5 = linked_3646.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3645, arg_3648) }; arg_3640 = tmp4.Invoke_O__O(tmp5); if linked_3637 == nil { return ifn_3638.Invoke_O_O__O(arg_3639, arg_3640) } else { return linked_3637.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3636, arg_3639, arg_3640) } } else { var root_3649 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_3650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3649, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3651 lang.IFn; if linked_3650 == nil { ifn_3651 = lang.IFn_Cast(root_3649) } else { ifn_3651 = nil }; var arg_3652 any; var root_3654 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_3655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3654, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3656 lang.IFn; if linked_3655 == nil { ifn_3656 = lang.IFn_Cast(root_3654) } else { ifn_3656 = nil }; var arg_3657 any = b__78000453__6; if linked_3655 == nil { arg_3652 = ifn_3656.Invoke_O__O(arg_3657) } else { arg_3652 = linked_3655.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3654, arg_3657) }; var arg_3653 any; if linked_3650 == nil { return ifn_3651.Invoke_O_O__O(arg_3652, arg_3653) } else { return linked_3650.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3649, arg_3652, arg_3653) } } } else { var vec__78000461__4 any; var root_3658 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_3659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3658, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3660 lang.IFn; if linked_3659 == nil { ifn_3660 = lang.IFn_Cast(root_3658) } else { ifn_3660 = nil }; var arg_3661 any = s__78000451__3; if linked_3659 == nil { vec__78000461__4 = ifn_3660.Invoke_O__O(arg_3661) } else { vec__78000461__4 = linked_3659.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3658, arg_3661) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000461__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000461__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3662 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_3663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3662, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3664 lang.IFn; if linked_3663 == nil { ifn_3664 = lang.IFn_Cast(root_3662) } else { ifn_3664 = nil }; var arg_3665 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil); var tmp7 any; var root_3667 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_3668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3667, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3669 lang.IFn; if linked_3668 == nil { ifn_3669 = lang.IFn_Cast(root_3667) } else { ifn_3669 = nil }; var arg_3670 any = k__5; if linked_3668 == nil { tmp7 = ifn_3669.Invoke_O__O(arg_3670) } else { tmp7 = linked_3668.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3667, arg_3670) }; arg_3665 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, v__6)).Ref(); var arg_3666 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000450); var tmp9 any; var root_3671 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_3672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3671, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3673 lang.IFn; if linked_3672 == nil { ifn_3673 = lang.IFn_Cast(root_3671) } else { ifn_3673 = nil }; var arg_3674 any = s__78000451__3; if linked_3672 == nil { tmp9 = ifn_3673.Invoke_O__O(arg_3674) } else { tmp9 = linked_3672.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3671, arg_3674) }; arg_3666 = tmp8.Invoke_O__O(tmp9); if linked_3663 == nil { return ifn_3664.Invoke_O_O__O(arg_3665, arg_3666) } else { return linked_3663.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3662, arg_3665, arg_3666) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :495:1
func A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__78000453 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__78000453 = c__b__78000453 }
//line :495:1
func (t *A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A) Invoke_O__O(self any) any { { var i__78000452__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000452__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__78000457__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000452__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000457__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__78000457__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3626 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_3627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3626, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3628 lang.IFn; if linked_3627 == nil { ifn_3628 = lang.IFn_Cast(root_3626) } else { ifn_3628 = nil }; var arg_3629 any = t.F_b__78000453; var arg_3630 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil); var tmp3 any; var root_3631 any = A_arbace_j2g_world_A_const_32.GetRawRoot__O(); var linked_3632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3631, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3633 lang.IFn; if linked_3632 == nil { ifn_3633 = lang.IFn_Cast(root_3631) } else { ifn_3633 = nil }; var arg_3634 any = k__3; if linked_3632 == nil { tmp3 = ifn_3633.Invoke_O__O(arg_3634) } else { tmp3 = linked_3632.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3631, arg_3634) }; arg_3630 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, v__4)).Ref(); if linked_3627 == nil { ifn_3628.Invoke_O_O__O(arg_3629, arg_3630) } else { linked_3627.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3626, arg_3629, arg_3630) }; i__78000452__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000452__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_world_load_world_iter__78000471__78000477_A_New() *A_arbace_j2g_world_load_world_iter__78000471__78000477_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_A) Ctor() {}
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_A) Invoke_O_O__O(self, s__78000472__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_New_O_O(s__78000472__1, self); var tmp2 *jrt.Class; var fncls__2415 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_fn_class; if fncls__2415 == nil { var fncls__2415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_fn_class = fncls__2415d; tmp2 = fncls__2415d } else { tmp2 = fncls__2415 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :500:1
func A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_New_O_O(p0, p1 any) *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A{}; t.Ctor_O_O(p0, p1); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A) Ctor_O_O(c__s__78000472, c__iter__78000471 any) { t.F_s__78000472 = c__s__78000472; t.F_iter__78000471 = c__iter__78000471 }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A) Invoke_O__O(self any) any { { var s__78000472__1 any; var t_ any = t.F_s__78000472; t.F_s__78000472 = nil; s__78000472__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2298 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2298, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2300 lang.IFn; if linked_2299 == nil { ifn_2300 = lang.IFn_Cast(root_2298) } else { ifn_2300 = nil }; var arg_2301 any = s__78000472__1; if linked_2299 == nil { temp__1927000414__auto____2 = ifn_2300.Invoke_O__O(arg_2301) } else { temp__1927000414__auto____2 = linked_2299.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2298, arg_2301) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__78000479__4 any; var root_2302 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2302, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2304 lang.IFn; if linked_2303 == nil { ifn_2304 = lang.IFn_Cast(root_2302) } else { ifn_2304 = nil }; var arg_2305 any = xs__1927001018__auto____3; if linked_2303 == nil { map__78000479__4 = ifn_2304.Invoke_O__O(arg_2305) } else { map__78000479__4 = linked_2303.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2302, arg_2305) }; var map__78000479__5 any; if lang.ISeq_InstanceOf(map__78000479__4) { var tmp1 any; var root_2306 any = A_arbace_j2g_world_A_const_48.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = map__78000479__4; if linked_2307 == nil { tmp1 = ifn_2308.Invoke_O__O(arg_2309) } else { tmp1 = linked_2307.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2306, arg_2309) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2310 any = A_arbace_j2g_world_A_const_49.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2310, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2312 lang.IFn; if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any = map__78000479__4; if linked_2311 == nil { tmp2 = ifn_2312.Invoke_O__O(arg_2313) } else { tmp2 = linked_2311.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2310, arg_2313) }; map__78000479__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2314 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2316 lang.IFn; if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = map__78000479__4; if linked_2315 == nil { tmp3 = ifn_2316.Invoke_O__O(arg_2317) } else { tmp3 = linked_2315.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2314, arg_2317) }; if jrt.J2g_Truth(tmp3) { var root_2318 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = map__78000479__4; if linked_2319 == nil { map__78000479__5 = ifn_2320.Invoke_O__O(arg_2321) } else { map__78000479__5 = linked_2319.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2318, arg_2321) } } else { map__78000479__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__78000479__5 = map__78000479__4 }; var file__6 any = lang.RT_Get_O_O__O_NoInit(map__78000479__5, A_arbace_j2g_world_A_const_168); var ns__7 any = lang.RT_Get_O_O__O_NoInit(map__78000479__5, A_arbace_j2g_world_A_const_143); var forms__8 any = lang.RT_Get_O_O__O_NoInit(map__78000479__5, A_arbace_j2g_world_A_const_50); if jrt.J2g_Truth(ns__7) { var iterys__1927001035__auto____9 any; var tmp4 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_New_O(file__6); var tmp5 *jrt.Class; var fncls__2388 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_fn_class; if fncls__2388 == nil { var fncls__2388d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_fn_class = fncls__2388d; tmp5 = fncls__2388d } else { tmp5 = fncls__2388 }; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____10 any; var root_2389 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____9); var tmp7 any; var root_2393 any = A_arbace_j2g_world_A_const_169.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, A_arbace_j2g_world_top_names_A_fn_class); var ifn_2395 lang.IFn
														if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = ns__7; var arg_2397 any = forms__8; if linked_2394 == nil { tmp7 = ifn_2395.Invoke_O_O__O(arg_2396, arg_2397) } else { tmp7 = linked_2394.(*A_arbace_j2g_world_top_names_A).Invoke_O_O_O__O(root_2393, arg_2396, arg_2397) }
//line :500:1
	arg_2392 = tmp6.Invoke_O__O(tmp7); if linked_2390 == nil { fs__1927001036__auto____10 = ifn_2391.Invoke_O__O(arg_2392) } else { fs__1927001036__auto____10 = linked_2390.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2389, arg_2392) }; if jrt.J2g_Truth(fs__1927001036__auto____10) { var root_2398 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2398, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2400 lang.IFn; if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any = fs__1927001036__auto____10; var arg_2402 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__78000471); var tmp9 any; var root_2403 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = s__78000472__1; if linked_2404 == nil { tmp9 = ifn_2405.Invoke_O__O(arg_2406) } else { tmp9 = linked_2404.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2403, arg_2406) }; arg_2402 = tmp8.Invoke_O__O(tmp9); if linked_2399 == nil { return ifn_2400.Invoke_O_O__O(arg_2401, arg_2402) } else { return linked_2399.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2398, arg_2401, arg_2402) } } else { var tmp10 any; var root_2407 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = s__78000472__1; if linked_2408 == nil { tmp10 = ifn_2409.Invoke_O__O(arg_2410) } else { tmp10 = linked_2408.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2407, arg_2410) }; s__78000472__1 = tmp10; continue L1 } } else { var tmp11 any; var root_2411 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = s__78000472__1; if linked_2412 == nil { tmp11 = ifn_2413.Invoke_O__O(arg_2414) } else { tmp11 = linked_2412.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2411, arg_2414) }; s__78000472__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :500:1
func A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_New_O(p0 any) *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A{}; t.Ctor_O(p0); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A) Ctor_O(c__file any) { t.F_file = c__file }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A) Invoke_O_O__O(self, s__78000474__1 any) any { var tmp1 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_New_O_O_O(s__78000474__1, t.F_file, self); var tmp2 *jrt.Class; var fncls__2387 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_fn_class; if fncls__2387 == nil { var fncls__2387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_fn_class = fncls__2387d; tmp2 = fncls__2387d } else { tmp2 = fncls__2387 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :500:1
func A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A) Ctor_O_O_O(c__s__78000474, c__file, c__iter__78000473 any) { t.F_s__78000474 = c__s__78000474; t.F_file = c__file; t.F_iter__78000473 = c__iter__78000473 }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A) Invoke_O__O(self any) any { { var s__78000474__1 any; var t_ any = t.F_s__78000474; t.F_s__78000474 = nil; s__78000474__1 = t_; for { var temp__1927000414__auto____2 any; var root_2322 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2324 lang.IFn; if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any = s__78000474__1; if linked_2323 == nil { temp__1927000414__auto____2 = ifn_2324.Invoke_O__O(arg_2325) } else { temp__1927000414__auto____2 = linked_2323.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2322, arg_2325) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__78000474__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2326 any = A_arbace_j2g_world_A_const_34.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = s__78000474__3; if linked_2327 == nil { tmp1 = ifn_2328.Invoke_O__O(arg_2329) } else { tmp1 = linked_2327.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2326, arg_2329) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2330 any = A_arbace_j2g_world_A_const_35.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = s__78000474__3; if linked_2331 == nil { c__1927001037__auto____4 = ifn_2332.Invoke_O__O(arg_2333) } else { c__1927001037__auto____4 = linked_2331.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2330, arg_2333) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__78000476__6 any; var root_2334 any = A_arbace_j2g_world_A_const_36.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2335 == nil { b__78000476__6 = ifn_2336.Invoke_O__O(arg_2337) } else { b__78000476__6 = linked_2335.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2334, arg_2337) }; var tmp2 any = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_New_O_O_I_O(b__78000476__6, t.F_file, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2347 *jrt.Class = A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_fn_class; if fncls__2347 == nil { var fncls__2347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_fn_class = fncls__2347d; tmp3 = fncls__2347d } else { tmp3 = fncls__2347 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2348 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any; var root_2353 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_2354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2353, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2355 lang.IFn; if linked_2354 == nil { ifn_2355 = lang.IFn_Cast(root_2353) } else { ifn_2355 = nil }; var arg_2356 any = b__78000476__6; if linked_2354 == nil { arg_2351 = ifn_2355.Invoke_O__O(arg_2356) } else { arg_2351 = linked_2354.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2353, arg_2356) }; var arg_2352 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__78000473); var tmp5 any; var root_2357 any = A_arbace_j2g_world_A_const_41.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2359 lang.IFn; if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = s__78000474__3; if linked_2358 == nil { tmp5 = ifn_2359.Invoke_O__O(arg_2360) } else { tmp5 = linked_2358.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2357, arg_2360) }; arg_2352 = tmp4.Invoke_O__O(tmp5); if linked_2349 == nil { return ifn_2350.Invoke_O_O__O(arg_2351, arg_2352) } else { return linked_2349.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2348, arg_2351, arg_2352) } } else { var root_2361 any = A_arbace_j2g_world_A_const_39.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any; var root_2366 any = A_arbace_j2g_world_A_const_40.GetRawRoot__O(); var linked_2367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2366, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2368 lang.IFn; if linked_2367 == nil { ifn_2368 = lang.IFn_Cast(root_2366) } else { ifn_2368 = nil }; var arg_2369 any = b__78000476__6; if linked_2367 == nil { arg_2364 = ifn_2368.Invoke_O__O(arg_2369) } else { arg_2364 = linked_2367.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2366, arg_2369) }; var arg_2365 any; if linked_2362 == nil { return ifn_2363.Invoke_O_O__O(arg_2364, arg_2365) } else { return linked_2362.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2361, arg_2364, arg_2365) } } } else { var n__4 any; var root_2370 any = A_arbace_j2g_world_A_const_31.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2372 lang.IFn; if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any = s__78000474__3; if linked_2371 == nil { n__4 = ifn_2372.Invoke_O__O(arg_2373) } else { n__4 = linked_2371.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2370, arg_2373) }; var root_2374 any = A_arbace_j2g_world_A_const_42.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2376 lang.IFn; if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any; var tmp6 any; var root_2379 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2379, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2381 lang.IFn

	if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = t.F_file; if linked_2380 == nil { tmp6 = ifn_2381.Invoke_O__O(arg_2382) } else { tmp6 = linked_2380.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2379, arg_2382) }
//line :500:1
	arg_2377 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp6); var arg_2378 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__78000473); var tmp8 any; var root_2383 any = A_arbace_j2g_world_A_const_43.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2385 lang.IFn; if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any = s__78000474__3; if linked_2384 == nil { tmp8 = ifn_2385.Invoke_O__O(arg_2386) } else { tmp8 = linked_2384.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2383, arg_2386) }; arg_2378 = tmp7.Invoke_O__O(tmp8); if linked_2375 == nil { return ifn_2376.Invoke_O_O__O(arg_2377, arg_2378) } else { return linked_2375.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2374, arg_2377, arg_2378) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :500:1
func A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A) Ctor_O_O_I_O(c__b__78000476, c__file any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__78000476 = c__b__78000476; t.F_file = c__file; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :500:1
func (t *A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A) Invoke_O__O(self any) any { { var i__78000475__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__78000475__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__78000475__1)); var root_2338 any = A_arbace_j2g_world_A_const_38.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2340 lang.IFn; if linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = t.F_b__78000476; var arg_2342 any; var tmp2 any; var root_2343 any = A_arbace_j2g_world_A_const_54.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2345 lang.IFn

	if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = t.F_file; if linked_2344 == nil { tmp2 = ifn_2345.Invoke_O__O(arg_2346) } else { tmp2 = linked_2344.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2343, arg_2346) }
//line :500:1
	arg_2342 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp2); if linked_2339 == nil { ifn_2340.Invoke_O_O__O(arg_2341, arg_2342) } else { linked_2339.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2338, arg_2341, arg_2342) }; i__78000475__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__78000475__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_world_with_world_A_New() *A_arbace_j2g_world_with_world_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_with_world_A{}; t.Ctor(); return t }
//line :505:1
func (t *A_arbace_j2g_world_with_world_A) Ctor() {}
//line :505:1
func (t *A_arbace_j2g_world_with_world_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, w__2, body__3 any) any { var root_4198 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4198, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4200 lang.IFn; if linked_4199 == nil { ifn_4200 = lang.IFn_Cast(root_4198) } else { ifn_4200 = nil }; var arg_4201 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_229); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp4 any; var root_4208 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_4209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4208, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_4210 lang.IFn; if linked_4209 == nil { ifn_4210 = lang.IFn_Cast(root_4208) } else { ifn_4210 = nil }; var arg_4211 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var arg_4212 any; var root_4213 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4213, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4215 lang.IFn; if linked_4214 == nil { ifn_4215 = lang.IFn_Cast(root_4213) } else { ifn_4215 = nil }; var arg_4216 any; var root_4217 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_4218 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4217, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4219 lang.IFn; if linked_4218 == nil { ifn_4219 = lang.IFn_Cast(root_4217) } else { ifn_4219 = nil }; var arg_4220 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_230); var arg_4221 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(w__2); if linked_4218 == nil { arg_4216 = ifn_4219.Invoke_O_O__O(arg_4220, arg_4221) } else { arg_4216 = linked_4218.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4217, arg_4220, arg_4221) }; if linked_4214 == nil { arg_4212 = ifn_4215.Invoke_O__O(arg_4216) } else { arg_4212 = linked_4214.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4213, arg_4216) }; if linked_4209 == nil { tmp4 = ifn_4210.Invoke_O_O__O(arg_4211, arg_4212) } else { tmp4 = linked_4209.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_4208, arg_4211, arg_4212) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp7 any; var root_4222 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4224 lang.IFn; if linked_4223 == nil { ifn_4224 = lang.IFn_Cast(root_4222) } else { ifn_4224 = nil }; var arg_4225 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_231); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp11 any; var root_4232 any = A_arbace_j2g_world_A_const_68.GetRawRoot__O(); var linked_4233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4232, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_4234 lang.IFn; if linked_4233 == nil { ifn_4234 = lang.IFn_Cast(root_4232) } else { ifn_4234 = nil }; var arg_4235 any = A_arbace_j2g_world_A_const_64.GetRawRoot__O(); var arg_4236 any; var root_4237 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4237, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4239 lang.IFn; if linked_4238 == nil { ifn_4239 = lang.IFn_Cast(root_4237) } else { ifn_4239 = nil }; var arg_4240 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_45.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_232); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp15 any; var root_4250 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4252 lang.IFn; if linked_4251 == nil { ifn_4252 = lang.IFn_Cast(root_4250) } else { ifn_4252 = nil }; var arg_4253 any; var root_4254 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_4255 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4254, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4256 lang.IFn; if linked_4255 == nil { ifn_4256 = lang.IFn_Cast(root_4254) } else { ifn_4256 = nil }; var arg_4257 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_172); var arg_4258 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_230); if linked_4255 == nil { arg_4253 = ifn_4256.Invoke_O_O__O(arg_4257, arg_4258) } else { arg_4253 = linked_4255.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4254, arg_4257, arg_4258) }; if linked_4251 == nil { tmp15 = ifn_4252.Invoke_O__O(arg_4253) } else { tmp15 = linked_4251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4250, arg_4253) }; var tmp16 any = tmp14.Invoke_O__O(tmp15); var tmp17 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_233); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp19 any; var root_4259 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4259, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4261 lang.IFn; if linked_4260 == nil { ifn_4261 = lang.IFn_Cast(root_4259) } else { ifn_4261 = nil }; var arg_4262 any; var root_4263 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_4264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4263, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4265 lang.IFn; if linked_4264 == nil { ifn_4265 = lang.IFn_Cast(root_4263) } else { ifn_4265 = nil }; var arg_4266 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_173); var arg_4267 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_230); if linked_4264 == nil { arg_4262 = ifn_4265.Invoke_O_O__O(arg_4266, arg_4267) } else { arg_4262 = linked_4264.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4263, arg_4266, arg_4267) }; if linked_4260 == nil { tmp19 = ifn_4261.Invoke_O__O(arg_4262) } else { tmp19 = linked_4260.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4259, arg_4262) }; var tmp20 any = tmp18.Invoke_O__O(tmp19); var tmp21 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_234); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()); var tmp23 any; var root_4268 any = A_arbace_j2g_world_A_const_33.GetRawRoot__O(); var linked_4269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4268, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4270 lang.IFn; if linked_4269 == nil { ifn_4270 = lang.IFn_Cast(root_4268) } else { ifn_4270 = nil }; var arg_4271 any; var root_4272 any = A_arbace_j2g_world_A_const_45.GetRawRoot__O(); var linked_4273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4272, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4274 lang.IFn; if linked_4273 == nil { ifn_4274 = lang.IFn_Cast(root_4272) } else { ifn_4274 = nil }; var arg_4275 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_174); var arg_4276 any = lang.IFn_Cast(A_arbace_j2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_world_A_const_230); if linked_4273 == nil { arg_4271 = ifn_4274.Invoke_O_O__O(arg_4275, arg_4276) } else { arg_4271 = linked_4273.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4272, arg_4275, arg_4276) }; if linked_4269 == nil { tmp23 = ifn_4270.Invoke_O__O(arg_4271) } else { tmp23 = linked_4269.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4268, arg_4271) }; arg_4240 = tmp12.Invoke_O_O_O_O_O_O__O(tmp13, tmp16, tmp17, tmp20, tmp21, tmp22.Invoke_O__O(tmp23)); if linked_4238 == nil { arg_4236 = ifn_4239.Invoke_O__O(arg_4240) } else { arg_4236 = linked_4238.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4237, arg_4240) }; if linked_4233 == nil { tmp11 = ifn_4234.Invoke_O_O__O(arg_4235, arg_4236) } else { tmp11 = linked_4233.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_4232, arg_4235, arg_4236) }; arg_4225 = tmp8.Invoke_O_O_O__O(tmp9, tmp10.Invoke_O__O(tmp11), body__3); if linked_4223 == nil { tmp7 = ifn_4224.Invoke_O__O(arg_4225) } else { tmp7 = linked_4223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4222, arg_4225) }; arg_4201 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_4199 == nil { return ifn_4200.Invoke_O__O(arg_4201) } else { return linked_4199.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4198, arg_4201) } }





























































































































































































































































































































































type A_arbace_j2g_world_A struct{ jrt.Object }

var A_arbace_j2g_world_A_const_pool *jrt.RefArray

var A_arbace_j2g_world_A_const_0 *lang.Var

var A_arbace_j2g_world_A_const_1 any

var A_arbace_j2g_world_A_const_2 *lang.Var

var A_arbace_j2g_world_A_const_3 any

var A_arbace_j2g_world_A_const_4 any

var A_arbace_j2g_world_A_const_5 any

var A_arbace_j2g_world_A_const_6 any

var A_arbace_j2g_world_A_const_7 any

var A_arbace_j2g_world_A_const_8 any

var A_arbace_j2g_world_A_const_9 any

var A_arbace_j2g_world_A_const_10 any

var A_arbace_j2g_world_A_const_11 *lang.Var

var A_arbace_j2g_world_A_const_12 *lang.Var

var A_arbace_j2g_world_A_const_13 *lang.Var

var A_arbace_j2g_world_A_const_14 *lang.Var

var A_arbace_j2g_world_A_const_15 any

var A_arbace_j2g_world_A_const_16 *lang.Var

var A_arbace_j2g_world_A_const_17 *lang.Var

var A_arbace_j2g_world_A_const_18 *lang.Var

var A_arbace_j2g_world_A_const_19 *lang.Var

var A_arbace_j2g_world_A_const_20 *lang.Keyword

var A_arbace_j2g_world_A_const_21 *lang.Var

var A_arbace_j2g_world_A_const_22 *lang.Var

var A_arbace_j2g_world_A_const_23 any

var A_arbace_j2g_world_A_const_24 *lang.Var

var A_arbace_j2g_world_A_const_25 *lang.Var

var A_arbace_j2g_world_A_const_26 *lang.Var

var A_arbace_j2g_world_A_const_27 *lang.Var

var A_arbace_j2g_world_A_const_28 any

var A_arbace_j2g_world_A_const_29 *lang.Var

var A_arbace_j2g_world_A_const_30 *lang.Var

var A_arbace_j2g_world_A_const_31 *lang.Var

var A_arbace_j2g_world_A_const_32 *lang.Var

var A_arbace_j2g_world_A_const_33 *lang.Var

var A_arbace_j2g_world_A_const_34 *lang.Var

var A_arbace_j2g_world_A_const_35 *lang.Var

var A_arbace_j2g_world_A_const_36 *lang.Var

var A_arbace_j2g_world_A_const_37 *lang.Var

var A_arbace_j2g_world_A_const_38 *lang.Var

var A_arbace_j2g_world_A_const_39 *lang.Var

var A_arbace_j2g_world_A_const_40 *lang.Var

var A_arbace_j2g_world_A_const_41 *lang.Var

var A_arbace_j2g_world_A_const_42 *lang.Var

var A_arbace_j2g_world_A_const_43 *lang.Var

var A_arbace_j2g_world_A_const_44 any

var A_arbace_j2g_world_A_const_45 *lang.Var

var A_arbace_j2g_world_A_const_46 any

var A_arbace_j2g_world_A_const_47 *lang.Var

var A_arbace_j2g_world_A_const_48 *lang.Var

var A_arbace_j2g_world_A_const_49 *lang.Var

var A_arbace_j2g_world_A_const_50 *lang.Keyword

var A_arbace_j2g_world_A_const_51 *lang.Var

var A_arbace_j2g_world_A_const_52 *lang.Var

var A_arbace_j2g_world_A_const_53 any

var A_arbace_j2g_world_A_const_54 *lang.Var

var A_arbace_j2g_world_A_const_55 *lang.Var

var A_arbace_j2g_world_A_const_56 *lang.Var

var A_arbace_j2g_world_A_const_57 *lang.Var

var A_arbace_j2g_world_A_const_58 *lang.Var

var A_arbace_j2g_world_A_const_59 *lang.Var

var A_arbace_j2g_world_A_const_60 *lang.Var

var A_arbace_j2g_world_A_const_61 *lang.Keyword

var A_arbace_j2g_world_A_const_62 *lang.Var

var A_arbace_j2g_world_A_const_63 *lang.Var

var A_arbace_j2g_world_A_const_64 *lang.Var

var A_arbace_j2g_world_A_const_65 *lang.Var

var A_arbace_j2g_world_A_const_66 any

var A_arbace_j2g_world_A_const_67 *lang.Var

var A_arbace_j2g_world_A_const_68 *lang.Var

var A_arbace_j2g_world_A_const_69 *lang.Var

var A_arbace_j2g_world_A_const_70 *lang.Var

var A_arbace_j2g_world_A_const_71 *lang.Var

var A_arbace_j2g_world_A_const_72 *lang.Var

var A_arbace_j2g_world_A_const_73 *lang.Var

var A_arbace_j2g_world_A_const_74 *lang.Var

var A_arbace_j2g_world_A_const_75 *lang.Var

var A_arbace_j2g_world_A_const_76 *lang.Keyword

var A_arbace_j2g_world_A_const_77 *lang.Var

var A_arbace_j2g_world_A_const_78 *lang.Var

var A_arbace_j2g_world_A_const_79 *lang.Var

var A_arbace_j2g_world_A_const_80 *lang.Var

var A_arbace_j2g_world_A_const_81 *lang.Var

var A_arbace_j2g_world_A_const_82 *lang.Var

var A_arbace_j2g_world_A_const_83 *lang.Keyword

var A_arbace_j2g_world_A_const_84 *lang.Var

var A_arbace_j2g_world_A_const_85 *lang.Var

var A_arbace_j2g_world_A_const_86 *lang.Var

var A_arbace_j2g_world_A_const_87 *lang.Var

var A_arbace_j2g_world_A_const_88 *lang.Keyword

var A_arbace_j2g_world_A_const_89 *lang.Var

var A_arbace_j2g_world_A_const_90 *lang.Var

var A_arbace_j2g_world_A_const_91 *lang.Keyword

var A_arbace_j2g_world_A_const_92 *lang.Keyword

var A_arbace_j2g_world_A_const_93 *lang.Keyword

var A_arbace_j2g_world_A_const_94 *lang.Keyword

var A_arbace_j2g_world_A_const_95 *lang.Var

var A_arbace_j2g_world_A_const_96 *lang.Var

var A_arbace_j2g_world_A_const_97 *lang.Var

var A_arbace_j2g_world_A_const_98 any

var A_arbace_j2g_world_A_const_99 *lang.Var

var A_arbace_j2g_world_A_const_100 *lang.Var

var A_arbace_j2g_world_A_const_101 *lang.Var

var A_arbace_j2g_world_A_const_102 *lang.Keyword

var A_arbace_j2g_world_A_const_103 any

var A_arbace_j2g_world_A_const_104 *lang.Keyword

var A_arbace_j2g_world_A_const_105 *lang.Keyword

var A_arbace_j2g_world_A_const_106 *lang.Keyword

var A_arbace_j2g_world_A_const_107 *lang.Keyword

var A_arbace_j2g_world_A_const_108 *lang.Keyword

var A_arbace_j2g_world_A_const_109 *lang.Keyword

var A_arbace_j2g_world_A_const_110 *lang.Keyword

var A_arbace_j2g_world_A_const_111 any

var A_arbace_j2g_world_A_const_112 *lang.Var

var A_arbace_j2g_world_A_const_113 any

var A_arbace_j2g_world_A_const_114 *lang.Var

var A_arbace_j2g_world_A_const_115 *lang.Var

var A_arbace_j2g_world_A_const_116 any

var A_arbace_j2g_world_A_const_117 *lang.Var

var A_arbace_j2g_world_A_const_118 *lang.Var

var A_arbace_j2g_world_A_const_119 *lang.Var

var A_arbace_j2g_world_A_const_120 any

var A_arbace_j2g_world_A_const_121 *lang.Var

var A_arbace_j2g_world_A_const_122 *lang.Var

var A_arbace_j2g_world_A_const_123 *lang.Var

var A_arbace_j2g_world_A_const_124 *lang.Var

var A_arbace_j2g_world_A_const_125 *lang.Keyword

var A_arbace_j2g_world_A_const_126 *lang.Keyword

var A_arbace_j2g_world_A_const_127 *lang.Keyword

var A_arbace_j2g_world_A_const_128 *lang.Var

var A_arbace_j2g_world_A_const_129 *lang.Var

var A_arbace_j2g_world_A_const_130 *lang.Var

var A_arbace_j2g_world_A_const_131 *lang.Var

var A_arbace_j2g_world_A_const_132 *lang.Keyword

var A_arbace_j2g_world_A_const_133 *lang.Keyword

var A_arbace_j2g_world_A_const_134 *lang.Keyword

var A_arbace_j2g_world_A_const_135 *lang.Keyword

var A_arbace_j2g_world_A_const_136 *lang.Keyword

var A_arbace_j2g_world_A_const_137 *lang.Keyword

var A_arbace_j2g_world_A_const_138 *lang.Keyword

var A_arbace_j2g_world_A_const_139 *lang.Keyword

var A_arbace_j2g_world_A_const_140 *jrt.Class

var A_arbace_j2g_world_A_const_141 *lang.Keyword

var A_arbace_j2g_world_A_const_142 *lang.Var

var A_arbace_j2g_world_A_const_143 *lang.Keyword

var A_arbace_j2g_world_A_const_144 *lang.Keyword

var A_arbace_j2g_world_A_const_145 *lang.Keyword

var A_arbace_j2g_world_A_const_146 *lang.Keyword

var A_arbace_j2g_world_A_const_147 *lang.Keyword

var A_arbace_j2g_world_A_const_148 *lang.Keyword

var A_arbace_j2g_world_A_const_149 *lang.Keyword

var A_arbace_j2g_world_A_const_150 *lang.Var

var A_arbace_j2g_world_A_const_151 *lang.Var

var A_arbace_j2g_world_A_const_152 *lang.Var

var A_arbace_j2g_world_A_const_153 *lang.Var

var A_arbace_j2g_world_A_const_154 *lang.Var

var A_arbace_j2g_world_A_const_155 *lang.Var

var A_arbace_j2g_world_A_const_156 *lang.Var

var A_arbace_j2g_world_A_const_157 *lang.Keyword

var A_arbace_j2g_world_A_const_158 *lang.Keyword

var A_arbace_j2g_world_A_const_159 *lang.Var

var A_arbace_j2g_world_A_const_160 *lang.Var

var A_arbace_j2g_world_A_const_161 *lang.Var

var A_arbace_j2g_world_A_const_162 *lang.Keyword

var A_arbace_j2g_world_A_const_163 *lang.Keyword

var A_arbace_j2g_world_A_const_164 *lang.Keyword

var A_arbace_j2g_world_A_const_165 *lang.Var

var A_arbace_j2g_world_A_const_166 *lang.Var

var A_arbace_j2g_world_A_const_167 *lang.Var

var A_arbace_j2g_world_A_const_168 *lang.Keyword

var A_arbace_j2g_world_A_const_169 *lang.Var

var A_arbace_j2g_world_A_const_170 *lang.Var

var A_arbace_j2g_world_A_const_171 *lang.Var

var A_arbace_j2g_world_A_const_172 *lang.Keyword

var A_arbace_j2g_world_A_const_173 *lang.Keyword

var A_arbace_j2g_world_A_const_174 *lang.Keyword

var A_arbace_j2g_world_A_const_175 *lang.Keyword

var A_arbace_j2g_world_A_const_176 *lang.Keyword

var A_arbace_j2g_world_A_const_177 *lang.Keyword

var A_arbace_j2g_world_A_const_178 *lang.Var

var A_arbace_j2g_world_A_const_179 *lang.Keyword

var A_arbace_j2g_world_A_const_180 *lang.Keyword

var A_arbace_j2g_world_A_const_181 *lang.Var

var A_arbace_j2g_world_A_const_182 *lang.Var

var A_arbace_j2g_world_A_const_183 any

var A_arbace_j2g_world_A_const_184 any

var A_arbace_j2g_world_A_const_185 *lang.Var

var A_arbace_j2g_world_A_const_186 *lang.Keyword

var A_arbace_j2g_world_A_const_187 *lang.Keyword

var A_arbace_j2g_world_A_const_188 *lang.Keyword

var A_arbace_j2g_world_A_const_189 *lang.Keyword

var A_arbace_j2g_world_A_const_190 *lang.Var

var A_arbace_j2g_world_A_const_191 *lang.Var

var A_arbace_j2g_world_A_const_192 *lang.Keyword

var A_arbace_j2g_world_A_const_193 *lang.Var

var A_arbace_j2g_world_A_const_194 *lang.Keyword

var A_arbace_j2g_world_A_const_195 *lang.Var

var A_arbace_j2g_world_A_const_196 *lang.Var

var A_arbace_j2g_world_A_const_197 *lang.Var

var A_arbace_j2g_world_A_const_198 *lang.Var

var A_arbace_j2g_world_A_const_199 *lang.Keyword

var A_arbace_j2g_world_A_const_200 *lang.Keyword

var A_arbace_j2g_world_A_const_201 *lang.Keyword

var A_arbace_j2g_world_A_const_202 *lang.Var

var A_arbace_j2g_world_A_const_203 *lang.Var

var A_arbace_j2g_world_A_const_204 *lang.Keyword

var A_arbace_j2g_world_A_const_205 *lang.Keyword

var A_arbace_j2g_world_A_const_206 *lang.Var

var A_arbace_j2g_world_A_const_207 *lang.Var

var A_arbace_j2g_world_A_const_208 *lang.Var

var A_arbace_j2g_world_A_const_209 *lang.Var

var A_arbace_j2g_world_A_const_210 *lang.Var

var A_arbace_j2g_world_A_const_211 *lang.Keyword

var A_arbace_j2g_world_A_const_212 *lang.Var

var A_arbace_j2g_world_A_const_213 *lang.Var

var A_arbace_j2g_world_A_const_214 *lang.Var

var A_arbace_j2g_world_A_const_215 *lang.Keyword

var A_arbace_j2g_world_A_const_216 *lang.Keyword

var A_arbace_j2g_world_A_const_217 *lang.Var

var A_arbace_j2g_world_A_const_218 any

var A_arbace_j2g_world_A_const_219 *lang.Var

var A_arbace_j2g_world_A_const_220 any

var A_arbace_j2g_world_A_const_221 *lang.Var

var A_arbace_j2g_world_A_const_222 *lang.Var

var A_arbace_j2g_world_A_const_223 *lang.Var

var A_arbace_j2g_world_A_const_224 *lang.Var

var A_arbace_j2g_world_A_const_225 *lang.Keyword

var A_arbace_j2g_world_A_const_226 *lang.Keyword

var A_arbace_j2g_world_A_const_227 *lang.Var

var A_arbace_j2g_world_A_const_228 *lang.Var

var A_arbace_j2g_world_A_const_229 any

var A_arbace_j2g_world_A_const_230 any

var A_arbace_j2g_world_A_const_231 any

var A_arbace_j2g_world_A_const_232 any

var A_arbace_j2g_world_A_const_233 any

var A_arbace_j2g_world_A_const_234 any

var A_arbace_j2g_world_A_init jrt.ClassInit

func A_arbace_j2g_world_A_Init() { if !A_arbace_j2g_world_A_init.Done() { A_arbace_j2g_world_A_init.Run(A_arbace_j2g_world_A_clinit) } }

func A_arbace_j2g_world_A_clinit() { A_arbace_j2g_world_A_clinit_p0(); A_arbace_j2g_world_A_clinit_p1(); A_arbace_j2g_world_A_clinit_p2(); A_arbace_j2g_world_A_clinit_p3(); A_arbace_j2g_world_A_clinit_p4(); A_arbace_j2g_world_A_clinit_p5(); A_arbace_j2g_world_A_clinit_p6(); A_arbace_j2g_world_A_clinit_p7(); A_arbace_j2g_world_A_clinit_p8(); A_arbace_j2g_world_A_clinit_p9(); A_arbace_j2g_world_A_clinit_p10(); A_arbace_j2g_world_A_clinit_p11(); A_arbace_j2g_world_A_clinit_p12(); A_arbace_j2g_world_A_clinit_p13(); A_arbace_j2g_world_A_clinit_p14(); A_arbace_j2g_world_A_clinit_p15(); A_arbace_j2g_world_A_clinit_p16(); A_arbace_j2g_world_A_clinit_p17(); A_arbace_j2g_world_A_clinit_p18(); A_arbace_j2g_world_A_clinit_p19() }

func A_arbace_j2g_world_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_world_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 335); A_arbace_j2g_world_A_const_0 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[100]); A_arbace_j2g_world_A_const_1 = A_arbace_j2g_world_A_const_pool.A[101]; A_arbace_j2g_world_A_const_2 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[102]); A_arbace_j2g_world_A_const_3 = A_arbace_j2g_world_A_const_pool.A[103]; A_arbace_j2g_world_A_const_4 = A_arbace_j2g_world_A_const_pool.A[104]; A_arbace_j2g_world_A_const_5 = A_arbace_j2g_world_A_const_pool.A[105]; A_arbace_j2g_world_A_const_6 = A_arbace_j2g_world_A_const_pool.A[106]; A_arbace_j2g_world_A_const_7 = A_arbace_j2g_world_A_const_pool.A[107]; A_arbace_j2g_world_A_const_8 = A_arbace_j2g_world_A_const_pool.A[108]; A_arbace_j2g_world_A_const_9 = A_arbace_j2g_world_A_const_pool.A[109]; A_arbace_j2g_world_A_const_10 = A_arbace_j2g_world_A_const_pool.A[110]; A_arbace_j2g_world_A_const_11 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[111]); A_arbace_j2g_world_A_const_12 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[112]) }

func A_arbace_j2g_world_A_clinit_p1() { A_arbace_j2g_world_A_const_13 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[113]); A_arbace_j2g_world_A_const_14 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[114]); A_arbace_j2g_world_A_const_15 = A_arbace_j2g_world_A_const_pool.A[115]; A_arbace_j2g_world_A_const_16 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[116]); A_arbace_j2g_world_A_const_17 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[117]); A_arbace_j2g_world_A_const_18 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[118]); A_arbace_j2g_world_A_const_19 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[119]); A_arbace_j2g_world_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[120]); A_arbace_j2g_world_A_const_21 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[121]); A_arbace_j2g_world_A_const_22 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[122]); A_arbace_j2g_world_A_const_23 = A_arbace_j2g_world_A_const_pool.A[123]; A_arbace_j2g_world_A_const_24 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[124]) }

func A_arbace_j2g_world_A_clinit_p2() { A_arbace_j2g_world_A_const_25 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[125]); A_arbace_j2g_world_A_const_26 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[126]); A_arbace_j2g_world_A_const_27 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[127]); A_arbace_j2g_world_A_const_28 = A_arbace_j2g_world_A_const_pool.A[128]; A_arbace_j2g_world_A_const_29 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[129]); A_arbace_j2g_world_A_const_30 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[130]); A_arbace_j2g_world_A_const_31 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[131]); A_arbace_j2g_world_A_const_32 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[132]); A_arbace_j2g_world_A_const_33 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[133]); A_arbace_j2g_world_A_const_34 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[134]); A_arbace_j2g_world_A_const_35 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[135]); A_arbace_j2g_world_A_const_36 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[136]) }

func A_arbace_j2g_world_A_clinit_p3() { A_arbace_j2g_world_A_const_37 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[137]); A_arbace_j2g_world_A_const_38 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[138]); A_arbace_j2g_world_A_const_39 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[139]); A_arbace_j2g_world_A_const_40 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[140]); A_arbace_j2g_world_A_const_41 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[141]); A_arbace_j2g_world_A_const_42 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[142]); A_arbace_j2g_world_A_const_43 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[143]); A_arbace_j2g_world_A_const_44 = A_arbace_j2g_world_A_const_pool.A[144]; A_arbace_j2g_world_A_const_45 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[145]); A_arbace_j2g_world_A_const_46 = A_arbace_j2g_world_A_const_pool.A[146]; A_arbace_j2g_world_A_const_47 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[147]); A_arbace_j2g_world_A_const_48 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[148]) }

func A_arbace_j2g_world_A_clinit_p4() { A_arbace_j2g_world_A_const_49 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[149]); A_arbace_j2g_world_A_const_50 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[150]); A_arbace_j2g_world_A_const_51 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[151]); A_arbace_j2g_world_A_const_52 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[152]); A_arbace_j2g_world_A_const_53 = A_arbace_j2g_world_A_const_pool.A[153]; A_arbace_j2g_world_A_const_54 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[154]); A_arbace_j2g_world_A_const_55 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[155]); A_arbace_j2g_world_A_const_56 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[156]); A_arbace_j2g_world_A_const_57 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[157]); A_arbace_j2g_world_A_const_58 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[158]); A_arbace_j2g_world_A_const_59 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[159]); A_arbace_j2g_world_A_const_60 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[160]) }

func A_arbace_j2g_world_A_clinit_p5() { A_arbace_j2g_world_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[161]); A_arbace_j2g_world_A_const_62 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[162]); A_arbace_j2g_world_A_const_63 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[163]); A_arbace_j2g_world_A_const_64 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[164]); A_arbace_j2g_world_A_const_65 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[165]); A_arbace_j2g_world_A_const_66 = A_arbace_j2g_world_A_const_pool.A[166]; A_arbace_j2g_world_A_const_67 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[167]); A_arbace_j2g_world_A_const_68 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[168]); A_arbace_j2g_world_A_const_69 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[169]); A_arbace_j2g_world_A_const_70 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[170]); A_arbace_j2g_world_A_const_71 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[171]); A_arbace_j2g_world_A_const_72 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[172]) }

func A_arbace_j2g_world_A_clinit_p6() { A_arbace_j2g_world_A_const_73 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[173]); A_arbace_j2g_world_A_const_74 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[174]); A_arbace_j2g_world_A_const_75 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[175]); A_arbace_j2g_world_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[176]); A_arbace_j2g_world_A_const_77 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[177]); A_arbace_j2g_world_A_const_78 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[178]); A_arbace_j2g_world_A_const_79 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[179]); A_arbace_j2g_world_A_const_80 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[180]); A_arbace_j2g_world_A_const_81 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[181]); A_arbace_j2g_world_A_const_82 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[182]); A_arbace_j2g_world_A_const_83 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[183]); A_arbace_j2g_world_A_const_84 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[184]) }

func A_arbace_j2g_world_A_clinit_p7() { A_arbace_j2g_world_A_const_85 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[185]); A_arbace_j2g_world_A_const_86 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[186]); A_arbace_j2g_world_A_const_87 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[187]); A_arbace_j2g_world_A_const_88 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[188]); A_arbace_j2g_world_A_const_89 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[189]); A_arbace_j2g_world_A_const_90 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[190]); A_arbace_j2g_world_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[191]); A_arbace_j2g_world_A_const_92 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[192]); A_arbace_j2g_world_A_const_93 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[193]); A_arbace_j2g_world_A_const_94 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[194]); A_arbace_j2g_world_A_const_95 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[195]); A_arbace_j2g_world_A_const_96 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[196]) }

func A_arbace_j2g_world_A_clinit_p8() { A_arbace_j2g_world_A_const_97 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[197]); A_arbace_j2g_world_A_const_98 = A_arbace_j2g_world_A_const_pool.A[198]; A_arbace_j2g_world_A_const_99 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[199]); A_arbace_j2g_world_A_const_100 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[200]); A_arbace_j2g_world_A_const_101 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[201]); A_arbace_j2g_world_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[202]); A_arbace_j2g_world_A_const_103 = A_arbace_j2g_world_A_const_pool.A[203]; A_arbace_j2g_world_A_const_104 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[204]); A_arbace_j2g_world_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[205]); A_arbace_j2g_world_A_const_106 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[206]); A_arbace_j2g_world_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[207]); A_arbace_j2g_world_A_const_108 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[208]) }

func A_arbace_j2g_world_A_clinit_p9() { A_arbace_j2g_world_A_const_109 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[209]); A_arbace_j2g_world_A_const_110 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[210]); A_arbace_j2g_world_A_const_111 = A_arbace_j2g_world_A_const_pool.A[211]; A_arbace_j2g_world_A_const_112 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[212]); A_arbace_j2g_world_A_const_113 = A_arbace_j2g_world_A_const_pool.A[213]; A_arbace_j2g_world_A_const_114 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[214]); A_arbace_j2g_world_A_const_115 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[215]); A_arbace_j2g_world_A_const_116 = A_arbace_j2g_world_A_const_pool.A[216]; A_arbace_j2g_world_A_const_117 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[217]); A_arbace_j2g_world_A_const_118 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[218]); A_arbace_j2g_world_A_const_119 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[219]); A_arbace_j2g_world_A_const_120 = A_arbace_j2g_world_A_const_pool.A[220]; A_arbace_j2g_world_A_const_121 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[221]) }

func A_arbace_j2g_world_A_clinit_p10() { A_arbace_j2g_world_A_const_122 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[222]); A_arbace_j2g_world_A_const_123 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[223]); A_arbace_j2g_world_A_const_124 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[224]); A_arbace_j2g_world_A_const_125 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[225]); A_arbace_j2g_world_A_const_126 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[226]); A_arbace_j2g_world_A_const_127 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[227]); A_arbace_j2g_world_A_const_128 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[228]); A_arbace_j2g_world_A_const_129 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[229]); A_arbace_j2g_world_A_const_130 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[230]); A_arbace_j2g_world_A_const_131 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[231]); A_arbace_j2g_world_A_const_132 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[232]); A_arbace_j2g_world_A_const_133 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[233]) }

func A_arbace_j2g_world_A_clinit_p11() { A_arbace_j2g_world_A_const_134 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[234]); A_arbace_j2g_world_A_const_135 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[235]); A_arbace_j2g_world_A_const_136 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[236]); A_arbace_j2g_world_A_const_137 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[237]); A_arbace_j2g_world_A_const_138 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[238]); A_arbace_j2g_world_A_const_139 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[239]); A_arbace_j2g_world_A_const_140 = jrt.Class_Cast(A_arbace_j2g_world_A_const_pool.A[240]); A_arbace_j2g_world_A_const_141 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[241]); A_arbace_j2g_world_A_const_142 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[242]); A_arbace_j2g_world_A_const_143 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[243]); A_arbace_j2g_world_A_const_144 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[244]); A_arbace_j2g_world_A_const_145 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[245]) }

func A_arbace_j2g_world_A_clinit_p12() { A_arbace_j2g_world_A_const_146 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[246]); A_arbace_j2g_world_A_const_147 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[247]); A_arbace_j2g_world_A_const_148 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[248]); A_arbace_j2g_world_A_const_149 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[249]); A_arbace_j2g_world_A_const_150 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[250]); A_arbace_j2g_world_A_const_151 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[251]); A_arbace_j2g_world_A_const_152 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[252]); A_arbace_j2g_world_A_const_153 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[253]); A_arbace_j2g_world_A_const_154 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[254]); A_arbace_j2g_world_A_const_155 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[255]); A_arbace_j2g_world_A_const_156 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[256]); A_arbace_j2g_world_A_const_157 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[257]) }

func A_arbace_j2g_world_A_clinit_p13() { A_arbace_j2g_world_A_const_158 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[258]); A_arbace_j2g_world_A_const_159 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[259]); A_arbace_j2g_world_A_const_160 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[260]); A_arbace_j2g_world_A_const_161 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[261]); A_arbace_j2g_world_A_const_162 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[262]); A_arbace_j2g_world_A_const_163 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[263]); A_arbace_j2g_world_A_const_164 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[264]); A_arbace_j2g_world_A_const_165 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[265]); A_arbace_j2g_world_A_const_166 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[266]); A_arbace_j2g_world_A_const_167 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[267]); A_arbace_j2g_world_A_const_168 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[268]); A_arbace_j2g_world_A_const_169 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[269]) }

func A_arbace_j2g_world_A_clinit_p14() { A_arbace_j2g_world_A_const_170 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[270]); A_arbace_j2g_world_A_const_171 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[271]); A_arbace_j2g_world_A_const_172 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[272]); A_arbace_j2g_world_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[273]); A_arbace_j2g_world_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[274]); A_arbace_j2g_world_A_const_175 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[275]); A_arbace_j2g_world_A_const_176 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[276]); A_arbace_j2g_world_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[277]); A_arbace_j2g_world_A_const_178 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[278]); A_arbace_j2g_world_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[279]); A_arbace_j2g_world_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[280]); A_arbace_j2g_world_A_const_181 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[281]) }

func A_arbace_j2g_world_A_clinit_p15() { A_arbace_j2g_world_A_const_182 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[282]); A_arbace_j2g_world_A_const_183 = A_arbace_j2g_world_A_const_pool.A[283]; A_arbace_j2g_world_A_const_184 = A_arbace_j2g_world_A_const_pool.A[284]; A_arbace_j2g_world_A_const_185 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[285]); A_arbace_j2g_world_A_const_186 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[286]); A_arbace_j2g_world_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[287]); A_arbace_j2g_world_A_const_188 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[288]); A_arbace_j2g_world_A_const_189 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[289]); A_arbace_j2g_world_A_const_190 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[290]); A_arbace_j2g_world_A_const_191 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[291]); A_arbace_j2g_world_A_const_192 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[292]); A_arbace_j2g_world_A_const_193 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[293]) }

func A_arbace_j2g_world_A_clinit_p16() { A_arbace_j2g_world_A_const_194 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[294]); A_arbace_j2g_world_A_const_195 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[295]); A_arbace_j2g_world_A_const_196 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[296]); A_arbace_j2g_world_A_const_197 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[297]); A_arbace_j2g_world_A_const_198 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[298]); A_arbace_j2g_world_A_const_199 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[299]); A_arbace_j2g_world_A_const_200 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[300]); A_arbace_j2g_world_A_const_201 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[301]); A_arbace_j2g_world_A_const_202 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[302]); A_arbace_j2g_world_A_const_203 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[303]); A_arbace_j2g_world_A_const_204 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[304]); A_arbace_j2g_world_A_const_205 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[305]) }

func A_arbace_j2g_world_A_clinit_p17() { A_arbace_j2g_world_A_const_206 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[306]); A_arbace_j2g_world_A_const_207 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[307]); A_arbace_j2g_world_A_const_208 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[308]); A_arbace_j2g_world_A_const_209 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[309]); A_arbace_j2g_world_A_const_210 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[310]); A_arbace_j2g_world_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[311]); A_arbace_j2g_world_A_const_212 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[312]); A_arbace_j2g_world_A_const_213 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[313]); A_arbace_j2g_world_A_const_214 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[314]); A_arbace_j2g_world_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[315]); A_arbace_j2g_world_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[316]); A_arbace_j2g_world_A_const_217 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[317]) }

func A_arbace_j2g_world_A_clinit_p18() { A_arbace_j2g_world_A_const_218 = A_arbace_j2g_world_A_const_pool.A[318]; A_arbace_j2g_world_A_const_219 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[319]); A_arbace_j2g_world_A_const_220 = A_arbace_j2g_world_A_const_pool.A[320]; A_arbace_j2g_world_A_const_221 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[321]); A_arbace_j2g_world_A_const_222 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[322]); A_arbace_j2g_world_A_const_223 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[323]); A_arbace_j2g_world_A_const_224 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[324]); A_arbace_j2g_world_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[325]); A_arbace_j2g_world_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_world_A_const_pool.A[326]); A_arbace_j2g_world_A_const_227 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[327]); A_arbace_j2g_world_A_const_228 = lang.Var_Cast(A_arbace_j2g_world_A_const_pool.A[328]); A_arbace_j2g_world_A_const_229 = A_arbace_j2g_world_A_const_pool.A[329]; A_arbace_j2g_world_A_const_230 = A_arbace_j2g_world_A_const_pool.A[330] }

func A_arbace_j2g_world_A_clinit_p19() { A_arbace_j2g_world_A_const_231 = A_arbace_j2g_world_A_const_pool.A[331]; A_arbace_j2g_world_A_const_232 = A_arbace_j2g_world_A_const_pool.A[332]; A_arbace_j2g_world_A_const_233 = A_arbace_j2g_world_A_const_pool.A[333]; A_arbace_j2g_world_A_const_234 = A_arbace_j2g_world_A_const_pool.A[334] }

func A_arbace_j2g_world_A_New() *A_arbace_j2g_world_A { A_arbace_j2g_world_A_Init(); t := &A_arbace_j2g_world_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_world_A) Ctor() {}

func (t *A_arbace_j2g_world_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_world_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_world_A_class }

func (t *A_arbace_j2g_world_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_world_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_world_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_world_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_world_A); return ok }

func A_arbace_j2g_world_A_Cast(x any) *A_arbace_j2g_world_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_world_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_world_A_class)) }; return v }



type A_arbace_j2g_world_apply_variant_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_apply_variant_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000173_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_world_apply_variant_fn__78000173_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000175_A struct{ j2g_header uint64; F_counts any }

var A_arbace_j2g_world_apply_variant_fn__78000175_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000177_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000179_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_world_apply_variant_fn__78000175_fn__78000181_A_fn_class *jrt.Class



type A_arbace_j2g_world_apply_variant_fn__78000184_A struct{ j2g_header uint64; F_variants_of, F_prefix, F_applied any }

var A_arbace_j2g_world_apply_variant_fn__78000184_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_form_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_forms_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A struct{ j2g_header uint64; F_s__78000021, F_iter__78000020 any }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A struct{ j2g_header uint64; F_s__78000023, F_iter__78000022 any }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A struct{ j2g_header uint64; F_b__78000025 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_class_forms_iter__78000020__78000026_fn__78000027_iter__78000022__78000028_fn__78000029_fn__78000030_A_fn_class *jrt.Class



type A_arbace_j2g_world_class_parts_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_class_parts_A_fn_class *jrt.Class



type A_arbace_j2g_world_continued_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_world_continued_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_world_cut_key_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_cut_key_A_fn_class *jrt.Class



type A_arbace_j2g_world_eval78000004_A struct{ jrt.Object }

func A_arbace_j2g_world_eval78000004_A_New() *A_arbace_j2g_world_eval78000004_A { t := &A_arbace_j2g_world_eval78000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_world_eval78000004_A) Ctor() {}

func (t *A_arbace_j2g_world_eval78000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_world_eval78000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_world_eval78000004_A_class }

func (t *A_arbace_j2g_world_eval78000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_world_eval78000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_world_eval78000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_world_eval78000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_world_eval78000004_A); return ok }

func A_arbace_j2g_world_eval78000004_A_Cast(x any) *A_arbace_j2g_world_eval78000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_world_eval78000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_world_eval78000004_A_class)) }; return v }



type A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_eval78000004_loading__1927001464__auto____78000005_A_fn_class *jrt.Class



type A_arbace_j2g_world_eval78000008_A struct{ jrt.Object }

func A_arbace_j2g_world_eval78000008_A_New() *A_arbace_j2g_world_eval78000008_A { t := &A_arbace_j2g_world_eval78000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_world_eval78000008_A) Ctor() {}

func (t *A_arbace_j2g_world_eval78000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_world_eval78000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_world_eval78000008_A_class }

func (t *A_arbace_j2g_world_eval78000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_world_eval78000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_world_eval78000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_world_eval78000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_world_eval78000008_A); return ok }

func A_arbace_j2g_world_eval78000008_A_Cast(x any) *A_arbace_j2g_world_eval78000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_world_eval78000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_world_eval78000008_A_class)) }; return v }



type A_arbace_j2g_world_eval78000008_fn__78000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_eval78000008_fn__78000009_A_fn_class *jrt.Class



type A_arbace_j2g_world_first_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_first_form_A_fn_class *jrt.Class



type A_arbace_j2g_world_head_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_head_name_A_fn_class *jrt.Class



type A_arbace_j2g_world_id_space_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_id_space_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_join_continued_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_A struct{ j2g_header uint64; F_claimed, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A struct{ j2g_header uint64; F_claimed, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A struct{ j2g_header uint64; F_claimed, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A struct{ j2g_header uint64; F_s__78000060, F_claimed, F_iter__78000059, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A struct{ j2g_header uint64; F_claimed, F_b__78000062 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_conts any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A struct{ j2g_header uint64; F_c any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000065_fn__78000066_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A struct{ j2g_header uint64; F_c any }

var A_arbace_j2g_world_join_continued_fn__78000057_fn__78000058_iter__78000059__78000063_fn__78000064_fn__78000073_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A struct{ j2g_header uint64; F_s__78000040, F_iter__78000039 any }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A struct{ j2g_header uint64; F_s__78000042, F_iter__78000041 any }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_A_fn_class *jrt.Class



type A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__78000044, F_c__1927001037__auto__ any }

var A_arbace_j2g_world_join_continued_iter__78000039__78000045_fn__78000046_iter__78000041__78000049_fn__78000050_fn__78000051_A_fn_class *jrt.Class



type A_arbace_j2g_world_levels_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_levels_A_fn_class *jrt.Class



type A_arbace_j2g_world_levels_lvl__78000211_A struct{ j2g_header uint64; F_in, F_deps, F_memo any }

var A_arbace_j2g_world_levels_lvl__78000211_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_A struct{ j2g_header uint64; F_parsed, F_variants, F_parse, F_failed, F_top_set, F_wait, F_tops, F_unit, F_applied, F_late_inputs any }

var A_arbace_j2g_world_load_world_fn__78000245_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A struct{ j2g_header uint64; F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_analyze_BANG___78000325_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A struct{ j2g_header uint64; F_variants, F_failed, F_applied any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A struct{ j2g_header uint64; F_nsobj, F_file, F_ns any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A struct{ j2g_header uint64; F_nsobj, F_file, F_s__78000258, F_iter__78000257, F_ns any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A struct{ j2g_header uint64; F_nsobj, F_file, F_b__78000260 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_ns any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000250_iter__78000257__78000261_fn__78000262_fn__78000263_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A struct{ j2g_header uint64; F_variants, F_applied any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A struct{ j2g_header uint64; F_variants any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000276_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A struct{ j2g_header uint64; F_pc any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000269_fn__78000278_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A struct{ j2g_header uint64; F_nsobj, F_pc, F_failed, F_members, F_file any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000293_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A struct{ j2g_header uint64; F_nsobj, F_pc, F_members, F_failed, F_file any }

var A_arbace_j2g_world_load_world_fn__78000245_enter_BANG___78000248_fn__78000303_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A struct{ j2g_header uint64; F_rt_order, F_analyze_BANG_, F_unit, F_rt_start, F_names1 any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000329_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A struct{ j2g_header uint64; F_analyze_BANG_, F_names1 any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000331_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A struct{ j2g_header uint64; F_space, F_prev any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000411_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A struct{ j2g_header uint64; F_space, F_analyze_BANG_, F_unit any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A struct{ j2g_header uint64; F_g, F_space, F_order, F_analyze_BANG_, F_unit any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000417_fn__78000418_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000421_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A struct{ j2g_header uint64; F_space, F_analyze_BANG_, F_unit any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A struct{ j2g_header uint64; F_g, F_space, F_order, F_analyze_BANG_, F_unit any }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000433_fn__78000434_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_fn__78000437_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A struct{ j2g_header uint64; F_heights any }

var A_arbace_j2g_world_load_world_fn__78000245_height__78000335_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_height__78000335_fn__78000336_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A struct{ j2g_header uint64; F_tops_QMARK_, F_height any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A struct{ j2g_header uint64; F_iter__78000339, F_tops_QMARK_, F_height, F_s__78000340 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A struct{ j2g_header uint64; F_tops_QMARK_, F_height any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__78000342 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000339__78000343_fn__78000344_fn__78000345_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A struct{ j2g_header uint64; F_tops_QMARK_, F_height any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A struct{ j2g_header uint64; F_iter__78000349, F_tops_QMARK_, F_height, F_s__78000350 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A struct{ j2g_header uint64; F_tops_QMARK_, F_height any; F_size__1927001038__auto__ int32; F_b__78000352, F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000349__78000353_fn__78000354_fn__78000355_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A struct{ j2g_header uint64; F_tops_QMARK_, F_levels any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A struct{ j2g_header uint64; F_iter__78000359, F_tops_QMARK_, F_s__78000360, F_levels any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A struct{ j2g_header uint64; F_tops_QMARK_, F_levels any; F_size__1927001038__auto__ int32; F_b__78000362, F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A struct{ j2g_header uint64; F_tops_QMARK_ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A struct{ j2g_header uint64; F_tops_QMARK_, F_s__78000367, F_iter__78000366 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A struct{ j2g_header uint64; F_b__78000369, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000366__78000370_fn__78000371_fn__78000372_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A struct{ j2g_header uint64; F_tops_QMARK_ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A struct{ j2g_header uint64; F_tops_QMARK_, F_s__78000377, F_iter__78000376 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A struct{ j2g_header uint64; F_b__78000379, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_fn__78000365_iter__78000376__78000380_fn__78000381_fn__78000382_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A struct{ j2g_header uint64; F_tops_QMARK_ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A struct{ j2g_header uint64; F_tops_QMARK_, F_s__78000388, F_iter__78000387 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A struct{ j2g_header uint64; F_tops_QMARK_, F_b__78000390 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000387__78000391_fn__78000392_fn__78000393_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A struct{ j2g_header uint64; F_tops_QMARK_ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A struct{ j2g_header uint64; F_tops_QMARK_, F_s__78000398, F_iter__78000397 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A struct{ j2g_header uint64; F_b__78000400, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000359__78000363_fn__78000364_iter__78000397__78000401_fn__78000402_fn__78000403_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A struct{ j2g_header uint64; F_s__78000451, F_iter__78000450 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__78000453 any }

var A_arbace_j2g_world_load_world_fn__78000245_iter__78000450__78000454_fn__78000455_fn__78000456_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A struct{ j2g_header uint64; F_t, F_laps any }

var A_arbace_j2g_world_load_world_fn__78000245_lap__78000246_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A struct{ j2g_header uint64; F_failed, F_lap any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000307_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A struct{ j2g_header uint64; F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000310_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A struct{ j2g_header uint64; F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000312_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A struct{ j2g_header uint64; F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000314_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A struct{ j2g_header uint64; F_n, F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000320_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A struct{ j2g_header uint64; F_n, F_failed any }

var A_arbace_j2g_world_load_world_fn__78000245_resolve_BANG___78000306_fn__78000322_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_fn__78000245_tops_QMARK___78000333_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_from_source__78000243_A struct{ j2g_header uint64; F_tops, F_top_of any }

var A_arbace_j2g_world_load_world_from_source__78000243_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A struct{ j2g_header uint64; F_s__78000472, F_iter__78000471 any }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A struct{ j2g_header uint64; F_file any }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A struct{ j2g_header uint64; F_s__78000474, F_file, F_iter__78000473 any }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A struct{ j2g_header uint64; F_b__78000476, F_file any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_load_world_iter__78000471__78000477_fn__78000478_iter__78000473__78000481_fn__78000482_fn__78000483_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_parse__78000228_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_parse__78000228_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_parse__78000228_fn__78000229_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_world_load_world_parse__78000228_fn__78000231_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_top_of__78000241_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_top_of__78000241_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_top_set__78000234_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_top_set__78000234_A_fn_class *jrt.Class



type A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_load_world_top_set__78000234_fn__78000236_A_fn_class *jrt.Class



type A_arbace_j2g_world_new_unit_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_new_unit_A_fn_class *jrt.Class



type A_arbace_j2g_world_ns_of_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_ns_of_forms_A_fn_class *jrt.Class



type A_arbace_j2g_world_ns_of_forms_fn__78000085_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_ns_of_forms_fn__78000085_A_fn_class *jrt.Class



type A_arbace_j2g_world_par_levels_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_par_levels_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_param_key_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000138_A struct{ j2g_header uint64; F_more any }

var A_arbace_j2g_world_param_key_fn__78000138_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000140_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_param_key_fn__78000140_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000146_A struct{ j2g_header uint64; F_more any }

var A_arbace_j2g_world_param_key_fn__78000146_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000148_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_param_key_fn__78000148_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000151_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_world_param_key_fn__78000151_A_fn_class *jrt.Class



type A_arbace_j2g_world_param_key_fn__78000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_param_key_fn__78000153_A_fn_class *jrt.Class



type A_arbace_j2g_world_parse_member_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_parse_member_classes_A_fn_class *jrt.Class



type A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A struct{ j2g_header uint64; F_pc any }

var A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_A_fn_class *jrt.Class



type A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A struct{ j2g_header uint64; F_pc, F_s__78000201, F_iter__78000200 any }

var A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_A_fn_class *jrt.Class



type A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A struct{ j2g_header uint64; F_b__78000203, F_pc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_parse_member_classes_iter__78000200__78000204_fn__78000205_fn__78000206_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_read_forms_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_forms_fn__78000013_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_read_forms_fn__78000013_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_forms_fn__78000015_A struct{ j2g_header uint64; F_r any }

var A_arbace_j2g_world_read_forms_fn__78000015_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_variants_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_read_variants_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_variants_fn__78000190_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_read_variants_fn__78000190_A_fn_class *jrt.Class



type A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A struct{ j2g_header uint64; F_nsname any }

var A_arbace_j2g_world_read_variants_fn__78000190_fn__78000191_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_source_files_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_fn__78000110_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_source_files_fn__78000110_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_fn__78000112_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_source_files_fn__78000112_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_A struct{ j2g_header uint64; F_root any }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A struct{ j2g_header uint64; F_s__78000115, F_iter__78000114, F_root any }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A struct{ j2g_header uint64; F_s__78000117, F_iter__78000116 any }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_A_fn_class *jrt.Class



type A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A struct{ j2g_header uint64; F_b__78000119 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_source_files_iter__78000114__78000120_fn__78000121_iter__78000116__78000122_fn__78000123_fn__78000124_A_fn_class *jrt.Class



type A_arbace_j2g_world_supers_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_supers_of_A_fn_class *jrt.Class



type A_arbace_j2g_world_top_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_top_names_A_fn_class *jrt.Class



type A_arbace_j2g_world_top_names_iter__78000088__78000092_A struct{ j2g_header uint64; F_nsname any }

var A_arbace_j2g_world_top_names_iter__78000088__78000092_A_fn_class *jrt.Class



type A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A struct{ j2g_header uint64; F_nsname, F_s__78000089, F_iter__78000088 any }

var A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_A_fn_class *jrt.Class



type A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A struct{ j2g_header uint64; F_nsname, F_b__78000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_world_top_names_iter__78000088__78000092_fn__78000093_fn__78000094_A_fn_class *jrt.Class



type A_arbace_j2g_world_with_world_A struct{ j2g_header uint64 }

var A_arbace_j2g_world_with_world_A_fn_class *jrt.Class
