//line j2g_strings.ae:1
package aot_arbace_j2g_world

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn20,arbace.classes.parseyn1,pyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmkn3,docks16,arbace.j2g.world3,eofkn3,eofkn9,read-condkn5,allowyn2,doys3,c2j8,continuekn5,formsks3,c2j5,partskn5,classkn4,elsekn7,dynamickn7,packagekn4,rootkn4,dirskn4,treekn5,filesyn2,nskn6,throwskn6,statickn6,methodkn3,tagkn5,fieldkn4,ctorkn18,static-initializerks3,j2g3,nthyn14,j2g-cut-methodkn8,replacedkn3,cutkn5,addedks16,arbace.j2g.world5,erasekn5,orderkn8,counterskn11,switch-mapskn14,switch-holderskn12,source-triedkn14,assert-holderskn12,holder-firstkn4,kindkn2,nskn7,nestingkn6,memberkn5,outerkn4,formkn6,parsedkn7,memberskn5,superkn10,interfacesyn5,quotekn13,variant-fileskn11,late-inputskn4,waitkn4,filekn10,read-errorkn11,compile-setkn4,unitkn11,from-sourcekn4,topskn9,source-ofkn6,failedkn8,variantskn6,erasedkn3,topkn2,pckn5,nsobjkn5,errorkn14,parsed-memberskn12,headers-donekn7,declarekn7,headerskn7,bridgeskn5,statekn15,analysis-failedkn14,member-classeskn16,analysis-startedkn4,readyn21,arbace.classes.nativekn17,analysis-compiledkn16,analysis-runtimeys11,arbace.core3,letyn19,w__78000628__auto__ys11,arbace.core7,bindingys18,arbace.classes.env13,*compile-set*ys22,arbace.classes.analyze6,*unit*ys18,arbace.classes.env13,*from-source*v11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.worldm2,R18,s455,j2g's input (J2G-SPEC §4.1): Java forms files (Arbace's arbace/lang/*.ae, repr/java's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the Java forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).v14,arbace.java.io6,readerv11,arbace.core5,doallv11,arbace.core6,mapcatv11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core5,firstv11,arbace.core4,namev11,arbace.core4,restv11,arbace.core10,take-whilev11,arbace.core4,not=R19,v11,arbace.core10,repeatedlyv11,arbace.core4,readm4,R20,R19,R21,R22,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*m4,R20,R19,R21,R22,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv16,arbace.j2g.world11,class-form?v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consR23,v11,arbace.core6,concatR24,v11,arbace.core4,intov11,arbace.core4,nextv11,arbace.core8,to-arrayR25,v16,arbace.j2g.world10,continued?v11,arbace.core4,dropl3,v11,arbace.core3,strv11,arbace.core6,empty?v11,arbace.core4,atomv11,arbace.core4,mapvv11,arbace.core6,updatev11,arbace.core3,vecv11,arbace.core3,notR26,v11,arbace.core6,secondv11,arbace.core3,mapv11,arbace.core6,vectorv11,arbace.core5,rangel1,v11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core9,not-emptyv11,arbace.core6,dissocv11,arbace.core9,contains?v11,arbace.core5,swap!v11,arbace.core7,ex-infoR27,v11,arbace.core6,removev11,arbace.core4,keysv11,arbace.core6,pr-strv11,arbace.core4,sortv11,arbace.core6,symbolv11,arbace.core8,find-varv11,arbace.core6,internv11,arbace.core9,create-nsv11,arbace.core10,ns-resolvev11,arbace.core9,namespacev11,arbace.core6,ns-mapv11,arbace.core4,var?v11,arbace.core7,ns-namev11,arbace.core10,ns-aliasesv11,arbace.core6,the-nsR28,v11,arbace.core11,alter-meta!v11,arbace.core5,mergeR29,v11,arbace.core6,filterv11,arbace.core7,vector?R30,v20,arbace.classes.parse13,split-optionsv11,arbace.core5,some?v13,arbace.string7,replacev13,arbace.string9,includes?v11,arbace.core5,mungev16,arbace.j2g.world11,class-formsR31,R32,R33,R34,v14,arbace.java.io4,filev11,arbace.core7,sort-byv16,arbace.j2g.world10,first-formR35,v13,arbace.string10,ends-with?v11,arbace.core8,file-seqv16,arbace.j2g.world9,head-nameR36,l2,R37,R38,R39,R40,R41,R42,R43,l0,v16,arbace.j2g.world9,param-keyR44,v11,arbace.core8,identityv16,arbace.j2g.world11,class-partsl-1,v11,arbace.core9,vary-metav11,arbace.core5,assocv11,arbace.core3,incm6,R45,l0,R46,l0,R47,l0,v11,arbace.core6,reducev16,arbace.j2g.world7,cut-keyv11,arbace.core4,somev11,arbace.core12,keep-indexedR47,R46,R45,v16,arbace.j2g.world13,apply-variantv16,arbace.j2g.world10,read-formsv16,arbace.j2g.world11,ns-of-formsv11,arbace.core4,fnilR48,R49,R50,R51,R52,R53,R54,R55,C14,arbace.lang.RTR56,v20,arbace.classes.parse11,parse-classR57,R58,R59,R60,R61,R62,R63,v16,arbace.j2g.world20,parse-member-classesv11,arbace.core3,setv11,arbace.core3,maxv11,arbace.core4,valsv11,arbace.core10,sorted-mapv11,arbace.core8,group-byv22,arbace.classes.analyze4,declR64,R65,v16,arbace.j2g.world6,levelsv16,arbace.j2g.model8,par-mapvv16,arbace.j2g.model4,jobsR66,v11,arbace.core11,sequential?v11,arbace.core4,subsv11,arbace.core7,re-findv16,arbace.j2g.world13,unresolved-reR67,R68,R69,v16,arbace.j2g.world13,read-variantsv16,arbace.j2g.world12,source-filesv16,arbace.j2g.world14,join-continuedR70,R71,v16,arbace.j2g.world9,top-namesv16,arbace.j2g.world8,new-unitR72,R73,R74,R75,R76,R77,v16,arbace.j2g.world8,importedv11,arbace.core4,juxtv16,arbace.j2g.world11,name-importR78,R79,v11,arbace.core6,reset!v11,arbace.core4,*ns*S3,s5,in-nss6,imports10,refer-varsS3,s5,in-nss6,imports10,refer-varsv16,arbace.j2g.world11,refer-vars!v22,arbace.classes.analyze13,eval-ns-form!R80,R81,R82,R83,v22,arbace.classes.analyze8,top-namev22,arbace.classes.analyze14,declare-class!R84,v16,arbace.j2g.world10,par-levelsR85,v22,arbace.classes.analyze15,resolve-header!v16,arbace.j2g.world9,supers-ofv22,arbace.classes.analyze16,resolve-members!v22,arbace.classes.analyze12,add-bridges!R86,R87,R88,v22,arbace.classes.analyze19,mark-enum-abstract!v22,arbace.classes.analyze14,analyze-class!R89,R90,v16,arbace.j2g.world8,id-spacev11,arbace.core11,future-callv11,arbace.core4,run!v22,arbace.classes.analyze6,*unit*v11,arbace.core4,keepR91,v11,arbace.core7,printlnv13,arbace.string4,joinv16,arbace.j2g.world16,analysis-id-baseR92,R93,v11,arbace.core5,zero?R94,v11,arbace.core4,takel10,v11,arbace.core4,compv11,arbace.core1,-v11,arbace.core6,formatv11,arbace.core1,+R95,R96,v18,arbace.classes.env13,*compile-set*v18,arbace.classes.env13,*from-source*R97,R98,R99,R100,R101,R102,")

var Lit_1 *jrt.String = jrt.Intern("arbace.j2g.world$apply_variant$fn__78000190")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.world$apply_variant$fn__78000192")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.world$apply_variant$fn__78000201")

var Lit_4 *jrt.String = jrt.Intern("static-initializer")

var Lit_5 *jrt.String = jrt.Intern("add")

var Lit_6 *jrt.String = jrt.Intern("cut")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.world$apply_variant$fn__78000192$fn__78000194")

var Lit_8 *jrt.String = jrt.Intern("j2g: variant cuts no member: ")

var Lit_9 *jrt.String = jrt.Intern("arbace.j2g.world$apply_variant$fn__78000192$fn__78000196")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.world$apply_variant$fn__78000192$fn__78000198")

var Lit_11 *jrt.String = jrt.Intern("j2g: variant replaces no member: ")

var Lit_12 *jrt.String = jrt.Intern("defclass")

var Lit_13 *jrt.String = jrt.Intern("$")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.world$class_forms$iter__78000022__78000028")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.world$class_forms$iter__78000022__78000028$fn__78000029")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.world$class_forms$iter__78000022__78000028$fn__78000029$iter__78000024__78000030")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.world$class_forms$iter__78000022__78000028$fn__78000029$iter__78000024__78000030$fn__78000031")

var Lit_18 *jrt.String = jrt.Intern("arbace.j2g.world$class_forms$iter__78000022__78000028$fn__78000029$iter__78000024__78000030$fn__78000031$fn__78000032")

var Lit_19 *jrt.String = jrt.Intern("field")

var Lit_20 *jrt.String = jrt.Intern("j2g: bad j2g/cut ")

var Lit_21 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_22 *jrt.String = jrt.Intern("ID_SPACE")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246")

var Lit_25 *jrt.String = jrt.Intern("import")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246$iter__78000239__78000247")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246$iter__78000239__78000247$fn__78000248")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246$iter__78000239__78000247$fn__78000248$iter__78000241__78000249")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246$iter__78000239__78000247$fn__78000248$iter__78000261__78000265")

var Lit_30 *jrt.String = jrt.Intern(".")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246$iter__78000239__78000247$fn__78000248$iter__78000241__78000249$fn__78000250")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246$iter__78000239__78000247$fn__78000248$iter__78000241__78000249$fn__78000250$fn__78000251")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246$iter__78000239__78000247$fn__78000248$iter__78000261__78000265$fn__78000266")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.world$imported$iter__78000237__78000245$fn__78000246$iter__78000239__78000247$fn__78000248$iter__78000261__78000265$fn__78000266$fn__78000267")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$iter__78000041__78000047")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$fn__78000059")

var Lit_37 *jrt.String = jrt.Intern("j2g: continuations of no Java form: ")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$fn__78000059$fn__78000060")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$fn__78000059$fn__78000060$iter__78000061__78000065")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$fn__78000059$fn__78000060$iter__78000061__78000065$fn__78000066")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$fn__78000059$fn__78000060$iter__78000061__78000065$fn__78000066$fn__78000067")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$fn__78000059$fn__78000060$iter__78000061__78000065$fn__78000066$fn__78000075")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$fn__78000059$fn__78000060$iter__78000061__78000065$fn__78000066$fn__78000067$fn__78000068")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$iter__78000041__78000047$fn__78000048")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$iter__78000041__78000047$fn__78000048$iter__78000043__78000051")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$iter__78000041__78000047$fn__78000048$iter__78000043__78000051$fn__78000052")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued$iter__78000041__78000047$fn__78000048$iter__78000043__78000051$fn__78000052$fn__78000053")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.world$levels$lvl__78000228")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$parse__78000290")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$top_set__78000296")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$top_of__78000303")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$from_source__78000305")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000307__78000311")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321")

var Lit_55 *jrt.String = jrt.Intern("a variant for a class not in the inputs")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000561__78000567")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000579__78000583")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000593__78000599")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000611__78000615")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$lap__78000322")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$resolve_BANG___78000382")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$analyze_BANG___78000401")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000405")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000407")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000409__78000413")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$tops_QMARK___78000423")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$height__78000425")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000429__78000433")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000439__78000443")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000501")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000507")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000511")

var Lit_75 *jrt.String = jrt.Intern("J2G_ANALYSIS_TIMES")

var Lit_76 *jrt.String = jrt.Intern("j2g: analysis group: %d tasks in %.2f s, the tasks %.2f s")

var Lit_77 *jrt.String = jrt.Intern("j2g: analysis time %.3f s %s")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000523")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000527")

var Lit_80 *jrt.String = jrt.Intern("j2g: ")

var Lit_81 *jrt.String = jrt.Intern(" local and anonymous classes declared by the second round's analysis")

var Lit_82 *jrt.String = jrt.Intern("j2g: load (s): ")

var Lit_83 *jrt.String = jrt.Intern(", ")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000540__78000544")

var Lit_85 *jrt.String = jrt.Intern("analysis: ")

var Lit_86 *jrt.String = jrt.Intern(" / ")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000326")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000345")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000369")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000379")

var Lit_91 *jrt.String = jrt.Intern("refer-vars")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000326$iter__78000333__78000337")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000326$iter__78000333__78000337$fn__78000338")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000326$iter__78000333__78000337$fn__78000338$fn__78000339")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000345$fn__78000352")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$enter_BANG___78000324$fn__78000345$fn__78000354")

var Lit_97 *jrt.String = jrt.Intern("parse: ")

var Lit_98 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000507$fn__78000508")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$fn__78000523$fn__78000524")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$height__78000425$fn__78000426")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000409__78000413$fn__78000414")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000409__78000413$fn__78000414$fn__78000415")

var Lit_103 *jrt.String = jrt.Intern("read: ")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000429__78000433$fn__78000434")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000429__78000433$fn__78000434$fn__78000435")

var Lit_106 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000439__78000443$fn__78000444")

var Lit_107 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000439__78000443$fn__78000444$fn__78000445")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$fn__78000455")

var Lit_110 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$iter__78000477__78000481")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$iter__78000487__78000491")

var Lit_112 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$fn__78000455$iter__78000456__78000460")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$fn__78000455$iter__78000466__78000470")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$fn__78000455$iter__78000456__78000460$fn__78000461")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$fn__78000455$iter__78000456__78000460$fn__78000461$fn__78000462")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$fn__78000455$iter__78000466__78000470$fn__78000471")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$fn__78000455$iter__78000466__78000470$fn__78000471$fn__78000472")

var Lit_118 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$iter__78000477__78000481$fn__78000482")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$iter__78000477__78000481$fn__78000482$fn__78000483")

var Lit_120 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$iter__78000487__78000491$fn__78000492")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000449__78000453$fn__78000454$iter__78000487__78000491$fn__78000492$fn__78000493")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000540__78000544$fn__78000545")

var Lit_123 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$iter__78000540__78000544$fn__78000545$fn__78000546")

var Lit_124 *jrt.String = jrt.Intern(" ")

var Lit_125 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$resolve_BANG___78000382$fn__78000383")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$resolve_BANG___78000382$fn__78000386")

var Lit_127 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$resolve_BANG___78000382$fn__78000388")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$resolve_BANG___78000382$fn__78000390")

var Lit_129 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$resolve_BANG___78000382$fn__78000396")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$fn__78000321$resolve_BANG___78000382$fn__78000398")

var Lit_131 *jrt.String = jrt.Intern("header: ")

var Lit_132 *jrt.String = jrt.Intern("members: ")

var Lit_133 *jrt.String = jrt.Intern("bridges: ")

var Lit_134 *jrt.String = jrt.Intern("enum: ")

var Lit_135 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000307__78000311$fn__78000312")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000307__78000311$fn__78000312$fn__78000313")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000561__78000567$fn__78000568")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000561__78000567$fn__78000568$iter__78000563__78000571")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000561__78000567$fn__78000568$iter__78000563__78000571$fn__78000572")

var Lit_140 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000561__78000567$fn__78000568$iter__78000563__78000571$fn__78000572$fn__78000573")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000579__78000583$fn__78000584")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000579__78000583$fn__78000584$fn__78000585")

var Lit_143 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000593__78000599$fn__78000600")

var Lit_144 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000593__78000599$fn__78000600$iter__78000595__78000603")

var Lit_145 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000593__78000599$fn__78000600$iter__78000595__78000603$fn__78000604")

var Lit_146 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000593__78000599$fn__78000600$iter__78000595__78000603$fn__78000604$fn__78000605")

var Lit_147 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000611__78000615$fn__78000616")

var Lit_148 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$iter__78000611__78000615$fn__78000616$fn__78000617")

var Lit_149 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$parse__78000290$fn__78000291")

var Lit_150 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$parse__78000290$fn__78000293")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.world$load_world$top_set__78000296$fn__78000298")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.world$name_import$fn__78000279")

var Lit_153 *jrt.String = jrt.Intern(" (the import ")

var Lit_154 *jrt.String = jrt.Intern(")")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.world$ns_of_forms$fn__78000102")

var Lit_156 *jrt.String = jrt.Intern("in-ns")

var Lit_157 *jrt.String = jrt.Intern("method")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.world$param_key$fn__78000155")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.world$param_key$fn__78000157")

var Lit_160 *jrt.String = jrt.Intern("j2g-cut-method")

var Lit_161 *jrt.String = jrt.Intern("arbace.j2g.world$param_key$fn__78000163")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.world$param_key$fn__78000165")

var Lit_163 *jrt.String = jrt.Intern("constructor")

var Lit_164 *jrt.String = jrt.Intern("arbace.j2g.world$param_key$fn__78000168")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.world$param_key$fn__78000170")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.world$parse_member_classes$iter__78000217__78000221")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.world$parse_member_classes$iter__78000217__78000221$fn__78000222")

var Lit_168 *jrt.String = jrt.Intern("arbace.j2g.world$parse_member_classes$iter__78000217__78000221$fn__78000222$fn__78000223")

var Lit_169 *jrt.String = jrt.Intern("arbace.j2g.world$read_forms$fn__78000013")

var Lit_170 *jrt.String = jrt.Intern("arbace.j2g.world$read_forms$fn__78000015")

var Lit_171 *jrt.String = jrt.Intern("arbace.j2g.world$read_forms$fn__78000017")

var Lit_172 *jrt.String = jrt.Intern("defclasses")

var Lit_173 *jrt.String = jrt.Intern("arbace.j2g.world$read_variants$fn__78000207")

var Lit_174 *jrt.String = jrt.Intern("arbace.j2g.world$read_variants$fn__78000207$fn__78000208")

var Lit_175 *jrt.String = jrt.Intern("variant")

var Lit_176 *jrt.String = jrt.Intern("/")

var Lit_177 *jrt.String = jrt.Intern("erase")

var Lit_178 *jrt.String = jrt.Intern("arbace.j2g.world$refer_vars_BANG_$fn__78000093")

var Lit_179 *jrt.String = jrt.Intern("arbace.core")

var Lit_180 *jrt.String = jrt.Intern("arbace.j2g.world$refer_vars_BANG_$fn__78000098")

var Lit_181 *jrt.String = jrt.Intern("arbace.j2g.world$source_files$fn__78000127")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.world$source_files$fn__78000129")

var Lit_183 *jrt.String = jrt.Intern("arbace.j2g.world$source_files$iter__78000131__78000137")

var Lit_184 *jrt.String = jrt.Intern(".ae")

var Lit_185 *jrt.String = jrt.Intern("arbace.j2g.world$source_files$iter__78000131__78000137$fn__78000138")

var Lit_186 *jrt.String = jrt.Intern("arbace.j2g.world$source_files$iter__78000131__78000137$fn__78000138$iter__78000133__78000139")

var Lit_187 *jrt.String = jrt.Intern("arbace.j2g.world$source_files$iter__78000131__78000137$fn__78000138$iter__78000133__78000139$fn__78000140")

var Lit_188 *jrt.String = jrt.Intern("arbace.j2g.world$source_files$iter__78000131__78000137$fn__78000138$iter__78000133__78000139$fn__78000140$fn__78000141")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.world$top_names$iter__78000105__78000109")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.world$top_names$iter__78000105__78000109$fn__78000110")

var Lit_191 *jrt.String = jrt.Intern("arbace.j2g.world$top_names$iter__78000105__78000109$fn__78000110$fn__78000111")

var Lit_192 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,fkn4,linekn6,columnkn4,filekn7,privateyn5,formsyn2,psyn2,nsyn7,entriesyn6,nsnamekn4,keysyn4,rootyn4,dirsyn4,treeyn5,filesyn1,xyn2,cfyn6,vformsyn6,prefixyn11,variants-ofyn7,appliedyn2,pcyn5,namesyn4,depsyn1,nyn7,importskn3,tagyn6,Stringyn6,inputsyn1,&yn13,variant-filesyn11,late-inputsyn4,waityn1,wyn4,bodyv11,arbace.core5,in-nsMyn16,arbace.j2g.worldm2,R0,s455,j2g's input (J2G-SPEC §4.1): Java forms files (Arbace's arbace/lang/*.ae, repr/java's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the Java forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).m2,R0,s455,j2g's input (J2G-SPEC §4.1): Java forms files (Arbace's arbace/lang/*.ae, repr/java's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the Java forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).R1,v16,arbace.j2g.world10,read-formsm10,R2,L1,V1,R3,R0,s177,The top-level forms of file f, a defclasses' classes spliced in its place (a Java file's\n  top-level classes, one compilation: JCS30 (b)), as j2g's world compiles them together.R4,i17,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world10,first-formm12,R7,TR2,L1,V1,R3,R0,s33,The first form of file f, or nil.R4,i28,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world11,class-form?m10,R7,TR2,L1,V1,R3,R4,i36,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world11,class-formsm10,R7,TR2,L1,V1,R8,R4,i38,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world10,continued?m10,R7,TR2,L1,V1,R3,R4,i44,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world14,join-continuedm12,R7,TR2,L1,V1,R9,R0,s566,The read files ps ([{:forms ...}...]) with each Java form continued in other files joined:\n  arbace.c2j writes a large top-level Java form across several files (SA220: one large file\n  bounded the parallel read), the Java form with :c2j/parts n in its metadata and the rest of\n  its elements in n continuations (c2j/continue NAME k element...), k from 1 to n; the\n  continuations' elements appended in that order, the Java form as printed whole (but the\n  reader's columns), :c2j/parts dropped, the continuations removed. A missing or unclaimed\n  continuation fails.R4,i46,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world11,refer-vars!m12,R7,TR2,L1,V2,R10,R11,R0,s627,c2j's (c2j/refer-vars [[symbol namespace name metadata]...]) in the file of the Java forms\n  compiler's classes (arbace.c2j.main's java-forms-file; REAP3, RPS6 (a)): the vars their Clojure\n  code named in namespace ns when the program prepared it, which this program has not loaded,\n  made so that the analysis resolves each symbol to its var as there: the var interned (with\n  the metadata the analysis reads) when its namespace lacks it, an unqualified symbol referred\n  to it, a qualified one's namespace aliased. A var or mapping the program has is kept (but a\n  mapping to arbace.core's var, which the namespace replaced).R4,i79,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world11,ns-of-formsm10,R7,TR2,L1,V1,R8,R4,i105,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world9,top-namesm12,R7,TR2,L1,V2,R12,R8,R0,s67,The internal names of the top-level classes of a file's Java forms.R4,i109,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world12,source-filesm10,R2,L1,V1,m2,R13,V4,R14,R15,R16,R17,R0,s168,The Java forms files of an input: {:root dir :dirs [subdir...]} or {:root dir :tree true}\n  (every .ae under root but package files, whose first form is their ns form).R4,i121,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world9,head-namem10,R7,TR2,L1,V1,R3,R4,i142,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world9,param-keym12,R7,TR2,L1,V1,R3,R0,s86,A method's or constructor's identity in a variant: kind, name, static, parameter tags.R4,i144,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world7,cut-keym10,R7,TR2,L1,V1,R18,R4,i171,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world11,class-partsm12,R7,TR2,L1,V1,R19,R0,s79,[head members] of a defclass form: head is defclass, name, components, options.R4,i179,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world13,apply-variantm10,R2,L2,V2,R19,R20,V5,R19,R20,R21,R22,R23,R0,s420,Java form cf with the variant's members applied: replaced, cut, added. Returns [cf'\n  counts]. With variants-of (a function of a nested class's simple name, giving its variant\n  members or nil) and applied (an atom of {name counts}), the variants of nested classes\n  (j2g/variant Outer$Inner ...) are applied to the nested Java forms too, recursively, and\n  recorded in applied under their names (proposed amendment B1).R4,i187,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world13,read-variantsm10,R2,L1,V1,R17,R0,s335,{internal-name [member-form ...]} of the variant files; a nested class's variant is named\n  by its binary name, (j2g/variant Compiler$ObjExpr ...). The prefixes of the packages a\n  variant file erases, (j2g/erase \"p/\"), are under the key ::erase (amendment E2; the Go\n  build erased ASM, arbace/asm/, until it left main on 2026-10-12).R4,i234,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world8,new-unitm10,R7,TR2,L1,V0,R4,i255,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world16,analysis-id-basel100000,m8,R4,i259,R5,i1,R6,s19,arbace/j2g/world.aeR0,s151,Where each task of the analysis starts its id space (RT.ID_SPACE, SA143): a round value well\n  above what loading j2g takes, as main's id-floor (SA13).v16,arbace.j2g.world8,id-spacem12,R7,TR2,L1,V0,R0,s84,The runtime's per-thread id space (RT.ID_SPACE, SA143), or nil on a host without it.R4,i264,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world20,parse-member-classesm12,R7,TR2,L1,V1,R24,R0,s363,The member classes of parsed class pc, parsed as arbace.classes.analyze/declare-class! parses\n  them (a member class's parse takes only the kind of its outer class), recursively:\n  [{:parsed member-class :members [...]}...] in their order, which declare-class! takes as its\n  ctx's :parsed-members (a host whose declare-class! does not take it parses them again).R4,i272,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world6,levelsm12,R7,TR2,L1,V2,R25,R26,R0,s222,names in levels, a name in a level after those of the names it depends on (deps: a name's\n  names to process first; others ignored), each level in names' order. A cycle (an error the\n  steps report) is cut where it closes.R4,i282,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world9,supers-ofm12,R7,TR2,L1,V1,R27,R0,s52,The direct supertypes of class n in the compilation.R4,i297,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world10,par-levelsm12,R7,TR2,L1,V3,R25,R26,R3,R0,s81,(f n) for each of names, a level (levels) at a time, a level's names in parallel.R4,i302,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world8,importedm12,R7,TR2,L1,V1,R8,R0,s156,The classes a Java forms file's import forms name: simple name -> qualified name\n  ((import '(java.net DatagramSocket)), (import 'java.net.DatagramSocket)).R4,i312,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world13,unresolved-rep77,(Unable to resolve (?:class|symbol)|Unknown (?:type|class)): ([A-Za-z_][\\w]*)m8,R7,TR4,i327,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world11,name-importm12,R7,TR2,L1,V2,R28,Myn3,msgm2,R29,R30,R0,s255,A failure's message with the import that would have declared the class it could not resolve\n  named after it (\"Unable to resolve class: DatagramSocket (the import java.net.DatagramSocket)\"),\n  from imports (simple -> qualified, its file's); else as it is.R4,i330,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world10,load-worldm10,R2,L1,V3,R31,R32,m2,R13,V3,R33,R34,R35,R0,s894,Reads, enters and analyzes the Java forms of the inputs, each {:root :dirs|:tree|:files},\n  with the Go-build variants of the variant files applied. Returns the world:\n  {:compile-set atom :unit unit :from-source pred :files [...] :tops #{} :failed [[class\n  msg]...] :variants {class counts}}. Run translation inside (with-world w ...).\n\n  In two rounds: the inputs, then the late ones (the compiled namespaces' tree, standalone\n  S6), each entered and resolved (headers, members, bridges) in order; the first round's classes\n  are analyzed on a thread of their own from the end of the first round, the late ones in\n  parallel after the second. Before the second round wait is called (j2g --await: the late\n  input is being written meanwhile; bin/arbace-go starts j2g as the host compiles the\n  namespaces). The rounds are the same with or without the wait: the output does not depend on\n  it.R4,i344,R5,i1,R6,s19,arbace/j2g/world.aev16,arbace.j2g.world10,with-worldm10,R2,L1,V3,R36,R32,R37,R0,s87,Runs body with the world's class environment bound (analyzer and env functions see it).R4,i586,R5,i1,R6,s19,arbace/j2g/world.ae")

var Lit_193 *jrt.String = jrt.Intern("arbace.j2g.world$eval78000004$loading__1927001464__auto____78000005")

var Lit_194 *jrt.String = jrt.Intern("arbace.j2g.world$eval78000008$fn__78000009")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.world$read_forms")

var Lit_196 *jrt.String = jrt.Intern("arbace.j2g.world$first_form")

var Lit_197 *jrt.String = jrt.Intern("arbace.j2g.world$class_form_QMARK_")

var Lit_198 *jrt.String = jrt.Intern("arbace.j2g.world$class_forms")

var Lit_199 *jrt.String = jrt.Intern("arbace.j2g.world$continued_QMARK_")

var Lit_200 *jrt.String = jrt.Intern("arbace.j2g.world$join_continued")

var Lit_201 *jrt.String = jrt.Intern("arbace.j2g.world$refer_vars_BANG_")

var Lit_202 *jrt.String = jrt.Intern("arbace.j2g.world$ns_of_forms")

var Lit_203 *jrt.String = jrt.Intern("arbace.j2g.world$top_names")

var Lit_204 *jrt.String = jrt.Intern("arbace.j2g.world$source_files")

var Lit_205 *jrt.String = jrt.Intern("arbace.j2g.world$head_name")

var Lit_206 *jrt.String = jrt.Intern("arbace.j2g.world$param_key")

var Lit_207 *jrt.String = jrt.Intern("arbace.j2g.world$cut_key")

var Lit_208 *jrt.String = jrt.Intern("arbace.j2g.world$class_parts")

var Lit_209 *jrt.String = jrt.Intern("arbace.j2g.world$apply_variant")

var Lit_210 *jrt.String = jrt.Intern("arbace.j2g.world$read_variants")

var Lit_211 *jrt.String = jrt.Intern("arbace.j2g.world$new_unit")

var Lit_212 *jrt.String = jrt.Intern("arbace.j2g.world$id_space")

var Lit_213 *jrt.String = jrt.Intern("arbace.j2g.world$parse_member_classes")

var Lit_214 *jrt.String = jrt.Intern("arbace.j2g.world$levels")

var Lit_215 *jrt.String = jrt.Intern("arbace.j2g.world$supers_of")

var Lit_216 *jrt.String = jrt.Intern("arbace.j2g.world$par_levels")

var Lit_217 *jrt.String = jrt.Intern("arbace.j2g.world$imported")

var Lit_218 *jrt.String = jrt.Intern("arbace.j2g.world$name_import")

var Lit_219 *jrt.String = jrt.Intern("arbace.j2g.world$load_world")

var Lit_220 *jrt.String = jrt.Intern("arbace.j2g.world$with_world")
