//line aot_arbace_pprint.ae:1
package aot_arbace_pprint

import (
	"arbace/jrt"
	"arbace/lang"
)




func A_arbace_pprint_print_table_A_New() *A_arbace_pprint_print_table_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_pprint_print_table_A) Ctor() {}
//line :11:1
func (t *A_arbace_pprint_print_table_A) Invoke_O_O_O__O(self, ks__0, rows__1 any) any {





	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(rows__1)) { var widths__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_print_table_fn__1821000006_A_New_O(rows__1); var tmp3 *jrt.Class
		var fncls__169 /*line :17:1*/*jrt.Class = A_arbace_pprint_print_table_fn__1821000006_A_fn_class

		if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_222, false); A_arbace_pprint_print_table_fn__1821000006_A_fn_class = fncls__169d; tmp3 = fncls__169d } else { tmp3 = fncls__169 }
//line :18:1
		widths__3 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ks__0)
//line :17:1
		var spacers__4 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp5 any = A_arbace_pprint_print_table_fn__1821000010_A_New(); var tmp6 *jrt.Class
		var fncls__170 /*line :17:1*/*jrt.Class = A_arbace_pprint_print_table_fn__1821000010_A_fn_class




		if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_223, false); A_arbace_pprint_print_table_fn__1821000010_A_fn_class = fncls__170d; tmp6 = fncls__170d } else { tmp6 = fncls__170 }; spacers__4 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), widths__3)
//line :17:1
		var fmts__5 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp8 any = A_arbace_pprint_print_table_fn__1821000012_A_New(); var tmp9 *jrt.Class
		var fncls__171 /*line :17:1*/*jrt.Class = A_arbace_pprint_print_table_fn__1821000012_A_fn_class





		if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_224, false); A_arbace_pprint_print_table_fn__1821000012_A_fn_class = fncls__171d; tmp9 = fncls__171d } else { tmp9 = fncls__171 }; fmts__5 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), widths__3)
//line :17:1
		var fmt_row__6 any; var tmp10 any = A_arbace_pprint_print_table_fmt_row__1821000014_A_New_O_O(fmts__5, ks__0); var tmp11 *jrt.Class
		var fncls__167 /*line :17:1*/*jrt.Class = A_arbace_pprint_print_table_fmt_row__1821000014_A_fn_class






		if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_225, false); A_arbace_pprint_print_table_fmt_row__1821000014_A_fn_class = fncls__167d; tmp11 = fncls__167d } else { tmp11 = fncls__167 }; fmt_row__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)





		lang.IFn_Cast(A_arbace_pprint_A_const_36.GetRawRoot__O()).Invoke__O()
		lang.IFn_Cast(A_arbace_pprint_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(fmt_row__6).Invoke_O_O_O_O__O(Lit_226, Lit_227, Lit_228, lang.IFn_Cast(A_arbace_pprint_A_const_507.GetRawRoot__O()).Invoke_O_O__O(ks__0, ks__0)))
		lang.IFn_Cast(A_arbace_pprint_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(fmt_row__6).Invoke_O_O_O_O__O(Lit_229, Lit_230, Lit_231, lang.IFn_Cast(A_arbace_pprint_A_const_507.GetRawRoot__O()).Invoke_O_O__O(ks__0, spacers__4)))
//line :17:1
		var seq_1821000034__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(rows__1); var chunk_1821000035__8 any; var count_1821000036__9 int64 = 0; var i_1821000037__10 int64 = 0; L1: for {















			if lang.Numbers_Lt_J_J__Z(i_1821000037__10, count_1821000036__9) { var row__11 any = lang.Indexed_Cast(chunk_1821000035__8).Nth_I__O(lang.RT_IntCast_J__I(i_1821000037__10))
				lang.IFn_Cast(A_arbace_pprint_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(fmt_row__6).Invoke_O_O_O_O__O(Lit_226, Lit_227, Lit_228, row__11))
//line :33:1
				seq_1821000034__7, chunk_1821000035__8, count_1821000036__9, i_1821000037__10 = seq_1821000034__7, chunk_1821000035__8, count_1821000036__9, lang.Numbers_Unchecked_inc_J__J(i_1821000037__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_1821000034__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1821000034__12 any = temp__1927000414__auto____11; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_1821000034__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1821000034__12); seq_1821000034__7, chunk_1821000035__8, count_1821000036__9, i_1821000037__10 = lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1821000034__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var row__13 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq_1821000034__12)
					lang.IFn_Cast(A_arbace_pprint_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(fmt_row__6).Invoke_O_O_O_O__O(Lit_226, Lit_227, Lit_228, row__13))
//line :33:1
					seq_1821000034__7, chunk_1821000035__8, count_1821000036__9, i_1821000037__10 = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1821000034__12), nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :17:1
						return nil }
//line :11:1
	panic("a2g: unreachable") }
//line :11:1
func (t *A_arbace_pprint_print_table_A) Invoke_O_O__O(self, rows__0 any) any {























	return lang.IFn_Cast(A_arbace_pprint_A_const_619.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_508.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(rows__0)), rows__0) }
//line :14:1
func A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_New() *A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A) Ctor() {}
//line :14:1
func (t *A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_pprint_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_2, A_arbace_pprint_A_const_3, A_arbace_pprint_A_const_4); tmp3 = lang.IFn_Cast(A_arbace_pprint_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_5); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :14:1
func A_arbace_pprint_eval1513000008_fn__1513000009_A_New() *A_arbace_pprint_eval1513000008_fn__1513000009_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1513000008_fn__1513000009_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_pprint_eval1513000008_fn__1513000009_A) Ctor() {}
//line :14:1
func (t *A_arbace_pprint_eval1513000008_fn__1513000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_10), A_arbace_pprint_A_const_8.GetRawRoot__O(), A_arbace_pprint_A_const_9) }




func A_arbace_pprint_print_table_fn__1821000006_A_New_O(p0 any) *A_arbace_pprint_print_table_fn__1821000006_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fn__1821000006_A{}; t.Ctor_O(p0); return t }
//line :19:1
func (t *A_arbace_pprint_print_table_fn__1821000006_A) Ctor_O(c__rows any) { t.F_rows = c__rows }
//line :19:1
func (t *A_arbace_pprint_print_table_fn__1821000006_A) Invoke_O_O__O(self, k__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_618.GetRawRoot__O(); var tmp3 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(k__1))).Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp5 any = A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_New_O(k__1); var tmp6 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_236, false); A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_fn_class = fncls__168d; tmp6 = fncls__168d } else { tmp6 = fncls__168 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), t.F_rows)) }
//line :19:1
func A_arbace_pprint_use_method_A_New() *A_arbace_pprint_use_method_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_use_method_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_pprint_use_method_A) Ctor() {}
//line :19:1
func (t *A_arbace_pprint_use_method_A) Invoke_O_O_O_O__O(self, multifn__0, dispatch_val__1, func__2 any) any {


	return jrt.NN(lang.MultiFn_Cast(multifn__0)).AddMethod_O_IFn__MultiFn(dispatch_val__1, lang.IFn_Cast(func__2)).Ref() }
//line :20:1
func A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_New_O(p0 any) *A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A{}; t.Ctor_O(p0); return t }
//line :20:1
func (t *A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :20:1
func (t *A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A) Invoke_O_O__O(self, p1__1821000002_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O(p1__1821000002_SHARP___1, t.F_k)))).Ref() }

func A_arbace_pprint_print_table_fn__1821000010_A_New() *A_arbace_pprint_print_table_fn__1821000010_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fn__1821000010_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_pprint_print_table_fn__1821000010_A) Ctor() {}
//line :22:1
func (t *A_arbace_pprint_print_table_fn__1821000010_A) Invoke_O_O__O(self, p1__1821000003_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(p1__1821000003_SHARP___1, Lit_61)) }
func A_arbace_pprint_print_table_fn__1821000012_A_New() *A_arbace_pprint_print_table_fn__1821000012_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fn__1821000012_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_pprint_print_table_fn__1821000012_A) Ctor() {}
//line :23:1
func (t *A_arbace_pprint_print_table_fn__1821000012_A) Invoke_O_O__O(self, p1__1821000004_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_146, nil, Lit_237), jrt.RefArrayOf(jrt.Object_class, nil, p1__1821000004_SHARP___1, nil)).Ref() }
func A_arbace_pprint_get_field_A_New() *A_arbace_pprint_get_field_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_field_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_pprint_get_field_A) Ctor() {}
//line :24:1
func (t *A_arbace_pprint_get_field_A) Invoke_O_O_O__O(self, this__0, sym__1 any) any {
	return lang.IFn_Cast(sym__1).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0))) }
//line :24:1
func A_arbace_pprint_print_table_fmt_row__1821000014_A_New_O_O(p0, p1 any) *A_arbace_pprint_print_table_fmt_row__1821000014_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fmt_row__1821000014_A{}; t.Ctor_O_O(p0, p1); return t }
//line :24:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_A) Ctor_O_O(c__fmts, c__ks any) { t.F_fmts = c__fmts; t.F_ks = c__ks }
//line :24:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_A) Invoke_O_O_O_O_O__O(self, leader__1, divider__2, trailer__3, row__4 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_A_const_146.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_342.GetRawRoot__O()); var tmp5 any; var iter__1927001039__auto____8 any; var tmp6 any = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_New(); var tmp7 *jrt.Class
	var fncls__165 /*line :25:1*/*jrt.Class = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_fn_class

	if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_232, false); A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_fn_class = fncls__165d; tmp7 = fncls__165d } else { tmp7 = fncls__165 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp10 any = A_arbace_pprint_A_const_78.GetRawRoot__O(); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp12 any = A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_New_O(row__4); var tmp13 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_233, false); A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_fn_class = fncls__166d; tmp13 = fncls__166d } else { tmp13 = fncls__166 }; tmp5 = tmp8.Invoke_O__O(tmp9.Invoke_O_O_O__O(tmp10, tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), t.F_ks), t.F_fmts))
//line :25:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, leader__1, tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(divider__2, tmp5)), trailer__3)).Ref() }
func A_arbace_pprint_cl_format_A_New() *A_arbace_pprint_cl_format_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_cl_format_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_pprint_cl_format_A) Ctor() {}
//line :26:1
func (t *A_arbace_pprint_cl_format_A) DoInvoke_O_O_O_O__O(self, writer__0, format_in__1, args__2 any) any { var compiled_format__4 any; if


































	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1)) { compiled_format__4 = lang.IFn_Cast(A_arbace_pprint_A_const_295.GetRawRoot__O()).Invoke_O__O(format_in__1) } else { compiled_format__4 = format_in__1 }; var navigator__5 any = /*line :26:1*/lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(args__2); return /*line :63:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_297.GetRawRoot__O()).Invoke_O_O_O__O(writer__0, compiled_format__4, navigator__5) }
//line :26:1
func A_arbace_pprint_map_passing_context_A_New() *A_arbace_pprint_map_passing_context_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_map_passing_context_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_pprint_map_passing_context_A) Ctor() {}
//line :26:1
func (t *A_arbace_pprint_map_passing_context_A) Invoke_O_O_O_O__O(self, func__0, initial_context__1, lis__2 any) any { { var context__4 any = initial_context__1; var lis__5 any = lis__2; var acc__6 any; lang.PersistentVector_Init(); acc__6 = lang.PersistentVector_EMPTY.Ref(); L1: for {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(lis__5)) { return lang.Tuple_Create_O_O__IPersistentVector(acc__6, context__4) } else { var this__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(lis__5); var remainder__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lis__5); var vec__1470000002__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(func__0, lang.Tuple_Create_O_O__IPersistentVector(this__7, context__4)); var result__10 any = lang.RT_Nth_O_I_O__O(vec__1470000002__9, lang.RT_IntCast_J__I(0), nil); var new_context__11 any = lang.RT_Nth_O_I_O__O(vec__1470000002__9, lang.RT_IntCast_J__I(1), nil)




		context__4, lis__5, acc__6 = new_context__11, remainder__8, lang.IFn_Cast(A_arbace_pprint_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__6, result__10); continue L1 } } }; /*line :26:1*/panic("a2g: unreachable") }
func A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_New_O(p0 any) *A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A{}; t.Ctor_O(p0); return t }
//line :27:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A) Ctor_O(c__row any) { t.F_row = c__row }
//line :27:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A) Invoke_O_O__O(self, p1__1821000005_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_row, p1__1821000005_SHARP___1) }
//line :27:1
func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_New() *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A) Ctor() {}
//line :27:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A) Invoke_O_O__O(self, s__1821000016__1 any) any { var tmp1 any = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_New_O_O(self, s__1821000016__1); var tmp2 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_234, false); A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_fn_class = fncls__164d; tmp2 = fncls__164d } else { tmp2 = fncls__164 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :27:1
func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_New_O_O(p0, p1 any) *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A) Ctor_O_O(c__iter__1821000015, c__s__1821000016 any) { t.F_iter__1821000015 = c__iter__1821000015; t.F_s__1821000016 = c__s__1821000016 }
//line :27:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A) Invoke_O__O(self any) any { { var s__1821000016__1 any; var t_ any = t.F_s__1821000016; t.F_s__1821000016 = nil; s__1821000016__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(s__1821000016__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1821000016__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(s__1821000016__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(s__1821000016__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1821000018__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_New_O_I_O(b__1821000018__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_235, false); A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_fn_class = fncls__163d; tmp2 = fncls__163d } else { tmp2 = fncls__163 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1821000015); return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1821000018__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1821000016__3))) } else { return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1821000018__6), nil) } } else { var vec__1821000026__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__1821000016__3); var col__5 any = lang.RT_Nth_O_I_O__O(vec__1821000026__4, lang.RT_IntCast_J__I(0), nil); var fmt__6 any = lang.RT_Nth_O_I_O__O(vec__1821000026__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1821000015); return lang.IFn_Cast(A_arbace_pprint_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_329.GetRawRoot__O()).Invoke_O_O__O(fmt__6, lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(col__5)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(s__1821000016__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :27:1
func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :27:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A) Ctor_O_I_O(c__b__1821000018 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1821000018 = c__b__1821000018; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :27:1
func (t *A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A) Invoke_O__O(self any) any { { var i__1821000017__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1821000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1821000022__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1821000017__1)); var col__3 any = lang.RT_Nth_O_I_O__O(vec__1821000022__2, lang.RT_IntCast_J__I(0), nil); var fmt__4 any = lang.RT_Nth_O_I_O__O(vec__1821000022__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_21.GetRawRoot__O()); var tmp3 any = t.F_b__1821000018; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_pprint_A_const_329.GetRawRoot__O()).Invoke_O_O__O(fmt__4, lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(col__3))); i__1821000017__1 = lang.Numbers_Unchecked_inc_J__J(i__1821000017__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
//line :27:1
func A_arbace_pprint_set_field_A_New() *A_arbace_pprint_set_field_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_field_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_pprint_set_field_A) Ctor() {}
//line :27:1
func (t *A_arbace_pprint_set_field_A) Invoke_O_O_O_O__O(self, this__0, sym__1, new_val__2 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0), A_arbace_pprint_A_const_44.GetRawRoot__O(), sym__1, new_val__2)
}
func A_arbace_pprint_get_column_A_New() *A_arbace_pprint_get_column_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_column_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_pprint_get_column_A) Ctor() {}
//line :30:1
func (t *A_arbace_pprint_get_column_A) Invoke_O_O__O(self, this__0 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(this__0, A_arbace_pprint_A_const_46)
}
func A_arbace_pprint_get_line_A_New() *A_arbace_pprint_get_line_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_line_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_pprint_get_line_A) Ctor() {}
//line :33:1
func (t *A_arbace_pprint_get_line_A) Invoke_O_O__O(self, this__0 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(this__0, A_arbace_pprint_A_const_47)
}
func A_arbace_pprint_get_max_column_A_New() *A_arbace_pprint_get_max_column_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_max_column_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_pprint_get_max_column_A) Ctor() {}
//line :36:1
func (t *A_arbace_pprint_get_max_column_A) Invoke_O_O__O(self, this__0 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(this__0, A_arbace_pprint_A_const_48) }
//line :36:1
func A_arbace_pprint_getf_A_New() *A_arbace_pprint_getf_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_getf_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_pprint_getf_A) Ctor() {}
//line :36:1
func (t *A_arbace_pprint_getf_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, sym__2 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(sym__2), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_63), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_63), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_64))))))))) }
func A_arbace_pprint_consume_A_New() *A_arbace_pprint_consume_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_consume_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_pprint_consume_A) Ctor() {}
//line :37:1
func (t *A_arbace_pprint_consume_A) Invoke_O_O_O__O(self, func__0, initial_context__1 any) any { { var context__3 any = initial_context__1; var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); L1: for { var vec__1470000006__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(func__0, lang.Tuple_Create_O__IPersistentVector(context__3)); var result__6 any = lang.RT_Nth_O_I_O__O(vec__1470000006__5, lang.RT_IntCast_J__I(0), nil); var new_context__7 any = lang.RT_Nth_O_I_O__O(vec__1470000006__5, lang.RT_IntCast_J__I(1), nil)



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(result__6)) { return lang.Tuple_Create_O_O__IPersistentVector(acc__4, new_context__7) } else {

		context__3, acc__4 = new_context__7, lang.IFn_Cast(A_arbace_pprint_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, result__6); continue L1 } } }; /*line :37:1*/panic("a2g: unreachable") }

func A_arbace_pprint_set_max_column_A_New() *A_arbace_pprint_set_max_column_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_max_column_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_pprint_set_max_column_A) Ctor() {}
//line :39:1
func (t *A_arbace_pprint_set_max_column_A) Invoke_O_O_O__O(self, this__0, new_max__1 any) any {
	var tmp1 any = A_arbace_pprint_set_max_column_fn__44000011_A_New_O_O(new_max__1, this__0); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_pprint_set_max_column_fn__44000011_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_248, false); A_arbace_pprint_set_max_column_fn__44000011_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil))
//line :39:1
	return nil }
func A_arbace_pprint_set_max_column_fn__44000011_A_New_O_O(p0, p1 any) *A_arbace_pprint_set_max_column_fn__44000011_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_max_column_fn__44000011_A{}; t.Ctor_O_O(p0, p1); return t }
//line :40:1
func (t *A_arbace_pprint_set_max_column_fn__44000011_A) Ctor_O_O(c__new_max, c__this any) { t.F_new_max = c__new_max; t.F_this = c__this }
//line :40:1
func (t *A_arbace_pprint_set_max_column_fn__44000011_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_49.GetRawRoot__O()).Invoke_O_O_O__O(t.F_this, A_arbace_pprint_A_const_48, t.F_new_max) }

func A_arbace_pprint_setf_A_New() *A_arbace_pprint_setf_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_setf_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_pprint_setf_A) Ctor() {}
//line :42:1
func (t *A_arbace_pprint_setf_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, sym__2, new_val__3 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_65), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_63), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_66)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_67), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(sym__2), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(new_val__3))) }
func A_arbace_pprint_get_writer_A_New() *A_arbace_pprint_get_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_writer_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_pprint_get_writer_A) Ctor() {}
//line :43:1
func (t *A_arbace_pprint_get_writer_A) Invoke_O_O__O(self, this__0 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(this__0, A_arbace_pprint_A_const_50) }
func A_arbace_pprint_consume_while_A_New() *A_arbace_pprint_consume_while_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_consume_while_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_pprint_consume_while_A) Ctor() {}
//line :45:1
func (t *A_arbace_pprint_consume_while_A) Invoke_O_O_O__O(self, func__0, initial_context__1 any) any { { var context__3 any = initial_context__1; var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); L1: for { var vec__1470000010__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(func__0, lang.Tuple_Create_O__IPersistentVector(context__3)); var result__6 any = lang.RT_Nth_O_I_O__O(vec__1470000010__5, lang.RT_IntCast_J__I(0), nil); var continue__7 any = lang.RT_Nth_O_I_O__O(vec__1470000010__5, lang.RT_IntCast_J__I(1), nil); var new_context__8 any = lang.RT_Nth_O_I_O__O(vec__1470000010__5, lang.RT_IntCast_J__I(2), nil)



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(continue__7)) { return lang.Tuple_Create_O_O__IPersistentVector(acc__4, context__3) } else {

		context__3, acc__4 = new_context__8, lang.IFn_Cast(A_arbace_pprint_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, result__6); continue L1 } } }; /*line :45:1*/panic("a2g: unreachable") }
func A_arbace_pprint_c_write_char_A_New() *A_arbace_pprint_c_write_char_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_c_write_char_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_pprint_c_write_char_A) Ctor() {}
//line :46:1
func (t *A_arbace_pprint_c_write_char_A) Invoke_O_O_O__O(self, this__0, c__1 any) any {
	var tmp1 any = A_arbace_pprint_c_write_char_fn__44000015_A_New_O_O(c__1, this__0); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_pprint_c_write_char_fn__44000015_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_pprint_c_write_char_fn__44000015_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil))




	jrt.Writer_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(this__0, A_arbace_pprint_A_const_50)).Write_I__V(lang.RT_IntCast_O__I(c__1)); return nil }
//line :47:1
func A_arbace_pprint_c_write_char_fn__44000015_A_New_O_O(p0, p1 any) *A_arbace_pprint_c_write_char_fn__44000015_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_c_write_char_fn__44000015_A{}; t.Ctor_O_O(p0, p1); return t }
//line :47:1
func (t *A_arbace_pprint_c_write_char_fn__44000015_A) Ctor_O_O(c__c, c__this any) { t.F_c = c__c; t.F_this = c__this }
//line :47:1
func (t *A_arbace_pprint_c_write_char_fn__44000015_A) Invoke_O__O(self any) any { var tmp1 any = t.F_c; if lang.Util_Equiv_O_J__Z(tmp1, int64(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_51))) {

	lang.IFn_Cast(A_arbace_pprint_A_const_49.GetRawRoot__O()).Invoke_O_O_O__O(t.F_this, A_arbace_pprint_A_const_46, A_arbace_pprint_A_const_28)
	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_49.GetRawRoot__O()); var tmp3 any = t.F_this; var tmp4 any = A_arbace_pprint_A_const_47; return tmp2.Invoke_O_O_O__O(tmp3, tmp4, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(t.F_this, A_arbace_pprint_A_const_47))) } else {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_49.GetRawRoot__O()); var tmp6 any = t.F_this; var tmp7 any = A_arbace_pprint_A_const_46; return tmp5.Invoke_O_O_O__O(tmp6, tmp7, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(t.F_this, A_arbace_pprint_A_const_46))) } }
//line :48:1
func A_arbace_pprint_deftype_A_New() *A_arbace_pprint_deftype_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_deftype_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_pprint_deftype_A) Ctor() {}
//line :48:1
func (t *A_arbace_pprint_deftype_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, type_name__2, fields__3 any) any { var name_str__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_68.GetRawRoot__O()).Invoke_O__O(type_name__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_69); var tmp4 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_70), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(type_name__2), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_71), fields__3))); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_72); var tmp9 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(type_name__2)))); var tmp10 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_74); var tmp11 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_75); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()); var tmp13 *jrt.Boolean;

	jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O__O(tmp6.Invoke_O__O(tmp7.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, tmp12.Invoke_O__O(tmp13.Ref())))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_76), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_77.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, name_str__5)).Ref())), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_79), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_80))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_81), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_82), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(type_name__2), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_83.GetRawRoot__O()).Invoke_O__O(name_str__5)), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_80))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_84), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_77.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_46), jrt.RefArrayOf(jrt.Object_class, name_str__5, nil)).Ref())), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_85))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_86), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_71), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_85)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_83.GetRawRoot__O()).Invoke_O__O(name_str__5)))))))))) }
//line :48:1
func A_arbace_pprint_pprint_reader_macro_A_New() *A_arbace_pprint_pprint_reader_macro_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_reader_macro_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_pprint_pprint_reader_macro_A) Ctor() {}
//line :48:1
func (t *A_arbace_pprint_pprint_reader_macro_A) Invoke_O_O__O(self, alis__0 any) any { var macro_char__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_585.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(alis__0)); var tmp1 any; var and__1927000168__auto____3 any = macro_char__2; if

	jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(alis__0)))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(jrt.String_Cast(macro_char__2))
		lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(alis__0))
//line :50:1
		jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { return nil } }


func A_arbace_pprint_unzip_map_A_New() *A_arbace_pprint_unzip_map_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_unzip_map_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_pprint_unzip_map_A) Ctor() {}
//line :53:1
func (t *A_arbace_pprint_unzip_map_A) Invoke_O_O__O(self, m__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____2 any; var tmp5 any = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_New(); var tmp6 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_fn_class; if




	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_265, false); A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(m__0); var tmp7 any = /*line :53:1*/tmp1.Invoke_O_O__O(tmp3, tmp4); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp9 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp9 = lang.PersistentArrayMap_EMPTY; var tmp10 any = tmp9.Ref(); var tmp11 any; var iter__1927001039__auto____2_2 any; var tmp12 any = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_New(); var tmp13 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_fn_class; if





	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_266, false); A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_fn_class = fncls__6d; tmp13 = fncls__6d } else { tmp13 = fncls__6 }; iter__1927001039__auto____2_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); tmp11 = lang.IFn_Cast(iter__1927001039__auto____2_2).Invoke_O__O(m__0); return /*line :53:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8.Invoke_O_O__O(tmp10, tmp11)) }
func A_arbace_pprint_column_writer_A_New() *A_arbace_pprint_column_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_column_writer_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_pprint_column_writer_A) Ctor() {}
//line :54:1
func (t *A_arbace_pprint_column_writer_A) Invoke_O_O_O__O(self, writer__0, max_columns__1 any) any { var fields__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_pprint_A_const_48, max_columns__1, A_arbace_pprint_A_const_46, A_arbace_pprint_A_const_28, A_arbace_pprint_A_const_47, A_arbace_pprint_A_const_28, A_arbace_pprint_A_const_50, writer__0))); var p__840000142__auto____4 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_32), jrt.RefArrayOf(jrt.Object_class)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_53.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_column_writer_fn__44000019_A_New_O(fields__3); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_pprint_column_writer_fn__44000019_A_fn_class; if



	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_pprint_column_writer_fn__44000019_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = A_arbace_pprint_column_writer_fn__44000021_A_New_O(writer__0); var tmp6 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_pprint_column_writer_fn__44000021_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_pprint_column_writer_fn__44000021_A_fn_class = fncls__14d; tmp6 = fncls__14d } else { tmp6 = fncls__14 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_pprint_column_writer_fn__44000023_A_New(); var tmp9 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_pprint_column_writer_fn__44000023_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_pprint_column_writer_fn__44000023_A_fn_class = fncls__17d; tmp9 = fncls__17d } else { tmp9 = fncls__17 }; tmp1.Invoke_O_O__O(p__840000142__auto____4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_33, tmp4, Lit_13, tmp7, Lit_15, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)))); return p__840000142__auto____4 }
//line :54:1
func (t *A_arbace_pprint_column_writer_A) Invoke_O_O__O(self, writer__0 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_61.GetRawRoot__O()).Invoke_O_O__O(writer__0, A_arbace_pprint_A_const_62.Get__O())
}

func A_arbace_pprint_column_writer_fn__44000019_A_New_O(p0 any) *A_arbace_pprint_column_writer_fn__44000019_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_column_writer_fn__44000019_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_pprint_column_writer_fn__44000019_A) Ctor_O(c__fields any) { t.F_fields = c__fields }
//line :58:1
func (t *A_arbace_pprint_column_writer_fn__44000019_A) Invoke_O_O__O(self, this__1 any) any { return t.F_fields }
//line :58:1
func A_arbace_pprint_column_writer_fn__44000021_A_New_O(p0 any) *A_arbace_pprint_column_writer_fn__44000021_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_column_writer_fn__44000021_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_pprint_column_writer_fn__44000021_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :58:1
func (t *A_arbace_pprint_column_writer_fn__44000021_A) Invoke_O_O__O(self, this__1 any) any {


	jrt.Writer_Cast(t.F_writer).Flush__V(); return nil }
//line :58:1
func A_arbace_pprint_column_writer_fn__44000023_A_New() *A_arbace_pprint_column_writer_fn__44000023_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_column_writer_fn__44000023_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_pprint_column_writer_fn__44000023_A) Ctor() {}
//line :58:1
func (t *A_arbace_pprint_column_writer_fn__44000023_A) Invoke_O_O_O_O_O__O(self, this__1, cbuf__2, off__3, len__4 any) any { var writer__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(this__1, A_arbace_pprint_A_const_50);






	jrt.Writer_Cast(writer__5).Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](cbuf__2, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_O__I(off__3), lang.RT_IntCast_O__I(len__4)); return nil }
//line :58:1
func (t *A_arbace_pprint_column_writer_fn__44000023_A) Invoke_O_O_O__O(self, this__1, x__2 any) any { var pred__44000024__3 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__44000025__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(x__2); if








	jrt.A2g_Truth(lang.IFn_Cast(pred__44000024__3).Invoke_O_O__O(A_arbace_pprint_A_const_57, expr__44000025__4)) { var s__5 any = x__2; var nl__6 int32 = jrt.NN(jrt.String_Cast(s__5)).LastIndexOf_I__I(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_51)); var tmp1 any = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_New_O_I_O(s__5, nl__6, this__1); var tmp2 *jrt.Class
		var fncls__16 /*line :67:1*/*jrt.Class = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_fn_class



		if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil))





		jrt.Writer_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(this__1, A_arbace_pprint_A_const_50)).Write_String__V(jrt.String_Cast(s__5)); return nil } else {
//line :67:1
			if jrt.A2g_Truth(lang.IFn_Cast(pred__44000024__3).Invoke_O_O__O(A_arbace_pprint_A_const_59, expr__44000025__4)) {












				return lang.IFn_Cast(A_arbace_pprint_A_const_56.GetRawRoot__O()).Invoke_O_O__O(this__1, x__2) } else {
//line :67:1
					if jrt.A2g_Truth(lang.IFn_Cast(pred__44000024__3).Invoke_O_O__O(A_arbace_pprint_A_const_60, expr__44000025__4)) {














						return lang.IFn_Cast(A_arbace_pprint_A_const_56.GetRawRoot__O()).Invoke_O_O__O(this__1, x__2) } else {
//line :67:1
							panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__44000025__4))))) } } } }
//line :58:1
func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_New() *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A) Ctor() {}
//line :58:1
func (t *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A) Invoke_O_O__O(self, s__1470000015__1 any) any { var tmp1 any = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_New_O_O(s__1470000015__1, self); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_267, false); A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :58:1
func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_New_O_O(p0, p1 any) *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A{}; t.Ctor_O_O(p0, p1); return t }
//line :58:1
func (t *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A) Ctor_O_O(c__s__1470000015, c__iter__1470000014 any) { t.F_s__1470000015 = c__s__1470000015; t.F_iter__1470000014 = c__iter__1470000014 }
//line :58:1
func (t *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A) Invoke_O__O(self any) any { { var s__1470000015__1 any; var t_ any = t.F_s__1470000015; t.F_s__1470000015 = nil; s__1470000015__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(s__1470000015__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1470000015__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(s__1470000015__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(s__1470000015__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1470000017__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1470000017__6); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_268, false); A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1470000014); return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1470000017__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1470000015__3))) } else { return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1470000017__6), nil) } } else { var vec__1470000028__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__1470000015__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1470000028__4, lang.RT_IntCast_J__I(0), nil); var vec__1470000031__6 any = lang.RT_Nth_O_I_O__O(vec__1470000028__4, lang.RT_IntCast_J__I(1), nil); var v1__7 any = lang.RT_Nth_O_I_O__O(vec__1470000031__6, lang.RT_IntCast_J__I(0), nil); var v2__8 any = lang.RT_Nth_O_I_O__O(vec__1470000031__6, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1470000014); _ = v2__8; return lang.IFn_Cast(A_arbace_pprint_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(k__5, v1__7), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(s__1470000015__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :58:1
func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :58:1
func (t *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1470000017 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1470000017 = c__b__1470000017 }
//line :58:1
func (t *A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A) Invoke_O__O(self any) any { { var i__1470000016__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1470000016__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1470000021__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1470000016__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1470000021__2, lang.RT_IntCast_J__I(0), nil); var vec__1470000024__4 any = lang.RT_Nth_O_I_O__O(vec__1470000021__2, lang.RT_IntCast_J__I(1), nil); var v1__5 any = lang.RT_Nth_O_I_O__O(vec__1470000024__4, lang.RT_IntCast_J__I(0), nil); var v2__6 any = lang.RT_Nth_O_I_O__O(vec__1470000024__4, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_21.GetRawRoot__O()); var tmp3 any = t.F_b__1470000017; _ = v2__6; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(k__3, v1__5)); i__1470000016__1 = lang.Numbers_Unchecked_inc_J__J(i__1470000016__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
//line :58:1
func A_arbace_pprint_write_to_base_A_New() *A_arbace_pprint_write_to_base_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_to_base_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_pprint_write_to_base_A) Ctor() {}
//line :58:1
func (t *A_arbace_pprint_write_to_base_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, args__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_88.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_89; return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_87), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_33.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_90), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_91)))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_92), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_50)))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_93), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_89), args__2))))) }
func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_New() *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A) Ctor() {}
//line :59:1
func (t *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A) Invoke_O_O__O(self, s__1470000037__1 any) any { var tmp1 any = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_New_O_O(s__1470000037__1, self); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_269, false); A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :59:1
func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_New_O_O(p0, p1 any) *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A{}; t.Ctor_O_O(p0, p1); return t }
//line :59:1
func (t *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A) Ctor_O_O(c__s__1470000037, c__iter__1470000036 any) { t.F_s__1470000037 = c__s__1470000037; t.F_iter__1470000036 = c__iter__1470000036 }
//line :59:1
func (t *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A) Invoke_O__O(self any) any { { var s__1470000037__1 any; var t_ any = t.F_s__1470000037; t.F_s__1470000037 = nil; s__1470000037__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(s__1470000037__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1470000037__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(s__1470000037__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(s__1470000037__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1470000039__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1470000039__6); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_270, false); A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1470000036); return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1470000039__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1470000037__3))) } else { return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1470000039__6), nil) } } else { var vec__1470000050__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__1470000037__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1470000050__4, lang.RT_IntCast_J__I(0), nil); var vec__1470000053__6 any = lang.RT_Nth_O_I_O__O(vec__1470000050__4, lang.RT_IntCast_J__I(1), nil); var v1__7 any = lang.RT_Nth_O_I_O__O(vec__1470000053__6, lang.RT_IntCast_J__I(0), nil); var v2__8 any = lang.RT_Nth_O_I_O__O(vec__1470000053__6, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1470000036); _ = v1__7; return lang.IFn_Cast(A_arbace_pprint_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(k__5, v2__8), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(s__1470000037__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :59:1
func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :59:1
func (t *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1470000039 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1470000039 = c__b__1470000039 }
//line :59:1
func (t *A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A) Invoke_O__O(self any) any { { var i__1470000038__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1470000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1470000043__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1470000038__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1470000043__2, lang.RT_IntCast_J__I(0), nil); var vec__1470000046__4 any = lang.RT_Nth_O_I_O__O(vec__1470000043__2, lang.RT_IntCast_J__I(1), nil); var v1__5 any = lang.RT_Nth_O_I_O__O(vec__1470000046__4, lang.RT_IntCast_J__I(0), nil); var v2__6 any = lang.RT_Nth_O_I_O__O(vec__1470000046__4, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_21.GetRawRoot__O()); var tmp3 any = t.F_b__1470000039; _ = v1__5; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(k__3, v2__6)); i__1470000038__1 = lang.Numbers_Unchecked_inc_J__J(i__1470000038__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_pprint_tuple_map_A_New() *A_arbace_pprint_tuple_map_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_tuple_map_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_pprint_tuple_map_A) Ctor() {}
//line :61:1
func (t *A_arbace_pprint_tuple_map_A) Invoke_O_O_O__O(self, m__0, v1__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____3 any; var tmp5 any = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_New_O(v1__1); var tmp6 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_259, false); A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_fn_class = fncls__9d; tmp6 = fncls__9d } else { tmp6 = fncls__9 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(m__0); return tmp1.Invoke_O_O__O(tmp3, tmp4) }
//line :64:1
func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_New_O(p0 any) *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A{}; t.Ctor_O(p0); return t }
//line :64:1
func (t *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A) Ctor_O(c__v1 any) { t.F_v1 = c__v1 }
//line :64:1
func (t *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A) Invoke_O_O__O(self, s__1470000060__1 any) any { var tmp1 any = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_New_O_O_O(s__1470000060__1, self, t.F_v1); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_260, false); A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :64:1
func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :64:1
func (t *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A) Ctor_O_O_O(c__s__1470000060, c__iter__1470000059, c__v1 any) { t.F_s__1470000060 = c__s__1470000060; t.F_iter__1470000059 = c__iter__1470000059; t.F_v1 = c__v1 }
//line :64:1
func (t *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A) Invoke_O__O(self any) any { { var s__1470000060__1 any; var t_ any = t.F_s__1470000060; t.F_s__1470000060 = nil; s__1470000060__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(s__1470000060__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1470000060__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(s__1470000060__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(s__1470000060__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1470000062__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_New_O_O_I_O(b__1470000062__6, t.F_v1, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_261, false); A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1470000059); return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1470000062__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1470000060__3))) } else { return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1470000062__6), nil) } } else { var vec__1470000070__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__1470000060__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1470000070__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1470000070__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1470000059); return lang.IFn_Cast(A_arbace_pprint_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(k__5, lang.Tuple_Create_O_O__IPersistentVector(v__6, t.F_v1)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(s__1470000060__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :64:1
func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :64:1
func (t *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A) Ctor_O_O_I_O(c__b__1470000062, c__v1 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1470000062 = c__b__1470000062; t.F_v1 = c__v1; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :64:1
func (t *A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A) Invoke_O__O(self any) any { { var i__1470000061__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1470000061__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1470000066__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1470000061__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1470000066__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1470000066__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_21.GetRawRoot__O()); var tmp3 any = t.F_b__1470000062; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(k__3, lang.Tuple_Create_O_O__IPersistentVector(v__4, t.F_v1))); i__1470000061__1 = lang.Numbers_Unchecked_inc_J__J(i__1470000061__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_pprint_pprint_meta_A_New() *A_arbace_pprint_pprint_meta_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_meta_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_pprint_pprint_meta_A) Ctor() {}
//line :66:1
func (t *A_arbace_pprint_pprint_meta_A) Invoke_O_O__O(self, obj__0 any) any {
	if jrt.A2g_Truth(A_arbace_pprint_A_const_586.Get__O()) { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap(obj__0)
		if jrt.A2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2
			jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_178)
			lang.IFn_Cast(A_arbace_pprint_A_const_587.GetRawRoot__O()).Invoke_O__O(m__3)
			jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)
			return lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439) } else {
//line :68:1
				return nil } } else {
//line :67:1
					return nil } }
//line :66:1
func A_arbace_pprint_rtrim_A_New() *A_arbace_pprint_rtrim_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_rtrim_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_pprint_rtrim_A) Ctor() {}
//line :66:1
func (t *A_arbace_pprint_rtrim_A) Invoke_O_O_O__O(self, s__0, c__1 any) any { { var len__3 int32 = lang.RT_Count_O__I(s__0); var tmp1 bool; var and__1927000168__auto____4 bool = lang.Numbers_IsPos_J__Z(int64(len__3))



	if and__1927000168__auto____4 { tmp1 = lang.Util_Equiv_O_O__Z(lang.RT_Nth_O_I__O(s__0, lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(s__0))))), c__1) } else { tmp1 = and__1927000168__auto____4 }; if tmp1 { var n__4 int64 = lang.Numbers_Dec_J__J(int64(len__3)); L1: for {

		if lang.Numbers_IsNeg_J__Z(n__4) { return Lit_43 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.RT_Nth_O_I__O(s__0, lang.RT_IntCast_J__I(n__4)), c__1)).Ref())) {

			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_A_const_28; return tmp2.Invoke_O_O_O__O(s__0, tmp3, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(n__4)).Ref()) } else {
//line :72:1
				var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp4.Ref()) {


					n__4 = lang.Numbers_Dec_J__J(n__4); continue L1 } else {
//line :72:1
						return nil } } } } } else {
//line :70:1
							return s__0 } }; /*line :66:1*/panic("a2g: unreachable") }
func A_arbace_pprint_format_error_A_New() *A_arbace_pprint_format_error_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_error_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_pprint_format_error_A) Ctor() {}
//line :67:1
func (t *A_arbace_pprint_format_error_A) Invoke_O_O_O__O(self, message__0, offset__1 any) any { var full_message__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,ns1:\nns1:\nns1:^s1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, message__0, nil, A_arbace_pprint_A_const_298.Get__O(), nil, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(offset__1, A_arbace_pprint_A_const_148)), nil, nil)).Ref(); panic(jrt.Thrown(jrt.RuntimeException_New_String(jrt.String_Cast(full_message__3)))) }



func A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A) Ctor_O_I_O(c__s any, c__nl int32, c__this any) { t.F_s = c__s; t.F_nl = c__nl; t.F_this = c__this }
//line :71:1
func (t *A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A) Invoke_O__O(self any) any { if lang.Numbers_IsNeg_J__Z(int64(t.F_nl)) {
												var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_49.GetRawRoot__O()); var tmp2 any = t.F_this; var tmp3 any = A_arbace_pprint_A_const_46; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.Numbers_Add_O_J__Number(lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(t.F_this, A_arbace_pprint_A_const_46), int64(lang.RT_Count_O__I(t.F_s)))) } else {

		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_49.GetRawRoot__O()); var tmp5 any = t.F_this; var tmp6 any = A_arbace_pprint_A_const_46; tmp4.Invoke_O_O_O__O(tmp5, tmp6, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(t.F_s)), int64(t.F_nl)), 1)).Ref())
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_49.GetRawRoot__O()); var tmp8 any = t.F_this; var tmp9 any = A_arbace_pprint_A_const_47; var tmp10 any = lang.IFn_Cast(A_arbace_pprint_A_const_45.GetRawRoot__O()).Invoke_O_O__O(t.F_this, A_arbace_pprint_A_const_47); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_58.GetRawRoot__O()); var tmp12 any = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_New(); var tmp13 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_fn_class
		if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_fn_class = fncls__15d; tmp13 = fncls__15d } else { tmp13 = fncls__15 }
//line :75:1
		return tmp7.Invoke_O_O_O__O(tmp8, tmp9, lang.Numbers_Add_O_J__Number(tmp10, int64(lang.RT_Count_O__I(tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), t.F_s))))) } }
//line :75:1
func A_arbace_pprint_pprint_simple_list_A_New() *A_arbace_pprint_pprint_simple_list_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_simple_list_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_pprint_pprint_simple_list_A) Ctor() {}
//line :75:1
func (t *A_arbace_pprint_pprint_simple_list_A) Invoke_O_O__O(self, alis__0 any) any {
	lang.IFn_Cast(A_arbace_pprint_A_const_588.GetRawRoot__O()).Invoke_O__O(alis__0)
	if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_simple_list_fn__740000005_A_New_O(alis__0); var tmp3 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_pprint_pprint_simple_list_fn__740000005_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_205, false); A_arbace_pprint_pprint_simple_list_fn__740000005_A_fn_class = fncls__116d; tmp3 = fncls__116d } else { tmp3 = fncls__116 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :75:1
	return nil }
func A_arbace_pprint_ancestor_QMARK__A_New() *A_arbace_pprint_ancestor_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_ancestor_QMARK__A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_pprint_ancestor_QMARK__A) Ctor() {}
//line :76:1
func (t *A_arbace_pprint_ancestor_QMARK__A) Invoke_O_O_O__O(self, parent__0, child__1 any) any { { var child__3 any = A_arbace_pprint_A_const_94.Invoke_O__O(child__1); L1: for {

	if lang.Util_Identical_O_O__Z(child__3, nil) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z(parent__0, child__3) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if A_arbace_pprint_A_const_95 != nil {


		child__3 = A_arbace_pprint_A_const_94.Invoke_O__O(child__3); continue L1 } else {
//line :78:1
			return nil } } } } }; /*line :76:1*/panic("a2g: unreachable") }
//line :76:1
func A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_New() *A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A) Ctor() {}
//line :76:1
func (t *A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A) Invoke_O_O__O(self, p1__44000018_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(p1__44000018_SHARP___1, A_arbace_pprint_A_const_51)).Ref() }
func A_arbace_pprint_pprint_simple_list_fn__740000005_A_New_O(p0 any) *A_arbace_pprint_pprint_simple_list_fn__740000005_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_simple_list_fn__740000005_A{}; t.Ctor_O(p0); return t }
//line :77:1
func (t *A_arbace_pprint_pprint_simple_list_fn__740000005_A) Ctor_O(c__alis any) { t.F_alis = c__alis }
//line :77:1
func (t *A_arbace_pprint_pprint_simple_list_fn__740000005_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_102, nil, Lit_103); var length_count740000006__3 int64 = 0; var alis__4 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_alis
											t.F_alis = nil; tmp4 = t_; alis__4 = tmp3.Invoke_O__O(tmp4)
//line :77:1
L1: for {
	var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_214.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_O__Z(length_count740000006__3, A_arbace_pprint_A_const_214.Get__O())).Ref() }; if jrt.A2g_Truth(tmp5) { if jrt.A2g_Truth(alis__4) {

		lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(alis__4))
//line :78:1
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(alis__4)) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)




			lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :78:1
			length_count740000006__3, alis__4 = lang.Numbers_Inc_J__J(length_count740000006__3), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(alis__4); continue L1 } } } else { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_154) }
//line :77:1
	break L1 }; var tmp6 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp6.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }
func A_arbace_pprint_ltrim_A_New() *A_arbace_pprint_ltrim_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_ltrim_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_pprint_ltrim_A) Ctor() {}
//line :78:1
func (t *A_arbace_pprint_ltrim_A) Invoke_O_O_O__O(self, s__0, c__1 any) any { { var len__3 int32 = lang.RT_Count_O__I(s__0); var tmp1 bool; var and__1927000168__auto____4 bool = lang.Numbers_IsPos_J__Z(int64(len__3))



	if and__1927000168__auto____4 { tmp1 = lang.Util_Equiv_O_O__Z(lang.RT_Nth_O_I__O(s__0, lang.RT_IntCast_J__I(0)), c__1) } else { tmp1 = and__1927000168__auto____4 }; if tmp1 { var n__4 int64 = 0; L1: for {

		var tmp2 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_J_J__Z(n__4, int64(len__3)); if or__1927000174__auto____5 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { tmp2 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.RT_Nth_O_I__O(s__0, lang.RT_IntCast_J__I(n__4)), c__1)).Ref()) }; if jrt.A2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__0, jrt.Long_ValueOf_J__Long(n__4).Ref()) } else {
				n__4 = lang.Numbers_Inc_J__J(n__4); continue L1 } } } else {
//line :82:1
					return s__0 } }; /*line :78:1*/panic("a2g: unreachable") }


func A_arbace_pprint_init_navigator_A_New() *A_arbace_pprint_init_navigator_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_init_navigator_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_pprint_init_navigator_A) Ctor() {}
//line :81:1
func (t *A_arbace_pprint_init_navigator_A) Invoke_O_O__O(self, s__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(s__0); return /*line :86:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_299.GetRawRoot__O(), s__2, s__2, A_arbace_pprint_A_const_28) }
//line :85:1
func A_arbace_pprint_buffer_length_A_New() *A_arbace_pprint_buffer_length_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_buffer_length_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_pprint_buffer_length_A) Ctor() {}
//line :85:1
func (t *A_arbace_pprint_buffer_length_A) Invoke_O_O__O(self, l__0 any) any { var l__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(l__0); if

	jrt.A2g_Truth(l__2) {
		var tmp1 *lang.Keyword = A_arbace_pprint_A_const_96; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_98; return lang.Numbers_Minus_O_O__Number(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_97.GetRawRoot__O()).Invoke_O__O(l__2)), tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(l__2))) } else {
//line :87:1
			return A_arbace_pprint_A_const_28 } }
//line :86:1
func A_arbace_pprint_pprint_list_A_New() *A_arbace_pprint_pprint_list_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_list_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_pprint_pprint_list_A) Ctor() {}
//line :86:1
func (t *A_arbace_pprint_pprint_list_A) Invoke_O_O__O(self, alis__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_590.GetRawRoot__O()).Invoke_O__O(alis__0))) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_589.GetRawRoot__O()).Invoke_O__O(alis__0) } else {
//line :87:1
			return nil
		} }
func A_arbace_pprint_next_arg_A_New() *A_arbace_pprint_next_arg_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_next_arg_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_pprint_next_arg_A) Ctor() {}
//line :89:1
func (t *A_arbace_pprint_next_arg_A) Invoke_O_O__O(self, navigator__0 any) any { var rst__2 any = A_arbace_pprint_A_const_300.Invoke_O__O(navigator__0); if

	jrt.A2g_Truth(rst__2) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(rst__2), lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_299.GetRawRoot__O(), A_arbace_pprint_A_const_301.Invoke_O__O(navigator__0), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(rst__2), lang.Numbers_Inc_O__Number(A_arbace_pprint_A_const_163.Invoke_O__O(navigator__0)))) } else { panic(jrt.Thrown(jrt.Exception_New_String(Lit_139))) } }
//line :89:1
func A_arbace_pprint_prefix_count_A_New() *A_arbace_pprint_prefix_count_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_prefix_count_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_pprint_prefix_count_A) Ctor() {}
//line :89:1
func (t *A_arbace_pprint_prefix_count_A) Invoke_O_O_O__O(self, aseq__0, val__1 any) any { { var test__3 any




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_29.GetRawRoot__O()).Invoke_O__O(val__1)) { test__3 = lang.IFn_Cast(A_arbace_pprint_A_const_30.GetRawRoot__O()).Invoke_O__O(val__1) } else { test__3 = lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, val__1)) }
//line :89:1
	var pos__4 int64 = 0; L1: for {






		var tmp1 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_J_J__Z(pos__4, int64(lang.RT_Count_O__I(aseq__0))); if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(test__3).Invoke_O__O(lang.RT_Nth_O_I__O(aseq__0, lang.RT_IntCast_J__I(pos__4)))) }; if jrt.A2g_Truth(tmp1) { return jrt.Long_ValueOf_J__Long(pos__4).Ref() } else {

			pos__4 = lang.Numbers_Inc_J__J(pos__4); continue L1 } } }; /*line :89:1*/panic("a2g: unreachable") }

func A_arbace_pprint_pprint_vector_A_New() *A_arbace_pprint_pprint_vector_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_vector_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_pprint_pprint_vector_A) Ctor() {}
//line :91:1
func (t *A_arbace_pprint_pprint_vector_A) Invoke_O_O__O(self, avec__0 any) any {
	lang.IFn_Cast(A_arbace_pprint_A_const_588.GetRawRoot__O()).Invoke_O__O(avec__0)
	if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_vector_fn__740000010_A_New_O(avec__0); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_pprint_pprint_vector_fn__740000010_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_207, false); A_arbace_pprint_pprint_vector_fn__740000010_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :91:1
	return nil }
func A_arbace_pprint_buffer_blob_QMARK__A_New() *A_arbace_pprint_buffer_blob_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_buffer_blob_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_pprint_buffer_blob_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_pprint_buffer_blob_QMARK__A) Invoke_O_O__O(self, x__1820000017__auto____0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_71.Invoke_O__O(x__1820000017__auto____0), A_arbace_pprint_A_const_101)).Ref() }
//line :92:1
func A_arbace_pprint_make_buffer_blob_A_New() *A_arbace_pprint_make_buffer_blob_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_make_buffer_blob_A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_pprint_make_buffer_blob_A) Ctor() {}
//line :92:1
func (t *A_arbace_pprint_make_buffer_blob_A) DoInvoke_O_O__O(self, vals__1820000016__auto____0 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_99.GetRawRoot__O(), A_arbace_pprint_A_const_100.GetRawRoot__O(), A_arbace_pprint_A_const_101, vals__1820000016__auto____0) }
func A_arbace_pprint_pprint_vector_fn__740000010_A_New_O(p0 any) *A_arbace_pprint_pprint_vector_fn__740000010_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_vector_fn__740000010_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_pprint_pprint_vector_fn__740000010_A) Ctor_O(c__avec any) { t.F_avec = c__avec }
//line :93:1
func (t *A_arbace_pprint_pprint_vector_fn__740000010_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_151, nil, Lit_152); var length_count740000011__3 int64 = 0; var aseq__4 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_avec
											t.F_avec = nil; tmp4 = t_; aseq__4 = tmp3.Invoke_O__O(tmp4)
//line :93:1
L1: for {
	var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_214.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_O__Z(length_count740000011__3, A_arbace_pprint_A_const_214.Get__O())).Ref() }; if jrt.A2g_Truth(tmp5) { if jrt.A2g_Truth(aseq__4) {

		lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(aseq__4))
//line :94:1
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(aseq__4)) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)




			lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :94:1
			length_count740000011__3, aseq__4 = lang.Numbers_Inc_J__J(length_count740000011__3), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(aseq__4); continue L1 } } } else { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_154) }
//line :93:1
	break L1 }; var tmp6 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp6.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }

func A_arbace_pprint_make_nl_t_A_New() *A_arbace_pprint_make_nl_t_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_make_nl_t_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_pprint_make_nl_t_A) Ctor() {}
//line :95:1
func (t *A_arbace_pprint_make_nl_t_A) DoInvoke_O_O__O(self, vals__1820000016__auto____0 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_99.GetRawRoot__O(), A_arbace_pprint_A_const_102.GetRawRoot__O(), A_arbace_pprint_A_const_103, vals__1820000016__auto____0) }
//line :95:1
func A_arbace_pprint_next_arg_or_nil_A_New() *A_arbace_pprint_next_arg_or_nil_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_next_arg_or_nil_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_pprint_next_arg_or_nil_A) Ctor() {}
//line :95:1
func (t *A_arbace_pprint_next_arg_or_nil_A) Invoke_O_O__O(self, navigator__0 any) any { var rst__2 any = A_arbace_pprint_A_const_300.Invoke_O__O(navigator__0); if

	jrt.A2g_Truth(rst__2) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(rst__2), lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_299.GetRawRoot__O(), A_arbace_pprint_A_const_301.Invoke_O__O(navigator__0), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(rst__2), lang.Numbers_Inc_O__Number(A_arbace_pprint_A_const_163.Invoke_O__O(navigator__0)))) } else { return lang.Tuple_Create_O_O__IPersistentVector(nil, navigator__0) } }
//line :95:1
func A_arbace_pprint_nl_t_QMARK__A_New() *A_arbace_pprint_nl_t_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_nl_t_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_pprint_nl_t_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_pprint_nl_t_QMARK__A) Invoke_O_O__O(self, x__1820000017__auto____0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_71.Invoke_O__O(x__1820000017__auto____0), A_arbace_pprint_A_const_103)).Ref() }

func A_arbace_pprint_make_start_block_t_A_New() *A_arbace_pprint_make_start_block_t_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_make_start_block_t_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_pprint_make_start_block_t_A) Ctor() {}
//line :97:1
func (t *A_arbace_pprint_make_start_block_t_A) DoInvoke_O_O__O(self, vals__1820000016__auto____0 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_99.GetRawRoot__O(), A_arbace_pprint_A_const_104.GetRawRoot__O(), A_arbace_pprint_A_const_105, vals__1820000016__auto____0) }
//line :97:1
func A_arbace_pprint_start_block_t_QMARK__A_New() *A_arbace_pprint_start_block_t_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_start_block_t_QMARK__A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_pprint_start_block_t_QMARK__A) Ctor() {}
//line :97:1
func (t *A_arbace_pprint_start_block_t_QMARK__A) Invoke_O_O__O(self, x__1820000017__auto____0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_71.Invoke_O__O(x__1820000017__auto____0), A_arbace_pprint_A_const_105)).Ref() }

func A_arbace_pprint_end_block_t_QMARK__A_New() *A_arbace_pprint_end_block_t_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_end_block_t_QMARK__A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_pprint_end_block_t_QMARK__A) Ctor() {}
//line :99:1
func (t *A_arbace_pprint_end_block_t_QMARK__A) Invoke_O_O__O(self, x__1820000017__auto____0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_71.Invoke_O__O(x__1820000017__auto____0), A_arbace_pprint_A_const_107)).Ref() }
//line :99:1
func A_arbace_pprint_make_end_block_t_A_New() *A_arbace_pprint_make_end_block_t_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_make_end_block_t_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_pprint_make_end_block_t_A) Ctor() {}
//line :99:1
func (t *A_arbace_pprint_make_end_block_t_A) DoInvoke_O_O__O(self, vals__1820000016__auto____0 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_99.GetRawRoot__O(), A_arbace_pprint_A_const_106.GetRawRoot__O(), A_arbace_pprint_A_const_107, vals__1820000016__auto____0) }
func A_arbace_pprint_prerr_A_New() *A_arbace_pprint_prerr_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_prerr_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_pprint_prerr_A) Ctor() {}
//line :100:1
func (t *A_arbace_pprint_prerr_A) DoInvoke_O_O__O(self, args__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_34; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_pprint_A_const_35.Get__O()))
//line :100:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		tmp3 = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_36.GetRawRoot__O(), args__0)
//line :100:1
		return nil
	}()

	lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O()
//line :100:1
	if tmp4 != nil { panic(tmp4) }; return tmp3 }
func A_arbace_pprint_indent_t_QMARK__A_New() *A_arbace_pprint_indent_t_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_indent_t_QMARK__A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_pprint_indent_t_QMARK__A) Ctor() {}
//line :101:1
func (t *A_arbace_pprint_indent_t_QMARK__A) Invoke_O_O__O(self, x__1820000017__auto____0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_71.Invoke_O__O(x__1820000017__auto____0), A_arbace_pprint_A_const_109)).Ref() }
//line :101:1
func A_arbace_pprint_make_indent_t_A_New() *A_arbace_pprint_make_indent_t_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_make_indent_t_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_pprint_make_indent_t_A) Ctor() {}
//line :101:1
func (t *A_arbace_pprint_make_indent_t_A) DoInvoke_O_O__O(self, vals__1820000016__auto____0 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_99.GetRawRoot__O(), A_arbace_pprint_A_const_108.GetRawRoot__O(), A_arbace_pprint_A_const_109, vals__1820000016__auto____0) }
func A_arbace_pprint_fn__740000014_A_New() *A_arbace_pprint_fn__740000014_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__740000014_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_pprint_fn__740000014_A) Ctor() {}
//line :102:1
func (t *A_arbace_pprint_fn__740000014_A) Invoke_O__O(self any) any { var format_in__1819000595__auto____1 any = Lit_91; var cf__1819000596__auto____2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____1)) { cf__1819000596__auto____2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____1) } else { cf__1819000596__auto____2 = format_in__1819000595__auto____1 }; var tmp1 any = A_arbace_pprint_fn__740000014_fn__740000015_A_New_O(cf__1819000596__auto____2); var tmp2 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_pprint_fn__740000014_fn__740000015_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, true); A_arbace_pprint_fn__740000014_fn__740000015_A_fn_class = fncls__118d; tmp2 = fncls__118d } else { tmp2 = fncls__118 }; return lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 0) }
//line :102:1
func A_arbace_pprint_fn__740000014_fn__740000015_A_New_O(p0 any) *A_arbace_pprint_fn__740000014_fn__740000015_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__740000014_fn__740000015_A{}; t.Ctor_O(p0); return t }
//line :102:1
func (t *A_arbace_pprint_fn__740000014_fn__740000015_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :102:1
func (t *A_arbace_pprint_fn__740000014_fn__740000015_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
//line :102:1
func A_arbace_pprint_get_format_arg_A_New() *A_arbace_pprint_get_format_arg_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_format_arg_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_pprint_get_format_arg_A) Ctor() {}
//line :102:1
func (t *A_arbace_pprint_get_format_arg_A) Invoke_O_O__O(self, navigator__0 any) any { var vec__1819000007__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__0); var raw_format__3 any = lang.RT_Nth_O_I_O__O(vec__1819000007__2, lang.RT_IntCast_J__I(0), nil); var navigator__4 any = lang.RT_Nth_O_I_O__O(vec__1819000007__2, lang.RT_IntCast_J__I(1), nil); var compiled_format__5 any; if

	jrt.String_InstanceOf(raw_format__3) {
		compiled_format__5 = lang.IFn_Cast(A_arbace_pprint_A_const_295.GetRawRoot__O()).Invoke_O__O(raw_format__3) } else {
//line :104:1
			compiled_format__5 = raw_format__3 }; return /*line :102:1*/ lang.Tuple_Create_O_O__IPersistentVector(compiled_format__5, navigator__4) }


func A_arbace_pprint_pprint_map_A_New() *A_arbace_pprint_pprint_map_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_map_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_pprint_pprint_map_A) Ctor() {}
//line :105:1
func (t *A_arbace_pprint_pprint_map_A) Invoke_O_O__O(self, amap__0 any) any {
	lang.IFn_Cast(A_arbace_pprint_A_const_588.GetRawRoot__O()).Invoke_O__O(amap__0)
//line :105:1
	var vec__740000018__2 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_593.GetRawRoot__O()).Invoke_O__O(amap__0))) {
		vec__740000018__2 = A_arbace_pprint_A_const_592.Invoke_O__O(amap__0) } else {
//line :107:1
			vec__740000018__2 = nil }
//line :105:1
	var ns__3 any = lang.RT_Nth_O_I_O__O(vec__740000018__2, lang.RT_IntCast_J__I(0), nil); var lift_map__4 any = lang.RT_Nth_O_I_O__O(vec__740000018__2, lang.RT_IntCast_J__I(1), nil); var amap__5 any
	var or__1927000174__auto____5 any = lift_map__4


	if jrt.A2g_Truth(or__1927000174__auto____5) { amap__5 = or__1927000174__auto____5 } else { amap__5 = amap__0 }
//line :105:1
	var prefix__6 any




	if jrt.A2g_Truth(ns__3) { prefix__6 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_173, nil, Lit_174), jrt.RefArrayOf(jrt.Object_class, nil, ns__3, nil)).Ref() } else { prefix__6 = Lit_174 }
	if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_map_fn__740000021_A_New_O_O(prefix__6, amap__5); var tmp3 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_pprint_pprint_map_fn__740000021_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_175, false); A_arbace_pprint_pprint_map_fn__740000021_A_fn_class = fncls__120d; tmp3 = fncls__120d } else { tmp3 = fncls__120 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :105:1
	return nil }
func A_arbace_pprint_prlabel_A_New() *A_arbace_pprint_prlabel_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_prlabel_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_pprint_prlabel_A) Ctor() {}
//line :106:1
func (t *A_arbace_pprint_prlabel_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, prefix__2, arg__3, more_args__4 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_39); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_23.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_41, prefix__2); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_40.GetRawRoot__O()); var tmp7 any = A_arbace_pprint_prlabel_fn__1470000081_A_New(); var tmp8 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_pprint_prlabel_fn__1470000081_A_fn_class; if


	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_238, false); A_arbace_pprint_prlabel_fn__1470000081_A_fn_class = fncls__10d; tmp8 = fncls__10d } else { tmp8 = fncls__10 }; return /*line :106:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.IFn_Cast(A_arbace_pprint_A_const_23.GetRawRoot__O()).Invoke_O_O__O(arg__3, lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(more_args__4)))))) }
func A_arbace_pprint_fn__1820000051_A_New() *A_arbace_pprint_fn__1820000051_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1820000051_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_pprint_fn__1820000051_A) Ctor() {}
//line :107:1
func (t *A_arbace_pprint_fn__1820000051_A) Invoke_O__O(self any) any { return jrt.System_GetProperty_String__String(Lit_90).Ref() }

func A_arbace_pprint_pr_with_base_A_New() *A_arbace_pprint_pr_with_base_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pr_with_base_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_pprint_pr_with_base_A) Ctor() {}
//line :109:1
func (t *A_arbace_pprint_pr_with_base_A) Invoke_O_O__O(self, x__0 any) any { var temp__1927000408__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_183.GetRawRoot__O()).Invoke_O__O(x__0); if
										jrt.A2g_Truth(temp__1927000408__auto____2) { var s__3 any = temp__1927000408__auto____2
											return lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(s__3) } else {
												return lang.IFn_Cast(A_arbace_pprint_A_const_185.GetRawRoot__O()).Invoke_O__O(x__0) } }
//line :109:1
func A_arbace_pprint_prlabel_fn__1470000081_A_New() *A_arbace_pprint_prlabel_fn__1470000081_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_prlabel_fn__1470000081_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_pprint_prlabel_fn__1470000081_A) Ctor() {}
//line :109:1
func (t *A_arbace_pprint_prlabel_fn__1470000081_A) Invoke_O_O__O(self, p1__1470000080_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_42, p1__1470000080_SHARP___1), Lit_239, p1__1470000080_SHARP___1) }

func A_arbace_pprint_absolute_reposition_A_New() *A_arbace_pprint_absolute_reposition_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_absolute_reposition_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_pprint_absolute_reposition_A) Ctor() {}
//line :111:1
func (t *A_arbace_pprint_absolute_reposition_A) Invoke_O_O_O__O(self, navigator__0, position__1 any) any {
	if lang.Numbers_Gte_O_O__Z(position__1, A_arbace_pprint_A_const_163.Invoke_O__O(navigator__0)) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_303.GetRawRoot__O()).Invoke_O_O__O(navigator__0, lang.Numbers_Minus_O_O__Number(position__1, A_arbace_pprint_A_const_163.Invoke_O__O(navigator__0))) } else {
			return lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_299.GetRawRoot__O(), A_arbace_pprint_A_const_301.Invoke_O__O(navigator__0), lang.IFn_Cast(A_arbace_pprint_A_const_142.GetRawRoot__O()).Invoke_O_O__O(position__1, A_arbace_pprint_A_const_301.Invoke_O__O(navigator__0)), position__1) } }
//line :111:1
func A_arbace_pprint_eval1820000055_fn__1820000056_A_New() *A_arbace_pprint_eval1820000055_fn__1820000056_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000055_fn__1820000056_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_pprint_eval1820000055_fn__1820000056_A) Ctor() {}
//line :111:1
func (t *A_arbace_pprint_eval1820000055_fn__1820000056_A) Invoke_O_O_O__O(self, p1__1820000054_SHARP___1, p2__1820000053_SHARP___2 any) any { return A_arbace_pprint_A_const_71.Invoke_O__O(p2__1820000053_SHARP___2) }
//line :111:1
func A_arbace_pprint_pprint_map_fn__740000021_A_New_O_O(p0, p1 any) *A_arbace_pprint_pprint_map_fn__740000021_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_map_fn__740000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :111:1
func (t *A_arbace_pprint_pprint_map_fn__740000021_A) Ctor_O_O(c__prefix, c__amap any) { t.F_prefix = c__prefix; t.F_amap = c__amap }
//line :111:1
func (t *A_arbace_pprint_pprint_map_fn__740000021_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; var tmp3 any = A_arbace_pprint_A_const_34.Get__O(); var tmp4 any; var t_ any = t.F_prefix; t.F_prefix = nil; tmp4 = t_; tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, nil, Lit_176); var length_count740000022__3 int64 = 0; var aseq__4 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_amap
										t.F_amap = nil; tmp6 = t__2; aseq__4 = tmp5.Invoke_O__O(tmp6)
//line :111:1
L1: for {
	var tmp7 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_214.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_O__Z(length_count740000022__3, A_arbace_pprint_A_const_214.Get__O())).Ref() }; if jrt.A2g_Truth(tmp7) { if jrt.A2g_Truth(aseq__4) { if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp8 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp9 any = A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_New_O(aseq__4); var tmp10 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_177, false); A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_fn_class = fncls__119d; tmp10 = fncls__119d } else { tmp10 = fncls__119 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O() }; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(aseq__4)) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_3)









		lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :112:1
		length_count740000022__3, aseq__4 = lang.Numbers_Inc_J__J(length_count740000022__3), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(aseq__4); continue L1 } } } else { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_154) }
//line :111:1
	break L1 }; var tmp11 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp11.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp12 != nil { panic(tmp12) }; return tmp1 }
func A_arbace_pprint_eval1820000059_fn__1820000060_A_New() *A_arbace_pprint_eval1820000059_fn__1820000060_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000059_fn__1820000060_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_pprint_eval1820000059_fn__1820000060_A) Ctor() {}
//line :112:1
func (t *A_arbace_pprint_eval1820000059_fn__1820000060_A) Invoke_O_O_O__O(self, this__1, token__2 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_116; var temp__1927000414__auto____3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1))); if
														jrt.A2g_Truth(temp__1927000414__auto____3) { var cb__4 any = temp__1927000414__auto____3; lang.IFn_Cast(cb__4).Invoke_O__O(A_arbace_pprint_A_const_117) }; var lb__3 any = /*line :112:1*/A_arbace_pprint_A_const_110.Invoke_O__O(token__2); var tmp2 any = A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_New_O_O(lb__3, this__1); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_fn_class; if


	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :112:1
func A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_New_O(p0 any) *A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A) Ctor_O(c__aseq any) { t.F_aseq = c__aseq }
//line :112:1
func (t *A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), nil, nil, nil)


	lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_594.GetRawRoot__O()).Invoke_O__O(t.F_aseq))
//line :112:1
	jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)




	lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :112:1
	A_arbace_pprint_A_const_213.Set_O__O(A_arbace_pprint_A_const_28)






	var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_595.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()); var tmp6 any; var t_ any = t.F_aseq; t.F_aseq = nil; tmp6 = t_; tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6)))
//line :112:1
	var tmp7 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp7.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }


func A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_New_O_O(p0, p1 any) *A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A{}; t.Ctor_O_O(p0, p1); return t }
//line :115:1
func (t *A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A) Ctor_O_O(c__lb, c__this any) { t.F_lb = c__lb; t.F_this = c__this }
//line :115:1
func (t *A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = A_arbace_pprint_A_const_113.Invoke_O__O(t.F_lb); if
													jrt.A2g_Truth(temp__1927000414__auto____1) { var prefix__2 any = temp__1927000414__auto____1; var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))
														jrt.Writer_Cast(w__1820000023__auto____3).Write_String__V(jrt.String_Cast(prefix__2)) }; var tmp2 /*line :115:1*/*lang.Keyword = A_arbace_pprint_A_const_50; var col__1 any = lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))));



	lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_114.Invoke_O__O(t.F_lb), col__1); return /*line :120:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_115.Invoke_O__O(t.F_lb), col__1) }
//line :116:1
func A_arbace_pprint_relative_reposition_A_New() *A_arbace_pprint_relative_reposition_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_relative_reposition_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_pprint_relative_reposition_A) Ctor() {}
//line :116:1
func (t *A_arbace_pprint_relative_reposition_A) Invoke_O_O_O__O(self, navigator__0, position__1 any) any { var newpos__3 any = lang.Numbers_Add_O_O__Number(A_arbace_pprint_A_const_163.Invoke_O__O(navigator__0), position__1); if

	lang.Numbers_IsNeg_O__Z(position__1) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_304.GetRawRoot__O()).Invoke_O_O__O(navigator__0, newpos__3) } else {
			return lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_299.GetRawRoot__O(), A_arbace_pprint_A_const_301.Invoke_O__O(navigator__0), lang.IFn_Cast(A_arbace_pprint_A_const_142.GetRawRoot__O()).Invoke_O_O__O(position__1, A_arbace_pprint_A_const_300.Invoke_O__O(navigator__0)), newpos__3) } }

func A_arbace_pprint_eval1820000065_fn__1820000066_A_New() *A_arbace_pprint_eval1820000065_fn__1820000066_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000065_fn__1820000066_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_pprint_eval1820000065_fn__1820000066_A) Ctor() {}
//line :122:1
func (t *A_arbace_pprint_eval1820000065_fn__1820000066_A) Invoke_O_O_O__O(self, this__1, token__2 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_116; var temp__1927000414__auto____3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1))); if
														jrt.A2g_Truth(temp__1927000414__auto____3) { var cb__4 any = temp__1927000414__auto____3; lang.IFn_Cast(cb__4).Invoke_O__O(A_arbace_pprint_A_const_119) }; var tmp2 /*line :122:1*/*lang.Keyword = A_arbace_pprint_A_const_118; var temp__1927000414__auto____3_2 any = tmp2.Invoke_O__O(A_arbace_pprint_A_const_110.Invoke_O__O(token__2)); if

	jrt.A2g_Truth(temp__1927000414__auto____3_2) { var suffix__4 any = temp__1927000414__auto____3_2; var tmp3 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____5 any = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1)))
		jrt.Writer_Cast(w__1820000023__auto____5).Write_String__V(jrt.String_Cast(suffix__4)); return nil } else {
//line :124:1
			return nil } }

func A_arbace_pprint_pprint_set_A_New() *A_arbace_pprint_pprint_set_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_set_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_pprint_pprint_set_A) Ctor() {}
//line :126:1
func (t *A_arbace_pprint_pprint_set_A) Invoke_O_O__O(self, aset__0 any) any {
	lang.IFn_Cast(A_arbace_pprint_A_const_588.GetRawRoot__O()).Invoke_O__O(aset__0)
	if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_set_fn__740000027_A_New_O(aset__0); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_pprint_pprint_set_fn__740000027_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_202, false); A_arbace_pprint_pprint_set_fn__740000027_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :126:1
	return nil }
func A_arbace_pprint_eval1820000069_fn__1820000070_A_New() *A_arbace_pprint_eval1820000069_fn__1820000070_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000069_fn__1820000070_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_pprint_eval1820000069_fn__1820000070_A) Ctor() {}
//line :127:1
func (t *A_arbace_pprint_eval1820000069_fn__1820000070_A) Invoke_O_O_O__O(self, this__1, token__2 any) any { var lb__3 any = A_arbace_pprint_A_const_110.Invoke_O__O(token__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_115.Invoke_O__O(lb__3); var tmp3 any = A_arbace_pprint_A_const_120.Invoke_O__O(token__2); var tmp4 any; var pred__1820000071__4 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__1820000072__5 any = A_arbace_pprint_A_const_121.Invoke_O__O(token__2); if



	jrt.A2g_Truth(lang.IFn_Cast(pred__1820000071__4).Invoke_O_O__O(A_arbace_pprint_A_const_122, expr__1820000072__5)) { tmp4 = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_114.Invoke_O__O(lb__3)) } else { if jrt.A2g_Truth(lang.IFn_Cast(pred__1820000071__4).Invoke_O_O__O(A_arbace_pprint_A_const_123, expr__1820000072__5)) {

		var tmp5 *lang.Keyword = A_arbace_pprint_A_const_50; tmp4 = lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1)))) } else {
//line :131:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__1820000072__5))))) } }; return /*line :129:1*/ tmp1.Invoke_O_O__O(tmp2, lang.Numbers_Add_O_O__Number(tmp3, tmp4)) }
//line :128:1
func A_arbace_pprint_pprint_set_fn__740000027_A_New_O(p0 any) *A_arbace_pprint_pprint_set_fn__740000027_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_set_fn__740000027_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_pprint_pprint_set_fn__740000027_A) Ctor_O(c__aset any) { t.F_aset = c__aset }
//line :128:1
func (t *A_arbace_pprint_pprint_set_fn__740000027_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_203, nil, Lit_176); var length_count740000028__3 int64 = 0; var aseq__4 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_aset
										t.F_aset = nil; tmp4 = t_; aseq__4 = tmp3.Invoke_O__O(tmp4)
//line :128:1
L1: for {
	var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_214.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_O__Z(length_count740000028__3, A_arbace_pprint_A_const_214.Get__O())).Ref() }; if jrt.A2g_Truth(tmp5) { if jrt.A2g_Truth(aseq__4) {

		lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(aseq__4))
//line :129:1
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(aseq__4)) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)




			lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :129:1
			length_count740000028__3, aseq__4 = lang.Numbers_Inc_J__J(length_count740000028__3), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(aseq__4); continue L1 } } } else { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_154) }
//line :128:1
	break L1 }; var tmp6 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp6.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }



func A_arbace_pprint_binding_map_A_New() *A_arbace_pprint_binding_map_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_binding_map_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_pprint_binding_map_A) Ctor() {}
//line :132:1
func (t *A_arbace_pprint_binding_map_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, amap__2, body__3 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_186), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_187), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_188), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_189), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(amap__2))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_190), body__3, lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_191), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_192), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_193), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_194))))))))))))))) }
//line :133:1
func A_arbace_pprint_realize_parameter_A_New() *A_arbace_pprint_realize_parameter_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_realize_parameter_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_pprint_realize_parameter_A) Ctor() {}
//line :133:1
func (t *A_arbace_pprint_realize_parameter_A) Invoke_O_O_O__O(self, p__1819000013__0, navigator__1 any) any { var vec__1819000014__3 any = p__1819000013__0; var param__4 any = lang.RT_Nth_O_I_O__O(vec__1819000014__3, lang.RT_IntCast_J__I(0), nil); var vec__1819000017__5 any = lang.RT_Nth_O_I_O__O(vec__1819000014__3, lang.RT_IntCast_J__I(1), nil); var raw_val__6 any = lang.RT_Nth_O_I_O__O(vec__1819000017__5, lang.RT_IntCast_J__I(0), nil); var offset__7 any = lang.RT_Nth_O_I_O__O(vec__1819000017__5, lang.RT_IntCast_J__I(1), nil); var vec__1819000020__8 any; if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_219.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_307, param__4)) { vec__1819000020__8 = lang.Tuple_Create_O_O__IPersistentVector(raw_val__6, navigator__1) } else { if lang.Util_Equiv_O_O__Z(raw_val__6, A_arbace_pprint_A_const_305) {




		vec__1819000020__8 = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1) } else {
//line :135:1
			if lang.Util_Equiv_O_O__Z(raw_val__6, A_arbace_pprint_A_const_306) { vec__1819000020__8 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_pprint_A_const_300.Invoke_O__O(navigator__1))).Ref(), navigator__1) } else { var tmp1 *jrt.Boolean; jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp1.Ref()) { vec__1819000020__8 = lang.Tuple_Create_O_O__IPersistentVector(raw_val__6, navigator__1) } else { vec__1819000020__8 = nil } } } }; var real_param__9 any = /*line :133:1*/lang.RT_Nth_O_I_O__O(vec__1819000020__8, lang.RT_IntCast_J__I(0), nil); var new_navigator__10 any = lang.RT_Nth_O_I_O__O(vec__1819000020__8, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(param__4, lang.Tuple_Create_O_O__IPersistentVector(real_param__9, offset__7)), new_navigator__10) }

func A_arbace_pprint_eval1820000075_fn__1820000076_A_New() *A_arbace_pprint_eval1820000075_fn__1820000076_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000075_fn__1820000076_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_pprint_eval1820000075_fn__1820000076_A) Ctor() {}
//line :135:1
func (t *A_arbace_pprint_eval1820000075_fn__1820000076_A) Invoke_O_O_O__O(self, this__1, token__2 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1)));
														jrt.Writer_Cast(w__1820000023__auto____3).Write_String__V(jrt.String_Cast(A_arbace_pprint_A_const_124.Invoke_O__O(token__2))); return nil }
func A_arbace_pprint_pprint_ideref_A_New() *A_arbace_pprint_pprint_ideref_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ideref_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_pprint_pprint_ideref_A) Ctor() {}
//line :137:1
func (t *A_arbace_pprint_pprint_ideref_A) Invoke_O_O__O(self, o__0 any) any {
	jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_167, nil, Lit_4, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(o__0))).GetName__String().Ref(), nil, lang.IFn_Cast(A_arbace_pprint_A_const_329.GetRawRoot__O()).Invoke_O_O__O(Lit_168, jrt.Integer_ValueOf_I__Integer(jrt.System_IdentityHashCode_O__I(o__0)).Ref()), nil)))
	lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_596.Invoke_O__O(o__0))
	jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_152); return nil }
//line :138:1
func A_arbace_pprint_eval1820000079_fn__1820000080_A_New() *A_arbace_pprint_eval1820000079_fn__1820000080_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000079_fn__1820000080_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_pprint_eval1820000079_fn__1820000080_A) Ctor() {}
//line :138:1
func (t *A_arbace_pprint_eval1820000079_fn__1820000080_A) Invoke_O_O_O__O(self, this__1, token__2 any) any {


	var tmp1 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_126.Invoke_O__O(token__2), A_arbace_pprint_A_const_127); if or__1927000174__auto____3 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_126.Invoke_O__O(token__2), A_arbace_pprint_A_const_129)).Ref())
		if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp2 *lang.Keyword = A_arbace_pprint_A_const_130; tmp1 = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_pprint_A_const_110.Invoke_O__O(token__2))) } else { tmp1 = and__1927000168__auto____4 } }
//line :141:1
	if jrt.A2g_Truth(tmp1) {


		lang.IFn_Cast(A_arbace_pprint_A_const_128.GetRawRoot__O()).Invoke_O_O__O(this__1, token__2) } else {
//line :141:1
			var tmp3 *lang.Keyword = A_arbace_pprint_A_const_125; var temp__1927000408__auto____3 any = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1)))



			if jrt.A2g_Truth(temp__1927000408__auto____3) { var tws__4 any = temp__1927000408__auto____3; var tmp4 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1)))
				jrt.Writer_Cast(w__1820000023__auto____5).Write_String__V(jrt.String_Cast(tws__4)) } }
	var tmp5 any = A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_New_O(this__1); var tmp6 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_fn_class = fncls__19d; tmp6 = fncls__19d } else { tmp6 = fncls__19 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :141:1
func A_arbace_pprint_table_ize_A_New() *A_arbace_pprint_table_ize_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_table_ize_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_pprint_table_ize_A) Ctor() {}
//line :141:1
func (t *A_arbace_pprint_table_ize_A) Invoke_O_O_O__O(self, t__0, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_33.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_40.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_table_ize_fn__693000011_A_New_O(t__0); var tmp5 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_pprint_table_ize_fn__693000011_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_258, false); A_arbace_pprint_table_ize_fn__693000011_A_fn_class = fncls__44d; tmp5 = fncls__44d } else { tmp5 = fncls__44 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), m__1)) }
//line :142:1
func A_arbace_pprint_fn__740000032_A_New() *A_arbace_pprint_fn__740000032_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__740000032_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_pprint_fn__740000032_A) Ctor() {}
//line :142:1
func (t *A_arbace_pprint_fn__740000032_A) Invoke_O__O(self any) any { var format_in__1819000595__auto____1 any = Lit_93; var cf__1819000596__auto____2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____1)) { cf__1819000596__auto____2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____1) } else { cf__1819000596__auto____2 = format_in__1819000595__auto____1 }; var tmp1 any = A_arbace_pprint_fn__740000032_fn__740000033_A_New_O(cf__1819000596__auto____2); var tmp2 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_pprint_fn__740000032_fn__740000033_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, true); A_arbace_pprint_fn__740000032_fn__740000033_A_fn_class = fncls__122d; tmp2 = fncls__122d } else { tmp2 = fncls__122 }; return lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 0) }
//line :142:1
func A_arbace_pprint_fn__740000032_fn__740000033_A_New_O(p0 any) *A_arbace_pprint_fn__740000032_fn__740000033_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__740000032_fn__740000033_A{}; t.Ctor_O(p0); return t }
//line :142:1
func (t *A_arbace_pprint_fn__740000032_fn__740000033_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :142:1
func (t *A_arbace_pprint_fn__740000032_fn__740000033_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
//line :142:1
func A_arbace_pprint_table_ize_fn__693000011_A_New_O(p0 any) *A_arbace_pprint_table_ize_fn__693000011_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_table_ize_fn__693000011_A{}; t.Ctor_O(p0); return t }
//line :142:1
func (t *A_arbace_pprint_table_ize_fn__693000011_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :142:1
func (t *A_arbace_pprint_table_ize_fn__693000011_A) Invoke_O_O__O(self, p1__693000010_SHARP___1 any) any { var tmp1 any = t.F_t; var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O(tmp1, lang.IFn_Cast(A_arbace_pprint_A_const_195.GetRawRoot__O()).Invoke_O__O(p1__693000010_SHARP___1)); if
														jrt.A2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_196.GetRawRoot__O()).Invoke_O__O(v__3), lang.IFn_Cast(A_arbace_pprint_A_const_197.GetRawRoot__O()).Invoke_O__O(p1__693000010_SHARP___1)) } else { return nil } }
func A_arbace_pprint_pprint_simple_default_A_New() *A_arbace_pprint_pprint_simple_default_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_simple_default_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_pprint_pprint_simple_default_A) Ctor() {}
//line :144:1
func (t *A_arbace_pprint_pprint_simple_default_A) Invoke_O_O__O(self, obj__0 any) any {
	if jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(obj__0))).IsArray__Z() {
		return lang.IFn_Cast(A_arbace_pprint_A_const_597.GetRawRoot__O()).Invoke_O__O(obj__0) } else {
//line :145:1
			var tmp1 any; var and__1927000168__auto____2 any = A_arbace_pprint_A_const_598.Get__O()

			if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_pprint_A_const_599.GetRawRoot__O()).Invoke_O__O(obj__0) } else { tmp1 = and__1927000168__auto____2 }
//line :145:1
			if jrt.A2g_Truth(tmp1) {

				return lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_68.GetRawRoot__O()).Invoke_O__O(obj__0)) } else {
//line :145:1
					if A_arbace_pprint_A_const_95 != nil {


						return lang.IFn_Cast(A_arbace_pprint_A_const_215.Get__O()).Invoke_O__O(obj__0) } else {
//line :145:1
							return nil } } } }
func A_arbace_pprint_pretty_writer_QMARK__A_New() *A_arbace_pprint_pretty_writer_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_QMARK__A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_pprint_pretty_writer_QMARK__A) Ctor() {}
//line :146:1
func (t *A_arbace_pprint_pretty_writer_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 bool = lang.IDeref_InstanceOf(x__0); if and__1927000168__auto____2 {

	var tmp1 *lang.Keyword = A_arbace_pprint_A_const_172; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(x__0))) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }
//line :147:1
func A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_New_O(p0 any) *A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A{}; t.Ctor_O(p0); return t }
//line :147:1
func (t *A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :147:1
func (t *A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_125, nil) }

func A_arbace_pprint_realize_parameter_list_A_New() *A_arbace_pprint_realize_parameter_list_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_realize_parameter_list_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_pprint_realize_parameter_list_A) Ctor() {}
//line :149:1
func (t *A_arbace_pprint_realize_parameter_list_A) Invoke_O_O_O__O(self, parameter_map__0, navigator__1 any) any { var vec__1819000024__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_308.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_309.GetRawRoot__O(), navigator__1, parameter_map__0); var pairs__4 any = lang.RT_Nth_O_I_O__O(vec__1819000024__3, lang.RT_IntCast_J__I(0), nil); var new_navigator__5 any = lang.RT_Nth_O_I_O__O(vec__1819000024__3, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; return lang.Tuple_Create_O_O__IPersistentVector(tmp1.Invoke_O_O__O(tmp2.Ref(), pairs__4), new_navigator__5) }
//line :149:1
func A_arbace_pprint_write_tokens_A_New() *A_arbace_pprint_write_tokens_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_tokens_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_pprint_write_tokens_A) Ctor() {}
//line :149:1
func (t *A_arbace_pprint_write_tokens_A) Invoke_O_O_O_O__O(self, this__0, tokens__1, force_trailing_whitespace__2 any) any { var seq_1820000085__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(tokens__1); var chunk_1820000086__5 any; var count_1820000087__6 int64 = 0; var i_1820000088__7 int64 = 0; L1: for {
																if lang.Numbers_Lt_J_J__Z(i_1820000088__7, count_1820000087__6) { var token__8 any = lang.Indexed_Cast(chunk_1820000086__5).Nth_I__O(lang.RT_IntCast_J__I(i_1820000088__7))
																	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_71.Invoke_O__O(token__8), A_arbace_pprint_A_const_103)).Ref())) { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_125; var temp__1927000408__auto____9 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))
																		if jrt.A2g_Truth(temp__1927000408__auto____9) { var tws__10 any = temp__1927000408__auto____9; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____11 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))
																			jrt.Writer_Cast(w__1820000023__auto____11).Write_String__V(jrt.String_Cast(tws__10)) } }
																	lang.IFn_Cast(A_arbace_pprint_A_const_131.GetRawRoot__O()).Invoke_O_O__O(this__0, token__8)
																	var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0); var tmp5 any = A_arbace_pprint_A_const_44.GetRawRoot__O(); var tmp6 any = A_arbace_pprint_A_const_125; tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, tmp6, A_arbace_pprint_A_const_125.Invoke_O__O(token__8))
//line :150:1
		seq_1820000085__4, chunk_1820000086__5, count_1820000087__6, i_1820000088__7 = seq_1820000085__4, chunk_1820000086__5, count_1820000087__6, lang.Numbers_Unchecked_inc_J__J(i_1820000088__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_1820000085__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1820000085__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_1820000085__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1820000085__9); seq_1820000085__4, chunk_1820000086__5, count_1820000087__6, i_1820000088__7 = lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1820000085__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var token__10 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq_1820000085__9)
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_71.Invoke_O__O(token__10), A_arbace_pprint_A_const_103)).Ref())) { var tmp7 *lang.Keyword = A_arbace_pprint_A_const_125; var temp__1927000408__auto____11 any = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))
				if jrt.A2g_Truth(temp__1927000408__auto____11) { var tws__12 any = temp__1927000408__auto____11; var tmp8 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____13 any = tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))
					jrt.Writer_Cast(w__1820000023__auto____13).Write_String__V(jrt.String_Cast(tws__12)) } }
			lang.IFn_Cast(A_arbace_pprint_A_const_131.GetRawRoot__O()).Invoke_O_O__O(this__0, token__10)
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0); var tmp11 any = A_arbace_pprint_A_const_44.GetRawRoot__O(); var tmp12 any = A_arbace_pprint_A_const_125; tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, tmp12, A_arbace_pprint_A_const_125.Invoke_O__O(token__10))
//line :150:1
			seq_1820000085__4, chunk_1820000086__5, count_1820000087__6, i_1820000088__7 = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1820000085__9), nil, 0, 0; continue L1 } } }
//line :149:1
	break L1 }; var tmp13 *lang.Keyword = A_arbace_pprint_A_const_125; var tws__4 any = tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0))); var tmp14 any; var and__1927000168__auto____5 any = force_trailing_whitespace__2; if







	jrt.A2g_Truth(and__1927000168__auto____5) { tmp14 = tws__4 } else { tmp14 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp14) { var tmp15 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____5 any = tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))
		jrt.Writer_Cast(w__1820000023__auto____5).Write_String__V(jrt.String_Cast(tws__4))
		return lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_125, nil) } else {
//line :157:1
			return nil } }
//line :150:1
func A_arbace_pprint_make_pretty_writer_A_New() *A_arbace_pprint_make_pretty_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_make_pretty_writer_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_pprint_make_pretty_writer_A) Ctor() {}
//line :150:1
func (t *A_arbace_pprint_make_pretty_writer_A) Invoke_O_O_O_O__O(self, base_writer__0, right_margin__1, miser_width__2 any) any {


	return lang.IFn_Cast(A_arbace_pprint_A_const_198.GetRawRoot__O()).Invoke_O_O_O__O(base_writer__0, right_margin__1, miser_width__2)
}
func A_arbace_pprint_with_pretty_writer_A_New() *A_arbace_pprint_with_pretty_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_with_pretty_writer_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_pprint_with_pretty_writer_A) Ctor() {}
//line :155:1
func (t *A_arbace_pprint_with_pretty_writer_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, base_writer__2, body__3 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_88.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_211; return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_199), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_200), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(base_writer__2), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_201), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_202), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_203), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_200))))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_204), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_205), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_206), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_201), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_207), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_200), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_208), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_209)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_200)))))))), body__3, lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_210), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_33.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_90), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_212)))))))))))))) }









func A_arbace_pprint_write_out_A_New() *A_arbace_pprint_write_out_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_out_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_pprint_write_out_A) Ctor() {}
//line :165:1
func (t *A_arbace_pprint_write_out_A) Invoke_O_O__O(self, object__0 any) any { var length_reached__2 any; var and__1927000168__auto____2 any = A_arbace_pprint_A_const_213.Get__O(); if












	jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = A_arbace_pprint_A_const_214.Get__O(); if jrt.A2g_Truth(and__1927000168__auto____3) {


		length_reached__2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_O_O__Z(A_arbace_pprint_A_const_213.Get__O(), A_arbace_pprint_A_const_214.Get__O())).Ref() } else {
//line :178:1
			length_reached__2 = and__1927000168__auto____3 } } else { length_reached__2 = and__1927000168__auto____2 }; if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_217.Get__O())) {
		lang.IFn_Cast(A_arbace_pprint_A_const_215.Get__O()).Invoke_O__O(object__0) } else {
			if jrt.A2g_Truth(length_reached__2) {
				lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(Lit_154) } else {

					if jrt.A2g_Truth(A_arbace_pprint_A_const_213.Get__O()) { var tmp1 *lang.Var = A_arbace_pprint_A_const_213; tmp1.Set_O__O(lang.Numbers_Inc_O__Number(A_arbace_pprint_A_const_213.Get__O())) }
					lang.IFn_Cast(A_arbace_pprint_A_const_216.Get__O()).Invoke_O__O(object__0) } }; return length_reached__2 }
//line :166:1
func A_arbace_pprint_tokens_fit_QMARK__A_New() *A_arbace_pprint_tokens_fit_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_tokens_fit_QMARK__A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_pprint_tokens_fit_QMARK__A) Ctor() {}
//line :166:1
func (t *A_arbace_pprint_tokens_fit_QMARK__A) Invoke_O_O_O__O(self, this__0, tokens__1 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; var maxcol__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_132.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))); var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z(maxcol__3, nil); if or__1927000174__auto____4 {


	return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else {

		var tmp2 *lang.Keyword = A_arbace_pprint_A_const_50; return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_O_O__Z(lang.Numbers_Add_O_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))), lang.IFn_Cast(A_arbace_pprint_A_const_133.GetRawRoot__O()).Invoke_O__O(tokens__1)), maxcol__3)).Ref() } }
//line :167:1
func A_arbace_pprint_format_simple_number_A_New() *A_arbace_pprint_format_simple_number_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_simple_number_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_pprint_format_simple_number_A) Ctor() {}
//line :167:1
func (t *A_arbace_pprint_format_simple_number_A) Invoke_O_O__O(self, n__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_310.GetRawRoot__O()).Invoke_O__O(n__0)) {
		if lang.Util_Equiv_O_J__Z(A_arbace_pprint_A_const_226.Get__O(), 10) {
			var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 *jrt.String; if jrt.A2g_Truth(A_arbace_pprint_A_const_224.Get__O()) { tmp2 = Lit_112 } else { tmp2 = nil }; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, n__0, tmp2.Ref())).Ref() } else {
				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp4 any
				if jrt.A2g_Truth(A_arbace_pprint_A_const_224.Get__O()) { var or__1927000174__auto____4 any = lang.RT_Get_O_O__O(A_arbace_pprint_A_const_311.GetRawRoot__O(), A_arbace_pprint_A_const_226.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_104, nil, Lit_113), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_pprint_A_const_226.Get__O(), nil)).Ref() } } else { tmp4 = nil }
//line :171:1
				return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, lang.IFn_Cast(A_arbace_pprint_A_const_312.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_226.Get__O(), n__0))).Ref() } } else {
//line :168:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_313.GetRawRoot__O()).Invoke_O__O(n__0)) {





						var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_114, nil); var tmp6 any
						if jrt.A2g_Truth(A_arbace_pprint_A_const_224.Get__O()) { var or__1927000174__auto____6 any = lang.RT_Get_O_O__O(A_arbace_pprint_A_const_311.GetRawRoot__O(), A_arbace_pprint_A_const_226.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp6 = or__1927000174__auto____6 } else { tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_104, nil, Lit_113), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_pprint_A_const_226.Get__O(), nil)).Ref() } } else { tmp6 = nil }
//line :174:1
						return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, lang.IFn_Cast(A_arbace_pprint_A_const_312.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_226.Get__O(), lang.Ratio_Cast(n__0).F_numerator.Ref()), nil, lang.IFn_Cast(A_arbace_pprint_A_const_312.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_226.Get__O(), lang.Ratio_Cast(n__0).F_denominator.Ref()))).Ref() } else {
//line :168:1
							if A_arbace_pprint_A_const_95 != nil { return nil } else { return nil
							}
						}
				}
}
func A_arbace_pprint_linear_nl_QMARK__A_New() *A_arbace_pprint_linear_nl_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_linear_nl_QMARK__A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_pprint_linear_nl_QMARK__A) Ctor() {}
//line :173:1
func (t *A_arbace_pprint_linear_nl_QMARK__A) Invoke_O_O_O_O__O(self, this__0, lb__1, section__2 any) any { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_130.Invoke_O__O(lb__1)); if

	jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
		return lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_134.GetRawRoot__O()).Invoke_O_O__O(this__0, section__2)) } }

func A_arbace_pprint_brackets_A_New() *A_arbace_pprint_brackets_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_brackets_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_pprint_brackets_A) Ctor() {}
//line :178:1
func (t *A_arbace_pprint_brackets_A) Invoke_O_O__O(self, form__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_600.GetRawRoot__O()).Invoke_O__O(form__0)) { return A_arbace_pprint_A_const_601 } else { return A_arbace_pprint_A_const_602 } }
//line :178:1
func A_arbace_pprint_miser_nl_QMARK__A_New() *A_arbace_pprint_miser_nl_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_miser_nl_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_pprint_miser_nl_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_pprint_miser_nl_QMARK__A) Invoke_O_O_O_O__O(self, this__0, lb__1, section__2 any) any { var miser_width__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_135.GetRawRoot__O()).Invoke_O__O(this__0); var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; var maxcol__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_132.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))); var and__1927000168__auto____6 any = miser_width__4; if


	jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = maxcol__5; if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 bool = lang.Numbers_Gte_O_O__Z(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_114.Invoke_O__O(lb__1)), lang.Numbers_Minus_O_O__Number(maxcol__5, miser_width__4)); if and__1927000168__auto____8 {

		return lang.IFn_Cast(A_arbace_pprint_A_const_136.GetRawRoot__O()).Invoke_O_O_O__O(this__0, lb__1, section__2) } else {
//line :181:1
			return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } }
//line :181:1
func A_arbace_pprint_format_ascii_A_New() *A_arbace_pprint_format_ascii_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_ascii_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_pprint_format_ascii_A) Ctor() {}
//line :181:1
func (t *A_arbace_pprint_format_ascii_A) Invoke_O_O_O_O_O__O(self, print_func__0, params__1, arg_navigator__2, offsets__3 any) any { var vec__1819000029__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(arg_navigator__2); var arg__6 any = lang.RT_Nth_O_I_O__O(vec__1819000029__5, lang.RT_IntCast_J__I(0), nil); var arg_navigator__7 any = lang.RT_Nth_O_I_O__O(vec__1819000029__5, lang.RT_IntCast_J__I(1), nil); var base_output__8 any; var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_pprint_A_const_183.GetRawRoot__O()).Invoke_O__O(arg__6); if

	jrt.A2g_Truth(or__1927000174__auto____8) { base_output__8 = or__1927000174__auto____8 } else { base_output__8 = lang.IFn_Cast(print_func__0).Invoke_O__O(arg__6) }; var base_width__9 int32 = /*line :181:1*/jrt.NN(jrt.String_Cast(base_output__8)).Length__I(); var min_width__10 any = lang.Numbers_Add_J_O__Number(int64(base_width__9), A_arbace_pprint_A_const_314.Invoke_O__O(params__1)); var width__11 any; if




	lang.Numbers_Gte_O_O__Z(min_width__10, A_arbace_pprint_A_const_315.Invoke_O__O(params__1)) { width__11 = min_width__10 } else {

		width__11 = lang.Numbers_Add_O_O__Number(min_width__10, lang.Numbers_Multiply_O_O__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Quotient_O_O__Number(lang.Numbers_Minus_O_J__Number(lang.Numbers_Minus_O_O__Number(A_arbace_pprint_A_const_315.Invoke_O__O(params__1), min_width__10), 1), A_arbace_pprint_A_const_316.Invoke_O__O(params__1)), 1), A_arbace_pprint_A_const_316.Invoke_O__O(params__1))) }; var chars__12 any = /*line :181:1*/lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(width__11, int64(base_width__9)), A_arbace_pprint_A_const_317.Invoke_O__O(params__1))); if












	jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__1)) {
		lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, chars__12, base_output__8)).Ref()) } else {
			lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, base_output__8, chars__12)).Ref()) }; return arg_navigator__7 }
//line :185:1
func A_arbace_pprint_eval1820000093_fn__1820000094_A_New() *A_arbace_pprint_eval1820000093_fn__1820000094_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000093_fn__1820000094_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_pprint_eval1820000093_fn__1820000094_A) Ctor() {}
//line :185:1
func (t *A_arbace_pprint_eval1820000093_fn__1820000094_A) Invoke_O_O_O_O_O__O(self, t__1, ___2, ___3, ___4 any) any { return A_arbace_pprint_A_const_126.Invoke_O__O(t__1) }
//line :185:1
func A_arbace_pprint_pprint_ns_reference_A_New() *A_arbace_pprint_pprint_ns_reference_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_pprint_pprint_ns_reference_A) Ctor() {}
//line :185:1
func (t *A_arbace_pprint_pprint_ns_reference_A) Invoke_O_O__O(self, reference__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_603.GetRawRoot__O()).Invoke_O__O(reference__0)) { var vec__740000058__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_604.GetRawRoot__O()).Invoke_O__O(reference__0); var start__3 any = lang.RT_Nth_O_I_O__O(vec__740000058__2, lang.RT_IntCast_J__I(0), nil); var end__4 any = lang.RT_Nth_O_I_O__O(vec__740000058__2, lang.RT_IntCast_J__I(1), nil); var vec__740000061__5 any = reference__0; var seq__740000062__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(vec__740000061__5); var first__740000063__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__740000062__6); var seq__740000062__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__740000062__6)
		var keyw__9 any = first__740000063__7
		var args__10 any = seq__740000062__8
		if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_A_New_O_O_O_O(keyw__9, args__10, end__4, start__3); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_186, false); A_arbace_pprint_pprint_ns_reference_fn__740000064_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :188:1
		return nil } else {




























			if jrt.A2g_Truth(reference__0) { return lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(reference__0) } else { return nil } } }
//line :187:1
func A_arbace_pprint_eval1820000097_fn__1820000098_A_New() *A_arbace_pprint_eval1820000097_fn__1820000098_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000097_fn__1820000098_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_pprint_eval1820000097_fn__1820000098_A) Ctor() {}
//line :187:1
func (t *A_arbace_pprint_eval1820000097_fn__1820000098_A) Invoke_O_O_O_O_O__O(self, newl__1, this__2, section__3, ___4 any) any { var lb__5 any = A_arbace_pprint_A_const_110.Invoke_O__O(newl__1); return /*line :189:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_136.GetRawRoot__O()).Invoke_O_O_O__O(this__2, lb__5, section__3) }

func A_arbace_pprint_eval1820000101_fn__1820000102_A_New() *A_arbace_pprint_eval1820000101_fn__1820000102_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000101_fn__1820000102_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_pprint_eval1820000101_fn__1820000102_A) Ctor() {}
//line :191:1
func (t *A_arbace_pprint_eval1820000101_fn__1820000102_A) Invoke_O_O_O_O_O__O(self, newl__1, this__2, section__3, ___4 any) any { var lb__5 any = A_arbace_pprint_A_const_110.Invoke_O__O(newl__1); return /*line :193:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_137.GetRawRoot__O()).Invoke_O_O_O__O(this__2, lb__5, section__3) }
//line :191:1
func A_arbace_pprint_pprint_ns_reference_fn__740000064_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :191:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_A) Ctor_O_O_O_O(c__keyw, c__args, c__end, c__start any) { t.F_keyw = c__keyw; t.F_args = c__args; t.F_end = c__end; t.F_start = c__start }
//line :191:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_A) Invoke_O__O(self any) any { var tmp1 any; tmp25 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; var tmp3 any = A_arbace_pprint_A_const_34.Get__O(); var tmp4 any; var t_ any = t.F_start; t.F_start = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var t__2 any = t.F_end; t.F_end = nil; tmp6 = t__2; tmp2.Invoke_O_O_O_O__O(tmp3, tmp5, nil, tmp6)
											var tmp7 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3 any = Lit_187; var cf__1819000596__auto____4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3)) { cf__1819000596__auto____4 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3) } else { cf__1819000596__auto____4 = format_in__1819000595__auto____3 }; var tmp8 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_New_O(cf__1819000596__auto____4); var tmp9 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_188, true); A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_fn_class = fncls__123d; tmp9 = fncls__123d } else { tmp9 = fncls__123 }; tmp7 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp8, tmp9, nil, 0); var tmp10 lang.IFn = Up_Compiler_AOTRestFn_IFn(tmp7); var tmp11 any; var t__3 any = t.F_keyw; t.F_keyw = nil; tmp11 = t__3; tmp10.Invoke_O__O(tmp11)
//line :191:1
	var args__3 any; var t__4 any = t.F_args; t.F_args = nil; args__3 = t__4; L1: for {


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(args__3)) {
			var tmp12 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____4 any = Lit_4; var cf__1819000596__auto____5 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____4)) { cf__1819000596__auto____5 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____4) } else { cf__1819000596__auto____5 = format_in__1819000595__auto____4 }; var tmp13 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_New_O(cf__1819000596__auto____5); var tmp14 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_189, true); A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_fn_class = fncls__124d; tmp14 = fncls__124d } else { tmp14 = fncls__124 }; tmp12 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp13, tmp14, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp12).Invoke__O()
//line :194:1
			var arg__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(args__3)


			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_603.GetRawRoot__O()).Invoke_O__O(arg__4)) { var vec__740000069__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_604.GetRawRoot__O()).Invoke_O__O(arg__4); var start__6 any = lang.RT_Nth_O_I_O__O(vec__740000069__5, lang.RT_IntCast_J__I(0), nil); var end__7 any = lang.RT_Nth_O_I_O__O(vec__740000069__5, lang.RT_IntCast_J__I(1), nil)

				if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp15 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp16 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_New_O_O_O(arg__4, end__7, start__6); var tmp17 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_190, false); A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_fn_class = fncls__130d; tmp17 = fncls__130d } else { tmp17 = fncls__130 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O()
				}









				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(args__3)) {
					var tmp18 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____8 any = Lit_191; var cf__1819000596__auto____9 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____8)) { cf__1819000596__auto____9 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____8) } else { cf__1819000596__auto____9 = format_in__1819000595__auto____8 }; var tmp19 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_New_O(cf__1819000596__auto____9); var tmp20 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_192, true); A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_fn_class = fncls__125d; tmp20 = fncls__125d } else { tmp20 = fncls__125 }; tmp18 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp19, tmp20, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp18).Invoke__O() } } else {

						lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(arg__4)
						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(args__3)) {
							var tmp21 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____5 any = Lit_193; var cf__1819000596__auto____6 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____5)) { cf__1819000596__auto____6 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____5) } else { cf__1819000596__auto____6 = format_in__1819000595__auto____5 }; var tmp22 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_New_O(cf__1819000596__auto____6); var tmp23 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_194, true); A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_fn_class = fncls__126d; tmp23 = fncls__126d } else { tmp23 = fncls__126 }; tmp21 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp22, tmp23, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp21).Invoke__O() } }
			args__3 = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(args__3); continue L1 }
//line :191:1
		break L1 }; var tmp24 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp24.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp25 != nil { panic(tmp25) }; return tmp1 }
//line :191:1
func A_arbace_pprint_write_A_New() *A_arbace_pprint_write_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_pprint_write_A) Ctor() {}
//line :191:1
func (t *A_arbace_pprint_write_A) DoInvoke_O_O_O__O(self, object__0, kw_args__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_218.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_221; var options__3 any = tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_33.GetRawRoot__O(), kw_args__1));

























	lang.Var_PushThreadBindings_Associative__V(lang.Associative_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_222.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_223.GetRawRoot__O(), options__3))); var tmp3 any; tmp18 := /*line :191:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


























		{ var tmp4 lang.IPersistentMap; var tmp5 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_J__Z(A_arbace_pprint_A_const_226.Get__O(), 10)).Ref()); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp5 = or__1927000174__auto____6 } else { tmp5 = A_arbace_pprint_A_const_224.Get__O() }; if jrt.A2g_Truth(tmp5) { var tmp6 any = A_arbace_pprint_A_const_215; tmp4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, A_arbace_pprint_A_const_225.GetRawRoot__O())) } else { lang.PersistentArrayMap_Init(); tmp4 = Up_PersistentArrayMap_IPersistentMap(lang.PersistentArrayMap_EMPTY) }; lang.Var_PushThreadBindings_Associative__V(tmp4); tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :191:1
			{ var optval__8 any



























				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_219.GetRawRoot__O()).Invoke_O_O__O(options__3, A_arbace_pprint_A_const_220)) {
					optval__8 = A_arbace_pprint_A_const_220.Invoke_O__O(options__3) } else {
//line :219:1
						jrt.Boolean_Init(); optval__8 = jrt.Boolean_TRUE.Ref() }
//line :191:1
				var base_writer__9 any; var pred__693000024__9 any = A_arbace_pprint_A_const_54.GetRawRoot__O()
				var expr__693000025__10 any = optval__8





























				if jrt.A2g_Truth(lang.IFn_Cast(pred__693000024__9).Invoke_O_O__O(nil, expr__693000025__10)) { base_writer__9 = jrt.StringWriter_New() } else { var tmp7 lang.IFn = lang.IFn_Cast(pred__693000024__9); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp7.Invoke_O_O__O(tmp8.Ref(), expr__693000025__10)) { base_writer__9 = A_arbace_pprint_A_const_34.Get__O() } else { base_writer__9 = optval__8
				}
				}

				if jrt.A2g_Truth(A_arbace_pprint_A_const_217.Get__O()) { var base_writer__693000016__auto____10 any = base_writer__9; var new_writer__693000017__auto____11 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_228.GetRawRoot__O()).Invoke_O__O(base_writer__693000016__auto____10)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()); var tmp11 any = A_arbace_pprint_A_const_34; var tmp12 any
					if jrt.A2g_Truth(new_writer__693000017__auto____11) { tmp12 = lang.IFn_Cast(A_arbace_pprint_A_const_229.GetRawRoot__O()).Invoke_O_O_O__O(base_writer__693000016__auto____10, A_arbace_pprint_A_const_230.Get__O(), A_arbace_pprint_A_const_231.Get__O()) } else { tmp12 = base_writer__693000016__auto____10 }; tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(tmp11, tmp12)); var tmp13 any = A_arbace_pprint_write_fn__693000026_A_New_O(object__0); var tmp14 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_pprint_write_fn__693000026_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_275, false); A_arbace_pprint_write_fn__693000026_A_fn_class = fncls__46d; tmp14 = fncls__46d } else { tmp14 = fncls__46 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O() } else {

						lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_34, base_writer__9)); var tmp15 any = A_arbace_pprint_write_fn__693000028_A_New_O(object__0); var tmp16 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_pprint_write_fn__693000028_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_276, false); A_arbace_pprint_write_fn__693000028_A_fn_class = fncls__47d; tmp16 = fncls__47d } else { tmp16 = fncls__47 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
					}
				if lang.Util_Identical_O_O__Z(optval__8, nil) {
					tmp3 = jrt.NN(jrt.StringWriter_Cast(base_writer__9)).ToString__String().Ref() } else {
//line :231:1
						tmp3 = nil } }
//line :218:1
			return nil }(); lang.Var_PopThreadBindings__V()
//line :191:1
			if tmp17 != nil { panic(tmp17) } }; return nil }();

























	lang.Var_PopThreadBindings__V(); if /*line :191:1*/ tmp18 != nil { panic(tmp18) }; return tmp3 }
func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A{}; t.Ctor_O(p0); return t }
//line :192:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :192:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }


func A_arbace_pprint_eval1820000105_fn__1820000106_A_New() *A_arbace_pprint_eval1820000105_fn__1820000106_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000105_fn__1820000106_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_pprint_eval1820000105_fn__1820000106_A) Ctor() {}
//line :195:1
func (t *A_arbace_pprint_eval1820000105_fn__1820000106_A) Invoke_O_O_O_O_O__O(self, newl__1, this__2, section__3, subsection__4 any) any { var lb__5 any = A_arbace_pprint_A_const_110.Invoke_O__O(newl__1); var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_138.Invoke_O__O(lb__5)); if

	jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_134.GetRawRoot__O()).Invoke_O_O__O(this__2, subsection__4)); if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else {

		return lang.IFn_Cast(A_arbace_pprint_A_const_137.GetRawRoot__O()).Invoke_O_O_O__O(this__2, lb__5, section__3) } } }
//line :195:1
func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A{}; t.Ctor_O(p0); return t }
//line :195:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :195:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }



func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_New_O_O_O(p0, p1, p2 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :199:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A) Ctor_O_O_O(c__arg, c__end, c__start any) { t.F_arg = c__arg; t.F_end = c__end; t.F_start = c__start }
//line :199:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A) Invoke_O__O(self any) any { var tmp1 any; tmp21 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; var tmp3 any = A_arbace_pprint_A_const_34.Get__O(); var tmp4 any; var t_ any = t.F_start; t.F_start = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var t__2 any = t.F_end; t.F_end = nil; tmp6 = t__2; tmp2.Invoke_O_O_O_O__O(tmp3, tmp5, nil, tmp6)
													var tmp7 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z(int64(lang.RT_Count_O__I(t.F_arg)), 3); if and__1927000168__auto____3 { tmp7 = lang.IFn_Cast(A_arbace_pprint_A_const_605.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(t.F_arg)) } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp7) { var vec__740000073__3 any; var t__3 any = t.F_arg; t.F_arg = nil; vec__740000073__3 = t__3; var ns__4 any = lang.RT_Nth_O_I_O__O(vec__740000073__3, lang.RT_IntCast_J__I(0), nil); var kw__5 any = lang.RT_Nth_O_I_O__O(vec__740000073__3, lang.RT_IntCast_J__I(1), nil); var lis__6 any = lang.RT_Nth_O_I_O__O(vec__740000073__3, lang.RT_IntCast_J__I(2), nil); var tmp8 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____7 any = Lit_195; var cf__1819000596__auto____8 any

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____7)) { cf__1819000596__auto____8 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____7) } else { cf__1819000596__auto____8 = format_in__1819000595__auto____7 }; var tmp9 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_New_O(cf__1819000596__auto____8); var tmp10 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_196, true); A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_fn_class = fncls__128d; tmp10 = fncls__128d } else { tmp10 = fncls__128 }; tmp8 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp8).Invoke_O_O__O(ns__4, kw__5)
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_603.GetRawRoot__O()).Invoke_O__O(lis__6)) {
			var tmp11 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____7_2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_600.GetRawRoot__O()).Invoke_O__O(lis__6)) { format_in__1819000595__auto____7_2 = Lit_197 } else { format_in__1819000595__auto____7_2 = Lit_198 }; var cf__1819000596__auto____8_2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____7_2)) { cf__1819000596__auto____8_2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____7_2) } else { cf__1819000596__auto____8_2 = format_in__1819000595__auto____7_2 }; var tmp12 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_New_O(cf__1819000596__auto____8_2); var tmp13 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_199, true); A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_fn_class = fncls__127d; tmp13 = fncls__127d } else { tmp13 = fncls__127 }; tmp11 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp12, tmp13, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp11).Invoke_O__O(lis__6) } else {



				lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lis__6) } } else {
					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp15 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3 any = Lit_200; var cf__1819000596__auto____4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3)) { cf__1819000596__auto____4 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3) } else { cf__1819000596__auto____4 = format_in__1819000595__auto____3 }; var tmp16 any = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_New_O(cf__1819000596__auto____4); var tmp17 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_201, true); A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_fn_class = fncls__129d; tmp17 = fncls__129d } else { tmp17 = fncls__129 }; tmp15 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp16, tmp17, nil, 0); var tmp18 any = tmp15.Ref(); var tmp19 any; var t__4 any = t.F_arg; t.F_arg = nil; tmp19 = t__4; tmp14.Invoke_O_O__O(tmp18, tmp19) }
//line :199:1
	var tmp20 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp20.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp21 != nil { panic(tmp21) }; return tmp1 }

func A_arbace_pprint_eval1820000109_fn__1820000110_A_New() *A_arbace_pprint_eval1820000109_fn__1820000110_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000109_fn__1820000110_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_pprint_eval1820000109_fn__1820000110_A) Ctor() {}
//line :201:1
func (t *A_arbace_pprint_eval1820000109_fn__1820000110_A) Invoke_O_O_O_O_O__O(self, ___1, ___2, ___3, ___4 any) any { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }
func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :202:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_integral_QMARK__A_New() *A_arbace_pprint_integral_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_integral_QMARK__A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_pprint_integral_QMARK__A) Ctor() {}
//line :204:1
func (t *A_arbace_pprint_integral_QMARK__A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_310.GetRawRoot__O()).Invoke_O__O(x__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_319.GetRawRoot__O()).Invoke_O__O(x__0)) {

		return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_O_J__Z(jrt.NN(jrt.NN(jrt.BigDecimal_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_320.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_28))).StripTrailingZeros__BigDecimal()).Ulp__BigDecimal().Ref(), 1)).Ref() } else {
//line :207:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_321.GetRawRoot__O()).Invoke_O__O(x__0)) {


				return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_D__Z(x__0, jrt.Math_Floor_D__D(lang.RT_DoubleCast_O__D(x__0)))).Ref() } else {
//line :207:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_313.GetRawRoot__O()).Invoke_O__O(x__0)) { var r__2 any = x__0; var tmp1 any = lang.Ratio_Cast(r__2).F_numerator.Ref()




						return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_O__Z(0, lang.Numbers_Remainder_O_O__Number(tmp1, lang.Ratio_Cast(r__2).F_denominator.Ref()))).Ref() } else {
//line :207:1
							if A_arbace_pprint_A_const_95 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil } } } } } }
//line :204:1
func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A{}; t.Ctor_O(p0); return t }
//line :204:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :204:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }



func A_arbace_pprint_get_section_A_New() *A_arbace_pprint_get_section_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_section_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_pprint_get_section_A) Ctor() {}
//line :208:1
func (t *A_arbace_pprint_get_section_A) Invoke_O_O__O(self, buffer__0 any) any { var nl__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(buffer__0); var lb__3 any = A_arbace_pprint_A_const_110.Invoke_O__O(nl__2); var section__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_139.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_get_section_fn__1820000114_A_New_O(lb__3); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_pprint_get_section_fn__1820000114_A_fn_class; if


	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_pprint_get_section_fn__1820000114_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; section__4 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(buffer__0))); return /*line :208:1*/ lang.Tuple_Create_O_O__IPersistentVector(section__4, lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_142.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(section__4)))).Ref(), buffer__0))) }
func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A{}; t.Ctor_O(p0); return t }
//line :209:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :209:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_get_section_fn__1820000114_A_New_O(p0 any) *A_arbace_pprint_get_section_fn__1820000114_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_section_fn__1820000114_A{}; t.Ctor_O(p0); return t }
//line :211:1
func (t *A_arbace_pprint_get_section_fn__1820000114_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :211:1
func (t *A_arbace_pprint_get_section_fn__1820000114_A) Invoke_O_O__O(self, p1__1820000113_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()); var tmp2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_140.GetRawRoot__O()).Invoke_O__O(p1__1820000113_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp2 = lang.IFn_Cast(A_arbace_pprint_A_const_141.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_110.Invoke_O__O(p1__1820000113_SHARP___1), t.F_lb) } else { tmp2 = and__1927000168__auto____2 }; return tmp1.Invoke_O__O(tmp2) }
//line :211:1
func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A{}; t.Ctor_O(p0); return t }
//line :211:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :211:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }



func A_arbace_pprint_get_sub_section_A_New() *A_arbace_pprint_get_sub_section_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_sub_section_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_pprint_get_sub_section_A) Ctor() {}
//line :215:1
func (t *A_arbace_pprint_get_sub_section_A) Invoke_O_O__O(self, buffer__0 any) any { var nl__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(buffer__0); var lb__3 any = A_arbace_pprint_A_const_110.Invoke_O__O(nl__2); var section__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_139.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_get_sub_section_fn__1820000118_A_New_O(lb__3); var tmp4 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_pprint_get_sub_section_fn__1820000118_A_fn_class; if


	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_pprint_get_sub_section_fn__1820000118_A_fn_class = fncls__21d; tmp4 = fncls__21d } else { tmp4 = fncls__21 }; section__4 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(buffer__0))); return section__4 }
//line :215:1
func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A{}; t.Ctor_O(p0); return t }
//line :215:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :215:1
func (t *A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
//line :215:1
func A_arbace_pprint_remainders_A_New() *A_arbace_pprint_remainders_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_remainders_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_pprint_remainders_A) Ctor() {}
//line :215:1
func (t *A_arbace_pprint_remainders_A) Invoke_O_O_O__O(self, base__0, val__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_322.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_remainders_fn__1819000035_A_New_O(base__0); var tmp5 *jrt.Class
	var fncls__51 /*line :218:1*/*jrt.Class = A_arbace_pprint_remainders_fn__1819000035_A_fn_class

	if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_245, false); A_arbace_pprint_remainders_fn__1819000035_A_fn_class = fncls__51d; tmp5 = fncls__51d } else { tmp5 = fncls__51 }
//line :218:1
	return tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), val__1))) }
//line :218:1
func A_arbace_pprint_get_sub_section_fn__1820000118_A_New_O(p0 any) *A_arbace_pprint_get_sub_section_fn__1820000118_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_sub_section_fn__1820000118_A{}; t.Ctor_O(p0); return t }
//line :218:1
func (t *A_arbace_pprint_get_sub_section_fn__1820000118_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :218:1
func (t *A_arbace_pprint_get_sub_section_fn__1820000118_A) Invoke_O_O__O(self, p1__1820000117_SHARP___1 any) any { var nl_lb__2 any = A_arbace_pprint_A_const_110.Invoke_O__O(p1__1820000117_SHARP___1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_pprint_A_const_140.GetRawRoot__O()).Invoke_O__O(p1__1820000117_SHARP___1); if
															jrt.A2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z(nl_lb__2, t.F_lb); if or__1927000174__auto____4 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { tmp2 = lang.IFn_Cast(A_arbace_pprint_A_const_141.GetRawRoot__O()).Invoke_O_O__O(nl_lb__2, t.F_lb) } } else { tmp2 = and__1927000168__auto____3 }; return tmp1.Invoke_O__O(tmp2) }
//line :219:1
func A_arbace_pprint_pprint_ns_A_New() *A_arbace_pprint_pprint_ns_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_pprint_pprint_ns_A) Ctor() {}
//line :219:1
func (t *A_arbace_pprint_pprint_ns_A) Invoke_O_O__O(self, alis__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(alis__0)) { var vec__740000089__2 any = alis__0; var seq__740000090__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(vec__740000089__2); var first__740000091__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__740000090__3); var seq__740000090__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__740000090__3); var ns_sym__6 any = first__740000091__4; var first__740000091__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__740000090__5); var seq__740000090__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__740000090__5); var ns_name__9 any = first__740000091__7; var stuff__10 any = seq__740000090__8; var vec__740000092__11 any

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(stuff__10))) { vec__740000092__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(stuff__10), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(stuff__10)) } else { vec__740000092__11 = lang.Tuple_Create_O_O__IPersistentVector(nil, stuff__10) }
//line :222:1
		var doc_str__12 any = lang.RT_Nth_O_I_O__O(vec__740000092__11, lang.RT_IntCast_J__I(0), nil); var stuff__13 any = lang.RT_Nth_O_I_O__O(vec__740000092__11, lang.RT_IntCast_J__I(1), nil); var vec__740000095__14 any




		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_606.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(stuff__13))) { vec__740000095__14 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(stuff__13), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(stuff__13)) } else { vec__740000095__14 = lang.Tuple_Create_O_O__IPersistentVector(nil, stuff__13) }
//line :222:1
		var attr_map__15 any = lang.RT_Nth_O_I_O__O(vec__740000095__14, lang.RT_IntCast_J__I(0), nil); var references__16 any = lang.RT_Nth_O_I_O__O(vec__740000095__14, lang.RT_IntCast_J__I(1), nil)







		if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_ns_fn__740000098_A_New_O_O_O_O_O(ns_sym__6, references__16, ns_name__9, doc_str__12, attr_map__15); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_pprint_pprint_ns_fn__740000098_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_179, false); A_arbace_pprint_pprint_ns_fn__740000098_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :222:1
		return nil } else {




















			return lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(alis__0) } }
//line :220:1
func A_arbace_pprint_remainders_fn__1819000035_A_New_O(p0 any) *A_arbace_pprint_remainders_fn__1819000035_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_remainders_fn__1819000035_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_pprint_remainders_fn__1819000035_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :220:1
func (t *A_arbace_pprint_remainders_fn__1819000035_A) Invoke_O_O__O(self, p1__1819000034_SHARP___1 any) any { if lang.Numbers_IsPos_O__Z(p1__1819000034_SHARP___1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.Numbers_Remainder_O_O__Number(p1__1819000034_SHARP___1, t.F_base), lang.Numbers_Quotient_O_O__Number(p1__1819000034_SHARP___1, t.F_base)) } else { return A_arbace_pprint_A_const_324 } }


func A_arbace_pprint_update_nl_state_A_New() *A_arbace_pprint_update_nl_state_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_update_nl_state_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_pprint_update_nl_state_A) Ctor() {}
//line :223:1
func (t *A_arbace_pprint_update_nl_state_A) Invoke_O_O__O(self, lb__0 any) any {
	var tmp1 any = A_arbace_pprint_update_nl_state_fn__1820000121_A_New_O(lb__0); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_pprint_update_nl_state_fn__1820000121_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_274, false); A_arbace_pprint_update_nl_state_fn__1820000121_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :224:1
func A_arbace_pprint_update_nl_state_fn__1820000121_A_New_O(p0 any) *A_arbace_pprint_update_nl_state_fn__1820000121_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_update_nl_state_fn__1820000121_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_pprint_update_nl_state_fn__1820000121_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :224:1
func (t *A_arbace_pprint_update_nl_state_fn__1820000121_A) Invoke_O__O(self any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_138.Invoke_O__O(t.F_lb); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; tmp1.Invoke_O_O__O(tmp2, tmp3.Ref())
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp5 any = A_arbace_pprint_A_const_130.Invoke_O__O(t.F_lb); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; tmp4.Invoke_O_O__O(tmp5, tmp6.Ref())
//line :224:1
		var lb__1 any = A_arbace_pprint_A_const_94.Invoke_O__O(t.F_lb); L1: for {



			if jrt.A2g_Truth(lb__1) {
				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp8 any = A_arbace_pprint_A_const_130.Invoke_O__O(lb__1); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; tmp7.Invoke_O_O__O(tmp8, tmp9.Ref())
				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp11 any = A_arbace_pprint_A_const_138.Invoke_O__O(lb__1); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; tmp10.Invoke_O_O__O(tmp11, tmp12.Ref())
				lb__1 = A_arbace_pprint_A_const_94.Invoke_O__O(lb__1); continue L1 } else {
//line :228:1
					return nil } } }
//line :224:1
	panic("a2g: unreachable")
}
func A_arbace_pprint_base_str_A_New() *A_arbace_pprint_base_str_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_base_str_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_pprint_base_str_A) Ctor() {}
//line :226:1
func (t *A_arbace_pprint_base_str_A) Invoke_O_O_O__O(self, base__0, val__1 any) any {


	if lang.Numbers_IsZero_O__Z(val__1) { return Lit_6 } else { var xlated_val__3 any; _ = xlated_val__3

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_321.GetRawRoot__O()).Invoke_O__O(val__1)) {
			xlated_val__3 = lang.IFn_Cast(A_arbace_pprint_A_const_320.GetRawRoot__O()).Invoke_O__O(val__1) } else {
//line :231:1
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_313.GetRawRoot__O()).Invoke_O__O(val__1)) { var r__3 any = val__1; var tmp1 *jrt.BigInteger = lang.Ratio_Cast(r__3).F_numerator


					xlated_val__3 = lang.Numbers_Divide_BigInteger_BigInteger__Number(tmp1, lang.Ratio_Cast(r__3).F_denominator) } else {
//line :231:1
						if A_arbace_pprint_A_const_95 != nil { xlated_val__3 = val__1 } else { xlated_val__3 = nil
						}
					}
			}

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_A_const_146.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp5 any = A_arbace_pprint_base_str_fn__1819000039_A_New(); var tmp6 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_pprint_base_str_fn__1819000039_A_fn_class
		if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_pprint_base_str_fn__1819000039_A_fn_class = fncls__52d; tmp6 = fncls__52d } else { tmp6 = fncls__52 }
//line :236:1
		return tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_pprint_A_const_327.GetRawRoot__O()).Invoke_O_O__O(base__0, val__1))) } }
//line :227:1
func A_arbace_pprint_write_fn__693000026_A_New_O(p0 any) *A_arbace_pprint_write_fn__693000026_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_fn__693000026_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_pprint_write_fn__693000026_A) Ctor_O(c__object any) { t.F_object = c__object }
//line :227:1
func (t *A_arbace_pprint_write_fn__693000026_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_object; t.F_object = nil; tmp3 = t_; tmp2.Invoke_O__O(tmp3)
//line :227:1
		var target_45 any = A_arbace_pprint_A_const_34.Get__O(); var tmp4 bool; var tmp5 bool; tmp5 = !(target_45 == nil); if tmp5 { tmp5 = lang.Compiler_AOT_IsDyn_O__Z(target_45) }; tmp4 = tmp5; if tmp4 { tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_45, Lit_145, jrt.RefArrayOf(jrt.Object_class)) } else { A_arbace_pprint_PrettyFlush_A_Cast(target_45).Ppflush__V(); tmp1 = nil } }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp1 }

func A_arbace_pprint_write_fn__693000028_A_New_O(p0 any) *A_arbace_pprint_write_fn__693000028_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_fn__693000028_A{}; t.Ctor_O(p0); return t }
//line :229:1
func (t *A_arbace_pprint_write_fn__693000028_A) Ctor_O(c__object any) { t.F_object = c__object }
//line :229:1
func (t *A_arbace_pprint_write_fn__693000028_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_215.Get__O()); var tmp3 any; var t_ any = t.F_object; t.F_object = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }
//line :229:1
	return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }
func A_arbace_pprint_pprint_ns_fn__740000098_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_pprint_pprint_ns_fn__740000098_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_fn__740000098_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :230:1
func (t *A_arbace_pprint_pprint_ns_fn__740000098_A) Ctor_O_O_O_O_O(c__ns_sym, c__references, c__ns_name, c__doc_str, c__attr_map any) { t.F_ns_sym = c__ns_sym; t.F_references = c__references; t.F_ns_name = c__ns_name; t.F_doc_str = c__doc_str; t.F_attr_map = c__attr_map }
//line :230:1
func (t *A_arbace_pprint_pprint_ns_fn__740000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp26 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_102, nil, Lit_103)
										var tmp3 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3 any = Lit_162; var cf__1819000596__auto____4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3)) { cf__1819000596__auto____4 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3) } else { cf__1819000596__auto____4 = format_in__1819000595__auto____3 }; var tmp4 any = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_New_O(cf__1819000596__auto____4); var tmp5 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_180, true); A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_fn_class = fncls__132d; tmp5 = fncls__132d } else { tmp5 = fncls__132 }; tmp3 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp4, tmp5, nil, 0); var tmp6 lang.IFn = Up_Compiler_AOTRestFn_IFn(tmp3); var tmp7 any; var t_ any = t.F_ns_sym; t.F_ns_sym = nil; tmp7 = t_; var tmp8 any = tmp7; var tmp9 any; var t__2 any = t.F_ns_name; t.F_ns_name = nil; tmp9 = t__2; tmp6.Invoke_O_O__O(tmp8, tmp9)
										var tmp10 any; var or__1927000174__auto____3 any = t.F_doc_str; if jrt.A2g_Truth(or__1927000174__auto____3) { tmp10 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any = t.F_attr_map; if jrt.A2g_Truth(or__1927000174__auto____4) { tmp10 = or__1927000174__auto____4 } else { tmp10 = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(t.F_references) } }; if jrt.A2g_Truth(tmp10) {
											var tmp11 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3_2 any = Lit_181; var cf__1819000596__auto____4_2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3_2)) { cf__1819000596__auto____4_2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3_2) } else { cf__1819000596__auto____4_2 = format_in__1819000595__auto____3_2 }; var tmp12 any = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_New_O(cf__1819000596__auto____4_2); var tmp13 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_182, true); A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_fn_class = fncls__133d; tmp13 = fncls__133d } else { tmp13 = fncls__133 }; tmp11 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp12, tmp13, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp11).Invoke__O() }
										if jrt.A2g_Truth(t.F_doc_str) {
											var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_365.GetRawRoot__O()); var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_TRUE; var tmp16 any = tmp15.Ref(); var tmp17 any; var t__3 any = t.F_doc_str; t.F_doc_str = nil; tmp17 = t__3; var tmp18 any = tmp17; var tmp19 any; var or__1927000174__auto____3_2 any = t.F_attr_map; if jrt.A2g_Truth(or__1927000174__auto____3_2) { tmp19 = or__1927000174__auto____3_2 } else { tmp19 = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(t.F_references) }; tmp14.Invoke_O_O_O_O__O(tmp16, Lit_183, tmp18, tmp19) }
										if jrt.A2g_Truth(t.F_attr_map) {
											var tmp20 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3_3 any = Lit_184; var cf__1819000596__auto____4_3 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3_3)) { cf__1819000596__auto____4_3 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3_3) } else { cf__1819000596__auto____4_3 = format_in__1819000595__auto____3_3 }; var tmp21 any = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_New_O(cf__1819000596__auto____4_3); var tmp22 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_185, true); A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_fn_class = fncls__134d; tmp22 = fncls__134d } else { tmp22 = fncls__134 }; tmp20 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp21, tmp22, nil, 0); var tmp23 lang.IFn = Up_Compiler_AOTRestFn_IFn(tmp20); var tmp24 any; var t__4 any = t.F_attr_map; t.F_attr_map = nil; tmp24 = t__4; tmp23.Invoke_O_O__O(tmp24, lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(t.F_references)) }
//line :230:1
	var references__3 any; var t__5 any = t.F_references; t.F_references = nil; references__3 = t__5; L1: for {








		lang.IFn_Cast(A_arbace_pprint_A_const_607.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(references__3))
//line :230:1
		var temp__1927000414__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(references__3)









		if jrt.A2g_Truth(temp__1927000414__auto____4) { var references__5 any = temp__1927000414__auto____4
			lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
			references__3 = references__5; continue L1 }
//line :230:1
		break L1 }; var tmp25 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp25.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp26 != nil { panic(tmp26) }; return tmp1 }
func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :231:1
func (t *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_emit_nl_A_New() *A_arbace_pprint_emit_nl_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_emit_nl_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_pprint_emit_nl_A) Ctor() {}
//line :233:1
func (t *A_arbace_pprint_emit_nl_A) Invoke_O_O_O__O(self, this__0, nl__1 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)));
											jrt.Writer_Cast(w__1820000023__auto____3).Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_145.GetRawRoot__O()).Invoke__O())); var tmp2 any =
											A_arbace_pprint_emit_nl_fn__1820000124_A_New_O(this__0); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_pprint_emit_nl_fn__1820000124_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_pprint_emit_nl_fn__1820000124_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var lb__3 any = /*line :233:1*/A_arbace_pprint_A_const_110.Invoke_O__O(nl__1); var prefix__4 any = A_arbace_pprint_A_const_143.Invoke_O__O(lb__3); if




	jrt.A2g_Truth(prefix__4) { var tmp4 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))
		jrt.Writer_Cast(w__1820000023__auto____5).Write_String__V(jrt.String_Cast(prefix__4)) }; var istr__5 any = /*line :233:1*/lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_115.Invoke_O__O(lb__3)), int64(lang.RT_Count_O__I(prefix__4))), A_arbace_pprint_A_const_148)); var tmp5 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____6 any = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)));








	jrt.Writer_Cast(w__1820000023__auto____6).Write_String__V(jrt.String_Cast(istr__5)); return /*line :243:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_144.GetRawRoot__O()).Invoke_O__O(lb__3) }
//line :233:1
func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :233:1
func (t *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
func A_arbace_pprint_pprint_A_New() *A_arbace_pprint_pprint_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_pprint_pprint_A) Ctor() {}
//line :234:1
func (t *A_arbace_pprint_pprint_A) Invoke_O_O_O__O(self, object__0, writer__1 any) any { var base_writer__693000016__auto____3 any = writer__1; var new_writer__693000017__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_228.GetRawRoot__O()).Invoke_O__O(base_writer__693000016__auto____3)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_A_const_34; var tmp4 any; if





	jrt.A2g_Truth(new_writer__693000017__auto____4) { tmp4 = lang.IFn_Cast(A_arbace_pprint_A_const_229.GetRawRoot__O()).Invoke_O_O_O__O(base_writer__693000016__auto____3, A_arbace_pprint_A_const_230.Get__O(), A_arbace_pprint_A_const_231.Get__O()) } else { tmp4 = base_writer__693000016__auto____3 }; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4)); var tmp5 any; tmp14 := /*line :234:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






		{ var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()); var tmp8 any = A_arbace_pprint_A_const_217; var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9.Ref())); var tmp10 any = A_arbace_pprint_pprint_fn__693000031_A_New_O(object__0); var tmp11 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_pprint_pprint_fn__693000031_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_144, false); A_arbace_pprint_pprint_fn__693000031_A_fn_class = fncls__49d; tmp11 = fncls__49d } else { tmp11 = fncls__49 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()


			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_O__Z(0, lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()))).Ref())) {
				lang.IFn_Cast(A_arbace_pprint_A_const_232.GetRawRoot__O()).Invoke__O() }
//line :240:1
			var target_48 any = A_arbace_pprint_A_const_34.Get__O(); var tmp12 bool; var tmp13 bool; tmp13 = !(target_48 == nil); if tmp13 { tmp13 = lang.Compiler_AOT_IsDyn_O__Z(target_48) }; tmp12 = tmp13; if tmp12 { tmp5 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_48, Lit_145, jrt.RefArrayOf(jrt.Object_class)) } else { A_arbace_pprint_PrettyFlush_A_Cast(target_48).Ppflush__V(); tmp5 = nil } }
//line :234:1
		return nil }();





	lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if /*line :234:1*/ tmp14 != nil { panic(tmp14) }; return tmp5 }
//line :234:1
func (t *A_arbace_pprint_pprint_A) Invoke_O_O__O(self, object__0 any) any {



	return lang.IFn_Cast(A_arbace_pprint_A_const_233.GetRawRoot__O()).Invoke_O_O__O(object__0, A_arbace_pprint_A_const_34.Get__O()) }
//line :235:1
func A_arbace_pprint_emit_nl_fn__1820000124_A_New_O(p0 any) *A_arbace_pprint_emit_nl_fn__1820000124_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_emit_nl_fn__1820000124_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_pprint_emit_nl_fn__1820000124_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :235:1
func (t *A_arbace_pprint_emit_nl_fn__1820000124_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_125, nil) }

func A_arbace_pprint_base_str_fn__1819000039_A_New() *A_arbace_pprint_base_str_fn__1819000039_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_base_str_fn__1819000039_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_pprint_base_str_fn__1819000039_A) Ctor() {}
//line :237:1
func (t *A_arbace_pprint_base_str_fn__1819000039_A) Invoke_O_O__O(self, p1__1819000038_SHARP___1 any) any {
	if lang.Numbers_Lt_O_J__Z(p1__1819000038_SHARP___1, 10) { return jrt.Character_ValueOf_C__Character(lang.RT_CharCast_O__C(lang.Numbers_Add_J_O__Number(int64(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_325)), p1__1819000038_SHARP___1))).Ref() } else { return jrt.Character_ValueOf_C__Character(lang.RT_CharCast_O__C(lang.Numbers_Add_J_O__Number(int64(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_326)), lang.Numbers_Minus_O_J__Number(p1__1819000038_SHARP___1, 10)))).Ref() } }
//line :237:1
func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_New_O(p0 any) *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A{}; t.Ctor_O(p0); return t }
//line :237:1
func (t *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :237:1
func (t *A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }



func A_arbace_pprint_pprint_fn__693000031_A_New_O(p0 any) *A_arbace_pprint_pprint_fn__693000031_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_fn__693000031_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_pprint_pprint_fn__693000031_A) Ctor_O(c__object any) { t.F_object = c__object }
//line :241:1
func (t *A_arbace_pprint_pprint_fn__693000031_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IPersistentMap; var tmp3 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_J__Z(A_arbace_pprint_A_const_226.Get__O(), 10)).Ref()); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { tmp3 = A_arbace_pprint_A_const_224.Get__O() }; if jrt.A2g_Truth(tmp3) { var tmp4 any = A_arbace_pprint_A_const_215; tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, A_arbace_pprint_A_const_225.GetRawRoot__O())) } else { lang.PersistentArrayMap_Init(); tmp2 = Up_PersistentArrayMap_IPersistentMap(lang.PersistentArrayMap_EMPTY) }; lang.Var_PushThreadBindings_Associative__V(tmp2); tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()); var tmp6 any; var t_ any = t.F_object; t.F_object = nil; tmp6 = t_; tmp1 = tmp5.Invoke_O__O(tmp6) }
//line :242:1
		return nil }(); lang.Var_PopThreadBindings__V()
//line :241:1
		if tmp7 != nil { panic(tmp7) } }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }


func A_arbace_pprint_opt_base_str_A_New() *A_arbace_pprint_opt_base_str_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_opt_base_str_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_pprint_opt_base_str_A) Ctor() {}
//line :244:1
func (t *A_arbace_pprint_opt_base_str_A) Invoke_O_O_O__O(self, base__0, val__1 any) any { var format_str__3 any = lang.RT_Get_O_O__O(A_arbace_pprint_A_const_328.GetRawRoot__O(), base__0); var tmp1 any; var and__1927000168__auto____4 any = format_str__3; if




	jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_310.GetRawRoot__O()).Invoke_O__O(val__1); if jrt.A2g_Truth(and__1927000168__auto____5) { tmp1 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.BigInt_InstanceOf(val__1)).Ref()) } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_329.GetRawRoot__O()).Invoke_O_O__O(format_str__3, val__1) } else {
			return lang.IFn_Cast(A_arbace_pprint_A_const_330.GetRawRoot__O()).Invoke_O_O__O(base__0, val__1) } }
//line :245:1
func A_arbace_pprint_split_at_newline_A_New() *A_arbace_pprint_split_at_newline_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_split_at_newline_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_pprint_split_at_newline_A) Ctor() {}
//line :245:1
func (t *A_arbace_pprint_split_at_newline_A) Invoke_O_O__O(self, tokens__0 any) any { var pre__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_139.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_split_at_newline_fn__1820000128_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_pprint_split_at_newline_fn__1820000128_A_fn_class; if
											fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_256, false); A_arbace_pprint_split_at_newline_fn__1820000128_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; pre__2 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), tokens__0)); return /*line :245:1*/ lang.Tuple_Create_O_O__IPersistentVector(pre__2, lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_142.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(pre__2)).Ref(), tokens__0))) }
func A_arbace_pprint_split_at_newline_fn__1820000128_A_New() *A_arbace_pprint_split_at_newline_fn__1820000128_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_split_at_newline_fn__1820000128_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_pprint_split_at_newline_fn__1820000128_A) Ctor() {}
//line :246:1
func (t *A_arbace_pprint_split_at_newline_fn__1820000128_A) Invoke_O_O__O(self, p1__1820000127_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_140.GetRawRoot__O()).Invoke_O__O(p1__1820000127_SHARP___1)) }
func A_arbace_pprint_pp_A_New() *A_arbace_pprint_pp_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pp_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_pprint_pp_A) Ctor() {}
//line :247:1
func (t *A_arbace_pprint_pp_A) Invoke_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_234), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_235))) }


func A_arbace_pprint_fn__740000107_A_New() *A_arbace_pprint_fn__740000107_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__740000107_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_pprint_fn__740000107_A) Ctor() {}
//line :250:1
func (t *A_arbace_pprint_fn__740000107_A) Invoke_O__O(self any) any { var format_in__1819000595__auto____1 any = Lit_95; var cf__1819000596__auto____2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____1)) { cf__1819000596__auto____2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____1) } else { cf__1819000596__auto____2 = format_in__1819000595__auto____1 }; var tmp1 any = A_arbace_pprint_fn__740000107_fn__740000108_A_New_O(cf__1819000596__auto____2); var tmp2 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_pprint_fn__740000107_fn__740000108_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, true); A_arbace_pprint_fn__740000107_fn__740000108_A_fn_class = fncls__136d; tmp2 = fncls__136d } else { tmp2 = fncls__136 }; return lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 0) }
//line :250:1
func A_arbace_pprint_fn__740000107_fn__740000108_A_New_O(p0 any) *A_arbace_pprint_fn__740000107_fn__740000108_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__740000107_fn__740000108_A{}; t.Ctor_O(p0); return t }
//line :250:1
func (t *A_arbace_pprint_fn__740000107_fn__740000108_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :250:1
func (t *A_arbace_pprint_fn__740000107_fn__740000108_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_eval1820000133_fn__1820000134_A_New() *A_arbace_pprint_eval1820000133_fn__1820000134_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000133_fn__1820000134_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_pprint_eval1820000133_fn__1820000134_A) Ctor() {}
//line :252:1
func (t *A_arbace_pprint_eval1820000133_fn__1820000134_A) Invoke_O_O__O(self, token__1 any) any {
	return A_arbace_pprint_A_const_126.Invoke_O__O(token__1) }
//line :253:1
func A_arbace_pprint_group_by_STAR__A_New() *A_arbace_pprint_group_by_STAR__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_group_by_STAR__A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_pprint_group_by_STAR__A) Ctor() {}
//line :253:1
func (t *A_arbace_pprint_group_by_STAR__A) Invoke_O_O_O__O(self, unit__0, lis__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_322.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_group_by_STAR__fn__1819000043_A_New_O(unit__0); var tmp5 *jrt.Class
	var fncls__53 /*line :254:1*/*jrt.Class = A_arbace_pprint_group_by_STAR__fn__1819000043_A_fn_class

	if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_pprint_group_by_STAR__fn__1819000043_A_fn_class = fncls__53d; tmp5 = fncls__53d } else { tmp5 = fncls__53 }
//line :254:1
	return tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_pprint_A_const_322.GetRawRoot__O()).Invoke_O__O(lis__1)))) }
//line :253:1
func A_arbace_pprint_set_pprint_dispatch_A_New() *A_arbace_pprint_set_pprint_dispatch_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_pprint_dispatch_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_pprint_set_pprint_dispatch_A) Ctor() {}
//line :253:1
func (t *A_arbace_pprint_set_pprint_dispatch_A) Invoke_O_O__O(self, function__0 any) any { var old_meta__2 any = lang.RT_Meta_O__IPersistentMap(A_arbace_pprint_A_const_216); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_237.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_216;









	tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_pprint_A_const_238.GetRawRoot__O()).Invoke_O__O(function__0)); var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_pprint_A_const_236.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_A_const_216; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_pprint_A_const_238.GetRawRoot__O()).Invoke_O__O(old_meta__2)); return nil }
//line :254:1
func A_arbace_pprint_eval1820000137_fn__1820000138_A_New() *A_arbace_pprint_eval1820000137_fn__1820000138_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000137_fn__1820000138_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_pprint_eval1820000137_fn__1820000138_A) Ctor() {}
//line :254:1
func (t *A_arbace_pprint_eval1820000137_fn__1820000138_A) Invoke_O_O__O(self, token__1 any) any {
	return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_23, nil, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_pprint_A_const_124.Invoke_O__O(token__1), A_arbace_pprint_A_const_125.Invoke_O__O(token__1), nil)).Ref() }
func A_arbace_pprint_eval1820000141_fn__1820000142_A_New() *A_arbace_pprint_eval1820000141_fn__1820000142_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_eval1820000141_fn__1820000142_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_pprint_eval1820000141_fn__1820000142_A) Ctor() {}
//line :256:1
func (t *A_arbace_pprint_eval1820000141_fn__1820000142_A) Invoke_O_O__O(self, token__1 any) any {
	return A_arbace_pprint_A_const_71.Invoke_O__O(token__1) }
//line :256:1
func A_arbace_pprint_group_by_STAR__fn__1819000043_A_New_O(p0 any) *A_arbace_pprint_group_by_STAR__fn__1819000043_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_group_by_STAR__fn__1819000043_A{}; t.Ctor_O(p0); return t }
//line :256:1
func (t *A_arbace_pprint_group_by_STAR__fn__1819000043_A) Ctor_O(c__unit any) { t.F_unit = c__unit }
//line :256:1
func (t *A_arbace_pprint_group_by_STAR__fn__1819000043_A) Invoke_O_O__O(self, x__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_322.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_242.GetRawRoot__O()).Invoke_O_O__O(t.F_unit, x__1))), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_142.GetRawRoot__O()).Invoke_O_O__O(t.F_unit, x__1))) }
func A_arbace_pprint_single_defn_A_New() *A_arbace_pprint_single_defn_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_single_defn_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_pprint_single_defn_A) Ctor() {}
//line :257:1
func (t *A_arbace_pprint_single_defn_A) Invoke_O_O_O__O(self, alis__0, has_doc_str_QMARK___1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(alis__0)) {

		if jrt.A2g_Truth(has_doc_str_QMARK___1) {
			var tmp1 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3 any = Lit_250; var cf__1819000596__auto____4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3)) { cf__1819000596__auto____4 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3) } else { cf__1819000596__auto____4 = format_in__1819000595__auto____3 }; var tmp2 any = A_arbace_pprint_single_defn_fn__740000111_A_New_O(cf__1819000596__auto____4); var tmp3 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_pprint_single_defn_fn__740000111_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_251, true); A_arbace_pprint_single_defn_fn__740000111_A_fn_class = fncls__138d; tmp3 = fncls__138d } else { tmp3 = fncls__138 }; tmp1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp1).Invoke__O() } else {
				var tmp4 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3_2 any = Lit_252; var cf__1819000596__auto____4_2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3_2)) { cf__1819000596__auto____4_2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3_2) } else { cf__1819000596__auto____4_2 = format_in__1819000595__auto____3_2 }; var tmp5 any = A_arbace_pprint_single_defn_fn__740000113_A_New_O(cf__1819000596__auto____4_2); var tmp6 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_pprint_single_defn_fn__740000113_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_253, true); A_arbace_pprint_single_defn_fn__740000113_A_fn_class = fncls__139d; tmp6 = fncls__139d } else { tmp6 = fncls__139 }; tmp4 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp4).Invoke__O() }
		var tmp7 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3_3 any = Lit_254; var cf__1819000596__auto____4_3 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3_3)) { cf__1819000596__auto____4_3 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3_3) } else { cf__1819000596__auto____4_3 = format_in__1819000595__auto____3_3 }; var tmp8 any = A_arbace_pprint_single_defn_fn__740000115_A_New_O(cf__1819000596__auto____4_3); var tmp9 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_pprint_single_defn_fn__740000115_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_255, true); A_arbace_pprint_single_defn_fn__740000115_A_fn_class = fncls__137d; tmp9 = fncls__137d } else { tmp9 = fncls__137 }; tmp7 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp8, tmp9, nil, 0); return Up_Compiler_AOTRestFn_IFn(tmp7).Invoke_O__O(alis__0) } else {
//line :258:1
			return nil } }
//line :258:1
func A_arbace_pprint_format_integer_A_New() *A_arbace_pprint_format_integer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_integer_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_pprint_format_integer_A) Ctor() {}
//line :258:1
func (t *A_arbace_pprint_format_integer_A) Invoke_O_O_O_O_O__O(self, base__0, params__1, arg_navigator__2, offsets__3 any) any { var vec__1819000047__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(arg_navigator__2); var arg__6 any = lang.RT_Nth_O_I_O__O(vec__1819000047__5, lang.RT_IntCast_J__I(0), nil); var arg_navigator__7 any = lang.RT_Nth_O_I_O__O(vec__1819000047__5, lang.RT_IntCast_J__I(1), nil); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_331.GetRawRoot__O()).Invoke_O__O(arg__6)) { var neg__8 bool = lang.Numbers_IsNeg_O__Z(arg__6); var pos_arg__9 any

		if neg__8 { pos_arg__9 = lang.Numbers_Minus_O__Number(arg__6) } else { pos_arg__9 = arg__6 }
//line :260:1
		var raw_str__10 any = lang.IFn_Cast(A_arbace_pprint_A_const_312.GetRawRoot__O()).Invoke_O_O__O(base__0, pos_arg__9); var group_str__11 any



		if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__1)) { var groups__11 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_format_integer_fn__1819000050_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_pprint_format_integer_fn__1819000050_A_fn_class
			if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_101, false); A_arbace_pprint_format_integer_fn__1819000050_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; groups__11 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_pprint_A_const_334.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_335.Invoke_O__O(params__1), raw_str__10))
//line :264:1
			var commas__12 any = lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(groups__11)).Ref(), A_arbace_pprint_A_const_336.Invoke_O__O(params__1))


			group_str__11 = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_337.GetRawRoot__O()).Invoke_O_O__O(commas__12, groups__11))) } else {
//line :264:1
				group_str__11 = raw_str__10 }
//line :260:1
		var signed_str__12 any








		if neg__8 {
			signed_str__12 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, group_str__11)).Ref() } else {
//line :269:1
				if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__1)) {

					signed_str__12 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, group_str__11)).Ref() } else {
//line :269:1
						var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp4.Ref()) { signed_str__12 = group_str__11 } else { signed_str__12 = nil } } }
//line :260:1
		var padded_str__13 any












		if lang.Numbers_Lt_J_O__Z(int64(jrt.NN(jrt.String_Cast(signed_str__12)).Length__I()), A_arbace_pprint_A_const_315.Invoke_O__O(params__1)) {
			padded_str__13 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(A_arbace_pprint_A_const_315.Invoke_O__O(params__1), int64(jrt.NN(jrt.String_Cast(signed_str__12)).Length__I())), A_arbace_pprint_A_const_317.Invoke_O__O(params__1))), signed_str__12)).Ref() } else {
//line :273:1
				padded_str__13 = signed_str__12
			}



		lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(padded_str__13) } else {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_333.GetRawRoot__O()); var tmp6 any = A_arbace_pprint_A_const_338.GetRawRoot__O(); var tmp7 any = A_arbace_pprint_A_const_315; var tmp8 any = A_arbace_pprint_A_const_315.Invoke_O__O(params__1); var tmp9 any = A_arbace_pprint_A_const_316; var tmp10 any = A_arbace_pprint_A_const_176; var tmp11 any = A_arbace_pprint_A_const_314; var tmp12 any = A_arbace_pprint_A_const_28; var tmp13 any = A_arbace_pprint_A_const_317; var tmp14 any = A_arbace_pprint_A_const_317.Invoke_O__O(params__1); var tmp15 any = A_arbace_pprint_A_const_318; var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; tmp5.Invoke_O_O_O_O__O(tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16.Ref())), lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O__IPersistentVector(arg__6)), nil) }; return arg_navigator__7 }
//line :258:1
func A_arbace_pprint_toks_A_New() *A_arbace_pprint_toks_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_toks_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_pprint_toks_A) Ctor() {}
//line :258:1
func (t *A_arbace_pprint_toks_A) Invoke_O_O__O(self, toks__0 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_150.GetRawRoot__O(), toks__0) }


func A_arbace_pprint_single_defn_fn__740000111_A_New_O(p0 any) *A_arbace_pprint_single_defn_fn__740000111_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_single_defn_fn__740000111_A{}; t.Ctor_O(p0); return t }
//line :261:1
func (t *A_arbace_pprint_single_defn_fn__740000111_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :261:1
func (t *A_arbace_pprint_single_defn_fn__740000111_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
func A_arbace_pprint_single_defn_fn__740000113_A_New_O(p0 any) *A_arbace_pprint_single_defn_fn__740000113_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_single_defn_fn__740000113_A{}; t.Ctor_O(p0); return t }
//line :262:1
func (t *A_arbace_pprint_single_defn_fn__740000113_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :262:1
func (t *A_arbace_pprint_single_defn_fn__740000113_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
func A_arbace_pprint_single_defn_fn__740000115_A_New_O(p0 any) *A_arbace_pprint_single_defn_fn__740000115_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_single_defn_fn__740000115_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_pprint_single_defn_fn__740000115_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :263:1
func (t *A_arbace_pprint_single_defn_fn__740000115_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
//line :263:1
func A_arbace_pprint_write_token_string_A_New() *A_arbace_pprint_write_token_string_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_token_string_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_pprint_write_token_string_A) Ctor() {}
//line :263:1
func (t *A_arbace_pprint_write_token_string_A) Invoke_O_O_O__O(self, this__0, tokens__1 any) any { var vec__1820000146__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_151.GetRawRoot__O()).Invoke_O__O(tokens__1); var a__4 any = lang.RT_Nth_O_I_O__O(vec__1820000146__3, lang.RT_IntCast_J__I(0), nil); var b__5 any = lang.RT_Nth_O_I_O__O(vec__1820000146__3, lang.RT_IntCast_J__I(1), nil); if


	jrt.A2g_Truth(a__4) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_155.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; tmp1.Invoke_O_O_O__O(this__0, a__4, tmp2.Ref()) }; if
	jrt.A2g_Truth(b__5) { var vec__1820000149__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_152.GetRawRoot__O()).Invoke_O__O(b__5); var section__7 any = lang.RT_Nth_O_I_O__O(vec__1820000149__6, lang.RT_IntCast_J__I(0), nil); var remainder__8 any = lang.RT_Nth_O_I_O__O(vec__1820000149__6, lang.RT_IntCast_J__I(1), nil); var newl__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(b__5); var do_nl__10 any = lang.IFn_Cast(A_arbace_pprint_A_const_153.GetRawRoot__O()).Invoke_O_O_O_O__O(newl__9, this__0, section__7, lang.IFn_Cast(A_arbace_pprint_A_const_156.GetRawRoot__O()).Invoke_O__O(b__5)); var result__11 any




		if jrt.A2g_Truth(do_nl__10) {


			lang.IFn_Cast(A_arbace_pprint_A_const_128.GetRawRoot__O()).Invoke_O_O__O(this__0, newl__9)
			result__11 = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(b__5) } else {
//line :272:1
				result__11 = b__5 }
//line :267:1
		var long_section__12 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_134.GetRawRoot__O()).Invoke_O_O__O(this__0, result__11)); var result__13 any











		if jrt.A2g_Truth(long_section__12) { var rem2__13 any = lang.IFn_Cast(A_arbace_pprint_A_const_154.GetRawRoot__O()).Invoke_O_O__O(this__0, section__7)


			if lang.Util_Equiv_O_O__Z(rem2__13, section__7) {


				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_155.GetRawRoot__O()); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp3.Invoke_O_O_O__O(this__0, section__7, tmp4.Ref())
//line :282:1
				result__13 = remainder__8 } else {




					var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; var tmp7 any = tmp6.Ref(); result__13 = tmp5.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(rem2__13, remainder__8)) } } else {
//line :279:1
						result__13 = result__11 }
//line :267:1
		return result__13 } else { return nil } }
//line :265:1
func A_arbace_pprint_format_integer_fn__1819000050_A_New() *A_arbace_pprint_format_integer_fn__1819000050_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_integer_fn__1819000050_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_pprint_format_integer_fn__1819000050_A) Ctor() {}
//line :265:1
func (t *A_arbace_pprint_format_integer_fn__1819000050_A) Invoke_O_O__O(self, p1__1819000046_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), p1__1819000046_SHARP___1) }
func A_arbace_pprint_multi_defn_A_New() *A_arbace_pprint_multi_defn_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_multi_defn_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_pprint_multi_defn_A) Ctor() {}
//line :266:1
func (t *A_arbace_pprint_multi_defn_A) Invoke_O_O_O__O(self, alis__0, has_doc_str_QMARK___1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(alis__0)) {
		var tmp1 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3 any = Lit_137; var cf__1819000596__auto____4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3)) { cf__1819000596__auto____4 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3) } else { cf__1819000596__auto____4 = format_in__1819000595__auto____3 }; var tmp2 any = A_arbace_pprint_multi_defn_fn__740000118_A_New_O(cf__1819000596__auto____4); var tmp3 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_pprint_multi_defn_fn__740000118_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_138, true); A_arbace_pprint_multi_defn_fn__740000118_A_fn_class = fncls__140d; tmp3 = fncls__140d } else { tmp3 = fncls__140 }; tmp1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0); return Up_Compiler_AOTRestFn_IFn(tmp1).Invoke_O__O(alis__0) } else {
//line :267:1
			return nil } }
//line :267:1
func A_arbace_pprint_with_pprint_dispatch_A_New() *A_arbace_pprint_with_pprint_dispatch_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_with_pprint_dispatch_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_pprint_with_pprint_dispatch_A) Ctor() {}
//line :267:1
func (t *A_arbace_pprint_with_pprint_dispatch_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, function__2, body__3 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_239), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_240), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(function__2))))), body__3)) }
func A_arbace_pprint_multi_defn_fn__740000118_A_New_O(p0 any) *A_arbace_pprint_multi_defn_fn__740000118_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_multi_defn_fn__740000118_A{}; t.Ctor_O(p0); return t }
//line :268:1
func (t *A_arbace_pprint_multi_defn_fn__740000118_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :268:1
func (t *A_arbace_pprint_multi_defn_fn__740000118_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }



func A_arbace_pprint_pprint_defn_A_New() *A_arbace_pprint_pprint_defn_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_defn_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_pprint_pprint_defn_A) Ctor() {}
//line :272:1
func (t *A_arbace_pprint_pprint_defn_A) Invoke_O_O__O(self, alis__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(alis__0)) { var vec__740000121__2 any = alis__0; var seq__740000122__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(vec__740000121__2); var first__740000123__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__740000122__3); var seq__740000122__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__740000122__3); var defn_sym__6 any = first__740000123__4; var first__740000123__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__740000122__5); var seq__740000122__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__740000122__5); var defn_name__9 any = first__740000123__7; var stuff__10 any = seq__740000122__8; var vec__740000124__11 any

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(stuff__10))) { vec__740000124__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(stuff__10), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(stuff__10)) } else { vec__740000124__11 = lang.Tuple_Create_O_O__IPersistentVector(nil, stuff__10) }
//line :273:1
		var doc_str__12 any = lang.RT_Nth_O_I_O__O(vec__740000124__11, lang.RT_IntCast_J__I(0), nil); var stuff__13 any = lang.RT_Nth_O_I_O__O(vec__740000124__11, lang.RT_IntCast_J__I(1), nil); var vec__740000127__14 any




		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_606.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(stuff__13))) { vec__740000127__14 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(stuff__13), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(stuff__13)) } else { vec__740000127__14 = lang.Tuple_Create_O_O__IPersistentVector(nil, stuff__13) }
//line :273:1
		var attr_map__15 any = lang.RT_Nth_O_I_O__O(vec__740000127__14, lang.RT_IntCast_J__I(0), nil); var stuff__16 any = lang.RT_Nth_O_I_O__O(vec__740000127__14, lang.RT_IntCast_J__I(1), nil)







		if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_defn_fn__740000130_A_New_O_O_O_O_O(stuff__16, defn_sym__6, defn_name__9, doc_str__12, attr_map__15); var tmp3 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_pprint_pprint_defn_fn__740000130_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_161, false); A_arbace_pprint_pprint_defn_fn__740000130_A_fn_class = fncls__144d; tmp3 = fncls__144d } else { tmp3 = fncls__144 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :273:1
		return nil } else {

















			return lang.IFn_Cast(A_arbace_pprint_A_const_608.GetRawRoot__O()).Invoke_O__O(alis__0) } }
//line :278:1
func A_arbace_pprint_parse_lb_options_A_New() *A_arbace_pprint_parse_lb_options_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_parse_lb_options_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_pprint_parse_lb_options_A) Ctor() {}
//line :278:1
func (t *A_arbace_pprint_parse_lb_options_A) Invoke_O_O_O__O(self, opts__0, body__1 any) any { { var body__3 any = body__1; var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); L1: for {


	if jrt.A2g_Truth(lang.IFn_Cast(opts__0).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(body__3))) {
		body__3, acc__4 = lang.IFn_Cast(A_arbace_pprint_A_const_142.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_241, body__3), lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.IFn_Cast(A_arbace_pprint_A_const_242.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_241, body__3)); continue L1 } else {
//line :281:1
			return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_33.GetRawRoot__O(), acc__4), body__3) } } }; /*line :278:1*/panic("a2g: unreachable") }


func A_arbace_pprint_pprint_defn_fn__740000130_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_pprint_pprint_defn_fn__740000130_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_defn_fn__740000130_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :281:1
func (t *A_arbace_pprint_pprint_defn_fn__740000130_A) Ctor_O_O_O_O_O(c__stuff, c__defn_sym, c__defn_name, c__doc_str, c__attr_map any) { t.F_stuff = c__stuff; t.F_defn_sym = c__defn_sym; t.F_defn_name = c__defn_name; t.F_doc_str = c__doc_str; t.F_attr_map = c__attr_map }
//line :281:1
func (t *A_arbace_pprint_pprint_defn_fn__740000130_A) Invoke_O__O(self any) any { var tmp1 any; tmp25 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_102, nil, Lit_103)
										var tmp3 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3 any = Lit_162; var cf__1819000596__auto____4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3)) { cf__1819000596__auto____4 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3) } else { cf__1819000596__auto____4 = format_in__1819000595__auto____3 }; var tmp4 any = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_New_O(cf__1819000596__auto____4); var tmp5 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_163, true); A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_fn_class = fncls__141d; tmp5 = fncls__141d } else { tmp5 = fncls__141 }; tmp3 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp4, tmp5, nil, 0); var tmp6 lang.IFn = Up_Compiler_AOTRestFn_IFn(tmp3); var tmp7 any; var t_ any = t.F_defn_sym; t.F_defn_sym = nil; tmp7 = t_; var tmp8 any = tmp7; var tmp9 any; var t__2 any = t.F_defn_name; t.F_defn_name = nil; tmp9 = t__2; tmp6.Invoke_O_O__O(tmp8, tmp9)
										if jrt.A2g_Truth(t.F_doc_str) {
											var tmp10 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3_2 any = Lit_164; var cf__1819000596__auto____4_2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3_2)) { cf__1819000596__auto____4_2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3_2) } else { cf__1819000596__auto____4_2 = format_in__1819000595__auto____3_2 }; var tmp11 any = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_New_O(cf__1819000596__auto____4_2); var tmp12 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_165, true); A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_fn_class = fncls__142d; tmp12 = fncls__142d } else { tmp12 = fncls__142 }; tmp10 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp11, tmp12, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp10).Invoke_O__O(t.F_doc_str) }
										if jrt.A2g_Truth(t.F_attr_map) {
											var tmp13 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3_3 any = Lit_164; var cf__1819000596__auto____4_3 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3_3)) { cf__1819000596__auto____4_3 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3_3) } else { cf__1819000596__auto____4_3 = format_in__1819000595__auto____3_3 }; var tmp14 any = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_New_O(cf__1819000596__auto____4_3); var tmp15 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_166, true); A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_fn_class = fncls__143d; tmp15 = fncls__143d } else { tmp15 = fncls__143 }; tmp13 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp14, tmp15, nil, 0); Up_Compiler_AOTRestFn_IFn(tmp13).Invoke_O__O(t.F_attr_map)
										}
										if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_600.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_stuff))) {
											var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_609.GetRawRoot__O()); var tmp17 any; var t__3 any = t.F_stuff; t.F_stuff = nil; tmp17 = t__3; var tmp18 any = tmp17; var tmp19 any; var or__1927000174__auto____3 any; var t__4 any = t.F_doc_str; t.F_doc_str = nil; or__1927000174__auto____3 = t__4; if jrt.A2g_Truth(or__1927000174__auto____3) { tmp19 = or__1927000174__auto____3 } else { var t__5 any = t.F_attr_map; t.F_attr_map = nil; tmp19 = t__5 }; tmp16.Invoke_O_O__O(tmp18, tmp19) } else {
//line :288:1
			if A_arbace_pprint_A_const_95 != nil {

				var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_610.GetRawRoot__O()); var tmp21 any; var t__6 any = t.F_stuff; t.F_stuff = nil; tmp21 = t__6; var tmp22 any = tmp21; var tmp23 any; var or__1927000174__auto____3_2 any; var t__7 any = t.F_doc_str; t.F_doc_str = nil; or__1927000174__auto____3_2 = t__7; if jrt.A2g_Truth(or__1927000174__auto____3_2) { tmp23 = or__1927000174__auto____3_2 } else { var t__8 any = t.F_attr_map; t.F_attr_map = nil; tmp23 = t__8 }; tmp20.Invoke_O_O__O(tmp22, tmp23) } }
//line :281:1
	var tmp24 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp24.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp25 != nil { panic(tmp25) }; return tmp1 }
func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_New_O(p0 any) *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A{}; t.Ctor_O(p0); return t }
//line :282:1
func (t *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :282:1
func (t *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_New_O(p0 any) *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A{}; t.Ctor_O(p0); return t }
//line :284:1
func (t *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :284:1
func (t *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
func A_arbace_pprint_check_enumerated_arg_A_New() *A_arbace_pprint_check_enumerated_arg_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_check_enumerated_arg_A{}; t.Ctor(); return t }
//line :285:1
func (t *A_arbace_pprint_check_enumerated_arg_A) Ctor() {}
//line :285:1
func (t *A_arbace_pprint_check_enumerated_arg_A) Invoke_O_O_O__O(self, arg__0, choices__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(choices__1).Invoke_O__O(arg__0))) { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, arg__0, nil, choices__1))))) } else { return nil } }
//line :286:1
func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_New_O(p0 any) *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :286:1
func (t *A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }





func A_arbace_pprint_level_exceeded_A_New() *A_arbace_pprint_level_exceeded_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_level_exceeded_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_pprint_level_exceeded_A) Ctor() {}
//line :292:1
func (t *A_arbace_pprint_level_exceeded_A) Invoke_O__O(self any) any { var and__1927000168__auto____1 any = A_arbace_pprint_A_const_243.Get__O(); if
									jrt.A2g_Truth(and__1927000168__auto____1) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_O_O__Z(A_arbace_pprint_A_const_244.Get__O(), A_arbace_pprint_A_const_243.Get__O())).Ref() } else { return and__1927000168__auto____1 } }
//line :293:1
func A_arbace_pprint_write_line_A_New() *A_arbace_pprint_write_line_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_line_A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_pprint_write_line_A) Ctor() {}
//line :293:1
func (t *A_arbace_pprint_write_line_A) Invoke_O_O__O(self, this__0 any) any {
	var tmp1 any = A_arbace_pprint_write_line_fn__1820000153_A_New_O(this__0); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_pprint_write_line_fn__1820000153_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_279, false); A_arbace_pprint_write_line_fn__1820000153_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :294:1
func A_arbace_pprint_write_line_fn__1820000153_A_New_O(p0 any) *A_arbace_pprint_write_line_fn__1820000153_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_line_fn__1820000153_A{}; t.Ctor_O(p0); return t }
//line :294:1
func (t *A_arbace_pprint_write_line_fn__1820000153_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :294:1
func (t *A_arbace_pprint_write_line_fn__1820000153_A) Invoke_O__O(self any) any { { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_157; var buffer__1 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); L1: for {


	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this); var tmp4 any = A_arbace_pprint_A_const_44.GetRawRoot__O(); var tmp5 any = A_arbace_pprint_A_const_157; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp7 *lang.PersistentVector; lang.PersistentVector_Init(); tmp7 = lang.PersistentVector_EMPTY; tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7.Ref(), buffer__1))
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_134.GetRawRoot__O()).Invoke_O_O__O(t.F_this, buffer__1))) { var new_buffer__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_154.GetRawRoot__O()).Invoke_O_O__O(t.F_this, buffer__1)


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(buffer__1, new_buffer__2)).Ref())) {
			buffer__1 = new_buffer__2; continue L1 } else {
//line :301:1
				return nil } } else {
//line :298:1
					return nil } } }; /*line :294:1*/panic("a2g: unreachable") }
func A_arbace_pprint_pprint_logical_block_A_New() *A_arbace_pprint_pprint_logical_block_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_logical_block_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_pprint_pprint_logical_block_A) Ctor() {}
//line :295:1
func (t *A_arbace_pprint_pprint_logical_block_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, args__2 any) any { var vec__693000048__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_245.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_246, args__2); var options__5 any = lang.RT_Nth_O_I_O__O(vec__693000048__4, lang.RT_IntCast_J__I(0), nil); var body__6 any = lang.RT_Nth_O_I_O__O(vec__693000048__4, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_88.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_251; return /*line :306:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_247), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_248), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_249))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_250), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_33.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_90), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_252)))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(Lit_104)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_253), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_254), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_33.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_255)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_256), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_257), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_258)))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_259)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_28)))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_260), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_261)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_262), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_113.Invoke_O__O(options__5)), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_143.Invoke_O__O(options__5)), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_118.Invoke_O__O(options__5))))), body__6, lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_263)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_264)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_265), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_266)))))))))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(nil))) }
//line :297:1
func A_arbace_pprint_pprint_binding_form_A_New() *A_arbace_pprint_pprint_binding_form_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_binding_form_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_pprint_pprint_binding_form_A) Ctor() {}
//line :297:1
func (t *A_arbace_pprint_pprint_binding_form_A) Invoke_O_O__O(self, binding_vec__0 any) any {
	if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_binding_form_fn__740000139_A_New_O(binding_vec__0); var tmp3 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_pprint_pprint_binding_form_fn__740000139_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_150, false); A_arbace_pprint_pprint_binding_form_fn__740000139_A_fn_class = fncls__146d; tmp3 = fncls__146d } else { tmp3 = fncls__146 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :297:1
	return nil }
func A_arbace_pprint_pprint_binding_form_fn__740000139_A_New_O(p0 any) *A_arbace_pprint_pprint_binding_form_fn__740000139_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_binding_form_fn__740000139_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_pprint_pprint_binding_form_fn__740000139_A) Ctor_O(c__binding_vec any) { t.F_binding_vec = c__binding_vec }
//line :298:1
func (t *A_arbace_pprint_pprint_binding_form_fn__740000139_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_151, nil, Lit_152); var length_count740000140__3 int64 = 0; var binding__4 any; var t_ any = t.F_binding_vec; t.F_binding_vec = nil; binding__4 = t_; L1: for {
											var tmp3 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_214.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp3 = or__1927000174__auto____5 } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_O__Z(length_count740000140__3, A_arbace_pprint_A_const_214.Get__O())).Ref() }; if jrt.A2g_Truth(tmp3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(binding__4)) { if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp4 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp5 any = A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_New_O(binding__4); var tmp6 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_153, false); A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_fn_class = fncls__145d; tmp6 = fncls__145d } else { tmp6 = fncls__145 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O() }; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(binding__4))) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)









		lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :299:1
		length_count740000140__3, binding__4 = lang.Numbers_Inc_J__J(length_count740000140__3), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(binding__4)); continue L1 } } } else { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_154) }
//line :298:1
	break L1 }; var tmp7 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp7.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
func A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_New_O(p0 any) *A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A) Ctor_O(c__binding any) { t.F_binding = c__binding }
//line :299:1
func (t *A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), nil, nil, nil)


	lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_binding))
//line :299:1
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_binding)) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)





		lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_438)
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()); var tmp5 any; var t_ any = t.F_binding; t.F_binding = nil; tmp5 = t_; tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)) }
//line :299:1
	var tmp6 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp6.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }






func A_arbace_pprint_add_to_buffer_A_New() *A_arbace_pprint_add_to_buffer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_add_to_buffer_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_pprint_add_to_buffer_A) Ctor() {}
//line :306:1
func (t *A_arbace_pprint_add_to_buffer_A) Invoke_O_O_O__O(self, this__0, token__1 any) any {

	var tmp1 any = A_arbace_pprint_add_to_buffer_fn__1820000156_A_New_O_O(token__1, this__0); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_pprint_add_to_buffer_fn__1820000156_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_pprint_add_to_buffer_fn__1820000156_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :308:1
func A_arbace_pprint_add_to_buffer_fn__1820000156_A_New_O_O(p0, p1 any) *A_arbace_pprint_add_to_buffer_fn__1820000156_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_add_to_buffer_fn__1820000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :308:1
func (t *A_arbace_pprint_add_to_buffer_fn__1820000156_A) Ctor_O_O(c__token, c__this any) { t.F_token = c__token; t.F_this = c__this }
//line :308:1
func (t *A_arbace_pprint_add_to_buffer_fn__1820000156_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this); var tmp3 any = A_arbace_pprint_A_const_44.GetRawRoot__O(); var tmp4 any = A_arbace_pprint_A_const_157; var tmp5 *lang.Keyword = A_arbace_pprint_A_const_157; tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.IFn_Cast(A_arbace_pprint_A_const_8.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))), t.F_token))
	var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_134.GetRawRoot__O()); var tmp7 any = t.F_this; var tmp8 *lang.Keyword = A_arbace_pprint_A_const_157; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))))) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_158.GetRawRoot__O()).Invoke_O__O(t.F_this) } else {
//line :310:1
			return nil
		} }
func A_arbace_pprint_pprint_let_A_New() *A_arbace_pprint_pprint_let_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_let_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_pprint_pprint_let_A) Ctor() {}
//line :312:1
func (t *A_arbace_pprint_pprint_let_A) Invoke_O_O__O(self, alis__0 any) any { var base_sym__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(alis__0); if

	jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_let_fn__740000145_A_New_O_O(alis__0, base_sym__2); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_pprint_pprint_let_fn__740000145_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_169, false); A_arbace_pprint_pprint_let_fn__740000145_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }; return nil }
//line :314:1
func A_arbace_pprint_pprint_let_fn__740000145_A_New_O_O(p0, p1 any) *A_arbace_pprint_pprint_let_fn__740000145_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_let_fn__740000145_A{}; t.Ctor_O_O(p0, p1); return t }
//line :314:1
func (t *A_arbace_pprint_pprint_let_fn__740000145_A) Ctor_O_O(c__alis, c__base_sym any) { t.F_alis = c__alis; t.F_base_sym = c__base_sym }
//line :314:1
func (t *A_arbace_pprint_pprint_let_fn__740000145_A) Invoke_O__O(self any) any { var tmp1 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_102, nil, Lit_103)
										var tmp3 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_alis); if jrt.A2g_Truth(and__1927000168__auto____3) { tmp3 = lang.IFn_Cast(A_arbace_pprint_A_const_600.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(t.F_alis)) } else { tmp3 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp3) {

		var tmp4 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3 any = Lit_170; var cf__1819000596__auto____4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3)) { cf__1819000596__auto____4 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3) } else { cf__1819000596__auto____4 = format_in__1819000595__auto____3 }; var tmp5 any = A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_New_O(cf__1819000596__auto____4); var tmp6 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_171, true); A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_fn_class = fncls__148d; tmp6 = fncls__148d } else { tmp6 = fncls__148 }; tmp4 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0); var tmp7 lang.IFn = Up_Compiler_AOTRestFn_IFn(tmp4); var tmp8 any; var t_ any = t.F_base_sym; t.F_base_sym = nil; tmp8 = t_; tmp7.Invoke_O__O(tmp8)
		lang.IFn_Cast(A_arbace_pprint_A_const_611.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(t.F_alis))
		var tmp9 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3_2 any = Lit_137; var cf__1819000596__auto____4_2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3_2)) { cf__1819000596__auto____4_2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3_2) } else { cf__1819000596__auto____4_2 = format_in__1819000595__auto____3_2 }; var tmp10 any = A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_New_O(cf__1819000596__auto____4_2); var tmp11 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_172, true); A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_fn_class = fncls__147d; tmp11 = fncls__147d } else { tmp11 = fncls__147 }; tmp9 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp10, tmp11, nil, 0); var tmp12 lang.IFn = Up_Compiler_AOTRestFn_IFn(tmp9); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()); var tmp15 any; var t__2 any = t.F_alis; t.F_alis = nil; tmp15 = t__2; tmp12.Invoke_O__O(tmp13.Invoke_O__O(tmp14.Invoke_O__O(tmp15))) } else {
			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_608.GetRawRoot__O()); var tmp17 any; var t__3 any = t.F_alis; t.F_alis = nil; tmp17 = t__3; tmp16.Invoke_O__O(tmp17) }
//line :314:1
	var tmp18 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp18.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp19 != nil { panic(tmp19) }; return tmp1 }
//line :314:1
func A_arbace_pprint_write_buffered_output_A_New() *A_arbace_pprint_write_buffered_output_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_buffered_output_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_pprint_write_buffered_output_A) Ctor() {}
//line :314:1
func (t *A_arbace_pprint_write_buffered_output_A) Invoke_O_O__O(self, this__0 any) any {
	lang.IFn_Cast(A_arbace_pprint_A_const_158.GetRawRoot__O()).Invoke_O__O(this__0)
//line :314:1
	var tmp1 *lang.Keyword = A_arbace_pprint_A_const_157; var temp__1927000408__auto____2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))

	if jrt.A2g_Truth(temp__1927000408__auto____2) { var buf__3 any = temp__1927000408__auto____2; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_155.GetRawRoot__O()); var tmp3 *jrt.Boolean

		jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; tmp2.Invoke_O_O_O__O(this__0, buf__3, tmp3.Ref())
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0); var tmp6 any = A_arbace_pprint_A_const_44.GetRawRoot__O(); var tmp7 any = A_arbace_pprint_A_const_157; var tmp8 *lang.PersistentVector; lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY; return tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8.Ref()) } else {
//line :316:1
			return nil } }
func A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_New_O(p0 any) *A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A{}; t.Ctor_O(p0); return t }
//line :317:1
func (t *A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :317:1
func (t *A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_New_O(p0 any) *A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A{}; t.Ctor_O(p0); return t }
//line :319:1
func (t *A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :319:1
func (t *A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_format_simple_cardinal_A_New() *A_arbace_pprint_format_simple_cardinal_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_simple_cardinal_A{}; t.Ctor(); return t }
//line :321:1
func (t *A_arbace_pprint_format_simple_cardinal_A) Ctor() {}
//line :321:1
func (t *A_arbace_pprint_format_simple_cardinal_A) Invoke_O_O__O(self, num__0 any) any { var hundreds__2 any = lang.Numbers_Quotient_O_J__Number(num__0, 100); var tens__3 any = lang.Numbers_Remainder_O_J__Number(num__0, 100); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if





	lang.Numbers_IsPos_O__Z(hundreds__2) { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_111), jrt.RefArrayOf(jrt.Object_class, lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_339.GetRawRoot__O(), lang.RT_IntCast_O__I(hundreds__2)), nil)) } else { tmp2 = nil }; var tmp3 any = /*line :326:1*/tmp2.Ref(); var tmp4 *jrt.String; var tmp5 bool; var and__1927000168__auto____7 bool = lang.Numbers_IsPos_O__Z(hundreds__2); if and__1927000168__auto____7 {

		tmp5 = lang.Numbers_IsPos_O__Z(tens__3) } else { tmp5 = and__1927000168__auto____7 }; if tmp5 { tmp4 = Lit_4 } else { tmp4 = nil }; var tmp6 any = /*line :326:1*/tmp4.Ref(); var tmp7 any; if


	lang.Numbers_IsPos_O__Z(tens__3) {
		if lang.Numbers_Lt_O_J__Z(tens__3, 20) {
			tmp7 = lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_339.GetRawRoot__O(), lang.RT_IntCast_O__I(tens__3)) } else {
//line :330:1
				var ten_digit__7 any = lang.Numbers_Quotient_O_J__Number(tens__3, 10); var unit_digit__8 any = lang.Numbers_Remainder_O_J__Number(tens__3, 10); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp9 any




				if lang.Numbers_IsPos_O__Z(ten_digit__7) { tmp9 = lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_340.GetRawRoot__O(), lang.RT_IntCast_O__I(ten_digit__7)) } else { tmp9 = nil }
//line :334:1
				var tmp10 any = tmp9; var tmp11 *jrt.String; var tmp12 bool; var and__1927000168__auto____12 bool = lang.Numbers_IsPos_O__Z(ten_digit__7)

				if and__1927000168__auto____12 { tmp12 = lang.Numbers_IsPos_O__Z(unit_digit__8) } else { tmp12 = and__1927000168__auto____12 }; if tmp12 { tmp11 = Lit_61 } else { tmp11 = nil }
//line :334:1
				var tmp13 any = tmp11.Ref(); var tmp14 any


				if lang.Numbers_IsPos_O__Z(unit_digit__8) { tmp14 = lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_339.GetRawRoot__O(), lang.RT_IntCast_O__I(unit_digit__8)) } else { tmp14 = nil }
//line :334:1
				tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp10, tmp13, tmp14)).Ref() } } else {
//line :329:1
					tmp7 = nil }; return /*line :326:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp6, tmp7)).Ref() }
//line :321:1
func A_arbace_pprint_write_white_space_A_New() *A_arbace_pprint_write_white_space_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_white_space_A{}; t.Ctor(); return t }
//line :321:1
func (t *A_arbace_pprint_write_white_space_A) Ctor() {}
//line :321:1
func (t *A_arbace_pprint_write_white_space_A) Invoke_O_O__O(self, this__0 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_125; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0))); if
											jrt.A2g_Truth(temp__1927000414__auto____2) { var tws__3 any = temp__1927000414__auto____2; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____4 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))

		jrt.Writer_Cast(w__1820000023__auto____4).Write_String__V(jrt.String_Cast(tws__3))
		var tmp3 any = A_arbace_pprint_write_white_space_fn__1820000160_A_New_O(this__0); var tmp4 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_pprint_write_white_space_fn__1820000160_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_280, false); A_arbace_pprint_write_white_space_fn__1820000160_A_fn_class = fncls__27d; tmp4 = fncls__27d } else { tmp4 = fncls__27 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } else {
//line :322:1
			return nil } }
//line :322:1
func A_arbace_pprint_pprint_newline_A_New() *A_arbace_pprint_pprint_newline_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_newline_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_pprint_pprint_newline_A) Ctor() {}
//line :322:1
func (t *A_arbace_pprint_pprint_newline_A) Invoke_O_O__O(self, kind__0 any) any {








	lang.IFn_Cast(A_arbace_pprint_A_const_268.GetRawRoot__O()).Invoke_O_O__O(kind__0, A_arbace_pprint_A_const_269)
	return lang.IFn_Cast(A_arbace_pprint_A_const_267.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_34.Get__O(), kind__0) }
//line :325:1
func A_arbace_pprint_write_white_space_fn__1820000160_A_New_O(p0 any) *A_arbace_pprint_write_white_space_fn__1820000160_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_white_space_fn__1820000160_A{}; t.Ctor_O(p0); return t }
//line :325:1
func (t *A_arbace_pprint_write_white_space_fn__1820000160_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :325:1
func (t *A_arbace_pprint_write_white_space_fn__1820000160_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_125, nil) }
//line :326:1
func A_arbace_pprint_fn__740000152_A_New() *A_arbace_pprint_fn__740000152_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__740000152_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_pprint_fn__740000152_A) Ctor() {}
//line :326:1
func (t *A_arbace_pprint_fn__740000152_A) Invoke_O__O(self any) any { var format_in__1819000595__auto____1 any = Lit_97; var cf__1819000596__auto____2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____1)) { cf__1819000596__auto____2 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____1) } else { cf__1819000596__auto____2 = format_in__1819000595__auto____1 }; var tmp1 any = A_arbace_pprint_fn__740000152_fn__740000153_A_New_O(cf__1819000596__auto____2); var tmp2 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_pprint_fn__740000152_fn__740000153_A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, true); A_arbace_pprint_fn__740000152_fn__740000153_A_fn_class = fncls__150d; tmp2 = fncls__150d } else { tmp2 = fncls__150 }; return lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 0) }
//line :326:1
func A_arbace_pprint_fn__740000152_fn__740000153_A_New_O(p0 any) *A_arbace_pprint_fn__740000152_fn__740000153_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__740000152_fn__740000153_A{}; t.Ctor_O(p0); return t }
//line :326:1
func (t *A_arbace_pprint_fn__740000152_fn__740000153_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :326:1
func (t *A_arbace_pprint_fn__740000152_fn__740000153_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_pprint_cond_A_New() *A_arbace_pprint_pprint_cond_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_cond_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_pprint_pprint_cond_A) Ctor() {}
//line :328:1
func (t *A_arbace_pprint_pprint_cond_A) Invoke_O_O__O(self, alis__0 any) any {
	if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_cond_fn__740000156_A_New_O(alis__0); var tmp3 *jrt.Class; var fncls__152 *jrt.Class = A_arbace_pprint_pprint_cond_fn__740000156_A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_155, false); A_arbace_pprint_pprint_cond_fn__740000156_A_fn_class = fncls__152d; tmp3 = fncls__152d } else { tmp3 = fncls__152 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :328:1
	return nil }
func A_arbace_pprint_pprint_cond_fn__740000156_A_New_O(p0 any) *A_arbace_pprint_pprint_cond_fn__740000156_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_cond_fn__740000156_A{}; t.Ctor_O(p0); return t }
//line :329:1
func (t *A_arbace_pprint_pprint_cond_fn__740000156_A) Ctor_O(c__alis any) { t.F_alis = c__alis }
//line :329:1
func (t *A_arbace_pprint_pprint_cond_fn__740000156_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_102, nil, Lit_103)
										lang.IFn_Cast(A_arbace_pprint_A_const_437.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_122, A_arbace_pprint_A_const_176)
										lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_alis))
										if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_alis)) {
											jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)
											lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :332:1
		var length_count740000157__3 int64 = 0; var alis__4 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_alis


		t.F_alis = nil; tmp4 = t_; alis__4 = tmp3.Invoke_O__O(tmp4)
//line :332:1
	L1: for {


		var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_214.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_O__Z(length_count740000157__3, A_arbace_pprint_A_const_214.Get__O())).Ref() }; if jrt.A2g_Truth(tmp5) { if jrt.A2g_Truth(alis__4) { if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp6 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp7 any = A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_New_O(alis__4); var tmp8 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_156, false); A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_fn_class = fncls__151d; tmp8 = fncls__151d } else { tmp8 = fncls__151 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O() }; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(alis__4))) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)









			lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :335:1
			length_count740000157__3, alis__4 = lang.Numbers_Inc_J__J(length_count740000157__3), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(alis__4)); continue L1 } } } else { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_154) }
//line :332:1
		break L1 } }
//line :329:1
	var tmp9 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp9.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp10 != nil { panic(tmp10) }; return tmp1 }
func A_arbace_pprint_write_initial_lines_A_New() *A_arbace_pprint_write_initial_lines_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_initial_lines_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_pprint_write_initial_lines_A) Ctor() {}
//line :330:1
func (t *A_arbace_pprint_write_initial_lines_A) Invoke_O_O_O__O(self, this__0, s__1 any) any { var tmp1 *jrt.Class = A_arbace_pprint_A_const_57; var lines__3 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(s__1, tmp1, Lit_277, jrt.RefArrayOf(jrt.Object_class, Lit_141, A_arbace_pprint_A_const_159)); if


	lang.Util_Equiv_J_J__Z(int64(lang.RT_Count_O__I(lines__3)), 1) { return s__1 } else {

		var tmp2 any = A_arbace_pprint_write_initial_lines_fn__1820000163_A_New_O_O(lines__3, this__0); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_pprint_write_initial_lines_fn__1820000163_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_278, false); A_arbace_pprint_write_initial_lines_fn__1820000163_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } }
//line :334:1
func A_arbace_pprint_pprint_indent_A_New() *A_arbace_pprint_pprint_indent_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_indent_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_pprint_pprint_indent_A) Ctor() {}
//line :334:1
func (t *A_arbace_pprint_pprint_indent_A) Invoke_O_O_O__O(self, relative_to__0, n__1 any) any {










	lang.IFn_Cast(A_arbace_pprint_A_const_268.GetRawRoot__O()).Invoke_O_O__O(relative_to__0, A_arbace_pprint_A_const_271)
	return lang.IFn_Cast(A_arbace_pprint_A_const_270.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), relative_to__0, n__1) }
//line :335:1
func A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_New_O(p0 any) *A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A{}; t.Ctor_O(p0); return t }
//line :335:1
func (t *A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A) Ctor_O(c__alis any) { t.F_alis = c__alis }
//line :335:1
func (t *A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), nil, nil, nil)


	lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_alis))
//line :335:1
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_alis)) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)





		lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_438)
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()); var tmp5 any; var t_ any = t.F_alis; t.F_alis = nil; tmp5 = t_; tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)) }
//line :335:1
	var tmp6 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp6.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :335:1
func A_arbace_pprint_write_initial_lines_fn__1820000163_A_New_O_O(p0, p1 any) *A_arbace_pprint_write_initial_lines_fn__1820000163_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_write_initial_lines_fn__1820000163_A{}; t.Ctor_O_O(p0, p1); return t }
//line :335:1
func (t *A_arbace_pprint_write_initial_lines_fn__1820000163_A) Ctor_O_O(c__lines, c__this any) { t.F_lines = c__lines; t.F_this = c__this }
//line :335:1
func (t *A_arbace_pprint_write_initial_lines_fn__1820000163_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_143; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_160; var prefix__1 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))))); var l__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_lines); var tmp3 any = A_arbace_pprint_A_const_161; var tmp4 *lang.Keyword = A_arbace_pprint_A_const_162; if


	lang.Util_Equiv_O_O__Z(tmp3, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))) { var tmp5 *lang.Keyword = A_arbace_pprint_A_const_163; var oldpos__3 any = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var newpos__4 any = lang.Numbers_Add_O_J__Number(oldpos__3, int64(lang.RT_Count_O__I(l__2)))


		lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_163, newpos__4)
		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_165.GetRawRoot__O()); var tmp7 any = t.F_this; tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_pprint_A_const_166.GetRawRoot__O()).Invoke_O_O_O_O__O(l__2, nil, oldpos__3, newpos__4))
		lang.IFn_Cast(A_arbace_pprint_A_const_164.GetRawRoot__O()).Invoke_O__O(t.F_this) } else {

			lang.IFn_Cast(A_arbace_pprint_A_const_167.GetRawRoot__O()).Invoke_O__O(t.F_this)
//line :338:1
			var tmp8 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____3 any = tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))







			jrt.Writer_Cast(w__1820000023__auto____3).Write_String__V(jrt.String_Cast(l__2)) }; var tmp9 /*line :335:1*/*lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____3_2 any = tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)));











	jrt.Writer_Cast(w__1820000023__auto____3_2).Write_I__V(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_51)); var seq_1820000164__3 any = /*line :335:1*/lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_168.GetRawRoot__O()).Invoke_O__O(t.F_lines))); var chunk_1820000165__4 any; var count_1820000166__5 int64 = 0; var i_1820000167__6 int64 = 0; L1: for {












		if lang.Numbers_Lt_J_J__Z(i_1820000167__6, count_1820000166__5) { var l__7 any = lang.Indexed_Cast(chunk_1820000165__4).Nth_I__O(lang.RT_IntCast_J__I(i_1820000167__6)); var tmp10 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____8 any = tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))
			jrt.Writer_Cast(w__1820000023__auto____8).Write_String__V(jrt.String_Cast(l__7))
//line :348:1
			var tmp11 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____8_2 any = tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))

			jrt.Writer_Cast(w__1820000023__auto____8_2).Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_145.GetRawRoot__O()).Invoke__O()))
			if jrt.A2g_Truth(prefix__1) { var tmp12 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____8_3 any = tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))
				jrt.Writer_Cast(w__1820000023__auto____8_3).Write_String__V(jrt.String_Cast(prefix__1)) }
//line :348:1
			seq_1820000164__3, chunk_1820000165__4, count_1820000166__5, i_1820000167__6 = seq_1820000164__3, chunk_1820000165__4, count_1820000166__5, lang.Numbers_Unchecked_inc_J__J(i_1820000167__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_1820000164__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1820000164__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_1820000164__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1820000164__8); seq_1820000164__3, chunk_1820000165__4, count_1820000166__5, i_1820000167__6 = lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1820000164__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var l__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq_1820000164__8); var tmp13 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____10 any = tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))
				jrt.Writer_Cast(w__1820000023__auto____10).Write_String__V(jrt.String_Cast(l__9))
//line :348:1
				var tmp14 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____10_2 any = tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))

				jrt.Writer_Cast(w__1820000023__auto____10_2).Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_145.GetRawRoot__O()).Invoke__O()))
				if jrt.A2g_Truth(prefix__1) { var tmp15 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____10_3 any = tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))
					jrt.Writer_Cast(w__1820000023__auto____10_3).Write_String__V(jrt.String_Cast(prefix__1)) }
//line :348:1
				seq_1820000164__3, chunk_1820000165__4, count_1820000166__5, i_1820000167__6 = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1820000164__8), nil, 0, 0; continue L1 } } }
//line :335:1
		break L1 };

















	lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_161, A_arbace_pprint_A_const_169); return /*line :354:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_97.GetRawRoot__O()).Invoke_O__O(t.F_lines) }
//line :339:1
func A_arbace_pprint_add_english_scales_A_New() *A_arbace_pprint_add_english_scales_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_add_english_scales_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_pprint_add_english_scales_A) Ctor() {}
//line :339:1
func (t *A_arbace_pprint_add_english_scales_A) Invoke_O_O_O__O(self, parts__0, offset__1 any) any { { var cnt__3 int32 = lang.RT_Count_O__I(parts__0); var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); var pos__5 int64 = lang.Numbers_Dec_J__J(int64(cnt__3)); var this__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(parts__0); var remainder__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(parts__0); L1: for {








	if lang.Util_Identical_O_O__Z(remainder__7, nil) {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil); var tmp2 any = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_342.GetRawRoot__O()).Invoke_O_O__O(Lit_3, acc__4)); var tmp3 *jrt.String; var tmp4 any; var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(this__6))
		if jrt.A2g_Truth(and__1927000168__auto____12) { tmp4 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(acc__4)) } else { tmp4 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp4) { tmp3 = Lit_3 } else { tmp3 = nil }
//line :349:1
		var tmp5 any = tmp3.Ref(); var tmp6 *jrt.String; var tmp7 any; var and__1927000168__auto____12_2 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(this__6))


		if jrt.A2g_Truth(and__1927000168__auto____12_2) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(lang.Numbers_Add_J_O__Number(pos__5, offset__1))).Ref() } else { tmp7 = and__1927000168__auto____12_2 }; if jrt.A2g_Truth(tmp7) {
			tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_341.GetRawRoot__O(), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(pos__5, offset__1))))) } else {
//line :352:1
				tmp6 = nil }
//line :349:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, this__6, tmp6.Ref())).Ref() } else {




			var tmp8 any
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(this__6)) { tmp8 = acc__4 } else {

				tmp8 = lang.IFn_Cast(A_arbace_pprint_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, this__6, nil, lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_341.GetRawRoot__O(), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(pos__5, offset__1))))).Ref()) }
//line :354:1
			acc__4, pos__5, this__6, remainder__7 = tmp8, lang.Numbers_Dec_J__J(pos__5), lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(remainder__7), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(remainder__7); continue L1 } } }; /*line :339:1*/panic("a2g: unreachable") }








func A_arbace_pprint_pprint_condp_A_New() *A_arbace_pprint_pprint_condp_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_condp_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_pprint_pprint_condp_A) Ctor() {}
//line :348:1
func (t *A_arbace_pprint_pprint_condp_A) Invoke_O_O__O(self, alis__0 any) any {
	if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(alis__0)), 3) {
		if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_condp_fn__740000162_A_New_O(alis__0); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_pprint_pprint_condp_fn__740000162_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_157, false); A_arbace_pprint_pprint_condp_fn__740000162_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :349:1
		return nil } else {















			return lang.IFn_Cast(A_arbace_pprint_A_const_608.GetRawRoot__O()).Invoke_O__O(alis__0) } }
//line :349:1
func A_arbace_pprint_pprint_tab_A_New() *A_arbace_pprint_pprint_tab_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_tab_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_pprint_pprint_tab_A) Ctor() {}
//line :349:1
func (t *A_arbace_pprint_pprint_tab_A) Invoke_O_O_O_O__O(self, kind__0, colnum__1, colinc__2 any) any {













	lang.IFn_Cast(A_arbace_pprint_A_const_268.GetRawRoot__O()).Invoke_O_O__O(kind__0, A_arbace_pprint_A_const_272)
//line :349:1
	panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(Lit_206))) }
func A_arbace_pprint_pprint_condp_fn__740000162_A_New_O(p0 any) *A_arbace_pprint_pprint_condp_fn__740000162_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_condp_fn__740000162_A{}; t.Ctor_O(p0); return t }
//line :350:1
func (t *A_arbace_pprint_pprint_condp_fn__740000162_A) Ctor_O(c__alis any) { t.F_alis = c__alis }
//line :350:1
func (t *A_arbace_pprint_pprint_condp_fn__740000162_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_102, nil, Lit_103)
											lang.IFn_Cast(A_arbace_pprint_A_const_437.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_122, A_arbace_pprint_A_const_176)
											var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp4 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____3 any = Lit_158; var cf__1819000596__auto____4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____3)) { cf__1819000596__auto____4 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____3) } else { cf__1819000596__auto____4 = format_in__1819000595__auto____3 }; var tmp5 any = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_New_O(cf__1819000596__auto____4); var tmp6 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_159, true); A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_fn_class = fncls__153d; tmp6 = fncls__153d } else { tmp6 = fncls__153 }; tmp4 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0); tmp3.Invoke_O_O__O(tmp4.Ref(), t.F_alis)
//line :350:1
	var length_count740000165__3 int64 = 0; var alis__4 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_142.GetRawRoot__O()); var tmp9 any = A_arbace_pprint_A_const_612; var tmp10 any; var t_ any = t.F_alis


	t.F_alis = nil; tmp10 = t_; alis__4 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10))
//line :350:1
L1: for {


	var tmp11 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_214.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp11 = or__1927000174__auto____5 } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_O__Z(length_count740000165__3, A_arbace_pprint_A_const_214.Get__O())).Ref() }; if jrt.A2g_Truth(tmp11) { if jrt.A2g_Truth(alis__4) { if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp12 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp13 any = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_New_O(alis__4); var tmp14 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_fn_class; if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_160, false); A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_fn_class = fncls__154d; tmp14 = fncls__154d } else { tmp14 = fncls__154 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O() }; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(alis__4))) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)









		lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :353:1
		length_count740000165__3, alis__4 = lang.Numbers_Inc_J__J(length_count740000165__3), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(alis__4)); continue L1 } } } else { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_154) }
//line :350:1
	break L1 }; var tmp15 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp15.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp16 != nil { panic(tmp16) }; return tmp1 }

func A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_New_O(p0 any) *A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A{}; t.Ctor_O(p0); return t }
//line :352:1
func (t *A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :352:1
func (t *A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }
func A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_New_O(p0 any) *A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A{}; t.Ctor_O(p0); return t }
//line :353:1
func (t *A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A) Ctor_O(c__alis any) { t.F_alis = c__alis }
//line :353:1
func (t *A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), nil, nil, nil)


	lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_alis))
//line :353:1
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_alis)) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)





		lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_438)
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()); var tmp5 any; var t_ any = t.F_alis; t.F_alis = nil; tmp5 = t_; tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)) }
//line :353:1
	var tmp6 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp6.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }


func A_arbace_pprint_p_write_char_A_New() *A_arbace_pprint_p_write_char_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_p_write_char_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_pprint_p_write_char_A) Ctor() {}
//line :356:1
func (t *A_arbace_pprint_p_write_char_A) Invoke_O_O_O__O(self, this__0, c__1 any) any {
	var tmp1 *lang.Keyword = A_arbace_pprint_A_const_162; if lang.Util_Equiv_O_O__Z(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0))), A_arbace_pprint_A_const_169) {

		lang.IFn_Cast(A_arbace_pprint_A_const_167.GetRawRoot__O()).Invoke_O__O(this__0)
//line :357:1
		var tmp2 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____3 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))


		jrt.Writer_Cast(w__1820000023__auto____3).Write_I__V(lang.RT_IntCast_O__I(c__1)); return nil } else {
			if lang.Util_Equiv_O_O__Z(c__1, A_arbace_pprint_A_const_51) {
				return lang.IFn_Cast(A_arbace_pprint_A_const_170.GetRawRoot__O()).Invoke_O_O__O(this__0, Lit_141) } else {
//line :361:1
					var tmp3 *lang.Keyword = A_arbace_pprint_A_const_163; var oldpos__3 any = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0))); var newpos__4 any = lang.Numbers_Inc_O__Number(oldpos__3); var tmp4 any = A_arbace_pprint_p_write_char_fn__1820000170_A_New_O_O_O_O(c__1, oldpos__3, newpos__4, this__0); var tmp5 *jrt.Class
					var fncls__29 /*line :361:1*/*jrt.Class = A_arbace_pprint_p_write_char_fn__1820000170_A_fn_class



					if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_142, false); A_arbace_pprint_p_write_char_fn__1820000170_A_fn_class = fncls__29d; tmp5 = fncls__29d } else { tmp5 = fncls__29 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)) } } }
//line :362:1
func A_arbace_pprint_format_cardinal_english_A_New() *A_arbace_pprint_format_cardinal_english_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_cardinal_english_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_pprint_format_cardinal_english_A) Ctor() {}
//line :362:1
func (t *A_arbace_pprint_format_cardinal_english_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000055__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000055__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000055__4, lang.RT_IntCast_J__I(1), nil); if

	lang.Util_Equiv_J_O__Z(0, arg__5) {
		lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(Lit_99) } else {
//line :364:1
			var abs_arg__7 any

			if lang.Numbers_IsNeg_O__Z(arg__5) { abs_arg__7 = lang.Numbers_Minus_O__Number(arg__5) } else { abs_arg__7 = arg__5 }
//line :364:1
			var parts__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_327.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_345, abs_arg__7)



			if lang.Numbers_Lte_J_J__Z(int64(lang.RT_Count_O__I(parts__8)), int64(lang.RT_Count_O__I(A_arbace_pprint_A_const_341.GetRawRoot__O()))) { var parts_strs__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_346.GetRawRoot__O(), parts__8); var full_str__10 any = lang.IFn_Cast(A_arbace_pprint_A_const_343.GetRawRoot__O()).Invoke_O_O__O(parts_strs__9, A_arbace_pprint_A_const_28); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 *jrt.String


				if lang.Numbers_IsNeg_O__Z(arg__5) { tmp3 = Lit_100 } else { tmp3 = nil }; tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3.Ref(), full_str__10)).Ref()) } else {
					var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_344.GetRawRoot__O()); var tmp5 any = A_arbace_pprint_A_const_347; var tmp6 any = A_arbace_pprint_A_const_348; tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O__IPersistentVector(arg__5)), A_arbace_pprint_A_const_349) } }; return navigator__6 }
//line :365:1
func A_arbace_pprint_p_write_char_fn__1820000170_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_pprint_p_write_char_fn__1820000170_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_p_write_char_fn__1820000170_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :365:1
func (t *A_arbace_pprint_p_write_char_fn__1820000170_A) Ctor_O_O_O_O(c__c, c__oldpos, c__newpos, c__this any) { t.F_c = c__c; t.F_oldpos = c__oldpos; t.F_newpos = c__newpos; t.F_this = c__this }
//line :365:1
func (t *A_arbace_pprint_p_write_char_fn__1820000170_A) Invoke_O__O(self any) any {
	lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_163, t.F_newpos)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_165.GetRawRoot__O()); var tmp2 any = t.F_this; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_pprint_A_const_166.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(lang.RT_CharCast_O__C(t.F_c)).Ref()), nil, t.F_oldpos, t.F_newpos))
}

func A_arbace_pprint_pprint_anon_func_A_New() *A_arbace_pprint_pprint_anon_func_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_anon_func_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_pprint_pprint_anon_func_A) Ctor() {}
//line :370:1
func (t *A_arbace_pprint_pprint_anon_func_A) Invoke_O_O__O(self, alis__0 any) any { var args__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(alis__0); var nlis__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(alis__0))); if


	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_600.GetRawRoot__O()).Invoke_O__O(args__2)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_A_const_613; var tmp4 any; if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(args__2))) { tmp4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(args__2), Lit_146)) } else {

			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp9 any = A_arbace_pprint_pprint_anon_func_fn__740000172_A_New(); var tmp10 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_pprint_pprint_anon_func_fn__740000172_A_fn_class
			if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_147, false); A_arbace_pprint_pprint_anon_func_fn__740000172_A_fn_class = fncls__157d; tmp10 = fncls__157d } else { tmp10 = fncls__157 }
//line :376:1
			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_614.GetRawRoot__O()); var tmp12 any = A_arbace_pprint_A_const_176; tmp4 = tmp5.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), args__2, tmp11.Invoke_O_O__O(tmp12, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(args__2)))).Ref()))) }
//line :374:1
		tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4))
//line :373:1
		var tmp13 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







			{ var tmp14 *lang.Compiler_AOTRestFn; var format_in__1819000595__auto____6 any = Lit_148; var cf__1819000596__auto____7 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_294.GetRawRoot__O()).Invoke_O__O(format_in__1819000595__auto____6)) { cf__1819000596__auto____7 = A_arbace_pprint_A_const_591.Invoke_O__O(format_in__1819000595__auto____6) } else { cf__1819000596__auto____7 = format_in__1819000595__auto____6 }; var tmp15 any = A_arbace_pprint_pprint_anon_func_fn__740000174_A_New_O(cf__1819000596__auto____7); var tmp16 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_pprint_pprint_anon_func_fn__740000174_A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_149, true); A_arbace_pprint_pprint_anon_func_fn__740000174_A_fn_class = fncls__156d; tmp16 = fncls__156d } else { tmp16 = fncls__156 }; tmp14 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp15, tmp16, nil, 0); tmp13 = Up_Compiler_AOTRestFn_IFn(tmp14).Invoke_O__O(nlis__3) }
//line :373:1
			return nil }()
		lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O()
//line :373:1
		if tmp17 != nil { panic(tmp17) }; return tmp13 } else {








			return lang.IFn_Cast(A_arbace_pprint_A_const_608.GetRawRoot__O()).Invoke_O__O(alis__0) } }
//line :372:1
func A_arbace_pprint_pll_mod_body_A_New() *A_arbace_pprint_pll_mod_body_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pll_mod_body_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_pprint_pll_mod_body_A) Ctor() {}
//line :372:1
func (t *A_arbace_pprint_pll_mod_body_A) Invoke_O_O_O__O(self, var_sym__0, body__1 any) any { var body_inner__3 *A_arbace_pprint_pll_mod_body_inner__693000059_A = A_arbace_pprint_pll_mod_body_inner__693000059_A_New_O(var_sym__0); var inner__3 any; var tmp1 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_pprint_pll_mod_body_inner__693000059_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_143, false); A_arbace_pprint_pll_mod_body_inner__693000059_A_fn_class = fncls__50d; tmp1 = fncls__50d } else { tmp1 = fncls__50 }; inner__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_inner__3), tmp1, nil); return /*line :381:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_275.GetRawRoot__O()).Invoke_O_O_O__O(inner__3, A_arbace_pprint_A_const_280.GetRawRoot__O(), body__1) }
//line :373:1
func A_arbace_pprint_pll_mod_body_inner__693000059_A_New_O(p0 any) *A_arbace_pprint_pll_mod_body_inner__693000059_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pll_mod_body_inner__693000059_A{}; t.Ctor_O(p0); return t }
//line :373:1
func (t *A_arbace_pprint_pll_mod_body_inner__693000059_A) Ctor_O(c__var_sym any) { t.F_var_sym = c__var_sym }
//line :373:1
func (t *A_arbace_pprint_pll_mod_body_inner__693000059_A) Invoke_O_O__O(self, form__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_273.GetRawRoot__O()).Invoke_O__O(form__1)) { var form__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_274.GetRawRoot__O()).Invoke_O__O(form__1); var pred__693000060__3 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__693000061__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(form__2)

		if jrt.A2g_Truth(lang.IFn_Cast(pred__693000060__3).Invoke_O_O__O(A_arbace_pprint_A_const_276, expr__693000061__4)) { return form__2 } else { if jrt.A2g_Truth(lang.IFn_Cast(pred__693000060__3).Invoke_O_O__O(A_arbace_pprint_A_const_277, expr__693000061__4)) {

			return lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_278), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_279), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(t.F_var_sym)))))), lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(form__2)) } else {
				return lang.IFn_Cast(A_arbace_pprint_A_const_275.GetRawRoot__O()).Invoke_O_O_O__O(self, A_arbace_pprint_A_const_280.GetRawRoot__O(), form__2) } } } else {
//line :374:1
					return form__1 } }
//line :373:1
func A_arbace_pprint_pretty_writer_A_New() *A_arbace_pprint_pretty_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_A{}; t.Ctor(); return t }
//line :373:1
func (t *A_arbace_pprint_pretty_writer_A) Ctor() {}
//line :373:1
func (t *A_arbace_pprint_pretty_writer_A) Invoke_O_O_O_O__O(self, writer__0, max_columns__1, miser_width__2 any) any { var lb__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_171.GetRawRoot__O(); var tmp3 any = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_28); var tmp4 any = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_28); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()); var tmp6 *jrt.Boolean;
															jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; var tmp7 any = tmp5.Invoke_O__O(tmp6.Ref()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; lb__4 = tmp1.Invoke_O_O_O_O_O_O_O__O(tmp2, nil, nil, tmp3, tmp4, tmp7, tmp8.Invoke_O__O(tmp9.Ref())); var fields__5 any; var tmp10 lang.IFn = /*line :373:1*/lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()); var tmp11 any = A_arbace_pprint_A_const_172; var tmp12 *jrt.Boolean;

	jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_pprint_A_const_50; var tmp15 any = lang.IFn_Cast(A_arbace_pprint_A_const_61.GetRawRoot__O()).Invoke_O_O__O(writer__0, max_columns__1); var tmp16 any = A_arbace_pprint_A_const_160; var tmp17 any = A_arbace_pprint_A_const_173; var tmp18 any = A_arbace_pprint_A_const_162; var tmp19 any = A_arbace_pprint_A_const_169; var tmp20 any = A_arbace_pprint_A_const_157; var tmp21 *lang.PersistentVector; lang.PersistentVector_Init(); tmp21 = lang.PersistentVector_EMPTY; fields__5 = tmp10.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp14, tmp15, tmp16, lb__4, tmp17, nil, tmp18, tmp19, tmp20, tmp21.Ref(), A_arbace_pprint_A_const_174, lb__4, A_arbace_pprint_A_const_175, A_arbace_pprint_A_const_176, A_arbace_pprint_A_const_177, miser_width__2, A_arbace_pprint_A_const_125, nil, A_arbace_pprint_A_const_163, A_arbace_pprint_A_const_28))); var p__840000142__auto____6 any = /*line :373:1*/lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_211), jrt.RefArrayOf(jrt.Object_class)); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_53.GetRawRoot__O()); var tmp23 any = A_arbace_pprint_pretty_writer_fn__1820000173_A_New_O(fields__5); var tmp24 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_pprint_pretty_writer_fn__1820000173_A_fn_class; if












	fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_212, false); A_arbace_pprint_pretty_writer_fn__1820000173_A_fn_class = fncls__30d; tmp24 = fncls__30d } else { tmp24 = fncls__30 }; var tmp25 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp26 any = A_arbace_pprint_pretty_writer_fn__1820000175_A_New(); var tmp27 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_pprint_pretty_writer_fn__1820000175_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_213, false); A_arbace_pprint_pretty_writer_fn__1820000175_A_fn_class = fncls__32d; tmp27 = fncls__32d } else { tmp27 = fncls__32 }; var tmp28 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var tmp29 any = A_arbace_pprint_pretty_writer_fn__1820000181_A_New(); var tmp30 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_pprint_pretty_writer_fn__1820000181_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_214, false); A_arbace_pprint_pretty_writer_fn__1820000181_A_fn_class = fncls__34d; tmp30 = fncls__34d } else { tmp30 = fncls__34 }; var tmp31 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil); var tmp32 any = A_arbace_pprint_pretty_writer_fn__1820000185_A_New(); var tmp33 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_pprint_pretty_writer_fn__1820000185_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_215, false); A_arbace_pprint_pretty_writer_fn__1820000185_A_fn_class = fncls__36d; tmp33 = fncls__36d } else { tmp33 = fncls__36 }; var tmp34 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var tmp35 any = A_arbace_pprint_pretty_writer_fn__1820000187_A_New(); var tmp36 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_pprint_pretty_writer_fn__1820000187_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_216, false); A_arbace_pprint_pretty_writer_fn__1820000187_A_fn_class = fncls__37d; tmp36 = fncls__37d } else { tmp36 = fncls__37 }; tmp22.Invoke_O_O__O(p__840000142__auto____6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_33, tmp25, Lit_15, tmp28, Lit_145, tmp31, Lit_13, tmp34, Lit_11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil)))); return p__840000142__auto____6 }
//line :377:1
func A_arbace_pprint_pprint_anon_func_fn__740000172_A_New() *A_arbace_pprint_pprint_anon_func_fn__740000172_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_anon_func_fn__740000172_A{}; t.Ctor(); return t }
//line :377:1
func (t *A_arbace_pprint_pprint_anon_func_fn__740000172_A) Ctor() {}
//line :377:1
func (t *A_arbace_pprint_pprint_anon_func_fn__740000172_A) Invoke_O_O_O__O(self, p1__740000170_SHARP___1, p2__740000171_SHARP___2 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_78.GetRawRoot__O()).Invoke_O_O__O(p1__740000170_SHARP___1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_146, nil), jrt.RefArrayOf(jrt.Object_class, nil, p2__740000171_SHARP___2)).Ref()) }
func A_arbace_pprint_format_simple_ordinal_A_New() *A_arbace_pprint_format_simple_ordinal_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_simple_ordinal_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_pprint_format_simple_ordinal_A) Ctor() {}
//line :379:1
func (t *A_arbace_pprint_format_simple_ordinal_A) Invoke_O_O__O(self, num__0 any) any { var hundreds__2 any = lang.Numbers_Quotient_O_J__Number(num__0, 100); var tens__3 any = lang.Numbers_Remainder_O_J__Number(num__0, 100); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if






	lang.Numbers_IsPos_O__Z(hundreds__2) { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_111), jrt.RefArrayOf(jrt.Object_class, lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_339.GetRawRoot__O(), lang.RT_IntCast_O__I(hundreds__2)), nil)) } else { tmp2 = nil }; var tmp3 any = /*line :385:1*/tmp2.Ref(); var tmp4 *jrt.String; var tmp5 bool; var and__1927000168__auto____7 bool = lang.Numbers_IsPos_O__Z(hundreds__2); if and__1927000168__auto____7 {

		tmp5 = lang.Numbers_IsPos_O__Z(tens__3) } else { tmp5 = and__1927000168__auto____7 }; if tmp5 { tmp4 = Lit_4 } else { tmp4 = nil }; var tmp6 any = /*line :385:1*/tmp4.Ref(); var tmp7 any; if


	lang.Numbers_IsPos_O__Z(tens__3) {
		if lang.Numbers_Lt_O_J__Z(tens__3, 20) {
			tmp7 = lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_350.GetRawRoot__O(), lang.RT_IntCast_O__I(tens__3)) } else {
//line :389:1
				var ten_digit__7 any = lang.Numbers_Quotient_O_J__Number(tens__3, 10); var unit_digit__8 any = lang.Numbers_Remainder_O_J__Number(tens__3, 10); var tmp8 any; var and__1927000168__auto____9 bool = lang.Numbers_IsPos_O__Z(ten_digit__7)



				if and__1927000168__auto____9 { tmp8 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(unit_digit__8)).Ref()) } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() }; if jrt.A2g_Truth(tmp8) {
					tmp7 = lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_351.GetRawRoot__O(), lang.RT_IntCast_O__I(ten_digit__7)) } else {
						var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp10 any
						if lang.Numbers_IsPos_O__Z(ten_digit__7) { tmp10 = lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_340.GetRawRoot__O(), lang.RT_IntCast_O__I(ten_digit__7)) } else { tmp10 = nil }
//line :395:1
						var tmp11 any = tmp10; var tmp12 *jrt.String; var tmp13 bool; var and__1927000168__auto____12 bool = lang.Numbers_IsPos_O__Z(ten_digit__7)

						if and__1927000168__auto____12 { tmp13 = lang.Numbers_IsPos_O__Z(unit_digit__8) } else { tmp13 = and__1927000168__auto____12 }; if tmp13 { tmp12 = Lit_61 } else { tmp12 = nil }
//line :395:1
						var tmp14 any = tmp12.Ref(); var tmp15 any


						if lang.Numbers_IsPos_O__Z(unit_digit__8) { tmp15 = lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_350.GetRawRoot__O(), lang.RT_IntCast_O__I(unit_digit__8)) } else { tmp15 = nil }
//line :395:1
						tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp11, tmp14, tmp15)).Ref() } } } else {



							if lang.Numbers_IsPos_O__Z(hundreds__2) { tmp7 = Lit_107 } else { tmp7 = nil } }; return /*line :385:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp6, tmp7)).Ref() }
//line :381:1
func A_arbace_pprint_pprint_anon_func_fn__740000174_A_New_O(p0 any) *A_arbace_pprint_pprint_anon_func_fn__740000174_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_anon_func_fn__740000174_A{}; t.Ctor_O(p0); return t }
//line :381:1
func (t *A_arbace_pprint_pprint_anon_func_fn__740000174_A) Ctor_O(c__cf__1819000596__auto__ any) { t.F_cf__1819000596__auto__ = c__cf__1819000596__auto__ }
//line :381:1
func (t *A_arbace_pprint_pprint_anon_func_fn__740000174_A) DoInvoke_O_O__O(self, args__1819000597__auto____1 any) any { var navigator__1819000598__auto____2 any = A_arbace_pprint_A_const_296.Invoke_O__O(args__1819000597__auto____1); return A_arbace_pprint_A_const_297.Invoke_O_O__O(t.F_cf__1819000596__auto__, navigator__1819000598__auto____2) }

func A_arbace_pprint_print_length_loop_A_New() *A_arbace_pprint_print_length_loop_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_print_length_loop_A{}; t.Ctor(); return t }
//line :383:1
func (t *A_arbace_pprint_print_length_loop_A) Ctor() {}
//line :383:1
func (t *A_arbace_pprint_print_length_loop_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, bindings__2, body__3 any) any { var count_var__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_281.GetRawRoot__O()).Invoke_O__O(Lit_221); var mod_body__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_282.GetRawRoot__O()).Invoke_O_O__O(count_var__5, body__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_88.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_292; return /*line :388:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_283), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), count_var__5, A_arbace_pprint_A_const_28, bindings__2)), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_284), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_285), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_286), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_287)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_288), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(count_var__5), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_289))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_290), mod_body__6))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_291), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_33.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_90), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_293)))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(Lit_154))))))))) }
//line :386:1
func A_arbace_pprint_pretty_writer_fn__1820000173_A_New_O(p0 any) *A_arbace_pprint_pretty_writer_fn__1820000173_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_fn__1820000173_A{}; t.Ctor_O(p0); return t }
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000173_A) Ctor_O(c__fields any) { t.F_fields = c__fields }
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000173_A) Invoke_O_O__O(self, this__1 any) any { return t.F_fields }
//line :386:1
func A_arbace_pprint_pretty_writer_fn__1820000175_A_New() *A_arbace_pprint_pretty_writer_fn__1820000175_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_fn__1820000175_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000175_A) Ctor() {}
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000175_A) Invoke_O_O_O_O_O__O(self, this__1, x__2, off__3, len__4 any) any {



























	jrt.Writer_Cast(this__1).Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(x__2), off__3, lang.Numbers_Add_O_O__Number(off__3, len__4)))); return nil }
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000175_A) Invoke_O_O_O__O(self, this__1, x__2 any) any { var pred__1820000176__3 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__1820000177__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(x__2); if





	jrt.A2g_Truth(lang.IFn_Cast(pred__1820000176__3).Invoke_O_O__O(A_arbace_pprint_A_const_57, expr__1820000177__4)) { var s0__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_170.GetRawRoot__O()).Invoke_O_O__O(this__1, x__2); var tmp1 *jrt.Class = A_arbace_pprint_A_const_57; var s__6 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(s0__5, tmp1, Lit_217, jrt.RefArrayOf(jrt.Object_class, Lit_218, Lit_43)); var white_space__7 any = jrt.NN(jrt.String_Cast(s0__5)).Substring_I__String(lang.RT_Count_O__I(s__6)).Ref(); var tmp2 *lang.Keyword = A_arbace_pprint_A_const_162; var mode__8 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1))); var tmp3 any = A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_New_O_O_O_O_O(white_space__7, s__6, s0__5, mode__8, this__1); var tmp4 *jrt.Class
		var fncls__31 /*line :392:1*/*jrt.Class = A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_fn_class





		if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_219, false); A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_fn_class = fncls__31d; tmp4 = fncls__31d } else { tmp4 = fncls__31 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } else {
//line :392:1
			if jrt.A2g_Truth(lang.IFn_Cast(pred__1820000176__3).Invoke_O_O__O(A_arbace_pprint_A_const_59, expr__1820000177__4)) {

















				return lang.IFn_Cast(A_arbace_pprint_A_const_178.GetRawRoot__O()).Invoke_O_O__O(this__1, x__2) } else {
//line :392:1
					if jrt.A2g_Truth(lang.IFn_Cast(pred__1820000176__3).Invoke_O_O__O(A_arbace_pprint_A_const_60, expr__1820000177__4)) {



















						return lang.IFn_Cast(A_arbace_pprint_A_const_178.GetRawRoot__O()).Invoke_O_O__O(this__1, x__2) } else {
//line :392:1
							panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__1820000177__4))))) } } } }
//line :386:1
func A_arbace_pprint_pretty_writer_fn__1820000181_A_New() *A_arbace_pprint_pretty_writer_fn__1820000181_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_fn__1820000181_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000181_A) Ctor() {}
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000181_A) Invoke_O_O__O(self, this__1 any) any {






























	var tmp1 *lang.Keyword = A_arbace_pprint_A_const_162; if lang.Util_Equiv_O_O__Z(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1))), A_arbace_pprint_A_const_161) {
		var tmp2 any = A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_New_O(this__1); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_220, false); A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else {


			return lang.IFn_Cast(A_arbace_pprint_A_const_167.GetRawRoot__O()).Invoke_O__O(this__1) } }
//line :386:1
func A_arbace_pprint_pretty_writer_fn__1820000185_A_New() *A_arbace_pprint_pretty_writer_fn__1820000185_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_fn__1820000185_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000185_A) Ctor() {}
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000185_A) Invoke_O_O__O(self, this__1 any) any {





































	var target_35 any = this__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_35 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_35) }; tmp1 = tmp2; if tmp1 { lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_35, Lit_145, jrt.RefArrayOf(jrt.Object_class)) } else { A_arbace_pprint_PrettyFlush_A_Cast(target_35).Ppflush__V() }
//line :386:1
	var tmp3 *lang.Keyword = A_arbace_pprint_A_const_50; var w__2 any = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__1)))







































	jrt.Writer_Cast(w__2).Flush__V(); return nil }
//line :386:1
func A_arbace_pprint_pretty_writer_fn__1820000187_A_New() *A_arbace_pprint_pretty_writer_fn__1820000187_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_fn__1820000187_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000187_A) Ctor() {}
//line :386:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000187_A) Invoke_O_O__O(self, this__1 any) any {










































	jrt.Writer_Cast(this__1).Flush__V(); return nil }
//line :392:1
func A_arbace_pprint_pprint_simple_code_list_A_New() *A_arbace_pprint_pprint_simple_code_list_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_simple_code_list_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_pprint_pprint_simple_code_list_A) Ctor() {}
//line :392:1
func (t *A_arbace_pprint_pprint_simple_code_list_A) Invoke_O_O__O(self, alis__0 any) any {
	if jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp1 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp2 any = A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_New_O(alis__0); var tmp3 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_204, false); A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_fn_class = fncls__158d; tmp3 = fncls__158d } else { tmp3 = fncls__158 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }
//line :392:1
	return nil }
func A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_New_O(p0 any) *A_arbace_pprint_pprint_simple_code_list_fn__740000177_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_simple_code_list_fn__740000177_A{}; t.Ctor_O(p0); return t }
//line :393:1
func (t *A_arbace_pprint_pprint_simple_code_list_fn__740000177_A) Ctor_O(c__alis any) { t.F_alis = c__alis }
//line :393:1
func (t *A_arbace_pprint_pprint_simple_code_list_fn__740000177_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; tmp2.Invoke_O_O_O_O__O(A_arbace_pprint_A_const_34.Get__O(), Lit_102, nil, Lit_103)
												lang.IFn_Cast(A_arbace_pprint_A_const_437.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_122, A_arbace_pprint_A_const_176)
//line :393:1
	var length_count740000178__3 int64 = 0; var alis__4 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_alis

	t.F_alis = nil; tmp4 = t_; alis__4 = tmp3.Invoke_O__O(tmp4)
//line :393:1
L1: for {

	var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_214.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_O__Z(length_count740000178__3, A_arbace_pprint_A_const_214.Get__O())).Ref() }; if jrt.A2g_Truth(tmp5) { if jrt.A2g_Truth(alis__4) {

		lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(alis__4))
//line :395:1
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(alis__4)) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_4)




			lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_439)
//line :395:1
			length_count740000178__3, alis__4 = lang.Numbers_Inc_J__J(length_count740000178__3), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(alis__4); continue L1 } } } else { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_154) }
//line :393:1
	break L1 }; var tmp6 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp6.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :398:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A) Ctor_O_O_O_O_O(c__white_space, c__s, c__s0, c__mode, c__this any) { t.F_white_space = c__white_space; t.F_s = c__s; t.F_s0 = c__s0; t.F_mode = c__mode; t.F_this = c__this }
//line :398:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A) Invoke_O__O(self any) any {
	if lang.Util_Equiv_O_O__Z(t.F_mode, A_arbace_pprint_A_const_169) {

		lang.IFn_Cast(A_arbace_pprint_A_const_167.GetRawRoot__O()).Invoke_O__O(t.F_this)
//line :399:1
		var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____1 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))


		jrt.Writer_Cast(w__1820000023__auto____1).Write_String__V(jrt.String_Cast(t.F_s))
		return lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_125, t.F_white_space) } else {
//line :399:1
			var tmp2 *lang.Keyword = A_arbace_pprint_A_const_163; var oldpos__1 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var newpos__2 any = lang.Numbers_Add_O_J__Number(oldpos__1, int64(lang.RT_Count_O__I(t.F_s0)))






			lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_163, newpos__2)
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_165.GetRawRoot__O()); var tmp4 any = t.F_this; return tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_pprint_A_const_166.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_s, t.F_white_space, oldpos__1, newpos__2)) } }
//line :401:1
func A_arbace_pprint_format_ordinal_english_A_New() *A_arbace_pprint_format_ordinal_english_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_ordinal_english_A{}; t.Ctor(); return t }
//line :401:1
func (t *A_arbace_pprint_format_ordinal_english_A) Ctor() {}
//line :401:1
func (t *A_arbace_pprint_format_ordinal_english_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000060__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000060__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000060__4, lang.RT_IntCast_J__I(1), nil); if

	lang.Util_Equiv_J_O__Z(0, arg__5) {
		lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(Lit_106) } else {
//line :403:1
			var abs_arg__7 any

			if lang.Numbers_IsNeg_O__Z(arg__5) { abs_arg__7 = lang.Numbers_Minus_O__Number(arg__5) } else { abs_arg__7 = arg__5 }
//line :403:1
			var parts__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_327.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_353, abs_arg__7)



			if lang.Numbers_Lte_J_J__Z(int64(lang.RT_Count_O__I(parts__8)), int64(lang.RT_Count_O__I(A_arbace_pprint_A_const_341.GetRawRoot__O()))) { var parts_strs__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_346.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_354.GetRawRoot__O()).Invoke_O__O(parts__8)); var head_str__10 any = lang.IFn_Cast(A_arbace_pprint_A_const_343.GetRawRoot__O()).Invoke_O_O__O(parts_strs__9, A_arbace_pprint_A_const_176); var tail_str__11 any = lang.IFn_Cast(A_arbace_pprint_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_97.GetRawRoot__O()).Invoke_O__O(parts__8)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 *jrt.String



				if lang.Numbers_IsNeg_O__Z(arg__5) { tmp3 = Lit_100 } else { tmp3 = nil }; var tmp4 any = tmp3.Ref(); var tmp5 any; var tmp6 any; var and__1927000168__auto____14 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(head_str__10))

				if jrt.A2g_Truth(and__1927000168__auto____14) { tmp6 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(tail_str__11)) } else { tmp6 = and__1927000168__auto____14 }
//line :412:1
				if jrt.A2g_Truth(tmp6) {

					tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, head_str__10, nil, tail_str__11)).Ref() } else {
//line :412:1
						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(head_str__10))) {



							tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, head_str__10, nil)).Ref() } else {
//line :412:1
								if A_arbace_pprint_A_const_95 != nil { tmp5 = tail_str__11 } else { tmp5 = nil } } }
//line :411:1
				tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref()) } else {






					var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_344.GetRawRoot__O()); var tmp8 any = A_arbace_pprint_A_const_347; var tmp9 any = A_arbace_pprint_A_const_355; tmp7.Invoke_O_O_O_O__O(tmp8, tmp9, lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O__IPersistentVector(arg__5)), A_arbace_pprint_A_const_356)
//line :407:1
					var low_two_digits__9 any = lang.Numbers_Remainder_O_J__Number(arg__5, 100); var not_teens__10 bool; var or__1927000174__auto____10 bool = lang.Numbers_Lt_J_O__Z(11, low_two_digits__9)
















					if or__1927000174__auto____10 { not_teens__10 = or__1927000174__auto____10 } else { not_teens__10 = lang.Numbers_Gt_J_O__Z(19, low_two_digits__9) }
//line :407:1
					var low_digit__11 any = lang.Numbers_Remainder_O_J__Number(low_two_digits__9, 10); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp11 *jrt.String; var tmp12 bool; var and__1927000168__auto____12 bool = lang.Numbers_Equiv_O_J__Z(low_digit__11, 1)



















					if and__1927000168__auto____12 { tmp12 = not_teens__10 } else { tmp12 = and__1927000168__auto____12 }
//line :426:1
					if tmp12 { tmp11 = Lit_108 } else { var tmp13 bool; var and__1927000168__auto____12_2 bool = lang.Numbers_Equiv_O_J__Z(low_digit__11, 2)

						if and__1927000168__auto____12_2 { tmp13 = not_teens__10 } else { tmp13 = and__1927000168__auto____12_2 }
//line :426:1
						if tmp13 { tmp11 = Lit_109 } else { var tmp14 bool; var and__1927000168__auto____12_3 bool = lang.Numbers_Equiv_O_J__Z(low_digit__11, 3)


							if and__1927000168__auto____12_3 { tmp14 = not_teens__10 } else { tmp14 = and__1927000168__auto____12_3 }
//line :426:1
							if tmp14 { tmp11 = Lit_110 } else { if A_arbace_pprint_A_const_95 != nil { tmp11 = Lit_107 } else { tmp11 = nil } } } }; tmp10.Invoke_O__O(tmp11.Ref()) } }; return navigator__6 }
//line :405:1
func A_arbace_pprint_two_forms_A_New() *A_arbace_pprint_two_forms_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_two_forms_A{}; t.Ctor(); return t }
//line :405:1
func (t *A_arbace_pprint_two_forms_A) Ctor() {}
//line :405:1
func (t *A_arbace_pprint_two_forms_A) Invoke_O_O__O(self, amap__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_pprint_A_const_280.GetRawRoot__O(); var tmp6 any; var iter__1927001039__auto____2 any; var tmp7 any = A_arbace_pprint_two_forms_iter__740000181__740000185_A_New(); var tmp8 *jrt.Class
	var fncls__161 /*line :406:1*/*jrt.Class = A_arbace_pprint_two_forms_iter__740000181__740000185_A_fn_class


	if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_262, false); A_arbace_pprint_two_forms_iter__740000181__740000185_A_fn_class = fncls__161d; tmp8 = fncls__161d } else { tmp8 = fncls__161 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(amap__0)
//line :406:1
	return tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, tmp6))
}

func A_arbace_pprint_two_forms_iter__740000181__740000185_A_New() *A_arbace_pprint_two_forms_iter__740000181__740000185_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_two_forms_iter__740000181__740000185_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_pprint_two_forms_iter__740000181__740000185_A) Ctor() {}
//line :409:1
func (t *A_arbace_pprint_two_forms_iter__740000181__740000185_A) Invoke_O_O__O(self, s__740000182__1 any) any { var tmp1 any = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_New_O_O(self, s__740000182__1); var tmp2 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_263, false); A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_fn_class = fncls__160d; tmp2 = fncls__160d } else { tmp2 = fncls__160 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :409:1
func A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_New_O_O(p0, p1 any) *A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :409:1
func (t *A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A) Ctor_O_O(c__iter__740000181, c__s__740000182 any) { t.F_iter__740000181 = c__iter__740000181; t.F_s__740000182 = c__s__740000182 }
//line :409:1
func (t *A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A) Invoke_O__O(self any) any { { var s__740000182__1 any; var t_ any = t.F_s__740000182; t.F_s__740000182 = nil; s__740000182__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(s__740000182__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__740000182__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(s__740000182__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(s__740000182__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__740000184__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_New_O_I_O(b__740000184__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_264, false); A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_fn_class = fncls__159d; tmp2 = fncls__159d } else { tmp2 = fncls__159 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__740000181); return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__740000184__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(s__740000182__3))) } else { return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__740000184__6), nil) } } else { var x__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__740000182__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__740000181); return lang.IFn_Cast(A_arbace_pprint_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(x__4, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_77.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(x__4))), lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(x__4))), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(s__740000182__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :409:1
func A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :409:1
func (t *A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A) Ctor_O_I_O(c__b__740000184 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__740000184 = c__b__740000184; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :409:1
func (t *A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A) Invoke_O__O(self any) any { { var i__740000183__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__740000183__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__740000183__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_21.GetRawRoot__O()); var tmp3 any = t.F_b__740000184; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(x__2, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_77.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(x__2))), lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(x__2)))); i__740000183__1 = lang.Numbers_Unchecked_inc_J__J(i__740000183__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_pprint_add_core_ns_A_New() *A_arbace_pprint_add_core_ns_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_add_core_ns_A{}; t.Ctor(); return t }
//line :412:1
func (t *A_arbace_pprint_add_core_ns_A) Ctor() {}
//line :412:1
func (t *A_arbace_pprint_add_core_ns_A) Invoke_O_O__O(self, amap__0 any) any { var core__2 any = Lit_1; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;

	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp5 any = A_arbace_pprint_add_core_ns_fn__740000193_A_New_O(core__2); var tmp6 *jrt.Class; var fncls__162 *jrt.Class = A_arbace_pprint_add_core_ns_fn__740000193_A_fn_class; if
	fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_pprint_add_core_ns_fn__740000193_A_fn_class = fncls__162d; tmp6 = fncls__162d } else { tmp6 = fncls__162 }; return /*line :414:1*/ tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), amap__0)) }
func A_arbace_pprint_add_core_ns_fn__740000193_A_New_O(p0 any) *A_arbace_pprint_add_core_ns_fn__740000193_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_add_core_ns_fn__740000193_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_pprint_add_core_ns_fn__740000193_A) Ctor_O(c__core any) { t.F_core = c__core }
//line :415:1
func (t *A_arbace_pprint_add_core_ns_fn__740000193_A) Invoke_O_O__O(self, p1__740000192_SHARP___1 any) any { var vec__740000194__2 any = p1__740000192_SHARP___1; var s__3 any = lang.RT_Nth_O_I_O__O(vec__740000194__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__740000194__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_615.GetRawRoot__O()).Invoke_O__O(s__3); if
														jrt.A2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.IFn_Cast(A_arbace_pprint_A_const_616.GetRawRoot__O()).Invoke_O__O(s__3) }; if jrt.A2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_77.GetRawRoot__O()); var tmp4 any = t.F_core; return lang.Tuple_Create_O_O__IPersistentVector(tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_pprint_A_const_68.GetRawRoot__O()).Invoke_O__O(s__3)), f__4) } else { return p1__740000192_SHARP___1 } }

func A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_New_O(p0 any) *A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A{}; t.Ctor_O(p0); return t }
//line :418:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :418:1
func (t *A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_155.GetRawRoot__O()); var tmp2 any = t.F_this; var tmp3 *lang.Keyword = A_arbace_pprint_A_const_157; var tmp4 any = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; tmp1.Invoke_O_O_O__O(tmp2, tmp4, tmp5.Ref())
	var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this); var tmp8 any = A_arbace_pprint_A_const_44.GetRawRoot__O(); var tmp9 any = A_arbace_pprint_A_const_157; var tmp10 *lang.PersistentVector; lang.PersistentVector_Init(); tmp10 = lang.PersistentVector_EMPTY; return tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp9, tmp10.Ref())
}













func A_arbace_pprint_start_block_A_New() *A_arbace_pprint_start_block_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_start_block_A{}; t.Ctor(); return t }
//line :435:1
func (t *A_arbace_pprint_start_block_A) Ctor() {}
//line :435:1
func (t *A_arbace_pprint_start_block_A) Invoke_O_O_O_O_O__O(self, this__0, prefix__1, per_line_prefix__2, suffix__3 any) any {


	var tmp1 any = A_arbace_pprint_start_block_fn__1820000190_A_New_O_O_O_O(suffix__3, prefix__1, per_line_prefix__2, this__0); var tmp2 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_pprint_start_block_fn__1820000190_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_257, false); A_arbace_pprint_start_block_fn__1820000190_A_fn_class = fncls__38d; tmp2 = fncls__38d } else { tmp2 = fncls__38 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :438:1
func A_arbace_pprint_pprint_code_list_A_New() *A_arbace_pprint_pprint_code_list_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_code_list_A{}; t.Ctor(); return t }
//line :438:1
func (t *A_arbace_pprint_pprint_code_list_A) Ctor() {}
//line :438:1
func (t *A_arbace_pprint_pprint_code_list_A) Invoke_O_O__O(self, alis__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_590.GetRawRoot__O()).Invoke_O__O(alis__0))) { var temp__1927000408__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_617.Get__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(alis__0))
		if jrt.A2g_Truth(temp__1927000408__auto____2) { var special_form__3 any = temp__1927000408__auto____2
			return lang.IFn_Cast(special_form__3).Invoke_O__O(alis__0) } else {
				return lang.IFn_Cast(A_arbace_pprint_A_const_608.GetRawRoot__O()).Invoke_O__O(alis__0) } } else {
//line :439:1
					return nil } }
//line :438:1
func A_arbace_pprint_start_block_fn__1820000190_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_pprint_start_block_fn__1820000190_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_start_block_fn__1820000190_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :438:1
func (t *A_arbace_pprint_start_block_fn__1820000190_A) Ctor_O_O_O_O(c__suffix, c__prefix, c__per_line_prefix, c__this any) { t.F_suffix = c__suffix; t.F_prefix = c__prefix; t.F_per_line_prefix = c__per_line_prefix; t.F_this = c__this }
//line :438:1
func (t *A_arbace_pprint_start_block_fn__1820000190_A) Invoke_O__O(self any) any { var lb__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_171.GetRawRoot__O(); var tmp3 *lang.Keyword = A_arbace_pprint_A_const_160; var tmp4 any = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var tmp5 any = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_28); var tmp6 any = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_28); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()); var tmp8 *jrt.Boolean;
											jrt.Boolean_Init(); tmp8 = jrt.Boolean_FALSE; var tmp9 any = tmp7.Invoke_O__O(tmp8.Ref()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_FALSE; lb__1 = tmp1.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp2, tmp4, nil, tmp5, tmp6, tmp9, tmp10.Invoke_O__O(tmp11.Ref()), t.F_prefix, t.F_per_line_prefix, t.F_suffix);


	lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_160, lb__1); var tmp12 /*line :443:1*/*lang.Keyword = A_arbace_pprint_A_const_162; if lang.Util_Equiv_O_O__Z(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))), A_arbace_pprint_A_const_169) {

		lang.IFn_Cast(A_arbace_pprint_A_const_167.GetRawRoot__O()).Invoke_O__O(t.F_this)
//line :443:1
		var tmp13 *lang.Keyword = A_arbace_pprint_A_const_116; var temp__1927000414__auto____2 any = tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))


		if jrt.A2g_Truth(temp__1927000414__auto____2) { var cb__3 any = temp__1927000414__auto____2; lang.IFn_Cast(cb__3).Invoke_O__O(A_arbace_pprint_A_const_117) }
		if jrt.A2g_Truth(t.F_prefix) { var tmp14 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____2 any = tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))
			jrt.Writer_Cast(w__1820000023__auto____2).Write_String__V(jrt.String_Cast(t.F_prefix)) }
//line :443:1
		var tmp15 *lang.Keyword = A_arbace_pprint_A_const_50; var col__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))))






		lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_114.Invoke_O__O(lb__1), col__2)
		return lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_115.Invoke_O__O(lb__1), col__2) } else {
//line :443:1
			var tmp16 *lang.Keyword = A_arbace_pprint_A_const_163; var oldpos__2 any = tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var newpos__3 any; var tmp17 any









			if jrt.A2g_Truth(t.F_prefix) { tmp17 = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_prefix)).Ref() } else { tmp17 = A_arbace_pprint_A_const_28 }; newpos__3 = lang.Numbers_Add_O_O__Number(oldpos__2, tmp17)
			lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_163, newpos__3)
			var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_165.GetRawRoot__O()); var tmp19 any = t.F_this; return tmp18.Invoke_O_O__O(tmp19, lang.IFn_Cast(A_arbace_pprint_A_const_179.GetRawRoot__O()).Invoke_O_O_O__O(lb__1, oldpos__2, newpos__3)) } }
//line :444:1
func A_arbace_pprint_pprint_code_symbol_A_New() *A_arbace_pprint_pprint_code_symbol_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pprint_code_symbol_A{}; t.Ctor(); return t }
//line :444:1
func (t *A_arbace_pprint_pprint_code_symbol_A) Ctor() {}
//line :444:1
func (t *A_arbace_pprint_pprint_code_symbol_A) Invoke_O_O__O(self, sym__0 any) any { var temp__1927000408__auto____2 any = lang.IFn_Cast(sym__0).Invoke_O__O(A_arbace_pprint_A_const_613.Get__O()); if
											jrt.A2g_Truth(temp__1927000408__auto____2) { var arg_num__3 any = temp__1927000408__auto____2
												return lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(arg_num__3) } else {
													if jrt.A2g_Truth(A_arbace_pprint_A_const_598.Get__O()) {
														return lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_68.GetRawRoot__O()).Invoke_O__O(sym__0)) } else {
															return lang.IFn_Cast(A_arbace_pprint_A_const_215.Get__O()).Invoke_O__O(sym__0) } } }

func A_arbace_pprint_format_roman_A_New() *A_arbace_pprint_format_roman_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_roman_A{}; t.Ctor(); return t }
//line :451:1
func (t *A_arbace_pprint_format_roman_A) Ctor() {}
//line :451:1
func (t *A_arbace_pprint_format_roman_A) Invoke_O_O_O_O_O__O(self, table__0, params__1, navigator__2, offsets__3 any) any { var vec__1819000064__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__2); var arg__6 any = lang.RT_Nth_O_I_O__O(vec__1819000064__5, lang.RT_IntCast_J__I(0), nil); var navigator__7 any = lang.RT_Nth_O_I_O__O(vec__1819000064__5, lang.RT_IntCast_J__I(1), nil); var tmp1 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_pprint_A_const_357.GetRawRoot__O()).Invoke_O__O(arg__6); if



	jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 bool = lang.Numbers_Gt_O_J__Z(arg__6, 0); if and__1927000168__auto____9 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_O_J__Z(arg__6, 4000)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() } } else { tmp1 = and__1927000168__auto____8 }; if jrt.A2g_Truth(tmp1) { var digits__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_327.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_347, arg__6); var acc__9 any; lang.PersistentVector_Init(); acc__9 = lang.PersistentVector_EMPTY.Ref(); var pos__10 int64 = lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(digits__8))); var digits__11 any = digits__8; L1: for {




		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(digits__11)) {
			lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), acc__9)) } else {
//line :460:1
				var digit__12 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(digits__11); var tmp2 any


				if lang.Util_Equiv_J_O__Z(0, digit__12) { tmp2 = acc__9 } else {

					tmp2 = lang.IFn_Cast(A_arbace_pprint_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__9, lang.RT_Nth_O_I__O(lang.RT_Nth_O_I__O(table__0, lang.RT_IntCast_J__I(pos__10)), lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(digit__12)))) }
//line :463:1
				acc__9, pos__10, digits__11 = tmp2, lang.Numbers_Dec_J__J(pos__10), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(digits__11); continue L1 }
//line :455:1
		break L1 } } else {












			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_344.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_A_const_347; var tmp5 any = A_arbace_pprint_A_const_358; tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O__IPersistentVector(arg__6)), A_arbace_pprint_A_const_359) }; return navigator__7 }
//line :457:1
func A_arbace_pprint_end_block_A_New() *A_arbace_pprint_end_block_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_end_block_A{}; t.Ctor(); return t }
//line :457:1
func (t *A_arbace_pprint_end_block_A) Ctor() {}
//line :457:1
func (t *A_arbace_pprint_end_block_A) Invoke_O_O__O(self, this__0 any) any {
	var tmp1 any = A_arbace_pprint_end_block_fn__1820000193_A_New_O(this__0); var tmp2 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_pprint_end_block_fn__1820000193_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_pprint_end_block_fn__1820000193_A_fn_class = fncls__39d; tmp2 = fncls__39d } else { tmp2 = fncls__39 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :458:1
func A_arbace_pprint_end_block_fn__1820000193_A_New_O(p0 any) *A_arbace_pprint_end_block_fn__1820000193_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_end_block_fn__1820000193_A{}; t.Ctor_O(p0); return t }
//line :458:1
func (t *A_arbace_pprint_end_block_fn__1820000193_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :458:1
func (t *A_arbace_pprint_end_block_fn__1820000193_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_160; var lb__1 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var suffix__2 any = A_arbace_pprint_A_const_118.Invoke_O__O(lb__1); var tmp2 *lang.Keyword = A_arbace_pprint_A_const_162; if


	lang.Util_Equiv_O_O__Z(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))), A_arbace_pprint_A_const_169) {

		lang.IFn_Cast(A_arbace_pprint_A_const_167.GetRawRoot__O()).Invoke_O__O(t.F_this)
		if jrt.A2g_Truth(suffix__2) { var tmp3 *lang.Keyword = A_arbace_pprint_A_const_50; var w__1820000023__auto____3 any = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))
			jrt.Writer_Cast(w__1820000023__auto____3).Write_String__V(jrt.String_Cast(suffix__2)) }
//line :461:1
		var tmp4 *lang.Keyword = A_arbace_pprint_A_const_116; var temp__1927000414__auto____3 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))




		if jrt.A2g_Truth(temp__1927000414__auto____3) { var cb__4 any = temp__1927000414__auto____3; lang.IFn_Cast(cb__4).Invoke_O__O(A_arbace_pprint_A_const_119) } } else {
//line :461:1
			var tmp5 *lang.Keyword = A_arbace_pprint_A_const_163; var oldpos__3 any = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var newpos__4 any; var tmp6 any






			if jrt.A2g_Truth(suffix__2) { tmp6 = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(suffix__2)).Ref() } else { tmp6 = A_arbace_pprint_A_const_28 }; newpos__4 = lang.Numbers_Add_O_O__Number(oldpos__3, tmp6)
			lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_163, newpos__4)
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_165.GetRawRoot__O()); var tmp8 any = t.F_this; tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_pprint_A_const_180.GetRawRoot__O()).Invoke_O_O_O__O(lb__1, oldpos__3, newpos__4)) }; var tmp9 lang.IFn =
	lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this); var tmp11 any = A_arbace_pprint_A_const_44.GetRawRoot__O(); var tmp12 any = A_arbace_pprint_A_const_160; return tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, tmp12, A_arbace_pprint_A_const_94.Invoke_O__O(lb__1)) }

func A_arbace_pprint_nl_A_New() *A_arbace_pprint_nl_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_nl_A{}; t.Ctor(); return t }
//line :473:1
func (t *A_arbace_pprint_nl_A) Ctor() {}
//line :473:1
func (t *A_arbace_pprint_nl_A) Invoke_O_O_O__O(self, this__0, type__1 any) any {
	var tmp1 any = A_arbace_pprint_nl_fn__1820000196_A_New_O_O(type__1, this__0); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_pprint_nl_fn__1820000196_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_140, false); A_arbace_pprint_nl_fn__1820000196_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :474:1
func A_arbace_pprint_nl_fn__1820000196_A_New_O_O(p0, p1 any) *A_arbace_pprint_nl_fn__1820000196_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_nl_fn__1820000196_A{}; t.Ctor_O_O(p0, p1); return t }
//line :474:1
func (t *A_arbace_pprint_nl_fn__1820000196_A) Ctor_O_O(c__type, c__this any) { t.F_type = c__type; t.F_this = c__this }
//line :474:1
func (t *A_arbace_pprint_nl_fn__1820000196_A) Invoke_O__O(self any) any {
	lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_162, A_arbace_pprint_A_const_161)
//line :474:1
	var tmp1 *lang.Keyword = A_arbace_pprint_A_const_163; var pos__1 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_165.GetRawRoot__O()); var tmp3 any = t.F_this; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_181.GetRawRoot__O()); var tmp5 any = t.F_type
	var tmp6 /*line :474:1*/*lang.Keyword = A_arbace_pprint_A_const_160


	return tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))), pos__1, pos__1)) }
//line :475:1
func A_arbace_pprint_format_old_roman_A_New() *A_arbace_pprint_format_old_roman_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_old_roman_A{}; t.Ctor(); return t }
//line :475:1
func (t *A_arbace_pprint_format_old_roman_A) Ctor() {}
//line :475:1
func (t *A_arbace_pprint_format_old_roman_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_360.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_361.GetRawRoot__O(), params__0, navigator__1, offsets__2)
}
func A_arbace_pprint_format_new_roman_A_New() *A_arbace_pprint_format_new_roman_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_new_roman_A{}; t.Ctor(); return t }
//line :478:1
func (t *A_arbace_pprint_format_new_roman_A) Ctor() {}
//line :478:1
func (t *A_arbace_pprint_format_new_roman_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_360.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_362.GetRawRoot__O(), params__0, navigator__1, offsets__2) }
//line :479:1
func A_arbace_pprint_indent_A_New() *A_arbace_pprint_indent_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_indent_A{}; t.Ctor(); return t }
//line :479:1
func (t *A_arbace_pprint_indent_A) Ctor() {}
//line :479:1
func (t *A_arbace_pprint_indent_A) Invoke_O_O_O_O__O(self, this__0, relative_to__1, offset__2 any) any {
	var tmp1 any = A_arbace_pprint_indent_fn__1820000199_A_New_O_O_O(relative_to__1, offset__2, this__0); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_pprint_indent_fn__1820000199_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_pprint_indent_fn__1820000199_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :480:1
func A_arbace_pprint_indent_fn__1820000199_A_New_O_O_O(p0, p1, p2 any) *A_arbace_pprint_indent_fn__1820000199_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_indent_fn__1820000199_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :480:1
func (t *A_arbace_pprint_indent_fn__1820000199_A) Ctor_O_O_O(c__relative_to, c__offset, c__this any) { t.F_relative_to = c__relative_to; t.F_offset = c__offset; t.F_this = c__this }
//line :480:1
func (t *A_arbace_pprint_indent_fn__1820000199_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_160; var lb__1 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var tmp2 *lang.Keyword = A_arbace_pprint_A_const_162; if

	lang.Util_Equiv_O_O__Z(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))), A_arbace_pprint_A_const_169) {

		lang.IFn_Cast(A_arbace_pprint_A_const_167.GetRawRoot__O()).Invoke_O__O(t.F_this)
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_A_const_115.Invoke_O__O(lb__1); var tmp5 any = t.F_offset; var tmp6 any; var pred__1820000200__2 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__1820000201__3 any = t.F_relative_to
		if jrt.A2g_Truth(lang.IFn_Cast(pred__1820000200__2).Invoke_O_O__O(A_arbace_pprint_A_const_122, expr__1820000201__3)) { tmp6 = lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_114.Invoke_O__O(lb__1)) } else { if jrt.A2g_Truth(lang.IFn_Cast(pred__1820000200__2).Invoke_O_O__O(A_arbace_pprint_A_const_123, expr__1820000201__3)) {

			var tmp7 *lang.Keyword = A_arbace_pprint_A_const_50; tmp6 = lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this)))) } else {
//line :486:1
				panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__1820000201__3))))) } }
//line :485:1
		return tmp3.Invoke_O_O__O(tmp4, lang.Numbers_Add_O_O__Number(tmp5, tmp6)) } else {
//line :482:1
			var tmp8 *lang.Keyword = A_arbace_pprint_A_const_163; var pos__2 any = tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this))); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_165.GetRawRoot__O()); var tmp10 any = t.F_this







			return tmp9.Invoke_O_O__O(tmp10, lang.IFn_Cast(A_arbace_pprint_A_const_182.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lb__1, t.F_relative_to, t.F_offset, pos__2, pos__2)) } }
//line :488:1
func A_arbace_pprint_pretty_character_A_New() *A_arbace_pprint_pretty_character_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_pretty_character_A{}; t.Ctor(); return t }
//line :488:1
func (t *A_arbace_pprint_pretty_character_A) Ctor() {}
//line :488:1
func (t *A_arbace_pprint_pretty_character_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000070__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var c__5 any = lang.RT_Nth_O_I_O__O(vec__1819000070__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000070__4, lang.RT_IntCast_J__I(1), nil); var as_int__7 int32 = lang.RT_IntCast_O__I(c__5); var base_char__8 int64 = lang.Numbers_And_J_J__J(int64(as_int__7), 127); var meta__9 int64 = lang.Numbers_And_J_J__J(int64(as_int__7), 128); var special__10 any = lang.RT_Get_O_O__O(A_arbace_pprint_A_const_363.GetRawRoot__O(), jrt.Long_ValueOf_J__Long(base_char__8).Ref()); if





	lang.Numbers_Gt_J_J__Z(meta__9, 0) { lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(Lit_208) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp2 any; if jrt.A2g_Truth(special__10) { tmp2 = special__10 } else { if lang.Numbers_Lt_J_J__Z(base_char__8, 32) {

		tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_209, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Character_ValueOf_C__Character(lang.RT_CharCast_J__C(lang.Numbers_Add_J_J__J(base_char__8, 64))).Ref())).Ref() } else {
//line :495:1
			if lang.Util_Equiv_J_J__Z(base_char__8, 127) { tmp2 = Lit_210 } else { if A_arbace_pprint_A_const_95 != nil {



				tmp2 = jrt.Character_ValueOf_C__Character(lang.RT_CharCast_J__C(base_char__8)).Ref() } else {
//line :495:1
					tmp2 = nil } } } }; tmp1.Invoke_O__O(tmp2); return navigator__6 }
//line :492:1
func A_arbace_pprint_get_miser_width_A_New() *A_arbace_pprint_get_miser_width_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_miser_width_A{}; t.Ctor(); return t }
//line :492:1
func (t *A_arbace_pprint_get_miser_width_A) Ctor() {}
//line :492:1
func (t *A_arbace_pprint_get_miser_width_A) Invoke_O_O__O(self, this__0 any) any {
	var tmp1 *lang.Keyword = A_arbace_pprint_A_const_177; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(this__0)))
}
func A_arbace_pprint_set_miser_width_A_New() *A_arbace_pprint_set_miser_width_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_miser_width_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_pprint_set_miser_width_A) Ctor() {}
//line :495:1
func (t *A_arbace_pprint_set_miser_width_A) Invoke_O_O_O__O(self, this__0, new_miser_width__1 any) any {
	var tmp1 any = A_arbace_pprint_set_miser_width_fn__1820000205_A_New_O_O(new_miser_width__1, this__0); var tmp2 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_pprint_set_miser_width_fn__1820000205_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_249, false); A_arbace_pprint_set_miser_width_fn__1820000205_A_fn_class = fncls__42d; tmp2 = fncls__42d } else { tmp2 = fncls__42 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :496:1
func A_arbace_pprint_set_miser_width_fn__1820000205_A_New_O_O(p0, p1 any) *A_arbace_pprint_set_miser_width_fn__1820000205_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_miser_width_fn__1820000205_A{}; t.Ctor_O_O(p0, p1); return t }
//line :496:1
func (t *A_arbace_pprint_set_miser_width_fn__1820000205_A) Ctor_O_O(c__new_miser_width, c__this any) { t.F_new_miser_width = c__new_miser_width; t.F_this = c__this }
//line :496:1
func (t *A_arbace_pprint_set_miser_width_fn__1820000205_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_177, t.F_new_miser_width) }

func A_arbace_pprint_set_logical_block_callback_A_New() *A_arbace_pprint_set_logical_block_callback_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_logical_block_callback_A{}; t.Ctor(); return t }
//line :498:1
func (t *A_arbace_pprint_set_logical_block_callback_A) Ctor() {}
//line :498:1
func (t *A_arbace_pprint_set_logical_block_callback_A) Invoke_O_O_O__O(self, this__0, f__1 any) any {
	var tmp1 any = A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_New_O_O(f__1, this__0); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_247, false); A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :499:1
func A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_New_O_O(p0, p1 any) *A_arbace_pprint_set_logical_block_callback_fn__1820000208_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_logical_block_callback_fn__1820000208_A{}; t.Ctor_O_O(p0, p1); return t }
//line :499:1
func (t *A_arbace_pprint_set_logical_block_callback_fn__1820000208_A) Ctor_O_O(c__f, c__this any) { t.F_f = c__f; t.F_this = c__this }
//line :499:1
func (t *A_arbace_pprint_set_logical_block_callback_fn__1820000208_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_this), A_arbace_pprint_A_const_44.GetRawRoot__O(), A_arbace_pprint_A_const_116, t.F_f) }


func A_arbace_pprint_readable_character_A_New() *A_arbace_pprint_readable_character_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_readable_character_A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_pprint_readable_character_A) Ctor() {}
//line :502:1
func (t *A_arbace_pprint_readable_character_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000074__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var c__5 any = lang.RT_Nth_O_I_O__O(vec__1819000074__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000074__4, lang.RT_IntCast_J__I(1), nil); var pred__1819000077__7 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__1819000078__8 any = A_arbace_pprint_A_const_364.Invoke_O__O(params__0); if

	jrt.A2g_Truth(lang.IFn_Cast(pred__1819000077__7).Invoke_O_O__O(A_arbace_pprint_A_const_366, expr__1819000078__8)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_365.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); tmp1.Invoke_O_O_O__O(tmp3, Lit_243, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(c__5)).Ref()) } else {
//line :504:1
			if jrt.A2g_Truth(lang.IFn_Cast(pred__1819000077__7).Invoke_O_O__O(A_arbace_pprint_A_const_367, expr__1819000078__8)) {

				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_365.GetRawRoot__O()); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); tmp4.Invoke_O_O_O__O(tmp6, Lit_244, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(c__5)).Ref()) } else {
//line :504:1
					if jrt.A2g_Truth(lang.IFn_Cast(pred__1819000077__7).Invoke_O_O__O(nil, expr__1819000078__8)) {


						lang.IFn_Cast(A_arbace_pprint_A_const_215.Get__O()).Invoke_O__O(c__5) } else {
//line :504:1
							panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__1819000078__8))))) } } }; return navigator__6 }





func A_arbace_pprint_plain_character_A_New() *A_arbace_pprint_plain_character_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_plain_character_A{}; t.Ctor(); return t }
//line :510:1
func (t *A_arbace_pprint_plain_character_A) Ctor() {}
//line :510:1
func (t *A_arbace_pprint_plain_character_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000080__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var char__5 any = lang.RT_Nth_O_I_O__O(vec__1819000080__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000080__4, lang.RT_IntCast_J__I(1), nil);

	lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(char__5); return navigator__6 }




func A_arbace_pprint_abort_QMARK__A_New() *A_arbace_pprint_abort_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_abort_QMARK__A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_pprint_abort_QMARK__A) Ctor() {}
//line :517:1
func (t *A_arbace_pprint_abort_QMARK__A) Invoke_O_O__O(self, context__0 any) any { var token__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(context__0); var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_368, token__2); if or__1927000174__auto____3 {

	return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_369, token__2)).Ref() } }


func A_arbace_pprint_execute_sub_format_A_New() *A_arbace_pprint_execute_sub_format_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_execute_sub_format_A{}; t.Ctor(); return t }
//line :522:1
func (t *A_arbace_pprint_execute_sub_format_A) Ctor() {}
//line :522:1
func (t *A_arbace_pprint_execute_sub_format_A) Invoke_O_O_O_O__O(self, format__0, args__1, base_args__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_308.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_execute_sub_format_fn__1819000085_A_New_O(base_args__2); var tmp4 *jrt.Class
	var fncls__55 /*line :523:1*/*jrt.Class = A_arbace_pprint_execute_sub_format_fn__1819000085_A_fn_class

	if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_pprint_execute_sub_format_fn__1819000085_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }
//line :523:1
	return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), args__1, format__0))
}
func A_arbace_pprint_execute_sub_format_fn__1819000085_A_New_O(p0 any) *A_arbace_pprint_execute_sub_format_fn__1819000085_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_execute_sub_format_fn__1819000085_A{}; t.Ctor_O(p0); return t }
//line :525:1
func (t *A_arbace_pprint_execute_sub_format_fn__1819000085_A) Ctor_O(c__base_args any) { t.F_base_args = c__base_args }
//line :525:1
func (t *A_arbace_pprint_execute_sub_format_fn__1819000085_A) Invoke_O_O_O__O(self, element__1, context__2 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_371.GetRawRoot__O()).Invoke_O__O(context__2)) { return lang.Tuple_Create_O_O__IPersistentVector(nil, context__2) } else { var vec__1819000086__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_372.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_374.Invoke_O__O(element__1), context__2); var params__4 any = lang.RT_Nth_O_I_O__O(vec__1819000086__3, lang.RT_IntCast_J__I(0), nil); var args__5 any = lang.RT_Nth_O_I_O__O(vec__1819000086__3, lang.RT_IntCast_J__I(1), nil); var vec__1819000089__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_373.GetRawRoot__O()).Invoke_O__O(params__4); var params__7 any = lang.RT_Nth_O_I_O__O(vec__1819000089__6, lang.RT_IntCast_J__I(0), nil); var offsets__8 any = lang.RT_Nth_O_I_O__O(vec__1819000089__6, lang.RT_IntCast_J__I(1), nil); var params__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(params__7, A_arbace_pprint_A_const_375, t.F_base_args); return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_376.Invoke_O__O(element__1), lang.Tuple_Create_O_O_O__IPersistentVector(params__9, args__5, offsets__8)))
	}
}











func A_arbace_pprint_float_parts_base_A_New() *A_arbace_pprint_float_parts_base_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_float_parts_base_A{}; t.Ctor(); return t }
//line :540:1
func (t *A_arbace_pprint_float_parts_base_A) Ctor() {}
//line :540:1
func (t *A_arbace_pprint_float_parts_base_A) Invoke_O_O__O(self, f__0 any) any { var s__2 any = jrt.NN(jrt.ToString(f__0)).ToLowerCase__String().Ref(); var exploc__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_I__I(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_377)); var dotloc__4 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_I__I(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_378)); if





	lang.Numbers_IsNeg_J__Z(int64(exploc__3)) {
		if lang.Numbers_IsNeg_J__Z(int64(dotloc__4)) { return lang.Tuple_Create_O_O__IPersistentVector(s__2, lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(s__2)))).Ref())) } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_28; return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, tmp1.Invoke_O_O_O__O(s__2, tmp2, jrt.Integer_ValueOf_I__Integer(dotloc__4).Ref()), lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__2, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(dotloc__4))).Ref()))).Ref(), lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(dotloc__4))).Ref())) } } else {


			if lang.Numbers_IsNeg_J__Z(int64(dotloc__4)) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_A_const_28; return lang.Tuple_Create_O_O__IPersistentVector(tmp3.Invoke_O_O_O__O(s__2, tmp4, jrt.Integer_ValueOf_I__Integer(exploc__3).Ref()), lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__2, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(exploc__3))).Ref())) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()); var tmp6 any = A_arbace_pprint_A_const_241; return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(s__2, A_arbace_pprint_A_const_28, A_arbace_pprint_A_const_176), tmp5.Invoke_O_O_O__O(s__2, tmp6, jrt.Integer_ValueOf_I__Integer(exploc__3).Ref()))).Ref(), lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__2, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(exploc__3))).Ref())) } } }



func A_arbace_pprint_float_parts_A_New() *A_arbace_pprint_float_parts_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_float_parts_A{}; t.Ctor(); return t }
//line :554:1
func (t *A_arbace_pprint_float_parts_A) Ctor() {}
//line :554:1
func (t *A_arbace_pprint_float_parts_A) Invoke_O_O__O(self, f__0 any) any { var vec__1819000095__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_379.GetRawRoot__O()).Invoke_O__O(f__0); var m__3 any = lang.RT_Nth_O_I_O__O(vec__1819000095__2, lang.RT_IntCast_J__I(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O(vec__1819000095__2, lang.RT_IntCast_J__I(1), nil); var m1__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_380.GetRawRoot__O()).Invoke_O_O__O(m__3, A_arbace_pprint_A_const_325); var m2__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_381.GetRawRoot__O()).Invoke_O_O__O(m1__5, A_arbace_pprint_A_const_325); var delta__7 int64 = lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(m1__5)), int64(lang.RT_Count_O__I(m2__6))); var e__8 any; var tmp1 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z(int64(lang.RT_Count_O__I(e__4))); if and__1927000168__auto____8 {






	tmp1 = lang.Util_Equiv_O_O__Z(lang.RT_Nth_O_I__O(e__4, lang.RT_IntCast_J__I(0)), A_arbace_pprint_A_const_382) } else { tmp1 = and__1927000168__auto____8 }; if tmp1 { e__8 = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(e__4, A_arbace_pprint_A_const_176) } else { e__8 = e__4 }; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(m2__6)) { return A_arbace_pprint_A_const_383 } else { return lang.Tuple_Create_O_O__IPersistentVector(m2__6, lang.Numbers_Minus_O_J__Number(jrt.Integer_ValueOf_String__Integer(jrt.String_Cast(e__8)).Ref(), delta__7)) } }



func A_arbace_pprint_inc_s_A_New() *A_arbace_pprint_inc_s_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_inc_s_A{}; t.Ctor(); return t }
//line :566:1
func (t *A_arbace_pprint_inc_s_A) Ctor() {}
//line :566:1
func (t *A_arbace_pprint_inc_s_A) Invoke_O_O__O(self, s__0 any) any { { var len_1__2 int64 = lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(s__0))); var i__3 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(len_1__2)); L1: for {








	if lang.Numbers_IsNeg_J__Z(i__3) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), Lit_118, lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(len_1__2)).Ref(), Lit_6)) } else {
//line :575:1
			if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(A_arbace_pprint_A_const_384)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(i__3))) {

				i__3 = lang.Numbers_Dec_J__J(i__3); continue L1 } else {
//line :575:1
					if A_arbace_pprint_A_const_95 != nil {


						var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_28; return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), tmp1.Invoke_O_O_O__O(s__0, tmp2, jrt.Long_ValueOf_J__Long(i__3).Ref()), jrt.Character_ValueOf_C__Character(lang.RT_CharCast_J__C(lang.Numbers_Inc_J__J(int64(lang.RT_IntCast_C__I(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(i__3))))))).Ref(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(len_1__2, i__3)).Ref(), Lit_6)) } else {
//line :575:1
							return nil } } } } }; /*line :566:1*/panic("a2g: unreachable") }















func A_arbace_pprint_round_str_A_New() *A_arbace_pprint_round_str_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_round_str_A{}; t.Ctor(); return t }
//line :582:1
func (t *A_arbace_pprint_round_str_A) Ctor() {}
//line :582:1
func (t *A_arbace_pprint_round_str_A) Invoke_O_O_O_O_O__O(self, m__0, e__1, d__2, w__3 any) any {
	var tmp1 any; var or__1927000174__auto____5 any = d__2; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = w__3 }; if jrt.A2g_Truth(tmp1) { var len__5 int32 = lang.RT_Count_O__I(m__0); var w__6 any



		if jrt.A2g_Truth(w__3) { w__6 = lang.Numbers_Max_J_O__O(2, w__3) } else { w__6 = nil }
//line :583:1
		var round_pos__7 any




		if jrt.A2g_Truth(d__2) {



			round_pos__7 = lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_O__Number(e__1, d__2), 1) } else {
//line :588:1
				if lang.Numbers_Gte_O_J__Z(e__1, 0) {











					round_pos__7 = lang.Numbers_Max_O_O__O(lang.Numbers_Inc_O__Number(e__1), lang.Numbers_Dec_O__Number(w__6)) } else {
//line :588:1
						if A_arbace_pprint_A_const_95 != nil {













							round_pos__7 = lang.Numbers_Add_O_O__Number(w__6, e__1) } else {
//line :588:1
								round_pos__7 = nil } } }
//line :583:1
		var vec__1819000100__8 any



















		if lang.Util_Equiv_O_J__Z(round_pos__7, 0) { var tmp2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__0)).Ref(); var tmp3 any = lang.Numbers_Inc_O__Number(e__1); var tmp4 any = A_arbace_pprint_A_const_176; vec__1819000100__8 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, tmp3, tmp4, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(len__5))).Ref()) } else { vec__1819000100__8 = lang.Tuple_Create_O_O_O_O__IPersistentVector(m__0, e__1, round_pos__7, jrt.Integer_ValueOf_I__Integer(len__5).Ref()) }
//line :583:1
		var m1__9 any = lang.RT_Nth_O_I_O__O(vec__1819000100__8, lang.RT_IntCast_J__I(0), nil); var e1__10 any = lang.RT_Nth_O_I_O__O(vec__1819000100__8, lang.RT_IntCast_J__I(1), nil); var round_pos__11 any = lang.RT_Nth_O_I_O__O(vec__1819000100__8, lang.RT_IntCast_J__I(2), nil); var len__12 any = lang.RT_Nth_O_I_O__O(vec__1819000100__8, lang.RT_IntCast_J__I(3), nil)






















		if jrt.A2g_Truth(round_pos__11) {
			if lang.Numbers_IsNeg_O__Z(round_pos__11) { return A_arbace_pprint_A_const_385 } else {

				if lang.Numbers_Gt_O_O__Z(len__12, round_pos__11) { var round_char__13 any = lang.RT_Nth_O_I__O(m1__9, lang.RT_IntCast_O__I(round_pos__11)); var result__14 any = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(m1__9, A_arbace_pprint_A_const_28, round_pos__11)


					if lang.Numbers_Gte_J_J__Z(int64(lang.RT_IntCast_O__I(round_char__13)), int64(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_386))) { var round_up_result__15 any = lang.IFn_Cast(A_arbace_pprint_A_const_387.GetRawRoot__O()).Invoke_O__O(result__14); var expanded__16 bool = lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(round_up_result__15)), int64(lang.RT_Count_O__I(result__14))); var tmp5 any


						if expanded__16 {
							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()); var tmp7 any = A_arbace_pprint_A_const_28; tmp5 = tmp6.Invoke_O_O_O__O(round_up_result__15, tmp7, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(round_up_result__15)))).Ref()) } else {
//line :615:1
								tmp5 = round_up_result__15 }
//line :612:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, e1__10, jrt.Boolean_ValueOf_Z__Boolean(expanded__16).Ref()) } else { var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O_O__IPersistentVector(result__14, e1__10, tmp8.Ref()) } } else {
//line :609:1
							var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O_O__IPersistentVector(m__0, e__1, tmp9.Ref()) } } } else {
//line :606:1
								var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O_O__IPersistentVector(m__0, e__1, tmp10.Ref()) } } else {
//line :583:1
									var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O_O__IPersistentVector(m__0, e__1, tmp11.Ref())
								}
}






































func A_arbace_pprint_expand_fixed_A_New() *A_arbace_pprint_expand_fixed_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_expand_fixed_A{}; t.Ctor(); return t }
//line :624:1
func (t *A_arbace_pprint_expand_fixed_A) Ctor() {}
//line :624:1
func (t *A_arbace_pprint_expand_fixed_A) Invoke_O_O_O_O__O(self, m__0, e__1, d__2 any) any { var vec__1819000104__4 any; if
												lang.Numbers_IsNeg_O__Z(e__1) { vec__1819000104__4 = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Dec_O__Number(lang.Numbers_Minus_O__Number(e__1)), A_arbace_pprint_A_const_325)), m__0)).Ref(), A_arbace_pprint_A_const_159) } else { vec__1819000104__4 = lang.Tuple_Create_O_O__IPersistentVector(m__0, e__1) }; var m1__5 any = /*line :624:1*/lang.RT_Nth_O_I_O__O(vec__1819000104__4, lang.RT_IntCast_J__I(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O(vec__1819000104__4, lang.RT_IntCast_J__I(1), nil); var len__7 int32 = lang.RT_Count_O__I(m1__5); var target_len__8 any; if




	jrt.A2g_Truth(d__2) { target_len__8 = lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_O__Number(e1__6, d__2), 1) } else { target_len__8 = lang.Numbers_Inc_O__Number(e1__6) }; if
	lang.Numbers_Lt_J_O__Z(int64(len__7), target_len__8) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, m1__5, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(target_len__8, int64(len__7)), A_arbace_pprint_A_const_325)))).Ref() } else {
//line :630:1
			return m1__5 } }



func A_arbace_pprint_insert_decimal_A_New() *A_arbace_pprint_insert_decimal_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_insert_decimal_A{}; t.Ctor(); return t }
//line :634:1
func (t *A_arbace_pprint_insert_decimal_A) Ctor() {}
//line :634:1
func (t *A_arbace_pprint_insert_decimal_A) Invoke_O_O_O__O(self, m__0, e__1 any) any {


	if lang.Numbers_IsNeg_O__Z(e__1) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_112, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__0)).Ref() } else {
//line :637:1
			var loc__3 any = lang.Numbers_Inc_O__Number(e__1)


			return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(m__0, A_arbace_pprint_A_const_28, loc__3), nil, lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(m__0, loc__3))).Ref()
		} }
func A_arbace_pprint_get_fixed_A_New() *A_arbace_pprint_get_fixed_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_fixed_A{}; t.Ctor(); return t }
//line :642:1
func (t *A_arbace_pprint_get_fixed_A) Ctor() {}
//line :642:1
func (t *A_arbace_pprint_get_fixed_A) Invoke_O_O_O_O__O(self, m__0, e__1, d__2 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_388.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_389.GetRawRoot__O()).Invoke_O_O_O__O(m__0, e__1, d__2), e__1)
}
func A_arbace_pprint_insert_scaled_decimal_A_New() *A_arbace_pprint_insert_scaled_decimal_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_insert_scaled_decimal_A{}; t.Ctor(); return t }
//line :645:1
func (t *A_arbace_pprint_insert_scaled_decimal_A) Ctor() {}
//line :645:1
func (t *A_arbace_pprint_insert_scaled_decimal_A) Invoke_O_O_O__O(self, m__0, k__1 any) any {


	if lang.Numbers_IsNeg_O__Z(k__1) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_112, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__0)).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(m__0, A_arbace_pprint_A_const_28, k__1), nil, lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(m__0, k__1))).Ref()
		} }
func A_arbace_pprint_convert_ratio_A_New() *A_arbace_pprint_convert_ratio_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_convert_ratio_A{}; t.Ctor(); return t }
//line :652:1
func (t *A_arbace_pprint_convert_ratio_A) Ctor() {}
//line :652:1
func (t *A_arbace_pprint_convert_ratio_A) Invoke_O_O__O(self, x__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_313.GetRawRoot__O()).Invoke_O__O(x__0)) { var d__2 float64 = lang.RT_DoubleCast_O__D(x__0)




		if lang.Numbers_Equiv_D_D__Z(d__2, 0.0) {
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_390.GetRawRoot__O()).Invoke_O_O__O(x__0, A_arbace_pprint_A_const_28)) {
				return lang.IFn_Cast(A_arbace_pprint_A_const_320.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :659:1
					return jrt.Double_ValueOf_D__Double(d__2).Ref() } } else {


						var tmp1 bool; var or__1927000174__auto____3 bool = lang.Numbers_Equiv_D_D__Z(d__2, jrt.PosInf64); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Numbers_Equiv_D_D__Z(d__2, jrt.NegInf64) }; if tmp1 {
							return lang.IFn_Cast(A_arbace_pprint_A_const_320.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :662:1
								return jrt.Double_ValueOf_D__Double(d__2).Ref() } } } else {
//line :653:1
									return x__0
								}
}













func A_arbace_pprint_fixed_float_A_New() *A_arbace_pprint_fixed_float_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fixed_float_A{}; t.Ctor(); return t }
//line :669:1
func (t *A_arbace_pprint_fixed_float_A) Ctor() {}
//line :669:1
func (t *A_arbace_pprint_fixed_float_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var w__4 any = A_arbace_pprint_A_const_391.Invoke_O__O(params__0); var d__5 any = A_arbace_pprint_A_const_392.Invoke_O__O(params__0); var vec__1819000112__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var arg__7 any = lang.RT_Nth_O_I_O__O(vec__1819000112__6, lang.RT_IntCast_J__I(0), nil); var navigator__8 any = lang.RT_Nth_O_I_O__O(vec__1819000112__6, lang.RT_IntCast_J__I(1), nil); var vec__1819000115__9 any; if



	lang.Numbers_IsNeg_O__Z(arg__7) { vec__1819000115__9 = lang.Tuple_Create_O_O__IPersistentVector(Lit_61, lang.Numbers_Minus_O__Number(arg__7)) } else { vec__1819000115__9 = lang.Tuple_Create_O_O__IPersistentVector(Lit_62, arg__7) }; var sign__10 any = /*line :669:1*/lang.RT_Nth_O_I_O__O(vec__1819000115__9, lang.RT_IntCast_J__I(0), nil); var abs__11 any = lang.RT_Nth_O_I_O__O(vec__1819000115__9, lang.RT_IntCast_J__I(1), nil); var abs__12 any = lang.IFn_Cast(A_arbace_pprint_A_const_393.GetRawRoot__O()).Invoke_O__O(abs__11); var vec__1819000118__13 any = lang.IFn_Cast(A_arbace_pprint_A_const_394.GetRawRoot__O()).Invoke_O__O(abs__12); var mantissa__14 any = lang.RT_Nth_O_I_O__O(vec__1819000118__13, lang.RT_IntCast_J__I(0), nil); var exp__15 any = lang.RT_Nth_O_I_O__O(vec__1819000118__13, lang.RT_IntCast_J__I(1), nil); var scaled_exp__16 any = lang.Numbers_Add_O_O__Number(exp__15, A_arbace_pprint_A_const_395.Invoke_O__O(params__0)); var add_sign__17 any; var or__1927000174__auto____17 any = A_arbace_pprint_A_const_318.Invoke_O__O(params__0); if







	jrt.A2g_Truth(or__1927000174__auto____17) { add_sign__17 = or__1927000174__auto____17 } else { add_sign__17 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_O__Z(arg__7)).Ref() }; var append_zero__18 any; var and__1927000168__auto____18 any = /*line :669:1*/lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(d__5); if








	jrt.A2g_Truth(and__1927000168__auto____18) { append_zero__18 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lte_J_O__Z(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(mantissa__14))), scaled_exp__16)).Ref() } else { append_zero__18 = and__1927000168__auto____18 }; var vec__1819000121__19 any; var tmp1 lang.IFn = /*line :669:1*/lang.IFn_Cast(A_arbace_pprint_A_const_396.GetRawRoot__O()); var tmp2 jrt.Number_I; if










	jrt.A2g_Truth(w__4) { var tmp3 int64; if jrt.A2g_Truth(add_sign__17) { tmp3 = 1 } else { tmp3 = 0 }; tmp2 = lang.Numbers_Minus_O_J__Number(w__4, tmp3) } else { tmp2 = nil }; vec__1819000121__19 = /*line :679:1*/tmp1.Invoke_O_O_O_O__O(mantissa__14, scaled_exp__16, d__5, tmp2); var rounded_mantissa__20 any = /*line :669:1*/lang.RT_Nth_O_I_O__O(vec__1819000121__19, lang.RT_IntCast_J__I(0), nil); var scaled_exp__21 any = lang.RT_Nth_O_I_O__O(vec__1819000121__19, lang.RT_IntCast_J__I(1), nil); var expanded__22 any = lang.RT_Nth_O_I_O__O(vec__1819000121__19, lang.RT_IntCast_J__I(2), nil); var fixed_repr__23 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_397.GetRawRoot__O()); var tmp5 any; if











	jrt.A2g_Truth(expanded__22) { tmp5 = lang.Numbers_Inc_O__Number(scaled_exp__21) } else { tmp5 = scaled_exp__21 }; fixed_repr__23 = tmp4.Invoke_O_O_O__O(rounded_mantissa__20, tmp5, d__5); var fixed_repr__24 any; var tmp6 any; var and__1927000168__auto____24 any = w__4; if
	jrt.A2g_Truth(and__1927000168__auto____24) { var and__1927000168__auto____25 any = d__5; if jrt.A2g_Truth(and__1927000168__auto____25) { var and__1927000168__auto____26 bool = lang.Numbers_Gte_O_J__Z(d__5, 1); if and__1927000168__auto____26 { var and__1927000168__auto____27 bool = lang.Util_Equiv_C_C__Z(jrt.NN(jrt.String_Cast(fixed_repr__23)).CharAt_I__C(lang.RT_IntCast_J__I(0)), jrt.NN(jrt.Character_Cast(A_arbace_pprint_A_const_325)).CharValue__C()); if and__1927000168__auto____27 { var and__1927000168__auto____28 bool = lang.Util_Equiv_C_C__Z(jrt.NN(jrt.String_Cast(fixed_repr__23)).CharAt_I__C(lang.RT_IntCast_J__I(1)), jrt.NN(jrt.Character_Cast(A_arbace_pprint_A_const_378)).CharValue__C()); if and__1927000168__auto____28 {



		var tmp7 int64 = int64(lang.RT_Count_O__I(fixed_repr__23)); var tmp8 int64; if jrt.A2g_Truth(add_sign__17) { tmp8 = 1 } else { tmp8 = 0 }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(tmp7, lang.Numbers_Minus_O_J__Number(w__4, tmp8))).Ref() } else {
//line :682:1
			tmp6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____28).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____27).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____26).Ref() } } else { tmp6 = and__1927000168__auto____25 } } else { tmp6 = and__1927000168__auto____24 }; if jrt.A2g_Truth(tmp6) {




				fixed_repr__24 = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(fixed_repr__23, A_arbace_pprint_A_const_176) } else {
//line :682:1
					fixed_repr__24 = fixed_repr__23 }; var prepend_zero__25 bool = /*line :669:1*/lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(fixed_repr__24), A_arbace_pprint_A_const_378); if




















	jrt.A2g_Truth(w__4) { var len__26 int32 = lang.RT_Count_O__I(fixed_repr__24); var signed_len__27 any

		if jrt.A2g_Truth(add_sign__17) { signed_len__27 = jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(len__26))).Ref() } else { signed_len__27 = jrt.Integer_ValueOf_I__Integer(len__26).Ref() }
//line :690:1
		var prepend_zero__28 any
		var and__1927000168__auto____28_2 bool = prepend_zero__25

		if and__1927000168__auto____28_2 { prepend_zero__28 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_O_O__Z(signed_len__27, w__4)).Ref()) } else { prepend_zero__28 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____28_2).Ref() }
//line :690:1
		var append_zero__29 any
		var and__1927000168__auto____29 any = append_zero__18


		if jrt.A2g_Truth(and__1927000168__auto____29) { append_zero__29 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_O_O__Z(signed_len__27, w__4)).Ref()) } else { append_zero__29 = and__1927000168__auto____29 }
//line :690:1
		var full_len__30 any; var tmp9 any
		var or__1927000174__auto____30 any = prepend_zero__28



		if jrt.A2g_Truth(or__1927000174__auto____30) { tmp9 = or__1927000174__auto____30 } else { tmp9 = append_zero__29 }; if jrt.A2g_Truth(tmp9) {
			full_len__30 = lang.Numbers_Inc_O__Number(signed_len__27) } else {
//line :695:1
				full_len__30 = signed_len__27
			}

		var tmp10 any; var and__1927000168__auto____31 bool = lang.Numbers_Gt_O_O__Z(full_len__30, w__4); if and__1927000168__auto____31 { tmp10 = A_arbace_pprint_A_const_398.Invoke_O__O(params__0) } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____31).Ref() }; if jrt.A2g_Truth(tmp10) {
			lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(w__4, A_arbace_pprint_A_const_398.Invoke_O__O(params__0)))) } else {
				var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil, nil); var tmp13 any = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_O__Number(w__4, full_len__30), A_arbace_pprint_A_const_317.Invoke_O__O(params__0))); var tmp14 any

				if jrt.A2g_Truth(add_sign__17) { tmp14 = sign__10 } else { tmp14 = nil }
//line :700:1
				var tmp15 any = tmp14; var tmp16 *jrt.String


				if jrt.A2g_Truth(prepend_zero__28) { tmp16 = Lit_6 } else { tmp16 = nil }
//line :700:1
				var tmp17 any = tmp16.Ref(); var tmp18 *jrt.String




				if jrt.A2g_Truth(append_zero__29) { tmp18 = Lit_6 } else { tmp18 = nil }
//line :700:1
				tmp11.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp12, jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp17, fixed_repr__24, tmp18.Ref())).Ref()) } } else {





					var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil); var tmp21 any
					if jrt.A2g_Truth(add_sign__17) { tmp21 = sign__10 } else { tmp21 = nil }
//line :706:1
					var tmp22 any = tmp21; var tmp23 *jrt.String

					if prepend_zero__25 { tmp23 = Lit_6 } else { tmp23 = nil }
//line :706:1
					var tmp24 any = tmp23.Ref(); var tmp25 *jrt.String



					if jrt.A2g_Truth(append_zero__18) { tmp25 = Lit_6 } else { tmp25 = nil }
//line :706:1
					tmp19.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, fixed_repr__24, tmp25.Ref())).Ref()) }; return navigator__8 }









func A_arbace_pprint_exponential_float_A_New() *A_arbace_pprint_exponential_float_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_exponential_float_A{}; t.Ctor(); return t }
//line :716:1
func (t *A_arbace_pprint_exponential_float_A) Ctor() {}
//line :716:1
func (t *A_arbace_pprint_exponential_float_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000125__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000125__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000125__4, lang.RT_IntCast_J__I(1), nil); var arg__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_393.GetRawRoot__O()).Invoke_O__O(arg__5); var G__1819000131__8_ any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_394.GetRawRoot__O()); var tmp2 any; if


	lang.Numbers_IsNeg_O__Z(arg__7) { tmp2 = lang.Numbers_Minus_O__Number(arg__7) } else { tmp2 = arg__7 }; G__1819000131__8_ = tmp1.Invoke_O__O(tmp2); var vec__1819000132__9 any = G__1819000131__8_; var mantissa__10 any = /*line :716:1*/lang.RT_Nth_O_I_O__O(vec__1819000132__9, lang.RT_IntCast_J__I(0), nil); var exp__11 any = lang.RT_Nth_O_I_O__O(vec__1819000132__9, lang.RT_IntCast_J__I(1), nil); var G__1819000131__12_ any = G__1819000131__8_; _ = mantissa__10; _ = exp__11; L1: for { var vec__1819000135__13 any = G__1819000131__12_; var mantissa__14 any = lang.RT_Nth_O_I_O__O(vec__1819000135__13, lang.RT_IntCast_J__I(0), nil); var exp__15 any = lang.RT_Nth_O_I_O__O(vec__1819000135__13, lang.RT_IntCast_J__I(1), nil); var w__16 any = A_arbace_pprint_A_const_391.Invoke_O__O(params__0); var d__17 any = A_arbace_pprint_A_const_392.Invoke_O__O(params__0); var e__18 any = A_arbace_pprint_A_const_399.Invoke_O__O(params__0); var k__19 any = A_arbace_pprint_A_const_395.Invoke_O__O(params__0); var expchar__20 any; var or__1927000174__auto____20 any = A_arbace_pprint_A_const_400.Invoke_O__O(params__0)







		if jrt.A2g_Truth(or__1927000174__auto____20) { expchar__20 = or__1927000174__auto____20 } else { expchar__20 = A_arbace_pprint_A_const_401 }
//line :716:1
		var add_sign__21 any; var or__1927000174__auto____21 any = A_arbace_pprint_A_const_318.Invoke_O__O(params__0)








		if jrt.A2g_Truth(or__1927000174__auto____21) { add_sign__21 = or__1927000174__auto____21 } else { add_sign__21 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_O__Z(arg__7)).Ref() }
//line :716:1
		var prepend_zero__22 bool = lang.Numbers_Lte_O_J__Z(k__19, 0); var scaled_exp__23 any = lang.Numbers_Minus_O_O__Number(exp__15, lang.Numbers_Dec_O__Number(k__19)); var scaled_exp_str__24 any = lang.IFn_Cast(A_arbace_pprint_A_const_146.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(jrt.Math_Abs_I__I(lang.RT_IntCast_O__I(scaled_exp__23))).Ref()); var scaled_exp_str__25 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil); var tmp4 any












		if lang.Numbers_IsNeg_O__Z(scaled_exp__23) { tmp4 = A_arbace_pprint_A_const_402 } else { tmp4 = A_arbace_pprint_A_const_382 }; var tmp5 any = tmp4; var tmp6 any
		if jrt.A2g_Truth(e__18) { tmp6 = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(e__18, int64(lang.RT_Count_O__I(scaled_exp_str__24))), A_arbace_pprint_A_const_325)) } else { tmp6 = nil }
//line :729:1
		scaled_exp_str__25 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, expchar__20, tmp5, tmp6, scaled_exp_str__24)).Ref()
//line :716:1
		var exp_width__26 int32 = lang.RT_Count_O__I(scaled_exp_str__25); var base_mantissa_width__27 int32 = lang.RT_Count_O__I(mantissa__14); var scaled_mantissa__28 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp8 any = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O__Number(k__19), A_arbace_pprint_A_const_325)); var tmp9 any























		if jrt.A2g_Truth(d__17) {
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp11 any = A_arbace_pprint_A_const_146.GetRawRoot__O(); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()); var tmp13 any = lang.Numbers_Minus_O_J__Number(d__17, lang.Numbers_Dec_J__J(int64(base_mantissa_width__27))); var tmp14 any


			if lang.Numbers_IsNeg_O__Z(k__19) { tmp14 = lang.Numbers_Minus_O__Number(k__19) } else { tmp14 = A_arbace_pprint_A_const_28 }
//line :741:1
			tmp9 = tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(lang.Numbers_Minus_O_O__Number(tmp13, tmp14), A_arbace_pprint_A_const_325)) } else {
//line :740:1
				tmp9 = nil }
//line :738:1
		scaled_mantissa__28 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, mantissa__14, tmp9)).Ref()
//line :716:1
		var w_mantissa__29 any




























		if jrt.A2g_Truth(w__16) { w_mantissa__29 = lang.Numbers_Minus_O_J__Number(w__16, int64(exp_width__26)) } else { w_mantissa__29 = nil }
//line :716:1
		var vec__1819000138__30 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_396.GetRawRoot__O()); var tmp16 any = A_arbace_pprint_A_const_28; var tmp17 any































		if lang.Util_Equiv_O_J__Z(k__19, 0) {
			tmp17 = lang.Numbers_Dec_O__Number(d__17) } else {
//line :748:1
				if lang.Numbers_IsPos_O__Z(k__19) { tmp17 = d__17 } else { if lang.Numbers_IsNeg_O__Z(k__19) {


					tmp17 = lang.Numbers_Dec_O__Number(d__17) } else {
//line :748:1
						tmp17 = nil } } }
//line :746:1
		var tmp18 any = tmp17; var tmp19 jrt.Number_I





		if jrt.A2g_Truth(w_mantissa__29) {
			var tmp20 int64; if jrt.A2g_Truth(add_sign__21) { tmp20 = 1 } else { tmp20 = 0 }; tmp19 = lang.Numbers_Minus_O_J__Number(w_mantissa__29, tmp20) } else {
//line :752:1
				tmp19 = nil }
//line :746:1
		vec__1819000138__30 = tmp15.Invoke_O_O_O_O__O(scaled_mantissa__28, tmp16, tmp18, tmp19)
//line :716:1
		var rounded_mantissa__31 any = lang.RT_Nth_O_I_O__O(vec__1819000138__30, lang.RT_IntCast_J__I(0), nil); var ___32 any = lang.RT_Nth_O_I_O__O(vec__1819000138__30, lang.RT_IntCast_J__I(1), nil); var incr_exp__33 any = lang.RT_Nth_O_I_O__O(vec__1819000138__30, lang.RT_IntCast_J__I(2), nil); var full_mantissa__34 any = lang.IFn_Cast(A_arbace_pprint_A_const_403.GetRawRoot__O()).Invoke_O_O__O(rounded_mantissa__31, k__19); var append_zero__35 bool; var and__1927000168__auto____35 bool = lang.Util_Equiv_O_J__Z(k__19, int64(lang.RT_Count_O__I(rounded_mantissa__31))); _ = ___32






































		if and__1927000168__auto____35 { append_zero__35 = lang.Util_Identical_O_O__Z(d__17, nil) } else { append_zero__35 = and__1927000168__auto____35 }
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(incr_exp__33)) {
			if jrt.A2g_Truth(w__16) { var len__36 int64 = lang.Numbers_Add_J_J__J(int64(lang.RT_Count_O__I(full_mantissa__34)), int64(exp_width__26)); var signed_len__37 int64

				if jrt.A2g_Truth(add_sign__21) { signed_len__37 = lang.Numbers_Inc_J__J(len__36) } else { signed_len__37 = len__36 }
//line :757:1
				var prepend_zero__38 any
				var and__1927000168__auto____38 bool = prepend_zero__22

				if and__1927000168__auto____38 { prepend_zero__38 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_O__Z(signed_len__37, w__16)).Ref()) } else { prepend_zero__38 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____38).Ref() }
//line :757:1
				var full_len__39 int64



				if jrt.A2g_Truth(prepend_zero__38) { full_len__39 = lang.Numbers_Inc_J__J(signed_len__37) } else { full_len__39 = signed_len__37 }
//line :757:1
				var append_zero__40 bool
				var and__1927000168__auto____40 bool = append_zero__35



				if and__1927000168__auto____40 { append_zero__40 = lang.Numbers_Lt_J_O__Z(full_len__39, w__16) } else { append_zero__40 = and__1927000168__auto____40 }
				var tmp21 any; var and__1927000168__auto____41 any; var or__1927000174__auto____41 bool = lang.Numbers_Gt_J_O__Z(full_len__39, w__16); if or__1927000174__auto____41 { and__1927000168__auto____41 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____41).Ref() } else { var and__1927000168__auto____42 any = e__18; if jrt.A2g_Truth(and__1927000168__auto____42) { and__1927000168__auto____41 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.Numbers_Minus_J_J__J(int64(exp_width__26), 2), e__18)).Ref() } else { and__1927000168__auto____41 = and__1927000168__auto____42 } }; if jrt.A2g_Truth(and__1927000168__auto____41) {
					tmp21 = A_arbace_pprint_A_const_398.Invoke_O__O(params__0) } else {
//line :763:1
						tmp21 = and__1927000168__auto____41 }; if jrt.A2g_Truth(tmp21) {

							lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(w__16, A_arbace_pprint_A_const_398.Invoke_O__O(params__0)))) } else {
								var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil, nil, nil); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp25 any = A_arbace_pprint_A_const_146.GetRawRoot__O(); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()); var tmp27 any = lang.Numbers_Minus_O_J__Number(w__16, full_len__39); var tmp28 int64


								if append_zero__40 { tmp28 = 1 } else { tmp28 = 0 }
//line :766:1
								var tmp29 any = tmp24.Invoke_O_O__O(tmp25, tmp26.Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(tmp27, tmp28), A_arbace_pprint_A_const_317.Invoke_O__O(params__0))); var tmp30 any




								if jrt.A2g_Truth(add_sign__21) { if lang.Numbers_IsNeg_O__Z(arg__7) { tmp30 = A_arbace_pprint_A_const_402 } else { tmp30 = A_arbace_pprint_A_const_382 } } else { tmp30 = nil }
//line :766:1
								var tmp31 any = tmp30; var tmp32 *jrt.String





								if jrt.A2g_Truth(prepend_zero__38) { tmp32 = Lit_6 } else { tmp32 = nil }
//line :766:1
								var tmp33 any = tmp32.Ref(); var tmp34 *jrt.String







								if append_zero__40 { tmp34 = Lit_6 } else { tmp34 = nil }
//line :766:1
								tmp22.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp23, jrt.RefArrayOf(jrt.Object_class, tmp29, tmp31, tmp33, full_mantissa__34, tmp34.Ref(), scaled_exp_str__25)).Ref()) } } else {









									var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp36 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil, nil); var tmp37 any
									if jrt.A2g_Truth(add_sign__21) { if lang.Numbers_IsNeg_O__Z(arg__7) { tmp37 = A_arbace_pprint_A_const_402 } else { tmp37 = A_arbace_pprint_A_const_382 } } else { tmp37 = nil }
//line :776:1
									var tmp38 any = tmp37; var tmp39 *jrt.String

									if prepend_zero__22 { tmp39 = Lit_6 } else { tmp39 = nil }
//line :776:1
									var tmp40 any = tmp39.Ref(); var tmp41 *jrt.String



									if append_zero__35 { tmp41 = Lit_6 } else { tmp41 = nil }
//line :776:1
									tmp35.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp36, jrt.RefArrayOf(jrt.Object_class, tmp38, tmp40, full_mantissa__34, tmp41.Ref(), scaled_exp_str__25)).Ref()) } } else {





										G__1819000131__12_ = lang.Tuple_Create_O_O__IPersistentVector(rounded_mantissa__31, lang.Numbers_Inc_O__Number(exp__15)); continue L1 }
//line :716:1
		break L1 }; return navigator__6 }









































































func A_arbace_pprint_general_float_A_New() *A_arbace_pprint_general_float_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_general_float_A{}; t.Ctor(); return t }
//line :790:1
func (t *A_arbace_pprint_general_float_A) Ctor() {}
//line :790:1
func (t *A_arbace_pprint_general_float_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000142__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000142__4, lang.RT_IntCast_J__I(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O(vec__1819000142__4, lang.RT_IntCast_J__I(1), nil); var arg__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_393.GetRawRoot__O()).Invoke_O__O(arg__5); var vec__1819000145__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_394.GetRawRoot__O()); var tmp2 any; _ = ___6; if


	lang.Numbers_IsNeg_O__Z(arg__7) { tmp2 = lang.Numbers_Minus_O__Number(arg__7) } else { tmp2 = arg__7 }; vec__1819000145__8 = tmp1.Invoke_O__O(tmp2); var mantissa__9 any = /*line :790:1*/lang.RT_Nth_O_I_O__O(vec__1819000145__8, lang.RT_IntCast_J__I(0), nil); var exp__10 any = lang.RT_Nth_O_I_O__O(vec__1819000145__8, lang.RT_IntCast_J__I(1), nil); var w__11 any = A_arbace_pprint_A_const_391.Invoke_O__O(params__0); var d__12 any = A_arbace_pprint_A_const_392.Invoke_O__O(params__0); var e__13 any = A_arbace_pprint_A_const_399.Invoke_O__O(params__0); var n__14 any; if






	lang.Util_Equiv_O_D__Z(arg__7, 0.0) { n__14 = A_arbace_pprint_A_const_28 } else { n__14 = lang.Numbers_Inc_O__Number(exp__10) }; var ee__15 any; if
	jrt.A2g_Truth(e__13) { ee__15 = lang.Numbers_Add_O_J__Number(e__13, 2) } else { ee__15 = A_arbace_pprint_A_const_404 }; var ww__16 any; if
	jrt.A2g_Truth(w__11) { ww__16 = lang.Numbers_Minus_O_O__Number(w__11, ee__15) } else { ww__16 = nil }; var d__17 any; if
	jrt.A2g_Truth(d__12) { d__17 = d__12 } else { d__17 = lang.Numbers_Max_J_O__O(int64(lang.RT_Count_O__I(mantissa__9)), lang.Numbers_Min_O_J__O(n__14, 7)) }; var dd__18 any = /*line :790:1*/lang.Numbers_Minus_O_O__Number(d__17, n__14); if











	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_405.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_28, dd__18, d__17)) { var tmp3 any = A_arbace_pprint_A_const_391; var tmp4 any = A_arbace_pprint_A_const_392; var tmp5 any = A_arbace_pprint_A_const_395; var tmp6 any = A_arbace_pprint_A_const_28; var tmp7 any = A_arbace_pprint_A_const_398; var tmp8 any = A_arbace_pprint_A_const_398.Invoke_O__O(params__0); var tmp9 any = A_arbace_pprint_A_const_317; var tmp10 any = A_arbace_pprint_A_const_317.Invoke_O__O(params__0); var tmp11 any = A_arbace_pprint_A_const_318; var navigator__19 any = lang.IFn_Cast(A_arbace_pprint_A_const_406.GetRawRoot__O()).Invoke_O_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, ww__16, tmp4, dd__18, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, A_arbace_pprint_A_const_318.Invoke_O__O(params__0))), navigator__1, offsets__2)




		lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(ee__15, A_arbace_pprint_A_const_148)))
//line :802:1
		return navigator__19 } else {






			return lang.IFn_Cast(A_arbace_pprint_A_const_407.GetRawRoot__O()).Invoke_O_O_O__O(params__0, navigator__1, offsets__2) } }



func A_arbace_pprint_dollar_float_A_New() *A_arbace_pprint_dollar_float_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_dollar_float_A{}; t.Ctor(); return t }
//line :813:1
func (t *A_arbace_pprint_dollar_float_A) Ctor() {}
//line :813:1
func (t *A_arbace_pprint_dollar_float_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000149__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000149__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000149__4, lang.RT_IntCast_J__I(1), nil); var vec__1819000152__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_394.GetRawRoot__O()).Invoke_O__O(jrt.Double_ValueOf_D__Double(jrt.Math_Abs_D__D(lang.RT_DoubleCast_O__D(arg__5))).Ref()); var mantissa__8 any = lang.RT_Nth_O_I_O__O(vec__1819000152__7, lang.RT_IntCast_J__I(0), nil); var exp__9 any = lang.RT_Nth_O_I_O__O(vec__1819000152__7, lang.RT_IntCast_J__I(1), nil); var d__10 any = A_arbace_pprint_A_const_392.Invoke_O__O(params__0); var n__11 any = A_arbace_pprint_A_const_408.Invoke_O__O(params__0); var w__12 any = A_arbace_pprint_A_const_391.Invoke_O__O(params__0); var add_sign__13 any; var or__1927000174__auto____13 any = A_arbace_pprint_A_const_318.Invoke_O__O(params__0); if





	jrt.A2g_Truth(or__1927000174__auto____13) { add_sign__13 = or__1927000174__auto____13 } else { add_sign__13 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_O__Z(arg__5)).Ref() }; var vec__1819000155__14 any = /*line :813:1*/lang.IFn_Cast(A_arbace_pprint_A_const_396.GetRawRoot__O()).Invoke_O_O_O_O__O(mantissa__8, exp__9, d__10, nil); var rounded_mantissa__15 any = lang.RT_Nth_O_I_O__O(vec__1819000155__14, lang.RT_IntCast_J__I(0), nil); var scaled_exp__16 any = lang.RT_Nth_O_I_O__O(vec__1819000155__14, lang.RT_IntCast_J__I(1), nil); var expanded__17 any = lang.RT_Nth_O_I_O__O(vec__1819000155__14, lang.RT_IntCast_J__I(2), nil); var fixed_repr__18 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_397.GetRawRoot__O()); var tmp2 any; if







	jrt.A2g_Truth(expanded__17) { tmp2 = lang.Numbers_Inc_O__Number(scaled_exp__16) } else { tmp2 = scaled_exp__16 }; fixed_repr__18 = tmp1.Invoke_O_O_O__O(rounded_mantissa__15, tmp2, d__10); var full_repr__19 any = /*line :813:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(n__11, int64(jrt.NN(jrt.String_Cast(fixed_repr__18)).IndexOf_I__I(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_378)))), A_arbace_pprint_A_const_325)), fixed_repr__18)).Ref(); var full_len__20 int64; var tmp3 int64 = int64(lang.RT_Count_O__I(full_repr__19)); var tmp4 int64; if









	jrt.A2g_Truth(add_sign__13) { tmp4 = 1 } else { tmp4 = 0 }; full_len__20 = lang.Numbers_Add_J_J__J(tmp3, tmp4); var tmp5 lang.IFn =
	lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil); var tmp7 any; var tmp8 any; var and__1927000168__auto____25 any = A_arbace_pprint_A_const_332.Invoke_O__O(params__0); if
	jrt.A2g_Truth(and__1927000168__auto____25) { tmp8 = add_sign__13 } else { tmp8 = and__1927000168__auto____25 }; if jrt.A2g_Truth(tmp8) { if lang.Numbers_IsNeg_O__Z(arg__5) { tmp7 = A_arbace_pprint_A_const_402 } else { tmp7 = A_arbace_pprint_A_const_382 } } else { tmp7 = nil }; var tmp9 any = tmp7; var tmp10 any = /*line :824:1*/lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(w__12, full_len__20), A_arbace_pprint_A_const_317.Invoke_O__O(params__0))); var tmp11 any; var tmp12 any; var and__1927000168__auto____25_2 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)); if


	jrt.A2g_Truth(and__1927000168__auto____25_2) { tmp12 = add_sign__13 } else { tmp12 = and__1927000168__auto____25_2 }; if jrt.A2g_Truth(tmp12) { if lang.Numbers_IsNeg_O__Z(arg__5) { tmp11 = A_arbace_pprint_A_const_402 } else { tmp11 = A_arbace_pprint_A_const_382 } } else { tmp11 = nil }; /*line :824:1*/tmp5.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, full_repr__19)).Ref()); return navigator__6 }














func A_arbace_pprint_choice_conditional_A_New() *A_arbace_pprint_choice_conditional_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_choice_conditional_A{}; t.Ctor(); return t }
//line :839:1
func (t *A_arbace_pprint_choice_conditional_A) Ctor() {}
//line :839:1
func (t *A_arbace_pprint_choice_conditional_A) Invoke_O_O_O_O__O(self, params__0, arg_navigator__1, offsets__2 any) any { var arg__4 any = A_arbace_pprint_A_const_409.Invoke_O__O(params__0); var vec__1819000159__5 any; if

	jrt.A2g_Truth(arg__4) { vec__1819000159__5 = lang.Tuple_Create_O_O__IPersistentVector(arg__4, arg_navigator__1) } else { vec__1819000159__5 = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(arg_navigator__1) }; var arg__6 any = /*line :839:1*/lang.RT_Nth_O_I_O__O(vec__1819000159__5, lang.RT_IntCast_J__I(0), nil); var navigator__7 any = lang.RT_Nth_O_I_O__O(vec__1819000159__5, lang.RT_IntCast_J__I(1), nil); var clauses__8 any = A_arbace_pprint_A_const_410.Invoke_O__O(params__0); var clause__9 any; var tmp1 bool; var or__1927000174__auto____9 bool = lang.Numbers_IsNeg_O__Z(arg__6); if or__1927000174__auto____9 {



		tmp1 = or__1927000174__auto____9 } else { tmp1 = lang.Numbers_Gte_O_J__Z(arg__6, int64(lang.RT_Count_O__I(clauses__8))) }; if tmp1 {
			clause__9 = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_95.Invoke_O__O(params__0)) } else {
				clause__9 = lang.RT_Nth_O_I__O(clauses__8, lang.RT_IntCast_O__I(arg__6)) }; if
	jrt.A2g_Truth(clause__9) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(clause__9, navigator__7, A_arbace_pprint_A_const_375.Invoke_O__O(params__0)) } else {
//line :846:1
			return navigator__7 } }




func A_arbace_pprint_boolean_conditional_A_New() *A_arbace_pprint_boolean_conditional_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_boolean_conditional_A{}; t.Ctor(); return t }
//line :851:1
func (t *A_arbace_pprint_boolean_conditional_A) Ctor() {}
//line :851:1
func (t *A_arbace_pprint_boolean_conditional_A) Invoke_O_O_O_O__O(self, params__0, arg_navigator__1, offsets__2 any) any { var vec__1819000163__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(arg_navigator__1); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000163__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000163__4, lang.RT_IntCast_J__I(1), nil); var clauses__7 any = A_arbace_pprint_A_const_410.Invoke_O__O(params__0); var clause__8 any; if


	jrt.A2g_Truth(arg__5) {
		clause__8 = lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(clauses__7) } else {
			clause__8 = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(clauses__7) }; if
	jrt.A2g_Truth(clause__8) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(clause__8, navigator__6, A_arbace_pprint_A_const_375.Invoke_O__O(params__0)) } else {
//line :857:1
			return navigator__6 } }





func A_arbace_pprint_check_arg_conditional_A_New() *A_arbace_pprint_check_arg_conditional_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_check_arg_conditional_A{}; t.Ctor(); return t }
//line :863:1
func (t *A_arbace_pprint_check_arg_conditional_A) Ctor() {}
//line :863:1
func (t *A_arbace_pprint_check_arg_conditional_A) Invoke_O_O_O_O__O(self, params__0, arg_navigator__1, offsets__2 any) any { var vec__1819000167__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(arg_navigator__1); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000167__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000167__4, lang.RT_IntCast_J__I(1), nil); var clauses__7 any = A_arbace_pprint_A_const_410.Invoke_O__O(params__0); var clause__8 any; if


	jrt.A2g_Truth(arg__5) { clause__8 = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(clauses__7) } else { clause__8 = nil }; if
	jrt.A2g_Truth(arg__5) {
		if jrt.A2g_Truth(clause__8) {
			return lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(clause__8, arg_navigator__1, A_arbace_pprint_A_const_375.Invoke_O__O(params__0)) } else {
//line :868:1
				return arg_navigator__1 } } else {
//line :867:1
					return navigator__6 } }












func A_arbace_pprint_iterate_sublist_A_New() *A_arbace_pprint_iterate_sublist_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_iterate_sublist_A{}; t.Ctor(); return t }
//line :880:1
func (t *A_arbace_pprint_iterate_sublist_A) Ctor() {}
//line :880:1
func (t *A_arbace_pprint_iterate_sublist_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { { var max_count__4 any = A_arbace_pprint_A_const_412.Invoke_O__O(params__0); var param_clause__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_410.Invoke_O__O(params__0)); var vec__1819000171__6 any


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(param_clause__5)) {
		vec__1819000171__6 = lang.IFn_Cast(A_arbace_pprint_A_const_413.GetRawRoot__O()).Invoke_O__O(navigator__1) } else {
//line :883:1
			vec__1819000171__6 = lang.Tuple_Create_O_O__IPersistentVector(param_clause__5, navigator__1) }
//line :880:1
	var clause__7 any = lang.RT_Nth_O_I_O__O(vec__1819000171__6, lang.RT_IntCast_J__I(0), nil); var navigator__8 any = lang.RT_Nth_O_I_O__O(vec__1819000171__6, lang.RT_IntCast_J__I(1), nil); var vec__1819000174__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__8); var arg_list__10 any = lang.RT_Nth_O_I_O__O(vec__1819000174__9, lang.RT_IntCast_J__I(0), nil); var navigator__11 any = lang.RT_Nth_O_I_O__O(vec__1819000174__9, lang.RT_IntCast_J__I(1), nil); var args__12 any = lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(arg_list__10); var count__13 int64 = 0; var args__14 any = args__12; var last_pos__15 any = lang.Numbers_Num_J__Number(-1); L1: for {










		var tmp1 any; var and__1927000168__auto____16 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(max_count__4); if jrt.A2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool = lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_163.Invoke_O__O(args__14), last_pos__15); if and__1927000168__auto____17 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(count__13, 1)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____17).Ref() } } else { tmp1 = and__1927000168__auto____16 }; if jrt.A2g_Truth(tmp1) { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_126)))
		}

		var tmp2 any; var or__1927000174__auto____16 any; var and__1927000168__auto____16_2 any = lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_300.Invoke_O__O(args__14)); if jrt.A2g_Truth(and__1927000168__auto____16_2) { var tmp3 *lang.Keyword = A_arbace_pprint_A_const_332; var or__1927000174__auto____17 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_pprint_A_const_414.Invoke_O__O(params__0)))
			if jrt.A2g_Truth(or__1927000174__auto____17) { or__1927000174__auto____16 = or__1927000174__auto____17 } else { or__1927000174__auto____16 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(count__13, 0)).Ref() } } else {
//line :894:1
				or__1927000174__auto____16 = and__1927000168__auto____16_2 }; if jrt.A2g_Truth(or__1927000174__auto____16) { tmp2 = or__1927000174__auto____16 } else { var and__1927000168__auto____17_2 any = max_count__4

					if jrt.A2g_Truth(and__1927000168__auto____17_2) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_O__Z(count__13, max_count__4)).Ref() } else { tmp2 = and__1927000168__auto____17_2 } }
//line :894:1
		if jrt.A2g_Truth(tmp2) { return navigator__11 } else { var iter_result__16 any = lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(clause__7, args__14, A_arbace_pprint_A_const_375.Invoke_O__O(params__0))
			var tmp4 any = A_arbace_pprint_A_const_368



			if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(iter_result__16)) { return navigator__11 } else {

				count__13, args__14, last_pos__15 = lang.Numbers_Inc_J__J(count__13), iter_result__16, A_arbace_pprint_A_const_163.Invoke_O__O(args__14); continue L1 } } } }; /*line :880:1*/panic("a2g: unreachable") }
























func A_arbace_pprint_iterate_list_of_sublists_A_New() *A_arbace_pprint_iterate_list_of_sublists_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_iterate_list_of_sublists_A{}; t.Ctor(); return t }
//line :905:1
func (t *A_arbace_pprint_iterate_list_of_sublists_A) Ctor() {}
//line :905:1
func (t *A_arbace_pprint_iterate_list_of_sublists_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { { var max_count__4 any = A_arbace_pprint_A_const_412.Invoke_O__O(params__0); var param_clause__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_410.Invoke_O__O(params__0)); var vec__1819000178__6 any


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(param_clause__5)) {
		vec__1819000178__6 = lang.IFn_Cast(A_arbace_pprint_A_const_413.GetRawRoot__O()).Invoke_O__O(navigator__1) } else {
//line :908:1
			vec__1819000178__6 = lang.Tuple_Create_O_O__IPersistentVector(param_clause__5, navigator__1) }
//line :905:1
	var clause__7 any = lang.RT_Nth_O_I_O__O(vec__1819000178__6, lang.RT_IntCast_J__I(0), nil); var navigator__8 any = lang.RT_Nth_O_I_O__O(vec__1819000178__6, lang.RT_IntCast_J__I(1), nil); var vec__1819000181__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__8); var arg_list__10 any = lang.RT_Nth_O_I_O__O(vec__1819000181__9, lang.RT_IntCast_J__I(0), nil); var navigator__11 any = lang.RT_Nth_O_I_O__O(vec__1819000181__9, lang.RT_IntCast_J__I(1), nil); var count__12 int64 = 0; var arg_list__13 any = arg_list__10; L1: for {








		var tmp1 any; var or__1927000174__auto____14 any; var and__1927000168__auto____14 any = lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(arg_list__13); if jrt.A2g_Truth(and__1927000168__auto____14) { var tmp2 *lang.Keyword = A_arbace_pprint_A_const_332; var or__1927000174__auto____15 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_pprint_A_const_414.Invoke_O__O(params__0)))
			if jrt.A2g_Truth(or__1927000174__auto____15) { or__1927000174__auto____14 = or__1927000174__auto____15 } else { or__1927000174__auto____14 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(count__12, 0)).Ref() } } else {
//line :914:1
				or__1927000174__auto____14 = and__1927000168__auto____14 }; if jrt.A2g_Truth(or__1927000174__auto____14) { tmp1 = or__1927000174__auto____14 } else { var and__1927000168__auto____15 any = max_count__4

					if jrt.A2g_Truth(and__1927000168__auto____15) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_O__Z(count__12, max_count__4)).Ref() } else { tmp1 = and__1927000168__auto____15 } }
//line :914:1
		if jrt.A2g_Truth(tmp1) { return navigator__11 } else { var iter_result__14 any = lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(clause__7, lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(arg_list__13)), lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(arg_list__13)))
			var tmp3 any = A_arbace_pprint_A_const_369






			if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(iter_result__14)) { return navigator__11 } else {

				count__12, arg_list__13 = lang.Numbers_Inc_J__J(count__12), lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(arg_list__13); continue L1 } } } }; /*line :905:1*/panic("a2g: unreachable") }






















func A_arbace_pprint_iterate_main_list_A_New() *A_arbace_pprint_iterate_main_list_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_iterate_main_list_A{}; t.Ctor(); return t }
//line :928:1
func (t *A_arbace_pprint_iterate_main_list_A) Ctor() {}
//line :928:1
func (t *A_arbace_pprint_iterate_main_list_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { { var max_count__4 any = A_arbace_pprint_A_const_412.Invoke_O__O(params__0); var param_clause__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_410.Invoke_O__O(params__0)); var vec__1819000185__6 any


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(param_clause__5)) {
		vec__1819000185__6 = lang.IFn_Cast(A_arbace_pprint_A_const_413.GetRawRoot__O()).Invoke_O__O(navigator__1) } else {
//line :931:1
			vec__1819000185__6 = lang.Tuple_Create_O_O__IPersistentVector(param_clause__5, navigator__1) }
//line :928:1
	var clause__7 any = lang.RT_Nth_O_I_O__O(vec__1819000185__6, lang.RT_IntCast_J__I(0), nil); var navigator__8 any = lang.RT_Nth_O_I_O__O(vec__1819000185__6, lang.RT_IntCast_J__I(1), nil); var count__9 int64 = 0; var navigator__10 any = navigator__8; var last_pos__11 any = lang.Numbers_Num_J__Number(-1); L1: for {








		var tmp1 any; var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(max_count__4); if jrt.A2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_163.Invoke_O__O(navigator__10), last_pos__11); if and__1927000168__auto____13 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(count__9, 1)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13).Ref() } } else { tmp1 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp1) { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_125)))
		}

		var tmp2 any; var or__1927000174__auto____12 any; var and__1927000168__auto____12_2 any = lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_300.Invoke_O__O(navigator__10)); if jrt.A2g_Truth(and__1927000168__auto____12_2) { var tmp3 *lang.Keyword = A_arbace_pprint_A_const_332; var or__1927000174__auto____13 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_pprint_A_const_414.Invoke_O__O(params__0)))
			if jrt.A2g_Truth(or__1927000174__auto____13) { or__1927000174__auto____12 = or__1927000174__auto____13 } else { or__1927000174__auto____12 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(count__9, 0)).Ref() } } else {
//line :940:1
				or__1927000174__auto____12 = and__1927000168__auto____12_2 }; if jrt.A2g_Truth(or__1927000174__auto____12) { tmp2 = or__1927000174__auto____12 } else { var and__1927000168__auto____13_2 any = max_count__4

					if jrt.A2g_Truth(and__1927000168__auto____13_2) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_O__Z(count__9, max_count__4)).Ref() } else { tmp2 = and__1927000168__auto____13_2 } }
//line :940:1
		if jrt.A2g_Truth(tmp2) { return navigator__10 } else { var iter_result__12 any = lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(clause__7, navigator__10, A_arbace_pprint_A_const_375.Invoke_O__O(params__0))
			var tmp4 any = A_arbace_pprint_A_const_368



			if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(iter_result__12)) {
				return lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(iter_result__12) } else {
					count__9, navigator__10, last_pos__11 = lang.Numbers_Inc_J__J(count__9), iter_result__12, A_arbace_pprint_A_const_163.Invoke_O__O(navigator__10); continue L1 } } } }; /*line :928:1*/panic("a2g: unreachable") }























func A_arbace_pprint_iterate_main_sublists_A_New() *A_arbace_pprint_iterate_main_sublists_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_iterate_main_sublists_A{}; t.Ctor(); return t }
//line :952:1
func (t *A_arbace_pprint_iterate_main_sublists_A) Ctor() {}
//line :952:1
func (t *A_arbace_pprint_iterate_main_sublists_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { { var max_count__4 any = A_arbace_pprint_A_const_412.Invoke_O__O(params__0); var param_clause__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_410.Invoke_O__O(params__0)); var vec__1819000189__6 any


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(param_clause__5)) {
		vec__1819000189__6 = lang.IFn_Cast(A_arbace_pprint_A_const_413.GetRawRoot__O()).Invoke_O__O(navigator__1) } else {
//line :955:1
			vec__1819000189__6 = lang.Tuple_Create_O_O__IPersistentVector(param_clause__5, navigator__1) }
//line :952:1
	var clause__7 any = lang.RT_Nth_O_I_O__O(vec__1819000189__6, lang.RT_IntCast_J__I(0), nil); var navigator__8 any = lang.RT_Nth_O_I_O__O(vec__1819000189__6, lang.RT_IntCast_J__I(1), nil); var count__9 int64 = 0; var navigator__10 any = navigator__8; L1: for {








		var tmp1 any; var or__1927000174__auto____11 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_300.Invoke_O__O(navigator__10)); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp2 *lang.Keyword = A_arbace_pprint_A_const_332; var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_pprint_A_const_414.Invoke_O__O(params__0)))
			if jrt.A2g_Truth(or__1927000174__auto____12) { or__1927000174__auto____11 = or__1927000174__auto____12 } else { or__1927000174__auto____11 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(count__9, 0)).Ref() } } else {
//line :961:1
				or__1927000174__auto____11 = and__1927000168__auto____11 }; if jrt.A2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else { var and__1927000168__auto____12 any = max_count__4

					if jrt.A2g_Truth(and__1927000168__auto____12) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_O__Z(count__9, max_count__4)).Ref() } else { tmp1 = and__1927000168__auto____12 } }
//line :961:1
		if jrt.A2g_Truth(tmp1) { return navigator__10 } else { var vec__1819000192__11 any = lang.IFn_Cast(A_arbace_pprint_A_const_415.GetRawRoot__O()).Invoke_O__O(navigator__10); var sublist__12 any = lang.RT_Nth_O_I_O__O(vec__1819000192__11, lang.RT_IntCast_J__I(0), nil); var navigator__13 any = lang.RT_Nth_O_I_O__O(vec__1819000192__11, lang.RT_IntCast_J__I(1), nil); var iter_result__14 any = lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(clause__7, lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(sublist__12), navigator__13)
			var tmp3 any = A_arbace_pprint_A_const_369




			if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(iter_result__14)) { return navigator__13 } else {

				count__9, navigator__10 = lang.Numbers_Inc_J__J(count__9), navigator__13; continue L1 } } } }; /*line :952:1*/panic("a2g: unreachable") }


































func A_arbace_pprint_logical_block_or_justify_A_New() *A_arbace_pprint_logical_block_or_justify_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_logical_block_or_justify_A{}; t.Ctor(); return t }
//line :987:1
func (t *A_arbace_pprint_logical_block_or_justify_A) Ctor() {}
//line :987:1
func (t *A_arbace_pprint_logical_block_or_justify_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any {
	var tmp1 *lang.Keyword = A_arbace_pprint_A_const_332; if jrt.A2g_Truth(tmp1.Invoke_O__O(A_arbace_pprint_A_const_414.Invoke_O__O(params__0))) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_416.GetRawRoot__O()).Invoke_O_O_O__O(params__0, navigator__1, offsets__2) } else {
			return lang.IFn_Cast(A_arbace_pprint_A_const_417.GetRawRoot__O()).Invoke_O_O_O__O(params__0, navigator__1, offsets__2)
		}
}



func A_arbace_pprint_render_clauses_A_New() *A_arbace_pprint_render_clauses_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_render_clauses_A{}; t.Ctor(); return t }
//line :996:1
func (t *A_arbace_pprint_render_clauses_A) Ctor() {}
//line :996:1
func (t *A_arbace_pprint_render_clauses_A) Invoke_O_O_O_O__O(self, clauses__0, navigator__1, base_navigator__2 any) any { { var clauses__4 any = clauses__0; var acc__5 any; lang.PersistentVector_Init(); acc__5 = lang.PersistentVector_EMPTY.Ref(); var navigator__6 any = navigator__1; L1: for {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(clauses__4)) { return lang.Tuple_Create_O_O__IPersistentVector(acc__5, navigator__6) } else { var clause__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(clauses__4); var vec__1819000197__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O())
		var tmp2 any = A_arbace_pprint_A_const_34

		lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.StringWriter_New())); var tmp3 any = A_arbace_pprint_render_clauses_fn__1819000200_A_New_O_O_O(base_navigator__2, clause__7, navigator__6); var tmp4 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_pprint_render_clauses_fn__1819000200_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_246, false); A_arbace_pprint_render_clauses_fn__1819000200_A_fn_class = fncls__56d; tmp4 = fncls__56d } else { tmp4 = fncls__56 }; vec__1819000197__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :1000:1
		var iter_result__9 any = lang.RT_Nth_O_I_O__O(vec__1819000197__8, lang.RT_IntCast_J__I(0), nil); var result_str__10 any = lang.RT_Nth_O_I_O__O(vec__1819000197__8, lang.RT_IntCast_J__I(1), nil)
		var tmp5 any = A_arbace_pprint_A_const_368




		if lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(iter_result__9)) { return lang.Tuple_Create_O_O__IPersistentVector(acc__5, lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(iter_result__9)) } else {

			clauses__4, acc__5, navigator__6 = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(clauses__4), lang.IFn_Cast(A_arbace_pprint_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__5, result_str__10), iter_result__9; continue L1 } } } }; /*line :996:1*/panic("a2g: unreachable") }






func A_arbace_pprint_render_clauses_fn__1819000200_A_New_O_O_O(p0, p1, p2 any) *A_arbace_pprint_render_clauses_fn__1819000200_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_render_clauses_fn__1819000200_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1003:1
func (t *A_arbace_pprint_render_clauses_fn__1819000200_A) Ctor_O_O_O(c__base_navigator, c__clause, c__navigator any) { t.F_base_navigator = c__base_navigator; t.F_clause = c__clause; t.F_navigator = c__navigator }
//line :1003:1
func (t *A_arbace_pprint_render_clauses_fn__1819000200_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_clause
											t.F_clause = nil; tmp3 = t_
//line :1003:1
	var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_navigator
	t.F_navigator = nil; tmp5 = t__2
//line :1003:1
	var tmp6 any = tmp5; var tmp7 any; var t__3 any = t.F_base_navigator
	t.F_base_navigator = nil; tmp7 = t__3
//line :1003:1
	tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp2.Invoke_O_O_O__O(tmp4, tmp6, tmp7), jrt.ToString(A_arbace_pprint_A_const_34.Get__O()).Ref()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }







func A_arbace_pprint_justify_clauses_A_New() *A_arbace_pprint_justify_clauses_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_justify_clauses_A{}; t.Ctor(); return t }
//line :1011:1
func (t *A_arbace_pprint_justify_clauses_A) Ctor() {}
//line :1011:1
func (t *A_arbace_pprint_justify_clauses_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var vec__1819000203__4 any; var temp__1927000414__auto____4 any = A_arbace_pprint_A_const_95.Invoke_O__O(params__0); if
															jrt.A2g_Truth(temp__1927000414__auto____4) { var else__5 any = temp__1927000414__auto____4
																vec__1819000203__4 = lang.IFn_Cast(A_arbace_pprint_A_const_418.GetRawRoot__O()).Invoke_O_O_O__O(else__5, navigator__1, A_arbace_pprint_A_const_375.Invoke_O__O(params__0)) } else {
//line :1012:1
			vec__1819000203__4 = nil }; var vec__1819000206__5 any = /*line :1011:1*/lang.RT_Nth_O_I_O__O(vec__1819000203__4, lang.RT_IntCast_J__I(0), nil); var eol_str__6 any = lang.RT_Nth_O_I_O__O(vec__1819000206__5, lang.RT_IntCast_J__I(0), nil); var new_navigator__7 any = lang.RT_Nth_O_I_O__O(vec__1819000203__4, lang.RT_IntCast_J__I(1), nil); var navigator__8 any; var or__1927000174__auto____8 any = new_navigator__7; if


	jrt.A2g_Truth(or__1927000174__auto____8) { navigator__8 = or__1927000174__auto____8 } else { navigator__8 = navigator__1 }; var vec__1819000209__9 any; var temp__1927000414__auto____9 any = /*line :1011:1*/A_arbace_pprint_A_const_419.Invoke_O__O(params__0); if



	jrt.A2g_Truth(temp__1927000414__auto____9) { var p__10 any = temp__1927000414__auto____9
		vec__1819000209__9 = lang.IFn_Cast(A_arbace_pprint_A_const_372.GetRawRoot__O()).Invoke_O_O__O(p__10, navigator__8) } else {
//line :1015:1
			vec__1819000209__9 = nil }; var else_params__10 any = /*line :1011:1*/lang.RT_Nth_O_I_O__O(vec__1819000209__9, lang.RT_IntCast_J__I(0), nil); var new_navigator__11 any = lang.RT_Nth_O_I_O__O(vec__1819000209__9, lang.RT_IntCast_J__I(1), nil); var navigator__12 any; var or__1927000174__auto____12 any = new_navigator__11; if





	jrt.A2g_Truth(or__1927000174__auto____12) { navigator__12 = or__1927000174__auto____12 } else { navigator__12 = navigator__8 }; var min_remaining__13 any; var or__1927000174__auto____13 any = /*line :1011:1*/lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_421.Invoke_O__O(else_params__10)); if






	jrt.A2g_Truth(or__1927000174__auto____13) { min_remaining__13 = or__1927000174__auto____13 } else { min_remaining__13 = A_arbace_pprint_A_const_28 }; var max_columns__14 any; var or__1927000174__auto____14 any = /*line :1011:1*/lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_422.Invoke_O__O(else_params__10)); if







	jrt.A2g_Truth(or__1927000174__auto____14) { max_columns__14 = or__1927000174__auto____14 } else {
		max_columns__14 = lang.IFn_Cast(A_arbace_pprint_A_const_132.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; var clauses__15 any = /*line :1011:1*/A_arbace_pprint_A_const_410.Invoke_O__O(params__0); var vec__1819000212__16 any = lang.IFn_Cast(A_arbace_pprint_A_const_418.GetRawRoot__O()).Invoke_O_O_O__O(clauses__15, navigator__12, A_arbace_pprint_A_const_375.Invoke_O__O(params__0)); var strs__17 any = lang.RT_Nth_O_I_O__O(vec__1819000212__16, lang.RT_IntCast_J__I(0), nil); var navigator__18 any = lang.RT_Nth_O_I_O__O(vec__1819000212__16, lang.RT_IntCast_J__I(1), nil); var slots__19 int64; var tmp1 int64 = lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(strs__17))); var tmp2 int64; if












	jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { tmp2 = 1 } else { tmp2 = 0 }; var tmp3 int64 = /*line :1023:1*/lang.Numbers_Add_J_J__J(tmp1, tmp2); var tmp4 int64; if
	jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { tmp4 = 1 } else { tmp4 = 0 }; slots__19 = /*line :1023:1*/lang.Numbers_Max_J_J__J(1, lang.Numbers_Add_J_J__J(tmp3, tmp4)); var chars__20 any = /*line :1011:1*/lang.IFn_Cast(A_arbace_pprint_A_const_420.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_423.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_424.GetRawRoot__O(), strs__17)); var mincol__21 any = A_arbace_pprint_A_const_315.Invoke_O__O(params__0); var minpad__22 any = A_arbace_pprint_A_const_314.Invoke_O__O(params__0); var colinc__23 any = A_arbace_pprint_A_const_316.Invoke_O__O(params__0); var minout__24 any = lang.Numbers_Add_O_O__Number(chars__20, lang.Numbers_Multiply_J_O__Number(slots__19, minpad__22)); var result_columns__25 any; if


















	lang.Numbers_Lte_O_O__Z(minout__24, mincol__21) { result_columns__25 = mincol__21 } else {

		result_columns__25 = lang.Numbers_Add_O_O__Number(mincol__21, lang.Numbers_Multiply_O_O__Number(colinc__23, lang.Numbers_Add_J_O__Number(1, lang.Numbers_Quotient_O_O__Number(lang.Numbers_Minus_O_J__Number(lang.Numbers_Minus_O_O__Number(minout__24, mincol__21), 1), colinc__23)))) }; var total_pad__26 any = /*line :1011:1*/lang.Numbers_Minus_O_O__Number(result_columns__25, chars__20); var pad__27 any = lang.Numbers_Max_O_O__O(minpad__22, lang.Numbers_Quotient_O_J__Number(total_pad__26, slots__19)); var extra_pad__28 any = lang.Numbers_Minus_O_O__Number(total_pad__26, lang.Numbers_Multiply_O_J__Number(pad__27, slots__19)); var pad_str__29 any = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(pad__27, A_arbace_pprint_A_const_317.Invoke_O__O(params__0))); var tmp5 any; var and__1927000168__auto____30 any = eol_str__6; if


























	jrt.A2g_Truth(and__1927000168__auto____30) { var tmp6 *lang.Keyword = A_arbace_pprint_A_const_50; tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_34.Get__O())))), min_remaining__13), result_columns__25), max_columns__14)).Ref() } else { tmp5 = and__1927000168__auto____30 }; if jrt.A2g_Truth(tmp5) {

		lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(eol_str__6) }; var slots__30 int64 = slots__19; var extra_pad__31 any = extra_pad__28; var strs__32 any = strs__17; var pad_only__33 any; var or__1927000174__auto____33 any = /*line :1011:1*/A_arbace_pprint_A_const_332.Invoke_O__O(params__0); if
































	jrt.A2g_Truth(or__1927000174__auto____33) { pad_only__33 = or__1927000174__auto____33 } else { var and__1927000168__auto____34 bool = lang.Util_Equiv_J_J__Z(int64(lang.RT_Count_O__I(strs__32)), 1)
		if and__1927000168__auto____34 { pad_only__33 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) } else { pad_only__33 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____34).Ref() } }; L1:
//line :1011:1
		for {


































			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(strs__32)) {

				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp9 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(pad_only__33)) { tmp9 = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(strs__32) } else { tmp9 = nil }; var tmp10 any = tmp9; var tmp11 any; var tmp12 any; var or__1927000174__auto____37 any = pad_only__33
				if jrt.A2g_Truth(or__1927000174__auto____37) { tmp12 = or__1927000174__auto____37 } else { var or__1927000174__auto____38 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(strs__32); if jrt.A2g_Truth(or__1927000174__auto____38) { tmp12 = or__1927000174__auto____38 } else { tmp12 = A_arbace_pprint_A_const_318.Invoke_O__O(params__0) } }; if jrt.A2g_Truth(tmp12) { tmp11 = pad_str__29 } else { tmp11 = nil }
//line :1048:1
				var tmp13 any = tmp11; var tmp14 any

				if lang.Numbers_IsPos_O__Z(extra_pad__31) { tmp14 = A_arbace_pprint_A_const_317.Invoke_O__O(params__0) } else { tmp14 = nil }
//line :1048:1
				tmp7.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp10, tmp13, tmp14)).Ref())


				var tmp15 int64 = lang.Numbers_Dec_J__J(slots__30); var tmp16 any = lang.Numbers_Dec_O__Number(extra_pad__31); var tmp17 any


				if jrt.A2g_Truth(pad_only__33) { tmp17 = strs__32 } else { tmp17 = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(strs__32) }
//line :1051:1
				var tmp18 any = tmp17; var tmp19 *jrt.Boolean; jrt.Boolean_Init(); tmp19 = jrt.Boolean_FALSE; slots__30, extra_pad__31, strs__32, pad_only__33 = tmp15, tmp16, tmp18, tmp19.Ref(); continue L1 }
//line :1011:1
			break L1 }; return navigator__18 }






















































func A_arbace_pprint_downcase_writer_A_New() *A_arbace_pprint_downcase_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_downcase_writer_A{}; t.Ctor(); return t }
//line :1066:1
func (t *A_arbace_pprint_downcase_writer_A) Ctor() {}
//line :1066:1
func (t *A_arbace_pprint_downcase_writer_A) Invoke_O_O__O(self, writer__0 any) any { var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_10), jrt.RefArrayOf(jrt.Object_class)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_53.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_downcase_writer_fn__1819000216_A_New_O(writer__0); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_pprint_downcase_writer_fn__1819000216_A_fn_class; if


	fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_pprint_downcase_writer_fn__1819000216_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = A_arbace_pprint_downcase_writer_fn__1819000218_A_New_O(writer__0); var tmp6 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_pprint_downcase_writer_fn__1819000218_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_pprint_downcase_writer_fn__1819000218_A_fn_class = fncls__58d; tmp6 = fncls__58d } else { tmp6 = fncls__58 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_pprint_downcase_writer_fn__1819000220_A_New_O(writer__0); var tmp9 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_pprint_downcase_writer_fn__1819000220_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_pprint_downcase_writer_fn__1819000220_A_fn_class = fncls__59d; tmp9 = fncls__59d } else { tmp9 = fncls__59 }; tmp1.Invoke_O_O__O(p__840000142__auto____2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_11, tmp4, Lit_13, tmp7, Lit_15, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)))); return p__840000142__auto____2 }
//line :1069:1
func A_arbace_pprint_downcase_writer_fn__1819000216_A_New_O(p0 any) *A_arbace_pprint_downcase_writer_fn__1819000216_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_downcase_writer_fn__1819000216_A{}; t.Ctor_O(p0); return t }
//line :1069:1
func (t *A_arbace_pprint_downcase_writer_fn__1819000216_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1069:1
func (t *A_arbace_pprint_downcase_writer_fn__1819000216_A) Invoke_O_O__O(self, this__1 any) any {
	jrt.Writer_Cast(t.F_writer).Close__V(); return nil }
//line :1069:1
func A_arbace_pprint_downcase_writer_fn__1819000218_A_New_O(p0 any) *A_arbace_pprint_downcase_writer_fn__1819000218_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_downcase_writer_fn__1819000218_A{}; t.Ctor_O(p0); return t }
//line :1069:1
func (t *A_arbace_pprint_downcase_writer_fn__1819000218_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1069:1
func (t *A_arbace_pprint_downcase_writer_fn__1819000218_A) Invoke_O_O__O(self, this__1 any) any {

	jrt.Writer_Cast(t.F_writer).Flush__V(); return nil }
//line :1069:1
func A_arbace_pprint_downcase_writer_fn__1819000220_A_New_O(p0 any) *A_arbace_pprint_downcase_writer_fn__1819000220_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_downcase_writer_fn__1819000220_A{}; t.Ctor_O(p0); return t }
//line :1069:1
func (t *A_arbace_pprint_downcase_writer_fn__1819000220_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1069:1
func (t *A_arbace_pprint_downcase_writer_fn__1819000220_A) Invoke_O_O_O_O_O__O(self, this__1, cbuf__2, off__3, len__4 any) any {



	var tmp1 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp1.Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](cbuf__2, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_O__I(off__3), lang.RT_IntCast_O__I(len__4)); return nil }
//line :1069:1
func (t *A_arbace_pprint_downcase_writer_fn__1819000220_A) Invoke_O_O_O__O(self, this__1, x__2 any) any { var pred__1819000221__3 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__1819000222__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(x__2); if





	jrt.A2g_Truth(lang.IFn_Cast(pred__1819000221__3).Invoke_O_O__O(A_arbace_pprint_A_const_57, expr__1819000222__4)) { var s__5 any = x__2; var tmp1 jrt.Writer_I = jrt.Writer_Cast(t.F_writer)


		tmp1.Write_String__V(jrt.NN(jrt.String_Cast(s__5)).ToLowerCase__String()); return nil } else {
//line :1075:1
			if jrt.A2g_Truth(lang.IFn_Cast(pred__1819000221__3).Invoke_O_O__O(A_arbace_pprint_A_const_59, expr__1819000222__4)) { var c__5 any = x__2; var tmp2 jrt.Writer_I = jrt.Writer_Cast(t.F_writer)






				tmp2.Write_I__V(lang.RT_IntCast_C__I(jrt.Character_ToLowerCase_C__C(lang.RT_CharCast_O__C(c__5)))); return nil } else {
//line :1075:1
					panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__1819000222__4))))) } } }








func A_arbace_pprint_upcase_writer_A_New() *A_arbace_pprint_upcase_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_upcase_writer_A{}; t.Ctor(); return t }
//line :1084:1
func (t *A_arbace_pprint_upcase_writer_A) Ctor() {}
//line :1084:1
func (t *A_arbace_pprint_upcase_writer_A) Invoke_O_O__O(self, writer__0 any) any { var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_10), jrt.RefArrayOf(jrt.Object_class)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_53.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_upcase_writer_fn__1819000225_A_New_O(writer__0); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_pprint_upcase_writer_fn__1819000225_A_fn_class; if


	fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_271, false); A_arbace_pprint_upcase_writer_fn__1819000225_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = A_arbace_pprint_upcase_writer_fn__1819000227_A_New_O(writer__0); var tmp6 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_pprint_upcase_writer_fn__1819000227_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_272, false); A_arbace_pprint_upcase_writer_fn__1819000227_A_fn_class = fncls__61d; tmp6 = fncls__61d } else { tmp6 = fncls__61 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_pprint_upcase_writer_fn__1819000229_A_New_O(writer__0); var tmp9 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_pprint_upcase_writer_fn__1819000229_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_273, false); A_arbace_pprint_upcase_writer_fn__1819000229_A_fn_class = fncls__62d; tmp9 = fncls__62d } else { tmp9 = fncls__62 }; tmp1.Invoke_O_O__O(p__840000142__auto____2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_11, tmp4, Lit_13, tmp7, Lit_15, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)))); return p__840000142__auto____2 }
//line :1087:1
func A_arbace_pprint_upcase_writer_fn__1819000225_A_New_O(p0 any) *A_arbace_pprint_upcase_writer_fn__1819000225_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_upcase_writer_fn__1819000225_A{}; t.Ctor_O(p0); return t }
//line :1087:1
func (t *A_arbace_pprint_upcase_writer_fn__1819000225_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1087:1
func (t *A_arbace_pprint_upcase_writer_fn__1819000225_A) Invoke_O_O__O(self, this__1 any) any {
	jrt.Writer_Cast(t.F_writer).Close__V(); return nil }
//line :1087:1
func A_arbace_pprint_upcase_writer_fn__1819000227_A_New_O(p0 any) *A_arbace_pprint_upcase_writer_fn__1819000227_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_upcase_writer_fn__1819000227_A{}; t.Ctor_O(p0); return t }
//line :1087:1
func (t *A_arbace_pprint_upcase_writer_fn__1819000227_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1087:1
func (t *A_arbace_pprint_upcase_writer_fn__1819000227_A) Invoke_O_O__O(self, this__1 any) any {

	jrt.Writer_Cast(t.F_writer).Flush__V(); return nil }
//line :1087:1
func A_arbace_pprint_upcase_writer_fn__1819000229_A_New_O(p0 any) *A_arbace_pprint_upcase_writer_fn__1819000229_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_upcase_writer_fn__1819000229_A{}; t.Ctor_O(p0); return t }
//line :1087:1
func (t *A_arbace_pprint_upcase_writer_fn__1819000229_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1087:1
func (t *A_arbace_pprint_upcase_writer_fn__1819000229_A) Invoke_O_O_O_O_O__O(self, this__1, cbuf__2, off__3, len__4 any) any {



	var tmp1 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp1.Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](cbuf__2, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_O__I(off__3), lang.RT_IntCast_O__I(len__4)); return nil }
//line :1087:1
func (t *A_arbace_pprint_upcase_writer_fn__1819000229_A) Invoke_O_O_O__O(self, this__1, x__2 any) any { var pred__1819000230__3 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__1819000231__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(x__2); if





	jrt.A2g_Truth(lang.IFn_Cast(pred__1819000230__3).Invoke_O_O__O(A_arbace_pprint_A_const_57, expr__1819000231__4)) { var s__5 any = x__2; var tmp1 jrt.Writer_I = jrt.Writer_Cast(t.F_writer)


		tmp1.Write_String__V(jrt.NN(jrt.String_Cast(s__5)).ToUpperCase__String()); return nil } else {
//line :1093:1
			if jrt.A2g_Truth(lang.IFn_Cast(pred__1819000230__3).Invoke_O_O__O(A_arbace_pprint_A_const_59, expr__1819000231__4)) { var c__5 any = x__2; var tmp2 jrt.Writer_I = jrt.Writer_Cast(t.F_writer)






				tmp2.Write_I__V(lang.RT_IntCast_C__I(jrt.Character_ToUpperCase_C__C(lang.RT_CharCast_O__C(c__5)))); return nil } else {
//line :1093:1
					panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__1819000231__4))))) } } }








func A_arbace_pprint_capitalize_string_A_New() *A_arbace_pprint_capitalize_string_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_capitalize_string_A{}; t.Ctor(); return t }
//line :1102:1
func (t *A_arbace_pprint_capitalize_string_A) Ctor() {}
//line :1102:1
func (t *A_arbace_pprint_capitalize_string_A) Invoke_O_O_O__O(self, s__0, first_QMARK___1 any) any { var f__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__0); var s__4 any; var tmp1 any; var and__1927000168__auto____4 any = first_QMARK___1; if




	jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = f__3; if jrt.A2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(jrt.Character_IsLetter_C__Z(jrt.NN(jrt.Character_Cast(f__3)).CharValue__C())).Ref() } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) {
		s__4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(jrt.Character_ToUpperCase_C__C(jrt.NN(jrt.Character_Cast(f__3)).CharValue__C())).Ref(), lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_pprint_A_const_176))).Ref() } else {
//line :1107:1
			s__4 = s__0 }; var tmp2 lang.IFn =


	lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_A_const_146.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp6 any = A_arbace_pprint_capitalize_string_fn__1819000234_A_New(); var tmp7 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_pprint_capitalize_string_fn__1819000234_A_fn_class; if


	fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_pprint_capitalize_string_fn__1819000234_A_fn_class = fncls__63d; tmp7 = fncls__63d } else { tmp7 = fncls__63 }; return /*line :1110:1*/ tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), s__4))) }


func A_arbace_pprint_capitalize_string_fn__1819000234_A_New() *A_arbace_pprint_capitalize_string_fn__1819000234_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_capitalize_string_fn__1819000234_A{}; t.Ctor(); return t }
//line :1113:1
func (t *A_arbace_pprint_capitalize_string_fn__1819000234_A) Ctor() {}
//line :1113:1
func (t *A_arbace_pprint_capitalize_string_fn__1819000234_A) Invoke_O_O__O(self, s__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(s__1)) { return A_arbace_pprint_A_const_425 } else { var m__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_426.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_428, s__1); var match__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_427.GetRawRoot__O()).Invoke_O__O(m__2); var offset__4 any
		var and__1927000168__auto____4 any = match__3


		if jrt.A2g_Truth(and__1927000168__auto____4) { offset__4 = jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.Matcher_Cast(m__2)).Start__I()))).Ref() } else { offset__4 = and__1927000168__auto____4 }
		if jrt.A2g_Truth(offset__4) { return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(s__1, A_arbace_pprint_A_const_28, offset__4), jrt.Character_ValueOf_C__Character(jrt.Character_ToUpperCase_C__C(jrt.NN(jrt.Character_Cast(lang.RT_Nth_O_I__O(s__1, lang.RT_IntCast_O__I(offset__4)))).CharValue__C())).Ref())).Ref(), lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__1, lang.Numbers_Inc_O__Number(offset__4))) } else { return lang.Tuple_Create_O_O__IPersistentVector(s__1, nil)
		}
	}
}



func A_arbace_pprint_capitalize_word_writer_A_New() *A_arbace_pprint_capitalize_word_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_capitalize_word_writer_A{}; t.Ctor(); return t }
//line :1126:1
func (t *A_arbace_pprint_capitalize_word_writer_A) Ctor() {}
//line :1126:1
func (t *A_arbace_pprint_capitalize_word_writer_A) Invoke_O_O__O(self, writer__0 any) any { var last_was_whitespace_QMARK___2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()); var tmp2 *jrt.Boolean;


	jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; last_was_whitespace_QMARK___2 = tmp1.Invoke_O__O(tmp2.Ref()); var p__840000142__auto____3 any = /*line :1126:1*/lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_10), jrt.RefArrayOf(jrt.Object_class)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_53.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_New_O(writer__0); var tmp5 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_fn_class; if



	fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_fn_class = fncls__64d; tmp5 = fncls__64d } else { tmp5 = fncls__64 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any = A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_New_O(writer__0); var tmp8 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_fn_class = fncls__65d; tmp8 = fncls__65d } else { tmp8 = fncls__65 }; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_New_O_O(last_was_whitespace_QMARK___2, writer__0); var tmp11 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_fn_class = fncls__68d; tmp11 = fncls__68d } else { tmp11 = fncls__68 }; tmp3.Invoke_O_O__O(p__840000142__auto____3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_11, tmp6, Lit_13, tmp9, Lit_15, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)))); return p__840000142__auto____3 }
//line :1130:1
func A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_New_O(p0 any) *A_arbace_pprint_capitalize_word_writer_fn__1819000237_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_capitalize_word_writer_fn__1819000237_A{}; t.Ctor_O(p0); return t }
//line :1130:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000237_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1130:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000237_A) Invoke_O_O__O(self, this__1 any) any {
	jrt.Writer_Cast(t.F_writer).Close__V(); return nil }
//line :1130:1
func A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_New_O(p0 any) *A_arbace_pprint_capitalize_word_writer_fn__1819000239_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_capitalize_word_writer_fn__1819000239_A{}; t.Ctor_O(p0); return t }
//line :1130:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000239_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1130:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000239_A) Invoke_O_O__O(self, this__1 any) any {

	jrt.Writer_Cast(t.F_writer).Flush__V(); return nil }
//line :1130:1
func A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_New_O_O(p0, p1 any) *A_arbace_pprint_capitalize_word_writer_fn__1819000241_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_capitalize_word_writer_fn__1819000241_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1130:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000241_A) Ctor_O_O(c__last_was_whitespace_QMARK_, c__writer any) { t.F_last_was_whitespace_QMARK_ = c__last_was_whitespace_QMARK_; t.F_writer = c__writer }
//line :1130:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000241_A) Invoke_O_O_O_O_O__O(self, this__1, cbuf__2, off__3, len__4 any) any {




	var tmp1 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp1.Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](cbuf__2, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_O__I(off__3), lang.RT_IntCast_O__I(len__4)); return nil }
//line :1130:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000241_A) Invoke_O_O_O__O(self, this__1, x__2 any) any { var pred__1819000242__3 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__1819000243__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(x__2); if






	jrt.A2g_Truth(lang.IFn_Cast(pred__1819000242__3).Invoke_O_O__O(A_arbace_pprint_A_const_57, expr__1819000243__4)) { var s__5 any = x__2; var tmp1 jrt.Writer_I = jrt.Writer_Cast(t.F_writer)


		tmp1.Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_429.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.String_Cast(s__5)).ToLowerCase__String().Ref(), lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_last_was_whitespace_QMARK_))))

		if lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(s__5)).Length__I())) {
			var tmp2 any = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_New_O_O(t.F_last_was_whitespace_QMARK_, s__5); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else {
//line :1142:1
				return nil } } else {
//line :1137:1
					if jrt.A2g_Truth(lang.IFn_Cast(pred__1819000242__3).Invoke_O_O__O(A_arbace_pprint_A_const_59, expr__1819000243__4)) { var c__5 uint16 = lang.RT_CharCast_O__C(x__2); var mod_c__6 uint16












						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_last_was_whitespace_QMARK_)) { mod_c__6 = jrt.Character_ToUpperCase_C__C(lang.RT_CharCast_O__C(x__2)) } else { mod_c__6 = c__5 }
						var tmp4 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp4.Write_I__V(lang.RT_IntCast_C__I(mod_c__6))
						var tmp5 any = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_New_O_O(t.F_last_was_whitespace_QMARK_, x__2); var tmp6 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_fn_class = fncls__67d; tmp6 = fncls__67d } else { tmp6 = fncls__67 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) } else {
//line :1137:1
							panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__1819000243__4))))) } } }





func A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_New_O_O(p0, p1 any) *A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1143:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A) Ctor_O_O(c__last_was_whitespace_QMARK_, c__s any) { t.F_last_was_whitespace_QMARK_ = c__last_was_whitespace_QMARK_; t.F_s = c__s }
//line :1143:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp2 any = t.F_last_was_whitespace_QMARK_; var tmp3 any = t.F_s; return tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(jrt.Character_IsWhitespace_C__Z(jrt.NN(jrt.Character_Cast(lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(t.F_s))))))).CharValue__C())).Ref())
}






func A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_New_O_O(p0, p1 any) *A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1152:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A) Ctor_O_O(c__last_was_whitespace_QMARK_, c__x any) { t.F_last_was_whitespace_QMARK_ = c__last_was_whitespace_QMARK_; t.F_x = c__x }
//line :1152:1
func (t *A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp2 any = t.F_last_was_whitespace_QMARK_; return tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(jrt.Character_IsWhitespace_C__Z(lang.RT_CharCast_O__C(t.F_x))).Ref()) }

func A_arbace_pprint_init_cap_writer_A_New() *A_arbace_pprint_init_cap_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_init_cap_writer_A{}; t.Ctor(); return t }
//line :1154:1
func (t *A_arbace_pprint_init_cap_writer_A) Ctor() {}
//line :1154:1
func (t *A_arbace_pprint_init_cap_writer_A) Invoke_O_O__O(self, writer__0 any) any { var capped__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_52.GetRawRoot__O()); var tmp2 *jrt.Boolean;


	jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; capped__2 = tmp1.Invoke_O__O(tmp2.Ref()); var p__840000142__auto____3 any = /*line :1154:1*/lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_10), jrt.RefArrayOf(jrt.Object_class)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_53.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_init_cap_writer_fn__1819000250_A_New_O(writer__0); var tmp5 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_pprint_init_cap_writer_fn__1819000250_A_fn_class; if



	fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_pprint_init_cap_writer_fn__1819000250_A_fn_class = fncls__69d; tmp5 = fncls__69d } else { tmp5 = fncls__69 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any = A_arbace_pprint_init_cap_writer_fn__1819000252_A_New_O(writer__0); var tmp8 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_pprint_init_cap_writer_fn__1819000252_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_pprint_init_cap_writer_fn__1819000252_A_fn_class = fncls__70d; tmp8 = fncls__70d } else { tmp8 = fncls__70 }; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_pprint_init_cap_writer_fn__1819000254_A_New_O_O(writer__0, capped__2); var tmp11 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_pprint_init_cap_writer_fn__1819000254_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_pprint_init_cap_writer_fn__1819000254_A_fn_class = fncls__73d; tmp11 = fncls__73d } else { tmp11 = fncls__73 }; tmp3.Invoke_O_O__O(p__840000142__auto____3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_11, tmp6, Lit_13, tmp9, Lit_15, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)))); return p__840000142__auto____3 }
//line :1158:1
func A_arbace_pprint_init_cap_writer_fn__1819000250_A_New_O(p0 any) *A_arbace_pprint_init_cap_writer_fn__1819000250_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_init_cap_writer_fn__1819000250_A{}; t.Ctor_O(p0); return t }
//line :1158:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000250_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1158:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000250_A) Invoke_O_O__O(self, this__1 any) any {
	jrt.Writer_Cast(t.F_writer).Close__V(); return nil }
//line :1158:1
func A_arbace_pprint_init_cap_writer_fn__1819000252_A_New_O(p0 any) *A_arbace_pprint_init_cap_writer_fn__1819000252_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_init_cap_writer_fn__1819000252_A{}; t.Ctor_O(p0); return t }
//line :1158:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000252_A) Ctor_O(c__writer any) { t.F_writer = c__writer }
//line :1158:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000252_A) Invoke_O_O__O(self, this__1 any) any {

	jrt.Writer_Cast(t.F_writer).Flush__V(); return nil }
//line :1158:1
func A_arbace_pprint_init_cap_writer_fn__1819000254_A_New_O_O(p0, p1 any) *A_arbace_pprint_init_cap_writer_fn__1819000254_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_init_cap_writer_fn__1819000254_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1158:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000254_A) Ctor_O_O(c__writer, c__capped any) { t.F_writer = c__writer; t.F_capped = c__capped }
//line :1158:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000254_A) Invoke_O_O_O_O_O__O(self, this__1, cbuf__2, off__3, len__4 any) any {



	var tmp1 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp1.Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](cbuf__2, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_O__I(off__3), lang.RT_IntCast_O__I(len__4)); return nil }
//line :1158:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000254_A) Invoke_O_O_O__O(self, this__1, x__2 any) any { var pred__1819000255__3 any = A_arbace_pprint_A_const_54.GetRawRoot__O(); var expr__1819000256__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(x__2); if





	jrt.A2g_Truth(lang.IFn_Cast(pred__1819000255__3).Invoke_O_O__O(A_arbace_pprint_A_const_57, expr__1819000256__4)) { var s__5 any = jrt.NN(jrt.String_Cast(x__2)).ToLowerCase__String().Ref()


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_capped))) { var m__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_426.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_430, s__5); var match__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_427.GetRawRoot__O()).Invoke_O__O(m__6); var offset__8 any
			var and__1927000168__auto____8 any = match__7

			if jrt.A2g_Truth(and__1927000168__auto____8) { offset__8 = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Matcher_Cast(m__6)).Start__I()).Ref() } else { offset__8 = and__1927000168__auto____8 }
			if jrt.A2g_Truth(offset__8) {
				var tmp1 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp1.Write_String__V(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(s__5, A_arbace_pprint_A_const_28, offset__8), jrt.Character_ValueOf_C__Character(jrt.Character_ToUpperCase_C__C(jrt.NN(jrt.Character_Cast(lang.RT_Nth_O_I__O(s__5, lang.RT_IntCast_O__I(offset__8)))).CharValue__C())).Ref(), jrt.NN(jrt.String_Cast(lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__5, lang.Numbers_Inc_O__Number(offset__8)))).ToLowerCase__String().Ref())))



				var tmp2 any = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_New_O(t.F_capped); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_123, false); A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else {
					var tmp4 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp4.Write_String__V(jrt.String_Cast(s__5)); return nil } } else {
						var tmp5 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp5.Write_String__V(jrt.NN(jrt.String_Cast(s__5)).ToLowerCase__String()); return nil } } else {
//line :1164:1
							if jrt.A2g_Truth(lang.IFn_Cast(pred__1819000255__3).Invoke_O_O__O(A_arbace_pprint_A_const_59, expr__1819000256__4)) { var c__5 any = jrt.Character_ValueOf_C__Character(lang.RT_CharCast_O__C(x__2)).Ref(); var tmp6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_capped))

















								if jrt.A2g_Truth(and__1927000168__auto____6) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(jrt.Character_IsLetter_C__Z(jrt.NN(jrt.Character_Cast(c__5)).CharValue__C())).Ref() } else { tmp6 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp6) {

									var tmp7 any = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_New_O(t.F_capped); var tmp8 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_124, false); A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_fn_class = fncls__72d; tmp8 = fncls__72d } else { tmp8 = fncls__72 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))
									var tmp9 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp9.Write_I__V(lang.RT_IntCast_C__I(jrt.Character_ToUpperCase_C__C(jrt.NN(jrt.Character_Cast(c__5)).CharValue__C()))); return nil } else {
										var tmp10 jrt.Writer_I = jrt.Writer_Cast(t.F_writer); tmp10.Write_I__V(lang.RT_IntCast_C__I(jrt.Character_ToLowerCase_C__C(jrt.NN(jrt.Character_Cast(c__5)).CharValue__C()))); return nil } } else {
//line :1164:1
											panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, expr__1819000256__4))))) } } }











func A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_New_O(p0 any) *A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A{}; t.Ctor_O(p0); return t }
//line :1176:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A) Ctor_O(c__capped any) { t.F_capped = c__capped }
//line :1176:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp2 any = t.F_capped; var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(tmp2, tmp3.Ref()) }







func A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_New_O(p0 any) *A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A{}; t.Ctor_O(p0); return t }
//line :1184:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A) Ctor_O(c__capped any) { t.F_capped = c__capped }
//line :1184:1
func (t *A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_112.GetRawRoot__O()); var tmp2 any = t.F_capped; var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(tmp2, tmp3.Ref()) }



func A_arbace_pprint_modify_case_A_New() *A_arbace_pprint_modify_case_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_modify_case_A{}; t.Ctor(); return t }
//line :1188:1
func (t *A_arbace_pprint_modify_case_A) Ctor() {}
//line :1188:1
func (t *A_arbace_pprint_modify_case_A) Invoke_O_O_O_O_O__O(self, make_writer__0, params__1, navigator__2, offsets__3 any) any { var clause__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_410.Invoke_O__O(params__1)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_34;

	lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(make_writer__0).Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()))); var tmp3 any; tmp4 := /*line :1188:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		tmp3 = lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(clause__5, navigator__2, A_arbace_pprint_A_const_375.Invoke_O__O(params__1))
//line :1188:1
		return nil }();

	lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if /*line :1188:1*/ tmp4 != nil { panic(tmp4) }; return tmp3 }








func A_arbace_pprint_get_pretty_writer_A_New() *A_arbace_pprint_get_pretty_writer_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_get_pretty_writer_A{}; t.Ctor(); return t }
//line :1197:1
func (t *A_arbace_pprint_get_pretty_writer_A) Ctor() {}
//line :1197:1
func (t *A_arbace_pprint_get_pretty_writer_A) Invoke_O_O__O(self, writer__0 any) any {

































	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_228.GetRawRoot__O()).Invoke_O__O(writer__0)) { return writer__0 } else {

		return lang.IFn_Cast(A_arbace_pprint_A_const_198.GetRawRoot__O()).Invoke_O_O_O__O(writer__0, A_arbace_pprint_A_const_230.Get__O(), A_arbace_pprint_A_const_231.Get__O())
	}
}



func A_arbace_pprint_fresh_line_A_New() *A_arbace_pprint_fresh_line_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fresh_line_A{}; t.Ctor(); return t }
//line :1239:1
func (t *A_arbace_pprint_fresh_line_A) Ctor() {}
//line :1239:1
func (t *A_arbace_pprint_fresh_line_A) Invoke_O__O(self any) any {




	if lang.IDeref_InstanceOf(A_arbace_pprint_A_const_34.Get__O()) {
		var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_O__Z(0, lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_34.Get__O())))))).Ref())) {
			return lang.IFn_Cast(A_arbace_pprint_A_const_232.GetRawRoot__O()).Invoke__O() } else {
//line :1245:1
				return nil } } else {

					return lang.IFn_Cast(A_arbace_pprint_A_const_232.GetRawRoot__O()).Invoke__O()
				} }
func A_arbace_pprint_absolute_tabulation_A_New() *A_arbace_pprint_absolute_tabulation_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_absolute_tabulation_A{}; t.Ctor(); return t }
//line :1249:1
func (t *A_arbace_pprint_absolute_tabulation_A) Ctor() {}
//line :1249:1
func (t *A_arbace_pprint_absolute_tabulation_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var colnum__4 any = A_arbace_pprint_A_const_431.Invoke_O__O(params__0); var colinc__5 any = A_arbace_pprint_A_const_316.Invoke_O__O(params__0); var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; var current__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_34.Get__O())))); var space_count__7 any; if



	lang.Numbers_Lt_O_O__Z(current__6, colnum__4) {
		space_count__7 = lang.Numbers_Minus_O_O__Number(colnum__4, current__6) } else {
//line :1253:1
			if lang.Util_Equiv_O_J__Z(colinc__5, 0) { space_count__7 = A_arbace_pprint_A_const_28 } else { if A_arbace_pprint_A_const_95 != nil {


				space_count__7 = lang.Numbers_Minus_O_O__Number(colinc__5, lang.Numbers_Remainder_O_O__Number(lang.Numbers_Minus_O_O__Number(current__6, colnum__4), colinc__5)) } else {
//line :1253:1
					space_count__7 = nil } } };



	lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(space_count__7, A_arbace_pprint_A_const_148))); return navigator__1 }


func A_arbace_pprint_relative_tabulation_A_New() *A_arbace_pprint_relative_tabulation_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_relative_tabulation_A{}; t.Ctor(); return t }
//line :1260:1
func (t *A_arbace_pprint_relative_tabulation_A) Ctor() {}
//line :1260:1
func (t *A_arbace_pprint_relative_tabulation_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var colrel__4 any = A_arbace_pprint_A_const_431.Invoke_O__O(params__0); var colinc__5 any = A_arbace_pprint_A_const_316.Invoke_O__O(params__0); var tmp1 *lang.Keyword = A_arbace_pprint_A_const_50; var start_col__6 any = lang.Numbers_Add_O_O__Number(colrel__4, lang.IFn_Cast(A_arbace_pprint_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()))))); var offset__7 any; if



	lang.Numbers_IsPos_O__Z(colinc__5) { offset__7 = lang.Numbers_Remainder_O_O__Number(start_col__6, colinc__5) } else { offset__7 = A_arbace_pprint_A_const_28 }; var space_count__8 any; var tmp2 any; if
	lang.Util_Equiv_J_O__Z(0, offset__7) { tmp2 = A_arbace_pprint_A_const_28 } else { tmp2 = lang.Numbers_Minus_O_O__Number(colinc__5, offset__7) }; space_count__8 = lang.Numbers_Add_O_O__Number(colrel__4, tmp2);
	lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(space_count__8, A_arbace_pprint_A_const_148))); return navigator__1 }








func A_arbace_pprint_format_logical_block_A_New() *A_arbace_pprint_format_logical_block_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_logical_block_A{}; t.Ctor(); return t }
//line :1275:1
func (t *A_arbace_pprint_format_logical_block_A) Ctor() {}
//line :1275:1
func (t *A_arbace_pprint_format_logical_block_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var clauses__4 any = A_arbace_pprint_A_const_410.Invoke_O__O(params__0); var clause_count__5 int32 = lang.RT_Count_O__I(clauses__4); var prefix__6 any; if


	lang.Numbers_Gt_J_J__Z(int64(clause_count__5), 1) {
		var tmp1 *lang.Keyword = A_arbace_pprint_A_const_432; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_374; prefix__6 = tmp1.Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(clauses__4)))) } else {
//line :1278:1
			if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { prefix__6 = Lit_102 } else { prefix__6 = nil } }; var body__7 any; var tmp3 int64; if


	lang.Numbers_Gt_J_J__Z(int64(clause_count__5), 1) { tmp3 = 1 } else { tmp3 = 0 }; body__7 = lang.RT_Nth_O_I__O(clauses__4, lang.RT_IntCast_J__I(tmp3)); var suffix__8 any; if
	lang.Numbers_Gt_J_J__Z(int64(clause_count__5), 2) {
		var tmp4 *lang.Keyword = A_arbace_pprint_A_const_432; var tmp5 *lang.Keyword = A_arbace_pprint_A_const_374; suffix__8 = tmp4.Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(clauses__4, lang.RT_IntCast_J__I(2))))) } else {
//line :1282:1
			if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { suffix__8 = Lit_103 } else { suffix__8 = nil } }; var vec__1819000268__9 any = /*line :1275:1*/lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__1); var arg__10 any = lang.RT_Nth_O_I_O__O(vec__1819000268__9, lang.RT_IntCast_J__I(0), nil); var navigator__11 any = lang.RT_Nth_O_I_O__O(vec__1819000268__9, lang.RT_IntCast_J__I(1), nil); if










	jrt.A2g_Truth(A_arbace_pprint_A_const_433.Invoke__O()) { jrt.Writer_Cast(A_arbace_pprint_A_const_34.Get__O()).Write_String__V(Lit_104) } else { var tmp6 any = A_arbace_pprint_A_const_244; lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_pprint_A_const_436.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_244)), A_arbace_pprint_A_const_213, A_arbace_pprint_A_const_28))); var tmp7 any = A_arbace_pprint_format_logical_block_fn__1819000271_A_New_O_O_O_O_O(params__0, suffix__8, prefix__6, arg__10, body__7); var tmp8 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_pprint_format_logical_block_fn__1819000271_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_pprint_format_logical_block_fn__1819000271_A_fn_class = fncls__74d; tmp8 = fncls__74d } else { tmp8 = fncls__74 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O() }; return navigator__11 }
//line :1286:1
func A_arbace_pprint_format_logical_block_fn__1819000271_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_pprint_format_logical_block_fn__1819000271_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_format_logical_block_fn__1819000271_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1286:1
func (t *A_arbace_pprint_format_logical_block_fn__1819000271_A) Ctor_O_O_O_O_O(c__params, c__suffix, c__prefix, c__arg, c__body any) { t.F_params = c__params; t.F_suffix = c__suffix; t.F_prefix = c__prefix; t.F_arg = c__arg; t.F_body = c__body }
//line :1286:1
func (t *A_arbace_pprint_format_logical_block_fn__1819000271_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_pprint_A_const_435; var tmp3 any = A_arbace_pprint_A_const_34.Get__O(); var tmp4 any; var t_ any = t.F_prefix; t.F_prefix = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var t__2 any = t.F_suffix; t.F_suffix = nil; tmp6 = t__2; tmp2.Invoke_O_O_O_O__O(tmp3, tmp5, nil, tmp6)
												var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()); var tmp8 any; var t__3 any = t.F_body; t.F_body = nil; tmp8 = t__3; var tmp9 any = tmp8; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()); var tmp11 any; var t__4 any = t.F_arg

	t.F_arg = nil; tmp11 = t__4
//line :1287:1
	var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 *lang.Keyword = A_arbace_pprint_A_const_375; var tmp14 any; var t__5 any = t.F_params


	t.F_params = nil; tmp14 = t__5
//line :1287:1
	tmp7.Invoke_O_O_O__O(tmp9, tmp12, tmp13.Invoke_O__O(tmp14))
//line :1286:1
	var tmp15 lang.IFn = A_arbace_pprint_A_const_434; tmp1 = tmp15.Invoke_O__O(A_arbace_pprint_A_const_34.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp16 != nil { panic(tmp16) }; return tmp1 }






func A_arbace_pprint_set_indent_A_New() *A_arbace_pprint_set_indent_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_set_indent_A{}; t.Ctor(); return t }
//line :1293:1
func (t *A_arbace_pprint_set_indent_A) Ctor() {}
//line :1293:1
func (t *A_arbace_pprint_set_indent_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var relative_to__4 any; if
														jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { relative_to__4 = A_arbace_pprint_A_const_123 } else { relative_to__4 = A_arbace_pprint_A_const_122 };
														lang.IFn_Cast(A_arbace_pprint_A_const_437.GetRawRoot__O()).Invoke_O_O__O(relative_to__4, A_arbace_pprint_A_const_408.Invoke_O__O(params__0)); return navigator__1 }




func A_arbace_pprint_conditional_newline_A_New() *A_arbace_pprint_conditional_newline_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_conditional_newline_A{}; t.Ctor(); return t }
//line :1300:1
func (t *A_arbace_pprint_conditional_newline_A) Ctor() {}
//line :1300:1
func (t *A_arbace_pprint_conditional_newline_A) Invoke_O_O_O_O__O(self, params__0, navigator__1, offsets__2 any) any { var kind__4 any; if
															jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) {
																if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { kind__4 = A_arbace_pprint_A_const_127 } else { kind__4 = A_arbace_pprint_A_const_129 } } else {
																	if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { kind__4 = A_arbace_pprint_A_const_438 } else { kind__4 = A_arbace_pprint_A_const_439 } };
															lang.IFn_Cast(A_arbace_pprint_A_const_440.GetRawRoot__O()).Invoke_O__O(kind__4); return navigator__1 }








func A_arbace_pprint_process_directive_table_element_A_New() *A_arbace_pprint_process_directive_table_element_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_process_directive_table_element_A{}; t.Ctor(); return t }
//line :1313:1
func (t *A_arbace_pprint_process_directive_table_element_A) Ctor() {}
//line :1313:1
func (t *A_arbace_pprint_process_directive_table_element_A) Invoke_O_O__O(self, p__1819000276__0 any) any { var vec__1819000277__2 any = p__1819000276__0; var seq__1819000278__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(vec__1819000277__2); var first__1819000279__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__1819000278__3); var seq__1819000278__5 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__1819000278__3); var char__6 any = first__1819000279__4; var first__1819000279__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__1819000278__5); var seq__1819000278__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__1819000278__5); var params__9 any = first__1819000279__7; var first__1819000279__10 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__1819000278__8); var seq__1819000278__11 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__1819000278__8); var flags__12 any = first__1819000279__10; var first__1819000279__13 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__1819000278__11); var seq__1819000278__14 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__1819000278__11); var bracket_info__15 any = first__1819000279__13; var generator_fn__16 any = seq__1819000278__14; var tmp1 any = A_arbace_pprint_A_const_441; var tmp2 any = A_arbace_pprint_A_const_374; var tmp3 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_445), params__9)); var tmp4 any = A_arbace_pprint_A_const_442; var tmp5 any = A_arbace_pprint_A_const_443; var tmp6 any = A_arbace_pprint_A_const_444; return lang.Tuple_Create_O_O__IPersistentVector(char__6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, char__6, tmp2, tmp3, tmp4, flags__12, tmp5, bracket_info__15, tmp6, lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_446, generator_fn__16)))) }







func A_arbace_pprint_defdirectives_A_New() *A_arbace_pprint_defdirectives_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_defdirectives_A{}; t.Ctor(); return t }
//line :1321:1
func (t *A_arbace_pprint_defdirectives_A) Ctor() {}
//line :1321:1
func (t *A_arbace_pprint_defdirectives_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, directives__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_447); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_88.GetRawRoot__O()); var tmp6 any = A_arbace_pprint_A_const_448; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()); var tmp8 any = A_arbace_pprint_A_const_33.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_75); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()); var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O__O(tmp13.Ref())))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_449), lang.IFn_Cast(A_arbace_pprint_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_450.GetRawRoot__O(), directives__2)))))) }





func A_arbace_pprint_fn__1819000328_A_New() *A_arbace_pprint_fn__1819000328_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000328_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000328_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000328_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { var tmp1 any = A_arbace_pprint_fn__1819000328_fn__1819000329_A_New(); var tmp2 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_pprint_fn__1819000328_fn__1819000329_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_pprint_fn__1819000328_fn__1819000329_A_fn_class = fncls__75d; tmp2 = fncls__75d } else { tmp2 = fncls__75 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000328_fn__1819000329_A_New() *A_arbace_pprint_fn__1819000328_fn__1819000329_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000328_fn__1819000329_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000328_fn__1819000329_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000328_fn__1819000329_A) Invoke_O_O_O_O__O(self, p1__1819000286_SHARP___1, p2__1819000287_SHARP___2, p3__1819000288_SHARP___3 any) any {



	return lang.IFn_Cast(A_arbace_pprint_A_const_333.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_338.GetRawRoot__O(), p1__1819000286_SHARP___1, p2__1819000287_SHARP___2, p3__1819000288_SHARP___3) }
//line :1327:1
func A_arbace_pprint_fn__1819000332_A_New() *A_arbace_pprint_fn__1819000332_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000332_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000332_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000332_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { var tmp1 any = A_arbace_pprint_fn__1819000332_fn__1819000333_A_New(); var tmp2 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_pprint_fn__1819000332_fn__1819000333_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_pprint_fn__1819000332_fn__1819000333_A_fn_class = fncls__76d; tmp2 = fncls__76d } else { tmp2 = fncls__76 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000332_fn__1819000333_A_New() *A_arbace_pprint_fn__1819000332_fn__1819000333_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000332_fn__1819000333_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000332_fn__1819000333_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000332_fn__1819000333_A) Invoke_O_O_O_O__O(self, p1__1819000289_SHARP___1, p2__1819000290_SHARP___2, p3__1819000291_SHARP___3 any) any {








	return lang.IFn_Cast(A_arbace_pprint_A_const_333.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_451.GetRawRoot__O(), p1__1819000289_SHARP___1, p2__1819000290_SHARP___2, p3__1819000291_SHARP___3) }
//line :1327:1
func A_arbace_pprint_fn__1819000336_A_New() *A_arbace_pprint_fn__1819000336_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000336_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000336_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000336_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { var tmp1 any = A_arbace_pprint_fn__1819000336_fn__1819000337_A_New(); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_pprint_fn__1819000336_fn__1819000337_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_pprint_fn__1819000336_fn__1819000337_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000336_fn__1819000337_A_New() *A_arbace_pprint_fn__1819000336_fn__1819000337_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000336_fn__1819000337_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000336_fn__1819000337_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000336_fn__1819000337_A) Invoke_O_O_O_O__O(self, p1__1819000292_SHARP___1, p2__1819000293_SHARP___2, p3__1819000294_SHARP___3 any) any {














	return lang.IFn_Cast(A_arbace_pprint_A_const_344.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_347, p1__1819000292_SHARP___1, p2__1819000293_SHARP___2, p3__1819000294_SHARP___3) }
//line :1327:1
func A_arbace_pprint_fn__1819000340_A_New() *A_arbace_pprint_fn__1819000340_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000340_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000340_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000340_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { var tmp1 any = A_arbace_pprint_fn__1819000340_fn__1819000341_A_New(); var tmp2 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_pprint_fn__1819000340_fn__1819000341_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_pprint_fn__1819000340_fn__1819000341_A_fn_class = fncls__78d; tmp2 = fncls__78d } else { tmp2 = fncls__78 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000340_fn__1819000341_A_New() *A_arbace_pprint_fn__1819000340_fn__1819000341_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000340_fn__1819000341_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000340_fn__1819000341_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000340_fn__1819000341_A) Invoke_O_O_O_O__O(self, p1__1819000295_SHARP___1, p2__1819000296_SHARP___2, p3__1819000297_SHARP___3 any) any {




















	return lang.IFn_Cast(A_arbace_pprint_A_const_344.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_241, p1__1819000295_SHARP___1, p2__1819000296_SHARP___2, p3__1819000297_SHARP___3) }
//line :1327:1
func A_arbace_pprint_fn__1819000344_A_New() *A_arbace_pprint_fn__1819000344_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000344_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000344_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000344_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { var tmp1 any = A_arbace_pprint_fn__1819000344_fn__1819000345_A_New(); var tmp2 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_pprint_fn__1819000344_fn__1819000345_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_pprint_fn__1819000344_fn__1819000345_A_fn_class = fncls__79d; tmp2 = fncls__79d } else { tmp2 = fncls__79 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000344_fn__1819000345_A_New() *A_arbace_pprint_fn__1819000344_fn__1819000345_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000344_fn__1819000345_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000344_fn__1819000345_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000344_fn__1819000345_A) Invoke_O_O_O_O__O(self, p1__1819000298_SHARP___1, p2__1819000299_SHARP___2, p3__1819000300_SHARP___3 any) any {


























	return lang.IFn_Cast(A_arbace_pprint_A_const_344.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_452, p1__1819000298_SHARP___1, p2__1819000299_SHARP___2, p3__1819000300_SHARP___3) }
//line :1327:1
func A_arbace_pprint_fn__1819000348_A_New() *A_arbace_pprint_fn__1819000348_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000348_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000348_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000348_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { var tmp1 any = A_arbace_pprint_fn__1819000348_fn__1819000349_A_New(); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_pprint_fn__1819000348_fn__1819000349_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_pprint_fn__1819000348_fn__1819000349_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000348_fn__1819000349_A_New() *A_arbace_pprint_fn__1819000348_fn__1819000349_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000348_fn__1819000349_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000348_fn__1819000349_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000348_fn__1819000349_A) Invoke_O_O_O_O__O(self, p1__1819000301_SHARP___1, p2__1819000302_SHARP___2, p3__1819000303_SHARP___3 any) any {
































	return lang.IFn_Cast(A_arbace_pprint_A_const_344.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_453, p1__1819000301_SHARP___1, p2__1819000302_SHARP___2, p3__1819000303_SHARP___3) }
//line :1327:1
func A_arbace_pprint_fn__1819000352_A_New() *A_arbace_pprint_fn__1819000352_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000352_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000352_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000352_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {







































	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_50.Invoke_O__O(params__0))) { var tmp1 any = A_arbace_pprint_fn__1819000352_fn__1819000353_A_New(); var tmp2 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_pprint_fn__1819000352_fn__1819000353_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_pprint_fn__1819000352_fn__1819000353_A_fn_class = fncls__81d; tmp2 = fncls__81d } else { tmp2 = fncls__81 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else { var tmp3 any; var and__1927000168__auto____3 any = A_arbace_pprint_A_const_318.Invoke_O__O(params__0)

		if jrt.A2g_Truth(and__1927000168__auto____3) { tmp3 = A_arbace_pprint_A_const_332.Invoke_O__O(params__0) } else { tmp3 = and__1927000168__auto____3 }
//line :1367:1
		if jrt.A2g_Truth(tmp3) { var tmp4 any = A_arbace_pprint_fn__1819000352_fn__1819000355_A_New(); var tmp5 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_pprint_fn__1819000352_fn__1819000355_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_pprint_fn__1819000352_fn__1819000355_A_fn_class = fncls__82d; tmp5 = fncls__82d } else { tmp5 = fncls__82 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else { if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { var tmp6 any = A_arbace_pprint_fn__1819000352_fn__1819000357_A_New(); var tmp7 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_pprint_fn__1819000352_fn__1819000357_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_pprint_fn__1819000352_fn__1819000357_A_fn_class = fncls__83d; tmp7 = fncls__83d } else { tmp7 = fncls__83 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) } else { if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { var tmp8 any = A_arbace_pprint_fn__1819000352_fn__1819000359_A_New(); var tmp9 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_pprint_fn__1819000352_fn__1819000359_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_pprint_fn__1819000352_fn__1819000359_A_fn_class = fncls__84d; tmp9 = fncls__84d } else { tmp9 = fncls__84 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil) } else { var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp10.Ref()) { var tmp11 any = A_arbace_pprint_fn__1819000352_fn__1819000361_A_New(); var tmp12 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_pprint_fn__1819000352_fn__1819000361_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_pprint_fn__1819000352_fn__1819000361_A_fn_class = fncls__85d; tmp12 = fncls__85d } else { tmp12 = fncls__85 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil) } else { return nil } } } } } }
//line :1327:1
func A_arbace_pprint_fn__1819000364_A_New() *A_arbace_pprint_fn__1819000364_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000364_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000364_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000364_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {

















































	var tmp1 any = A_arbace_pprint_fn__1819000364_fn__1819000365_A_New(); var tmp2 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_pprint_fn__1819000364_fn__1819000365_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_pprint_fn__1819000364_fn__1819000365_A_fn_class = fncls__86d; tmp2 = fncls__86d } else { tmp2 = fncls__86 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000371_A_New() *A_arbace_pprint_fn__1819000371_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000371_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000371_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000371_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {



























































	if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { return A_arbace_pprint_A_const_460.GetRawRoot__O() } else { if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { return A_arbace_pprint_A_const_461.GetRawRoot__O() } else { if A_arbace_pprint_A_const_95 != nil { return A_arbace_pprint_A_const_462.GetRawRoot__O() } else { return nil } } } }
//line :1327:1
func A_arbace_pprint_fn__1819000373_A_New() *A_arbace_pprint_fn__1819000373_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000373_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000373_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000373_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return A_arbace_pprint_A_const_406.GetRawRoot__O() }
//line :1327:1
func A_arbace_pprint_fn__1819000375_A_New() *A_arbace_pprint_fn__1819000375_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000375_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000375_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000375_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return A_arbace_pprint_A_const_407.GetRawRoot__O() }
//line :1327:1
func A_arbace_pprint_fn__1819000377_A_New() *A_arbace_pprint_fn__1819000377_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000377_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000377_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000377_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return A_arbace_pprint_A_const_463.GetRawRoot__O() }
//line :1327:1
func A_arbace_pprint_fn__1819000379_A_New() *A_arbace_pprint_fn__1819000379_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000379_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000379_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000379_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return A_arbace_pprint_A_const_464.GetRawRoot__O() }
//line :1327:1
func A_arbace_pprint_fn__1819000381_A_New() *A_arbace_pprint_fn__1819000381_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000381_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000381_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000381_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {




























































































	var tmp1 any = A_arbace_pprint_fn__1819000381_fn__1819000382_A_New(); var tmp2 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_pprint_fn__1819000381_fn__1819000382_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_pprint_fn__1819000381_fn__1819000382_A_fn_class = fncls__87d; tmp2 = fncls__87d } else { tmp2 = fncls__87 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000385_A_New() *A_arbace_pprint_fn__1819000385_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000385_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000385_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000385_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {




































































































	var tmp1 any = A_arbace_pprint_fn__1819000385_fn__1819000386_A_New(); var tmp2 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_pprint_fn__1819000385_fn__1819000386_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_pprint_fn__1819000385_fn__1819000386_A_fn_class = fncls__88d; tmp2 = fncls__88d } else { tmp2 = fncls__88 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000389_A_New() *A_arbace_pprint_fn__1819000389_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000389_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000389_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000389_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {














































































































	var tmp1 any = A_arbace_pprint_fn__1819000389_fn__1819000390_A_New(); var tmp2 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_pprint_fn__1819000389_fn__1819000390_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_pprint_fn__1819000389_fn__1819000390_A_fn_class = fncls__89d; tmp2 = fncls__89d } else { tmp2 = fncls__89 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000393_A_New() *A_arbace_pprint_fn__1819000393_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000393_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000393_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000393_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {






















































































































	var tmp1 any = A_arbace_pprint_fn__1819000393_fn__1819000394_A_New(); var tmp2 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_pprint_fn__1819000393_fn__1819000394_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_pprint_fn__1819000393_fn__1819000394_A_fn_class = fncls__90d; tmp2 = fncls__90d } else { tmp2 = fncls__90 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000397_A_New() *A_arbace_pprint_fn__1819000397_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000397_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000397_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000397_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {






























































































































	var tmp1 any = A_arbace_pprint_fn__1819000397_fn__1819000398_A_New(); var tmp2 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_pprint_fn__1819000397_fn__1819000398_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_pprint_fn__1819000397_fn__1819000398_A_fn_class = fncls__91d; tmp2 = fncls__91d } else { tmp2 = fncls__91 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000401_A_New() *A_arbace_pprint_fn__1819000401_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000401_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000401_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000401_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {






































































































































	if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { var tmp1 any = A_arbace_pprint_fn__1819000401_fn__1819000402_A_New(); var tmp2 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_pprint_fn__1819000401_fn__1819000402_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_pprint_fn__1819000401_fn__1819000402_A_fn_class = fncls__92d; tmp2 = fncls__92d } else { tmp2 = fncls__92 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else { var tmp3 any = A_arbace_pprint_fn__1819000401_fn__1819000404_A_New(); var tmp4 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_pprint_fn__1819000401_fn__1819000404_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_pprint_fn__1819000401_fn__1819000404_A_fn_class = fncls__93d; tmp4 = fncls__93d } else { tmp4 = fncls__93 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) } }
//line :1327:1
func A_arbace_pprint_fn__1819000407_A_New() *A_arbace_pprint_fn__1819000407_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000407_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000407_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000407_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {













































































































































	if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) {
		var tmp1 any = A_arbace_pprint_fn__1819000407_fn__1819000408_A_New(); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_pprint_fn__1819000407_fn__1819000408_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_pprint_fn__1819000407_fn__1819000408_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else {


			var tmp3 any = A_arbace_pprint_fn__1819000407_fn__1819000410_A_New(); var tmp4 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_pprint_fn__1819000407_fn__1819000410_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_pprint_fn__1819000407_fn__1819000410_A_fn_class = fncls__95d; tmp4 = fncls__95d } else { tmp4 = fncls__95 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) } }
//line :1327:1
func A_arbace_pprint_fn__1819000413_A_New() *A_arbace_pprint_fn__1819000413_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000413_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000413_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000413_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {
























































































































































	if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) {
		var tmp1 any = A_arbace_pprint_fn__1819000413_fn__1819000414_A_New(); var tmp2 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_pprint_fn__1819000413_fn__1819000414_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_pprint_fn__1819000413_fn__1819000414_A_fn_class = fncls__96d; tmp2 = fncls__96d } else { tmp2 = fncls__96 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else {


			var tmp3 any = A_arbace_pprint_fn__1819000413_fn__1819000419_A_New(); var tmp4 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_pprint_fn__1819000413_fn__1819000419_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); A_arbace_pprint_fn__1819000413_fn__1819000419_A_fn_class = fncls__97d; tmp4 = fncls__97d } else { tmp4 = fncls__97 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) } }
//line :1327:1
func A_arbace_pprint_fn__1819000428_A_New() *A_arbace_pprint_fn__1819000428_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000428_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000428_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000428_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { var mod_case_writer__3 any; var tmp1 any; var and__1927000168__auto____3 any = A_arbace_pprint_A_const_318.Invoke_O__O(params__0); if








































































































































































	jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = A_arbace_pprint_A_const_332.Invoke_O__O(params__0) } else { tmp1 = and__1927000168__auto____3 }; if /*line :1495:1*/ jrt.A2g_Truth(tmp1) { mod_case_writer__3 = A_arbace_pprint_A_const_471.GetRawRoot__O() } else { if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { mod_case_writer__3 = A_arbace_pprint_A_const_472.GetRawRoot__O() } else { if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { mod_case_writer__3 = A_arbace_pprint_A_const_473.GetRawRoot__O() } else { if A_arbace_pprint_A_const_95 != nil { mod_case_writer__3 = A_arbace_pprint_A_const_474.GetRawRoot__O() } else { mod_case_writer__3 = nil } } } }; var tmp2 any = A_arbace_pprint_fn__1819000428_fn__1819000429_A_New_O(mod_case_writer__3); var tmp3 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_pprint_fn__1819000428_fn__1819000429_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_pprint_fn__1819000428_fn__1819000429_A_fn_class = fncls__98d; tmp3 = fncls__98d } else { tmp3 = fncls__98 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000432_A_New() *A_arbace_pprint_fn__1819000432_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000432_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000432_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000432_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return nil }
//line :1327:1
func A_arbace_pprint_fn__1819000434_A_New() *A_arbace_pprint_fn__1819000434_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000434_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000434_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000434_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {


























































































































































































	if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { return A_arbace_pprint_A_const_476.GetRawRoot__O() } else { if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { return A_arbace_pprint_A_const_477.GetRawRoot__O() } else { var tmp1 *jrt.Boolean; jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp1.Ref()) { return A_arbace_pprint_A_const_478.GetRawRoot__O() } else { return nil } } } }
//line :1327:1
func A_arbace_pprint_fn__1819000436_A_New() *A_arbace_pprint_fn__1819000436_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000436_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000436_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000436_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return nil }
//line :1327:1
func A_arbace_pprint_fn__1819000438_A_New() *A_arbace_pprint_fn__1819000438_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000438_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000438_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000438_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return nil }
//line :1327:1
func A_arbace_pprint_fn__1819000440_A_New() *A_arbace_pprint_fn__1819000440_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000440_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000440_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000440_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {












































































































































































































	var tmp1 any; var and__1927000168__auto____3 any = A_arbace_pprint_A_const_318.Invoke_O__O(params__0)
	if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = A_arbace_pprint_A_const_332.Invoke_O__O(params__0) } else { tmp1 = and__1927000168__auto____3 }
//line :1532:1
	if jrt.A2g_Truth(tmp1) { return A_arbace_pprint_A_const_479.GetRawRoot__O() } else { if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { return A_arbace_pprint_A_const_480.GetRawRoot__O() } else { if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { return A_arbace_pprint_A_const_481.GetRawRoot__O() } else { var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp2.Ref()) { return A_arbace_pprint_A_const_482.GetRawRoot__O() } else { return nil } } } } }
//line :1327:1
func A_arbace_pprint_fn__1819000442_A_New() *A_arbace_pprint_fn__1819000442_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000442_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000442_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000442_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return nil }
//line :1327:1
func A_arbace_pprint_fn__1819000444_A_New() *A_arbace_pprint_fn__1819000444_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000444_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000444_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000444_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return A_arbace_pprint_A_const_483.GetRawRoot__O() }
//line :1327:1
func A_arbace_pprint_fn__1819000446_A_New() *A_arbace_pprint_fn__1819000446_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000446_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000446_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000446_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return nil }
//line :1327:1
func A_arbace_pprint_fn__1819000448_A_New() *A_arbace_pprint_fn__1819000448_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000448_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000448_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000448_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {






































































































































































































































	var tmp1 any = A_arbace_pprint_fn__1819000448_fn__1819000449_A_New(); var tmp2 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_pprint_fn__1819000448_fn__1819000449_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_pprint_fn__1819000448_fn__1819000449_A_fn_class = fncls__99d; tmp2 = fncls__99d } else { tmp2 = fncls__99 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :1327:1
func A_arbace_pprint_fn__1819000452_A_New() *A_arbace_pprint_fn__1819000452_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000452_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000452_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000452_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any {






























































































































































































































































	var tmp1 any; var or__1927000174__auto____3 any = A_arbace_pprint_A_const_318.Invoke_O__O(params__0); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = A_arbace_pprint_A_const_332.Invoke_O__O(params__0) }; if jrt.A2g_Truth(tmp1) { var bindings__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()); var tmp3 any

		if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__0)) { tmp3 = A_arbace_pprint_A_const_488 } else { lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY.Ref() }
//line :1583:1
		var tmp4 any = tmp3; var tmp5 any

		if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__0)) { tmp5 = A_arbace_pprint_A_const_489 } else { lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY.Ref() }
//line :1583:1
		bindings__3 = tmp2.Invoke_O_O__O(tmp4, tmp5)


		var tmp6 any = A_arbace_pprint_fn__1819000452_fn__1819000453_A_New_O(bindings__3); var tmp7 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_pprint_fn__1819000452_fn__1819000453_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_pprint_fn__1819000452_fn__1819000453_A_fn_class = fncls__100d; tmp7 = fncls__100d } else { tmp7 = fncls__100 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) } else {




			var tmp8 any = A_arbace_pprint_fn__1819000452_fn__1819000458_A_New(); var tmp9 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_pprint_fn__1819000452_fn__1819000458_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_pprint_fn__1819000452_fn__1819000458_A_fn_class = fncls__101d; tmp9 = fncls__101d } else { tmp9 = fncls__101 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil) } }
//line :1327:1
func A_arbace_pprint_fn__1819000464_A_New() *A_arbace_pprint_fn__1819000464_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000464_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000464_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000464_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return A_arbace_pprint_A_const_490.GetRawRoot__O() }
//line :1327:1
func A_arbace_pprint_fn__1819000466_A_New() *A_arbace_pprint_fn__1819000466_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000466_A{}; t.Ctor(); return t }
//line :1327:1
func (t *A_arbace_pprint_fn__1819000466_A) Ctor() {}
//line :1327:1
func (t *A_arbace_pprint_fn__1819000466_A) Invoke_O_O_O__O(self, params__0, offset__1 any) any { return A_arbace_pprint_A_const_491.GetRawRoot__O() }







































func A_arbace_pprint_fn__1819000352_fn__1819000353_A_New() *A_arbace_pprint_fn__1819000352_fn__1819000353_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000352_fn__1819000353_A{}; t.Ctor(); return t }
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000353_A) Ctor() {}
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000353_A) Invoke_O_O_O_O__O(self, p1__1819000304_SHARP___1, p2__1819000305_SHARP___2, p3__1819000306_SHARP___3 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_344.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_A_const_50.Invoke_O__O(p1__1819000304_SHARP___1), p1__1819000304_SHARP___1, p2__1819000305_SHARP___2, p3__1819000306_SHARP___3) }
//line :1367:1
func A_arbace_pprint_fn__1819000352_fn__1819000355_A_New() *A_arbace_pprint_fn__1819000352_fn__1819000355_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000352_fn__1819000355_A{}; t.Ctor(); return t }
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000355_A) Ctor() {}
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000355_A) Invoke_O_O_O_O__O(self, p1__1819000307_SHARP___1, p2__1819000308_SHARP___2, p3__1819000309_SHARP___3 any) any {

	return lang.IFn_Cast(A_arbace_pprint_A_const_454.GetRawRoot__O()).Invoke_O_O_O__O(p1__1819000307_SHARP___1, p2__1819000308_SHARP___2, p3__1819000309_SHARP___3) }
//line :1367:1
func A_arbace_pprint_fn__1819000352_fn__1819000357_A_New() *A_arbace_pprint_fn__1819000352_fn__1819000357_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000352_fn__1819000357_A{}; t.Ctor(); return t }
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000357_A) Ctor() {}
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000357_A) Invoke_O_O_O_O__O(self, p1__1819000310_SHARP___1, p2__1819000311_SHARP___2, p3__1819000312_SHARP___3 any) any {


	return lang.IFn_Cast(A_arbace_pprint_A_const_455.GetRawRoot__O()).Invoke_O_O_O__O(p1__1819000310_SHARP___1, p2__1819000311_SHARP___2, p3__1819000312_SHARP___3) }
//line :1367:1
func A_arbace_pprint_fn__1819000352_fn__1819000359_A_New() *A_arbace_pprint_fn__1819000352_fn__1819000359_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000352_fn__1819000359_A{}; t.Ctor(); return t }
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000359_A) Ctor() {}
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000359_A) Invoke_O_O_O_O__O(self, p1__1819000313_SHARP___1, p2__1819000314_SHARP___2, p3__1819000315_SHARP___3 any) any {



	return lang.IFn_Cast(A_arbace_pprint_A_const_456.GetRawRoot__O()).Invoke_O_O_O__O(p1__1819000313_SHARP___1, p2__1819000314_SHARP___2, p3__1819000315_SHARP___3) }
//line :1367:1
func A_arbace_pprint_fn__1819000352_fn__1819000361_A_New() *A_arbace_pprint_fn__1819000352_fn__1819000361_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000352_fn__1819000361_A{}; t.Ctor(); return t }
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000361_A) Ctor() {}
//line :1367:1
func (t *A_arbace_pprint_fn__1819000352_fn__1819000361_A) Invoke_O_O_O_O__O(self, p1__1819000316_SHARP___1, p2__1819000317_SHARP___2, p3__1819000318_SHARP___3 any) any {




	return lang.IFn_Cast(A_arbace_pprint_A_const_457.GetRawRoot__O()).Invoke_O_O_O__O(p1__1819000316_SHARP___1, p2__1819000317_SHARP___2, p3__1819000318_SHARP___3)
}



func A_arbace_pprint_fn__1819000364_fn__1819000365_A_New() *A_arbace_pprint_fn__1819000364_fn__1819000365_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000364_fn__1819000365_A{}; t.Ctor(); return t }
//line :1377:1
func (t *A_arbace_pprint_fn__1819000364_fn__1819000365_A) Ctor() {}
//line :1377:1
func (t *A_arbace_pprint_fn__1819000364_fn__1819000365_A) Invoke_O_O_O_O__O(self, params__1, navigator__2, offsets__3 any) any { var navigator__4 any; if
																jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__1)) { navigator__4 = lang.IFn_Cast(A_arbace_pprint_A_const_303.GetRawRoot__O()).Invoke_O_O__O(navigator__2, A_arbace_pprint_A_const_159) } else { navigator__4 = navigator__2 }; var strs__5 any; if
																jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__1)) { strs__5 = A_arbace_pprint_A_const_458 } else { strs__5 = A_arbace_pprint_A_const_459 }; var vec__1819000366__6 any = /*line :1377:1*/lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__4); var arg__7 any = lang.RT_Nth_O_I_O__O(vec__1819000366__6, lang.RT_IntCast_J__I(0), nil); var navigator__8 any = lang.RT_Nth_O_I_O__O(vec__1819000366__6, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()); var tmp2 any; if



	lang.Util_Equiv_O_J__Z(arg__7, 1) { tmp2 = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(strs__5) } else { tmp2 = lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(strs__5) }; tmp1.Invoke_O__O(tmp2); return navigator__8 }






































func A_arbace_pprint_fn__1819000381_fn__1819000382_A_New() *A_arbace_pprint_fn__1819000381_fn__1819000382_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000381_fn__1819000382_A{}; t.Ctor(); return t }
//line :1420:1
func (t *A_arbace_pprint_fn__1819000381_fn__1819000382_A) Ctor() {}
//line :1420:1
func (t *A_arbace_pprint_fn__1819000381_fn__1819000382_A) Invoke_O_O_O_O__O(self, params__1, arg_navigator__2, offsets__3 any) any { var n__1927000701__auto____4 int64 = lang.RT_LongCast_O__J(A_arbace_pprint_A_const_465.Invoke_O__O(params__1)); var i__5 int64 = 0; L1: for {
																	if lang.Numbers_Lt_J_J__Z(i__5, n__1927000701__auto____4) {
																		lang.IFn_Cast(A_arbace_pprint_A_const_232.GetRawRoot__O()).Invoke__O()
//line :1421:1
		i__5 = lang.Numbers_Unchecked_inc_J__J(i__5); continue L1 }
//line :1420:1
	break L1 }; return arg_navigator__2 }







func A_arbace_pprint_fn__1819000385_fn__1819000386_A_New() *A_arbace_pprint_fn__1819000385_fn__1819000386_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000385_fn__1819000386_A{}; t.Ctor(); return t }
//line :1428:1
func (t *A_arbace_pprint_fn__1819000385_fn__1819000386_A) Ctor() {}
//line :1428:1
func (t *A_arbace_pprint_fn__1819000385_fn__1819000386_A) Invoke_O_O_O_O__O(self, params__1, arg_navigator__2, offsets__3 any) any { var cnt__4 any = A_arbace_pprint_A_const_465.Invoke_O__O(params__1); if

	lang.Numbers_IsPos_O__Z(cnt__4) { lang.IFn_Cast(A_arbace_pprint_A_const_466.GetRawRoot__O()).Invoke__O() }; var n__1927000701__auto____5 int64 = /*line :1428:1*/lang.RT_LongCast_O__J(lang.Numbers_Dec_O__Number(cnt__4)); var i__6 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z(i__6, n__1927000701__auto____5) {
			lang.IFn_Cast(A_arbace_pprint_A_const_232.GetRawRoot__O()).Invoke__O()
//line :1431:1
			i__6 = lang.Numbers_Unchecked_inc_J__J(i__6); continue L1 }
//line :1428:1
		break L1 }; return arg_navigator__2 }









func A_arbace_pprint_fn__1819000389_fn__1819000390_A_New() *A_arbace_pprint_fn__1819000389_fn__1819000390_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000389_fn__1819000390_A{}; t.Ctor(); return t }
//line :1438:1
func (t *A_arbace_pprint_fn__1819000389_fn__1819000390_A) Ctor() {}
//line :1438:1
func (t *A_arbace_pprint_fn__1819000389_fn__1819000390_A) Invoke_O_O_O_O__O(self, params__1, arg_navigator__2, offsets__3 any) any { var n__1927000701__auto____4 int64 = lang.RT_LongCast_O__J(A_arbace_pprint_A_const_465.Invoke_O__O(params__1)); var i__5 int64 = 0; L1: for {
																	if lang.Numbers_Lt_J_J__Z(i__5, n__1927000701__auto____4) {
																		lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_467)
//line :1439:1
		i__5 = lang.Numbers_Unchecked_inc_J__J(i__5); continue L1 }
//line :1438:1
	break L1 }; return arg_navigator__2 }







func A_arbace_pprint_fn__1819000393_fn__1819000394_A_New() *A_arbace_pprint_fn__1819000393_fn__1819000394_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000393_fn__1819000394_A{}; t.Ctor(); return t }
//line :1446:1
func (t *A_arbace_pprint_fn__1819000393_fn__1819000394_A) Ctor() {}
//line :1446:1
func (t *A_arbace_pprint_fn__1819000393_fn__1819000394_A) Invoke_O_O_O_O__O(self, params__1, arg_navigator__2, offsets__3 any) any { var n__4 any = A_arbace_pprint_A_const_408.Invoke_O__O(params__1);

	lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_147.GetRawRoot__O()).Invoke_O_O__O(n__4, A_arbace_pprint_A_const_468))); return arg_navigator__2 }





func A_arbace_pprint_fn__1819000397_fn__1819000398_A_New() *A_arbace_pprint_fn__1819000397_fn__1819000398_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000397_fn__1819000398_A{}; t.Ctor(); return t }
//line :1454:1
func (t *A_arbace_pprint_fn__1819000397_fn__1819000398_A) Ctor() {}
//line :1454:1
func (t *A_arbace_pprint_fn__1819000397_fn__1819000398_A) Invoke_O_O_O_O__O(self, params__1, arg_navigator__2, offsets__3 any) any {
	if jrt.A2g_Truth(A_arbace_pprint_A_const_318.Invoke_O__O(params__1)) {
		lang.IFn_Cast(A_arbace_pprint_A_const_232.GetRawRoot__O()).Invoke__O() }
//line :1454:1
	return arg_navigator__2
}






func A_arbace_pprint_fn__1819000401_fn__1819000402_A_New() *A_arbace_pprint_fn__1819000401_fn__1819000402_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000401_fn__1819000402_A{}; t.Ctor(); return t }
//line :1462:1
func (t *A_arbace_pprint_fn__1819000401_fn__1819000402_A) Ctor() {}
//line :1462:1
func (t *A_arbace_pprint_fn__1819000401_fn__1819000402_A) Invoke_O_O_O_O__O(self, p1__1819000319_SHARP___1, p2__1819000320_SHARP___2, p3__1819000321_SHARP___3 any) any {
	return lang.IFn_Cast(A_arbace_pprint_A_const_469.GetRawRoot__O()).Invoke_O_O_O__O(p1__1819000319_SHARP___1, p2__1819000320_SHARP___2, p3__1819000321_SHARP___3) }
//line :1462:1
func A_arbace_pprint_fn__1819000401_fn__1819000404_A_New() *A_arbace_pprint_fn__1819000401_fn__1819000404_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000401_fn__1819000404_A{}; t.Ctor(); return t }
//line :1462:1
func (t *A_arbace_pprint_fn__1819000401_fn__1819000404_A) Ctor() {}
//line :1462:1
func (t *A_arbace_pprint_fn__1819000401_fn__1819000404_A) Invoke_O_O_O_O__O(self, p1__1819000322_SHARP___1, p2__1819000323_SHARP___2, p3__1819000324_SHARP___3 any) any {

	return lang.IFn_Cast(A_arbace_pprint_A_const_470.GetRawRoot__O()).Invoke_O_O_O__O(p1__1819000322_SHARP___1, p2__1819000323_SHARP___2, p3__1819000324_SHARP___3)
}




func A_arbace_pprint_fn__1819000407_fn__1819000408_A_New() *A_arbace_pprint_fn__1819000407_fn__1819000408_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000407_fn__1819000408_A{}; t.Ctor(); return t }
//line :1470:1
func (t *A_arbace_pprint_fn__1819000407_fn__1819000408_A) Ctor() {}
//line :1470:1
func (t *A_arbace_pprint_fn__1819000407_fn__1819000408_A) Invoke_O_O_O_O__O(self, params__1, navigator__2, offsets__3 any) any { var n__4 any; var or__1927000174__auto____4 any = A_arbace_pprint_A_const_408.Invoke_O__O(params__1); if
																jrt.A2g_Truth(or__1927000174__auto____4) { n__4 = or__1927000174__auto____4 } else { n__4 = A_arbace_pprint_A_const_28 }; return /*line :1472:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_304.GetRawRoot__O()).Invoke_O_O__O(navigator__2, n__4) }
func A_arbace_pprint_fn__1819000407_fn__1819000410_A_New() *A_arbace_pprint_fn__1819000407_fn__1819000410_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000407_fn__1819000410_A{}; t.Ctor(); return t }
//line :1473:1
func (t *A_arbace_pprint_fn__1819000407_fn__1819000410_A) Ctor() {}
//line :1473:1
func (t *A_arbace_pprint_fn__1819000407_fn__1819000410_A) Invoke_O_O_O_O__O(self, params__1, navigator__2, offsets__3 any) any { var n__4 any; var or__1927000174__auto____4 any = A_arbace_pprint_A_const_408.Invoke_O__O(params__1); if
																jrt.A2g_Truth(or__1927000174__auto____4) { n__4 = or__1927000174__auto____4 } else { n__4 = A_arbace_pprint_A_const_176 }; var tmp1 lang.IFn =
																lang.IFn_Cast(A_arbace_pprint_A_const_303.GetRawRoot__O()); var tmp2 any; if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__1)) { tmp2 = lang.Numbers_Minus_O__Number(n__4) } else { tmp2 = n__4 }; return tmp1.Invoke_O_O__O(navigator__2, tmp2) }





func A_arbace_pprint_fn__1819000413_fn__1819000414_A_New() *A_arbace_pprint_fn__1819000413_fn__1819000414_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000413_fn__1819000414_A{}; t.Ctor(); return t }
//line :1481:1
func (t *A_arbace_pprint_fn__1819000413_fn__1819000414_A) Ctor() {}
//line :1481:1
func (t *A_arbace_pprint_fn__1819000413_fn__1819000414_A) Invoke_O_O_O_O__O(self, params__1, navigator__2, offsets__3 any) any { var vec__1819000415__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_413.GetRawRoot__O()).Invoke_O__O(navigator__2); var subformat__5 any = lang.RT_Nth_O_I_O__O(vec__1819000415__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000415__4, lang.RT_IntCast_J__I(1), nil); return /*line :1483:1*/ lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(subformat__5, navigator__6, A_arbace_pprint_A_const_375.Invoke_O__O(params__1)) }
func A_arbace_pprint_fn__1819000413_fn__1819000419_A_New() *A_arbace_pprint_fn__1819000413_fn__1819000419_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000413_fn__1819000419_A{}; t.Ctor(); return t }
//line :1484:1
func (t *A_arbace_pprint_fn__1819000413_fn__1819000419_A) Ctor() {}
//line :1484:1
func (t *A_arbace_pprint_fn__1819000413_fn__1819000419_A) Invoke_O_O_O_O__O(self, params__1, navigator__2, offsets__3 any) any { var vec__1819000420__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_413.GetRawRoot__O()).Invoke_O__O(navigator__2); var subformat__5 any = lang.RT_Nth_O_I_O__O(vec__1819000420__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000420__4, lang.RT_IntCast_J__I(1), nil); var vec__1819000423__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__6); var subargs__8 any = lang.RT_Nth_O_I_O__O(vec__1819000423__7, lang.RT_IntCast_J__I(0), nil); var navigator__9 any = lang.RT_Nth_O_I_O__O(vec__1819000423__7, lang.RT_IntCast_J__I(1), nil); var sub_navigator__10 any = lang.IFn_Cast(A_arbace_pprint_A_const_296.GetRawRoot__O()).Invoke_O__O(subargs__8);



	lang.IFn_Cast(A_arbace_pprint_A_const_411.GetRawRoot__O()).Invoke_O_O_O__O(subformat__5, sub_navigator__10, A_arbace_pprint_A_const_375.Invoke_O__O(params__1)); return navigator__9 }






func A_arbace_pprint_fn__1819000428_fn__1819000429_A_New_O(p0 any) *A_arbace_pprint_fn__1819000428_fn__1819000429_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000428_fn__1819000429_A{}; t.Ctor_O(p0); return t }
//line :1495:1
func (t *A_arbace_pprint_fn__1819000428_fn__1819000429_A) Ctor_O(c__mod_case_writer any) { t.F_mod_case_writer = c__mod_case_writer }
//line :1495:1
func (t *A_arbace_pprint_fn__1819000428_fn__1819000429_A) Invoke_O_O_O_O__O(self, p1__1819000325_SHARP___1, p2__1819000326_SHARP___2, p3__1819000327_SHARP___3 any) any {











	return lang.IFn_Cast(A_arbace_pprint_A_const_475.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_mod_case_writer, p1__1819000325_SHARP___1, p2__1819000326_SHARP___2, p3__1819000327_SHARP___3)
}

















































func A_arbace_pprint_fn__1819000448_fn__1819000449_A_New() *A_arbace_pprint_fn__1819000448_fn__1819000449_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000448_fn__1819000449_A{}; t.Ctor(); return t }
//line :1558:1
func (t *A_arbace_pprint_fn__1819000448_fn__1819000449_A) Ctor() {}
//line :1558:1
func (t *A_arbace_pprint_fn__1819000448_fn__1819000449_A) Invoke_O_O_O_O__O(self, params__1, navigator__2, offsets__3 any) any { var arg1__4 any = A_arbace_pprint_A_const_484.Invoke_O__O(params__1); var arg2__5 any = A_arbace_pprint_A_const_485.Invoke_O__O(params__1); var arg3__6 any = A_arbace_pprint_A_const_486.Invoke_O__O(params__1); var exit__7 any; if



	jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__1)) { exit__7 = A_arbace_pprint_A_const_369 } else { exit__7 = A_arbace_pprint_A_const_368 }; var tmp1 any; var and__1927000168__auto____8 any = arg1__4; if

	jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = arg2__5; if jrt.A2g_Truth(and__1927000168__auto____9) { tmp1 = arg3__6 } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 }; if /*line :1563:1*/ jrt.A2g_Truth(tmp1) {

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_405.GetRawRoot__O()).Invoke_O_O_O__O(arg1__4, arg2__5, arg3__6)) { return lang.Tuple_Create_O_O__IPersistentVector(exit__7, navigator__2) } else { return navigator__2 } } else {
//line :1563:1
			var tmp2 any
			var and__1927000168__auto____8_2 any = arg1__4


			if jrt.A2g_Truth(and__1927000168__auto____8_2) { tmp2 = arg2__5 } else { tmp2 = and__1927000168__auto____8_2 }
//line :1563:1
			if jrt.A2g_Truth(tmp2) {




				if lang.Util_Equiv_O_O__Z(arg1__4, arg2__5) { return lang.Tuple_Create_O_O__IPersistentVector(exit__7, navigator__2) } else { return navigator__2 } } else {
//line :1563:1
					if jrt.A2g_Truth(arg1__4) {







						if lang.Util_Equiv_O_J__Z(arg1__4, 0) { return lang.Tuple_Create_O_O__IPersistentVector(exit__7, navigator__2) } else { return navigator__2 } } else {
//line :1563:1
							var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp3.Ref()) {










								var tmp4 any; if jrt.A2g_Truth(A_arbace_pprint_A_const_332.Invoke_O__O(params__1)) {
									var tmp5 *lang.Keyword = A_arbace_pprint_A_const_300; tmp4 = lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_pprint_A_const_375.Invoke_O__O(params__1))) } else {
										tmp4 = lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_300.Invoke_O__O(navigator__2)) }
//line :1574:1
								if jrt.A2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(exit__7, navigator__2) } else { return navigator__2 } } else {
//line :1563:1
									return nil } } } } }






















func A_arbace_pprint_fn__1819000452_fn__1819000453_A_New_O(p0 any) *A_arbace_pprint_fn__1819000452_fn__1819000453_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000452_fn__1819000453_A{}; t.Ctor_O(p0); return t }
//line :1586:1
func (t *A_arbace_pprint_fn__1819000452_fn__1819000453_A) Ctor_O(c__bindings any) { t.F_bindings = c__bindings }
//line :1586:1
func (t *A_arbace_pprint_fn__1819000452_fn__1819000453_A) Invoke_O_O_O_O__O(self, params__1, navigator__2, offsets__3 any) any { var vec__1819000454__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__2); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000454__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000454__4, lang.RT_IntCast_J__I(1), nil); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_487.GetRawRoot__O(), arg__5, t.F_bindings)) { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_pprint_A_const_368, navigator__6) } else { return navigator__6 } }


func A_arbace_pprint_fn__1819000452_fn__1819000458_A_New() *A_arbace_pprint_fn__1819000452_fn__1819000458_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_fn__1819000452_fn__1819000458_A{}; t.Ctor(); return t }
//line :1591:1
func (t *A_arbace_pprint_fn__1819000452_fn__1819000458_A) Ctor() {}
//line :1591:1
func (t *A_arbace_pprint_fn__1819000452_fn__1819000458_A) Invoke_O_O_O_O__O(self, params__1, navigator__2, offsets__3 any) any { var vec__1819000459__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_302.GetRawRoot__O()).Invoke_O__O(navigator__2); var arg__5 any = lang.RT_Nth_O_I_O__O(vec__1819000459__4, lang.RT_IntCast_J__I(0), nil); var navigator__6 any = lang.RT_Nth_O_I_O__O(vec__1819000459__4, lang.RT_IntCast_J__I(1), nil); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_227.GetRawRoot__O()).Invoke_O__O(arg__5)) { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_pprint_A_const_368, navigator__6) } else { return navigator__6 } }
























func A_arbace_pprint_extract_param_A_New() *A_arbace_pprint_extract_param_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_extract_param_A{}; t.Ctor(); return t }
//line :1618:1
func (t *A_arbace_pprint_extract_param_A) Ctor() {}
//line :1618:1
func (t *A_arbace_pprint_extract_param_A) Invoke_O_O__O(self, p__1819000468__0 any) any { var vec__1819000469__2 any = p__1819000468__0; var s__3 any = lang.RT_Nth_O_I_O__O(vec__1819000469__2, lang.RT_IntCast_J__I(0), nil); var offset__4 any = lang.RT_Nth_O_I_O__O(vec__1819000469__2, lang.RT_IntCast_J__I(1), nil); var saw_comma__5 any = lang.RT_Nth_O_I_O__O(vec__1819000469__2, lang.RT_IntCast_J__I(2), nil); var m__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_426.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_493.GetRawRoot__O(), s__3); var param__7 any = lang.IFn_Cast(A_arbace_pprint_A_const_427.GetRawRoot__O()).Invoke_O__O(m__6); if


	jrt.A2g_Truth(param__7) { var token_str__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_494.GetRawRoot__O()).Invoke_O__O(m__6)); var remainder__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__3, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Matcher_Cast(m__6)).End__I()).Ref()); var new_offset__10 any = lang.Numbers_Add_O_J__Number(offset__4, int64(jrt.NN(jrt.Matcher_Cast(m__6)).End__I()))
		var tmp1 any = A_arbace_pprint_A_const_495


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.RT_Nth_O_I__O(remainder__9, lang.RT_IntCast_J__I(0)))).Ref())) { var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(token_str__8, offset__4); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Tuple_Create_O_O_O__IPersistentVector(remainder__9, new_offset__10, tmp3.Ref())) } else { var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(token_str__8, offset__4); var tmp5 any = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(remainder__9, A_arbace_pprint_A_const_176); var tmp6 any = lang.Numbers_Inc_O__Number(new_offset__10); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; return lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7.Ref())) } } else {


			if jrt.A2g_Truth(saw_comma__5) {
				return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(Lit_60, offset__4) } else {
//line :1628:1
					return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Tuple_Create_O_O__IPersistentVector(s__3, offset__4)) } } }



func A_arbace_pprint_extract_params_A_New() *A_arbace_pprint_extract_params_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_extract_params_A{}; t.Ctor(); return t }
//line :1632:1
func (t *A_arbace_pprint_extract_params_A) Ctor() {}
//line :1632:1
func (t *A_arbace_pprint_extract_params_A) Invoke_O_O_O__O(self, s__0, offset__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_496.GetRawRoot__O(); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O__O(tmp2, lang.Tuple_Create_O_O_O__IPersistentVector(s__0, offset__1, tmp3.Ref()))
}
func A_arbace_pprint_translate_param_A_New() *A_arbace_pprint_translate_param_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_translate_param_A{}; t.Ctor(); return t }
//line :1635:1
func (t *A_arbace_pprint_translate_param_A) Ctor() {}
//line :1635:1
func (t *A_arbace_pprint_translate_param_A) Invoke_O_O__O(self, p__1819000474__0 any) any { var vec__1819000475__2 any = p__1819000474__0; var p__3 any = lang.RT_Nth_O_I_O__O(vec__1819000475__2, lang.RT_IntCast_J__I(0), nil); var offset__4 any = lang.RT_Nth_O_I_O__O(vec__1819000475__2, lang.RT_IntCast_J__I(1), nil); var tmp1 any; if



	lang.Util_Equiv_J_J__Z(int64(jrt.NN(jrt.String_Cast(p__3)).Length__I()), 0) { tmp1 = nil } else { var tmp2 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z(int64(jrt.NN(jrt.String_Cast(p__3)).Length__I()), 1)

		if and__1927000168__auto____5 { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_219.GetRawRoot__O()); var tmp4 any = A_arbace_pprint_A_const_499; tmp2 = tmp3.Invoke_O_O__O(tmp4, lang.RT_Nth_O_I__O(p__3, lang.RT_IntCast_J__I(0))) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :1639:1
		if jrt.A2g_Truth(tmp2) { tmp1 = A_arbace_pprint_A_const_305 } else { var tmp5 bool; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_J_J__Z(int64(jrt.NN(jrt.String_Cast(p__3)).Length__I()), 1)


			if and__1927000168__auto____5_2 { var tmp6 any = A_arbace_pprint_A_const_497; tmp5 = lang.Util_Equiv_O_O__Z(tmp6, lang.RT_Nth_O_I__O(p__3, lang.RT_IntCast_J__I(0))) } else { tmp5 = and__1927000168__auto____5_2 }
//line :1639:1
			if tmp5 { tmp1 = A_arbace_pprint_A_const_306 } else { var tmp7 bool; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_J_J__Z(int64(jrt.NN(jrt.String_Cast(p__3)).Length__I()), 2)



				if and__1927000168__auto____5_3 { var tmp8 any = A_arbace_pprint_A_const_498; tmp7 = lang.Util_Equiv_O_O__Z(tmp8, lang.RT_Nth_O_I__O(p__3, lang.RT_IntCast_J__I(0))) } else { tmp7 = and__1927000168__auto____5_3 }
//line :1639:1
				if tmp7 {



					tmp1 = lang.RT_Nth_O_I__O(p__3, lang.RT_IntCast_J__I(1)) } else {
//line :1639:1
						var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp9.Ref()) {




							tmp1 = jrt.Integer_ValueOf_I__Integer(jrt.Integer_ParseInt_String__I(jrt.String_Cast(p__3))).Ref() } else {
//line :1639:1
								tmp1 = nil } } } } }; return /*line :1635:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, offset__4) }














func A_arbace_pprint_extract_flags_A_New() *A_arbace_pprint_extract_flags_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_extract_flags_A{}; t.Ctor(); return t }
//line :1650:1
func (t *A_arbace_pprint_extract_flags_A) Ctor() {}
//line :1650:1
func (t *A_arbace_pprint_extract_flags_A) Invoke_O_O_O__O(self, s__0, offset__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_extract_flags_fn__1819000480_A_New(); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_pprint_extract_flags_fn__1819000480_A_fn_class
	if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_pprint_extract_flags_fn__1819000480_A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }
//line :1651:1
	var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(s__0, offset__1, tmp5.Ref())) }
func A_arbace_pprint_extract_flags_fn__1819000480_A_New() *A_arbace_pprint_extract_flags_fn__1819000480_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_extract_flags_fn__1819000480_A{}; t.Ctor(); return t }
//line :1652:1
func (t *A_arbace_pprint_extract_flags_fn__1819000480_A) Ctor() {}
//line :1652:1
func (t *A_arbace_pprint_extract_flags_fn__1819000480_A) Invoke_O_O__O(self, p__1819000479__1 any) any { var vec__1819000481__2 any = p__1819000479__1; var s__3 any = lang.RT_Nth_O_I_O__O(vec__1819000481__2, lang.RT_IntCast_J__I(0), nil); var offset__4 any = lang.RT_Nth_O_I_O__O(vec__1819000481__2, lang.RT_IntCast_J__I(1), nil); var flags__5 any = lang.RT_Nth_O_I_O__O(vec__1819000481__2, lang.RT_IntCast_J__I(2), nil); if
													jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(s__3)) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Tuple_Create_O_O_O__IPersistentVector(s__3, offset__4, flags__5)) } else { var flag__6 any = lang.RT_Get_O_O__O(A_arbace_pprint_A_const_500.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__3))


		if jrt.A2g_Truth(flag__6) {
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_219.GetRawRoot__O()).Invoke_O_O__O(flags__5, flag__6)) {
				return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_58, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__3), nil)).Ref(), offset__4) } else {
//line :1657:1
					var tmp1 *jrt.Boolean; jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE; var tmp2 any = tmp1.Ref(); var tmp3 any = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__3, A_arbace_pprint_A_const_176); var tmp4 any = lang.Numbers_Inc_O__Number(offset__4); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_44.GetRawRoot__O()); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp4, tmp5.Invoke_O_O_O__O(flags__5, flag__6, lang.Tuple_Create_O_O__IPersistentVector(tmp6.Ref(), offset__4)))) } } else {
//line :1656:1
						return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Tuple_Create_O_O_O__IPersistentVector(s__3, offset__4, flags__5)) } } }








func A_arbace_pprint_check_flags_A_New() *A_arbace_pprint_check_flags_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_check_flags_A{}; t.Ctor(); return t }
//line :1665:1
func (t *A_arbace_pprint_check_flags_A) Ctor() {}
//line :1665:1
func (t *A_arbace_pprint_check_flags_A) Invoke_O_O_O__O(self, def__0, flags__1 any) any { var allowed__3 any = A_arbace_pprint_A_const_442.Invoke_O__O(def__0); var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_318.Invoke_O__O(allowed__3)); if

	jrt.A2g_Truth(and__1927000168__auto____4) { tmp1 = A_arbace_pprint_A_const_318.Invoke_O__O(flags__1) } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_22, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_pprint_A_const_441.Invoke_O__O(def__0), nil)).Ref(), lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_318.Invoke_O__O(flags__1), lang.RT_IntCast_J__I(1))) }; var tmp2 any; var and__1927000168__auto____4_2 any =

	lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_332.Invoke_O__O(allowed__3)); if jrt.A2g_Truth(and__1927000168__auto____4_2) { tmp2 = A_arbace_pprint_A_const_332.Invoke_O__O(flags__1) } else { tmp2 = and__1927000168__auto____4_2 }; if jrt.A2g_Truth(tmp2) {
		lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_pprint_A_const_441.Invoke_O__O(def__0), nil)).Ref(), lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_332.Invoke_O__O(flags__1), lang.RT_IntCast_J__I(1))) }; var tmp3 any; var and__1927000168__auto____4_3 any =

	lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_501.Invoke_O__O(allowed__3)); if jrt.A2g_Truth(and__1927000168__auto____4_3) { var and__1927000168__auto____5 any = A_arbace_pprint_A_const_318.Invoke_O__O(flags__1); if jrt.A2g_Truth(and__1927000168__auto____5) { tmp3 = A_arbace_pprint_A_const_332.Invoke_O__O(flags__1) } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4_3 }; if jrt.A2g_Truth(tmp3) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_25, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_pprint_A_const_441.Invoke_O__O(def__0), nil)).Ref(), lang.Numbers_Min_O_O__O(lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_332.Invoke_O__O(flags__1), lang.RT_IntCast_J__I(1)), lang.RT_Nth_O_I__O(A_arbace_pprint_A_const_318.Invoke_O__O(flags__1), lang.RT_IntCast_J__I(1)))) } else {
//line :1673:1
			return nil } }




func A_arbace_pprint_map_params_A_New() *A_arbace_pprint_map_params_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_map_params_A{}; t.Ctor(); return t }
//line :1678:1
func (t *A_arbace_pprint_map_params_A) Ctor() {}
//line :1678:1
func (t *A_arbace_pprint_map_params_A) Invoke_O_O_O_O_O__O(self, def__0, params__1, flags__2, offset__3 any) any {





	lang.IFn_Cast(A_arbace_pprint_A_const_502.GetRawRoot__O()).Invoke_O_O__O(def__0, flags__2)
	if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(params__1)), int64(lang.RT_Count_O__I(A_arbace_pprint_A_const_374.Invoke_O__O(def__0)))) {
		lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_365.GetRawRoot__O()).Invoke_O_O_O_O_O__O(nil, Lit_127, A_arbace_pprint_A_const_441.Invoke_O__O(def__0), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(params__1)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_pprint_A_const_374.Invoke_O__O(def__0))).Ref()), lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(params__1)))
	}




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_503.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_map_params_fn__1819000492_A_New_O(def__0); var tmp4 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_pprint_map_params_fn__1819000492_A_fn_class
	if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_pprint_map_params_fn__1819000492_A_fn_class = fncls__103d; tmp4 = fncls__103d } else { tmp4 = fncls__103 }
//line :1692:1
	tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), params__1, A_arbace_pprint_A_const_374.Invoke_O__O(def__0)))









	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_218.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_16.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_pprint_A_const_506.GetRawRoot__O()).Invoke__O(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_322.GetRawRoot__O()); var tmp9 any; var iter__1927001039__auto____5 any; var tmp10 any = A_arbace_pprint_map_params_iter__1819000494__1819000498_A_New_O(offset__3); var tmp11 *jrt.Class
	var fncls__106 /*line :1702:1*/*jrt.Class = A_arbace_pprint_map_params_iter__1819000494__1819000498_A_fn_class

	if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_pprint_map_params_iter__1819000494__1819000498_A_fn_class = fncls__106d; tmp11 = fncls__106d } else { tmp11 = fncls__106 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_pprint_A_const_374.Invoke_O__O(def__0))
//line :1702:1
	var tmp12 any = tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O__O(tmp9)); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_420.GetRawRoot__O()); var tmp14 any = A_arbace_pprint_map_params_fn__1819000516_A_New(); var tmp15 *jrt.Class
	var fncls__107 /*line :1702:1*/*jrt.Class = A_arbace_pprint_map_params_fn__1819000516_A_fn_class


	if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_pprint_map_params_fn__1819000516_A_fn_class = fncls__107d; tmp15 = fncls__107d } else { tmp15 = fncls__107 }
//line :1702:1
	var tmp16 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp17 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp17 = lang.PersistentArrayMap_EMPTY; var tmp18 any = tmp17.Ref(); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_58.GetRawRoot__O()); var tmp20 any = A_arbace_pprint_map_params_fn__1819000518_A_New(); var tmp21 *jrt.Class
	var fncls__108 /*line :1702:1*/*jrt.Class = A_arbace_pprint_map_params_fn__1819000518_A_fn_class


	if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_pprint_map_params_fn__1819000518_A_fn_class = fncls__108d; tmp21 = fncls__108d } else { tmp21 = fncls__108 }
//line :1702:1
	return tmp5.Invoke_O_O_O__O(tmp12, tmp13.Invoke_O_O_O__O(tmp16, tmp18, tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), lang.IFn_Cast(A_arbace_pprint_A_const_507.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_508.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_374.Invoke_O__O(def__0)), params__1))), flags__2) }
//line :1693:1
func A_arbace_pprint_map_params_fn__1819000492_A_New_O(p0 any) *A_arbace_pprint_map_params_fn__1819000492_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_map_params_fn__1819000492_A{}; t.Ctor_O(p0); return t }
//line :1693:1
func (t *A_arbace_pprint_map_params_fn__1819000492_A) Ctor_O(c__def any) { t.F_def = c__def }
//line :1693:1
func (t *A_arbace_pprint_map_params_fn__1819000492_A) Invoke_O_O_O__O(self, p1__1819000487_SHARP___1, p2__1819000488_SHARP___2 any) any { var val__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(p1__1819000487_SHARP___1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z(val__3, nil); if or__1927000174__auto____4 {
																	tmp2 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_pprint_A_const_219.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_505.GetRawRoot__O(), val__3); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else {
																		tmp2 = lang.IFn_Cast(A_arbace_pprint_A_const_504.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(p2__1819000488_SHARP___2)), val__3) } }; if /*line :1694:1*/ jrt.A2g_Truth(tmp1.Invoke_O__O(tmp2)) {

			return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_132, nil, Lit_133, nil, Lit_134, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_pprint_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(p2__1819000488_SHARP___2)), nil, A_arbace_pprint_A_const_441.Invoke_O__O(t.F_def), nil, lang.IFn_Cast(A_arbace_pprint_A_const_55.GetRawRoot__O()).Invoke_O__O(val__3))).Ref(), lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()).Invoke_O__O(p1__1819000487_SHARP___1)) } else {
//line :1694:1
				return nil } }









func A_arbace_pprint_map_params_iter__1819000494__1819000498_A_New_O(p0 any) *A_arbace_pprint_map_params_iter__1819000494__1819000498_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_map_params_iter__1819000494__1819000498_A{}; t.Ctor_O(p0); return t }
//line :1704:1
func (t *A_arbace_pprint_map_params_iter__1819000494__1819000498_A) Ctor_O(c__offset any) { t.F_offset = c__offset }
//line :1704:1
func (t *A_arbace_pprint_map_params_iter__1819000494__1819000498_A) Invoke_O_O__O(self, s__1819000495__1 any) any { var tmp1 any = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_New_O_O_O(s__1819000495__1, self, t.F_offset); var tmp2 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_fn_class = fncls__105d; tmp2 = fncls__105d } else { tmp2 = fncls__105 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1704:1
func A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_New_O_O_O(p0, p1, p2 any) *A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1704:1
func (t *A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A) Ctor_O_O_O(c__s__1819000495, c__iter__1819000494, c__offset any) { t.F_s__1819000495 = c__s__1819000495; t.F_iter__1819000494 = c__iter__1819000494; t.F_offset = c__offset }
//line :1704:1
func (t *A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A) Invoke_O__O(self any) any { { var s__1819000495__1 any; var t_ any = t.F_s__1819000495; t.F_s__1819000495 = nil; s__1819000495__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(s__1819000495__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1819000495__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_18.GetRawRoot__O()).Invoke_O__O(s__1819000495__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_19.GetRawRoot__O()).Invoke_O__O(s__1819000495__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1819000497__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_New_O_O_I_O(b__1819000497__6, t.F_offset, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_fn_class = fncls__104d; tmp2 = fncls__104d } else { tmp2 = fncls__104 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1819000494); return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1819000497__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1819000495__3))) } else { return lang.IFn_Cast(A_arbace_pprint_A_const_22.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_24.GetRawRoot__O()).Invoke_O__O(b__1819000497__6), nil) } } else { var vec__1819000508__4 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(s__1819000495__3); var name__5 any = lang.RT_Nth_O_I_O__O(vec__1819000508__4, lang.RT_IntCast_J__I(0), nil); var vec__1819000511__6 any = lang.RT_Nth_O_I_O__O(vec__1819000508__4, lang.RT_IntCast_J__I(1), nil); var default__7 any = lang.RT_Nth_O_I_O__O(vec__1819000511__6, lang.RT_IntCast_J__I(0), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1819000494); return lang.IFn_Cast(A_arbace_pprint_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(name__5, lang.Tuple_Create_O_O__IPersistentVector(default__7, t.F_offset)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_26.GetRawRoot__O()).Invoke_O__O(s__1819000495__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1704:1
func A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1704:1
func (t *A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A) Ctor_O_O_I_O(c__b__1819000497, c__offset any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1819000497 = c__b__1819000497; t.F_offset = c__offset; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1704:1
func (t *A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A) Invoke_O__O(self any) any { { var i__1819000496__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1819000496__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1819000501__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1819000496__1)); var name__3 any = lang.RT_Nth_O_I_O__O(vec__1819000501__2, lang.RT_IntCast_J__I(0), nil); var vec__1819000504__4 any = lang.RT_Nth_O_I_O__O(vec__1819000501__2, lang.RT_IntCast_J__I(1), nil); var default__5 any = lang.RT_Nth_O_I_O__O(vec__1819000504__4, lang.RT_IntCast_J__I(0), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_21.GetRawRoot__O()); var tmp3 any = t.F_b__1819000497; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(name__3, lang.Tuple_Create_O_O__IPersistentVector(default__5, t.F_offset))); i__1819000496__1 = lang.Numbers_Unchecked_inc_J__J(i__1819000496__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_pprint_map_params_fn__1819000516_A_New() *A_arbace_pprint_map_params_fn__1819000516_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_map_params_fn__1819000516_A{}; t.Ctor(); return t }
//line :1705:1
func (t *A_arbace_pprint_map_params_fn__1819000516_A) Ctor() {}
//line :1705:1
func (t *A_arbace_pprint_map_params_fn__1819000516_A) Invoke_O_O_O__O(self, p1__1819000489_SHARP___1, p2__1819000490_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_44.GetRawRoot__O(), p1__1819000489_SHARP___1, p2__1819000490_SHARP___2) }
//line :1705:1
func A_arbace_pprint_map_params_fn__1819000518_A_New() *A_arbace_pprint_map_params_fn__1819000518_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_map_params_fn__1819000518_A{}; t.Ctor(); return t }
//line :1705:1
func (t *A_arbace_pprint_map_params_fn__1819000518_A) Ctor() {}
//line :1705:1
func (t *A_arbace_pprint_map_params_fn__1819000518_A) Invoke_O_O__O(self, p1__1819000491_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(p1__1819000491_SHARP___1, lang.RT_IntCast_J__I(1))) }


func A_arbace_pprint_compile_directive_A_New() *A_arbace_pprint_compile_directive_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_compile_directive_A{}; t.Ctor(); return t }
//line :1708:1
func (t *A_arbace_pprint_compile_directive_A) Ctor() {}
//line :1708:1
func (t *A_arbace_pprint_compile_directive_A) Invoke_O_O_O__O(self, s__0, offset__1 any) any { var vec__1819000521__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_509.GetRawRoot__O()).Invoke_O_O__O(s__0, offset__1); var raw_params__4 any = lang.RT_Nth_O_I_O__O(vec__1819000521__3, lang.RT_IntCast_J__I(0), nil); var vec__1819000524__5 any = lang.RT_Nth_O_I_O__O(vec__1819000521__3, lang.RT_IntCast_J__I(1), nil); var rest__6 any = lang.RT_Nth_O_I_O__O(vec__1819000524__5, lang.RT_IntCast_J__I(0), nil); var offset__7 any = lang.RT_Nth_O_I_O__O(vec__1819000524__5, lang.RT_IntCast_J__I(1), nil); var vec__1819000527__8 any = lang.IFn_Cast(A_arbace_pprint_A_const_510.GetRawRoot__O()).Invoke_O_O__O(rest__6, offset__7); var ___9 any = lang.RT_Nth_O_I_O__O(vec__1819000527__8, lang.RT_IntCast_J__I(0), nil); var vec__1819000530__10 any = lang.RT_Nth_O_I_O__O(vec__1819000527__8, lang.RT_IntCast_J__I(1), nil); var rest__11 any = lang.RT_Nth_O_I_O__O(vec__1819000530__10, lang.RT_IntCast_J__I(0), nil); var offset__12 any = lang.RT_Nth_O_I_O__O(vec__1819000530__10, lang.RT_IntCast_J__I(1), nil); var flags__13 any = lang.RT_Nth_O_I_O__O(vec__1819000530__10, lang.RT_IntCast_J__I(2), nil); var directive__14 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(rest__11); var def__15 any = lang.RT_Get_O_O__O(A_arbace_pprint_A_const_511.GetRawRoot__O(), jrt.Character_ValueOf_C__Character(jrt.Character_ToUpperCase_C__C(jrt.NN(jrt.Character_Cast(directive__14)).CharValue__C())).Ref()); var params__16 any; _ = ___9; if




	jrt.A2g_Truth(def__15) { params__16 = lang.IFn_Cast(A_arbace_pprint_A_const_512.GetRawRoot__O()).Invoke_O_O_O_O__O(def__15, lang.IFn_Cast(A_arbace_pprint_A_const_149.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_513.GetRawRoot__O(), raw_params__4), flags__13, offset__12) } else { params__16 = nil }; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(directive__14)) {
		lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(Lit_39, offset__12) }; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(def__15)) {
		lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil, Lit_41), jrt.RefArrayOf(jrt.Object_class, nil, directive__14, nil)).Ref(), offset__12) }; var tmp1 any = /*line :1708:1*/lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_A_const_515.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_444.Invoke_O__O(def__15)).Invoke_O_O__O(params__16, offset__12), def__15, params__16, offset__12); var tmp2 lang.IPersistentVector; var remainder__17 any = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(rest__11, A_arbace_pprint_A_const_176); var offset__18 any = lang.Numbers_Inc_O__Number(offset__12); var trim_QMARK___19 any; var tmp3 any = A_arbace_pprint_A_const_51; var and__1927000168__auto____19 bool = lang.Util_Equiv_O_O__Z(tmp3, A_arbace_pprint_A_const_441.Invoke_O__O(def__15)); if and__1927000168__auto____19 {













			trim_QMARK___19 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_332.Invoke_O__O(params__16)) } else {
//line :1721:1
				trim_QMARK___19 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____19).Ref() }; var trim_count__20 any; if

	jrt.A2g_Truth(trim_QMARK___19) { trim_count__20 = lang.IFn_Cast(A_arbace_pprint_A_const_514.GetRawRoot__O()).Invoke_O_O__O(remainder__17, A_arbace_pprint_A_const_516) } else { trim_count__20 = A_arbace_pprint_A_const_28 }; var remainder__21 any = /*line :1708:1*/lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(remainder__17, trim_count__20); var offset__22 any = lang.Numbers_Add_O_O__Number(offset__18, trim_count__20); tmp2 = lang.Tuple_Create_O_O__IPersistentVector(remainder__21, offset__22); return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }



















func A_arbace_pprint_compile_raw_string_A_New() *A_arbace_pprint_compile_raw_string_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_compile_raw_string_A{}; t.Ctor(); return t }
//line :1728:1
func (t *A_arbace_pprint_compile_raw_string_A) Ctor() {}
//line :1728:1
func (t *A_arbace_pprint_compile_raw_string_A) Invoke_O_O_O__O(self, s__0, offset__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_515.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_compile_raw_string_fn__1819000534_A_New_O(s__0); var tmp4 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_pprint_compile_raw_string_fn__1819000534_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_pprint_compile_raw_string_fn__1819000534_A_fn_class = fncls__109d; tmp4 = fncls__109d } else { tmp4 = fncls__109 }; return tmp1.Invoke_O_O_O_O_O__O(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), nil, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_pprint_A_const_432, s__0)), offset__1) }
//line :1729:1
func A_arbace_pprint_compile_raw_string_fn__1819000534_A_New_O(p0 any) *A_arbace_pprint_compile_raw_string_fn__1819000534_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_compile_raw_string_fn__1819000534_A{}; t.Ctor_O(p0); return t }
//line :1729:1
func (t *A_arbace_pprint_compile_raw_string_fn__1819000534_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :1729:1
func (t *A_arbace_pprint_compile_raw_string_fn__1819000534_A) Invoke_O_O_O_O__O(self, ___1, a__2, ___3 any) any { lang.IFn_Cast(A_arbace_pprint_A_const_184.GetRawRoot__O()).Invoke_O__O(t.F_s); return a__2 }

func A_arbace_pprint_right_bracket_A_New() *A_arbace_pprint_right_bracket_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_right_bracket_A{}; t.Ctor(); return t }
//line :1731:1
func (t *A_arbace_pprint_right_bracket_A) Ctor() {}
//line :1731:1
func (t *A_arbace_pprint_right_bracket_A) Invoke_O_O__O(self, this__0 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_517; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_443; return tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_pprint_A_const_518.Invoke_O__O(this__0))) }
func A_arbace_pprint_separator_QMARK__A_New() *A_arbace_pprint_separator_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_separator_QMARK__A{}; t.Ctor(); return t }
//line :1732:1
func (t *A_arbace_pprint_separator_QMARK__A) Ctor() {}
//line :1732:1
func (t *A_arbace_pprint_separator_QMARK__A) Invoke_O_O__O(self, this__0 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_519; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_443; return tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_pprint_A_const_518.Invoke_O__O(this__0))) }
func A_arbace_pprint_else_separator_QMARK__A_New() *A_arbace_pprint_else_separator_QMARK__A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_else_separator_QMARK__A{}; t.Ctor(); return t }
//line :1733:1
func (t *A_arbace_pprint_else_separator_QMARK__A) Ctor() {}
//line :1733:1
func (t *A_arbace_pprint_else_separator_QMARK__A) Invoke_O_O__O(self, this__0 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_519; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_443; var and__1927000168__auto____2 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_pprint_A_const_518.Invoke_O__O(this__0))); if
											jrt.A2g_Truth(and__1927000168__auto____2) {
												var tmp3 *lang.Keyword = A_arbace_pprint_A_const_332; return tmp3.Invoke_O__O(A_arbace_pprint_A_const_374.Invoke_O__O(this__0)) } else {
//line :1734:1
			return and__1927000168__auto____2 } }





func A_arbace_pprint_process_bracket_A_New() *A_arbace_pprint_process_bracket_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_process_bracket_A{}; t.Ctor(); return t }
//line :1740:1
func (t *A_arbace_pprint_process_bracket_A) Ctor() {}
//line :1740:1
func (t *A_arbace_pprint_process_bracket_A) Invoke_O_O_O__O(self, this__0, remainder__1 any) any { var tmp1 *lang.Keyword = A_arbace_pprint_A_const_443; var vec__1819000540__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_520.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O__O(A_arbace_pprint_A_const_518.Invoke_O__O(this__0)), A_arbace_pprint_A_const_120.Invoke_O__O(this__0), remainder__1); var subex__4 any = lang.RT_Nth_O_I_O__O(vec__1819000540__3, lang.RT_IntCast_J__I(0), nil); var remainder__5 any = lang.RT_Nth_O_I_O__O(vec__1819000540__3, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_A_const_515.GetRawRoot__O(), A_arbace_pprint_A_const_376.Invoke_O__O(this__0), A_arbace_pprint_A_const_518.Invoke_O__O(this__0), lang.IFn_Cast(A_arbace_pprint_A_const_218.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_374.Invoke_O__O(this__0), lang.IFn_Cast(A_arbace_pprint_A_const_521.GetRawRoot__O()).Invoke_O_O__O(subex__4, A_arbace_pprint_A_const_120.Invoke_O__O(this__0))), A_arbace_pprint_A_const_120.Invoke_O__O(this__0)), remainder__5) }








func A_arbace_pprint_process_clause_A_New() *A_arbace_pprint_process_clause_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_process_clause_A{}; t.Ctor(); return t }
//line :1749:1
func (t *A_arbace_pprint_process_clause_A) Ctor() {}
//line :1749:1
func (t *A_arbace_pprint_process_clause_A) Invoke_O_O_O_O__O(self, bracket_info__0, offset__1, remainder__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_process_clause_fn__1819000544_A_New_O_O(bracket_info__0, offset__1); var tmp3 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_pprint_process_clause_fn__1819000544_A_fn_class
	if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_240, false); A_arbace_pprint_process_clause_fn__1819000544_A_fn_class = fncls__110d; tmp3 = fncls__110d } else { tmp3 = fncls__110 }
//line :1750:1
	return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), remainder__2) }
func A_arbace_pprint_process_clause_fn__1819000544_A_New_O_O(p0, p1 any) *A_arbace_pprint_process_clause_fn__1819000544_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_process_clause_fn__1819000544_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1751:1
func (t *A_arbace_pprint_process_clause_fn__1819000544_A) Ctor_O_O(c__bracket_info, c__offset any) { t.F_bracket_info = c__bracket_info; t.F_offset = c__offset }
//line :1751:1
func (t *A_arbace_pprint_process_clause_fn__1819000544_A) Invoke_O_O__O(self, remainder__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(remainder__1)) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(Lit_241, t.F_offset) } else {
//line :1752:1
			var this__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(remainder__1); var remainder__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(remainder__1)



			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_522.GetRawRoot__O()).Invoke_O__O(this__2)) {

				return lang.IFn_Cast(A_arbace_pprint_A_const_523.GetRawRoot__O()).Invoke_O_O__O(this__2, remainder__3) } else {
//line :1756:1
					var tmp1 *lang.Keyword = A_arbace_pprint_A_const_441; if lang.Util_Equiv_O_O__Z(A_arbace_pprint_A_const_517.Invoke_O__O(t.F_bracket_info), tmp1.Invoke_O__O(A_arbace_pprint_A_const_518.Invoke_O__O(this__2))) { var tmp2 any = A_arbace_pprint_A_const_526; return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, A_arbace_pprint_A_const_374.Invoke_O__O(this__2), nil, remainder__3)) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_524.GetRawRoot__O()).Invoke_O__O(this__2)) { var tmp3 any = A_arbace_pprint_A_const_95; return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp3, nil, A_arbace_pprint_A_const_374.Invoke_O__O(this__2), remainder__3)) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_525.GetRawRoot__O()).Invoke_O__O(this__2)) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_pprint_A_const_519, nil, nil, remainder__3)) } else { var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp4.Ref()) { return lang.Tuple_Create_O_O__IPersistentVector(this__2, remainder__3) } else { return nil
					}
					}
					}
					}
				}
		}
}









func A_arbace_pprint_collect_clauses_A_New() *A_arbace_pprint_collect_clauses_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_collect_clauses_A{}; t.Ctor(); return t }
//line :1773:1
func (t *A_arbace_pprint_collect_clauses_A) Ctor() {}
//line :1773:1
func (t *A_arbace_pprint_collect_clauses_A) Invoke_O_O_O_O__O(self, bracket_info__0, offset__1, remainder__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_370.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_collect_clauses_fn__1819000548_A_New_O_O(bracket_info__0, offset__1); var tmp4 *jrt.Class
	var fncls__111 /*line :1774:1*/*jrt.Class = A_arbace_pprint_collect_clauses_fn__1819000548_A_fn_class

	if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_pprint_collect_clauses_fn__1819000548_A_fn_class = fncls__111d; tmp4 = fncls__111d } else { tmp4 = fncls__111 }
//line :1774:1
	var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any = A_arbace_pprint_A_const_410; var tmp7 *lang.PersistentVector; lang.PersistentVector_Init(); tmp7 = lang.PersistentVector_EMPTY; var tmp8 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7.Ref())); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp5, lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9.Ref(), remainder__2)))
}
func A_arbace_pprint_collect_clauses_fn__1819000548_A_New_O_O(p0, p1 any) *A_arbace_pprint_collect_clauses_fn__1819000548_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_collect_clauses_fn__1819000548_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1776:1
func (t *A_arbace_pprint_collect_clauses_fn__1819000548_A) Ctor_O_O(c__bracket_info, c__offset any) { t.F_bracket_info = c__bracket_info; t.F_offset = c__offset }
//line :1776:1
func (t *A_arbace_pprint_collect_clauses_fn__1819000548_A) Invoke_O_O__O(self, p__1819000547__1 any) any { var vec__1819000549__2 any = p__1819000547__1; var clause_map__3 any = lang.RT_Nth_O_I_O__O(vec__1819000549__2, lang.RT_IntCast_J__I(0), nil); var saw_else__4 any = lang.RT_Nth_O_I_O__O(vec__1819000549__2, lang.RT_IntCast_J__I(1), nil); var remainder__5 any = lang.RT_Nth_O_I_O__O(vec__1819000549__2, lang.RT_IntCast_J__I(2), nil); var vec__1819000552__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_527.GetRawRoot__O()).Invoke_O_O_O__O(t.F_bracket_info, t.F_offset, remainder__5); var clause__7 any = lang.RT_Nth_O_I_O__O(vec__1819000552__6, lang.RT_IntCast_J__I(0), nil); var vec__1819000555__8 any = lang.RT_Nth_O_I_O__O(vec__1819000552__6, lang.RT_IntCast_J__I(1), nil); var type__9 any = lang.RT_Nth_O_I_O__O(vec__1819000555__8, lang.RT_IntCast_J__I(0), nil); var right_params__10 any = lang.RT_Nth_O_I_O__O(vec__1819000555__8, lang.RT_IntCast_J__I(1), nil); var else_params__11 any = lang.RT_Nth_O_I_O__O(vec__1819000555__8, lang.RT_IntCast_J__I(2), nil); var remainder__12 any = lang.RT_Nth_O_I_O__O(vec__1819000555__8, lang.RT_IntCast_J__I(3), nil); if


	lang.Util_Equiv_O_O__Z(type__9, A_arbace_pprint_A_const_526) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_529.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_A_const_37.GetRawRoot__O(); var tmp3 *lang.Keyword


		if jrt.A2g_Truth(saw_else__4) { tmp3 = A_arbace_pprint_A_const_95 } else { tmp3 = A_arbace_pprint_A_const_410 }
//line :1779:1
		return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Tuple_Create_O_O__IPersistentVector(tmp1.Invoke_O_O_O__O(tmp2, clause_map__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3.Ref(), lang.Tuple_Create_O__IPersistentVector(clause__7), A_arbace_pprint_A_const_414, right_params__10))), remainder__12)) } else { if lang.Util_Equiv_O_O__Z(type__9, A_arbace_pprint_A_const_95) {







			if jrt.A2g_Truth(A_arbace_pprint_A_const_95.Invoke_O__O(clause_map__3)) {

				return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(Lit_27, t.F_offset) } else {
//line :1787:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_95.Invoke_O__O(t.F_bracket_info))) {




						return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(Lit_28, t.F_offset) } else {
//line :1787:1
							var tmp4 any; var tmp5 any = A_arbace_pprint_A_const_528; var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z(tmp5, A_arbace_pprint_A_const_95.Invoke_O__O(t.F_bracket_info))







							if and__1927000168__auto____13 { tmp4 = lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_410.Invoke_O__O(clause_map__3)) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13).Ref() }
//line :1787:1
							if jrt.A2g_Truth(tmp4) {








								return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(Lit_29, t.F_offset) } else {
//line :1787:1
									var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp6.Ref()) {














										var tmp7 any = A_arbace_pprint_A_const_528; if lang.Util_Equiv_O_O__Z(tmp7, A_arbace_pprint_A_const_95.Invoke_O__O(t.F_bracket_info)) { var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); var tmp10 any = A_arbace_pprint_A_const_95; var tmp11 any = lang.IFn_Cast(A_arbace_pprint_A_const_529.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_37.GetRawRoot__O(), clause_map__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Tuple_Create_O__IPersistentVector(clause__7), A_arbace_pprint_A_const_419, else_params__11))); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O__IPersistentVector(tmp9, lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12.Ref(), remainder__12)) } else { var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; var tmp14 any = tmp13.Ref(); var tmp15 any = A_arbace_pprint_A_const_410; var tmp16 any = lang.IFn_Cast(A_arbace_pprint_A_const_529.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_37.GetRawRoot__O(), clause_map__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(clause__7)))); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; return lang.Tuple_Create_O_O__IPersistentVector(tmp14, lang.Tuple_Create_O_O_O__IPersistentVector(tmp16, tmp17.Ref(), remainder__12)) } } else {
//line :1787:1
											return nil } } } } } else {
//line :1779:1
												if lang.Util_Equiv_O_O__Z(type__9, A_arbace_pprint_A_const_519) {





























													if jrt.A2g_Truth(saw_else__4) {

														return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(Lit_30, t.F_offset) } else {
//line :1809:1
															if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_530.Invoke_O__O(t.F_bracket_info))) {




																return lang.IFn_Cast(A_arbace_pprint_A_const_492.GetRawRoot__O()).Invoke_O_O__O(Lit_31, t.F_offset) } else {
//line :1809:1
																	var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp18.Ref()) { var tmp19 *jrt.Boolean; jrt.Boolean_Init(); tmp19 = jrt.Boolean_TRUE; var tmp20 any = tmp19.Ref(); var tmp21 any = A_arbace_pprint_A_const_410; var tmp22 any = lang.IFn_Cast(A_arbace_pprint_A_const_529.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_A_const_37.GetRawRoot__O(), clause_map__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, lang.Tuple_Create_O__IPersistentVector(clause__7)))); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O__IPersistentVector(tmp20, lang.Tuple_Create_O_O_O__IPersistentVector(tmp22, tmp23.Ref(), remainder__12)) } else { return nil } } } } else {
//line :1779:1
																		return nil } } } }










































func A_arbace_pprint_process_nesting_A_New() *A_arbace_pprint_process_nesting_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_process_nesting_A{}; t.Ctor(); return t }
//line :1822:1
func (t *A_arbace_pprint_process_nesting_A) Ctor() {}
//line :1822:1
func (t *A_arbace_pprint_process_nesting_A) Invoke_O_O__O(self, format__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_process_nesting_fn__1819000560_A_New(); var tmp4 *jrt.Class
	var fncls__112 /*line :1826:1*/*jrt.Class = A_arbace_pprint_process_nesting_fn__1819000560_A_fn_class

	if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_242, false); A_arbace_pprint_process_nesting_fn__1819000560_A_fn_class = fncls__112d; tmp4 = fncls__112d } else { tmp4 = fncls__112 }
//line :1826:1
	return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), format__0))
}
func A_arbace_pprint_process_nesting_fn__1819000560_A_New() *A_arbace_pprint_process_nesting_fn__1819000560_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_process_nesting_fn__1819000560_A{}; t.Ctor(); return t }
//line :1828:1
func (t *A_arbace_pprint_process_nesting_fn__1819000560_A) Ctor() {}
//line :1828:1
func (t *A_arbace_pprint_process_nesting_fn__1819000560_A) Invoke_O_O__O(self, remainder__1 any) any { var this__2 any = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(remainder__1); var remainder__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(remainder__1); var tmp1 *lang.Keyword = A_arbace_pprint_A_const_443; var bracket__4 any = tmp1.Invoke_O__O(A_arbace_pprint_A_const_518.Invoke_O__O(this__2)); if



	jrt.A2g_Truth(A_arbace_pprint_A_const_517.Invoke_O__O(bracket__4)) {
		return lang.IFn_Cast(A_arbace_pprint_A_const_523.GetRawRoot__O()).Invoke_O_O__O(this__2, remainder__3) } else {
//line :1832:1
			return lang.Tuple_Create_O_O__IPersistentVector(this__2, remainder__3) } }




func A_arbace_pprint_compile_format_A_New() *A_arbace_pprint_compile_format_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_compile_format_A{}; t.Ctor(); return t }
//line :1837:1
func (t *A_arbace_pprint_compile_format_A) Ctor() {}
//line :1837:1
func (t *A_arbace_pprint_compile_format_A) Invoke_O_O__O(self, format_str__0 any) any {





	lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_298, format_str__0))
//line :1837:1
	var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






		{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_531.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_323.GetRawRoot__O()); var tmp5 any = A_arbace_pprint_compile_format_fn__1819000564_A_New(); var tmp6 *jrt.Class
			var fncls__113 /*line :1844:1*/*jrt.Class = A_arbace_pprint_compile_format_fn__1819000564_A_fn_class


			if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_pprint_compile_format_fn__1819000564_A_fn_class = fncls__113d; tmp6 = fncls__113d } else { tmp6 = fncls__113 }
//line :1844:1
			tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.Tuple_Create_O_O__IPersistentVector(format_str__0, A_arbace_pprint_A_const_28)))) }
//line :1837:1
		return nil
	}()




	lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O()
//line :1837:1
	if tmp7 != nil { panic(tmp7) }; return tmp1
}








func A_arbace_pprint_compile_format_fn__1819000564_A_New() *A_arbace_pprint_compile_format_fn__1819000564_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_compile_format_fn__1819000564_A{}; t.Ctor(); return t }
//line :1847:1
func (t *A_arbace_pprint_compile_format_fn__1819000564_A) Ctor() {}
//line :1847:1
func (t *A_arbace_pprint_compile_format_fn__1819000564_A) Invoke_O_O__O(self, p__1819000563__1 any) any { var vec__1819000565__2 any = p__1819000563__1; var s__3 any = lang.RT_Nth_O_I_O__O(vec__1819000565__2, lang.RT_IntCast_J__I(0), nil); var offset__4 any = lang.RT_Nth_O_I_O__O(vec__1819000565__2, lang.RT_IntCast_J__I(1), nil); if
													jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(s__3)) { return lang.Tuple_Create_O_O__IPersistentVector(nil, s__3) } else { var tilde__5 int32 = jrt.NN(jrt.String_Cast(s__3)).IndexOf_I__I(lang.RT_IntCast_O__I(A_arbace_pprint_A_const_468))


		if lang.Numbers_IsNeg_J__Z(int64(tilde__5)) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_533.GetRawRoot__O()).Invoke_O_O__O(s__3, offset__4), lang.Tuple_Create_O_O__IPersistentVector(Lit_43, lang.Numbers_Add_O_J__Number(offset__4, int64(jrt.NN(jrt.String_Cast(s__3)).Length__I())))) } else { if lang.Numbers_IsZero_J__Z(int64(tilde__5)) {

			return lang.IFn_Cast(A_arbace_pprint_A_const_532.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__3, A_arbace_pprint_A_const_176), lang.Numbers_Inc_O__Number(offset__4)) } else {
//line :1851:1
				var tmp1 *jrt.Boolean; jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp1.Ref()) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_A_const_28; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_533.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O_O_O__O(s__3, tmp3, jrt.Integer_ValueOf_I__Integer(tilde__5).Ref()), offset__4), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_pprint_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__3, jrt.Integer_ValueOf_I__Integer(tilde__5).Ref()), lang.Numbers_Add_J_O__Number(int64(tilde__5), offset__4))) } else { return nil } } } } }






func A_arbace_pprint_needs_pretty_A_New() *A_arbace_pprint_needs_pretty_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_needs_pretty_A{}; t.Ctor(); return t }
//line :1858:1
func (t *A_arbace_pprint_needs_pretty_A) Ctor() {}
//line :1858:1
func (t *A_arbace_pprint_needs_pretty_A) Invoke_O_O__O(self, format__0 any) any { { var format__2 any = format__0; L1: for {




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_11.GetRawRoot__O()).Invoke_O__O(format__2)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else {

		var tmp1 any; var tmp2 *lang.Keyword = A_arbace_pprint_A_const_534; var tmp3 *lang.Keyword = A_arbace_pprint_A_const_442; var tmp4 *lang.Keyword = A_arbace_pprint_A_const_518; var or__1927000174__auto____3 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(format__2)))); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var tmp5 *lang.Keyword = A_arbace_pprint_A_const_410; var tmp6 *lang.Keyword = A_arbace_pprint_A_const_374; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_pprint_A_const_535.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_536.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(format__2))))); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else {

			var tmp7 *lang.Keyword = A_arbace_pprint_A_const_95; var tmp8 *lang.Keyword = A_arbace_pprint_A_const_374; tmp1 = lang.IFn_Cast(A_arbace_pprint_A_const_535.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_536.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_12.GetRawRoot__O()).Invoke_O__O(format__2))))) } }
//line :1865:1
		if jrt.A2g_Truth(tmp1) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else {



			format__2 = lang.IFn_Cast(A_arbace_pprint_A_const_13.GetRawRoot__O()).Invoke_O__O(format__2); continue L1 } } } }; /*line :1858:1*/panic("a2g: unreachable") }












func A_arbace_pprint_execute_format_A_New() *A_arbace_pprint_execute_format_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_execute_format_A{}; t.Ctor(); return t }
//line :1871:1
func (t *A_arbace_pprint_execute_format_A) Ctor() {}
//line :1871:1
func (t *A_arbace_pprint_execute_format_A) Invoke_O_O_O_O__O(self, stream__0, format__1, args__2 any) any { var real_stream__4 any; if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(stream__0)) { real_stream__4 = jrt.StringWriter_New() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_537.GetRawRoot__O()).Invoke_O__O(stream__0)) { real_stream__4 = A_arbace_pprint_A_const_34.Get__O() } else { if A_arbace_pprint_A_const_95 != nil { real_stream__4 = stream__0 } else { real_stream__4 = nil } } }; var wrapped_stream__5 any; var tmp1 any; var and__1927000168__auto____5 any = /*line :1871:1*/lang.IFn_Cast(A_arbace_pprint_A_const_536.GetRawRoot__O()).Invoke_O__O(format__1); if







	jrt.A2g_Truth(and__1927000168__auto____5) {
		tmp1 = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_228.GetRawRoot__O()).Invoke_O__O(real_stream__4)) } else {
//line :1879:1
			tmp1 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp1) {

				wrapped_stream__5 = lang.IFn_Cast(A_arbace_pprint_A_const_538.GetRawRoot__O()).Invoke_O__O(real_stream__4) } else {
//line :1879:1
					wrapped_stream__5 = real_stream__4 };



	lang.IFn_Cast(A_arbace_pprint_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_33.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_34, wrapped_stream__5)); var tmp2 any; tmp5 := /*line :1871:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)












		{ var tmp3 any = A_arbace_pprint_execute_format_fn__1819000571_A_New_O_O_O_O(format__1, wrapped_stream__5, args__2, real_stream__4); var tmp4 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_pprint_execute_format_fn__1819000571_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_pprint_execute_format_fn__1819000571_A_fn_class = fncls__114d; tmp4 = fncls__114d } else { tmp4 = fncls__114 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()




			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()).Invoke_O__O(stream__0)) { tmp2 = jrt.ToString(real_stream__4).Ref() } else { tmp2 = nil } }
//line :1871:1
		return nil }();











	lang.IFn_Cast(A_arbace_pprint_A_const_31.GetRawRoot__O()).Invoke__O(); if /*line :1871:1*/ tmp5 != nil { panic(tmp5) }; return tmp2 }
//line :1871:1
func (t *A_arbace_pprint_execute_format_A) Invoke_O_O_O__O(self, format__0, args__1 any) any {



















	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_308.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_execute_format_fn__1819000573_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_pprint_execute_format_fn__1819000573_A_fn_class
	if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_pprint_execute_format_fn__1819000573_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }
//line :1891:1
	tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), args__1, format__0)
//line :1871:1
	return nil
}











func A_arbace_pprint_execute_format_fn__1819000571_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_pprint_execute_format_fn__1819000571_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_execute_format_fn__1819000571_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1884:1
func (t *A_arbace_pprint_execute_format_fn__1819000571_A) Ctor_O_O_O_O(c__format, c__wrapped_stream, c__args, c__real_stream any) { t.F_format = c__format; t.F_wrapped_stream = c__wrapped_stream; t.F_args = c__args; t.F_real_stream = c__real_stream }
//line :1884:1
func (t *A_arbace_pprint_execute_format_fn__1819000571_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_297.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_format; t.F_format = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_args; t.F_args = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5) }
//line :1884:1
	return nil }(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_A_const_15.GetRawRoot__O()); var tmp8 any; var t__3 any = t.F_real_stream;


	t.F_real_stream = nil; tmp8 = t__3; if jrt.A2g_Truth(tmp7.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(tmp8, t.F_wrapped_stream)).Ref())) {
		var tmp9 any; var t__4 any = t.F_wrapped_stream; t.F_wrapped_stream = nil; tmp9 = t__4; jrt.Writer_Cast(tmp9).Flush__V() }; if /*line :1884:1*/ tmp6 != nil { panic(tmp6) }; return tmp1 }







func A_arbace_pprint_execute_format_fn__1819000573_A_New() *A_arbace_pprint_execute_format_fn__1819000573_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_execute_format_fn__1819000573_A{}; t.Ctor(); return t }
//line :1892:1
func (t *A_arbace_pprint_execute_format_fn__1819000573_A) Ctor() {}
//line :1892:1
func (t *A_arbace_pprint_execute_format_fn__1819000573_A) Invoke_O_O_O__O(self, element__1, context__2 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_pprint_A_const_371.GetRawRoot__O()).Invoke_O__O(context__2)) { return lang.Tuple_Create_O_O__IPersistentVector(nil, context__2) } else { var vec__1819000574__3 any = lang.IFn_Cast(A_arbace_pprint_A_const_372.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_374.Invoke_O__O(element__1), context__2); var params__4 any = lang.RT_Nth_O_I_O__O(vec__1819000574__3, lang.RT_IntCast_J__I(0), nil); var args__5 any = lang.RT_Nth_O_I_O__O(vec__1819000574__3, lang.RT_IntCast_J__I(1), nil); var vec__1819000577__6 any = lang.IFn_Cast(A_arbace_pprint_A_const_373.GetRawRoot__O()).Invoke_O__O(params__4); var params__7 any = lang.RT_Nth_O_I_O__O(vec__1819000577__6, lang.RT_IntCast_J__I(0), nil); var offsets__8 any = lang.RT_Nth_O_I_O__O(vec__1819000577__6, lang.RT_IntCast_J__I(1), nil); var params__9 any = lang.IFn_Cast(A_arbace_pprint_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(params__7, A_arbace_pprint_A_const_375, args__5); return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_376.Invoke_O__O(element__1), lang.Tuple_Create_O_O_O__IPersistentVector(params__9, args__5, offsets__8)))
	}
}












func A_arbace_pprint_formatter_A_New() *A_arbace_pprint_formatter_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_formatter_A{}; t.Ctor(); return t }
//line :1908:1
func (t *A_arbace_pprint_formatter_A) Ctor() {}
//line :1908:1
func (t *A_arbace_pprint_formatter_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, format_in__2 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_539), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_540), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(format_in__2), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_541), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_542), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_543), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_544), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_545), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_546), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_547)))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_546), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_548)))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_549), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_550), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_551), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_552), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_553), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_546), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_554)))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_546), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_555)))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_556), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_557), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_558), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_559), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_560), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_546), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_561)))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_546), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_562)))))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_563), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_564), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_565), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_540)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_541), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_540)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_540)))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_566), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_567), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_568), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_569))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_570), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_571), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_556), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_569)))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_549), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_567), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_563), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_571)))))))))))) }



















func A_arbace_pprint_formatter_out_A_New() *A_arbace_pprint_formatter_out_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_formatter_out_A{}; t.Ctor(); return t }
//line :1928:1
func (t *A_arbace_pprint_formatter_out_A) Ctor() {}
//line :1928:1
func (t *A_arbace_pprint_formatter_out_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, format_in__2 any) any { return lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_572), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_573), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(format_in__2), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_574), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_575), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_576), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_573)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_577)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_573)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_573)))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_578), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_579), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_580))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_581), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_582), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_583)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_580)))))))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_73), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_584)))), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_574), lang.IFn_Cast(A_arbace_pprint_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_A_const_582)))))))))))) }
















































































































































































































































































































































































































































































































































































































































type A_arbace_pprint_A struct{ jrt.Object }

var A_arbace_pprint_A_const_pool *jrt.RefArray

var A_arbace_pprint_A_const_0 *lang.Var

var A_arbace_pprint_A_const_1 *lang.Var

var A_arbace_pprint_A_const_2 any

var A_arbace_pprint_A_const_3 *lang.Keyword

var A_arbace_pprint_A_const_4 any

var A_arbace_pprint_A_const_5 any

var A_arbace_pprint_A_const_6 *lang.Var

var A_arbace_pprint_A_const_7 *lang.Var

var A_arbace_pprint_A_const_8 *lang.Var

var A_arbace_pprint_A_const_9 any

var A_arbace_pprint_A_const_10 *lang.Var

var A_arbace_pprint_A_const_11 *lang.Var

var A_arbace_pprint_A_const_12 *lang.Var

var A_arbace_pprint_A_const_13 *lang.Var

var A_arbace_pprint_A_const_14 *lang.Var

var A_arbace_pprint_A_const_15 *lang.Var

var A_arbace_pprint_A_const_16 *lang.Var

var A_arbace_pprint_A_const_17 *lang.Var

var A_arbace_pprint_A_const_18 *lang.Var

var A_arbace_pprint_A_const_19 *lang.Var

var A_arbace_pprint_A_const_20 *lang.Var

var A_arbace_pprint_A_const_21 *lang.Var

var A_arbace_pprint_A_const_22 *lang.Var

var A_arbace_pprint_A_const_23 *lang.Var

var A_arbace_pprint_A_const_24 *lang.Var

var A_arbace_pprint_A_const_25 *lang.Var

var A_arbace_pprint_A_const_26 *lang.Var

var A_arbace_pprint_A_const_27 *lang.Var

var A_arbace_pprint_A_const_28 any

var A_arbace_pprint_A_const_29 *lang.Var

var A_arbace_pprint_A_const_30 *lang.Var

var A_arbace_pprint_A_const_31 *lang.Var

var A_arbace_pprint_A_const_32 *lang.Var

var A_arbace_pprint_A_const_33 *lang.Var

var A_arbace_pprint_A_const_34 *lang.Var

var A_arbace_pprint_A_const_35 *lang.Var

var A_arbace_pprint_A_const_36 *lang.Var

var A_arbace_pprint_A_const_37 *lang.Var

var A_arbace_pprint_A_const_38 *lang.Var

var A_arbace_pprint_A_const_39 any

var A_arbace_pprint_A_const_40 *lang.Var

var A_arbace_pprint_A_const_41 any

var A_arbace_pprint_A_const_42 any

var A_arbace_pprint_A_const_43 *lang.Var

var A_arbace_pprint_A_const_44 *lang.Var

var A_arbace_pprint_A_const_45 *lang.Var

var A_arbace_pprint_A_const_46 *lang.Keyword

var A_arbace_pprint_A_const_47 *lang.Keyword

var A_arbace_pprint_A_const_48 *lang.Keyword

var A_arbace_pprint_A_const_49 *lang.Var

var A_arbace_pprint_A_const_50 *lang.Keyword

var A_arbace_pprint_A_const_51 any

var A_arbace_pprint_A_const_52 *lang.Var

var A_arbace_pprint_A_const_53 *lang.Var

var A_arbace_pprint_A_const_54 *lang.Var

var A_arbace_pprint_A_const_55 *lang.Var

var A_arbace_pprint_A_const_56 *lang.Var

var A_arbace_pprint_A_const_57 *jrt.Class

var A_arbace_pprint_A_const_58 *lang.Var

var A_arbace_pprint_A_const_59 *jrt.Class

var A_arbace_pprint_A_const_60 *jrt.Class

var A_arbace_pprint_A_const_61 *lang.Var

var A_arbace_pprint_A_const_62 *lang.Var

var A_arbace_pprint_A_const_63 any

var A_arbace_pprint_A_const_64 any

var A_arbace_pprint_A_const_65 any

var A_arbace_pprint_A_const_66 any

var A_arbace_pprint_A_const_67 any

var A_arbace_pprint_A_const_68 *lang.Var

var A_arbace_pprint_A_const_69 any

var A_arbace_pprint_A_const_70 any

var A_arbace_pprint_A_const_71 *lang.Keyword

var A_arbace_pprint_A_const_72 any

var A_arbace_pprint_A_const_73 any

var A_arbace_pprint_A_const_74 any

var A_arbace_pprint_A_const_75 *lang.Keyword

var A_arbace_pprint_A_const_76 any

var A_arbace_pprint_A_const_77 *lang.Var

var A_arbace_pprint_A_const_78 *lang.Var

var A_arbace_pprint_A_const_79 any

var A_arbace_pprint_A_const_80 any

var A_arbace_pprint_A_const_81 any

var A_arbace_pprint_A_const_82 any

var A_arbace_pprint_A_const_83 *lang.Var

var A_arbace_pprint_A_const_84 any

var A_arbace_pprint_A_const_85 any

var A_arbace_pprint_A_const_86 any

var A_arbace_pprint_A_const_87 any

var A_arbace_pprint_A_const_88 *lang.Var

var A_arbace_pprint_A_const_89 any

var A_arbace_pprint_A_const_90 *lang.Keyword

var A_arbace_pprint_A_const_91 any

var A_arbace_pprint_A_const_92 any

var A_arbace_pprint_A_const_93 any

var A_arbace_pprint_A_const_94 *lang.Keyword

var A_arbace_pprint_A_const_95 *lang.Keyword

var A_arbace_pprint_A_const_96 *lang.Keyword

var A_arbace_pprint_A_const_97 *lang.Var

var A_arbace_pprint_A_const_98 *lang.Keyword

var A_arbace_pprint_A_const_99 *lang.Var

var A_arbace_pprint_A_const_100 *lang.Var

var A_arbace_pprint_A_const_101 *lang.Keyword

var A_arbace_pprint_A_const_102 *lang.Var

var A_arbace_pprint_A_const_103 *lang.Keyword

var A_arbace_pprint_A_const_104 *lang.Var

var A_arbace_pprint_A_const_105 *lang.Keyword

var A_arbace_pprint_A_const_106 *lang.Var

var A_arbace_pprint_A_const_107 *lang.Keyword

var A_arbace_pprint_A_const_108 *lang.Var

var A_arbace_pprint_A_const_109 *lang.Keyword

var A_arbace_pprint_A_const_110 *lang.Keyword

var A_arbace_pprint_A_const_111 *lang.Var

var A_arbace_pprint_A_const_112 *lang.Var

var A_arbace_pprint_A_const_113 *lang.Keyword

var A_arbace_pprint_A_const_114 *lang.Keyword

var A_arbace_pprint_A_const_115 *lang.Keyword

var A_arbace_pprint_A_const_116 *lang.Keyword

var A_arbace_pprint_A_const_117 *lang.Keyword

var A_arbace_pprint_A_const_118 *lang.Keyword

var A_arbace_pprint_A_const_119 *lang.Keyword

var A_arbace_pprint_A_const_120 *lang.Keyword

var A_arbace_pprint_A_const_121 *lang.Keyword

var A_arbace_pprint_A_const_122 *lang.Keyword

var A_arbace_pprint_A_const_123 *lang.Keyword

var A_arbace_pprint_A_const_124 *lang.Keyword

var A_arbace_pprint_A_const_125 *lang.Keyword

var A_arbace_pprint_A_const_126 *lang.Keyword

var A_arbace_pprint_A_const_127 *lang.Keyword

var A_arbace_pprint_A_const_128 *lang.Var

var A_arbace_pprint_A_const_129 *lang.Keyword

var A_arbace_pprint_A_const_130 *lang.Keyword

var A_arbace_pprint_A_const_131 *lang.Var

var A_arbace_pprint_A_const_132 *lang.Var

var A_arbace_pprint_A_const_133 *lang.Var

var A_arbace_pprint_A_const_134 *lang.Var

var A_arbace_pprint_A_const_135 *lang.Var

var A_arbace_pprint_A_const_136 *lang.Var

var A_arbace_pprint_A_const_137 *lang.Var

var A_arbace_pprint_A_const_138 *lang.Keyword

var A_arbace_pprint_A_const_139 *lang.Var

var A_arbace_pprint_A_const_140 *lang.Var

var A_arbace_pprint_A_const_141 *lang.Var

var A_arbace_pprint_A_const_142 *lang.Var

var A_arbace_pprint_A_const_143 *lang.Keyword

var A_arbace_pprint_A_const_144 *lang.Var

var A_arbace_pprint_A_const_145 *lang.Var

var A_arbace_pprint_A_const_146 *lang.Var

var A_arbace_pprint_A_const_147 *lang.Var

var A_arbace_pprint_A_const_148 any

var A_arbace_pprint_A_const_149 *lang.Var

var A_arbace_pprint_A_const_150 *lang.Var

var A_arbace_pprint_A_const_151 *lang.Var

var A_arbace_pprint_A_const_152 *lang.Var

var A_arbace_pprint_A_const_153 *lang.Var

var A_arbace_pprint_A_const_154 *lang.Var

var A_arbace_pprint_A_const_155 *lang.Var

var A_arbace_pprint_A_const_156 *lang.Var

var A_arbace_pprint_A_const_157 *lang.Keyword

var A_arbace_pprint_A_const_158 *lang.Var

var A_arbace_pprint_A_const_159 any

var A_arbace_pprint_A_const_160 *lang.Keyword

var A_arbace_pprint_A_const_161 *lang.Keyword

var A_arbace_pprint_A_const_162 *lang.Keyword

var A_arbace_pprint_A_const_163 *lang.Keyword

var A_arbace_pprint_A_const_164 *lang.Var

var A_arbace_pprint_A_const_165 *lang.Var

var A_arbace_pprint_A_const_166 *lang.Var

var A_arbace_pprint_A_const_167 *lang.Var

var A_arbace_pprint_A_const_168 *lang.Var

var A_arbace_pprint_A_const_169 *lang.Keyword

var A_arbace_pprint_A_const_170 *lang.Var

var A_arbace_pprint_A_const_171 *lang.Var

var A_arbace_pprint_A_const_172 *lang.Keyword

var A_arbace_pprint_A_const_173 *lang.Keyword

var A_arbace_pprint_A_const_174 *lang.Keyword

var A_arbace_pprint_A_const_175 *lang.Keyword

var A_arbace_pprint_A_const_176 any

var A_arbace_pprint_A_const_177 *lang.Keyword

var A_arbace_pprint_A_const_178 *lang.Var

var A_arbace_pprint_A_const_179 *lang.Var

var A_arbace_pprint_A_const_180 *lang.Var

var A_arbace_pprint_A_const_181 *lang.Var

var A_arbace_pprint_A_const_182 *lang.Var

var A_arbace_pprint_A_const_183 *lang.Var

var A_arbace_pprint_A_const_184 *lang.Var

var A_arbace_pprint_A_const_185 *lang.Var

var A_arbace_pprint_A_const_186 any

var A_arbace_pprint_A_const_187 any

var A_arbace_pprint_A_const_188 any

var A_arbace_pprint_A_const_189 any

var A_arbace_pprint_A_const_190 any

var A_arbace_pprint_A_const_191 any

var A_arbace_pprint_A_const_192 any

var A_arbace_pprint_A_const_193 any

var A_arbace_pprint_A_const_194 any

var A_arbace_pprint_A_const_195 *lang.Var

var A_arbace_pprint_A_const_196 *lang.Var

var A_arbace_pprint_A_const_197 *lang.Var

var A_arbace_pprint_A_const_198 *lang.Var

var A_arbace_pprint_A_const_199 any

var A_arbace_pprint_A_const_200 any

var A_arbace_pprint_A_const_201 any

var A_arbace_pprint_A_const_202 any

var A_arbace_pprint_A_const_203 any

var A_arbace_pprint_A_const_204 any

var A_arbace_pprint_A_const_205 any

var A_arbace_pprint_A_const_206 any

var A_arbace_pprint_A_const_207 any

var A_arbace_pprint_A_const_208 any

var A_arbace_pprint_A_const_209 any

var A_arbace_pprint_A_const_210 any

var A_arbace_pprint_A_const_211 any

var A_arbace_pprint_A_const_212 any

var A_arbace_pprint_A_const_213 *lang.Var

var A_arbace_pprint_A_const_214 *lang.Var

var A_arbace_pprint_A_const_215 *lang.Var

var A_arbace_pprint_A_const_216 *lang.Var

var A_arbace_pprint_A_const_217 *lang.Var

var A_arbace_pprint_A_const_218 *lang.Var

var A_arbace_pprint_A_const_219 *lang.Var

var A_arbace_pprint_A_const_220 *lang.Keyword

var A_arbace_pprint_A_const_221 any

var A_arbace_pprint_A_const_222 *lang.Var

var A_arbace_pprint_A_const_223 *lang.Var

var A_arbace_pprint_A_const_224 *lang.Var

var A_arbace_pprint_A_const_225 *lang.Var

var A_arbace_pprint_A_const_226 *lang.Var

var A_arbace_pprint_A_const_227 *lang.Var

var A_arbace_pprint_A_const_228 *lang.Var

var A_arbace_pprint_A_const_229 *lang.Var

var A_arbace_pprint_A_const_230 *lang.Var

var A_arbace_pprint_A_const_231 *lang.Var

var A_arbace_pprint_A_const_232 *lang.Var

var A_arbace_pprint_A_const_233 *lang.Var

var A_arbace_pprint_A_const_234 any

var A_arbace_pprint_A_const_235 any

var A_arbace_pprint_A_const_236 *lang.Var

var A_arbace_pprint_A_const_237 *lang.Var

var A_arbace_pprint_A_const_238 *lang.Var

var A_arbace_pprint_A_const_239 any

var A_arbace_pprint_A_const_240 any

var A_arbace_pprint_A_const_241 any

var A_arbace_pprint_A_const_242 *lang.Var

var A_arbace_pprint_A_const_243 *lang.Var

var A_arbace_pprint_A_const_244 *lang.Var

var A_arbace_pprint_A_const_245 *lang.Var

var A_arbace_pprint_A_const_246 any

var A_arbace_pprint_A_const_247 any

var A_arbace_pprint_A_const_248 any

var A_arbace_pprint_A_const_249 any

var A_arbace_pprint_A_const_250 any

var A_arbace_pprint_A_const_251 any

var A_arbace_pprint_A_const_252 any

var A_arbace_pprint_A_const_253 any

var A_arbace_pprint_A_const_254 any

var A_arbace_pprint_A_const_255 any

var A_arbace_pprint_A_const_256 any

var A_arbace_pprint_A_const_257 any

var A_arbace_pprint_A_const_258 any

var A_arbace_pprint_A_const_259 any

var A_arbace_pprint_A_const_260 any

var A_arbace_pprint_A_const_261 any

var A_arbace_pprint_A_const_262 any

var A_arbace_pprint_A_const_263 any

var A_arbace_pprint_A_const_264 any

var A_arbace_pprint_A_const_265 any

var A_arbace_pprint_A_const_266 any

var A_arbace_pprint_A_const_267 *lang.Var

var A_arbace_pprint_A_const_268 *lang.Var

var A_arbace_pprint_A_const_269 any

var A_arbace_pprint_A_const_270 *lang.Var

var A_arbace_pprint_A_const_271 any

var A_arbace_pprint_A_const_272 any

var A_arbace_pprint_A_const_273 *lang.Var

var A_arbace_pprint_A_const_274 *lang.Var

var A_arbace_pprint_A_const_275 *lang.Var

var A_arbace_pprint_A_const_276 any

var A_arbace_pprint_A_const_277 any

var A_arbace_pprint_A_const_278 any

var A_arbace_pprint_A_const_279 any

var A_arbace_pprint_A_const_280 *lang.Var

var A_arbace_pprint_A_const_281 *lang.Var

var A_arbace_pprint_A_const_282 *lang.Var

var A_arbace_pprint_A_const_283 any

var A_arbace_pprint_A_const_284 any

var A_arbace_pprint_A_const_285 any

var A_arbace_pprint_A_const_286 any

var A_arbace_pprint_A_const_287 any

var A_arbace_pprint_A_const_288 any

var A_arbace_pprint_A_const_289 any

var A_arbace_pprint_A_const_290 any

var A_arbace_pprint_A_const_291 any

var A_arbace_pprint_A_const_292 any

var A_arbace_pprint_A_const_293 any

var A_arbace_pprint_A_const_294 *lang.Var

var A_arbace_pprint_A_const_295 *lang.Var

var A_arbace_pprint_A_const_296 *lang.Var

var A_arbace_pprint_A_const_297 *lang.Var

var A_arbace_pprint_A_const_298 *lang.Var

var A_arbace_pprint_A_const_299 *lang.Var

var A_arbace_pprint_A_const_300 *lang.Keyword

var A_arbace_pprint_A_const_301 *lang.Keyword

var A_arbace_pprint_A_const_302 *lang.Var

var A_arbace_pprint_A_const_303 *lang.Var

var A_arbace_pprint_A_const_304 *lang.Var

var A_arbace_pprint_A_const_305 *lang.Keyword

var A_arbace_pprint_A_const_306 *lang.Keyword

var A_arbace_pprint_A_const_307 any

var A_arbace_pprint_A_const_308 *lang.Var

var A_arbace_pprint_A_const_309 *lang.Var

var A_arbace_pprint_A_const_310 *lang.Var

var A_arbace_pprint_A_const_311 *lang.Var

var A_arbace_pprint_A_const_312 *lang.Var

var A_arbace_pprint_A_const_313 *lang.Var

var A_arbace_pprint_A_const_314 *lang.Keyword

var A_arbace_pprint_A_const_315 *lang.Keyword

var A_arbace_pprint_A_const_316 *lang.Keyword

var A_arbace_pprint_A_const_317 *lang.Keyword

var A_arbace_pprint_A_const_318 *lang.Keyword

var A_arbace_pprint_A_const_319 *lang.Var

var A_arbace_pprint_A_const_320 *lang.Var

var A_arbace_pprint_A_const_321 *lang.Var

var A_arbace_pprint_A_const_322 *lang.Var

var A_arbace_pprint_A_const_323 *lang.Var

var A_arbace_pprint_A_const_324 any

var A_arbace_pprint_A_const_325 any

var A_arbace_pprint_A_const_326 any

var A_arbace_pprint_A_const_327 *lang.Var

var A_arbace_pprint_A_const_328 *lang.Var

var A_arbace_pprint_A_const_329 *lang.Var

var A_arbace_pprint_A_const_330 *lang.Var

var A_arbace_pprint_A_const_331 *lang.Var

var A_arbace_pprint_A_const_332 *lang.Keyword

var A_arbace_pprint_A_const_333 *lang.Var

var A_arbace_pprint_A_const_334 *lang.Var

var A_arbace_pprint_A_const_335 *lang.Keyword

var A_arbace_pprint_A_const_336 *lang.Keyword

var A_arbace_pprint_A_const_337 *lang.Var

var A_arbace_pprint_A_const_338 *lang.Var

var A_arbace_pprint_A_const_339 *lang.Var

var A_arbace_pprint_A_const_340 *lang.Var

var A_arbace_pprint_A_const_341 *lang.Var

var A_arbace_pprint_A_const_342 *lang.Var

var A_arbace_pprint_A_const_343 *lang.Var

var A_arbace_pprint_A_const_344 *lang.Var

var A_arbace_pprint_A_const_345 any

var A_arbace_pprint_A_const_346 *lang.Var

var A_arbace_pprint_A_const_347 any

var A_arbace_pprint_A_const_348 any

var A_arbace_pprint_A_const_349 any

var A_arbace_pprint_A_const_350 *lang.Var

var A_arbace_pprint_A_const_351 *lang.Var

var A_arbace_pprint_A_const_352 *lang.Var

var A_arbace_pprint_A_const_353 any

var A_arbace_pprint_A_const_354 *lang.Var

var A_arbace_pprint_A_const_355 any

var A_arbace_pprint_A_const_356 any

var A_arbace_pprint_A_const_357 *lang.Var

var A_arbace_pprint_A_const_358 any

var A_arbace_pprint_A_const_359 any

var A_arbace_pprint_A_const_360 *lang.Var

var A_arbace_pprint_A_const_361 *lang.Var

var A_arbace_pprint_A_const_362 *lang.Var

var A_arbace_pprint_A_const_363 *lang.Var

var A_arbace_pprint_A_const_364 *lang.Keyword

var A_arbace_pprint_A_const_365 *lang.Var

var A_arbace_pprint_A_const_366 any

var A_arbace_pprint_A_const_367 any

var A_arbace_pprint_A_const_368 *lang.Keyword

var A_arbace_pprint_A_const_369 *lang.Keyword

var A_arbace_pprint_A_const_370 *lang.Var

var A_arbace_pprint_A_const_371 *lang.Var

var A_arbace_pprint_A_const_372 *lang.Var

var A_arbace_pprint_A_const_373 *lang.Var

var A_arbace_pprint_A_const_374 *lang.Keyword

var A_arbace_pprint_A_const_375 *lang.Keyword

var A_arbace_pprint_A_const_376 *lang.Keyword

var A_arbace_pprint_A_const_377 any

var A_arbace_pprint_A_const_378 any

var A_arbace_pprint_A_const_379 *lang.Var

var A_arbace_pprint_A_const_380 *lang.Var

var A_arbace_pprint_A_const_381 *lang.Var

var A_arbace_pprint_A_const_382 any

var A_arbace_pprint_A_const_383 any

var A_arbace_pprint_A_const_384 any

var A_arbace_pprint_A_const_385 any

var A_arbace_pprint_A_const_386 any

var A_arbace_pprint_A_const_387 *lang.Var

var A_arbace_pprint_A_const_388 *lang.Var

var A_arbace_pprint_A_const_389 *lang.Var

var A_arbace_pprint_A_const_390 *lang.Var

var A_arbace_pprint_A_const_391 *lang.Keyword

var A_arbace_pprint_A_const_392 *lang.Keyword

var A_arbace_pprint_A_const_393 *lang.Var

var A_arbace_pprint_A_const_394 *lang.Var

var A_arbace_pprint_A_const_395 *lang.Keyword

var A_arbace_pprint_A_const_396 *lang.Var

var A_arbace_pprint_A_const_397 *lang.Var

var A_arbace_pprint_A_const_398 *lang.Keyword

var A_arbace_pprint_A_const_399 *lang.Keyword

var A_arbace_pprint_A_const_400 *lang.Keyword

var A_arbace_pprint_A_const_401 any

var A_arbace_pprint_A_const_402 any

var A_arbace_pprint_A_const_403 *lang.Var

var A_arbace_pprint_A_const_404 any

var A_arbace_pprint_A_const_405 *lang.Var

var A_arbace_pprint_A_const_406 *lang.Var

var A_arbace_pprint_A_const_407 *lang.Var

var A_arbace_pprint_A_const_408 *lang.Keyword

var A_arbace_pprint_A_const_409 *lang.Keyword

var A_arbace_pprint_A_const_410 *lang.Keyword

var A_arbace_pprint_A_const_411 *lang.Var

var A_arbace_pprint_A_const_412 *lang.Keyword

var A_arbace_pprint_A_const_413 *lang.Var

var A_arbace_pprint_A_const_414 *lang.Keyword

var A_arbace_pprint_A_const_415 *lang.Var

var A_arbace_pprint_A_const_416 *lang.Var

var A_arbace_pprint_A_const_417 *lang.Var

var A_arbace_pprint_A_const_418 *lang.Var

var A_arbace_pprint_A_const_419 *lang.Keyword

var A_arbace_pprint_A_const_420 *lang.Var

var A_arbace_pprint_A_const_421 *lang.Keyword

var A_arbace_pprint_A_const_422 *lang.Keyword

var A_arbace_pprint_A_const_423 *lang.Var

var A_arbace_pprint_A_const_424 *lang.Var

var A_arbace_pprint_A_const_425 any

var A_arbace_pprint_A_const_426 *lang.Var

var A_arbace_pprint_A_const_427 *lang.Var

var A_arbace_pprint_A_const_428 any

var A_arbace_pprint_A_const_429 *lang.Var

var A_arbace_pprint_A_const_430 any

var A_arbace_pprint_A_const_431 *lang.Keyword

var A_arbace_pprint_A_const_432 *lang.Keyword

var A_arbace_pprint_A_const_433 *lang.Var

var A_arbace_pprint_A_const_434 *lang.Var

var A_arbace_pprint_A_const_435 *lang.Var

var A_arbace_pprint_A_const_436 *lang.Var

var A_arbace_pprint_A_const_437 *lang.Var

var A_arbace_pprint_A_const_438 *lang.Keyword

var A_arbace_pprint_A_const_439 *lang.Keyword

var A_arbace_pprint_A_const_440 *lang.Var

var A_arbace_pprint_A_const_441 *lang.Keyword

var A_arbace_pprint_A_const_442 *lang.Keyword

var A_arbace_pprint_A_const_443 *lang.Keyword

var A_arbace_pprint_A_const_444 *lang.Keyword

var A_arbace_pprint_A_const_445 any

var A_arbace_pprint_A_const_446 any

var A_arbace_pprint_A_const_447 any

var A_arbace_pprint_A_const_448 any

var A_arbace_pprint_A_const_449 any

var A_arbace_pprint_A_const_450 *lang.Var

var A_arbace_pprint_A_const_451 *lang.Var

var A_arbace_pprint_A_const_452 any

var A_arbace_pprint_A_const_453 any

var A_arbace_pprint_A_const_454 *lang.Var

var A_arbace_pprint_A_const_455 *lang.Var

var A_arbace_pprint_A_const_456 *lang.Var

var A_arbace_pprint_A_const_457 *lang.Var

var A_arbace_pprint_A_const_458 any

var A_arbace_pprint_A_const_459 any

var A_arbace_pprint_A_const_460 *lang.Var

var A_arbace_pprint_A_const_461 *lang.Var

var A_arbace_pprint_A_const_462 *lang.Var

var A_arbace_pprint_A_const_463 *lang.Var

var A_arbace_pprint_A_const_464 *lang.Var

var A_arbace_pprint_A_const_465 *lang.Keyword

var A_arbace_pprint_A_const_466 *lang.Var

var A_arbace_pprint_A_const_467 any

var A_arbace_pprint_A_const_468 any

var A_arbace_pprint_A_const_469 *lang.Var

var A_arbace_pprint_A_const_470 *lang.Var

var A_arbace_pprint_A_const_471 *lang.Var

var A_arbace_pprint_A_const_472 *lang.Var

var A_arbace_pprint_A_const_473 *lang.Var

var A_arbace_pprint_A_const_474 *lang.Var

var A_arbace_pprint_A_const_475 *lang.Var

var A_arbace_pprint_A_const_476 *lang.Var

var A_arbace_pprint_A_const_477 *lang.Var

var A_arbace_pprint_A_const_478 *lang.Var

var A_arbace_pprint_A_const_479 *lang.Var

var A_arbace_pprint_A_const_480 *lang.Var

var A_arbace_pprint_A_const_481 *lang.Var

var A_arbace_pprint_A_const_482 *lang.Var

var A_arbace_pprint_A_const_483 *lang.Var

var A_arbace_pprint_A_const_484 *lang.Keyword

var A_arbace_pprint_A_const_485 *lang.Keyword

var A_arbace_pprint_A_const_486 *lang.Keyword

var A_arbace_pprint_A_const_487 *lang.Var

var A_arbace_pprint_A_const_488 any

var A_arbace_pprint_A_const_489 any

var A_arbace_pprint_A_const_490 *lang.Var

var A_arbace_pprint_A_const_491 *lang.Var

var A_arbace_pprint_A_const_492 *lang.Var

var A_arbace_pprint_A_const_493 *lang.Var

var A_arbace_pprint_A_const_494 *lang.Var

var A_arbace_pprint_A_const_495 any

var A_arbace_pprint_A_const_496 *lang.Var

var A_arbace_pprint_A_const_497 any

var A_arbace_pprint_A_const_498 any

var A_arbace_pprint_A_const_499 any

var A_arbace_pprint_A_const_500 *lang.Var

var A_arbace_pprint_A_const_501 *lang.Keyword

var A_arbace_pprint_A_const_502 *lang.Var

var A_arbace_pprint_A_const_503 *lang.Var

var A_arbace_pprint_A_const_504 *lang.Var

var A_arbace_pprint_A_const_505 *lang.Var

var A_arbace_pprint_A_const_506 *lang.Var

var A_arbace_pprint_A_const_507 *lang.Var

var A_arbace_pprint_A_const_508 *lang.Var

var A_arbace_pprint_A_const_509 *lang.Var

var A_arbace_pprint_A_const_510 *lang.Var

var A_arbace_pprint_A_const_511 *lang.Var

var A_arbace_pprint_A_const_512 *lang.Var

var A_arbace_pprint_A_const_513 *lang.Var

var A_arbace_pprint_A_const_514 *lang.Var

var A_arbace_pprint_A_const_515 *lang.Var

var A_arbace_pprint_A_const_516 any

var A_arbace_pprint_A_const_517 *lang.Keyword

var A_arbace_pprint_A_const_518 *lang.Keyword

var A_arbace_pprint_A_const_519 *lang.Keyword

var A_arbace_pprint_A_const_520 *lang.Var

var A_arbace_pprint_A_const_521 *lang.Var

var A_arbace_pprint_A_const_522 *lang.Var

var A_arbace_pprint_A_const_523 *lang.Var

var A_arbace_pprint_A_const_524 *lang.Var

var A_arbace_pprint_A_const_525 *lang.Var

var A_arbace_pprint_A_const_526 *lang.Keyword

var A_arbace_pprint_A_const_527 *lang.Var

var A_arbace_pprint_A_const_528 *lang.Keyword

var A_arbace_pprint_A_const_529 *lang.Var

var A_arbace_pprint_A_const_530 *lang.Keyword

var A_arbace_pprint_A_const_531 *lang.Var

var A_arbace_pprint_A_const_532 *lang.Var

var A_arbace_pprint_A_const_533 *lang.Var

var A_arbace_pprint_A_const_534 *lang.Keyword

var A_arbace_pprint_A_const_535 *lang.Var

var A_arbace_pprint_A_const_536 *lang.Var

var A_arbace_pprint_A_const_537 *lang.Var

var A_arbace_pprint_A_const_538 *lang.Var

var A_arbace_pprint_A_const_539 any

var A_arbace_pprint_A_const_540 any

var A_arbace_pprint_A_const_541 any

var A_arbace_pprint_A_const_542 any

var A_arbace_pprint_A_const_543 any

var A_arbace_pprint_A_const_544 any

var A_arbace_pprint_A_const_545 any

var A_arbace_pprint_A_const_546 any

var A_arbace_pprint_A_const_547 any

var A_arbace_pprint_A_const_548 any

var A_arbace_pprint_A_const_549 any

var A_arbace_pprint_A_const_550 any

var A_arbace_pprint_A_const_551 any

var A_arbace_pprint_A_const_552 any

var A_arbace_pprint_A_const_553 any

var A_arbace_pprint_A_const_554 any

var A_arbace_pprint_A_const_555 any

var A_arbace_pprint_A_const_556 any

var A_arbace_pprint_A_const_557 any

var A_arbace_pprint_A_const_558 any

var A_arbace_pprint_A_const_559 any

var A_arbace_pprint_A_const_560 any

var A_arbace_pprint_A_const_561 any

var A_arbace_pprint_A_const_562 any

var A_arbace_pprint_A_const_563 any

var A_arbace_pprint_A_const_564 any

var A_arbace_pprint_A_const_565 any

var A_arbace_pprint_A_const_566 any

var A_arbace_pprint_A_const_567 any

var A_arbace_pprint_A_const_568 any

var A_arbace_pprint_A_const_569 any

var A_arbace_pprint_A_const_570 any

var A_arbace_pprint_A_const_571 any

var A_arbace_pprint_A_const_572 any

var A_arbace_pprint_A_const_573 any

var A_arbace_pprint_A_const_574 any

var A_arbace_pprint_A_const_575 any

var A_arbace_pprint_A_const_576 any

var A_arbace_pprint_A_const_577 any

var A_arbace_pprint_A_const_578 any

var A_arbace_pprint_A_const_579 any

var A_arbace_pprint_A_const_580 any

var A_arbace_pprint_A_const_581 any

var A_arbace_pprint_A_const_582 any

var A_arbace_pprint_A_const_583 any

var A_arbace_pprint_A_const_584 any

var A_arbace_pprint_A_const_585 *lang.Var

var A_arbace_pprint_A_const_586 *lang.Var

var A_arbace_pprint_A_const_587 *lang.Var

var A_arbace_pprint_A_const_588 *lang.Var

var A_arbace_pprint_A_const_589 *lang.Var

var A_arbace_pprint_A_const_590 *lang.Var

var A_arbace_pprint_A_const_591 *lang.Var

var A_arbace_pprint_A_const_592 *lang.Var

var A_arbace_pprint_A_const_593 *lang.Var

var A_arbace_pprint_A_const_594 *lang.Var

var A_arbace_pprint_A_const_595 *lang.Var

var A_arbace_pprint_A_const_596 *lang.Var

var A_arbace_pprint_A_const_597 *lang.Var

var A_arbace_pprint_A_const_598 *lang.Var

var A_arbace_pprint_A_const_599 *lang.Var

var A_arbace_pprint_A_const_600 *lang.Var

var A_arbace_pprint_A_const_601 any

var A_arbace_pprint_A_const_602 any

var A_arbace_pprint_A_const_603 *lang.Var

var A_arbace_pprint_A_const_604 *lang.Var

var A_arbace_pprint_A_const_605 *lang.Var

var A_arbace_pprint_A_const_606 *lang.Var

var A_arbace_pprint_A_const_607 *lang.Var

var A_arbace_pprint_A_const_608 *lang.Var

var A_arbace_pprint_A_const_609 *lang.Var

var A_arbace_pprint_A_const_610 *lang.Var

var A_arbace_pprint_A_const_611 *lang.Var

var A_arbace_pprint_A_const_612 any

var A_arbace_pprint_A_const_613 *lang.Var

var A_arbace_pprint_A_const_614 *lang.Var

var A_arbace_pprint_A_const_615 *lang.Var

var A_arbace_pprint_A_const_616 *lang.Var

var A_arbace_pprint_A_const_617 *lang.Var

var A_arbace_pprint_A_const_618 *lang.Var

var A_arbace_pprint_A_const_619 *lang.Var

var A_arbace_pprint_A_init jrt.ClassInit

func A_arbace_pprint_A_Init() { if !A_arbace_pprint_A_init.Done() { A_arbace_pprint_A_init.Run(A_arbace_pprint_A_clinit) } }

func A_arbace_pprint_A_clinit() { A_arbace_pprint_A_clinit_p0(); A_arbace_pprint_A_clinit_p1(); A_arbace_pprint_A_clinit_p2(); A_arbace_pprint_A_clinit_p3(); A_arbace_pprint_A_clinit_p4(); A_arbace_pprint_A_clinit_p5(); A_arbace_pprint_A_clinit_p6(); A_arbace_pprint_A_clinit_p7(); A_arbace_pprint_A_clinit_p8(); A_arbace_pprint_A_clinit_p9(); A_arbace_pprint_A_clinit_p10(); A_arbace_pprint_A_clinit_p11(); A_arbace_pprint_A_clinit_p12(); A_arbace_pprint_A_clinit_p13(); A_arbace_pprint_A_clinit_p14(); A_arbace_pprint_A_clinit_p15(); A_arbace_pprint_A_clinit_p16(); A_arbace_pprint_A_clinit_p17(); A_arbace_pprint_A_clinit_p18(); A_arbace_pprint_A_clinit_p19(); A_arbace_pprint_A_clinit_p20(); A_arbace_pprint_A_clinit_p21(); A_arbace_pprint_A_clinit_p22(); A_arbace_pprint_A_clinit_p23(); A_arbace_pprint_A_clinit_p24(); A_arbace_pprint_A_clinit_p25(); A_arbace_pprint_A_clinit_p26(); A_arbace_pprint_A_clinit_p27(); A_arbace_pprint_A_clinit_p28(); A_arbace_pprint_A_clinit_p29(); A_arbace_pprint_A_clinit_p30(); A_arbace_pprint_A_clinit_p31(); A_arbace_pprint_A_clinit_p32(); A_arbace_pprint_A_clinit_p33(); A_arbace_pprint_A_clinit_p34(); A_arbace_pprint_A_clinit_p35(); A_arbace_pprint_A_clinit_p36(); A_arbace_pprint_A_clinit_p37(); A_arbace_pprint_A_clinit_p38(); A_arbace_pprint_A_clinit_p39(); A_arbace_pprint_A_clinit_p40(); A_arbace_pprint_A_clinit_p41(); A_arbace_pprint_A_clinit_p42(); A_arbace_pprint_A_clinit_p43(); A_arbace_pprint_A_clinit_p44(); A_arbace_pprint_A_clinit_p45(); A_arbace_pprint_A_clinit_p46(); A_arbace_pprint_A_clinit_p47(); A_arbace_pprint_A_clinit_p48() }

func A_arbace_pprint_A_clinit_p0() { A_arbace_pprint_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 824); A_arbace_pprint_A_const_0 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[204]); A_arbace_pprint_A_const_1 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[205]); A_arbace_pprint_A_const_2 = A_arbace_pprint_A_const_pool.A[206]; A_arbace_pprint_A_const_3 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[207]); A_arbace_pprint_A_const_4 = A_arbace_pprint_A_const_pool.A[208]; A_arbace_pprint_A_const_5 = A_arbace_pprint_A_const_pool.A[209]; A_arbace_pprint_A_const_6 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[210]); A_arbace_pprint_A_const_7 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[211]); A_arbace_pprint_A_const_8 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[212]); A_arbace_pprint_A_const_9 = A_arbace_pprint_A_const_pool.A[213]; A_arbace_pprint_A_const_10 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[214]); A_arbace_pprint_A_const_11 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[215]) }

func A_arbace_pprint_A_clinit_p1() { A_arbace_pprint_A_const_12 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[216]); A_arbace_pprint_A_const_13 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[217]); A_arbace_pprint_A_const_14 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[218]); A_arbace_pprint_A_const_15 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[219]); A_arbace_pprint_A_const_16 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[220]); A_arbace_pprint_A_const_17 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[221]); A_arbace_pprint_A_const_18 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[222]); A_arbace_pprint_A_const_19 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[223]); A_arbace_pprint_A_const_20 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[224]); A_arbace_pprint_A_const_21 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[225]); A_arbace_pprint_A_const_22 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[226]); A_arbace_pprint_A_const_23 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[227]) }

func A_arbace_pprint_A_clinit_p2() { A_arbace_pprint_A_const_24 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[228]); A_arbace_pprint_A_const_25 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[229]); A_arbace_pprint_A_const_26 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[230]); A_arbace_pprint_A_const_27 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[231]); A_arbace_pprint_A_const_28 = A_arbace_pprint_A_const_pool.A[232]; A_arbace_pprint_A_const_29 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[233]); A_arbace_pprint_A_const_30 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[234]); A_arbace_pprint_A_const_31 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[235]); A_arbace_pprint_A_const_32 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[236]); A_arbace_pprint_A_const_33 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[237]); A_arbace_pprint_A_const_34 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[238]); A_arbace_pprint_A_const_35 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[239]) }

func A_arbace_pprint_A_clinit_p3() { A_arbace_pprint_A_const_36 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[240]); A_arbace_pprint_A_const_37 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[241]); A_arbace_pprint_A_const_38 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[242]); A_arbace_pprint_A_const_39 = A_arbace_pprint_A_const_pool.A[243]; A_arbace_pprint_A_const_40 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[244]); A_arbace_pprint_A_const_41 = A_arbace_pprint_A_const_pool.A[245]; A_arbace_pprint_A_const_42 = A_arbace_pprint_A_const_pool.A[246]; A_arbace_pprint_A_const_43 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[247]); A_arbace_pprint_A_const_44 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[248]); A_arbace_pprint_A_const_45 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[249]); A_arbace_pprint_A_const_46 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[250]); A_arbace_pprint_A_const_47 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[251]) }

func A_arbace_pprint_A_clinit_p4() { A_arbace_pprint_A_const_48 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[252]); A_arbace_pprint_A_const_49 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[253]); A_arbace_pprint_A_const_50 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[254]); A_arbace_pprint_A_const_51 = A_arbace_pprint_A_const_pool.A[255]; A_arbace_pprint_A_const_52 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[256]); A_arbace_pprint_A_const_53 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[257]); A_arbace_pprint_A_const_54 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[258]); A_arbace_pprint_A_const_55 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[259]); A_arbace_pprint_A_const_56 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[260]); A_arbace_pprint_A_const_57 = jrt.Class_Cast(A_arbace_pprint_A_const_pool.A[261]); A_arbace_pprint_A_const_58 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[262]); A_arbace_pprint_A_const_59 = jrt.Class_Cast(A_arbace_pprint_A_const_pool.A[263]) }

func A_arbace_pprint_A_clinit_p5() { A_arbace_pprint_A_const_60 = jrt.Class_Cast(A_arbace_pprint_A_const_pool.A[264]); A_arbace_pprint_A_const_61 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[265]); A_arbace_pprint_A_const_62 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[266]); A_arbace_pprint_A_const_63 = A_arbace_pprint_A_const_pool.A[267]; A_arbace_pprint_A_const_64 = A_arbace_pprint_A_const_pool.A[268]; A_arbace_pprint_A_const_65 = A_arbace_pprint_A_const_pool.A[269]; A_arbace_pprint_A_const_66 = A_arbace_pprint_A_const_pool.A[270]; A_arbace_pprint_A_const_67 = A_arbace_pprint_A_const_pool.A[271]; A_arbace_pprint_A_const_68 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[272]); A_arbace_pprint_A_const_69 = A_arbace_pprint_A_const_pool.A[273]; A_arbace_pprint_A_const_70 = A_arbace_pprint_A_const_pool.A[274]; A_arbace_pprint_A_const_71 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[275]); A_arbace_pprint_A_const_72 = A_arbace_pprint_A_const_pool.A[276]; A_arbace_pprint_A_const_73 = A_arbace_pprint_A_const_pool.A[277] }

func A_arbace_pprint_A_clinit_p6() { A_arbace_pprint_A_const_74 = A_arbace_pprint_A_const_pool.A[278]; A_arbace_pprint_A_const_75 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[279]); A_arbace_pprint_A_const_76 = A_arbace_pprint_A_const_pool.A[280]; A_arbace_pprint_A_const_77 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[281]); A_arbace_pprint_A_const_78 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[282]); A_arbace_pprint_A_const_79 = A_arbace_pprint_A_const_pool.A[283]; A_arbace_pprint_A_const_80 = A_arbace_pprint_A_const_pool.A[284]; A_arbace_pprint_A_const_81 = A_arbace_pprint_A_const_pool.A[285]; A_arbace_pprint_A_const_82 = A_arbace_pprint_A_const_pool.A[286]; A_arbace_pprint_A_const_83 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[287]); A_arbace_pprint_A_const_84 = A_arbace_pprint_A_const_pool.A[288]; A_arbace_pprint_A_const_85 = A_arbace_pprint_A_const_pool.A[289]; A_arbace_pprint_A_const_86 = A_arbace_pprint_A_const_pool.A[290]; A_arbace_pprint_A_const_87 = A_arbace_pprint_A_const_pool.A[291] }

func A_arbace_pprint_A_clinit_p7() { A_arbace_pprint_A_const_88 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[292]); A_arbace_pprint_A_const_89 = A_arbace_pprint_A_const_pool.A[293]; A_arbace_pprint_A_const_90 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[294]); A_arbace_pprint_A_const_91 = A_arbace_pprint_A_const_pool.A[295]; A_arbace_pprint_A_const_92 = A_arbace_pprint_A_const_pool.A[296]; A_arbace_pprint_A_const_93 = A_arbace_pprint_A_const_pool.A[297]; A_arbace_pprint_A_const_94 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[298]); A_arbace_pprint_A_const_95 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[299]); A_arbace_pprint_A_const_96 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[300]); A_arbace_pprint_A_const_97 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[301]); A_arbace_pprint_A_const_98 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[302]); A_arbace_pprint_A_const_99 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[303]); A_arbace_pprint_A_const_100 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[304]) }

func A_arbace_pprint_A_clinit_p8() { A_arbace_pprint_A_const_101 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[305]); A_arbace_pprint_A_const_102 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[306]); A_arbace_pprint_A_const_103 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[307]); A_arbace_pprint_A_const_104 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[308]); A_arbace_pprint_A_const_105 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[309]); A_arbace_pprint_A_const_106 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[310]); A_arbace_pprint_A_const_107 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[311]); A_arbace_pprint_A_const_108 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[312]); A_arbace_pprint_A_const_109 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[313]); A_arbace_pprint_A_const_110 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[314]); A_arbace_pprint_A_const_111 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[315]); A_arbace_pprint_A_const_112 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[316]) }

func A_arbace_pprint_A_clinit_p9() { A_arbace_pprint_A_const_113 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[317]); A_arbace_pprint_A_const_114 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[318]); A_arbace_pprint_A_const_115 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[319]); A_arbace_pprint_A_const_116 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[320]); A_arbace_pprint_A_const_117 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[321]); A_arbace_pprint_A_const_118 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[322]); A_arbace_pprint_A_const_119 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[323]); A_arbace_pprint_A_const_120 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[324]); A_arbace_pprint_A_const_121 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[325]); A_arbace_pprint_A_const_122 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[326]); A_arbace_pprint_A_const_123 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[327]); A_arbace_pprint_A_const_124 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[328]) }

func A_arbace_pprint_A_clinit_p10() { A_arbace_pprint_A_const_125 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[329]); A_arbace_pprint_A_const_126 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[330]); A_arbace_pprint_A_const_127 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[331]); A_arbace_pprint_A_const_128 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[332]); A_arbace_pprint_A_const_129 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[333]); A_arbace_pprint_A_const_130 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[334]); A_arbace_pprint_A_const_131 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[335]); A_arbace_pprint_A_const_132 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[336]); A_arbace_pprint_A_const_133 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[337]); A_arbace_pprint_A_const_134 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[338]); A_arbace_pprint_A_const_135 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[339]); A_arbace_pprint_A_const_136 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[340]) }

func A_arbace_pprint_A_clinit_p11() { A_arbace_pprint_A_const_137 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[341]); A_arbace_pprint_A_const_138 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[342]); A_arbace_pprint_A_const_139 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[343]); A_arbace_pprint_A_const_140 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[344]); A_arbace_pprint_A_const_141 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[345]); A_arbace_pprint_A_const_142 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[346]); A_arbace_pprint_A_const_143 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[347]); A_arbace_pprint_A_const_144 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[348]); A_arbace_pprint_A_const_145 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[349]); A_arbace_pprint_A_const_146 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[350]); A_arbace_pprint_A_const_147 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[351]); A_arbace_pprint_A_const_148 = A_arbace_pprint_A_const_pool.A[352] }

func A_arbace_pprint_A_clinit_p12() { A_arbace_pprint_A_const_149 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[353]); A_arbace_pprint_A_const_150 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[354]); A_arbace_pprint_A_const_151 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[355]); A_arbace_pprint_A_const_152 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[356]); A_arbace_pprint_A_const_153 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[357]); A_arbace_pprint_A_const_154 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[358]); A_arbace_pprint_A_const_155 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[359]); A_arbace_pprint_A_const_156 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[360]); A_arbace_pprint_A_const_157 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[361]); A_arbace_pprint_A_const_158 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[362]); A_arbace_pprint_A_const_159 = A_arbace_pprint_A_const_pool.A[363]; A_arbace_pprint_A_const_160 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[364]) }

func A_arbace_pprint_A_clinit_p13() { A_arbace_pprint_A_const_161 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[365]); A_arbace_pprint_A_const_162 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[366]); A_arbace_pprint_A_const_163 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[367]); A_arbace_pprint_A_const_164 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[368]); A_arbace_pprint_A_const_165 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[369]); A_arbace_pprint_A_const_166 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[370]); A_arbace_pprint_A_const_167 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[371]); A_arbace_pprint_A_const_168 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[372]); A_arbace_pprint_A_const_169 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[373]); A_arbace_pprint_A_const_170 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[374]); A_arbace_pprint_A_const_171 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[375]); A_arbace_pprint_A_const_172 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[376]) }

func A_arbace_pprint_A_clinit_p14() { A_arbace_pprint_A_const_173 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[377]); A_arbace_pprint_A_const_174 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[378]); A_arbace_pprint_A_const_175 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[379]); A_arbace_pprint_A_const_176 = A_arbace_pprint_A_const_pool.A[380]; A_arbace_pprint_A_const_177 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[381]); A_arbace_pprint_A_const_178 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[382]); A_arbace_pprint_A_const_179 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[383]); A_arbace_pprint_A_const_180 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[384]); A_arbace_pprint_A_const_181 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[385]); A_arbace_pprint_A_const_182 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[386]); A_arbace_pprint_A_const_183 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[387]); A_arbace_pprint_A_const_184 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[388]) }

func A_arbace_pprint_A_clinit_p15() { A_arbace_pprint_A_const_185 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[389]); A_arbace_pprint_A_const_186 = A_arbace_pprint_A_const_pool.A[390]; A_arbace_pprint_A_const_187 = A_arbace_pprint_A_const_pool.A[391]; A_arbace_pprint_A_const_188 = A_arbace_pprint_A_const_pool.A[392]; A_arbace_pprint_A_const_189 = A_arbace_pprint_A_const_pool.A[393]; A_arbace_pprint_A_const_190 = A_arbace_pprint_A_const_pool.A[394]; A_arbace_pprint_A_const_191 = A_arbace_pprint_A_const_pool.A[395]; A_arbace_pprint_A_const_192 = A_arbace_pprint_A_const_pool.A[396]; A_arbace_pprint_A_const_193 = A_arbace_pprint_A_const_pool.A[397]; A_arbace_pprint_A_const_194 = A_arbace_pprint_A_const_pool.A[398]; A_arbace_pprint_A_const_195 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[399]); A_arbace_pprint_A_const_196 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[400]); A_arbace_pprint_A_const_197 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[401]); A_arbace_pprint_A_const_198 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[402]) }

func A_arbace_pprint_A_clinit_p16() { A_arbace_pprint_A_const_199 = A_arbace_pprint_A_const_pool.A[403]; A_arbace_pprint_A_const_200 = A_arbace_pprint_A_const_pool.A[404]; A_arbace_pprint_A_const_201 = A_arbace_pprint_A_const_pool.A[405]; A_arbace_pprint_A_const_202 = A_arbace_pprint_A_const_pool.A[406]; A_arbace_pprint_A_const_203 = A_arbace_pprint_A_const_pool.A[407]; A_arbace_pprint_A_const_204 = A_arbace_pprint_A_const_pool.A[408]; A_arbace_pprint_A_const_205 = A_arbace_pprint_A_const_pool.A[409]; A_arbace_pprint_A_const_206 = A_arbace_pprint_A_const_pool.A[410]; A_arbace_pprint_A_const_207 = A_arbace_pprint_A_const_pool.A[411]; A_arbace_pprint_A_const_208 = A_arbace_pprint_A_const_pool.A[412]; A_arbace_pprint_A_const_209 = A_arbace_pprint_A_const_pool.A[413]; A_arbace_pprint_A_const_210 = A_arbace_pprint_A_const_pool.A[414]; A_arbace_pprint_A_const_211 = A_arbace_pprint_A_const_pool.A[415]; A_arbace_pprint_A_const_212 = A_arbace_pprint_A_const_pool.A[416]; A_arbace_pprint_A_const_213 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[417]) }

func A_arbace_pprint_A_clinit_p17() { A_arbace_pprint_A_const_214 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[418]); A_arbace_pprint_A_const_215 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[419]); A_arbace_pprint_A_const_216 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[420]); A_arbace_pprint_A_const_217 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[421]); A_arbace_pprint_A_const_218 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[422]); A_arbace_pprint_A_const_219 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[423]); A_arbace_pprint_A_const_220 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[424]); A_arbace_pprint_A_const_221 = A_arbace_pprint_A_const_pool.A[425]; A_arbace_pprint_A_const_222 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[426]); A_arbace_pprint_A_const_223 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[427]); A_arbace_pprint_A_const_224 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[428]); A_arbace_pprint_A_const_225 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[429]) }

func A_arbace_pprint_A_clinit_p18() { A_arbace_pprint_A_const_226 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[430]); A_arbace_pprint_A_const_227 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[431]); A_arbace_pprint_A_const_228 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[432]); A_arbace_pprint_A_const_229 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[433]); A_arbace_pprint_A_const_230 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[434]); A_arbace_pprint_A_const_231 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[435]); A_arbace_pprint_A_const_232 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[436]); A_arbace_pprint_A_const_233 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[437]); A_arbace_pprint_A_const_234 = A_arbace_pprint_A_const_pool.A[438]; A_arbace_pprint_A_const_235 = A_arbace_pprint_A_const_pool.A[439]; A_arbace_pprint_A_const_236 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[440]); A_arbace_pprint_A_const_237 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[441]) }

func A_arbace_pprint_A_clinit_p19() { A_arbace_pprint_A_const_238 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[442]); A_arbace_pprint_A_const_239 = A_arbace_pprint_A_const_pool.A[443]; A_arbace_pprint_A_const_240 = A_arbace_pprint_A_const_pool.A[444]; A_arbace_pprint_A_const_241 = A_arbace_pprint_A_const_pool.A[445]; A_arbace_pprint_A_const_242 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[446]); A_arbace_pprint_A_const_243 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[447]); A_arbace_pprint_A_const_244 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[448]); A_arbace_pprint_A_const_245 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[449]); A_arbace_pprint_A_const_246 = A_arbace_pprint_A_const_pool.A[450]; A_arbace_pprint_A_const_247 = A_arbace_pprint_A_const_pool.A[451]; A_arbace_pprint_A_const_248 = A_arbace_pprint_A_const_pool.A[452]; A_arbace_pprint_A_const_249 = A_arbace_pprint_A_const_pool.A[453]; A_arbace_pprint_A_const_250 = A_arbace_pprint_A_const_pool.A[454]; A_arbace_pprint_A_const_251 = A_arbace_pprint_A_const_pool.A[455] }

func A_arbace_pprint_A_clinit_p20() { A_arbace_pprint_A_const_252 = A_arbace_pprint_A_const_pool.A[456]; A_arbace_pprint_A_const_253 = A_arbace_pprint_A_const_pool.A[457]; A_arbace_pprint_A_const_254 = A_arbace_pprint_A_const_pool.A[458]; A_arbace_pprint_A_const_255 = A_arbace_pprint_A_const_pool.A[459]; A_arbace_pprint_A_const_256 = A_arbace_pprint_A_const_pool.A[460]; A_arbace_pprint_A_const_257 = A_arbace_pprint_A_const_pool.A[461]; A_arbace_pprint_A_const_258 = A_arbace_pprint_A_const_pool.A[462]; A_arbace_pprint_A_const_259 = A_arbace_pprint_A_const_pool.A[463]; A_arbace_pprint_A_const_260 = A_arbace_pprint_A_const_pool.A[464]; A_arbace_pprint_A_const_261 = A_arbace_pprint_A_const_pool.A[465]; A_arbace_pprint_A_const_262 = A_arbace_pprint_A_const_pool.A[466]; A_arbace_pprint_A_const_263 = A_arbace_pprint_A_const_pool.A[467]; A_arbace_pprint_A_const_264 = A_arbace_pprint_A_const_pool.A[468]; A_arbace_pprint_A_const_265 = A_arbace_pprint_A_const_pool.A[469]; A_arbace_pprint_A_const_266 = A_arbace_pprint_A_const_pool.A[470] }

func A_arbace_pprint_A_clinit_p21() { A_arbace_pprint_A_const_267 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[471]); A_arbace_pprint_A_const_268 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[472]); A_arbace_pprint_A_const_269 = A_arbace_pprint_A_const_pool.A[473]; A_arbace_pprint_A_const_270 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[474]); A_arbace_pprint_A_const_271 = A_arbace_pprint_A_const_pool.A[475]; A_arbace_pprint_A_const_272 = A_arbace_pprint_A_const_pool.A[476]; A_arbace_pprint_A_const_273 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[477]); A_arbace_pprint_A_const_274 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[478]); A_arbace_pprint_A_const_275 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[479]); A_arbace_pprint_A_const_276 = A_arbace_pprint_A_const_pool.A[480]; A_arbace_pprint_A_const_277 = A_arbace_pprint_A_const_pool.A[481]; A_arbace_pprint_A_const_278 = A_arbace_pprint_A_const_pool.A[482]; A_arbace_pprint_A_const_279 = A_arbace_pprint_A_const_pool.A[483] }

func A_arbace_pprint_A_clinit_p22() { A_arbace_pprint_A_const_280 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[484]); A_arbace_pprint_A_const_281 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[485]); A_arbace_pprint_A_const_282 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[486]); A_arbace_pprint_A_const_283 = A_arbace_pprint_A_const_pool.A[487]; A_arbace_pprint_A_const_284 = A_arbace_pprint_A_const_pool.A[488]; A_arbace_pprint_A_const_285 = A_arbace_pprint_A_const_pool.A[489]; A_arbace_pprint_A_const_286 = A_arbace_pprint_A_const_pool.A[490]; A_arbace_pprint_A_const_287 = A_arbace_pprint_A_const_pool.A[491]; A_arbace_pprint_A_const_288 = A_arbace_pprint_A_const_pool.A[492]; A_arbace_pprint_A_const_289 = A_arbace_pprint_A_const_pool.A[493]; A_arbace_pprint_A_const_290 = A_arbace_pprint_A_const_pool.A[494]; A_arbace_pprint_A_const_291 = A_arbace_pprint_A_const_pool.A[495]; A_arbace_pprint_A_const_292 = A_arbace_pprint_A_const_pool.A[496]; A_arbace_pprint_A_const_293 = A_arbace_pprint_A_const_pool.A[497] }

func A_arbace_pprint_A_clinit_p23() { A_arbace_pprint_A_const_294 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[498]); A_arbace_pprint_A_const_295 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[499]); A_arbace_pprint_A_const_296 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[500]); A_arbace_pprint_A_const_297 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[501]); A_arbace_pprint_A_const_298 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[502]); A_arbace_pprint_A_const_299 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[503]); A_arbace_pprint_A_const_300 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[504]); A_arbace_pprint_A_const_301 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[505]); A_arbace_pprint_A_const_302 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[506]); A_arbace_pprint_A_const_303 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[507]); A_arbace_pprint_A_const_304 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[508]); A_arbace_pprint_A_const_305 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[509]) }

func A_arbace_pprint_A_clinit_p24() { A_arbace_pprint_A_const_306 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[510]); A_arbace_pprint_A_const_307 = A_arbace_pprint_A_const_pool.A[511]; A_arbace_pprint_A_const_308 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[512]); A_arbace_pprint_A_const_309 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[513]); A_arbace_pprint_A_const_310 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[514]); A_arbace_pprint_A_const_311 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[515]); A_arbace_pprint_A_const_312 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[516]); A_arbace_pprint_A_const_313 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[517]); A_arbace_pprint_A_const_314 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[518]); A_arbace_pprint_A_const_315 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[519]); A_arbace_pprint_A_const_316 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[520]); A_arbace_pprint_A_const_317 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[521]) }

func A_arbace_pprint_A_clinit_p25() { A_arbace_pprint_A_const_318 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[522]); A_arbace_pprint_A_const_319 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[523]); A_arbace_pprint_A_const_320 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[524]); A_arbace_pprint_A_const_321 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[525]); A_arbace_pprint_A_const_322 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[526]); A_arbace_pprint_A_const_323 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[527]); A_arbace_pprint_A_const_324 = A_arbace_pprint_A_const_pool.A[528]; A_arbace_pprint_A_const_325 = A_arbace_pprint_A_const_pool.A[529]; A_arbace_pprint_A_const_326 = A_arbace_pprint_A_const_pool.A[530]; A_arbace_pprint_A_const_327 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[531]); A_arbace_pprint_A_const_328 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[532]); A_arbace_pprint_A_const_329 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[533]) }

func A_arbace_pprint_A_clinit_p26() { A_arbace_pprint_A_const_330 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[534]); A_arbace_pprint_A_const_331 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[535]); A_arbace_pprint_A_const_332 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[536]); A_arbace_pprint_A_const_333 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[537]); A_arbace_pprint_A_const_334 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[538]); A_arbace_pprint_A_const_335 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[539]); A_arbace_pprint_A_const_336 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[540]); A_arbace_pprint_A_const_337 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[541]); A_arbace_pprint_A_const_338 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[542]); A_arbace_pprint_A_const_339 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[543]); A_arbace_pprint_A_const_340 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[544]); A_arbace_pprint_A_const_341 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[545]) }

func A_arbace_pprint_A_clinit_p27() { A_arbace_pprint_A_const_342 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[546]); A_arbace_pprint_A_const_343 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[547]); A_arbace_pprint_A_const_344 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[548]); A_arbace_pprint_A_const_345 = A_arbace_pprint_A_const_pool.A[549]; A_arbace_pprint_A_const_346 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[550]); A_arbace_pprint_A_const_347 = A_arbace_pprint_A_const_pool.A[551]; A_arbace_pprint_A_const_348 = A_arbace_pprint_A_const_pool.A[552]; A_arbace_pprint_A_const_349 = A_arbace_pprint_A_const_pool.A[553]; A_arbace_pprint_A_const_350 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[554]); A_arbace_pprint_A_const_351 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[555]); A_arbace_pprint_A_const_352 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[556]); A_arbace_pprint_A_const_353 = A_arbace_pprint_A_const_pool.A[557]; A_arbace_pprint_A_const_354 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[558]) }

func A_arbace_pprint_A_clinit_p28() { A_arbace_pprint_A_const_355 = A_arbace_pprint_A_const_pool.A[559]; A_arbace_pprint_A_const_356 = A_arbace_pprint_A_const_pool.A[560]; A_arbace_pprint_A_const_357 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[561]); A_arbace_pprint_A_const_358 = A_arbace_pprint_A_const_pool.A[562]; A_arbace_pprint_A_const_359 = A_arbace_pprint_A_const_pool.A[563]; A_arbace_pprint_A_const_360 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[564]); A_arbace_pprint_A_const_361 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[565]); A_arbace_pprint_A_const_362 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[566]); A_arbace_pprint_A_const_363 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[567]); A_arbace_pprint_A_const_364 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[568]); A_arbace_pprint_A_const_365 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[569]); A_arbace_pprint_A_const_366 = A_arbace_pprint_A_const_pool.A[570]; A_arbace_pprint_A_const_367 = A_arbace_pprint_A_const_pool.A[571] }

func A_arbace_pprint_A_clinit_p29() { A_arbace_pprint_A_const_368 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[572]); A_arbace_pprint_A_const_369 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[573]); A_arbace_pprint_A_const_370 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[574]); A_arbace_pprint_A_const_371 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[575]); A_arbace_pprint_A_const_372 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[576]); A_arbace_pprint_A_const_373 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[577]); A_arbace_pprint_A_const_374 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[578]); A_arbace_pprint_A_const_375 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[579]); A_arbace_pprint_A_const_376 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[580]); A_arbace_pprint_A_const_377 = A_arbace_pprint_A_const_pool.A[581]; A_arbace_pprint_A_const_378 = A_arbace_pprint_A_const_pool.A[582]; A_arbace_pprint_A_const_379 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[583]) }

func A_arbace_pprint_A_clinit_p30() { A_arbace_pprint_A_const_380 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[584]); A_arbace_pprint_A_const_381 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[585]); A_arbace_pprint_A_const_382 = A_arbace_pprint_A_const_pool.A[586]; A_arbace_pprint_A_const_383 = A_arbace_pprint_A_const_pool.A[587]; A_arbace_pprint_A_const_384 = A_arbace_pprint_A_const_pool.A[588]; A_arbace_pprint_A_const_385 = A_arbace_pprint_A_const_pool.A[589]; A_arbace_pprint_A_const_386 = A_arbace_pprint_A_const_pool.A[590]; A_arbace_pprint_A_const_387 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[591]); A_arbace_pprint_A_const_388 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[592]); A_arbace_pprint_A_const_389 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[593]); A_arbace_pprint_A_const_390 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[594]); A_arbace_pprint_A_const_391 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[595]); A_arbace_pprint_A_const_392 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[596]) }

func A_arbace_pprint_A_clinit_p31() { A_arbace_pprint_A_const_393 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[597]); A_arbace_pprint_A_const_394 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[598]); A_arbace_pprint_A_const_395 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[599]); A_arbace_pprint_A_const_396 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[600]); A_arbace_pprint_A_const_397 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[601]); A_arbace_pprint_A_const_398 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[602]); A_arbace_pprint_A_const_399 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[603]); A_arbace_pprint_A_const_400 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[604]); A_arbace_pprint_A_const_401 = A_arbace_pprint_A_const_pool.A[605]; A_arbace_pprint_A_const_402 = A_arbace_pprint_A_const_pool.A[606]; A_arbace_pprint_A_const_403 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[607]); A_arbace_pprint_A_const_404 = A_arbace_pprint_A_const_pool.A[608] }

func A_arbace_pprint_A_clinit_p32() { A_arbace_pprint_A_const_405 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[609]); A_arbace_pprint_A_const_406 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[610]); A_arbace_pprint_A_const_407 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[611]); A_arbace_pprint_A_const_408 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[612]); A_arbace_pprint_A_const_409 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[613]); A_arbace_pprint_A_const_410 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[614]); A_arbace_pprint_A_const_411 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[615]); A_arbace_pprint_A_const_412 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[616]); A_arbace_pprint_A_const_413 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[617]); A_arbace_pprint_A_const_414 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[618]); A_arbace_pprint_A_const_415 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[619]); A_arbace_pprint_A_const_416 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[620]) }

func A_arbace_pprint_A_clinit_p33() { A_arbace_pprint_A_const_417 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[621]); A_arbace_pprint_A_const_418 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[622]); A_arbace_pprint_A_const_419 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[623]); A_arbace_pprint_A_const_420 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[624]); A_arbace_pprint_A_const_421 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[625]); A_arbace_pprint_A_const_422 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[626]); A_arbace_pprint_A_const_423 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[627]); A_arbace_pprint_A_const_424 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[628]); A_arbace_pprint_A_const_425 = A_arbace_pprint_A_const_pool.A[629]; A_arbace_pprint_A_const_426 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[630]); A_arbace_pprint_A_const_427 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[631]); A_arbace_pprint_A_const_428 = A_arbace_pprint_A_const_pool.A[632] }

func A_arbace_pprint_A_clinit_p34() { A_arbace_pprint_A_const_429 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[633]); A_arbace_pprint_A_const_430 = A_arbace_pprint_A_const_pool.A[634]; A_arbace_pprint_A_const_431 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[635]); A_arbace_pprint_A_const_432 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[636]); A_arbace_pprint_A_const_433 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[637]); A_arbace_pprint_A_const_434 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[638]); A_arbace_pprint_A_const_435 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[639]); A_arbace_pprint_A_const_436 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[640]); A_arbace_pprint_A_const_437 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[641]); A_arbace_pprint_A_const_438 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[642]); A_arbace_pprint_A_const_439 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[643]); A_arbace_pprint_A_const_440 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[644]) }

func A_arbace_pprint_A_clinit_p35() { A_arbace_pprint_A_const_441 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[645]); A_arbace_pprint_A_const_442 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[646]); A_arbace_pprint_A_const_443 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[647]); A_arbace_pprint_A_const_444 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[648]); A_arbace_pprint_A_const_445 = A_arbace_pprint_A_const_pool.A[649]; A_arbace_pprint_A_const_446 = A_arbace_pprint_A_const_pool.A[650]; A_arbace_pprint_A_const_447 = A_arbace_pprint_A_const_pool.A[651]; A_arbace_pprint_A_const_448 = A_arbace_pprint_A_const_pool.A[652]; A_arbace_pprint_A_const_449 = A_arbace_pprint_A_const_pool.A[653]; A_arbace_pprint_A_const_450 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[654]); A_arbace_pprint_A_const_451 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[655]); A_arbace_pprint_A_const_452 = A_arbace_pprint_A_const_pool.A[656]; A_arbace_pprint_A_const_453 = A_arbace_pprint_A_const_pool.A[657] }

func A_arbace_pprint_A_clinit_p36() { A_arbace_pprint_A_const_454 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[658]); A_arbace_pprint_A_const_455 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[659]); A_arbace_pprint_A_const_456 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[660]); A_arbace_pprint_A_const_457 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[661]); A_arbace_pprint_A_const_458 = A_arbace_pprint_A_const_pool.A[662]; A_arbace_pprint_A_const_459 = A_arbace_pprint_A_const_pool.A[663]; A_arbace_pprint_A_const_460 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[664]); A_arbace_pprint_A_const_461 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[665]); A_arbace_pprint_A_const_462 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[666]); A_arbace_pprint_A_const_463 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[667]); A_arbace_pprint_A_const_464 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[668]); A_arbace_pprint_A_const_465 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[669]) }

func A_arbace_pprint_A_clinit_p37() { A_arbace_pprint_A_const_466 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[670]); A_arbace_pprint_A_const_467 = A_arbace_pprint_A_const_pool.A[671]; A_arbace_pprint_A_const_468 = A_arbace_pprint_A_const_pool.A[672]; A_arbace_pprint_A_const_469 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[673]); A_arbace_pprint_A_const_470 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[674]); A_arbace_pprint_A_const_471 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[675]); A_arbace_pprint_A_const_472 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[676]); A_arbace_pprint_A_const_473 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[677]); A_arbace_pprint_A_const_474 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[678]); A_arbace_pprint_A_const_475 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[679]); A_arbace_pprint_A_const_476 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[680]); A_arbace_pprint_A_const_477 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[681]) }

func A_arbace_pprint_A_clinit_p38() { A_arbace_pprint_A_const_478 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[682]); A_arbace_pprint_A_const_479 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[683]); A_arbace_pprint_A_const_480 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[684]); A_arbace_pprint_A_const_481 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[685]); A_arbace_pprint_A_const_482 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[686]); A_arbace_pprint_A_const_483 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[687]); A_arbace_pprint_A_const_484 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[688]); A_arbace_pprint_A_const_485 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[689]); A_arbace_pprint_A_const_486 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[690]); A_arbace_pprint_A_const_487 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[691]); A_arbace_pprint_A_const_488 = A_arbace_pprint_A_const_pool.A[692]; A_arbace_pprint_A_const_489 = A_arbace_pprint_A_const_pool.A[693] }

func A_arbace_pprint_A_clinit_p39() { A_arbace_pprint_A_const_490 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[694]); A_arbace_pprint_A_const_491 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[695]); A_arbace_pprint_A_const_492 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[696]); A_arbace_pprint_A_const_493 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[697]); A_arbace_pprint_A_const_494 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[698]); A_arbace_pprint_A_const_495 = A_arbace_pprint_A_const_pool.A[699]; A_arbace_pprint_A_const_496 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[700]); A_arbace_pprint_A_const_497 = A_arbace_pprint_A_const_pool.A[701]; A_arbace_pprint_A_const_498 = A_arbace_pprint_A_const_pool.A[702]; A_arbace_pprint_A_const_499 = A_arbace_pprint_A_const_pool.A[703]; A_arbace_pprint_A_const_500 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[704]); A_arbace_pprint_A_const_501 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[705]); A_arbace_pprint_A_const_502 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[706]) }

func A_arbace_pprint_A_clinit_p40() { A_arbace_pprint_A_const_503 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[707]); A_arbace_pprint_A_const_504 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[708]); A_arbace_pprint_A_const_505 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[709]); A_arbace_pprint_A_const_506 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[710]); A_arbace_pprint_A_const_507 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[711]); A_arbace_pprint_A_const_508 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[712]); A_arbace_pprint_A_const_509 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[713]); A_arbace_pprint_A_const_510 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[714]); A_arbace_pprint_A_const_511 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[715]); A_arbace_pprint_A_const_512 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[716]); A_arbace_pprint_A_const_513 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[717]); A_arbace_pprint_A_const_514 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[718]) }

func A_arbace_pprint_A_clinit_p41() { A_arbace_pprint_A_const_515 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[719]); A_arbace_pprint_A_const_516 = A_arbace_pprint_A_const_pool.A[720]; A_arbace_pprint_A_const_517 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[721]); A_arbace_pprint_A_const_518 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[722]); A_arbace_pprint_A_const_519 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[723]); A_arbace_pprint_A_const_520 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[724]); A_arbace_pprint_A_const_521 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[725]); A_arbace_pprint_A_const_522 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[726]); A_arbace_pprint_A_const_523 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[727]); A_arbace_pprint_A_const_524 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[728]); A_arbace_pprint_A_const_525 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[729]); A_arbace_pprint_A_const_526 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[730]) }

func A_arbace_pprint_A_clinit_p42() { A_arbace_pprint_A_const_527 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[731]); A_arbace_pprint_A_const_528 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[732]); A_arbace_pprint_A_const_529 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[733]); A_arbace_pprint_A_const_530 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[734]); A_arbace_pprint_A_const_531 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[735]); A_arbace_pprint_A_const_532 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[736]); A_arbace_pprint_A_const_533 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[737]); A_arbace_pprint_A_const_534 = lang.Keyword_Cast(A_arbace_pprint_A_const_pool.A[738]); A_arbace_pprint_A_const_535 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[739]); A_arbace_pprint_A_const_536 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[740]); A_arbace_pprint_A_const_537 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[741]); A_arbace_pprint_A_const_538 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[742]) }

func A_arbace_pprint_A_clinit_p43() { A_arbace_pprint_A_const_539 = A_arbace_pprint_A_const_pool.A[743]; A_arbace_pprint_A_const_540 = A_arbace_pprint_A_const_pool.A[744]; A_arbace_pprint_A_const_541 = A_arbace_pprint_A_const_pool.A[745]; A_arbace_pprint_A_const_542 = A_arbace_pprint_A_const_pool.A[746]; A_arbace_pprint_A_const_543 = A_arbace_pprint_A_const_pool.A[747]; A_arbace_pprint_A_const_544 = A_arbace_pprint_A_const_pool.A[748]; A_arbace_pprint_A_const_545 = A_arbace_pprint_A_const_pool.A[749]; A_arbace_pprint_A_const_546 = A_arbace_pprint_A_const_pool.A[750]; A_arbace_pprint_A_const_547 = A_arbace_pprint_A_const_pool.A[751]; A_arbace_pprint_A_const_548 = A_arbace_pprint_A_const_pool.A[752]; A_arbace_pprint_A_const_549 = A_arbace_pprint_A_const_pool.A[753]; A_arbace_pprint_A_const_550 = A_arbace_pprint_A_const_pool.A[754]; A_arbace_pprint_A_const_551 = A_arbace_pprint_A_const_pool.A[755]; A_arbace_pprint_A_const_552 = A_arbace_pprint_A_const_pool.A[756]; A_arbace_pprint_A_const_553 = A_arbace_pprint_A_const_pool.A[757]; A_arbace_pprint_A_const_554 = A_arbace_pprint_A_const_pool.A[758] }

func A_arbace_pprint_A_clinit_p44() { A_arbace_pprint_A_const_555 = A_arbace_pprint_A_const_pool.A[759]; A_arbace_pprint_A_const_556 = A_arbace_pprint_A_const_pool.A[760]; A_arbace_pprint_A_const_557 = A_arbace_pprint_A_const_pool.A[761]; A_arbace_pprint_A_const_558 = A_arbace_pprint_A_const_pool.A[762]; A_arbace_pprint_A_const_559 = A_arbace_pprint_A_const_pool.A[763]; A_arbace_pprint_A_const_560 = A_arbace_pprint_A_const_pool.A[764]; A_arbace_pprint_A_const_561 = A_arbace_pprint_A_const_pool.A[765]; A_arbace_pprint_A_const_562 = A_arbace_pprint_A_const_pool.A[766]; A_arbace_pprint_A_const_563 = A_arbace_pprint_A_const_pool.A[767]; A_arbace_pprint_A_const_564 = A_arbace_pprint_A_const_pool.A[768]; A_arbace_pprint_A_const_565 = A_arbace_pprint_A_const_pool.A[769]; A_arbace_pprint_A_const_566 = A_arbace_pprint_A_const_pool.A[770]; A_arbace_pprint_A_const_567 = A_arbace_pprint_A_const_pool.A[771]; A_arbace_pprint_A_const_568 = A_arbace_pprint_A_const_pool.A[772]; A_arbace_pprint_A_const_569 = A_arbace_pprint_A_const_pool.A[773]; A_arbace_pprint_A_const_570 = A_arbace_pprint_A_const_pool.A[774] }

func A_arbace_pprint_A_clinit_p45() { A_arbace_pprint_A_const_571 = A_arbace_pprint_A_const_pool.A[775]; A_arbace_pprint_A_const_572 = A_arbace_pprint_A_const_pool.A[776]; A_arbace_pprint_A_const_573 = A_arbace_pprint_A_const_pool.A[777]; A_arbace_pprint_A_const_574 = A_arbace_pprint_A_const_pool.A[778]; A_arbace_pprint_A_const_575 = A_arbace_pprint_A_const_pool.A[779]; A_arbace_pprint_A_const_576 = A_arbace_pprint_A_const_pool.A[780]; A_arbace_pprint_A_const_577 = A_arbace_pprint_A_const_pool.A[781]; A_arbace_pprint_A_const_578 = A_arbace_pprint_A_const_pool.A[782]; A_arbace_pprint_A_const_579 = A_arbace_pprint_A_const_pool.A[783]; A_arbace_pprint_A_const_580 = A_arbace_pprint_A_const_pool.A[784]; A_arbace_pprint_A_const_581 = A_arbace_pprint_A_const_pool.A[785]; A_arbace_pprint_A_const_582 = A_arbace_pprint_A_const_pool.A[786]; A_arbace_pprint_A_const_583 = A_arbace_pprint_A_const_pool.A[787]; A_arbace_pprint_A_const_584 = A_arbace_pprint_A_const_pool.A[788]; A_arbace_pprint_A_const_585 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[789]) }

func A_arbace_pprint_A_clinit_p46() { A_arbace_pprint_A_const_586 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[790]); A_arbace_pprint_A_const_587 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[791]); A_arbace_pprint_A_const_588 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[792]); A_arbace_pprint_A_const_589 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[793]); A_arbace_pprint_A_const_590 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[794]); A_arbace_pprint_A_const_591 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[795]); A_arbace_pprint_A_const_592 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[796]); A_arbace_pprint_A_const_593 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[797]); A_arbace_pprint_A_const_594 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[798]); A_arbace_pprint_A_const_595 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[799]); A_arbace_pprint_A_const_596 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[800]); A_arbace_pprint_A_const_597 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[801]) }

func A_arbace_pprint_A_clinit_p47() { A_arbace_pprint_A_const_598 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[802]); A_arbace_pprint_A_const_599 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[803]); A_arbace_pprint_A_const_600 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[804]); A_arbace_pprint_A_const_601 = A_arbace_pprint_A_const_pool.A[805]; A_arbace_pprint_A_const_602 = A_arbace_pprint_A_const_pool.A[806]; A_arbace_pprint_A_const_603 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[807]); A_arbace_pprint_A_const_604 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[808]); A_arbace_pprint_A_const_605 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[809]); A_arbace_pprint_A_const_606 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[810]); A_arbace_pprint_A_const_607 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[811]); A_arbace_pprint_A_const_608 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[812]); A_arbace_pprint_A_const_609 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[813]) }

func A_arbace_pprint_A_clinit_p48() { A_arbace_pprint_A_const_610 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[814]); A_arbace_pprint_A_const_611 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[815]); A_arbace_pprint_A_const_612 = A_arbace_pprint_A_const_pool.A[816]; A_arbace_pprint_A_const_613 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[817]); A_arbace_pprint_A_const_614 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[818]); A_arbace_pprint_A_const_615 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[819]); A_arbace_pprint_A_const_616 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[820]); A_arbace_pprint_A_const_617 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[821]); A_arbace_pprint_A_const_618 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[822]); A_arbace_pprint_A_const_619 = lang.Var_Cast(A_arbace_pprint_A_const_pool.A[823]) }

func A_arbace_pprint_A_New() *A_arbace_pprint_A { A_arbace_pprint_A_Init(); t := &A_arbace_pprint_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_A) Ctor() {}

func (t *A_arbace_pprint_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_A_class }

func (t *A_arbace_pprint_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_A); return ok }

func A_arbace_pprint_A_Cast(x any) *A_arbace_pprint_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_A_class)) }; return v }



type A_arbace_pprint_abort_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_abort_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_absolute_reposition_A struct{ a2g_header uint64 }

var A_arbace_pprint_absolute_reposition_A_fn_class *jrt.Class



type A_arbace_pprint_absolute_tabulation_A struct{ a2g_header uint64 }

var A_arbace_pprint_absolute_tabulation_A_fn_class *jrt.Class



type A_arbace_pprint_add_core_ns_A struct{ a2g_header uint64 }

var A_arbace_pprint_add_core_ns_A_fn_class *jrt.Class



type A_arbace_pprint_add_core_ns_fn__740000193_A struct{ a2g_header uint64; F_core any }

var A_arbace_pprint_add_core_ns_fn__740000193_A_fn_class *jrt.Class



type A_arbace_pprint_add_english_scales_A struct{ a2g_header uint64 }

var A_arbace_pprint_add_english_scales_A_fn_class *jrt.Class



type A_arbace_pprint_add_to_buffer_A struct{ a2g_header uint64 }

var A_arbace_pprint_add_to_buffer_A_fn_class *jrt.Class



type A_arbace_pprint_add_to_buffer_fn__1820000156_A struct{ a2g_header uint64; F_token, F_this any }

var A_arbace_pprint_add_to_buffer_fn__1820000156_A_fn_class *jrt.Class



type A_arbace_pprint_ancestor_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_ancestor_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_base_str_A struct{ a2g_header uint64 }

var A_arbace_pprint_base_str_A_fn_class *jrt.Class



type A_arbace_pprint_base_str_fn__1819000039_A struct{ a2g_header uint64 }

var A_arbace_pprint_base_str_fn__1819000039_A_fn_class *jrt.Class



type A_arbace_pprint_binding_map_A struct{ a2g_header uint64 }

var A_arbace_pprint_binding_map_A_fn_class *jrt.Class



type A_arbace_pprint_boolean_conditional_A struct{ a2g_header uint64 }

var A_arbace_pprint_boolean_conditional_A_fn_class *jrt.Class



type A_arbace_pprint_brackets_A struct{ a2g_header uint64 }

var A_arbace_pprint_brackets_A_fn_class *jrt.Class



type A_arbace_pprint_buffer_blob_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_buffer_blob_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_buffer_length_A struct{ a2g_header uint64 }

var A_arbace_pprint_buffer_length_A_fn_class *jrt.Class



type A_arbace_pprint_c_write_char_A struct{ a2g_header uint64 }

var A_arbace_pprint_c_write_char_A_fn_class *jrt.Class



type A_arbace_pprint_c_write_char_fn__44000015_A struct{ a2g_header uint64; F_c, F_this any }

var A_arbace_pprint_c_write_char_fn__44000015_A_fn_class *jrt.Class



type A_arbace_pprint_capitalize_string_A struct{ a2g_header uint64 }

var A_arbace_pprint_capitalize_string_A_fn_class *jrt.Class



type A_arbace_pprint_capitalize_string_fn__1819000234_A struct{ a2g_header uint64 }

var A_arbace_pprint_capitalize_string_fn__1819000234_A_fn_class *jrt.Class



type A_arbace_pprint_capitalize_word_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_capitalize_word_writer_A_fn_class *jrt.Class



type A_arbace_pprint_capitalize_word_writer_fn__1819000237_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_fn_class *jrt.Class



type A_arbace_pprint_capitalize_word_writer_fn__1819000239_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_fn_class *jrt.Class



type A_arbace_pprint_capitalize_word_writer_fn__1819000241_A struct{ a2g_header uint64; F_last_was_whitespace_QMARK_, F_writer any }

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_fn_class *jrt.Class



type A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A struct{ a2g_header uint64; F_last_was_whitespace_QMARK_, F_s any }

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_fn_class *jrt.Class



type A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A struct{ a2g_header uint64; F_last_was_whitespace_QMARK_, F_x any }

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_fn_class *jrt.Class



type A_arbace_pprint_check_arg_conditional_A struct{ a2g_header uint64 }

var A_arbace_pprint_check_arg_conditional_A_fn_class *jrt.Class



type A_arbace_pprint_check_enumerated_arg_A struct{ a2g_header uint64 }

var A_arbace_pprint_check_enumerated_arg_A_fn_class *jrt.Class



type A_arbace_pprint_check_flags_A struct{ a2g_header uint64 }

var A_arbace_pprint_check_flags_A_fn_class *jrt.Class



type A_arbace_pprint_choice_conditional_A struct{ a2g_header uint64 }

var A_arbace_pprint_choice_conditional_A_fn_class *jrt.Class



type A_arbace_pprint_cl_format_A struct{ a2g_header uint64 }

var A_arbace_pprint_cl_format_A_fn_class *jrt.Class



type A_arbace_pprint_collect_clauses_A struct{ a2g_header uint64 }

var A_arbace_pprint_collect_clauses_A_fn_class *jrt.Class



type A_arbace_pprint_collect_clauses_fn__1819000548_A struct{ a2g_header uint64; F_bracket_info, F_offset any }

var A_arbace_pprint_collect_clauses_fn__1819000548_A_fn_class *jrt.Class



type A_arbace_pprint_column_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_column_writer_A_fn_class *jrt.Class



type A_arbace_pprint_column_writer_fn__44000019_A struct{ a2g_header uint64; F_fields any }

var A_arbace_pprint_column_writer_fn__44000019_A_fn_class *jrt.Class



type A_arbace_pprint_column_writer_fn__44000021_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_column_writer_fn__44000021_A_fn_class *jrt.Class



type A_arbace_pprint_column_writer_fn__44000023_A struct{ a2g_header uint64 }

var A_arbace_pprint_column_writer_fn__44000023_A_fn_class *jrt.Class



type A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A struct{ a2g_header uint64; F_s any; F_nl int32; F_this any }

var A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_fn_class *jrt.Class



type A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A struct{ a2g_header uint64 }

var A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_fn_class *jrt.Class



type A_arbace_pprint_compile_directive_A struct{ a2g_header uint64 }

var A_arbace_pprint_compile_directive_A_fn_class *jrt.Class



type A_arbace_pprint_compile_format_A struct{ a2g_header uint64 }

var A_arbace_pprint_compile_format_A_fn_class *jrt.Class



type A_arbace_pprint_compile_format_fn__1819000564_A struct{ a2g_header uint64 }

var A_arbace_pprint_compile_format_fn__1819000564_A_fn_class *jrt.Class



type A_arbace_pprint_compile_raw_string_A struct{ a2g_header uint64 }

var A_arbace_pprint_compile_raw_string_A_fn_class *jrt.Class



type A_arbace_pprint_compile_raw_string_fn__1819000534_A struct{ a2g_header uint64; F_s any }

var A_arbace_pprint_compile_raw_string_fn__1819000534_A_fn_class *jrt.Class



type A_arbace_pprint_conditional_newline_A struct{ a2g_header uint64 }

var A_arbace_pprint_conditional_newline_A_fn_class *jrt.Class



type A_arbace_pprint_consume_A struct{ a2g_header uint64 }

var A_arbace_pprint_consume_A_fn_class *jrt.Class



type A_arbace_pprint_consume_while_A struct{ a2g_header uint64 }

var A_arbace_pprint_consume_while_A_fn_class *jrt.Class



type A_arbace_pprint_convert_ratio_A struct{ a2g_header uint64 }

var A_arbace_pprint_convert_ratio_A_fn_class *jrt.Class



type A_arbace_pprint_defdirectives_A struct{ a2g_header uint64 }

var A_arbace_pprint_defdirectives_A_fn_class *jrt.Class



type A_arbace_pprint_deftype_A struct{ a2g_header uint64 }

var A_arbace_pprint_deftype_A_fn_class *jrt.Class



type A_arbace_pprint_dollar_float_A struct{ a2g_header uint64 }

var A_arbace_pprint_dollar_float_A_fn_class *jrt.Class



type A_arbace_pprint_downcase_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_downcase_writer_A_fn_class *jrt.Class



type A_arbace_pprint_downcase_writer_fn__1819000216_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_downcase_writer_fn__1819000216_A_fn_class *jrt.Class



type A_arbace_pprint_downcase_writer_fn__1819000218_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_downcase_writer_fn__1819000218_A_fn_class *jrt.Class



type A_arbace_pprint_downcase_writer_fn__1819000220_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_downcase_writer_fn__1819000220_A_fn_class *jrt.Class



type A_arbace_pprint_else_separator_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_else_separator_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_emit_nl_A struct{ a2g_header uint64 }

var A_arbace_pprint_emit_nl_A_fn_class *jrt.Class



type A_arbace_pprint_emit_nl_fn__1820000124_A struct{ a2g_header uint64; F_this any }

var A_arbace_pprint_emit_nl_fn__1820000124_A_fn_class *jrt.Class



type A_arbace_pprint_end_block_A struct{ a2g_header uint64 }

var A_arbace_pprint_end_block_A_fn_class *jrt.Class



type A_arbace_pprint_end_block_fn__1820000193_A struct{ a2g_header uint64; F_this any }

var A_arbace_pprint_end_block_fn__1820000193_A_fn_class *jrt.Class



type A_arbace_pprint_end_block_t_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_end_block_t_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_eval1513000004_A struct{ jrt.Object }

func A_arbace_pprint_eval1513000004_A_New() *A_arbace_pprint_eval1513000004_A { t := &A_arbace_pprint_eval1513000004_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1513000004_A) Ctor() {}

func (t *A_arbace_pprint_eval1513000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1513000004_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1513000004_A_class }

func (t *A_arbace_pprint_eval1513000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1513000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1513000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1513000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1513000004_A); return ok }

func A_arbace_pprint_eval1513000004_A_Cast(x any) *A_arbace_pprint_eval1513000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1513000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1513000004_A_class)) }; return v }



type A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_fn_class *jrt.Class



type A_arbace_pprint_eval1513000008_A struct{ jrt.Object }

func A_arbace_pprint_eval1513000008_A_New() *A_arbace_pprint_eval1513000008_A { t := &A_arbace_pprint_eval1513000008_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1513000008_A) Ctor() {}

func (t *A_arbace_pprint_eval1513000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1513000008_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1513000008_A_class }

func (t *A_arbace_pprint_eval1513000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1513000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1513000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1513000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1513000008_A); return ok }

func A_arbace_pprint_eval1513000008_A_Cast(x any) *A_arbace_pprint_eval1513000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1513000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1513000008_A_class)) }; return v }



type A_arbace_pprint_eval1513000008_fn__1513000009_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1513000008_fn__1513000009_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000055_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000055_A_New() *A_arbace_pprint_eval1820000055_A { t := &A_arbace_pprint_eval1820000055_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000055_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000055_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000055_A_class }

func (t *A_arbace_pprint_eval1820000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000055_A); return ok }

func A_arbace_pprint_eval1820000055_A_Cast(x any) *A_arbace_pprint_eval1820000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000055_A_class)) }; return v }



type A_arbace_pprint_eval1820000055_fn__1820000056_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000059_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000059_A_New() *A_arbace_pprint_eval1820000059_A { t := &A_arbace_pprint_eval1820000059_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000059_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000059_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000059_A_class }

func (t *A_arbace_pprint_eval1820000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000059_A); return ok }

func A_arbace_pprint_eval1820000059_A_Cast(x any) *A_arbace_pprint_eval1820000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000059_A_class)) }; return v }



type A_arbace_pprint_eval1820000059_fn__1820000060_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A struct{ a2g_header uint64; F_lb, F_this any }

var A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000065_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000065_A_New() *A_arbace_pprint_eval1820000065_A { t := &A_arbace_pprint_eval1820000065_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000065_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000065_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000065_A_class }

func (t *A_arbace_pprint_eval1820000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000065_A); return ok }

func A_arbace_pprint_eval1820000065_A_Cast(x any) *A_arbace_pprint_eval1820000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000065_A_class)) }; return v }



type A_arbace_pprint_eval1820000065_fn__1820000066_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000069_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000069_A_New() *A_arbace_pprint_eval1820000069_A { t := &A_arbace_pprint_eval1820000069_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000069_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000069_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000069_A_class }

func (t *A_arbace_pprint_eval1820000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000069_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000069_A); return ok }

func A_arbace_pprint_eval1820000069_A_Cast(x any) *A_arbace_pprint_eval1820000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000069_A_class)) }; return v }



type A_arbace_pprint_eval1820000069_fn__1820000070_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000075_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000075_A_New() *A_arbace_pprint_eval1820000075_A { t := &A_arbace_pprint_eval1820000075_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000075_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000075_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000075_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000075_A_class }

func (t *A_arbace_pprint_eval1820000075_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000075_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000075_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000075_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000075_A); return ok }

func A_arbace_pprint_eval1820000075_A_Cast(x any) *A_arbace_pprint_eval1820000075_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000075_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000075_A_class)) }; return v }



type A_arbace_pprint_eval1820000075_fn__1820000076_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000079_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000079_A_New() *A_arbace_pprint_eval1820000079_A { t := &A_arbace_pprint_eval1820000079_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000079_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000079_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000079_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000079_A_class }

func (t *A_arbace_pprint_eval1820000079_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000079_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000079_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000079_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000079_A); return ok }

func A_arbace_pprint_eval1820000079_A_Cast(x any) *A_arbace_pprint_eval1820000079_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000079_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000079_A_class)) }; return v }



type A_arbace_pprint_eval1820000079_fn__1820000080_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A struct{ a2g_header uint64; F_this any }

var A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000093_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000093_A_New() *A_arbace_pprint_eval1820000093_A { t := &A_arbace_pprint_eval1820000093_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000093_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000093_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000093_A_class }

func (t *A_arbace_pprint_eval1820000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000093_A); return ok }

func A_arbace_pprint_eval1820000093_A_Cast(x any) *A_arbace_pprint_eval1820000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000093_A_class)) }; return v }



type A_arbace_pprint_eval1820000093_fn__1820000094_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000097_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000097_A_New() *A_arbace_pprint_eval1820000097_A { t := &A_arbace_pprint_eval1820000097_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000097_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000097_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000097_A_class }

func (t *A_arbace_pprint_eval1820000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000097_A); return ok }

func A_arbace_pprint_eval1820000097_A_Cast(x any) *A_arbace_pprint_eval1820000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000097_A_class)) }; return v }



type A_arbace_pprint_eval1820000097_fn__1820000098_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000101_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000101_A_New() *A_arbace_pprint_eval1820000101_A { t := &A_arbace_pprint_eval1820000101_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000101_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000101_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000101_A_class }

func (t *A_arbace_pprint_eval1820000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000101_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000101_A); return ok }

func A_arbace_pprint_eval1820000101_A_Cast(x any) *A_arbace_pprint_eval1820000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000101_A_class)) }; return v }



type A_arbace_pprint_eval1820000101_fn__1820000102_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000105_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000105_A_New() *A_arbace_pprint_eval1820000105_A { t := &A_arbace_pprint_eval1820000105_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000105_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000105_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000105_A_class }

func (t *A_arbace_pprint_eval1820000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000105_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000105_A); return ok }

func A_arbace_pprint_eval1820000105_A_Cast(x any) *A_arbace_pprint_eval1820000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000105_A_class)) }; return v }



type A_arbace_pprint_eval1820000105_fn__1820000106_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000109_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000109_A_New() *A_arbace_pprint_eval1820000109_A { t := &A_arbace_pprint_eval1820000109_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000109_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000109_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000109_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000109_A_class }

func (t *A_arbace_pprint_eval1820000109_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000109_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000109_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000109_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000109_A); return ok }

func A_arbace_pprint_eval1820000109_A_Cast(x any) *A_arbace_pprint_eval1820000109_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000109_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000109_A_class)) }; return v }



type A_arbace_pprint_eval1820000109_fn__1820000110_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000133_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000133_A_New() *A_arbace_pprint_eval1820000133_A { t := &A_arbace_pprint_eval1820000133_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000133_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000133_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000133_A_class }

func (t *A_arbace_pprint_eval1820000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000133_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000133_A); return ok }

func A_arbace_pprint_eval1820000133_A_Cast(x any) *A_arbace_pprint_eval1820000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000133_A_class)) }; return v }



type A_arbace_pprint_eval1820000133_fn__1820000134_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000137_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000137_A_New() *A_arbace_pprint_eval1820000137_A { t := &A_arbace_pprint_eval1820000137_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000137_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000137_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000137_A_class }

func (t *A_arbace_pprint_eval1820000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000137_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000137_A); return ok }

func A_arbace_pprint_eval1820000137_A_Cast(x any) *A_arbace_pprint_eval1820000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000137_A_class)) }; return v }



type A_arbace_pprint_eval1820000137_fn__1820000138_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class *jrt.Class



type A_arbace_pprint_eval1820000141_A struct{ jrt.Object }

func A_arbace_pprint_eval1820000141_A_New() *A_arbace_pprint_eval1820000141_A { t := &A_arbace_pprint_eval1820000141_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_eval1820000141_A) Ctor() {}

func (t *A_arbace_pprint_eval1820000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_eval1820000141_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_eval1820000141_A_class }

func (t *A_arbace_pprint_eval1820000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_eval1820000141_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_eval1820000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_eval1820000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_eval1820000141_A); return ok }

func A_arbace_pprint_eval1820000141_A_Cast(x any) *A_arbace_pprint_eval1820000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_eval1820000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_eval1820000141_A_class)) }; return v }



type A_arbace_pprint_eval1820000141_fn__1820000142_A struct{ a2g_header uint64 }

var A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class *jrt.Class



type A_arbace_pprint_execute_format_A struct{ a2g_header uint64 }

var A_arbace_pprint_execute_format_A_fn_class *jrt.Class



type A_arbace_pprint_execute_format_fn__1819000571_A struct{ a2g_header uint64; F_format, F_wrapped_stream, F_args, F_real_stream any }

var A_arbace_pprint_execute_format_fn__1819000571_A_fn_class *jrt.Class



type A_arbace_pprint_execute_format_fn__1819000573_A struct{ a2g_header uint64 }

var A_arbace_pprint_execute_format_fn__1819000573_A_fn_class *jrt.Class



type A_arbace_pprint_execute_sub_format_A struct{ a2g_header uint64 }

var A_arbace_pprint_execute_sub_format_A_fn_class *jrt.Class



type A_arbace_pprint_execute_sub_format_fn__1819000085_A struct{ a2g_header uint64; F_base_args any }

var A_arbace_pprint_execute_sub_format_fn__1819000085_A_fn_class *jrt.Class



type A_arbace_pprint_expand_fixed_A struct{ a2g_header uint64 }

var A_arbace_pprint_expand_fixed_A_fn_class *jrt.Class



type A_arbace_pprint_exponential_float_A struct{ a2g_header uint64 }

var A_arbace_pprint_exponential_float_A_fn_class *jrt.Class



type A_arbace_pprint_extract_flags_A struct{ a2g_header uint64 }

var A_arbace_pprint_extract_flags_A_fn_class *jrt.Class



type A_arbace_pprint_extract_flags_fn__1819000480_A struct{ a2g_header uint64 }

var A_arbace_pprint_extract_flags_fn__1819000480_A_fn_class *jrt.Class



type A_arbace_pprint_extract_param_A struct{ a2g_header uint64 }

var A_arbace_pprint_extract_param_A_fn_class *jrt.Class



type A_arbace_pprint_extract_params_A struct{ a2g_header uint64 }

var A_arbace_pprint_extract_params_A_fn_class *jrt.Class



type A_arbace_pprint_fixed_float_A struct{ a2g_header uint64 }

var A_arbace_pprint_fixed_float_A_fn_class *jrt.Class



type A_arbace_pprint_float_parts_A struct{ a2g_header uint64 }

var A_arbace_pprint_float_parts_A_fn_class *jrt.Class



type A_arbace_pprint_float_parts_base_A struct{ a2g_header uint64 }

var A_arbace_pprint_float_parts_base_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000328_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000328_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000328_fn__1819000329_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000328_fn__1819000329_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000332_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000332_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000332_fn__1819000333_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000332_fn__1819000333_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000336_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000336_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000336_fn__1819000337_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000336_fn__1819000337_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000340_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000340_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000340_fn__1819000341_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000340_fn__1819000341_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000344_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000344_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000344_fn__1819000345_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000344_fn__1819000345_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000348_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000348_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000348_fn__1819000349_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000348_fn__1819000349_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000352_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000352_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000352_fn__1819000353_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000352_fn__1819000353_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000352_fn__1819000355_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000352_fn__1819000355_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000352_fn__1819000357_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000352_fn__1819000357_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000352_fn__1819000359_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000352_fn__1819000359_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000352_fn__1819000361_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000352_fn__1819000361_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000364_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000364_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000364_fn__1819000365_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000364_fn__1819000365_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000371_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000371_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000373_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000373_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000375_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000375_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000377_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000377_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000379_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000379_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000381_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000381_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000381_fn__1819000382_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000381_fn__1819000382_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000385_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000385_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000385_fn__1819000386_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000385_fn__1819000386_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000389_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000389_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000389_fn__1819000390_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000389_fn__1819000390_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000393_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000393_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000393_fn__1819000394_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000393_fn__1819000394_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000397_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000397_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000397_fn__1819000398_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000397_fn__1819000398_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000401_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000401_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000401_fn__1819000402_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000401_fn__1819000402_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000401_fn__1819000404_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000401_fn__1819000404_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000407_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000407_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000407_fn__1819000408_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000407_fn__1819000408_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000407_fn__1819000410_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000407_fn__1819000410_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000413_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000413_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000413_fn__1819000414_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000413_fn__1819000414_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000413_fn__1819000419_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000413_fn__1819000419_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000428_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000428_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000428_fn__1819000429_A struct{ a2g_header uint64; F_mod_case_writer any }

var A_arbace_pprint_fn__1819000428_fn__1819000429_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000432_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000432_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000434_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000434_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000436_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000436_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000438_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000438_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000440_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000440_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000442_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000442_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000444_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000444_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000446_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000446_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000448_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000448_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000448_fn__1819000449_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000448_fn__1819000449_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000452_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000452_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000452_fn__1819000453_A struct{ a2g_header uint64; F_bindings any }

var A_arbace_pprint_fn__1819000452_fn__1819000453_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000452_fn__1819000458_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000452_fn__1819000458_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000464_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000464_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1819000466_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1819000466_A_fn_class *jrt.Class



type A_arbace_pprint_fn__1820000051_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__1820000051_A_fn_class *jrt.Class



type A_arbace_pprint_fn__740000014_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__740000014_A_fn_class *jrt.Class



type A_arbace_pprint_fn__740000014_fn__740000015_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_fn__740000014_fn__740000015_A_fn_class *jrt.Class



type A_arbace_pprint_fn__740000032_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__740000032_A_fn_class *jrt.Class



type A_arbace_pprint_fn__740000032_fn__740000033_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_fn__740000032_fn__740000033_A_fn_class *jrt.Class



type A_arbace_pprint_fn__740000107_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__740000107_A_fn_class *jrt.Class



type A_arbace_pprint_fn__740000107_fn__740000108_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_fn__740000107_fn__740000108_A_fn_class *jrt.Class



type A_arbace_pprint_fn__740000152_A struct{ a2g_header uint64 }

var A_arbace_pprint_fn__740000152_A_fn_class *jrt.Class



type A_arbace_pprint_fn__740000152_fn__740000153_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_fn__740000152_fn__740000153_A_fn_class *jrt.Class



type A_arbace_pprint_format_ascii_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_ascii_A_fn_class *jrt.Class



type A_arbace_pprint_format_cardinal_english_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_cardinal_english_A_fn_class *jrt.Class



type A_arbace_pprint_format_error_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_error_A_fn_class *jrt.Class



type A_arbace_pprint_format_integer_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_integer_A_fn_class *jrt.Class



type A_arbace_pprint_format_integer_fn__1819000050_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_integer_fn__1819000050_A_fn_class *jrt.Class



type A_arbace_pprint_format_logical_block_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_logical_block_A_fn_class *jrt.Class



type A_arbace_pprint_format_logical_block_fn__1819000271_A struct{ a2g_header uint64; F_params, F_suffix, F_prefix, F_arg, F_body any }

var A_arbace_pprint_format_logical_block_fn__1819000271_A_fn_class *jrt.Class



type A_arbace_pprint_format_new_roman_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_new_roman_A_fn_class *jrt.Class



type A_arbace_pprint_format_old_roman_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_old_roman_A_fn_class *jrt.Class



type A_arbace_pprint_format_ordinal_english_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_ordinal_english_A_fn_class *jrt.Class



type A_arbace_pprint_format_roman_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_roman_A_fn_class *jrt.Class



type A_arbace_pprint_format_simple_cardinal_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_simple_cardinal_A_fn_class *jrt.Class



type A_arbace_pprint_format_simple_number_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_simple_number_A_fn_class *jrt.Class



type A_arbace_pprint_format_simple_ordinal_A struct{ a2g_header uint64 }

var A_arbace_pprint_format_simple_ordinal_A_fn_class *jrt.Class



type A_arbace_pprint_formatter_A struct{ a2g_header uint64 }

var A_arbace_pprint_formatter_A_fn_class *jrt.Class



type A_arbace_pprint_formatter_out_A struct{ a2g_header uint64 }

var A_arbace_pprint_formatter_out_A_fn_class *jrt.Class



type A_arbace_pprint_fresh_line_A struct{ a2g_header uint64 }

var A_arbace_pprint_fresh_line_A_fn_class *jrt.Class



type A_arbace_pprint_general_float_A struct{ a2g_header uint64 }

var A_arbace_pprint_general_float_A_fn_class *jrt.Class



type A_arbace_pprint_get_column_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_column_A_fn_class *jrt.Class



type A_arbace_pprint_get_field_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_field_A_fn_class *jrt.Class



type A_arbace_pprint_get_fixed_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_fixed_A_fn_class *jrt.Class



type A_arbace_pprint_get_format_arg_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_format_arg_A_fn_class *jrt.Class



type A_arbace_pprint_get_line_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_line_A_fn_class *jrt.Class



type A_arbace_pprint_get_max_column_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_max_column_A_fn_class *jrt.Class



type A_arbace_pprint_get_miser_width_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_miser_width_A_fn_class *jrt.Class



type A_arbace_pprint_get_pretty_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_pretty_writer_A_fn_class *jrt.Class



type A_arbace_pprint_get_section_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_section_A_fn_class *jrt.Class



type A_arbace_pprint_get_section_fn__1820000114_A struct{ a2g_header uint64; F_lb any }

var A_arbace_pprint_get_section_fn__1820000114_A_fn_class *jrt.Class



type A_arbace_pprint_get_sub_section_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_sub_section_A_fn_class *jrt.Class



type A_arbace_pprint_get_sub_section_fn__1820000118_A struct{ a2g_header uint64; F_lb any }

var A_arbace_pprint_get_sub_section_fn__1820000118_A_fn_class *jrt.Class



type A_arbace_pprint_get_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_get_writer_A_fn_class *jrt.Class



type A_arbace_pprint_getf_A struct{ a2g_header uint64 }

var A_arbace_pprint_getf_A_fn_class *jrt.Class



type A_arbace_pprint_group_by_STAR__A struct{ a2g_header uint64 }

var A_arbace_pprint_group_by_STAR__A_fn_class *jrt.Class



type A_arbace_pprint_group_by_STAR__fn__1819000043_A struct{ a2g_header uint64; F_unit any }

var A_arbace_pprint_group_by_STAR__fn__1819000043_A_fn_class *jrt.Class



type A_arbace_pprint_inc_s_A struct{ a2g_header uint64 }

var A_arbace_pprint_inc_s_A_fn_class *jrt.Class



type A_arbace_pprint_indent_A struct{ a2g_header uint64 }

var A_arbace_pprint_indent_A_fn_class *jrt.Class



type A_arbace_pprint_indent_fn__1820000199_A struct{ a2g_header uint64; F_relative_to, F_offset, F_this any }

var A_arbace_pprint_indent_fn__1820000199_A_fn_class *jrt.Class



type A_arbace_pprint_indent_t_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_indent_t_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_init_cap_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_init_cap_writer_A_fn_class *jrt.Class



type A_arbace_pprint_init_cap_writer_fn__1819000250_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_init_cap_writer_fn__1819000250_A_fn_class *jrt.Class



type A_arbace_pprint_init_cap_writer_fn__1819000252_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_init_cap_writer_fn__1819000252_A_fn_class *jrt.Class



type A_arbace_pprint_init_cap_writer_fn__1819000254_A struct{ a2g_header uint64; F_writer, F_capped any }

var A_arbace_pprint_init_cap_writer_fn__1819000254_A_fn_class *jrt.Class



type A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A struct{ a2g_header uint64; F_capped any }

var A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_fn_class *jrt.Class



type A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A struct{ a2g_header uint64; F_capped any }

var A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_fn_class *jrt.Class



type A_arbace_pprint_init_navigator_A struct{ a2g_header uint64 }

var A_arbace_pprint_init_navigator_A_fn_class *jrt.Class



type A_arbace_pprint_insert_decimal_A struct{ a2g_header uint64 }

var A_arbace_pprint_insert_decimal_A_fn_class *jrt.Class



type A_arbace_pprint_insert_scaled_decimal_A struct{ a2g_header uint64 }

var A_arbace_pprint_insert_scaled_decimal_A_fn_class *jrt.Class



type A_arbace_pprint_integral_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_integral_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_iterate_list_of_sublists_A struct{ a2g_header uint64 }

var A_arbace_pprint_iterate_list_of_sublists_A_fn_class *jrt.Class



type A_arbace_pprint_iterate_main_list_A struct{ a2g_header uint64 }

var A_arbace_pprint_iterate_main_list_A_fn_class *jrt.Class



type A_arbace_pprint_iterate_main_sublists_A struct{ a2g_header uint64 }

var A_arbace_pprint_iterate_main_sublists_A_fn_class *jrt.Class



type A_arbace_pprint_iterate_sublist_A struct{ a2g_header uint64 }

var A_arbace_pprint_iterate_sublist_A_fn_class *jrt.Class



type A_arbace_pprint_justify_clauses_A struct{ a2g_header uint64 }

var A_arbace_pprint_justify_clauses_A_fn_class *jrt.Class



type A_arbace_pprint_level_exceeded_A struct{ a2g_header uint64 }

var A_arbace_pprint_level_exceeded_A_fn_class *jrt.Class



type A_arbace_pprint_linear_nl_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_linear_nl_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_logical_block_or_justify_A struct{ a2g_header uint64 }

var A_arbace_pprint_logical_block_or_justify_A_fn_class *jrt.Class



type A_arbace_pprint_ltrim_A struct{ a2g_header uint64 }

var A_arbace_pprint_ltrim_A_fn_class *jrt.Class



type A_arbace_pprint_make_buffer_blob_A struct{ a2g_header uint64 }

var A_arbace_pprint_make_buffer_blob_A_fn_class *jrt.Class



type A_arbace_pprint_make_end_block_t_A struct{ a2g_header uint64 }

var A_arbace_pprint_make_end_block_t_A_fn_class *jrt.Class



type A_arbace_pprint_make_indent_t_A struct{ a2g_header uint64 }

var A_arbace_pprint_make_indent_t_A_fn_class *jrt.Class



type A_arbace_pprint_make_nl_t_A struct{ a2g_header uint64 }

var A_arbace_pprint_make_nl_t_A_fn_class *jrt.Class



type A_arbace_pprint_make_pretty_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_make_pretty_writer_A_fn_class *jrt.Class



type A_arbace_pprint_make_start_block_t_A struct{ a2g_header uint64 }

var A_arbace_pprint_make_start_block_t_A_fn_class *jrt.Class



type A_arbace_pprint_map_params_A struct{ a2g_header uint64 }

var A_arbace_pprint_map_params_A_fn_class *jrt.Class



type A_arbace_pprint_map_params_fn__1819000492_A struct{ a2g_header uint64; F_def any }

var A_arbace_pprint_map_params_fn__1819000492_A_fn_class *jrt.Class



type A_arbace_pprint_map_params_fn__1819000516_A struct{ a2g_header uint64 }

var A_arbace_pprint_map_params_fn__1819000516_A_fn_class *jrt.Class



type A_arbace_pprint_map_params_fn__1819000518_A struct{ a2g_header uint64 }

var A_arbace_pprint_map_params_fn__1819000518_A_fn_class *jrt.Class



type A_arbace_pprint_map_params_iter__1819000494__1819000498_A struct{ a2g_header uint64; F_offset any }

var A_arbace_pprint_map_params_iter__1819000494__1819000498_A_fn_class *jrt.Class



type A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A struct{ a2g_header uint64; F_s__1819000495, F_iter__1819000494, F_offset any }

var A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_fn_class *jrt.Class



type A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A struct{ a2g_header uint64; F_b__1819000497, F_offset any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_fn_class *jrt.Class



type A_arbace_pprint_map_passing_context_A struct{ a2g_header uint64 }

var A_arbace_pprint_map_passing_context_A_fn_class *jrt.Class



type A_arbace_pprint_miser_nl_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_miser_nl_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_modify_case_A struct{ a2g_header uint64 }

var A_arbace_pprint_modify_case_A_fn_class *jrt.Class



type A_arbace_pprint_multi_defn_A struct{ a2g_header uint64 }

var A_arbace_pprint_multi_defn_A_fn_class *jrt.Class



type A_arbace_pprint_multi_defn_fn__740000118_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_multi_defn_fn__740000118_A_fn_class *jrt.Class



type A_arbace_pprint_needs_pretty_A struct{ a2g_header uint64 }

var A_arbace_pprint_needs_pretty_A_fn_class *jrt.Class



type A_arbace_pprint_next_arg_A struct{ a2g_header uint64 }

var A_arbace_pprint_next_arg_A_fn_class *jrt.Class



type A_arbace_pprint_next_arg_or_nil_A struct{ a2g_header uint64 }

var A_arbace_pprint_next_arg_or_nil_A_fn_class *jrt.Class



type A_arbace_pprint_nl_A struct{ a2g_header uint64 }

var A_arbace_pprint_nl_A_fn_class *jrt.Class



type A_arbace_pprint_nl_fn__1820000196_A struct{ a2g_header uint64; F_type, F_this any }

var A_arbace_pprint_nl_fn__1820000196_A_fn_class *jrt.Class



type A_arbace_pprint_nl_t_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_nl_t_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_opt_base_str_A struct{ a2g_header uint64 }

var A_arbace_pprint_opt_base_str_A_fn_class *jrt.Class



type A_arbace_pprint_p_write_char_A struct{ a2g_header uint64 }

var A_arbace_pprint_p_write_char_A_fn_class *jrt.Class



type A_arbace_pprint_p_write_char_fn__1820000170_A struct{ a2g_header uint64; F_c, F_oldpos, F_newpos, F_this any }

var A_arbace_pprint_p_write_char_fn__1820000170_A_fn_class *jrt.Class



type A_arbace_pprint_parse_lb_options_A struct{ a2g_header uint64 }

var A_arbace_pprint_parse_lb_options_A_fn_class *jrt.Class



type A_arbace_pprint_plain_character_A struct{ a2g_header uint64 }

var A_arbace_pprint_plain_character_A_fn_class *jrt.Class



type A_arbace_pprint_pll_mod_body_A struct{ a2g_header uint64 }

var A_arbace_pprint_pll_mod_body_A_fn_class *jrt.Class



type A_arbace_pprint_pll_mod_body_inner__693000059_A struct{ a2g_header uint64; F_var_sym any }

var A_arbace_pprint_pll_mod_body_inner__693000059_A_fn_class *jrt.Class



type A_arbace_pprint_pp_A struct{ a2g_header uint64 }

var A_arbace_pprint_pp_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_fn__693000031_A struct{ a2g_header uint64; F_object any }

var A_arbace_pprint_pprint_fn__693000031_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_anon_func_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_anon_func_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_anon_func_fn__740000172_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_anon_func_fn__740000172_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_anon_func_fn__740000174_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_anon_func_fn__740000174_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_binding_form_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_binding_form_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_binding_form_fn__740000139_A struct{ a2g_header uint64; F_binding_vec any }

var A_arbace_pprint_pprint_binding_form_fn__740000139_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A struct{ a2g_header uint64; F_binding any }

var A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_code_list_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_code_list_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_code_symbol_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_code_symbol_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_cond_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_cond_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_cond_fn__740000156_A struct{ a2g_header uint64; F_alis any }

var A_arbace_pprint_pprint_cond_fn__740000156_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A struct{ a2g_header uint64; F_alis any }

var A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_condp_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_condp_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_condp_fn__740000162_A struct{ a2g_header uint64; F_alis any }

var A_arbace_pprint_pprint_condp_fn__740000162_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A struct{ a2g_header uint64; F_alis any }

var A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_defn_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_defn_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_defn_fn__740000130_A struct{ a2g_header uint64; F_stuff, F_defn_sym, F_defn_name, F_doc_str, F_attr_map any }

var A_arbace_pprint_pprint_defn_fn__740000130_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ideref_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_ideref_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_indent_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_indent_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_let_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_let_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_let_fn__740000145_A struct{ a2g_header uint64; F_alis, F_base_sym any }

var A_arbace_pprint_pprint_let_fn__740000145_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_list_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_list_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_logical_block_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_logical_block_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_map_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_map_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_map_fn__740000021_A struct{ a2g_header uint64; F_prefix, F_amap any }

var A_arbace_pprint_pprint_map_fn__740000021_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A struct{ a2g_header uint64; F_aseq any }

var A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_meta_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_meta_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_newline_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_newline_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_ns_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_fn__740000098_A struct{ a2g_header uint64; F_ns_sym, F_references, F_ns_name, F_doc_str, F_attr_map any }

var A_arbace_pprint_pprint_ns_fn__740000098_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_ns_reference_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_A struct{ a2g_header uint64; F_keyw, F_args, F_end, F_start any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A struct{ a2g_header uint64; F_arg, F_end, F_start any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_reader_macro_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_reader_macro_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_set_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_set_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_set_fn__740000027_A struct{ a2g_header uint64; F_aset any }

var A_arbace_pprint_pprint_set_fn__740000027_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_simple_code_list_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_simple_code_list_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_simple_code_list_fn__740000177_A struct{ a2g_header uint64; F_alis any }

var A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_simple_default_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_simple_default_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_simple_list_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_simple_list_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_simple_list_fn__740000005_A struct{ a2g_header uint64; F_alis any }

var A_arbace_pprint_pprint_simple_list_fn__740000005_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_tab_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_tab_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_vector_A struct{ a2g_header uint64 }

var A_arbace_pprint_pprint_vector_A_fn_class *jrt.Class



type A_arbace_pprint_pprint_vector_fn__740000010_A struct{ a2g_header uint64; F_avec any }

var A_arbace_pprint_pprint_vector_fn__740000010_A_fn_class *jrt.Class



type A_arbace_pprint_pr_with_base_A struct{ a2g_header uint64 }

var A_arbace_pprint_pr_with_base_A_fn_class *jrt.Class



type A_arbace_pprint_prefix_count_A struct{ a2g_header uint64 }

var A_arbace_pprint_prefix_count_A_fn_class *jrt.Class



type A_arbace_pprint_prerr_A struct{ a2g_header uint64 }

var A_arbace_pprint_prerr_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_character_A struct{ a2g_header uint64 }

var A_arbace_pprint_pretty_character_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_pretty_writer_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_fn__1820000173_A struct{ a2g_header uint64; F_fields any }

var A_arbace_pprint_pretty_writer_fn__1820000173_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_fn__1820000175_A struct{ a2g_header uint64 }

var A_arbace_pprint_pretty_writer_fn__1820000175_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A struct{ a2g_header uint64; F_white_space, F_s, F_s0, F_mode, F_this any }

var A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_fn__1820000181_A struct{ a2g_header uint64 }

var A_arbace_pprint_pretty_writer_fn__1820000181_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A struct{ a2g_header uint64; F_this any }

var A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_fn__1820000185_A struct{ a2g_header uint64 }

var A_arbace_pprint_pretty_writer_fn__1820000185_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_fn__1820000187_A struct{ a2g_header uint64 }

var A_arbace_pprint_pretty_writer_fn__1820000187_A_fn_class *jrt.Class



type A_arbace_pprint_pretty_writer_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_pretty_writer_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_print_length_loop_A struct{ a2g_header uint64 }

var A_arbace_pprint_print_length_loop_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_A struct{ a2g_header uint64 }

var A_arbace_pprint_print_table_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fmt_row__1821000014_A struct{ a2g_header uint64; F_fmts, F_ks any }

var A_arbace_pprint_print_table_fmt_row__1821000014_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A struct{ a2g_header uint64; F_row any }

var A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A struct{ a2g_header uint64 }

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A struct{ a2g_header uint64; F_iter__1821000015, F_s__1821000016 any }

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A struct{ a2g_header uint64; F_b__1821000018 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fn__1821000006_A struct{ a2g_header uint64; F_rows any }

var A_arbace_pprint_print_table_fn__1821000006_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A struct{ a2g_header uint64; F_k any }

var A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fn__1821000010_A struct{ a2g_header uint64 }

var A_arbace_pprint_print_table_fn__1821000010_A_fn_class *jrt.Class



type A_arbace_pprint_print_table_fn__1821000012_A struct{ a2g_header uint64 }

var A_arbace_pprint_print_table_fn__1821000012_A_fn_class *jrt.Class



type A_arbace_pprint_prlabel_A struct{ a2g_header uint64 }

var A_arbace_pprint_prlabel_A_fn_class *jrt.Class



type A_arbace_pprint_prlabel_fn__1470000081_A struct{ a2g_header uint64 }

var A_arbace_pprint_prlabel_fn__1470000081_A_fn_class *jrt.Class



type A_arbace_pprint_process_bracket_A struct{ a2g_header uint64 }

var A_arbace_pprint_process_bracket_A_fn_class *jrt.Class



type A_arbace_pprint_process_clause_A struct{ a2g_header uint64 }

var A_arbace_pprint_process_clause_A_fn_class *jrt.Class



type A_arbace_pprint_process_clause_fn__1819000544_A struct{ a2g_header uint64; F_bracket_info, F_offset any }

var A_arbace_pprint_process_clause_fn__1819000544_A_fn_class *jrt.Class



type A_arbace_pprint_process_directive_table_element_A struct{ a2g_header uint64 }

var A_arbace_pprint_process_directive_table_element_A_fn_class *jrt.Class



type A_arbace_pprint_process_nesting_A struct{ a2g_header uint64 }

var A_arbace_pprint_process_nesting_A_fn_class *jrt.Class



type A_arbace_pprint_process_nesting_fn__1819000560_A struct{ a2g_header uint64 }

var A_arbace_pprint_process_nesting_fn__1819000560_A_fn_class *jrt.Class



type A_arbace_pprint_readable_character_A struct{ a2g_header uint64 }

var A_arbace_pprint_readable_character_A_fn_class *jrt.Class



type A_arbace_pprint_realize_parameter_A struct{ a2g_header uint64 }

var A_arbace_pprint_realize_parameter_A_fn_class *jrt.Class



type A_arbace_pprint_realize_parameter_list_A struct{ a2g_header uint64 }

var A_arbace_pprint_realize_parameter_list_A_fn_class *jrt.Class



type A_arbace_pprint_relative_reposition_A struct{ a2g_header uint64 }

var A_arbace_pprint_relative_reposition_A_fn_class *jrt.Class



type A_arbace_pprint_relative_tabulation_A struct{ a2g_header uint64 }

var A_arbace_pprint_relative_tabulation_A_fn_class *jrt.Class



type A_arbace_pprint_remainders_A struct{ a2g_header uint64 }

var A_arbace_pprint_remainders_A_fn_class *jrt.Class



type A_arbace_pprint_remainders_fn__1819000035_A struct{ a2g_header uint64; F_base any }

var A_arbace_pprint_remainders_fn__1819000035_A_fn_class *jrt.Class



type A_arbace_pprint_render_clauses_A struct{ a2g_header uint64 }

var A_arbace_pprint_render_clauses_A_fn_class *jrt.Class



type A_arbace_pprint_render_clauses_fn__1819000200_A struct{ a2g_header uint64; F_base_navigator, F_clause, F_navigator any }

var A_arbace_pprint_render_clauses_fn__1819000200_A_fn_class *jrt.Class



type A_arbace_pprint_right_bracket_A struct{ a2g_header uint64 }

var A_arbace_pprint_right_bracket_A_fn_class *jrt.Class



type A_arbace_pprint_round_str_A struct{ a2g_header uint64 }

var A_arbace_pprint_round_str_A_fn_class *jrt.Class



type A_arbace_pprint_rtrim_A struct{ a2g_header uint64 }

var A_arbace_pprint_rtrim_A_fn_class *jrt.Class



type A_arbace_pprint_separator_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_separator_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_set_field_A struct{ a2g_header uint64 }

var A_arbace_pprint_set_field_A_fn_class *jrt.Class



type A_arbace_pprint_set_indent_A struct{ a2g_header uint64 }

var A_arbace_pprint_set_indent_A_fn_class *jrt.Class



type A_arbace_pprint_set_logical_block_callback_A struct{ a2g_header uint64 }

var A_arbace_pprint_set_logical_block_callback_A_fn_class *jrt.Class



type A_arbace_pprint_set_logical_block_callback_fn__1820000208_A struct{ a2g_header uint64; F_f, F_this any }

var A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_fn_class *jrt.Class



type A_arbace_pprint_set_max_column_A struct{ a2g_header uint64 }

var A_arbace_pprint_set_max_column_A_fn_class *jrt.Class



type A_arbace_pprint_set_max_column_fn__44000011_A struct{ a2g_header uint64; F_new_max, F_this any }

var A_arbace_pprint_set_max_column_fn__44000011_A_fn_class *jrt.Class



type A_arbace_pprint_set_miser_width_A struct{ a2g_header uint64 }

var A_arbace_pprint_set_miser_width_A_fn_class *jrt.Class



type A_arbace_pprint_set_miser_width_fn__1820000205_A struct{ a2g_header uint64; F_new_miser_width, F_this any }

var A_arbace_pprint_set_miser_width_fn__1820000205_A_fn_class *jrt.Class



type A_arbace_pprint_set_pprint_dispatch_A struct{ a2g_header uint64 }

var A_arbace_pprint_set_pprint_dispatch_A_fn_class *jrt.Class



type A_arbace_pprint_setf_A struct{ a2g_header uint64 }

var A_arbace_pprint_setf_A_fn_class *jrt.Class



type A_arbace_pprint_single_defn_A struct{ a2g_header uint64 }

var A_arbace_pprint_single_defn_A_fn_class *jrt.Class



type A_arbace_pprint_single_defn_fn__740000111_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_single_defn_fn__740000111_A_fn_class *jrt.Class



type A_arbace_pprint_single_defn_fn__740000113_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_single_defn_fn__740000113_A_fn_class *jrt.Class



type A_arbace_pprint_single_defn_fn__740000115_A struct{ a2g_header uint64; F_cf__1819000596__auto__ any }

var A_arbace_pprint_single_defn_fn__740000115_A_fn_class *jrt.Class



type A_arbace_pprint_split_at_newline_A struct{ a2g_header uint64 }

var A_arbace_pprint_split_at_newline_A_fn_class *jrt.Class



type A_arbace_pprint_split_at_newline_fn__1820000128_A struct{ a2g_header uint64 }

var A_arbace_pprint_split_at_newline_fn__1820000128_A_fn_class *jrt.Class



type A_arbace_pprint_start_block_A struct{ a2g_header uint64 }

var A_arbace_pprint_start_block_A_fn_class *jrt.Class



type A_arbace_pprint_start_block_fn__1820000190_A struct{ a2g_header uint64; F_suffix, F_prefix, F_per_line_prefix, F_this any }

var A_arbace_pprint_start_block_fn__1820000190_A_fn_class *jrt.Class



type A_arbace_pprint_start_block_t_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_start_block_t_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_table_ize_A struct{ a2g_header uint64 }

var A_arbace_pprint_table_ize_A_fn_class *jrt.Class



type A_arbace_pprint_table_ize_fn__693000011_A struct{ a2g_header uint64; F_t any }

var A_arbace_pprint_table_ize_fn__693000011_A_fn_class *jrt.Class



type A_arbace_pprint_tokens_fit_QMARK__A struct{ a2g_header uint64 }

var A_arbace_pprint_tokens_fit_QMARK__A_fn_class *jrt.Class



type A_arbace_pprint_toks_A struct{ a2g_header uint64 }

var A_arbace_pprint_toks_A_fn_class *jrt.Class



type A_arbace_pprint_translate_param_A struct{ a2g_header uint64 }

var A_arbace_pprint_translate_param_A_fn_class *jrt.Class



type A_arbace_pprint_tuple_map_A struct{ a2g_header uint64 }

var A_arbace_pprint_tuple_map_A_fn_class *jrt.Class



type A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A struct{ a2g_header uint64; F_v1 any }

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_fn_class *jrt.Class



type A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A struct{ a2g_header uint64; F_s__1470000060, F_iter__1470000059, F_v1 any }

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_fn_class *jrt.Class



type A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A struct{ a2g_header uint64; F_b__1470000062, F_v1 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_fn_class *jrt.Class



type A_arbace_pprint_two_forms_A struct{ a2g_header uint64 }

var A_arbace_pprint_two_forms_A_fn_class *jrt.Class



type A_arbace_pprint_two_forms_iter__740000181__740000185_A struct{ a2g_header uint64 }

var A_arbace_pprint_two_forms_iter__740000181__740000185_A_fn_class *jrt.Class



type A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A struct{ a2g_header uint64; F_iter__740000181, F_s__740000182 any }

var A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_fn_class *jrt.Class



type A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A struct{ a2g_header uint64; F_b__740000184 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_fn_class *jrt.Class



type A_arbace_pprint_unzip_map_A struct{ a2g_header uint64 }

var A_arbace_pprint_unzip_map_A_fn_class *jrt.Class



type A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A struct{ a2g_header uint64 }

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_fn_class *jrt.Class



type A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A struct{ a2g_header uint64; F_s__1470000015, F_iter__1470000014 any }

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_fn_class *jrt.Class



type A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1470000017 any }

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_fn_class *jrt.Class



type A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A struct{ a2g_header uint64 }

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_fn_class *jrt.Class



type A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A struct{ a2g_header uint64; F_s__1470000037, F_iter__1470000036 any }

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_fn_class *jrt.Class



type A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1470000039 any }

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_fn_class *jrt.Class



type A_arbace_pprint_upcase_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_upcase_writer_A_fn_class *jrt.Class



type A_arbace_pprint_upcase_writer_fn__1819000225_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_upcase_writer_fn__1819000225_A_fn_class *jrt.Class



type A_arbace_pprint_upcase_writer_fn__1819000227_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_upcase_writer_fn__1819000227_A_fn_class *jrt.Class



type A_arbace_pprint_upcase_writer_fn__1819000229_A struct{ a2g_header uint64; F_writer any }

var A_arbace_pprint_upcase_writer_fn__1819000229_A_fn_class *jrt.Class



type A_arbace_pprint_update_nl_state_A struct{ a2g_header uint64 }

var A_arbace_pprint_update_nl_state_A_fn_class *jrt.Class



type A_arbace_pprint_update_nl_state_fn__1820000121_A struct{ a2g_header uint64; F_lb any }

var A_arbace_pprint_update_nl_state_fn__1820000121_A_fn_class *jrt.Class



type A_arbace_pprint_use_method_A struct{ a2g_header uint64 }

var A_arbace_pprint_use_method_A_fn_class *jrt.Class



type A_arbace_pprint_with_pprint_dispatch_A struct{ a2g_header uint64 }

var A_arbace_pprint_with_pprint_dispatch_A_fn_class *jrt.Class



type A_arbace_pprint_with_pretty_writer_A struct{ a2g_header uint64 }

var A_arbace_pprint_with_pretty_writer_A_fn_class *jrt.Class



type A_arbace_pprint_write_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_A_fn_class *jrt.Class



type A_arbace_pprint_write_fn__693000026_A struct{ a2g_header uint64; F_object any }

var A_arbace_pprint_write_fn__693000026_A_fn_class *jrt.Class



type A_arbace_pprint_write_fn__693000028_A struct{ a2g_header uint64; F_object any }

var A_arbace_pprint_write_fn__693000028_A_fn_class *jrt.Class



type A_arbace_pprint_write_buffered_output_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_buffered_output_A_fn_class *jrt.Class



type A_arbace_pprint_write_initial_lines_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_initial_lines_A_fn_class *jrt.Class



type A_arbace_pprint_write_initial_lines_fn__1820000163_A struct{ a2g_header uint64; F_lines, F_this any }

var A_arbace_pprint_write_initial_lines_fn__1820000163_A_fn_class *jrt.Class



type A_arbace_pprint_write_line_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_line_A_fn_class *jrt.Class



type A_arbace_pprint_write_line_fn__1820000153_A struct{ a2g_header uint64; F_this any }

var A_arbace_pprint_write_line_fn__1820000153_A_fn_class *jrt.Class



type A_arbace_pprint_write_out_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_out_A_fn_class *jrt.Class



type A_arbace_pprint_write_to_base_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_to_base_A_fn_class *jrt.Class



type A_arbace_pprint_write_token_string_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_token_string_A_fn_class *jrt.Class



type A_arbace_pprint_write_tokens_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_tokens_A_fn_class *jrt.Class



type A_arbace_pprint_write_white_space_A struct{ a2g_header uint64 }

var A_arbace_pprint_write_white_space_A_fn_class *jrt.Class



type A_arbace_pprint_write_white_space_fn__1820000160_A struct{ a2g_header uint64; F_this any }

var A_arbace_pprint_write_white_space_fn__1820000160_A_fn_class *jrt.Class
