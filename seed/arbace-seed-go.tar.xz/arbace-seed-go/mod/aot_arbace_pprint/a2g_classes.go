//line a2g_classes.ae:1
package aot_arbace_pprint

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_pprint_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_A_New()}; return nil }

var A_arbace_pprint_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_A_new}

var A_arbace_pprint_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_pprint.A_arbace_pprint_A"})

func init() { i := A_arbace_pprint_A_class.Info(); i.IsInstance = A_arbace_pprint_A_InstanceOf; i.Init = A_arbace_pprint_A_Init; i.Table = A_arbace_pprint_A_members; jrt.RegisterGoType(A_arbace_pprint_A_class, reflect.TypeFor[A_arbace_pprint_A]()) }

func A_arbace_pprint_abort_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_abort_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_abort_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_abort_QMARK__A_New()}; return nil }

func A_arbace_pprint_abort_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_abort_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_abort_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_abort_QMARK__A_invoke, New: A_arbace_pprint_abort_QMARK__A_new, Get: A_arbace_pprint_abort_QMARK__A_get}

var A_arbace_pprint_abort_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$abort_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "abort_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_abort_QMARK__A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_abort_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_abort_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_abort_QMARK__A_Init; i.Table = A_arbace_pprint_abort_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_abort_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_abort_QMARK__A]()) }

func A_arbace_pprint_absolute_reposition_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_absolute_reposition_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_absolute_reposition_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_absolute_reposition_A_New()}; return nil }

func A_arbace_pprint_absolute_reposition_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_absolute_reposition_A_fn_class)}; return nil }

var A_arbace_pprint_absolute_reposition_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_absolute_reposition_A_invoke, New: A_arbace_pprint_absolute_reposition_A_new, Get: A_arbace_pprint_absolute_reposition_A_get}

var A_arbace_pprint_absolute_reposition_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$absolute_reposition", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "absolute_reposition", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_absolute_reposition_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_absolute_reposition_A_class.Info(); i.IsInstance = A_arbace_pprint_absolute_reposition_A_InstanceOf; i.Init = A_arbace_pprint_absolute_reposition_A_Init; i.Table = A_arbace_pprint_absolute_reposition_A_members; jrt.RegisterGoType(A_arbace_pprint_absolute_reposition_A_class, reflect.TypeFor[A_arbace_pprint_absolute_reposition_A]()) }

func A_arbace_pprint_absolute_tabulation_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_absolute_tabulation_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_absolute_tabulation_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_absolute_tabulation_A_New()}; return nil }

func A_arbace_pprint_absolute_tabulation_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_absolute_tabulation_A_fn_class)}; return nil }

var A_arbace_pprint_absolute_tabulation_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_absolute_tabulation_A_invoke, New: A_arbace_pprint_absolute_tabulation_A_new, Get: A_arbace_pprint_absolute_tabulation_A_get}

var A_arbace_pprint_absolute_tabulation_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$absolute_tabulation", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "absolute_tabulation", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_absolute_tabulation_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_absolute_tabulation_A_class.Info(); i.IsInstance = A_arbace_pprint_absolute_tabulation_A_InstanceOf; i.Init = A_arbace_pprint_absolute_tabulation_A_Init; i.Table = A_arbace_pprint_absolute_tabulation_A_members; jrt.RegisterGoType(A_arbace_pprint_absolute_tabulation_A_class, reflect.TypeFor[A_arbace_pprint_absolute_tabulation_A]()) }

func A_arbace_pprint_add_core_ns_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_add_core_ns_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_add_core_ns_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_add_core_ns_A_New()}; return nil }

func A_arbace_pprint_add_core_ns_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_add_core_ns_A_fn_class)}; return nil }

var A_arbace_pprint_add_core_ns_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_add_core_ns_A_invoke, New: A_arbace_pprint_add_core_ns_A_new, Get: A_arbace_pprint_add_core_ns_A_get}

var A_arbace_pprint_add_core_ns_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$add_core_ns", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "add_core_ns", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_add_core_ns_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_add_core_ns_A_class.Info(); i.IsInstance = A_arbace_pprint_add_core_ns_A_InstanceOf; i.Init = A_arbace_pprint_add_core_ns_A_Init; i.Table = A_arbace_pprint_add_core_ns_A_members; jrt.RegisterGoType(A_arbace_pprint_add_core_ns_A_class, reflect.TypeFor[A_arbace_pprint_add_core_ns_A]()) }

func A_arbace_pprint_add_core_ns_fn__740000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_add_core_ns_fn__740000193_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_add_core_ns_fn__740000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_add_core_ns_fn__740000193_A_New_O(args[0])}; return nil }

func A_arbace_pprint_add_core_ns_fn__740000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_add_core_ns_fn__740000193_A_fn_class)}; return nil }

var A_arbace_pprint_add_core_ns_fn__740000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_add_core_ns_fn__740000193_A_invoke, New: A_arbace_pprint_add_core_ns_fn__740000193_A_new, Get: A_arbace_pprint_add_core_ns_fn__740000193_A_get}

var A_arbace_pprint_add_core_ns_fn__740000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$add_core_ns$fn__740000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_add_core_ns_A_class, Simple: "fn__740000193", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_add_core_ns_fn__740000193_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_add_core_ns_fn__740000193_A_class.Info(); i.IsInstance = A_arbace_pprint_add_core_ns_fn__740000193_A_InstanceOf; i.Init = A_arbace_pprint_add_core_ns_fn__740000193_A_Init; i.Table = A_arbace_pprint_add_core_ns_fn__740000193_A_members; jrt.RegisterGoType(A_arbace_pprint_add_core_ns_fn__740000193_A_class, reflect.TypeFor[A_arbace_pprint_add_core_ns_fn__740000193_A]()) }

func A_arbace_pprint_add_english_scales_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_add_english_scales_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_add_english_scales_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_add_english_scales_A_New()}; return nil }

func A_arbace_pprint_add_english_scales_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_add_english_scales_A_fn_class)}; return nil }

var A_arbace_pprint_add_english_scales_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_add_english_scales_A_invoke, New: A_arbace_pprint_add_english_scales_A_new, Get: A_arbace_pprint_add_english_scales_A_get}

var A_arbace_pprint_add_english_scales_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$add_english_scales", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "add_english_scales", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_add_english_scales_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_add_english_scales_A_class.Info(); i.IsInstance = A_arbace_pprint_add_english_scales_A_InstanceOf; i.Init = A_arbace_pprint_add_english_scales_A_Init; i.Table = A_arbace_pprint_add_english_scales_A_members; jrt.RegisterGoType(A_arbace_pprint_add_english_scales_A_class, reflect.TypeFor[A_arbace_pprint_add_english_scales_A]()) }

func A_arbace_pprint_add_to_buffer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_add_to_buffer_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_add_to_buffer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_add_to_buffer_A_New()}; return nil }

func A_arbace_pprint_add_to_buffer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_add_to_buffer_A_fn_class)}; return nil }

var A_arbace_pprint_add_to_buffer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_add_to_buffer_A_invoke, New: A_arbace_pprint_add_to_buffer_A_new, Get: A_arbace_pprint_add_to_buffer_A_get}

var A_arbace_pprint_add_to_buffer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$add_to_buffer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "add_to_buffer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_add_to_buffer_A_class.Info(); i.IsInstance = A_arbace_pprint_add_to_buffer_A_InstanceOf; i.Init = A_arbace_pprint_add_to_buffer_A_Init; i.Table = A_arbace_pprint_add_to_buffer_A_members; jrt.RegisterGoType(A_arbace_pprint_add_to_buffer_A_class, reflect.TypeFor[A_arbace_pprint_add_to_buffer_A]()) }

func A_arbace_pprint_add_to_buffer_fn__1820000156_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_add_to_buffer_fn__1820000156_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_add_to_buffer_fn__1820000156_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_add_to_buffer_fn__1820000156_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_add_to_buffer_fn__1820000156_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_add_to_buffer_fn__1820000156_A_fn_class)}; return nil }

var A_arbace_pprint_add_to_buffer_fn__1820000156_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_add_to_buffer_fn__1820000156_A_invoke, New: A_arbace_pprint_add_to_buffer_fn__1820000156_A_new, Get: A_arbace_pprint_add_to_buffer_fn__1820000156_A_get}

var A_arbace_pprint_add_to_buffer_fn__1820000156_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$add_to_buffer$fn__1820000156", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_add_to_buffer_A_class, Simple: "fn__1820000156", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_add_to_buffer_fn__1820000156_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_add_to_buffer_fn__1820000156_A_class.Info(); i.IsInstance = A_arbace_pprint_add_to_buffer_fn__1820000156_A_InstanceOf; i.Init = A_arbace_pprint_add_to_buffer_fn__1820000156_A_Init; i.Table = A_arbace_pprint_add_to_buffer_fn__1820000156_A_members; jrt.RegisterGoType(A_arbace_pprint_add_to_buffer_fn__1820000156_A_class, reflect.TypeFor[A_arbace_pprint_add_to_buffer_fn__1820000156_A]()) }

func A_arbace_pprint_ancestor_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_ancestor_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_ancestor_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_ancestor_QMARK__A_New()}; return nil }

func A_arbace_pprint_ancestor_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_ancestor_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_ancestor_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_ancestor_QMARK__A_invoke, New: A_arbace_pprint_ancestor_QMARK__A_new, Get: A_arbace_pprint_ancestor_QMARK__A_get}

var A_arbace_pprint_ancestor_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$ancestor_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "ancestor_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_ancestor_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_ancestor_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_ancestor_QMARK__A_Init; i.Table = A_arbace_pprint_ancestor_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_ancestor_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_ancestor_QMARK__A]()) }

func A_arbace_pprint_base_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_base_str_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_base_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_base_str_A_New()}; return nil }

func A_arbace_pprint_base_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_base_str_A_fn_class)}; return nil }

var A_arbace_pprint_base_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_base_str_A_invoke, New: A_arbace_pprint_base_str_A_new, Get: A_arbace_pprint_base_str_A_get}

var A_arbace_pprint_base_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$base_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "base_str", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_base_str_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_base_str_A_class.Info(); i.IsInstance = A_arbace_pprint_base_str_A_InstanceOf; i.Init = A_arbace_pprint_base_str_A_Init; i.Table = A_arbace_pprint_base_str_A_members; jrt.RegisterGoType(A_arbace_pprint_base_str_A_class, reflect.TypeFor[A_arbace_pprint_base_str_A]()) }

func A_arbace_pprint_base_str_fn__1819000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_base_str_fn__1819000039_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_base_str_fn__1819000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_base_str_fn__1819000039_A_New()}; return nil }

func A_arbace_pprint_base_str_fn__1819000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_base_str_fn__1819000039_A_fn_class)}; return nil }

var A_arbace_pprint_base_str_fn__1819000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_base_str_fn__1819000039_A_invoke, New: A_arbace_pprint_base_str_fn__1819000039_A_new, Get: A_arbace_pprint_base_str_fn__1819000039_A_get}

var A_arbace_pprint_base_str_fn__1819000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$base_str$fn__1819000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_base_str_A_class, Simple: "fn__1819000039", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_base_str_fn__1819000039_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_base_str_fn__1819000039_A_class.Info(); i.IsInstance = A_arbace_pprint_base_str_fn__1819000039_A_InstanceOf; i.Init = A_arbace_pprint_base_str_fn__1819000039_A_Init; i.Table = A_arbace_pprint_base_str_fn__1819000039_A_members; jrt.RegisterGoType(A_arbace_pprint_base_str_fn__1819000039_A_class, reflect.TypeFor[A_arbace_pprint_base_str_fn__1819000039_A]()) }

func A_arbace_pprint_binding_map_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_binding_map_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_binding_map_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_binding_map_A_New()}; return nil }

func A_arbace_pprint_binding_map_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_binding_map_A_fn_class)}; return nil }

var A_arbace_pprint_binding_map_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_binding_map_A_invoke, New: A_arbace_pprint_binding_map_A_new, Get: A_arbace_pprint_binding_map_A_get}

var A_arbace_pprint_binding_map_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$binding_map", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_pprint_A_class, Simple: "binding_map", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_binding_map_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_binding_map_A_class.Info(); i.IsInstance = A_arbace_pprint_binding_map_A_InstanceOf; i.Init = A_arbace_pprint_binding_map_A_Init; i.Table = A_arbace_pprint_binding_map_A_members; jrt.RegisterGoType(A_arbace_pprint_binding_map_A_class, reflect.TypeFor[A_arbace_pprint_binding_map_A]()) }

func A_arbace_pprint_boolean_conditional_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_boolean_conditional_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_boolean_conditional_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_boolean_conditional_A_New()}; return nil }

func A_arbace_pprint_boolean_conditional_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_boolean_conditional_A_fn_class)}; return nil }

var A_arbace_pprint_boolean_conditional_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_boolean_conditional_A_invoke, New: A_arbace_pprint_boolean_conditional_A_new, Get: A_arbace_pprint_boolean_conditional_A_get}

var A_arbace_pprint_boolean_conditional_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$boolean_conditional", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "boolean_conditional", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_boolean_conditional_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_boolean_conditional_A_class.Info(); i.IsInstance = A_arbace_pprint_boolean_conditional_A_InstanceOf; i.Init = A_arbace_pprint_boolean_conditional_A_Init; i.Table = A_arbace_pprint_boolean_conditional_A_members; jrt.RegisterGoType(A_arbace_pprint_boolean_conditional_A_class, reflect.TypeFor[A_arbace_pprint_boolean_conditional_A]()) }

func A_arbace_pprint_brackets_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_brackets_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_brackets_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_brackets_A_New()}; return nil }

func A_arbace_pprint_brackets_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_brackets_A_fn_class)}; return nil }

var A_arbace_pprint_brackets_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_brackets_A_invoke, New: A_arbace_pprint_brackets_A_new, Get: A_arbace_pprint_brackets_A_get}

var A_arbace_pprint_brackets_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$brackets", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "brackets", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_brackets_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_brackets_A_class.Info(); i.IsInstance = A_arbace_pprint_brackets_A_InstanceOf; i.Init = A_arbace_pprint_brackets_A_Init; i.Table = A_arbace_pprint_brackets_A_members; jrt.RegisterGoType(A_arbace_pprint_brackets_A_class, reflect.TypeFor[A_arbace_pprint_brackets_A]()) }

func A_arbace_pprint_buffer_blob_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_buffer_blob_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_buffer_blob_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_buffer_blob_QMARK__A_New()}; return nil }

func A_arbace_pprint_buffer_blob_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_buffer_blob_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_buffer_blob_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_buffer_blob_QMARK__A_invoke, New: A_arbace_pprint_buffer_blob_QMARK__A_new, Get: A_arbace_pprint_buffer_blob_QMARK__A_get}

var A_arbace_pprint_buffer_blob_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$buffer_blob_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "buffer_blob_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_buffer_blob_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_buffer_blob_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_buffer_blob_QMARK__A_Init; i.Table = A_arbace_pprint_buffer_blob_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_buffer_blob_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_buffer_blob_QMARK__A]()) }

func A_arbace_pprint_buffer_length_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_buffer_length_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_buffer_length_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_buffer_length_A_New()}; return nil }

func A_arbace_pprint_buffer_length_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_buffer_length_A_fn_class)}; return nil }

var A_arbace_pprint_buffer_length_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_buffer_length_A_invoke, New: A_arbace_pprint_buffer_length_A_new, Get: A_arbace_pprint_buffer_length_A_get}

var A_arbace_pprint_buffer_length_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$buffer_length", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "buffer_length", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_buffer_length_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_buffer_length_A_class.Info(); i.IsInstance = A_arbace_pprint_buffer_length_A_InstanceOf; i.Init = A_arbace_pprint_buffer_length_A_Init; i.Table = A_arbace_pprint_buffer_length_A_members; jrt.RegisterGoType(A_arbace_pprint_buffer_length_A_class, reflect.TypeFor[A_arbace_pprint_buffer_length_A]()) }

func A_arbace_pprint_c_write_char_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_c_write_char_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_c_write_char_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_c_write_char_A_New()}; return nil }

func A_arbace_pprint_c_write_char_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_c_write_char_A_fn_class)}; return nil }

var A_arbace_pprint_c_write_char_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_c_write_char_A_invoke, New: A_arbace_pprint_c_write_char_A_new, Get: A_arbace_pprint_c_write_char_A_get}

var A_arbace_pprint_c_write_char_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$c_write_char", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "c_write_char", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_c_write_char_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_c_write_char_A_class.Info(); i.IsInstance = A_arbace_pprint_c_write_char_A_InstanceOf; i.Init = A_arbace_pprint_c_write_char_A_Init; i.Table = A_arbace_pprint_c_write_char_A_members; jrt.RegisterGoType(A_arbace_pprint_c_write_char_A_class, reflect.TypeFor[A_arbace_pprint_c_write_char_A]()) }

func A_arbace_pprint_c_write_char_fn__44000015_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_c_write_char_fn__44000015_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_c_write_char_fn__44000015_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_c_write_char_fn__44000015_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_c_write_char_fn__44000015_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_c_write_char_fn__44000015_A_fn_class)}; return nil }

var A_arbace_pprint_c_write_char_fn__44000015_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_c_write_char_fn__44000015_A_invoke, New: A_arbace_pprint_c_write_char_fn__44000015_A_new, Get: A_arbace_pprint_c_write_char_fn__44000015_A_get}

var A_arbace_pprint_c_write_char_fn__44000015_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$c_write_char$fn__44000015", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_c_write_char_A_class, Simple: "fn__44000015", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_c_write_char_fn__44000015_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_c_write_char_fn__44000015_A_class.Info(); i.IsInstance = A_arbace_pprint_c_write_char_fn__44000015_A_InstanceOf; i.Init = A_arbace_pprint_c_write_char_fn__44000015_A_Init; i.Table = A_arbace_pprint_c_write_char_fn__44000015_A_members; jrt.RegisterGoType(A_arbace_pprint_c_write_char_fn__44000015_A_class, reflect.TypeFor[A_arbace_pprint_c_write_char_fn__44000015_A]()) }

func A_arbace_pprint_capitalize_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_capitalize_string_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_capitalize_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_capitalize_string_A_New()}; return nil }

func A_arbace_pprint_capitalize_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_capitalize_string_A_fn_class)}; return nil }

var A_arbace_pprint_capitalize_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_capitalize_string_A_invoke, New: A_arbace_pprint_capitalize_string_A_new, Get: A_arbace_pprint_capitalize_string_A_get}

var A_arbace_pprint_capitalize_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$capitalize_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "capitalize_string", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_capitalize_string_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_capitalize_string_A_class.Info(); i.IsInstance = A_arbace_pprint_capitalize_string_A_InstanceOf; i.Init = A_arbace_pprint_capitalize_string_A_Init; i.Table = A_arbace_pprint_capitalize_string_A_members; jrt.RegisterGoType(A_arbace_pprint_capitalize_string_A_class, reflect.TypeFor[A_arbace_pprint_capitalize_string_A]()) }

func A_arbace_pprint_capitalize_string_fn__1819000234_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_capitalize_string_fn__1819000234_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_capitalize_string_fn__1819000234_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_capitalize_string_fn__1819000234_A_New()}; return nil }

func A_arbace_pprint_capitalize_string_fn__1819000234_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_capitalize_string_fn__1819000234_A_fn_class)}; return nil }

var A_arbace_pprint_capitalize_string_fn__1819000234_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_capitalize_string_fn__1819000234_A_invoke, New: A_arbace_pprint_capitalize_string_fn__1819000234_A_new, Get: A_arbace_pprint_capitalize_string_fn__1819000234_A_get}

var A_arbace_pprint_capitalize_string_fn__1819000234_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$capitalize_string$fn__1819000234", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_capitalize_string_A_class, Simple: "fn__1819000234", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_capitalize_string_fn__1819000234_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_capitalize_string_fn__1819000234_A_class.Info(); i.IsInstance = A_arbace_pprint_capitalize_string_fn__1819000234_A_InstanceOf; i.Init = A_arbace_pprint_capitalize_string_fn__1819000234_A_Init; i.Table = A_arbace_pprint_capitalize_string_fn__1819000234_A_members; jrt.RegisterGoType(A_arbace_pprint_capitalize_string_fn__1819000234_A_class, reflect.TypeFor[A_arbace_pprint_capitalize_string_fn__1819000234_A]()) }

func A_arbace_pprint_capitalize_word_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_capitalize_word_writer_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_capitalize_word_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_capitalize_word_writer_A_New()}; return nil }

func A_arbace_pprint_capitalize_word_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_capitalize_word_writer_A_fn_class)}; return nil }

var A_arbace_pprint_capitalize_word_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_capitalize_word_writer_A_invoke, New: A_arbace_pprint_capitalize_word_writer_A_new, Get: A_arbace_pprint_capitalize_word_writer_A_get}

var A_arbace_pprint_capitalize_word_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$capitalize_word_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "capitalize_word_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_capitalize_word_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_capitalize_word_writer_A_InstanceOf; i.Init = A_arbace_pprint_capitalize_word_writer_A_Init; i.Table = A_arbace_pprint_capitalize_word_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_capitalize_word_writer_A_class, reflect.TypeFor[A_arbace_pprint_capitalize_word_writer_A]()) }

func A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_capitalize_word_writer_fn__1819000237_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_New_O(args[0])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_fn_class)}; return nil }

var A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_invoke, New: A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_new, Get: A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_get}

var A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$capitalize_word_writer$fn__1819000237", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_capitalize_word_writer_A_class, Simple: "fn__1819000237", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_fn__1819000237_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_class.Info(); i.IsInstance = A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_InstanceOf; i.Init = A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_Init; i.Table = A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_members; jrt.RegisterGoType(A_arbace_pprint_capitalize_word_writer_fn__1819000237_A_class, reflect.TypeFor[A_arbace_pprint_capitalize_word_writer_fn__1819000237_A]()) }

func A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_capitalize_word_writer_fn__1819000239_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_New_O(args[0])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_fn_class)}; return nil }

var A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_invoke, New: A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_new, Get: A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_get}

var A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$capitalize_word_writer$fn__1819000239", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_capitalize_word_writer_A_class, Simple: "fn__1819000239", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_fn__1819000239_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_class.Info(); i.IsInstance = A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_InstanceOf; i.Init = A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_Init; i.Table = A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_members; jrt.RegisterGoType(A_arbace_pprint_capitalize_word_writer_fn__1819000239_A_class, reflect.TypeFor[A_arbace_pprint_capitalize_word_writer_fn__1819000239_A]()) }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_capitalize_word_writer_fn__1819000241_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_pprint_capitalize_word_writer_fn__1819000241_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_fn_class)}; return nil }

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_invoke, New: A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_new, Get: A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_get}

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$capitalize_word_writer$fn__1819000241", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_capitalize_word_writer_A_class, Simple: "fn__1819000241", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_fn__1819000241_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_class.Info(); i.IsInstance = A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_InstanceOf; i.Init = A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_Init; i.Table = A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_members; jrt.RegisterGoType(A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_class, reflect.TypeFor[A_arbace_pprint_capitalize_word_writer_fn__1819000241_A]()) }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_fn_class)}; return nil }

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_invoke, New: A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_new, Get: A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_get}

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$capitalize_word_writer$fn__1819000241$fn__1819000244", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_class, Simple: "fn__1819000244", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_class.Info(); i.IsInstance = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_InstanceOf; i.Init = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_Init; i.Table = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_members; jrt.RegisterGoType(A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A_class, reflect.TypeFor[A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000244_A]()) }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_fn_class)}; return nil }

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_invoke, New: A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_new, Get: A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_get}

var A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$capitalize_word_writer$fn__1819000241$fn__1819000246", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_capitalize_word_writer_fn__1819000241_A_class, Simple: "fn__1819000246", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_class.Info(); i.IsInstance = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_InstanceOf; i.Init = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_Init; i.Table = A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_members; jrt.RegisterGoType(A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A_class, reflect.TypeFor[A_arbace_pprint_capitalize_word_writer_fn__1819000241_fn__1819000246_A]()) }

func A_arbace_pprint_check_arg_conditional_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_check_arg_conditional_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_check_arg_conditional_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_check_arg_conditional_A_New()}; return nil }

func A_arbace_pprint_check_arg_conditional_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_check_arg_conditional_A_fn_class)}; return nil }

var A_arbace_pprint_check_arg_conditional_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_check_arg_conditional_A_invoke, New: A_arbace_pprint_check_arg_conditional_A_new, Get: A_arbace_pprint_check_arg_conditional_A_get}

var A_arbace_pprint_check_arg_conditional_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$check_arg_conditional", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "check_arg_conditional", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_check_arg_conditional_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_check_arg_conditional_A_class.Info(); i.IsInstance = A_arbace_pprint_check_arg_conditional_A_InstanceOf; i.Init = A_arbace_pprint_check_arg_conditional_A_Init; i.Table = A_arbace_pprint_check_arg_conditional_A_members; jrt.RegisterGoType(A_arbace_pprint_check_arg_conditional_A_class, reflect.TypeFor[A_arbace_pprint_check_arg_conditional_A]()) }

func A_arbace_pprint_check_enumerated_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_check_enumerated_arg_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_check_enumerated_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_check_enumerated_arg_A_New()}; return nil }

func A_arbace_pprint_check_enumerated_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_check_enumerated_arg_A_fn_class)}; return nil }

var A_arbace_pprint_check_enumerated_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_check_enumerated_arg_A_invoke, New: A_arbace_pprint_check_enumerated_arg_A_new, Get: A_arbace_pprint_check_enumerated_arg_A_get}

var A_arbace_pprint_check_enumerated_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$check_enumerated_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "check_enumerated_arg", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_check_enumerated_arg_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_check_enumerated_arg_A_class.Info(); i.IsInstance = A_arbace_pprint_check_enumerated_arg_A_InstanceOf; i.Init = A_arbace_pprint_check_enumerated_arg_A_Init; i.Table = A_arbace_pprint_check_enumerated_arg_A_members; jrt.RegisterGoType(A_arbace_pprint_check_enumerated_arg_A_class, reflect.TypeFor[A_arbace_pprint_check_enumerated_arg_A]()) }

func A_arbace_pprint_check_flags_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_check_flags_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_check_flags_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_check_flags_A_New()}; return nil }

func A_arbace_pprint_check_flags_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_check_flags_A_fn_class)}; return nil }

var A_arbace_pprint_check_flags_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_check_flags_A_invoke, New: A_arbace_pprint_check_flags_A_new, Get: A_arbace_pprint_check_flags_A_get}

var A_arbace_pprint_check_flags_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$check_flags", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "check_flags", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_check_flags_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_check_flags_A_class.Info(); i.IsInstance = A_arbace_pprint_check_flags_A_InstanceOf; i.Init = A_arbace_pprint_check_flags_A_Init; i.Table = A_arbace_pprint_check_flags_A_members; jrt.RegisterGoType(A_arbace_pprint_check_flags_A_class, reflect.TypeFor[A_arbace_pprint_check_flags_A]()) }

func A_arbace_pprint_choice_conditional_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_choice_conditional_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_choice_conditional_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_choice_conditional_A_New()}; return nil }

func A_arbace_pprint_choice_conditional_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_choice_conditional_A_fn_class)}; return nil }

var A_arbace_pprint_choice_conditional_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_choice_conditional_A_invoke, New: A_arbace_pprint_choice_conditional_A_new, Get: A_arbace_pprint_choice_conditional_A_get}

var A_arbace_pprint_choice_conditional_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$choice_conditional", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "choice_conditional", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_choice_conditional_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_choice_conditional_A_class.Info(); i.IsInstance = A_arbace_pprint_choice_conditional_A_InstanceOf; i.Init = A_arbace_pprint_choice_conditional_A_Init; i.Table = A_arbace_pprint_choice_conditional_A_members; jrt.RegisterGoType(A_arbace_pprint_choice_conditional_A_class, reflect.TypeFor[A_arbace_pprint_choice_conditional_A]()) }

func A_arbace_pprint_cl_format_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_cl_format_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_cl_format_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_cl_format_A_New()}; return nil }

func A_arbace_pprint_cl_format_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_cl_format_A_fn_class)}; return nil }

var A_arbace_pprint_cl_format_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_cl_format_A_invoke, New: A_arbace_pprint_cl_format_A_new, Get: A_arbace_pprint_cl_format_A_get}

var A_arbace_pprint_cl_format_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$cl_format", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_pprint_A_class, Simple: "cl_format", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_cl_format_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_cl_format_A_class.Info(); i.IsInstance = A_arbace_pprint_cl_format_A_InstanceOf; i.Init = A_arbace_pprint_cl_format_A_Init; i.Table = A_arbace_pprint_cl_format_A_members; jrt.RegisterGoType(A_arbace_pprint_cl_format_A_class, reflect.TypeFor[A_arbace_pprint_cl_format_A]()) }

func A_arbace_pprint_collect_clauses_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_collect_clauses_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_collect_clauses_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_collect_clauses_A_New()}; return nil }

func A_arbace_pprint_collect_clauses_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_collect_clauses_A_fn_class)}; return nil }

var A_arbace_pprint_collect_clauses_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_collect_clauses_A_invoke, New: A_arbace_pprint_collect_clauses_A_new, Get: A_arbace_pprint_collect_clauses_A_get}

var A_arbace_pprint_collect_clauses_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$collect_clauses", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "collect_clauses", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_collect_clauses_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_collect_clauses_A_class.Info(); i.IsInstance = A_arbace_pprint_collect_clauses_A_InstanceOf; i.Init = A_arbace_pprint_collect_clauses_A_Init; i.Table = A_arbace_pprint_collect_clauses_A_members; jrt.RegisterGoType(A_arbace_pprint_collect_clauses_A_class, reflect.TypeFor[A_arbace_pprint_collect_clauses_A]()) }

func A_arbace_pprint_collect_clauses_fn__1819000548_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_collect_clauses_fn__1819000548_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_collect_clauses_fn__1819000548_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_collect_clauses_fn__1819000548_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_collect_clauses_fn__1819000548_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_collect_clauses_fn__1819000548_A_fn_class)}; return nil }

var A_arbace_pprint_collect_clauses_fn__1819000548_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_collect_clauses_fn__1819000548_A_invoke, New: A_arbace_pprint_collect_clauses_fn__1819000548_A_new, Get: A_arbace_pprint_collect_clauses_fn__1819000548_A_get}

var A_arbace_pprint_collect_clauses_fn__1819000548_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$collect_clauses$fn__1819000548", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_collect_clauses_A_class, Simple: "fn__1819000548", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_collect_clauses_fn__1819000548_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_collect_clauses_fn__1819000548_A_class.Info(); i.IsInstance = A_arbace_pprint_collect_clauses_fn__1819000548_A_InstanceOf; i.Init = A_arbace_pprint_collect_clauses_fn__1819000548_A_Init; i.Table = A_arbace_pprint_collect_clauses_fn__1819000548_A_members; jrt.RegisterGoType(A_arbace_pprint_collect_clauses_fn__1819000548_A_class, reflect.TypeFor[A_arbace_pprint_collect_clauses_fn__1819000548_A]()) }

func A_arbace_pprint_column_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_column_writer_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_pprint_column_writer_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_column_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_column_writer_A_New()}; return nil }

func A_arbace_pprint_column_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_column_writer_A_fn_class)}; return nil }

var A_arbace_pprint_column_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_column_writer_A_invoke, New: A_arbace_pprint_column_writer_A_new, Get: A_arbace_pprint_column_writer_A_get}

var A_arbace_pprint_column_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$column_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "column_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_column_writer_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_column_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_column_writer_A_InstanceOf; i.Init = A_arbace_pprint_column_writer_A_Init; i.Table = A_arbace_pprint_column_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_column_writer_A_class, reflect.TypeFor[A_arbace_pprint_column_writer_A]()) }

func A_arbace_pprint_column_writer_fn__44000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_column_writer_fn__44000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_column_writer_fn__44000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_column_writer_fn__44000019_A_New_O(args[0])}; return nil }

func A_arbace_pprint_column_writer_fn__44000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_column_writer_fn__44000019_A_fn_class)}; return nil }

var A_arbace_pprint_column_writer_fn__44000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_column_writer_fn__44000019_A_invoke, New: A_arbace_pprint_column_writer_fn__44000019_A_new, Get: A_arbace_pprint_column_writer_fn__44000019_A_get}

var A_arbace_pprint_column_writer_fn__44000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$column_writer$fn__44000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_column_writer_A_class, Simple: "fn__44000019", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_column_writer_fn__44000019_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_column_writer_fn__44000019_A_class.Info(); i.IsInstance = A_arbace_pprint_column_writer_fn__44000019_A_InstanceOf; i.Init = A_arbace_pprint_column_writer_fn__44000019_A_Init; i.Table = A_arbace_pprint_column_writer_fn__44000019_A_members; jrt.RegisterGoType(A_arbace_pprint_column_writer_fn__44000019_A_class, reflect.TypeFor[A_arbace_pprint_column_writer_fn__44000019_A]()) }

func A_arbace_pprint_column_writer_fn__44000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_column_writer_fn__44000021_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_column_writer_fn__44000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_column_writer_fn__44000021_A_New_O(args[0])}; return nil }

func A_arbace_pprint_column_writer_fn__44000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_column_writer_fn__44000021_A_fn_class)}; return nil }

var A_arbace_pprint_column_writer_fn__44000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_column_writer_fn__44000021_A_invoke, New: A_arbace_pprint_column_writer_fn__44000021_A_new, Get: A_arbace_pprint_column_writer_fn__44000021_A_get}

var A_arbace_pprint_column_writer_fn__44000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$column_writer$fn__44000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_column_writer_A_class, Simple: "fn__44000021", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_column_writer_fn__44000021_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_column_writer_fn__44000021_A_class.Info(); i.IsInstance = A_arbace_pprint_column_writer_fn__44000021_A_InstanceOf; i.Init = A_arbace_pprint_column_writer_fn__44000021_A_Init; i.Table = A_arbace_pprint_column_writer_fn__44000021_A_members; jrt.RegisterGoType(A_arbace_pprint_column_writer_fn__44000021_A_class, reflect.TypeFor[A_arbace_pprint_column_writer_fn__44000021_A]()) }

func A_arbace_pprint_column_writer_fn__44000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_column_writer_fn__44000023_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_pprint_column_writer_fn__44000023_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_column_writer_fn__44000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_column_writer_fn__44000023_A_New()}; return nil }

func A_arbace_pprint_column_writer_fn__44000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_column_writer_fn__44000023_A_fn_class)}; return nil }

var A_arbace_pprint_column_writer_fn__44000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_column_writer_fn__44000023_A_invoke, New: A_arbace_pprint_column_writer_fn__44000023_A_new, Get: A_arbace_pprint_column_writer_fn__44000023_A_get}

var A_arbace_pprint_column_writer_fn__44000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$column_writer$fn__44000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_column_writer_A_class, Simple: "fn__44000023", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_column_writer_fn__44000023_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_column_writer_fn__44000023_A_class.Info(); i.IsInstance = A_arbace_pprint_column_writer_fn__44000023_A_InstanceOf; i.Init = A_arbace_pprint_column_writer_fn__44000023_A_Init; i.Table = A_arbace_pprint_column_writer_fn__44000023_A_members; jrt.RegisterGoType(A_arbace_pprint_column_writer_fn__44000023_A_class, reflect.TypeFor[A_arbace_pprint_column_writer_fn__44000023_A]()) }

func A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_fn_class)}; return nil }

var A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_invoke, New: A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_new, Get: A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_get}

var A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$column_writer$fn__44000023$fn__44000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_column_writer_fn__44000023_A_class, Simple: "fn__44000026", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_class.Info(); i.IsInstance = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_InstanceOf; i.Init = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_Init; i.Table = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_members; jrt.RegisterGoType(A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_class, reflect.TypeFor[A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A]()) }

func A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_New()}; return nil }

func A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_fn_class)}; return nil }

var A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_invoke, New: A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_new, Get: A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_get}

var A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$column_writer$fn__44000023$fn__44000026$fn__44000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_column_writer_fn__44000023_fn__44000026_A_class, Simple: "fn__44000027", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_class.Info(); i.IsInstance = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_InstanceOf; i.Init = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_Init; i.Table = A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_members; jrt.RegisterGoType(A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A_class, reflect.TypeFor[A_arbace_pprint_column_writer_fn__44000023_fn__44000026_fn__44000027_A]()) }

func A_arbace_pprint_compile_directive_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_compile_directive_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_compile_directive_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_compile_directive_A_New()}; return nil }

func A_arbace_pprint_compile_directive_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_compile_directive_A_fn_class)}; return nil }

var A_arbace_pprint_compile_directive_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_compile_directive_A_invoke, New: A_arbace_pprint_compile_directive_A_new, Get: A_arbace_pprint_compile_directive_A_get}

var A_arbace_pprint_compile_directive_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$compile_directive", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "compile_directive", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_compile_directive_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_compile_directive_A_class.Info(); i.IsInstance = A_arbace_pprint_compile_directive_A_InstanceOf; i.Init = A_arbace_pprint_compile_directive_A_Init; i.Table = A_arbace_pprint_compile_directive_A_members; jrt.RegisterGoType(A_arbace_pprint_compile_directive_A_class, reflect.TypeFor[A_arbace_pprint_compile_directive_A]()) }

func A_arbace_pprint_compile_format_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_compile_format_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_compile_format_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_compile_format_A_New()}; return nil }

func A_arbace_pprint_compile_format_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_compile_format_A_fn_class)}; return nil }

var A_arbace_pprint_compile_format_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_compile_format_A_invoke, New: A_arbace_pprint_compile_format_A_new, Get: A_arbace_pprint_compile_format_A_get}

var A_arbace_pprint_compile_format_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$compile_format", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "compile_format", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_compile_format_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_compile_format_A_class.Info(); i.IsInstance = A_arbace_pprint_compile_format_A_InstanceOf; i.Init = A_arbace_pprint_compile_format_A_Init; i.Table = A_arbace_pprint_compile_format_A_members; jrt.RegisterGoType(A_arbace_pprint_compile_format_A_class, reflect.TypeFor[A_arbace_pprint_compile_format_A]()) }

func A_arbace_pprint_compile_format_fn__1819000564_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_compile_format_fn__1819000564_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_compile_format_fn__1819000564_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_compile_format_fn__1819000564_A_New()}; return nil }

func A_arbace_pprint_compile_format_fn__1819000564_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_compile_format_fn__1819000564_A_fn_class)}; return nil }

var A_arbace_pprint_compile_format_fn__1819000564_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_compile_format_fn__1819000564_A_invoke, New: A_arbace_pprint_compile_format_fn__1819000564_A_new, Get: A_arbace_pprint_compile_format_fn__1819000564_A_get}

var A_arbace_pprint_compile_format_fn__1819000564_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$compile_format$fn__1819000564", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_compile_format_A_class, Simple: "fn__1819000564", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_compile_format_fn__1819000564_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_compile_format_fn__1819000564_A_class.Info(); i.IsInstance = A_arbace_pprint_compile_format_fn__1819000564_A_InstanceOf; i.Init = A_arbace_pprint_compile_format_fn__1819000564_A_Init; i.Table = A_arbace_pprint_compile_format_fn__1819000564_A_members; jrt.RegisterGoType(A_arbace_pprint_compile_format_fn__1819000564_A_class, reflect.TypeFor[A_arbace_pprint_compile_format_fn__1819000564_A]()) }

func A_arbace_pprint_compile_raw_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_compile_raw_string_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_compile_raw_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_compile_raw_string_A_New()}; return nil }

func A_arbace_pprint_compile_raw_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_compile_raw_string_A_fn_class)}; return nil }

var A_arbace_pprint_compile_raw_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_compile_raw_string_A_invoke, New: A_arbace_pprint_compile_raw_string_A_new, Get: A_arbace_pprint_compile_raw_string_A_get}

var A_arbace_pprint_compile_raw_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$compile_raw_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "compile_raw_string", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_compile_raw_string_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_compile_raw_string_A_class.Info(); i.IsInstance = A_arbace_pprint_compile_raw_string_A_InstanceOf; i.Init = A_arbace_pprint_compile_raw_string_A_Init; i.Table = A_arbace_pprint_compile_raw_string_A_members; jrt.RegisterGoType(A_arbace_pprint_compile_raw_string_A_class, reflect.TypeFor[A_arbace_pprint_compile_raw_string_A]()) }

func A_arbace_pprint_compile_raw_string_fn__1819000534_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_compile_raw_string_fn__1819000534_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_compile_raw_string_fn__1819000534_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_compile_raw_string_fn__1819000534_A_New_O(args[0])}; return nil }

func A_arbace_pprint_compile_raw_string_fn__1819000534_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_compile_raw_string_fn__1819000534_A_fn_class)}; return nil }

var A_arbace_pprint_compile_raw_string_fn__1819000534_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_compile_raw_string_fn__1819000534_A_invoke, New: A_arbace_pprint_compile_raw_string_fn__1819000534_A_new, Get: A_arbace_pprint_compile_raw_string_fn__1819000534_A_get}

var A_arbace_pprint_compile_raw_string_fn__1819000534_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$compile_raw_string$fn__1819000534", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_compile_raw_string_A_class, Simple: "fn__1819000534", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_compile_raw_string_fn__1819000534_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_compile_raw_string_fn__1819000534_A_class.Info(); i.IsInstance = A_arbace_pprint_compile_raw_string_fn__1819000534_A_InstanceOf; i.Init = A_arbace_pprint_compile_raw_string_fn__1819000534_A_Init; i.Table = A_arbace_pprint_compile_raw_string_fn__1819000534_A_members; jrt.RegisterGoType(A_arbace_pprint_compile_raw_string_fn__1819000534_A_class, reflect.TypeFor[A_arbace_pprint_compile_raw_string_fn__1819000534_A]()) }

func A_arbace_pprint_conditional_newline_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_conditional_newline_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_conditional_newline_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_conditional_newline_A_New()}; return nil }

func A_arbace_pprint_conditional_newline_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_conditional_newline_A_fn_class)}; return nil }

var A_arbace_pprint_conditional_newline_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_conditional_newline_A_invoke, New: A_arbace_pprint_conditional_newline_A_new, Get: A_arbace_pprint_conditional_newline_A_get}

var A_arbace_pprint_conditional_newline_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$conditional_newline", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "conditional_newline", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_conditional_newline_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_conditional_newline_A_class.Info(); i.IsInstance = A_arbace_pprint_conditional_newline_A_InstanceOf; i.Init = A_arbace_pprint_conditional_newline_A_Init; i.Table = A_arbace_pprint_conditional_newline_A_members; jrt.RegisterGoType(A_arbace_pprint_conditional_newline_A_class, reflect.TypeFor[A_arbace_pprint_conditional_newline_A]()) }

func A_arbace_pprint_consume_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_consume_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_consume_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_consume_A_New()}; return nil }

func A_arbace_pprint_consume_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_consume_A_fn_class)}; return nil }

var A_arbace_pprint_consume_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_consume_A_invoke, New: A_arbace_pprint_consume_A_new, Get: A_arbace_pprint_consume_A_get}

var A_arbace_pprint_consume_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$consume", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "consume", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_consume_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_consume_A_class.Info(); i.IsInstance = A_arbace_pprint_consume_A_InstanceOf; i.Init = A_arbace_pprint_consume_A_Init; i.Table = A_arbace_pprint_consume_A_members; jrt.RegisterGoType(A_arbace_pprint_consume_A_class, reflect.TypeFor[A_arbace_pprint_consume_A]()) }

func A_arbace_pprint_consume_while_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_consume_while_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_consume_while_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_consume_while_A_New()}; return nil }

func A_arbace_pprint_consume_while_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_consume_while_A_fn_class)}; return nil }

var A_arbace_pprint_consume_while_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_consume_while_A_invoke, New: A_arbace_pprint_consume_while_A_new, Get: A_arbace_pprint_consume_while_A_get}

var A_arbace_pprint_consume_while_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$consume_while", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "consume_while", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_consume_while_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_consume_while_A_class.Info(); i.IsInstance = A_arbace_pprint_consume_while_A_InstanceOf; i.Init = A_arbace_pprint_consume_while_A_Init; i.Table = A_arbace_pprint_consume_while_A_members; jrt.RegisterGoType(A_arbace_pprint_consume_while_A_class, reflect.TypeFor[A_arbace_pprint_consume_while_A]()) }

func A_arbace_pprint_convert_ratio_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_convert_ratio_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_convert_ratio_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_convert_ratio_A_New()}; return nil }

func A_arbace_pprint_convert_ratio_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_convert_ratio_A_fn_class)}; return nil }

var A_arbace_pprint_convert_ratio_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_convert_ratio_A_invoke, New: A_arbace_pprint_convert_ratio_A_new, Get: A_arbace_pprint_convert_ratio_A_get}

var A_arbace_pprint_convert_ratio_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$convert_ratio", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "convert_ratio", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_convert_ratio_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_convert_ratio_A_class.Info(); i.IsInstance = A_arbace_pprint_convert_ratio_A_InstanceOf; i.Init = A_arbace_pprint_convert_ratio_A_Init; i.Table = A_arbace_pprint_convert_ratio_A_members; jrt.RegisterGoType(A_arbace_pprint_convert_ratio_A_class, reflect.TypeFor[A_arbace_pprint_convert_ratio_A]()) }

func A_arbace_pprint_defdirectives_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_defdirectives_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_defdirectives_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_defdirectives_A_New()}; return nil }

func A_arbace_pprint_defdirectives_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_defdirectives_A_fn_class)}; return nil }

var A_arbace_pprint_defdirectives_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_defdirectives_A_invoke, New: A_arbace_pprint_defdirectives_A_new, Get: A_arbace_pprint_defdirectives_A_get}

var A_arbace_pprint_defdirectives_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$defdirectives", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_pprint_A_class, Simple: "defdirectives", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_defdirectives_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_defdirectives_A_class.Info(); i.IsInstance = A_arbace_pprint_defdirectives_A_InstanceOf; i.Init = A_arbace_pprint_defdirectives_A_Init; i.Table = A_arbace_pprint_defdirectives_A_members; jrt.RegisterGoType(A_arbace_pprint_defdirectives_A_class, reflect.TypeFor[A_arbace_pprint_defdirectives_A]()) }

func A_arbace_pprint_deftype_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_deftype_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_deftype_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_deftype_A_New()}; return nil }

func A_arbace_pprint_deftype_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_deftype_A_fn_class)}; return nil }

var A_arbace_pprint_deftype_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_deftype_A_invoke, New: A_arbace_pprint_deftype_A_new, Get: A_arbace_pprint_deftype_A_get}

var A_arbace_pprint_deftype_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$deftype", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_pprint_A_class, Simple: "deftype", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_deftype_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_deftype_A_class.Info(); i.IsInstance = A_arbace_pprint_deftype_A_InstanceOf; i.Init = A_arbace_pprint_deftype_A_Init; i.Table = A_arbace_pprint_deftype_A_members; jrt.RegisterGoType(A_arbace_pprint_deftype_A_class, reflect.TypeFor[A_arbace_pprint_deftype_A]()) }

func A_arbace_pprint_dollar_float_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_dollar_float_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_dollar_float_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_dollar_float_A_New()}; return nil }

func A_arbace_pprint_dollar_float_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_dollar_float_A_fn_class)}; return nil }

var A_arbace_pprint_dollar_float_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_dollar_float_A_invoke, New: A_arbace_pprint_dollar_float_A_new, Get: A_arbace_pprint_dollar_float_A_get}

var A_arbace_pprint_dollar_float_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$dollar_float", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "dollar_float", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_dollar_float_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_dollar_float_A_class.Info(); i.IsInstance = A_arbace_pprint_dollar_float_A_InstanceOf; i.Init = A_arbace_pprint_dollar_float_A_Init; i.Table = A_arbace_pprint_dollar_float_A_members; jrt.RegisterGoType(A_arbace_pprint_dollar_float_A_class, reflect.TypeFor[A_arbace_pprint_dollar_float_A]()) }

func A_arbace_pprint_downcase_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_downcase_writer_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_downcase_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_downcase_writer_A_New()}; return nil }

func A_arbace_pprint_downcase_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_downcase_writer_A_fn_class)}; return nil }

var A_arbace_pprint_downcase_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_downcase_writer_A_invoke, New: A_arbace_pprint_downcase_writer_A_new, Get: A_arbace_pprint_downcase_writer_A_get}

var A_arbace_pprint_downcase_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$downcase_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "downcase_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_downcase_writer_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_downcase_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_downcase_writer_A_InstanceOf; i.Init = A_arbace_pprint_downcase_writer_A_Init; i.Table = A_arbace_pprint_downcase_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_downcase_writer_A_class, reflect.TypeFor[A_arbace_pprint_downcase_writer_A]()) }

func A_arbace_pprint_downcase_writer_fn__1819000216_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_downcase_writer_fn__1819000216_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_downcase_writer_fn__1819000216_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_downcase_writer_fn__1819000216_A_New_O(args[0])}; return nil }

func A_arbace_pprint_downcase_writer_fn__1819000216_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_downcase_writer_fn__1819000216_A_fn_class)}; return nil }

var A_arbace_pprint_downcase_writer_fn__1819000216_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_downcase_writer_fn__1819000216_A_invoke, New: A_arbace_pprint_downcase_writer_fn__1819000216_A_new, Get: A_arbace_pprint_downcase_writer_fn__1819000216_A_get}

var A_arbace_pprint_downcase_writer_fn__1819000216_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$downcase_writer$fn__1819000216", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_downcase_writer_A_class, Simple: "fn__1819000216", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_downcase_writer_fn__1819000216_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_downcase_writer_fn__1819000216_A_class.Info(); i.IsInstance = A_arbace_pprint_downcase_writer_fn__1819000216_A_InstanceOf; i.Init = A_arbace_pprint_downcase_writer_fn__1819000216_A_Init; i.Table = A_arbace_pprint_downcase_writer_fn__1819000216_A_members; jrt.RegisterGoType(A_arbace_pprint_downcase_writer_fn__1819000216_A_class, reflect.TypeFor[A_arbace_pprint_downcase_writer_fn__1819000216_A]()) }

func A_arbace_pprint_downcase_writer_fn__1819000218_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_downcase_writer_fn__1819000218_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_downcase_writer_fn__1819000218_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_downcase_writer_fn__1819000218_A_New_O(args[0])}; return nil }

func A_arbace_pprint_downcase_writer_fn__1819000218_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_downcase_writer_fn__1819000218_A_fn_class)}; return nil }

var A_arbace_pprint_downcase_writer_fn__1819000218_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_downcase_writer_fn__1819000218_A_invoke, New: A_arbace_pprint_downcase_writer_fn__1819000218_A_new, Get: A_arbace_pprint_downcase_writer_fn__1819000218_A_get}

var A_arbace_pprint_downcase_writer_fn__1819000218_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$downcase_writer$fn__1819000218", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_downcase_writer_A_class, Simple: "fn__1819000218", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_downcase_writer_fn__1819000218_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_downcase_writer_fn__1819000218_A_class.Info(); i.IsInstance = A_arbace_pprint_downcase_writer_fn__1819000218_A_InstanceOf; i.Init = A_arbace_pprint_downcase_writer_fn__1819000218_A_Init; i.Table = A_arbace_pprint_downcase_writer_fn__1819000218_A_members; jrt.RegisterGoType(A_arbace_pprint_downcase_writer_fn__1819000218_A_class, reflect.TypeFor[A_arbace_pprint_downcase_writer_fn__1819000218_A]()) }

func A_arbace_pprint_downcase_writer_fn__1819000220_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_downcase_writer_fn__1819000220_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_pprint_downcase_writer_fn__1819000220_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_downcase_writer_fn__1819000220_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_downcase_writer_fn__1819000220_A_New_O(args[0])}; return nil }

func A_arbace_pprint_downcase_writer_fn__1819000220_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_downcase_writer_fn__1819000220_A_fn_class)}; return nil }

var A_arbace_pprint_downcase_writer_fn__1819000220_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_downcase_writer_fn__1819000220_A_invoke, New: A_arbace_pprint_downcase_writer_fn__1819000220_A_new, Get: A_arbace_pprint_downcase_writer_fn__1819000220_A_get}

var A_arbace_pprint_downcase_writer_fn__1819000220_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$downcase_writer$fn__1819000220", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_downcase_writer_A_class, Simple: "fn__1819000220", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_downcase_writer_fn__1819000220_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_downcase_writer_fn__1819000220_A_class.Info(); i.IsInstance = A_arbace_pprint_downcase_writer_fn__1819000220_A_InstanceOf; i.Init = A_arbace_pprint_downcase_writer_fn__1819000220_A_Init; i.Table = A_arbace_pprint_downcase_writer_fn__1819000220_A_members; jrt.RegisterGoType(A_arbace_pprint_downcase_writer_fn__1819000220_A_class, reflect.TypeFor[A_arbace_pprint_downcase_writer_fn__1819000220_A]()) }

func A_arbace_pprint_else_separator_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_else_separator_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_else_separator_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_else_separator_QMARK__A_New()}; return nil }

func A_arbace_pprint_else_separator_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_else_separator_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_else_separator_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_else_separator_QMARK__A_invoke, New: A_arbace_pprint_else_separator_QMARK__A_new, Get: A_arbace_pprint_else_separator_QMARK__A_get}

var A_arbace_pprint_else_separator_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$else_separator_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "else_separator_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_else_separator_QMARK__A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_else_separator_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_else_separator_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_else_separator_QMARK__A_Init; i.Table = A_arbace_pprint_else_separator_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_else_separator_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_else_separator_QMARK__A]()) }

func A_arbace_pprint_emit_nl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_emit_nl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_emit_nl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_emit_nl_A_New()}; return nil }

func A_arbace_pprint_emit_nl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_emit_nl_A_fn_class)}; return nil }

var A_arbace_pprint_emit_nl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_emit_nl_A_invoke, New: A_arbace_pprint_emit_nl_A_new, Get: A_arbace_pprint_emit_nl_A_get}

var A_arbace_pprint_emit_nl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$emit_nl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "emit_nl", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_emit_nl_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_emit_nl_A_class.Info(); i.IsInstance = A_arbace_pprint_emit_nl_A_InstanceOf; i.Init = A_arbace_pprint_emit_nl_A_Init; i.Table = A_arbace_pprint_emit_nl_A_members; jrt.RegisterGoType(A_arbace_pprint_emit_nl_A_class, reflect.TypeFor[A_arbace_pprint_emit_nl_A]()) }

func A_arbace_pprint_emit_nl_fn__1820000124_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_emit_nl_fn__1820000124_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_emit_nl_fn__1820000124_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_emit_nl_fn__1820000124_A_New_O(args[0])}; return nil }

func A_arbace_pprint_emit_nl_fn__1820000124_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_emit_nl_fn__1820000124_A_fn_class)}; return nil }

var A_arbace_pprint_emit_nl_fn__1820000124_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_emit_nl_fn__1820000124_A_invoke, New: A_arbace_pprint_emit_nl_fn__1820000124_A_new, Get: A_arbace_pprint_emit_nl_fn__1820000124_A_get}

var A_arbace_pprint_emit_nl_fn__1820000124_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$emit_nl$fn__1820000124", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_emit_nl_A_class, Simple: "fn__1820000124", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_emit_nl_fn__1820000124_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_emit_nl_fn__1820000124_A_class.Info(); i.IsInstance = A_arbace_pprint_emit_nl_fn__1820000124_A_InstanceOf; i.Init = A_arbace_pprint_emit_nl_fn__1820000124_A_Init; i.Table = A_arbace_pprint_emit_nl_fn__1820000124_A_members; jrt.RegisterGoType(A_arbace_pprint_emit_nl_fn__1820000124_A_class, reflect.TypeFor[A_arbace_pprint_emit_nl_fn__1820000124_A]()) }

func A_arbace_pprint_end_block_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_end_block_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_end_block_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_end_block_A_New()}; return nil }

func A_arbace_pprint_end_block_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_end_block_A_fn_class)}; return nil }

var A_arbace_pprint_end_block_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_end_block_A_invoke, New: A_arbace_pprint_end_block_A_new, Get: A_arbace_pprint_end_block_A_get}

var A_arbace_pprint_end_block_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$end_block", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "end_block", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_end_block_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_end_block_A_class.Info(); i.IsInstance = A_arbace_pprint_end_block_A_InstanceOf; i.Init = A_arbace_pprint_end_block_A_Init; i.Table = A_arbace_pprint_end_block_A_members; jrt.RegisterGoType(A_arbace_pprint_end_block_A_class, reflect.TypeFor[A_arbace_pprint_end_block_A]()) }

func A_arbace_pprint_end_block_fn__1820000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_end_block_fn__1820000193_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_end_block_fn__1820000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_end_block_fn__1820000193_A_New_O(args[0])}; return nil }

func A_arbace_pprint_end_block_fn__1820000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_end_block_fn__1820000193_A_fn_class)}; return nil }

var A_arbace_pprint_end_block_fn__1820000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_end_block_fn__1820000193_A_invoke, New: A_arbace_pprint_end_block_fn__1820000193_A_new, Get: A_arbace_pprint_end_block_fn__1820000193_A_get}

var A_arbace_pprint_end_block_fn__1820000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$end_block$fn__1820000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_end_block_A_class, Simple: "fn__1820000193", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_end_block_fn__1820000193_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_end_block_fn__1820000193_A_class.Info(); i.IsInstance = A_arbace_pprint_end_block_fn__1820000193_A_InstanceOf; i.Init = A_arbace_pprint_end_block_fn__1820000193_A_Init; i.Table = A_arbace_pprint_end_block_fn__1820000193_A_members; jrt.RegisterGoType(A_arbace_pprint_end_block_fn__1820000193_A_class, reflect.TypeFor[A_arbace_pprint_end_block_fn__1820000193_A]()) }

func A_arbace_pprint_end_block_t_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_end_block_t_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_end_block_t_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_end_block_t_QMARK__A_New()}; return nil }

func A_arbace_pprint_end_block_t_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_end_block_t_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_end_block_t_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_end_block_t_QMARK__A_invoke, New: A_arbace_pprint_end_block_t_QMARK__A_new, Get: A_arbace_pprint_end_block_t_QMARK__A_get}

var A_arbace_pprint_end_block_t_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$end_block_t_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "end_block_t_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_end_block_t_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_end_block_t_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_end_block_t_QMARK__A_Init; i.Table = A_arbace_pprint_end_block_t_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_end_block_t_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_end_block_t_QMARK__A]()) }

func A_arbace_pprint_eval1513000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1513000004_A_New()}; return nil }

var A_arbace_pprint_eval1513000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1513000004_A_new}

var A_arbace_pprint_eval1513000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1513000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1513000004", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1513000004_A"})

func init() { i := A_arbace_pprint_eval1513000004_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1513000004_A_InstanceOf; i.Table = A_arbace_pprint_eval1513000004_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1513000004_A_class, reflect.TypeFor[A_arbace_pprint_eval1513000004_A]()) }

func A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_New()}; return nil }

func A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_fn_class)}; return nil }

var A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_invoke, New: A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_new, Get: A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_get}

var A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1513000004$loading__1927001464__auto____1513000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_eval1513000004_A_class, Simple: "loading__1927001464__auto____1513000005", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A", Source: "pprint.ae"})

func init() { i := A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_InstanceOf; i.Init = A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_Init; i.Table = A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_class, reflect.TypeFor[A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A]()) }

func A_arbace_pprint_eval1513000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1513000008_A_New()}; return nil }

var A_arbace_pprint_eval1513000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1513000008_A_new}

var A_arbace_pprint_eval1513000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1513000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1513000008", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1513000008_A"})

func init() { i := A_arbace_pprint_eval1513000008_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1513000008_A_InstanceOf; i.Table = A_arbace_pprint_eval1513000008_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1513000008_A_class, reflect.TypeFor[A_arbace_pprint_eval1513000008_A]()) }

func A_arbace_pprint_eval1513000008_fn__1513000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1513000008_fn__1513000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_eval1513000008_fn__1513000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1513000008_fn__1513000009_A_New()}; return nil }

func A_arbace_pprint_eval1513000008_fn__1513000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1513000008_fn__1513000009_A_fn_class)}; return nil }

var A_arbace_pprint_eval1513000008_fn__1513000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1513000008_fn__1513000009_A_invoke, New: A_arbace_pprint_eval1513000008_fn__1513000009_A_new, Get: A_arbace_pprint_eval1513000008_fn__1513000009_A_get}

var A_arbace_pprint_eval1513000008_fn__1513000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1513000008$fn__1513000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_eval1513000008_A_class, Simple: "fn__1513000009", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1513000008_fn__1513000009_A", Source: "pprint.ae"})

func init() { i := A_arbace_pprint_eval1513000008_fn__1513000009_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1513000008_fn__1513000009_A_InstanceOf; i.Init = A_arbace_pprint_eval1513000008_fn__1513000009_A_Init; i.Table = A_arbace_pprint_eval1513000008_fn__1513000009_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1513000008_fn__1513000009_A_class, reflect.TypeFor[A_arbace_pprint_eval1513000008_fn__1513000009_A]()) }

func A_arbace_pprint_eval1820000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000055_A_New()}; return nil }

var A_arbace_pprint_eval1820000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000055_A_new}

var A_arbace_pprint_eval1820000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000055", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000055_A"})

func init() { i := A_arbace_pprint_eval1820000055_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000055_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000055_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000055_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000055_A]()) }

func A_arbace_pprint_eval1820000055_fn__1820000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000055_fn__1820000056_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_eval1820000055_fn__1820000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000055_fn__1820000056_A_New()}; return nil }

func A_arbace_pprint_eval1820000055_fn__1820000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000055_fn__1820000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000055_fn__1820000056_A_invoke, New: A_arbace_pprint_eval1820000055_fn__1820000056_A_new, Get: A_arbace_pprint_eval1820000055_fn__1820000056_A_get}

var A_arbace_pprint_eval1820000055_fn__1820000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000055$fn__1820000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_eval1820000055_A_class, Simple: "fn__1820000056", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000055_fn__1820000056_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000055_fn__1820000056_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000055_fn__1820000056_A_Init; i.Table = A_arbace_pprint_eval1820000055_fn__1820000056_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000055_fn__1820000056_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000055_fn__1820000056_A]()) }

func A_arbace_pprint_eval1820000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000059_A_New()}; return nil }

var A_arbace_pprint_eval1820000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000059_A_new}

var A_arbace_pprint_eval1820000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000059", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000059_A"})

func init() { i := A_arbace_pprint_eval1820000059_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000059_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000059_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000059_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000059_A]()) }

func A_arbace_pprint_eval1820000059_fn__1820000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000059_fn__1820000060_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_eval1820000059_fn__1820000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000059_fn__1820000060_A_New()}; return nil }

func A_arbace_pprint_eval1820000059_fn__1820000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000059_fn__1820000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000059_fn__1820000060_A_invoke, New: A_arbace_pprint_eval1820000059_fn__1820000060_A_new, Get: A_arbace_pprint_eval1820000059_fn__1820000060_A_get}

var A_arbace_pprint_eval1820000059_fn__1820000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000059$fn__1820000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_eval1820000059_A_class, Simple: "fn__1820000060", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000059_fn__1820000060_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000059_fn__1820000060_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000059_fn__1820000060_A_Init; i.Table = A_arbace_pprint_eval1820000059_fn__1820000060_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000059_fn__1820000060_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000059_fn__1820000060_A]()) }

func A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_invoke, New: A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_new, Get: A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_get}

var A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000059$fn__1820000060$fn__1820000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_eval1820000059_fn__1820000060_A_class, Simple: "fn__1820000061", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_Init; i.Table = A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000059_fn__1820000060_fn__1820000061_A]()) }

func A_arbace_pprint_eval1820000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000065_A_New()}; return nil }

var A_arbace_pprint_eval1820000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000065_A_new}

var A_arbace_pprint_eval1820000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000065", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000065_A"})

func init() { i := A_arbace_pprint_eval1820000065_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000065_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000065_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000065_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000065_A]()) }

func A_arbace_pprint_eval1820000065_fn__1820000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000065_fn__1820000066_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_eval1820000065_fn__1820000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000065_fn__1820000066_A_New()}; return nil }

func A_arbace_pprint_eval1820000065_fn__1820000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000065_fn__1820000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000065_fn__1820000066_A_invoke, New: A_arbace_pprint_eval1820000065_fn__1820000066_A_new, Get: A_arbace_pprint_eval1820000065_fn__1820000066_A_get}

var A_arbace_pprint_eval1820000065_fn__1820000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000065$fn__1820000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_eval1820000065_A_class, Simple: "fn__1820000066", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000065_fn__1820000066_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000065_fn__1820000066_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000065_fn__1820000066_A_Init; i.Table = A_arbace_pprint_eval1820000065_fn__1820000066_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000065_fn__1820000066_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000065_fn__1820000066_A]()) }

func A_arbace_pprint_eval1820000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000069_A_New()}; return nil }

var A_arbace_pprint_eval1820000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000069_A_new}

var A_arbace_pprint_eval1820000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000069", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000069_A"})

func init() { i := A_arbace_pprint_eval1820000069_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000069_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000069_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000069_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000069_A]()) }

func A_arbace_pprint_eval1820000069_fn__1820000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000069_fn__1820000070_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_eval1820000069_fn__1820000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000069_fn__1820000070_A_New()}; return nil }

func A_arbace_pprint_eval1820000069_fn__1820000070_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000069_fn__1820000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000069_fn__1820000070_A_invoke, New: A_arbace_pprint_eval1820000069_fn__1820000070_A_new, Get: A_arbace_pprint_eval1820000069_fn__1820000070_A_get}

var A_arbace_pprint_eval1820000069_fn__1820000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000069$fn__1820000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_eval1820000069_A_class, Simple: "fn__1820000070", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000069_fn__1820000070_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000069_fn__1820000070_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000069_fn__1820000070_A_Init; i.Table = A_arbace_pprint_eval1820000069_fn__1820000070_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000069_fn__1820000070_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000069_fn__1820000070_A]()) }

func A_arbace_pprint_eval1820000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000075_A_New()}; return nil }

var A_arbace_pprint_eval1820000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000075_A_new}

var A_arbace_pprint_eval1820000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000075", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000075_A"})

func init() { i := A_arbace_pprint_eval1820000075_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000075_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000075_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000075_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000075_A]()) }

func A_arbace_pprint_eval1820000075_fn__1820000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000075_fn__1820000076_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_eval1820000075_fn__1820000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000075_fn__1820000076_A_New()}; return nil }

func A_arbace_pprint_eval1820000075_fn__1820000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000075_fn__1820000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000075_fn__1820000076_A_invoke, New: A_arbace_pprint_eval1820000075_fn__1820000076_A_new, Get: A_arbace_pprint_eval1820000075_fn__1820000076_A_get}

var A_arbace_pprint_eval1820000075_fn__1820000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000075$fn__1820000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_eval1820000075_A_class, Simple: "fn__1820000076", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000075_fn__1820000076_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000075_fn__1820000076_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000075_fn__1820000076_A_Init; i.Table = A_arbace_pprint_eval1820000075_fn__1820000076_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000075_fn__1820000076_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000075_fn__1820000076_A]()) }

func A_arbace_pprint_eval1820000079_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000079_A_New()}; return nil }

var A_arbace_pprint_eval1820000079_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000079_A_new}

var A_arbace_pprint_eval1820000079_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000079", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000079", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000079_A"})

func init() { i := A_arbace_pprint_eval1820000079_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000079_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000079_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000079_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000079_A]()) }

func A_arbace_pprint_eval1820000079_fn__1820000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000079_fn__1820000080_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_eval1820000079_fn__1820000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000079_fn__1820000080_A_New()}; return nil }

func A_arbace_pprint_eval1820000079_fn__1820000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000079_fn__1820000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000079_fn__1820000080_A_invoke, New: A_arbace_pprint_eval1820000079_fn__1820000080_A_new, Get: A_arbace_pprint_eval1820000079_fn__1820000080_A_get}

var A_arbace_pprint_eval1820000079_fn__1820000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000079$fn__1820000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_eval1820000079_A_class, Simple: "fn__1820000080", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000079_fn__1820000080_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000079_fn__1820000080_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000079_fn__1820000080_A_Init; i.Table = A_arbace_pprint_eval1820000079_fn__1820000080_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000079_fn__1820000080_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000079_fn__1820000080_A]()) }

func A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_New_O(args[0])}; return nil }

func A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_invoke, New: A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_new, Get: A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_get}

var A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000079$fn__1820000080$fn__1820000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_eval1820000079_fn__1820000080_A_class, Simple: "fn__1820000081", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_Init; i.Table = A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000079_fn__1820000080_fn__1820000081_A]()) }

func A_arbace_pprint_eval1820000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000093_A_New()}; return nil }

var A_arbace_pprint_eval1820000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000093_A_new}

var A_arbace_pprint_eval1820000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000093", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000093_A"})

func init() { i := A_arbace_pprint_eval1820000093_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000093_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000093_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000093_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000093_A]()) }

func A_arbace_pprint_eval1820000093_fn__1820000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000093_fn__1820000094_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_eval1820000093_fn__1820000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000093_fn__1820000094_A_New()}; return nil }

func A_arbace_pprint_eval1820000093_fn__1820000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000093_fn__1820000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000093_fn__1820000094_A_invoke, New: A_arbace_pprint_eval1820000093_fn__1820000094_A_new, Get: A_arbace_pprint_eval1820000093_fn__1820000094_A_get}

var A_arbace_pprint_eval1820000093_fn__1820000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000093$fn__1820000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_eval1820000093_A_class, Simple: "fn__1820000094", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000093_fn__1820000094_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000093_fn__1820000094_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000093_fn__1820000094_A_Init; i.Table = A_arbace_pprint_eval1820000093_fn__1820000094_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000093_fn__1820000094_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000093_fn__1820000094_A]()) }

func A_arbace_pprint_eval1820000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000097_A_New()}; return nil }

var A_arbace_pprint_eval1820000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000097_A_new}

var A_arbace_pprint_eval1820000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000097", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000097_A"})

func init() { i := A_arbace_pprint_eval1820000097_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000097_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000097_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000097_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000097_A]()) }

func A_arbace_pprint_eval1820000097_fn__1820000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000097_fn__1820000098_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_eval1820000097_fn__1820000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000097_fn__1820000098_A_New()}; return nil }

func A_arbace_pprint_eval1820000097_fn__1820000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000097_fn__1820000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000097_fn__1820000098_A_invoke, New: A_arbace_pprint_eval1820000097_fn__1820000098_A_new, Get: A_arbace_pprint_eval1820000097_fn__1820000098_A_get}

var A_arbace_pprint_eval1820000097_fn__1820000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000097$fn__1820000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_eval1820000097_A_class, Simple: "fn__1820000098", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000097_fn__1820000098_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000097_fn__1820000098_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000097_fn__1820000098_A_Init; i.Table = A_arbace_pprint_eval1820000097_fn__1820000098_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000097_fn__1820000098_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000097_fn__1820000098_A]()) }

func A_arbace_pprint_eval1820000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000101_A_New()}; return nil }

var A_arbace_pprint_eval1820000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000101_A_new}

var A_arbace_pprint_eval1820000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000101", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000101_A"})

func init() { i := A_arbace_pprint_eval1820000101_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000101_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000101_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000101_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000101_A]()) }

func A_arbace_pprint_eval1820000101_fn__1820000102_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000101_fn__1820000102_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_eval1820000101_fn__1820000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000101_fn__1820000102_A_New()}; return nil }

func A_arbace_pprint_eval1820000101_fn__1820000102_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000101_fn__1820000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000101_fn__1820000102_A_invoke, New: A_arbace_pprint_eval1820000101_fn__1820000102_A_new, Get: A_arbace_pprint_eval1820000101_fn__1820000102_A_get}

var A_arbace_pprint_eval1820000101_fn__1820000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000101$fn__1820000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_eval1820000101_A_class, Simple: "fn__1820000102", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000101_fn__1820000102_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000101_fn__1820000102_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000101_fn__1820000102_A_Init; i.Table = A_arbace_pprint_eval1820000101_fn__1820000102_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000101_fn__1820000102_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000101_fn__1820000102_A]()) }

func A_arbace_pprint_eval1820000105_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000105_A_New()}; return nil }

var A_arbace_pprint_eval1820000105_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000105_A_new}

var A_arbace_pprint_eval1820000105_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000105", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000105", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000105_A"})

func init() { i := A_arbace_pprint_eval1820000105_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000105_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000105_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000105_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000105_A]()) }

func A_arbace_pprint_eval1820000105_fn__1820000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000105_fn__1820000106_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_eval1820000105_fn__1820000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000105_fn__1820000106_A_New()}; return nil }

func A_arbace_pprint_eval1820000105_fn__1820000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000105_fn__1820000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000105_fn__1820000106_A_invoke, New: A_arbace_pprint_eval1820000105_fn__1820000106_A_new, Get: A_arbace_pprint_eval1820000105_fn__1820000106_A_get}

var A_arbace_pprint_eval1820000105_fn__1820000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000105$fn__1820000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_eval1820000105_A_class, Simple: "fn__1820000106", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000105_fn__1820000106_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000105_fn__1820000106_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000105_fn__1820000106_A_Init; i.Table = A_arbace_pprint_eval1820000105_fn__1820000106_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000105_fn__1820000106_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000105_fn__1820000106_A]()) }

func A_arbace_pprint_eval1820000109_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000109_A_New()}; return nil }

var A_arbace_pprint_eval1820000109_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000109_A_new}

var A_arbace_pprint_eval1820000109_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000109", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000109", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000109_A"})

func init() { i := A_arbace_pprint_eval1820000109_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000109_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000109_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000109_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000109_A]()) }

func A_arbace_pprint_eval1820000109_fn__1820000110_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000109_fn__1820000110_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_eval1820000109_fn__1820000110_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000109_fn__1820000110_A_New()}; return nil }

func A_arbace_pprint_eval1820000109_fn__1820000110_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000109_fn__1820000110_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000109_fn__1820000110_A_invoke, New: A_arbace_pprint_eval1820000109_fn__1820000110_A_new, Get: A_arbace_pprint_eval1820000109_fn__1820000110_A_get}

var A_arbace_pprint_eval1820000109_fn__1820000110_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000109$fn__1820000110", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_eval1820000109_A_class, Simple: "fn__1820000110", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000109_fn__1820000110_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000109_fn__1820000110_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000109_fn__1820000110_A_Init; i.Table = A_arbace_pprint_eval1820000109_fn__1820000110_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000109_fn__1820000110_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000109_fn__1820000110_A]()) }

func A_arbace_pprint_eval1820000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000133_A_New()}; return nil }

var A_arbace_pprint_eval1820000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000133_A_new}

var A_arbace_pprint_eval1820000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000133", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000133_A"})

func init() { i := A_arbace_pprint_eval1820000133_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000133_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000133_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000133_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000133_A]()) }

func A_arbace_pprint_eval1820000133_fn__1820000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000133_fn__1820000134_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_eval1820000133_fn__1820000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000133_fn__1820000134_A_New()}; return nil }

func A_arbace_pprint_eval1820000133_fn__1820000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000133_fn__1820000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000133_fn__1820000134_A_invoke, New: A_arbace_pprint_eval1820000133_fn__1820000134_A_new, Get: A_arbace_pprint_eval1820000133_fn__1820000134_A_get}

var A_arbace_pprint_eval1820000133_fn__1820000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000133$fn__1820000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_eval1820000133_A_class, Simple: "fn__1820000134", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000133_fn__1820000134_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000133_fn__1820000134_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000133_fn__1820000134_A_Init; i.Table = A_arbace_pprint_eval1820000133_fn__1820000134_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000133_fn__1820000134_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000133_fn__1820000134_A]()) }

func A_arbace_pprint_eval1820000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000137_A_New()}; return nil }

var A_arbace_pprint_eval1820000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000137_A_new}

var A_arbace_pprint_eval1820000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000137", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000137_A"})

func init() { i := A_arbace_pprint_eval1820000137_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000137_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000137_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000137_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000137_A]()) }

func A_arbace_pprint_eval1820000137_fn__1820000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000137_fn__1820000138_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_eval1820000137_fn__1820000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000137_fn__1820000138_A_New()}; return nil }

func A_arbace_pprint_eval1820000137_fn__1820000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000137_fn__1820000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000137_fn__1820000138_A_invoke, New: A_arbace_pprint_eval1820000137_fn__1820000138_A_new, Get: A_arbace_pprint_eval1820000137_fn__1820000138_A_get}

var A_arbace_pprint_eval1820000137_fn__1820000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000137$fn__1820000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_eval1820000137_A_class, Simple: "fn__1820000138", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000137_fn__1820000138_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000137_fn__1820000138_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000137_fn__1820000138_A_Init; i.Table = A_arbace_pprint_eval1820000137_fn__1820000138_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000137_fn__1820000138_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000137_fn__1820000138_A]()) }

func A_arbace_pprint_eval1820000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000141_A_New()}; return nil }

var A_arbace_pprint_eval1820000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_pprint_eval1820000141_A_new}

var A_arbace_pprint_eval1820000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_pprint_A_class, Simple: "eval1820000141", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000141_A"})

func init() { i := A_arbace_pprint_eval1820000141_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000141_A_InstanceOf; i.Table = A_arbace_pprint_eval1820000141_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000141_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000141_A]()) }

func A_arbace_pprint_eval1820000141_fn__1820000142_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_eval1820000141_fn__1820000142_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_eval1820000141_fn__1820000142_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_eval1820000141_fn__1820000142_A_New()}; return nil }

func A_arbace_pprint_eval1820000141_fn__1820000142_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class)}; return nil }

var A_arbace_pprint_eval1820000141_fn__1820000142_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_eval1820000141_fn__1820000142_A_invoke, New: A_arbace_pprint_eval1820000141_fn__1820000142_A_new, Get: A_arbace_pprint_eval1820000141_fn__1820000142_A_get}

var A_arbace_pprint_eval1820000141_fn__1820000142_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$eval1820000141$fn__1820000142", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_eval1820000141_A_class, Simple: "fn__1820000142", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_eval1820000141_fn__1820000142_A_class.Info(); i.IsInstance = A_arbace_pprint_eval1820000141_fn__1820000142_A_InstanceOf; i.Init = A_arbace_pprint_eval1820000141_fn__1820000142_A_Init; i.Table = A_arbace_pprint_eval1820000141_fn__1820000142_A_members; jrt.RegisterGoType(A_arbace_pprint_eval1820000141_fn__1820000142_A_class, reflect.TypeFor[A_arbace_pprint_eval1820000141_fn__1820000142_A]()) }

func A_arbace_pprint_execute_format_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_execute_format_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_pprint_execute_format_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_execute_format_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_execute_format_A_New()}; return nil }

func A_arbace_pprint_execute_format_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_execute_format_A_fn_class)}; return nil }

var A_arbace_pprint_execute_format_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_execute_format_A_invoke, New: A_arbace_pprint_execute_format_A_new, Get: A_arbace_pprint_execute_format_A_get}

var A_arbace_pprint_execute_format_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$execute_format", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "execute_format", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_execute_format_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_execute_format_A_class.Info(); i.IsInstance = A_arbace_pprint_execute_format_A_InstanceOf; i.Init = A_arbace_pprint_execute_format_A_Init; i.Table = A_arbace_pprint_execute_format_A_members; jrt.RegisterGoType(A_arbace_pprint_execute_format_A_class, reflect.TypeFor[A_arbace_pprint_execute_format_A]()) }

func A_arbace_pprint_execute_format_fn__1819000571_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_execute_format_fn__1819000571_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_execute_format_fn__1819000571_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_execute_format_fn__1819000571_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_execute_format_fn__1819000571_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_execute_format_fn__1819000571_A_fn_class)}; return nil }

var A_arbace_pprint_execute_format_fn__1819000571_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_execute_format_fn__1819000571_A_invoke, New: A_arbace_pprint_execute_format_fn__1819000571_A_new, Get: A_arbace_pprint_execute_format_fn__1819000571_A_get}

var A_arbace_pprint_execute_format_fn__1819000571_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$execute_format$fn__1819000571", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_execute_format_A_class, Simple: "fn__1819000571", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_execute_format_fn__1819000571_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_execute_format_fn__1819000571_A_class.Info(); i.IsInstance = A_arbace_pprint_execute_format_fn__1819000571_A_InstanceOf; i.Init = A_arbace_pprint_execute_format_fn__1819000571_A_Init; i.Table = A_arbace_pprint_execute_format_fn__1819000571_A_members; jrt.RegisterGoType(A_arbace_pprint_execute_format_fn__1819000571_A_class, reflect.TypeFor[A_arbace_pprint_execute_format_fn__1819000571_A]()) }

func A_arbace_pprint_execute_format_fn__1819000573_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_execute_format_fn__1819000573_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_execute_format_fn__1819000573_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_execute_format_fn__1819000573_A_New()}; return nil }

func A_arbace_pprint_execute_format_fn__1819000573_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_execute_format_fn__1819000573_A_fn_class)}; return nil }

var A_arbace_pprint_execute_format_fn__1819000573_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_execute_format_fn__1819000573_A_invoke, New: A_arbace_pprint_execute_format_fn__1819000573_A_new, Get: A_arbace_pprint_execute_format_fn__1819000573_A_get}

var A_arbace_pprint_execute_format_fn__1819000573_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$execute_format$fn__1819000573", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_execute_format_A_class, Simple: "fn__1819000573", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_execute_format_fn__1819000573_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_execute_format_fn__1819000573_A_class.Info(); i.IsInstance = A_arbace_pprint_execute_format_fn__1819000573_A_InstanceOf; i.Init = A_arbace_pprint_execute_format_fn__1819000573_A_Init; i.Table = A_arbace_pprint_execute_format_fn__1819000573_A_members; jrt.RegisterGoType(A_arbace_pprint_execute_format_fn__1819000573_A_class, reflect.TypeFor[A_arbace_pprint_execute_format_fn__1819000573_A]()) }

func A_arbace_pprint_execute_sub_format_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_execute_sub_format_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_execute_sub_format_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_execute_sub_format_A_New()}; return nil }

func A_arbace_pprint_execute_sub_format_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_execute_sub_format_A_fn_class)}; return nil }

var A_arbace_pprint_execute_sub_format_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_execute_sub_format_A_invoke, New: A_arbace_pprint_execute_sub_format_A_new, Get: A_arbace_pprint_execute_sub_format_A_get}

var A_arbace_pprint_execute_sub_format_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$execute_sub_format", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "execute_sub_format", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_execute_sub_format_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_execute_sub_format_A_class.Info(); i.IsInstance = A_arbace_pprint_execute_sub_format_A_InstanceOf; i.Init = A_arbace_pprint_execute_sub_format_A_Init; i.Table = A_arbace_pprint_execute_sub_format_A_members; jrt.RegisterGoType(A_arbace_pprint_execute_sub_format_A_class, reflect.TypeFor[A_arbace_pprint_execute_sub_format_A]()) }

func A_arbace_pprint_execute_sub_format_fn__1819000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_execute_sub_format_fn__1819000085_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_execute_sub_format_fn__1819000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_execute_sub_format_fn__1819000085_A_New_O(args[0])}; return nil }

func A_arbace_pprint_execute_sub_format_fn__1819000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_execute_sub_format_fn__1819000085_A_fn_class)}; return nil }

var A_arbace_pprint_execute_sub_format_fn__1819000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_execute_sub_format_fn__1819000085_A_invoke, New: A_arbace_pprint_execute_sub_format_fn__1819000085_A_new, Get: A_arbace_pprint_execute_sub_format_fn__1819000085_A_get}

var A_arbace_pprint_execute_sub_format_fn__1819000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$execute_sub_format$fn__1819000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_execute_sub_format_A_class, Simple: "fn__1819000085", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_execute_sub_format_fn__1819000085_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_execute_sub_format_fn__1819000085_A_class.Info(); i.IsInstance = A_arbace_pprint_execute_sub_format_fn__1819000085_A_InstanceOf; i.Init = A_arbace_pprint_execute_sub_format_fn__1819000085_A_Init; i.Table = A_arbace_pprint_execute_sub_format_fn__1819000085_A_members; jrt.RegisterGoType(A_arbace_pprint_execute_sub_format_fn__1819000085_A_class, reflect.TypeFor[A_arbace_pprint_execute_sub_format_fn__1819000085_A]()) }

func A_arbace_pprint_expand_fixed_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_expand_fixed_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_expand_fixed_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_expand_fixed_A_New()}; return nil }

func A_arbace_pprint_expand_fixed_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_expand_fixed_A_fn_class)}; return nil }

var A_arbace_pprint_expand_fixed_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_expand_fixed_A_invoke, New: A_arbace_pprint_expand_fixed_A_new, Get: A_arbace_pprint_expand_fixed_A_get}

var A_arbace_pprint_expand_fixed_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$expand_fixed", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "expand_fixed", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_expand_fixed_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_expand_fixed_A_class.Info(); i.IsInstance = A_arbace_pprint_expand_fixed_A_InstanceOf; i.Init = A_arbace_pprint_expand_fixed_A_Init; i.Table = A_arbace_pprint_expand_fixed_A_members; jrt.RegisterGoType(A_arbace_pprint_expand_fixed_A_class, reflect.TypeFor[A_arbace_pprint_expand_fixed_A]()) }

func A_arbace_pprint_exponential_float_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_exponential_float_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_exponential_float_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_exponential_float_A_New()}; return nil }

func A_arbace_pprint_exponential_float_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_exponential_float_A_fn_class)}; return nil }

var A_arbace_pprint_exponential_float_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_exponential_float_A_invoke, New: A_arbace_pprint_exponential_float_A_new, Get: A_arbace_pprint_exponential_float_A_get}

var A_arbace_pprint_exponential_float_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$exponential_float", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "exponential_float", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_exponential_float_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_exponential_float_A_class.Info(); i.IsInstance = A_arbace_pprint_exponential_float_A_InstanceOf; i.Init = A_arbace_pprint_exponential_float_A_Init; i.Table = A_arbace_pprint_exponential_float_A_members; jrt.RegisterGoType(A_arbace_pprint_exponential_float_A_class, reflect.TypeFor[A_arbace_pprint_exponential_float_A]()) }

func A_arbace_pprint_extract_flags_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_extract_flags_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_extract_flags_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_extract_flags_A_New()}; return nil }

func A_arbace_pprint_extract_flags_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_extract_flags_A_fn_class)}; return nil }

var A_arbace_pprint_extract_flags_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_extract_flags_A_invoke, New: A_arbace_pprint_extract_flags_A_new, Get: A_arbace_pprint_extract_flags_A_get}

var A_arbace_pprint_extract_flags_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$extract_flags", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "extract_flags", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_extract_flags_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_extract_flags_A_class.Info(); i.IsInstance = A_arbace_pprint_extract_flags_A_InstanceOf; i.Init = A_arbace_pprint_extract_flags_A_Init; i.Table = A_arbace_pprint_extract_flags_A_members; jrt.RegisterGoType(A_arbace_pprint_extract_flags_A_class, reflect.TypeFor[A_arbace_pprint_extract_flags_A]()) }

func A_arbace_pprint_extract_flags_fn__1819000480_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_extract_flags_fn__1819000480_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_extract_flags_fn__1819000480_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_extract_flags_fn__1819000480_A_New()}; return nil }

func A_arbace_pprint_extract_flags_fn__1819000480_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_extract_flags_fn__1819000480_A_fn_class)}; return nil }

var A_arbace_pprint_extract_flags_fn__1819000480_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_extract_flags_fn__1819000480_A_invoke, New: A_arbace_pprint_extract_flags_fn__1819000480_A_new, Get: A_arbace_pprint_extract_flags_fn__1819000480_A_get}

var A_arbace_pprint_extract_flags_fn__1819000480_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$extract_flags$fn__1819000480", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_extract_flags_A_class, Simple: "fn__1819000480", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_extract_flags_fn__1819000480_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_extract_flags_fn__1819000480_A_class.Info(); i.IsInstance = A_arbace_pprint_extract_flags_fn__1819000480_A_InstanceOf; i.Init = A_arbace_pprint_extract_flags_fn__1819000480_A_Init; i.Table = A_arbace_pprint_extract_flags_fn__1819000480_A_members; jrt.RegisterGoType(A_arbace_pprint_extract_flags_fn__1819000480_A_class, reflect.TypeFor[A_arbace_pprint_extract_flags_fn__1819000480_A]()) }

func A_arbace_pprint_extract_param_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_extract_param_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_extract_param_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_extract_param_A_New()}; return nil }

func A_arbace_pprint_extract_param_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_extract_param_A_fn_class)}; return nil }

var A_arbace_pprint_extract_param_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_extract_param_A_invoke, New: A_arbace_pprint_extract_param_A_new, Get: A_arbace_pprint_extract_param_A_get}

var A_arbace_pprint_extract_param_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$extract_param", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "extract_param", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_extract_param_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_extract_param_A_class.Info(); i.IsInstance = A_arbace_pprint_extract_param_A_InstanceOf; i.Init = A_arbace_pprint_extract_param_A_Init; i.Table = A_arbace_pprint_extract_param_A_members; jrt.RegisterGoType(A_arbace_pprint_extract_param_A_class, reflect.TypeFor[A_arbace_pprint_extract_param_A]()) }

func A_arbace_pprint_extract_params_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_extract_params_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_extract_params_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_extract_params_A_New()}; return nil }

func A_arbace_pprint_extract_params_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_extract_params_A_fn_class)}; return nil }

var A_arbace_pprint_extract_params_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_extract_params_A_invoke, New: A_arbace_pprint_extract_params_A_new, Get: A_arbace_pprint_extract_params_A_get}

var A_arbace_pprint_extract_params_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$extract_params", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "extract_params", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_extract_params_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_extract_params_A_class.Info(); i.IsInstance = A_arbace_pprint_extract_params_A_InstanceOf; i.Init = A_arbace_pprint_extract_params_A_Init; i.Table = A_arbace_pprint_extract_params_A_members; jrt.RegisterGoType(A_arbace_pprint_extract_params_A_class, reflect.TypeFor[A_arbace_pprint_extract_params_A]()) }

func A_arbace_pprint_fixed_float_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fixed_float_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fixed_float_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fixed_float_A_New()}; return nil }

func A_arbace_pprint_fixed_float_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fixed_float_A_fn_class)}; return nil }

var A_arbace_pprint_fixed_float_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fixed_float_A_invoke, New: A_arbace_pprint_fixed_float_A_new, Get: A_arbace_pprint_fixed_float_A_get}

var A_arbace_pprint_fixed_float_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fixed_float", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "fixed_float", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fixed_float_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fixed_float_A_class.Info(); i.IsInstance = A_arbace_pprint_fixed_float_A_InstanceOf; i.Init = A_arbace_pprint_fixed_float_A_Init; i.Table = A_arbace_pprint_fixed_float_A_members; jrt.RegisterGoType(A_arbace_pprint_fixed_float_A_class, reflect.TypeFor[A_arbace_pprint_fixed_float_A]()) }

func A_arbace_pprint_float_parts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_float_parts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_float_parts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_float_parts_A_New()}; return nil }

func A_arbace_pprint_float_parts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_float_parts_A_fn_class)}; return nil }

var A_arbace_pprint_float_parts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_float_parts_A_invoke, New: A_arbace_pprint_float_parts_A_new, Get: A_arbace_pprint_float_parts_A_get}

var A_arbace_pprint_float_parts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$float_parts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "float_parts", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_float_parts_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_float_parts_A_class.Info(); i.IsInstance = A_arbace_pprint_float_parts_A_InstanceOf; i.Init = A_arbace_pprint_float_parts_A_Init; i.Table = A_arbace_pprint_float_parts_A_members; jrt.RegisterGoType(A_arbace_pprint_float_parts_A_class, reflect.TypeFor[A_arbace_pprint_float_parts_A]()) }

func A_arbace_pprint_float_parts_base_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_float_parts_base_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_float_parts_base_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_float_parts_base_A_New()}; return nil }

func A_arbace_pprint_float_parts_base_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_float_parts_base_A_fn_class)}; return nil }

var A_arbace_pprint_float_parts_base_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_float_parts_base_A_invoke, New: A_arbace_pprint_float_parts_base_A_new, Get: A_arbace_pprint_float_parts_base_A_get}

var A_arbace_pprint_float_parts_base_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$float_parts_base", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "float_parts_base", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_float_parts_base_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_float_parts_base_A_class.Info(); i.IsInstance = A_arbace_pprint_float_parts_base_A_InstanceOf; i.Init = A_arbace_pprint_float_parts_base_A_Init; i.Table = A_arbace_pprint_float_parts_base_A_members; jrt.RegisterGoType(A_arbace_pprint_float_parts_base_A_class, reflect.TypeFor[A_arbace_pprint_float_parts_base_A]()) }

func A_arbace_pprint_fn__1819000328_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000328_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000328_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000328_A_New()}; return nil }

func A_arbace_pprint_fn__1819000328_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000328_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000328_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000328_A_invoke, New: A_arbace_pprint_fn__1819000328_A_new, Get: A_arbace_pprint_fn__1819000328_A_get}

var A_arbace_pprint_fn__1819000328_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000328", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000328", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000328_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000328_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000328_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000328_A_Init; i.Table = A_arbace_pprint_fn__1819000328_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000328_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000328_A]()) }

func A_arbace_pprint_fn__1819000328_fn__1819000329_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000328_fn__1819000329_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000328_fn__1819000329_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000328_fn__1819000329_A_New()}; return nil }

func A_arbace_pprint_fn__1819000328_fn__1819000329_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000328_fn__1819000329_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000328_fn__1819000329_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000328_fn__1819000329_A_invoke, New: A_arbace_pprint_fn__1819000328_fn__1819000329_A_new, Get: A_arbace_pprint_fn__1819000328_fn__1819000329_A_get}

var A_arbace_pprint_fn__1819000328_fn__1819000329_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000328$fn__1819000329", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000328_A_class, Simple: "fn__1819000329", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000328_fn__1819000329_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000328_fn__1819000329_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000328_fn__1819000329_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000328_fn__1819000329_A_Init; i.Table = A_arbace_pprint_fn__1819000328_fn__1819000329_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000328_fn__1819000329_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000328_fn__1819000329_A]()) }

func A_arbace_pprint_fn__1819000332_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000332_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000332_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000332_A_New()}; return nil }

func A_arbace_pprint_fn__1819000332_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000332_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000332_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000332_A_invoke, New: A_arbace_pprint_fn__1819000332_A_new, Get: A_arbace_pprint_fn__1819000332_A_get}

var A_arbace_pprint_fn__1819000332_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000332", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000332", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000332_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000332_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000332_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000332_A_Init; i.Table = A_arbace_pprint_fn__1819000332_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000332_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000332_A]()) }

func A_arbace_pprint_fn__1819000332_fn__1819000333_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000332_fn__1819000333_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000332_fn__1819000333_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000332_fn__1819000333_A_New()}; return nil }

func A_arbace_pprint_fn__1819000332_fn__1819000333_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000332_fn__1819000333_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000332_fn__1819000333_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000332_fn__1819000333_A_invoke, New: A_arbace_pprint_fn__1819000332_fn__1819000333_A_new, Get: A_arbace_pprint_fn__1819000332_fn__1819000333_A_get}

var A_arbace_pprint_fn__1819000332_fn__1819000333_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000332$fn__1819000333", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000332_A_class, Simple: "fn__1819000333", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000332_fn__1819000333_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000332_fn__1819000333_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000332_fn__1819000333_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000332_fn__1819000333_A_Init; i.Table = A_arbace_pprint_fn__1819000332_fn__1819000333_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000332_fn__1819000333_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000332_fn__1819000333_A]()) }

func A_arbace_pprint_fn__1819000336_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000336_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000336_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000336_A_New()}; return nil }

func A_arbace_pprint_fn__1819000336_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000336_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000336_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000336_A_invoke, New: A_arbace_pprint_fn__1819000336_A_new, Get: A_arbace_pprint_fn__1819000336_A_get}

var A_arbace_pprint_fn__1819000336_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000336", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000336", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000336_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000336_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000336_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000336_A_Init; i.Table = A_arbace_pprint_fn__1819000336_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000336_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000336_A]()) }

func A_arbace_pprint_fn__1819000336_fn__1819000337_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000336_fn__1819000337_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000336_fn__1819000337_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000336_fn__1819000337_A_New()}; return nil }

func A_arbace_pprint_fn__1819000336_fn__1819000337_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000336_fn__1819000337_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000336_fn__1819000337_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000336_fn__1819000337_A_invoke, New: A_arbace_pprint_fn__1819000336_fn__1819000337_A_new, Get: A_arbace_pprint_fn__1819000336_fn__1819000337_A_get}

var A_arbace_pprint_fn__1819000336_fn__1819000337_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000336$fn__1819000337", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000336_A_class, Simple: "fn__1819000337", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000336_fn__1819000337_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000336_fn__1819000337_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000336_fn__1819000337_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000336_fn__1819000337_A_Init; i.Table = A_arbace_pprint_fn__1819000336_fn__1819000337_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000336_fn__1819000337_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000336_fn__1819000337_A]()) }

func A_arbace_pprint_fn__1819000340_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000340_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000340_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000340_A_New()}; return nil }

func A_arbace_pprint_fn__1819000340_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000340_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000340_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000340_A_invoke, New: A_arbace_pprint_fn__1819000340_A_new, Get: A_arbace_pprint_fn__1819000340_A_get}

var A_arbace_pprint_fn__1819000340_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000340", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000340", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000340_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000340_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000340_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000340_A_Init; i.Table = A_arbace_pprint_fn__1819000340_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000340_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000340_A]()) }

func A_arbace_pprint_fn__1819000340_fn__1819000341_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000340_fn__1819000341_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000340_fn__1819000341_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000340_fn__1819000341_A_New()}; return nil }

func A_arbace_pprint_fn__1819000340_fn__1819000341_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000340_fn__1819000341_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000340_fn__1819000341_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000340_fn__1819000341_A_invoke, New: A_arbace_pprint_fn__1819000340_fn__1819000341_A_new, Get: A_arbace_pprint_fn__1819000340_fn__1819000341_A_get}

var A_arbace_pprint_fn__1819000340_fn__1819000341_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000340$fn__1819000341", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000340_A_class, Simple: "fn__1819000341", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000340_fn__1819000341_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000340_fn__1819000341_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000340_fn__1819000341_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000340_fn__1819000341_A_Init; i.Table = A_arbace_pprint_fn__1819000340_fn__1819000341_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000340_fn__1819000341_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000340_fn__1819000341_A]()) }

func A_arbace_pprint_fn__1819000344_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000344_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000344_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000344_A_New()}; return nil }

func A_arbace_pprint_fn__1819000344_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000344_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000344_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000344_A_invoke, New: A_arbace_pprint_fn__1819000344_A_new, Get: A_arbace_pprint_fn__1819000344_A_get}

var A_arbace_pprint_fn__1819000344_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000344", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000344", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000344_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000344_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000344_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000344_A_Init; i.Table = A_arbace_pprint_fn__1819000344_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000344_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000344_A]()) }

func A_arbace_pprint_fn__1819000344_fn__1819000345_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000344_fn__1819000345_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000344_fn__1819000345_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000344_fn__1819000345_A_New()}; return nil }

func A_arbace_pprint_fn__1819000344_fn__1819000345_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000344_fn__1819000345_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000344_fn__1819000345_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000344_fn__1819000345_A_invoke, New: A_arbace_pprint_fn__1819000344_fn__1819000345_A_new, Get: A_arbace_pprint_fn__1819000344_fn__1819000345_A_get}

var A_arbace_pprint_fn__1819000344_fn__1819000345_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000344$fn__1819000345", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000344_A_class, Simple: "fn__1819000345", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000344_fn__1819000345_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000344_fn__1819000345_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000344_fn__1819000345_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000344_fn__1819000345_A_Init; i.Table = A_arbace_pprint_fn__1819000344_fn__1819000345_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000344_fn__1819000345_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000344_fn__1819000345_A]()) }

func A_arbace_pprint_fn__1819000348_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000348_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000348_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000348_A_New()}; return nil }

func A_arbace_pprint_fn__1819000348_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000348_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000348_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000348_A_invoke, New: A_arbace_pprint_fn__1819000348_A_new, Get: A_arbace_pprint_fn__1819000348_A_get}

var A_arbace_pprint_fn__1819000348_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000348", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000348", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000348_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000348_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000348_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000348_A_Init; i.Table = A_arbace_pprint_fn__1819000348_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000348_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000348_A]()) }

func A_arbace_pprint_fn__1819000348_fn__1819000349_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000348_fn__1819000349_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000348_fn__1819000349_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000348_fn__1819000349_A_New()}; return nil }

func A_arbace_pprint_fn__1819000348_fn__1819000349_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000348_fn__1819000349_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000348_fn__1819000349_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000348_fn__1819000349_A_invoke, New: A_arbace_pprint_fn__1819000348_fn__1819000349_A_new, Get: A_arbace_pprint_fn__1819000348_fn__1819000349_A_get}

var A_arbace_pprint_fn__1819000348_fn__1819000349_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000348$fn__1819000349", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000348_A_class, Simple: "fn__1819000349", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000348_fn__1819000349_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000348_fn__1819000349_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000348_fn__1819000349_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000348_fn__1819000349_A_Init; i.Table = A_arbace_pprint_fn__1819000348_fn__1819000349_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000348_fn__1819000349_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000348_fn__1819000349_A]()) }

func A_arbace_pprint_fn__1819000352_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000352_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000352_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000352_A_New()}; return nil }

func A_arbace_pprint_fn__1819000352_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000352_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000352_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000352_A_invoke, New: A_arbace_pprint_fn__1819000352_A_new, Get: A_arbace_pprint_fn__1819000352_A_get}

var A_arbace_pprint_fn__1819000352_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000352", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000352", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000352_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000352_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000352_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000352_A_Init; i.Table = A_arbace_pprint_fn__1819000352_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000352_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000352_A]()) }

func A_arbace_pprint_fn__1819000352_fn__1819000353_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000352_fn__1819000353_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000353_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000352_fn__1819000353_A_New()}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000353_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000352_fn__1819000353_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000352_fn__1819000353_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000352_fn__1819000353_A_invoke, New: A_arbace_pprint_fn__1819000352_fn__1819000353_A_new, Get: A_arbace_pprint_fn__1819000352_fn__1819000353_A_get}

var A_arbace_pprint_fn__1819000352_fn__1819000353_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000352$fn__1819000353", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000352_A_class, Simple: "fn__1819000353", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000352_fn__1819000353_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000352_fn__1819000353_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000352_fn__1819000353_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000352_fn__1819000353_A_Init; i.Table = A_arbace_pprint_fn__1819000352_fn__1819000353_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000352_fn__1819000353_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000352_fn__1819000353_A]()) }

func A_arbace_pprint_fn__1819000352_fn__1819000355_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000352_fn__1819000355_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000355_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000352_fn__1819000355_A_New()}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000355_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000352_fn__1819000355_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000352_fn__1819000355_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000352_fn__1819000355_A_invoke, New: A_arbace_pprint_fn__1819000352_fn__1819000355_A_new, Get: A_arbace_pprint_fn__1819000352_fn__1819000355_A_get}

var A_arbace_pprint_fn__1819000352_fn__1819000355_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000352$fn__1819000355", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000352_A_class, Simple: "fn__1819000355", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000352_fn__1819000355_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000352_fn__1819000355_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000352_fn__1819000355_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000352_fn__1819000355_A_Init; i.Table = A_arbace_pprint_fn__1819000352_fn__1819000355_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000352_fn__1819000355_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000352_fn__1819000355_A]()) }

func A_arbace_pprint_fn__1819000352_fn__1819000357_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000352_fn__1819000357_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000357_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000352_fn__1819000357_A_New()}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000357_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000352_fn__1819000357_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000352_fn__1819000357_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000352_fn__1819000357_A_invoke, New: A_arbace_pprint_fn__1819000352_fn__1819000357_A_new, Get: A_arbace_pprint_fn__1819000352_fn__1819000357_A_get}

var A_arbace_pprint_fn__1819000352_fn__1819000357_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000352$fn__1819000357", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000352_A_class, Simple: "fn__1819000357", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000352_fn__1819000357_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000352_fn__1819000357_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000352_fn__1819000357_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000352_fn__1819000357_A_Init; i.Table = A_arbace_pprint_fn__1819000352_fn__1819000357_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000352_fn__1819000357_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000352_fn__1819000357_A]()) }

func A_arbace_pprint_fn__1819000352_fn__1819000359_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000352_fn__1819000359_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000359_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000352_fn__1819000359_A_New()}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000359_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000352_fn__1819000359_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000352_fn__1819000359_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000352_fn__1819000359_A_invoke, New: A_arbace_pprint_fn__1819000352_fn__1819000359_A_new, Get: A_arbace_pprint_fn__1819000352_fn__1819000359_A_get}

var A_arbace_pprint_fn__1819000352_fn__1819000359_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000352$fn__1819000359", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000352_A_class, Simple: "fn__1819000359", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000352_fn__1819000359_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000352_fn__1819000359_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000352_fn__1819000359_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000352_fn__1819000359_A_Init; i.Table = A_arbace_pprint_fn__1819000352_fn__1819000359_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000352_fn__1819000359_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000352_fn__1819000359_A]()) }

func A_arbace_pprint_fn__1819000352_fn__1819000361_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000352_fn__1819000361_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000361_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000352_fn__1819000361_A_New()}; return nil }

func A_arbace_pprint_fn__1819000352_fn__1819000361_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000352_fn__1819000361_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000352_fn__1819000361_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000352_fn__1819000361_A_invoke, New: A_arbace_pprint_fn__1819000352_fn__1819000361_A_new, Get: A_arbace_pprint_fn__1819000352_fn__1819000361_A_get}

var A_arbace_pprint_fn__1819000352_fn__1819000361_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000352$fn__1819000361", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000352_A_class, Simple: "fn__1819000361", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000352_fn__1819000361_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000352_fn__1819000361_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000352_fn__1819000361_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000352_fn__1819000361_A_Init; i.Table = A_arbace_pprint_fn__1819000352_fn__1819000361_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000352_fn__1819000361_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000352_fn__1819000361_A]()) }

func A_arbace_pprint_fn__1819000364_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000364_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000364_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000364_A_New()}; return nil }

func A_arbace_pprint_fn__1819000364_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000364_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000364_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000364_A_invoke, New: A_arbace_pprint_fn__1819000364_A_new, Get: A_arbace_pprint_fn__1819000364_A_get}

var A_arbace_pprint_fn__1819000364_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000364", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000364", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000364_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000364_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000364_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000364_A_Init; i.Table = A_arbace_pprint_fn__1819000364_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000364_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000364_A]()) }

func A_arbace_pprint_fn__1819000364_fn__1819000365_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000364_fn__1819000365_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000364_fn__1819000365_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000364_fn__1819000365_A_New()}; return nil }

func A_arbace_pprint_fn__1819000364_fn__1819000365_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000364_fn__1819000365_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000364_fn__1819000365_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000364_fn__1819000365_A_invoke, New: A_arbace_pprint_fn__1819000364_fn__1819000365_A_new, Get: A_arbace_pprint_fn__1819000364_fn__1819000365_A_get}

var A_arbace_pprint_fn__1819000364_fn__1819000365_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000364$fn__1819000365", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000364_A_class, Simple: "fn__1819000365", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000364_fn__1819000365_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000364_fn__1819000365_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000364_fn__1819000365_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000364_fn__1819000365_A_Init; i.Table = A_arbace_pprint_fn__1819000364_fn__1819000365_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000364_fn__1819000365_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000364_fn__1819000365_A]()) }

func A_arbace_pprint_fn__1819000371_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000371_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000371_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000371_A_New()}; return nil }

func A_arbace_pprint_fn__1819000371_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000371_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000371_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000371_A_invoke, New: A_arbace_pprint_fn__1819000371_A_new, Get: A_arbace_pprint_fn__1819000371_A_get}

var A_arbace_pprint_fn__1819000371_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000371", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000371", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000371_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000371_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000371_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000371_A_Init; i.Table = A_arbace_pprint_fn__1819000371_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000371_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000371_A]()) }

func A_arbace_pprint_fn__1819000373_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000373_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000373_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000373_A_New()}; return nil }

func A_arbace_pprint_fn__1819000373_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000373_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000373_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000373_A_invoke, New: A_arbace_pprint_fn__1819000373_A_new, Get: A_arbace_pprint_fn__1819000373_A_get}

var A_arbace_pprint_fn__1819000373_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000373", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000373", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000373_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000373_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000373_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000373_A_Init; i.Table = A_arbace_pprint_fn__1819000373_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000373_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000373_A]()) }

func A_arbace_pprint_fn__1819000375_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000375_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000375_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000375_A_New()}; return nil }

func A_arbace_pprint_fn__1819000375_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000375_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000375_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000375_A_invoke, New: A_arbace_pprint_fn__1819000375_A_new, Get: A_arbace_pprint_fn__1819000375_A_get}

var A_arbace_pprint_fn__1819000375_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000375", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000375", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000375_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000375_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000375_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000375_A_Init; i.Table = A_arbace_pprint_fn__1819000375_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000375_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000375_A]()) }

func A_arbace_pprint_fn__1819000377_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000377_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000377_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000377_A_New()}; return nil }

func A_arbace_pprint_fn__1819000377_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000377_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000377_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000377_A_invoke, New: A_arbace_pprint_fn__1819000377_A_new, Get: A_arbace_pprint_fn__1819000377_A_get}

var A_arbace_pprint_fn__1819000377_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000377", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000377", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000377_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000377_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000377_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000377_A_Init; i.Table = A_arbace_pprint_fn__1819000377_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000377_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000377_A]()) }

func A_arbace_pprint_fn__1819000379_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000379_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000379_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000379_A_New()}; return nil }

func A_arbace_pprint_fn__1819000379_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000379_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000379_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000379_A_invoke, New: A_arbace_pprint_fn__1819000379_A_new, Get: A_arbace_pprint_fn__1819000379_A_get}

var A_arbace_pprint_fn__1819000379_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000379", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000379", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000379_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000379_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000379_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000379_A_Init; i.Table = A_arbace_pprint_fn__1819000379_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000379_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000379_A]()) }

func A_arbace_pprint_fn__1819000381_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000381_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000381_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000381_A_New()}; return nil }

func A_arbace_pprint_fn__1819000381_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000381_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000381_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000381_A_invoke, New: A_arbace_pprint_fn__1819000381_A_new, Get: A_arbace_pprint_fn__1819000381_A_get}

var A_arbace_pprint_fn__1819000381_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000381", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000381", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000381_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000381_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000381_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000381_A_Init; i.Table = A_arbace_pprint_fn__1819000381_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000381_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000381_A]()) }

func A_arbace_pprint_fn__1819000381_fn__1819000382_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000381_fn__1819000382_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000381_fn__1819000382_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000381_fn__1819000382_A_New()}; return nil }

func A_arbace_pprint_fn__1819000381_fn__1819000382_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000381_fn__1819000382_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000381_fn__1819000382_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000381_fn__1819000382_A_invoke, New: A_arbace_pprint_fn__1819000381_fn__1819000382_A_new, Get: A_arbace_pprint_fn__1819000381_fn__1819000382_A_get}

var A_arbace_pprint_fn__1819000381_fn__1819000382_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000381$fn__1819000382", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000381_A_class, Simple: "fn__1819000382", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000381_fn__1819000382_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000381_fn__1819000382_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000381_fn__1819000382_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000381_fn__1819000382_A_Init; i.Table = A_arbace_pprint_fn__1819000381_fn__1819000382_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000381_fn__1819000382_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000381_fn__1819000382_A]()) }

func A_arbace_pprint_fn__1819000385_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000385_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000385_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000385_A_New()}; return nil }

func A_arbace_pprint_fn__1819000385_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000385_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000385_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000385_A_invoke, New: A_arbace_pprint_fn__1819000385_A_new, Get: A_arbace_pprint_fn__1819000385_A_get}

var A_arbace_pprint_fn__1819000385_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000385", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000385", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000385_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000385_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000385_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000385_A_Init; i.Table = A_arbace_pprint_fn__1819000385_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000385_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000385_A]()) }

func A_arbace_pprint_fn__1819000385_fn__1819000386_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000385_fn__1819000386_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000385_fn__1819000386_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000385_fn__1819000386_A_New()}; return nil }

func A_arbace_pprint_fn__1819000385_fn__1819000386_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000385_fn__1819000386_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000385_fn__1819000386_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000385_fn__1819000386_A_invoke, New: A_arbace_pprint_fn__1819000385_fn__1819000386_A_new, Get: A_arbace_pprint_fn__1819000385_fn__1819000386_A_get}

var A_arbace_pprint_fn__1819000385_fn__1819000386_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000385$fn__1819000386", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000385_A_class, Simple: "fn__1819000386", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000385_fn__1819000386_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000385_fn__1819000386_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000385_fn__1819000386_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000385_fn__1819000386_A_Init; i.Table = A_arbace_pprint_fn__1819000385_fn__1819000386_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000385_fn__1819000386_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000385_fn__1819000386_A]()) }

func A_arbace_pprint_fn__1819000389_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000389_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000389_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000389_A_New()}; return nil }

func A_arbace_pprint_fn__1819000389_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000389_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000389_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000389_A_invoke, New: A_arbace_pprint_fn__1819000389_A_new, Get: A_arbace_pprint_fn__1819000389_A_get}

var A_arbace_pprint_fn__1819000389_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000389", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000389", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000389_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000389_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000389_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000389_A_Init; i.Table = A_arbace_pprint_fn__1819000389_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000389_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000389_A]()) }

func A_arbace_pprint_fn__1819000389_fn__1819000390_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000389_fn__1819000390_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000389_fn__1819000390_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000389_fn__1819000390_A_New()}; return nil }

func A_arbace_pprint_fn__1819000389_fn__1819000390_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000389_fn__1819000390_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000389_fn__1819000390_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000389_fn__1819000390_A_invoke, New: A_arbace_pprint_fn__1819000389_fn__1819000390_A_new, Get: A_arbace_pprint_fn__1819000389_fn__1819000390_A_get}

var A_arbace_pprint_fn__1819000389_fn__1819000390_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000389$fn__1819000390", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000389_A_class, Simple: "fn__1819000390", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000389_fn__1819000390_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000389_fn__1819000390_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000389_fn__1819000390_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000389_fn__1819000390_A_Init; i.Table = A_arbace_pprint_fn__1819000389_fn__1819000390_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000389_fn__1819000390_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000389_fn__1819000390_A]()) }

func A_arbace_pprint_fn__1819000393_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000393_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000393_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000393_A_New()}; return nil }

func A_arbace_pprint_fn__1819000393_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000393_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000393_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000393_A_invoke, New: A_arbace_pprint_fn__1819000393_A_new, Get: A_arbace_pprint_fn__1819000393_A_get}

var A_arbace_pprint_fn__1819000393_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000393", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000393", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000393_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000393_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000393_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000393_A_Init; i.Table = A_arbace_pprint_fn__1819000393_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000393_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000393_A]()) }

func A_arbace_pprint_fn__1819000393_fn__1819000394_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000393_fn__1819000394_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000393_fn__1819000394_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000393_fn__1819000394_A_New()}; return nil }

func A_arbace_pprint_fn__1819000393_fn__1819000394_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000393_fn__1819000394_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000393_fn__1819000394_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000393_fn__1819000394_A_invoke, New: A_arbace_pprint_fn__1819000393_fn__1819000394_A_new, Get: A_arbace_pprint_fn__1819000393_fn__1819000394_A_get}

var A_arbace_pprint_fn__1819000393_fn__1819000394_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000393$fn__1819000394", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000393_A_class, Simple: "fn__1819000394", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000393_fn__1819000394_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000393_fn__1819000394_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000393_fn__1819000394_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000393_fn__1819000394_A_Init; i.Table = A_arbace_pprint_fn__1819000393_fn__1819000394_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000393_fn__1819000394_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000393_fn__1819000394_A]()) }

func A_arbace_pprint_fn__1819000397_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000397_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000397_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000397_A_New()}; return nil }

func A_arbace_pprint_fn__1819000397_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000397_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000397_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000397_A_invoke, New: A_arbace_pprint_fn__1819000397_A_new, Get: A_arbace_pprint_fn__1819000397_A_get}

var A_arbace_pprint_fn__1819000397_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000397", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000397", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000397_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000397_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000397_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000397_A_Init; i.Table = A_arbace_pprint_fn__1819000397_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000397_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000397_A]()) }

func A_arbace_pprint_fn__1819000397_fn__1819000398_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000397_fn__1819000398_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000397_fn__1819000398_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000397_fn__1819000398_A_New()}; return nil }

func A_arbace_pprint_fn__1819000397_fn__1819000398_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000397_fn__1819000398_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000397_fn__1819000398_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000397_fn__1819000398_A_invoke, New: A_arbace_pprint_fn__1819000397_fn__1819000398_A_new, Get: A_arbace_pprint_fn__1819000397_fn__1819000398_A_get}

var A_arbace_pprint_fn__1819000397_fn__1819000398_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000397$fn__1819000398", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000397_A_class, Simple: "fn__1819000398", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000397_fn__1819000398_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000397_fn__1819000398_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000397_fn__1819000398_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000397_fn__1819000398_A_Init; i.Table = A_arbace_pprint_fn__1819000397_fn__1819000398_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000397_fn__1819000398_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000397_fn__1819000398_A]()) }

func A_arbace_pprint_fn__1819000401_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000401_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000401_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000401_A_New()}; return nil }

func A_arbace_pprint_fn__1819000401_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000401_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000401_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000401_A_invoke, New: A_arbace_pprint_fn__1819000401_A_new, Get: A_arbace_pprint_fn__1819000401_A_get}

var A_arbace_pprint_fn__1819000401_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000401", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000401", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000401_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000401_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000401_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000401_A_Init; i.Table = A_arbace_pprint_fn__1819000401_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000401_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000401_A]()) }

func A_arbace_pprint_fn__1819000401_fn__1819000402_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000401_fn__1819000402_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000401_fn__1819000402_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000401_fn__1819000402_A_New()}; return nil }

func A_arbace_pprint_fn__1819000401_fn__1819000402_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000401_fn__1819000402_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000401_fn__1819000402_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000401_fn__1819000402_A_invoke, New: A_arbace_pprint_fn__1819000401_fn__1819000402_A_new, Get: A_arbace_pprint_fn__1819000401_fn__1819000402_A_get}

var A_arbace_pprint_fn__1819000401_fn__1819000402_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000401$fn__1819000402", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000401_A_class, Simple: "fn__1819000402", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000401_fn__1819000402_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000401_fn__1819000402_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000401_fn__1819000402_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000401_fn__1819000402_A_Init; i.Table = A_arbace_pprint_fn__1819000401_fn__1819000402_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000401_fn__1819000402_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000401_fn__1819000402_A]()) }

func A_arbace_pprint_fn__1819000401_fn__1819000404_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000401_fn__1819000404_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000401_fn__1819000404_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000401_fn__1819000404_A_New()}; return nil }

func A_arbace_pprint_fn__1819000401_fn__1819000404_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000401_fn__1819000404_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000401_fn__1819000404_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000401_fn__1819000404_A_invoke, New: A_arbace_pprint_fn__1819000401_fn__1819000404_A_new, Get: A_arbace_pprint_fn__1819000401_fn__1819000404_A_get}

var A_arbace_pprint_fn__1819000401_fn__1819000404_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000401$fn__1819000404", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000401_A_class, Simple: "fn__1819000404", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000401_fn__1819000404_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000401_fn__1819000404_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000401_fn__1819000404_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000401_fn__1819000404_A_Init; i.Table = A_arbace_pprint_fn__1819000401_fn__1819000404_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000401_fn__1819000404_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000401_fn__1819000404_A]()) }

func A_arbace_pprint_fn__1819000407_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000407_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000407_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000407_A_New()}; return nil }

func A_arbace_pprint_fn__1819000407_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000407_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000407_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000407_A_invoke, New: A_arbace_pprint_fn__1819000407_A_new, Get: A_arbace_pprint_fn__1819000407_A_get}

var A_arbace_pprint_fn__1819000407_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000407", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000407", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000407_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000407_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000407_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000407_A_Init; i.Table = A_arbace_pprint_fn__1819000407_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000407_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000407_A]()) }

func A_arbace_pprint_fn__1819000407_fn__1819000408_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000407_fn__1819000408_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000407_fn__1819000408_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000407_fn__1819000408_A_New()}; return nil }

func A_arbace_pprint_fn__1819000407_fn__1819000408_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000407_fn__1819000408_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000407_fn__1819000408_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000407_fn__1819000408_A_invoke, New: A_arbace_pprint_fn__1819000407_fn__1819000408_A_new, Get: A_arbace_pprint_fn__1819000407_fn__1819000408_A_get}

var A_arbace_pprint_fn__1819000407_fn__1819000408_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000407$fn__1819000408", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000407_A_class, Simple: "fn__1819000408", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000407_fn__1819000408_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000407_fn__1819000408_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000407_fn__1819000408_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000407_fn__1819000408_A_Init; i.Table = A_arbace_pprint_fn__1819000407_fn__1819000408_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000407_fn__1819000408_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000407_fn__1819000408_A]()) }

func A_arbace_pprint_fn__1819000407_fn__1819000410_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000407_fn__1819000410_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000407_fn__1819000410_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000407_fn__1819000410_A_New()}; return nil }

func A_arbace_pprint_fn__1819000407_fn__1819000410_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000407_fn__1819000410_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000407_fn__1819000410_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000407_fn__1819000410_A_invoke, New: A_arbace_pprint_fn__1819000407_fn__1819000410_A_new, Get: A_arbace_pprint_fn__1819000407_fn__1819000410_A_get}

var A_arbace_pprint_fn__1819000407_fn__1819000410_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000407$fn__1819000410", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000407_A_class, Simple: "fn__1819000410", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000407_fn__1819000410_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000407_fn__1819000410_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000407_fn__1819000410_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000407_fn__1819000410_A_Init; i.Table = A_arbace_pprint_fn__1819000407_fn__1819000410_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000407_fn__1819000410_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000407_fn__1819000410_A]()) }

func A_arbace_pprint_fn__1819000413_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000413_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000413_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000413_A_New()}; return nil }

func A_arbace_pprint_fn__1819000413_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000413_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000413_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000413_A_invoke, New: A_arbace_pprint_fn__1819000413_A_new, Get: A_arbace_pprint_fn__1819000413_A_get}

var A_arbace_pprint_fn__1819000413_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000413", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000413", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000413_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000413_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000413_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000413_A_Init; i.Table = A_arbace_pprint_fn__1819000413_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000413_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000413_A]()) }

func A_arbace_pprint_fn__1819000413_fn__1819000414_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000413_fn__1819000414_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000413_fn__1819000414_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000413_fn__1819000414_A_New()}; return nil }

func A_arbace_pprint_fn__1819000413_fn__1819000414_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000413_fn__1819000414_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000413_fn__1819000414_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000413_fn__1819000414_A_invoke, New: A_arbace_pprint_fn__1819000413_fn__1819000414_A_new, Get: A_arbace_pprint_fn__1819000413_fn__1819000414_A_get}

var A_arbace_pprint_fn__1819000413_fn__1819000414_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000413$fn__1819000414", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000413_A_class, Simple: "fn__1819000414", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000413_fn__1819000414_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000413_fn__1819000414_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000413_fn__1819000414_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000413_fn__1819000414_A_Init; i.Table = A_arbace_pprint_fn__1819000413_fn__1819000414_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000413_fn__1819000414_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000413_fn__1819000414_A]()) }

func A_arbace_pprint_fn__1819000413_fn__1819000419_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000413_fn__1819000419_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000413_fn__1819000419_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000413_fn__1819000419_A_New()}; return nil }

func A_arbace_pprint_fn__1819000413_fn__1819000419_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000413_fn__1819000419_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000413_fn__1819000419_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000413_fn__1819000419_A_invoke, New: A_arbace_pprint_fn__1819000413_fn__1819000419_A_new, Get: A_arbace_pprint_fn__1819000413_fn__1819000419_A_get}

var A_arbace_pprint_fn__1819000413_fn__1819000419_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000413$fn__1819000419", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000413_A_class, Simple: "fn__1819000419", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000413_fn__1819000419_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000413_fn__1819000419_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000413_fn__1819000419_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000413_fn__1819000419_A_Init; i.Table = A_arbace_pprint_fn__1819000413_fn__1819000419_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000413_fn__1819000419_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000413_fn__1819000419_A]()) }

func A_arbace_pprint_fn__1819000428_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000428_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000428_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000428_A_New()}; return nil }

func A_arbace_pprint_fn__1819000428_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000428_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000428_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000428_A_invoke, New: A_arbace_pprint_fn__1819000428_A_new, Get: A_arbace_pprint_fn__1819000428_A_get}

var A_arbace_pprint_fn__1819000428_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000428", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000428", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000428_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000428_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000428_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000428_A_Init; i.Table = A_arbace_pprint_fn__1819000428_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000428_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000428_A]()) }

func A_arbace_pprint_fn__1819000428_fn__1819000429_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000428_fn__1819000429_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000428_fn__1819000429_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000428_fn__1819000429_A_New_O(args[0])}; return nil }

func A_arbace_pprint_fn__1819000428_fn__1819000429_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000428_fn__1819000429_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000428_fn__1819000429_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000428_fn__1819000429_A_invoke, New: A_arbace_pprint_fn__1819000428_fn__1819000429_A_new, Get: A_arbace_pprint_fn__1819000428_fn__1819000429_A_get}

var A_arbace_pprint_fn__1819000428_fn__1819000429_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000428$fn__1819000429", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000428_A_class, Simple: "fn__1819000429", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000428_fn__1819000429_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000428_fn__1819000429_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000428_fn__1819000429_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000428_fn__1819000429_A_Init; i.Table = A_arbace_pprint_fn__1819000428_fn__1819000429_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000428_fn__1819000429_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000428_fn__1819000429_A]()) }

func A_arbace_pprint_fn__1819000432_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000432_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000432_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000432_A_New()}; return nil }

func A_arbace_pprint_fn__1819000432_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000432_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000432_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000432_A_invoke, New: A_arbace_pprint_fn__1819000432_A_new, Get: A_arbace_pprint_fn__1819000432_A_get}

var A_arbace_pprint_fn__1819000432_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000432", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000432", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000432_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000432_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000432_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000432_A_Init; i.Table = A_arbace_pprint_fn__1819000432_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000432_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000432_A]()) }

func A_arbace_pprint_fn__1819000434_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000434_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000434_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000434_A_New()}; return nil }

func A_arbace_pprint_fn__1819000434_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000434_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000434_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000434_A_invoke, New: A_arbace_pprint_fn__1819000434_A_new, Get: A_arbace_pprint_fn__1819000434_A_get}

var A_arbace_pprint_fn__1819000434_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000434", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000434", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000434_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000434_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000434_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000434_A_Init; i.Table = A_arbace_pprint_fn__1819000434_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000434_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000434_A]()) }

func A_arbace_pprint_fn__1819000436_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000436_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000436_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000436_A_New()}; return nil }

func A_arbace_pprint_fn__1819000436_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000436_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000436_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000436_A_invoke, New: A_arbace_pprint_fn__1819000436_A_new, Get: A_arbace_pprint_fn__1819000436_A_get}

var A_arbace_pprint_fn__1819000436_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000436", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000436", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000436_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000436_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000436_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000436_A_Init; i.Table = A_arbace_pprint_fn__1819000436_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000436_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000436_A]()) }

func A_arbace_pprint_fn__1819000438_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000438_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000438_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000438_A_New()}; return nil }

func A_arbace_pprint_fn__1819000438_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000438_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000438_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000438_A_invoke, New: A_arbace_pprint_fn__1819000438_A_new, Get: A_arbace_pprint_fn__1819000438_A_get}

var A_arbace_pprint_fn__1819000438_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000438", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000438", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000438_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000438_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000438_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000438_A_Init; i.Table = A_arbace_pprint_fn__1819000438_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000438_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000438_A]()) }

func A_arbace_pprint_fn__1819000440_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000440_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000440_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000440_A_New()}; return nil }

func A_arbace_pprint_fn__1819000440_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000440_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000440_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000440_A_invoke, New: A_arbace_pprint_fn__1819000440_A_new, Get: A_arbace_pprint_fn__1819000440_A_get}

var A_arbace_pprint_fn__1819000440_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000440", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000440", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000440_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000440_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000440_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000440_A_Init; i.Table = A_arbace_pprint_fn__1819000440_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000440_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000440_A]()) }

func A_arbace_pprint_fn__1819000442_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000442_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000442_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000442_A_New()}; return nil }

func A_arbace_pprint_fn__1819000442_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000442_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000442_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000442_A_invoke, New: A_arbace_pprint_fn__1819000442_A_new, Get: A_arbace_pprint_fn__1819000442_A_get}

var A_arbace_pprint_fn__1819000442_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000442", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000442", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000442_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000442_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000442_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000442_A_Init; i.Table = A_arbace_pprint_fn__1819000442_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000442_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000442_A]()) }

func A_arbace_pprint_fn__1819000444_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000444_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000444_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000444_A_New()}; return nil }

func A_arbace_pprint_fn__1819000444_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000444_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000444_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000444_A_invoke, New: A_arbace_pprint_fn__1819000444_A_new, Get: A_arbace_pprint_fn__1819000444_A_get}

var A_arbace_pprint_fn__1819000444_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000444", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000444", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000444_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000444_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000444_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000444_A_Init; i.Table = A_arbace_pprint_fn__1819000444_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000444_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000444_A]()) }

func A_arbace_pprint_fn__1819000446_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000446_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000446_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000446_A_New()}; return nil }

func A_arbace_pprint_fn__1819000446_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000446_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000446_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000446_A_invoke, New: A_arbace_pprint_fn__1819000446_A_new, Get: A_arbace_pprint_fn__1819000446_A_get}

var A_arbace_pprint_fn__1819000446_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000446", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000446", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000446_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000446_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000446_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000446_A_Init; i.Table = A_arbace_pprint_fn__1819000446_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000446_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000446_A]()) }

func A_arbace_pprint_fn__1819000448_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000448_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000448_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000448_A_New()}; return nil }

func A_arbace_pprint_fn__1819000448_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000448_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000448_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000448_A_invoke, New: A_arbace_pprint_fn__1819000448_A_new, Get: A_arbace_pprint_fn__1819000448_A_get}

var A_arbace_pprint_fn__1819000448_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000448", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000448", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000448_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000448_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000448_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000448_A_Init; i.Table = A_arbace_pprint_fn__1819000448_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000448_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000448_A]()) }

func A_arbace_pprint_fn__1819000448_fn__1819000449_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000448_fn__1819000449_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000448_fn__1819000449_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000448_fn__1819000449_A_New()}; return nil }

func A_arbace_pprint_fn__1819000448_fn__1819000449_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000448_fn__1819000449_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000448_fn__1819000449_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000448_fn__1819000449_A_invoke, New: A_arbace_pprint_fn__1819000448_fn__1819000449_A_new, Get: A_arbace_pprint_fn__1819000448_fn__1819000449_A_get}

var A_arbace_pprint_fn__1819000448_fn__1819000449_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000448$fn__1819000449", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000448_A_class, Simple: "fn__1819000449", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000448_fn__1819000449_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000448_fn__1819000449_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000448_fn__1819000449_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000448_fn__1819000449_A_Init; i.Table = A_arbace_pprint_fn__1819000448_fn__1819000449_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000448_fn__1819000449_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000448_fn__1819000449_A]()) }

func A_arbace_pprint_fn__1819000452_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000452_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000452_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000452_A_New()}; return nil }

func A_arbace_pprint_fn__1819000452_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000452_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000452_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000452_A_invoke, New: A_arbace_pprint_fn__1819000452_A_new, Get: A_arbace_pprint_fn__1819000452_A_get}

var A_arbace_pprint_fn__1819000452_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000452", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000452", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000452_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000452_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000452_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000452_A_Init; i.Table = A_arbace_pprint_fn__1819000452_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000452_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000452_A]()) }

func A_arbace_pprint_fn__1819000452_fn__1819000453_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000452_fn__1819000453_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000452_fn__1819000453_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000452_fn__1819000453_A_New_O(args[0])}; return nil }

func A_arbace_pprint_fn__1819000452_fn__1819000453_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000452_fn__1819000453_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000452_fn__1819000453_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000452_fn__1819000453_A_invoke, New: A_arbace_pprint_fn__1819000452_fn__1819000453_A_new, Get: A_arbace_pprint_fn__1819000452_fn__1819000453_A_get}

var A_arbace_pprint_fn__1819000452_fn__1819000453_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000452$fn__1819000453", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000452_A_class, Simple: "fn__1819000453", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000452_fn__1819000453_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000452_fn__1819000453_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000452_fn__1819000453_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000452_fn__1819000453_A_Init; i.Table = A_arbace_pprint_fn__1819000452_fn__1819000453_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000452_fn__1819000453_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000452_fn__1819000453_A]()) }

func A_arbace_pprint_fn__1819000452_fn__1819000458_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000452_fn__1819000458_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_fn__1819000452_fn__1819000458_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000452_fn__1819000458_A_New()}; return nil }

func A_arbace_pprint_fn__1819000452_fn__1819000458_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000452_fn__1819000458_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000452_fn__1819000458_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000452_fn__1819000458_A_invoke, New: A_arbace_pprint_fn__1819000452_fn__1819000458_A_new, Get: A_arbace_pprint_fn__1819000452_fn__1819000458_A_get}

var A_arbace_pprint_fn__1819000452_fn__1819000458_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000452$fn__1819000458", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_fn__1819000452_A_class, Simple: "fn__1819000458", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000452_fn__1819000458_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000452_fn__1819000458_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000452_fn__1819000458_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000452_fn__1819000458_A_Init; i.Table = A_arbace_pprint_fn__1819000452_fn__1819000458_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000452_fn__1819000458_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000452_fn__1819000458_A]()) }

func A_arbace_pprint_fn__1819000464_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000464_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000464_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000464_A_New()}; return nil }

func A_arbace_pprint_fn__1819000464_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000464_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000464_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000464_A_invoke, New: A_arbace_pprint_fn__1819000464_A_new, Get: A_arbace_pprint_fn__1819000464_A_get}

var A_arbace_pprint_fn__1819000464_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000464", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000464", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000464_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000464_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000464_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000464_A_Init; i.Table = A_arbace_pprint_fn__1819000464_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000464_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000464_A]()) }

func A_arbace_pprint_fn__1819000466_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1819000466_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_fn__1819000466_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1819000466_A_New()}; return nil }

func A_arbace_pprint_fn__1819000466_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1819000466_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1819000466_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1819000466_A_invoke, New: A_arbace_pprint_fn__1819000466_A_new, Get: A_arbace_pprint_fn__1819000466_A_get}

var A_arbace_pprint_fn__1819000466_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1819000466", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1819000466", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1819000466_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fn__1819000466_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1819000466_A_InstanceOf; i.Init = A_arbace_pprint_fn__1819000466_A_Init; i.Table = A_arbace_pprint_fn__1819000466_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1819000466_A_class, reflect.TypeFor[A_arbace_pprint_fn__1819000466_A]()) }

func A_arbace_pprint_fn__1820000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__1820000051_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_fn__1820000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__1820000051_A_New()}; return nil }

func A_arbace_pprint_fn__1820000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__1820000051_A_fn_class)}; return nil }

var A_arbace_pprint_fn__1820000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__1820000051_A_invoke, New: A_arbace_pprint_fn__1820000051_A_new, Get: A_arbace_pprint_fn__1820000051_A_get}

var A_arbace_pprint_fn__1820000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__1820000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__1820000051", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_fn__1820000051_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__1820000051_A_InstanceOf; i.Init = A_arbace_pprint_fn__1820000051_A_Init; i.Table = A_arbace_pprint_fn__1820000051_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__1820000051_A_class, reflect.TypeFor[A_arbace_pprint_fn__1820000051_A]()) }

func A_arbace_pprint_fn__740000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__740000014_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_fn__740000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__740000014_A_New()}; return nil }

func A_arbace_pprint_fn__740000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__740000014_A_fn_class)}; return nil }

var A_arbace_pprint_fn__740000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__740000014_A_invoke, New: A_arbace_pprint_fn__740000014_A_new, Get: A_arbace_pprint_fn__740000014_A_get}

var A_arbace_pprint_fn__740000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__740000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__740000014", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__740000014_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_fn__740000014_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__740000014_A_InstanceOf; i.Init = A_arbace_pprint_fn__740000014_A_Init; i.Table = A_arbace_pprint_fn__740000014_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__740000014_A_class, reflect.TypeFor[A_arbace_pprint_fn__740000014_A]()) }

func A_arbace_pprint_fn__740000014_fn__740000015_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__740000014_fn__740000015_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_fn__740000014_fn__740000015_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__740000014_fn__740000015_A_New_O(args[0])}; return nil }

func A_arbace_pprint_fn__740000014_fn__740000015_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__740000014_fn__740000015_A_fn_class)}; return nil }

var A_arbace_pprint_fn__740000014_fn__740000015_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__740000014_fn__740000015_A_invoke, New: A_arbace_pprint_fn__740000014_fn__740000015_A_new, Get: A_arbace_pprint_fn__740000014_fn__740000015_A_get}

var A_arbace_pprint_fn__740000014_fn__740000015_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__740000014$fn__740000015", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_fn__740000014_A_class, Simple: "fn__740000015", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__740000014_fn__740000015_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_fn__740000014_fn__740000015_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__740000014_fn__740000015_A_InstanceOf; i.Init = A_arbace_pprint_fn__740000014_fn__740000015_A_Init; i.Table = A_arbace_pprint_fn__740000014_fn__740000015_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__740000014_fn__740000015_A_class, reflect.TypeFor[A_arbace_pprint_fn__740000014_fn__740000015_A]()) }

func A_arbace_pprint_fn__740000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__740000032_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_fn__740000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__740000032_A_New()}; return nil }

func A_arbace_pprint_fn__740000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__740000032_A_fn_class)}; return nil }

var A_arbace_pprint_fn__740000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__740000032_A_invoke, New: A_arbace_pprint_fn__740000032_A_new, Get: A_arbace_pprint_fn__740000032_A_get}

var A_arbace_pprint_fn__740000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__740000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__740000032", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__740000032_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_fn__740000032_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__740000032_A_InstanceOf; i.Init = A_arbace_pprint_fn__740000032_A_Init; i.Table = A_arbace_pprint_fn__740000032_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__740000032_A_class, reflect.TypeFor[A_arbace_pprint_fn__740000032_A]()) }

func A_arbace_pprint_fn__740000032_fn__740000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__740000032_fn__740000033_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_fn__740000032_fn__740000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__740000032_fn__740000033_A_New_O(args[0])}; return nil }

func A_arbace_pprint_fn__740000032_fn__740000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__740000032_fn__740000033_A_fn_class)}; return nil }

var A_arbace_pprint_fn__740000032_fn__740000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__740000032_fn__740000033_A_invoke, New: A_arbace_pprint_fn__740000032_fn__740000033_A_new, Get: A_arbace_pprint_fn__740000032_fn__740000033_A_get}

var A_arbace_pprint_fn__740000032_fn__740000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__740000032$fn__740000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_fn__740000032_A_class, Simple: "fn__740000033", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__740000032_fn__740000033_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_fn__740000032_fn__740000033_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__740000032_fn__740000033_A_InstanceOf; i.Init = A_arbace_pprint_fn__740000032_fn__740000033_A_Init; i.Table = A_arbace_pprint_fn__740000032_fn__740000033_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__740000032_fn__740000033_A_class, reflect.TypeFor[A_arbace_pprint_fn__740000032_fn__740000033_A]()) }

func A_arbace_pprint_fn__740000107_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__740000107_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_fn__740000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__740000107_A_New()}; return nil }

func A_arbace_pprint_fn__740000107_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__740000107_A_fn_class)}; return nil }

var A_arbace_pprint_fn__740000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__740000107_A_invoke, New: A_arbace_pprint_fn__740000107_A_new, Get: A_arbace_pprint_fn__740000107_A_get}

var A_arbace_pprint_fn__740000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__740000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__740000107", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__740000107_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_fn__740000107_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__740000107_A_InstanceOf; i.Init = A_arbace_pprint_fn__740000107_A_Init; i.Table = A_arbace_pprint_fn__740000107_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__740000107_A_class, reflect.TypeFor[A_arbace_pprint_fn__740000107_A]()) }

func A_arbace_pprint_fn__740000107_fn__740000108_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__740000107_fn__740000108_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_fn__740000107_fn__740000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__740000107_fn__740000108_A_New_O(args[0])}; return nil }

func A_arbace_pprint_fn__740000107_fn__740000108_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__740000107_fn__740000108_A_fn_class)}; return nil }

var A_arbace_pprint_fn__740000107_fn__740000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__740000107_fn__740000108_A_invoke, New: A_arbace_pprint_fn__740000107_fn__740000108_A_new, Get: A_arbace_pprint_fn__740000107_fn__740000108_A_get}

var A_arbace_pprint_fn__740000107_fn__740000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__740000107$fn__740000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_fn__740000107_A_class, Simple: "fn__740000108", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__740000107_fn__740000108_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_fn__740000107_fn__740000108_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__740000107_fn__740000108_A_InstanceOf; i.Init = A_arbace_pprint_fn__740000107_fn__740000108_A_Init; i.Table = A_arbace_pprint_fn__740000107_fn__740000108_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__740000107_fn__740000108_A_class, reflect.TypeFor[A_arbace_pprint_fn__740000107_fn__740000108_A]()) }

func A_arbace_pprint_fn__740000152_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__740000152_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_fn__740000152_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__740000152_A_New()}; return nil }

func A_arbace_pprint_fn__740000152_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__740000152_A_fn_class)}; return nil }

var A_arbace_pprint_fn__740000152_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__740000152_A_invoke, New: A_arbace_pprint_fn__740000152_A_new, Get: A_arbace_pprint_fn__740000152_A_get}

var A_arbace_pprint_fn__740000152_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__740000152", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_A_class, Simple: "fn__740000152", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__740000152_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_fn__740000152_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__740000152_A_InstanceOf; i.Init = A_arbace_pprint_fn__740000152_A_Init; i.Table = A_arbace_pprint_fn__740000152_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__740000152_A_class, reflect.TypeFor[A_arbace_pprint_fn__740000152_A]()) }

func A_arbace_pprint_fn__740000152_fn__740000153_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fn__740000152_fn__740000153_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_fn__740000152_fn__740000153_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fn__740000152_fn__740000153_A_New_O(args[0])}; return nil }

func A_arbace_pprint_fn__740000152_fn__740000153_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fn__740000152_fn__740000153_A_fn_class)}; return nil }

var A_arbace_pprint_fn__740000152_fn__740000153_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fn__740000152_fn__740000153_A_invoke, New: A_arbace_pprint_fn__740000152_fn__740000153_A_new, Get: A_arbace_pprint_fn__740000152_fn__740000153_A_get}

var A_arbace_pprint_fn__740000152_fn__740000153_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fn__740000152$fn__740000153", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_fn__740000152_A_class, Simple: "fn__740000153", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fn__740000152_fn__740000153_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_fn__740000152_fn__740000153_A_class.Info(); i.IsInstance = A_arbace_pprint_fn__740000152_fn__740000153_A_InstanceOf; i.Init = A_arbace_pprint_fn__740000152_fn__740000153_A_Init; i.Table = A_arbace_pprint_fn__740000152_fn__740000153_A_members; jrt.RegisterGoType(A_arbace_pprint_fn__740000152_fn__740000153_A_class, reflect.TypeFor[A_arbace_pprint_fn__740000152_fn__740000153_A]()) }

func A_arbace_pprint_format_ascii_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_ascii_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_format_ascii_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_ascii_A_New()}; return nil }

func A_arbace_pprint_format_ascii_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_ascii_A_fn_class)}; return nil }

var A_arbace_pprint_format_ascii_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_ascii_A_invoke, New: A_arbace_pprint_format_ascii_A_new, Get: A_arbace_pprint_format_ascii_A_get}

var A_arbace_pprint_format_ascii_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_ascii", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_ascii", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_ascii_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_ascii_A_class.Info(); i.IsInstance = A_arbace_pprint_format_ascii_A_InstanceOf; i.Init = A_arbace_pprint_format_ascii_A_Init; i.Table = A_arbace_pprint_format_ascii_A_members; jrt.RegisterGoType(A_arbace_pprint_format_ascii_A_class, reflect.TypeFor[A_arbace_pprint_format_ascii_A]()) }

func A_arbace_pprint_format_cardinal_english_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_cardinal_english_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_format_cardinal_english_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_cardinal_english_A_New()}; return nil }

func A_arbace_pprint_format_cardinal_english_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_cardinal_english_A_fn_class)}; return nil }

var A_arbace_pprint_format_cardinal_english_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_cardinal_english_A_invoke, New: A_arbace_pprint_format_cardinal_english_A_new, Get: A_arbace_pprint_format_cardinal_english_A_get}

var A_arbace_pprint_format_cardinal_english_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_cardinal_english", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_cardinal_english", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_cardinal_english_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_cardinal_english_A_class.Info(); i.IsInstance = A_arbace_pprint_format_cardinal_english_A_InstanceOf; i.Init = A_arbace_pprint_format_cardinal_english_A_Init; i.Table = A_arbace_pprint_format_cardinal_english_A_members; jrt.RegisterGoType(A_arbace_pprint_format_cardinal_english_A_class, reflect.TypeFor[A_arbace_pprint_format_cardinal_english_A]()) }

func A_arbace_pprint_format_error_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_error_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_format_error_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_error_A_New()}; return nil }

func A_arbace_pprint_format_error_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_error_A_fn_class)}; return nil }

var A_arbace_pprint_format_error_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_error_A_invoke, New: A_arbace_pprint_format_error_A_new, Get: A_arbace_pprint_format_error_A_get}

var A_arbace_pprint_format_error_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_error", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_error", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_error_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_error_A_class.Info(); i.IsInstance = A_arbace_pprint_format_error_A_InstanceOf; i.Init = A_arbace_pprint_format_error_A_Init; i.Table = A_arbace_pprint_format_error_A_members; jrt.RegisterGoType(A_arbace_pprint_format_error_A_class, reflect.TypeFor[A_arbace_pprint_format_error_A]()) }

func A_arbace_pprint_format_integer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_integer_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_format_integer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_integer_A_New()}; return nil }

func A_arbace_pprint_format_integer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_integer_A_fn_class)}; return nil }

var A_arbace_pprint_format_integer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_integer_A_invoke, New: A_arbace_pprint_format_integer_A_new, Get: A_arbace_pprint_format_integer_A_get}

var A_arbace_pprint_format_integer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_integer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_integer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_integer_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_integer_A_class.Info(); i.IsInstance = A_arbace_pprint_format_integer_A_InstanceOf; i.Init = A_arbace_pprint_format_integer_A_Init; i.Table = A_arbace_pprint_format_integer_A_members; jrt.RegisterGoType(A_arbace_pprint_format_integer_A_class, reflect.TypeFor[A_arbace_pprint_format_integer_A]()) }

func A_arbace_pprint_format_integer_fn__1819000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_integer_fn__1819000050_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_format_integer_fn__1819000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_integer_fn__1819000050_A_New()}; return nil }

func A_arbace_pprint_format_integer_fn__1819000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_integer_fn__1819000050_A_fn_class)}; return nil }

var A_arbace_pprint_format_integer_fn__1819000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_integer_fn__1819000050_A_invoke, New: A_arbace_pprint_format_integer_fn__1819000050_A_new, Get: A_arbace_pprint_format_integer_fn__1819000050_A_get}

var A_arbace_pprint_format_integer_fn__1819000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_integer$fn__1819000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_format_integer_A_class, Simple: "fn__1819000050", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_integer_fn__1819000050_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_integer_fn__1819000050_A_class.Info(); i.IsInstance = A_arbace_pprint_format_integer_fn__1819000050_A_InstanceOf; i.Init = A_arbace_pprint_format_integer_fn__1819000050_A_Init; i.Table = A_arbace_pprint_format_integer_fn__1819000050_A_members; jrt.RegisterGoType(A_arbace_pprint_format_integer_fn__1819000050_A_class, reflect.TypeFor[A_arbace_pprint_format_integer_fn__1819000050_A]()) }

func A_arbace_pprint_format_logical_block_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_logical_block_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_format_logical_block_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_logical_block_A_New()}; return nil }

func A_arbace_pprint_format_logical_block_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_logical_block_A_fn_class)}; return nil }

var A_arbace_pprint_format_logical_block_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_logical_block_A_invoke, New: A_arbace_pprint_format_logical_block_A_new, Get: A_arbace_pprint_format_logical_block_A_get}

var A_arbace_pprint_format_logical_block_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_logical_block", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_logical_block", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_logical_block_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_logical_block_A_class.Info(); i.IsInstance = A_arbace_pprint_format_logical_block_A_InstanceOf; i.Init = A_arbace_pprint_format_logical_block_A_Init; i.Table = A_arbace_pprint_format_logical_block_A_members; jrt.RegisterGoType(A_arbace_pprint_format_logical_block_A_class, reflect.TypeFor[A_arbace_pprint_format_logical_block_A]()) }

func A_arbace_pprint_format_logical_block_fn__1819000271_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_logical_block_fn__1819000271_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_format_logical_block_fn__1819000271_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_logical_block_fn__1819000271_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_format_logical_block_fn__1819000271_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_logical_block_fn__1819000271_A_fn_class)}; return nil }

var A_arbace_pprint_format_logical_block_fn__1819000271_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_logical_block_fn__1819000271_A_invoke, New: A_arbace_pprint_format_logical_block_fn__1819000271_A_new, Get: A_arbace_pprint_format_logical_block_fn__1819000271_A_get}

var A_arbace_pprint_format_logical_block_fn__1819000271_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_logical_block$fn__1819000271", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_format_logical_block_A_class, Simple: "fn__1819000271", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_logical_block_fn__1819000271_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_logical_block_fn__1819000271_A_class.Info(); i.IsInstance = A_arbace_pprint_format_logical_block_fn__1819000271_A_InstanceOf; i.Init = A_arbace_pprint_format_logical_block_fn__1819000271_A_Init; i.Table = A_arbace_pprint_format_logical_block_fn__1819000271_A_members; jrt.RegisterGoType(A_arbace_pprint_format_logical_block_fn__1819000271_A_class, reflect.TypeFor[A_arbace_pprint_format_logical_block_fn__1819000271_A]()) }

func A_arbace_pprint_format_new_roman_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_new_roman_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_format_new_roman_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_new_roman_A_New()}; return nil }

func A_arbace_pprint_format_new_roman_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_new_roman_A_fn_class)}; return nil }

var A_arbace_pprint_format_new_roman_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_new_roman_A_invoke, New: A_arbace_pprint_format_new_roman_A_new, Get: A_arbace_pprint_format_new_roman_A_get}

var A_arbace_pprint_format_new_roman_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_new_roman", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_new_roman", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_new_roman_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_new_roman_A_class.Info(); i.IsInstance = A_arbace_pprint_format_new_roman_A_InstanceOf; i.Init = A_arbace_pprint_format_new_roman_A_Init; i.Table = A_arbace_pprint_format_new_roman_A_members; jrt.RegisterGoType(A_arbace_pprint_format_new_roman_A_class, reflect.TypeFor[A_arbace_pprint_format_new_roman_A]()) }

func A_arbace_pprint_format_old_roman_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_old_roman_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_format_old_roman_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_old_roman_A_New()}; return nil }

func A_arbace_pprint_format_old_roman_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_old_roman_A_fn_class)}; return nil }

var A_arbace_pprint_format_old_roman_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_old_roman_A_invoke, New: A_arbace_pprint_format_old_roman_A_new, Get: A_arbace_pprint_format_old_roman_A_get}

var A_arbace_pprint_format_old_roman_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_old_roman", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_old_roman", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_old_roman_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_old_roman_A_class.Info(); i.IsInstance = A_arbace_pprint_format_old_roman_A_InstanceOf; i.Init = A_arbace_pprint_format_old_roman_A_Init; i.Table = A_arbace_pprint_format_old_roman_A_members; jrt.RegisterGoType(A_arbace_pprint_format_old_roman_A_class, reflect.TypeFor[A_arbace_pprint_format_old_roman_A]()) }

func A_arbace_pprint_format_ordinal_english_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_ordinal_english_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_format_ordinal_english_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_ordinal_english_A_New()}; return nil }

func A_arbace_pprint_format_ordinal_english_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_ordinal_english_A_fn_class)}; return nil }

var A_arbace_pprint_format_ordinal_english_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_ordinal_english_A_invoke, New: A_arbace_pprint_format_ordinal_english_A_new, Get: A_arbace_pprint_format_ordinal_english_A_get}

var A_arbace_pprint_format_ordinal_english_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_ordinal_english", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_ordinal_english", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_ordinal_english_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_ordinal_english_A_class.Info(); i.IsInstance = A_arbace_pprint_format_ordinal_english_A_InstanceOf; i.Init = A_arbace_pprint_format_ordinal_english_A_Init; i.Table = A_arbace_pprint_format_ordinal_english_A_members; jrt.RegisterGoType(A_arbace_pprint_format_ordinal_english_A_class, reflect.TypeFor[A_arbace_pprint_format_ordinal_english_A]()) }

func A_arbace_pprint_format_roman_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_roman_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_format_roman_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_roman_A_New()}; return nil }

func A_arbace_pprint_format_roman_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_roman_A_fn_class)}; return nil }

var A_arbace_pprint_format_roman_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_roman_A_invoke, New: A_arbace_pprint_format_roman_A_new, Get: A_arbace_pprint_format_roman_A_get}

var A_arbace_pprint_format_roman_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_roman", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_roman", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_roman_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_roman_A_class.Info(); i.IsInstance = A_arbace_pprint_format_roman_A_InstanceOf; i.Init = A_arbace_pprint_format_roman_A_Init; i.Table = A_arbace_pprint_format_roman_A_members; jrt.RegisterGoType(A_arbace_pprint_format_roman_A_class, reflect.TypeFor[A_arbace_pprint_format_roman_A]()) }

func A_arbace_pprint_format_simple_cardinal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_simple_cardinal_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_format_simple_cardinal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_simple_cardinal_A_New()}; return nil }

func A_arbace_pprint_format_simple_cardinal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_simple_cardinal_A_fn_class)}; return nil }

var A_arbace_pprint_format_simple_cardinal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_simple_cardinal_A_invoke, New: A_arbace_pprint_format_simple_cardinal_A_new, Get: A_arbace_pprint_format_simple_cardinal_A_get}

var A_arbace_pprint_format_simple_cardinal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_simple_cardinal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_simple_cardinal", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_simple_cardinal_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_simple_cardinal_A_class.Info(); i.IsInstance = A_arbace_pprint_format_simple_cardinal_A_InstanceOf; i.Init = A_arbace_pprint_format_simple_cardinal_A_Init; i.Table = A_arbace_pprint_format_simple_cardinal_A_members; jrt.RegisterGoType(A_arbace_pprint_format_simple_cardinal_A_class, reflect.TypeFor[A_arbace_pprint_format_simple_cardinal_A]()) }

func A_arbace_pprint_format_simple_number_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_simple_number_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_format_simple_number_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_simple_number_A_New()}; return nil }

func A_arbace_pprint_format_simple_number_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_simple_number_A_fn_class)}; return nil }

var A_arbace_pprint_format_simple_number_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_simple_number_A_invoke, New: A_arbace_pprint_format_simple_number_A_new, Get: A_arbace_pprint_format_simple_number_A_get}

var A_arbace_pprint_format_simple_number_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_simple_number", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_simple_number", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_simple_number_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_simple_number_A_class.Info(); i.IsInstance = A_arbace_pprint_format_simple_number_A_InstanceOf; i.Init = A_arbace_pprint_format_simple_number_A_Init; i.Table = A_arbace_pprint_format_simple_number_A_members; jrt.RegisterGoType(A_arbace_pprint_format_simple_number_A_class, reflect.TypeFor[A_arbace_pprint_format_simple_number_A]()) }

func A_arbace_pprint_format_simple_ordinal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_format_simple_ordinal_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_format_simple_ordinal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_format_simple_ordinal_A_New()}; return nil }

func A_arbace_pprint_format_simple_ordinal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_format_simple_ordinal_A_fn_class)}; return nil }

var A_arbace_pprint_format_simple_ordinal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_format_simple_ordinal_A_invoke, New: A_arbace_pprint_format_simple_ordinal_A_new, Get: A_arbace_pprint_format_simple_ordinal_A_get}

var A_arbace_pprint_format_simple_ordinal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$format_simple_ordinal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "format_simple_ordinal", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_format_simple_ordinal_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_format_simple_ordinal_A_class.Info(); i.IsInstance = A_arbace_pprint_format_simple_ordinal_A_InstanceOf; i.Init = A_arbace_pprint_format_simple_ordinal_A_Init; i.Table = A_arbace_pprint_format_simple_ordinal_A_members; jrt.RegisterGoType(A_arbace_pprint_format_simple_ordinal_A_class, reflect.TypeFor[A_arbace_pprint_format_simple_ordinal_A]()) }

func A_arbace_pprint_formatter_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_formatter_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_formatter_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_formatter_A_New()}; return nil }

func A_arbace_pprint_formatter_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_formatter_A_fn_class)}; return nil }

var A_arbace_pprint_formatter_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_formatter_A_invoke, New: A_arbace_pprint_formatter_A_new, Get: A_arbace_pprint_formatter_A_get}

var A_arbace_pprint_formatter_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$formatter", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "formatter", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_formatter_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_formatter_A_class.Info(); i.IsInstance = A_arbace_pprint_formatter_A_InstanceOf; i.Init = A_arbace_pprint_formatter_A_Init; i.Table = A_arbace_pprint_formatter_A_members; jrt.RegisterGoType(A_arbace_pprint_formatter_A_class, reflect.TypeFor[A_arbace_pprint_formatter_A]()) }

func A_arbace_pprint_formatter_out_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_formatter_out_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_formatter_out_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_formatter_out_A_New()}; return nil }

func A_arbace_pprint_formatter_out_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_formatter_out_A_fn_class)}; return nil }

var A_arbace_pprint_formatter_out_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_formatter_out_A_invoke, New: A_arbace_pprint_formatter_out_A_new, Get: A_arbace_pprint_formatter_out_A_get}

var A_arbace_pprint_formatter_out_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$formatter_out", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "formatter_out", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_formatter_out_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_formatter_out_A_class.Info(); i.IsInstance = A_arbace_pprint_formatter_out_A_InstanceOf; i.Init = A_arbace_pprint_formatter_out_A_Init; i.Table = A_arbace_pprint_formatter_out_A_members; jrt.RegisterGoType(A_arbace_pprint_formatter_out_A_class, reflect.TypeFor[A_arbace_pprint_formatter_out_A]()) }

func A_arbace_pprint_fresh_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_fresh_line_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_fresh_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_fresh_line_A_New()}; return nil }

func A_arbace_pprint_fresh_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_fresh_line_A_fn_class)}; return nil }

var A_arbace_pprint_fresh_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_fresh_line_A_invoke, New: A_arbace_pprint_fresh_line_A_new, Get: A_arbace_pprint_fresh_line_A_get}

var A_arbace_pprint_fresh_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$fresh_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_A_class, Simple: "fresh_line", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_fresh_line_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_fresh_line_A_class.Info(); i.IsInstance = A_arbace_pprint_fresh_line_A_InstanceOf; i.Init = A_arbace_pprint_fresh_line_A_Init; i.Table = A_arbace_pprint_fresh_line_A_members; jrt.RegisterGoType(A_arbace_pprint_fresh_line_A_class, reflect.TypeFor[A_arbace_pprint_fresh_line_A]()) }

func A_arbace_pprint_general_float_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_general_float_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_general_float_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_general_float_A_New()}; return nil }

func A_arbace_pprint_general_float_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_general_float_A_fn_class)}; return nil }

var A_arbace_pprint_general_float_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_general_float_A_invoke, New: A_arbace_pprint_general_float_A_new, Get: A_arbace_pprint_general_float_A_get}

var A_arbace_pprint_general_float_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$general_float", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "general_float", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_general_float_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_general_float_A_class.Info(); i.IsInstance = A_arbace_pprint_general_float_A_InstanceOf; i.Init = A_arbace_pprint_general_float_A_Init; i.Table = A_arbace_pprint_general_float_A_members; jrt.RegisterGoType(A_arbace_pprint_general_float_A_class, reflect.TypeFor[A_arbace_pprint_general_float_A]()) }

func A_arbace_pprint_get_column_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_column_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_column_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_column_A_New()}; return nil }

func A_arbace_pprint_get_column_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_column_A_fn_class)}; return nil }

var A_arbace_pprint_get_column_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_column_A_invoke, New: A_arbace_pprint_get_column_A_new, Get: A_arbace_pprint_get_column_A_get}

var A_arbace_pprint_get_column_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_column", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_column", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_column_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_get_column_A_class.Info(); i.IsInstance = A_arbace_pprint_get_column_A_InstanceOf; i.Init = A_arbace_pprint_get_column_A_Init; i.Table = A_arbace_pprint_get_column_A_members; jrt.RegisterGoType(A_arbace_pprint_get_column_A_class, reflect.TypeFor[A_arbace_pprint_get_column_A]()) }

func A_arbace_pprint_get_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_field_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_get_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_field_A_New()}; return nil }

func A_arbace_pprint_get_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_field_A_fn_class)}; return nil }

var A_arbace_pprint_get_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_field_A_invoke, New: A_arbace_pprint_get_field_A_new, Get: A_arbace_pprint_get_field_A_get}

var A_arbace_pprint_get_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_field", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_field_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_get_field_A_class.Info(); i.IsInstance = A_arbace_pprint_get_field_A_InstanceOf; i.Init = A_arbace_pprint_get_field_A_Init; i.Table = A_arbace_pprint_get_field_A_members; jrt.RegisterGoType(A_arbace_pprint_get_field_A_class, reflect.TypeFor[A_arbace_pprint_get_field_A]()) }

func A_arbace_pprint_get_fixed_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_fixed_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_get_fixed_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_fixed_A_New()}; return nil }

func A_arbace_pprint_get_fixed_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_fixed_A_fn_class)}; return nil }

var A_arbace_pprint_get_fixed_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_fixed_A_invoke, New: A_arbace_pprint_get_fixed_A_new, Get: A_arbace_pprint_get_fixed_A_get}

var A_arbace_pprint_get_fixed_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_fixed", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_fixed", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_fixed_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_get_fixed_A_class.Info(); i.IsInstance = A_arbace_pprint_get_fixed_A_InstanceOf; i.Init = A_arbace_pprint_get_fixed_A_Init; i.Table = A_arbace_pprint_get_fixed_A_members; jrt.RegisterGoType(A_arbace_pprint_get_fixed_A_class, reflect.TypeFor[A_arbace_pprint_get_fixed_A]()) }

func A_arbace_pprint_get_format_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_format_arg_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_format_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_format_arg_A_New()}; return nil }

func A_arbace_pprint_get_format_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_format_arg_A_fn_class)}; return nil }

var A_arbace_pprint_get_format_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_format_arg_A_invoke, New: A_arbace_pprint_get_format_arg_A_new, Get: A_arbace_pprint_get_format_arg_A_get}

var A_arbace_pprint_get_format_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_format_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_format_arg", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_format_arg_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_get_format_arg_A_class.Info(); i.IsInstance = A_arbace_pprint_get_format_arg_A_InstanceOf; i.Init = A_arbace_pprint_get_format_arg_A_Init; i.Table = A_arbace_pprint_get_format_arg_A_members; jrt.RegisterGoType(A_arbace_pprint_get_format_arg_A_class, reflect.TypeFor[A_arbace_pprint_get_format_arg_A]()) }

func A_arbace_pprint_get_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_line_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_line_A_New()}; return nil }

func A_arbace_pprint_get_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_line_A_fn_class)}; return nil }

var A_arbace_pprint_get_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_line_A_invoke, New: A_arbace_pprint_get_line_A_new, Get: A_arbace_pprint_get_line_A_get}

var A_arbace_pprint_get_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_line", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_line_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_get_line_A_class.Info(); i.IsInstance = A_arbace_pprint_get_line_A_InstanceOf; i.Init = A_arbace_pprint_get_line_A_Init; i.Table = A_arbace_pprint_get_line_A_members; jrt.RegisterGoType(A_arbace_pprint_get_line_A_class, reflect.TypeFor[A_arbace_pprint_get_line_A]()) }

func A_arbace_pprint_get_max_column_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_max_column_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_max_column_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_max_column_A_New()}; return nil }

func A_arbace_pprint_get_max_column_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_max_column_A_fn_class)}; return nil }

var A_arbace_pprint_get_max_column_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_max_column_A_invoke, New: A_arbace_pprint_get_max_column_A_new, Get: A_arbace_pprint_get_max_column_A_get}

var A_arbace_pprint_get_max_column_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_max_column", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_max_column", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_max_column_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_get_max_column_A_class.Info(); i.IsInstance = A_arbace_pprint_get_max_column_A_InstanceOf; i.Init = A_arbace_pprint_get_max_column_A_Init; i.Table = A_arbace_pprint_get_max_column_A_members; jrt.RegisterGoType(A_arbace_pprint_get_max_column_A_class, reflect.TypeFor[A_arbace_pprint_get_max_column_A]()) }

func A_arbace_pprint_get_miser_width_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_miser_width_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_miser_width_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_miser_width_A_New()}; return nil }

func A_arbace_pprint_get_miser_width_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_miser_width_A_fn_class)}; return nil }

var A_arbace_pprint_get_miser_width_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_miser_width_A_invoke, New: A_arbace_pprint_get_miser_width_A_new, Get: A_arbace_pprint_get_miser_width_A_get}

var A_arbace_pprint_get_miser_width_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_miser_width", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_miser_width", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_miser_width_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_get_miser_width_A_class.Info(); i.IsInstance = A_arbace_pprint_get_miser_width_A_InstanceOf; i.Init = A_arbace_pprint_get_miser_width_A_Init; i.Table = A_arbace_pprint_get_miser_width_A_members; jrt.RegisterGoType(A_arbace_pprint_get_miser_width_A_class, reflect.TypeFor[A_arbace_pprint_get_miser_width_A]()) }

func A_arbace_pprint_get_pretty_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_pretty_writer_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_pretty_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_pretty_writer_A_New()}; return nil }

func A_arbace_pprint_get_pretty_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_pretty_writer_A_fn_class)}; return nil }

var A_arbace_pprint_get_pretty_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_pretty_writer_A_invoke, New: A_arbace_pprint_get_pretty_writer_A_new, Get: A_arbace_pprint_get_pretty_writer_A_get}

var A_arbace_pprint_get_pretty_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_pretty_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_pretty_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_pretty_writer_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_get_pretty_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_get_pretty_writer_A_InstanceOf; i.Init = A_arbace_pprint_get_pretty_writer_A_Init; i.Table = A_arbace_pprint_get_pretty_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_get_pretty_writer_A_class, reflect.TypeFor[A_arbace_pprint_get_pretty_writer_A]()) }

func A_arbace_pprint_get_section_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_section_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_section_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_section_A_New()}; return nil }

func A_arbace_pprint_get_section_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_section_A_fn_class)}; return nil }

var A_arbace_pprint_get_section_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_section_A_invoke, New: A_arbace_pprint_get_section_A_new, Get: A_arbace_pprint_get_section_A_get}

var A_arbace_pprint_get_section_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_section", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_section", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_section_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_get_section_A_class.Info(); i.IsInstance = A_arbace_pprint_get_section_A_InstanceOf; i.Init = A_arbace_pprint_get_section_A_Init; i.Table = A_arbace_pprint_get_section_A_members; jrt.RegisterGoType(A_arbace_pprint_get_section_A_class, reflect.TypeFor[A_arbace_pprint_get_section_A]()) }

func A_arbace_pprint_get_section_fn__1820000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_section_fn__1820000114_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_section_fn__1820000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_section_fn__1820000114_A_New_O(args[0])}; return nil }

func A_arbace_pprint_get_section_fn__1820000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_section_fn__1820000114_A_fn_class)}; return nil }

var A_arbace_pprint_get_section_fn__1820000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_section_fn__1820000114_A_invoke, New: A_arbace_pprint_get_section_fn__1820000114_A_new, Get: A_arbace_pprint_get_section_fn__1820000114_A_get}

var A_arbace_pprint_get_section_fn__1820000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_section$fn__1820000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_get_section_A_class, Simple: "fn__1820000114", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_section_fn__1820000114_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_get_section_fn__1820000114_A_class.Info(); i.IsInstance = A_arbace_pprint_get_section_fn__1820000114_A_InstanceOf; i.Init = A_arbace_pprint_get_section_fn__1820000114_A_Init; i.Table = A_arbace_pprint_get_section_fn__1820000114_A_members; jrt.RegisterGoType(A_arbace_pprint_get_section_fn__1820000114_A_class, reflect.TypeFor[A_arbace_pprint_get_section_fn__1820000114_A]()) }

func A_arbace_pprint_get_sub_section_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_sub_section_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_sub_section_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_sub_section_A_New()}; return nil }

func A_arbace_pprint_get_sub_section_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_sub_section_A_fn_class)}; return nil }

var A_arbace_pprint_get_sub_section_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_sub_section_A_invoke, New: A_arbace_pprint_get_sub_section_A_new, Get: A_arbace_pprint_get_sub_section_A_get}

var A_arbace_pprint_get_sub_section_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_sub_section", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_sub_section", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_sub_section_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_get_sub_section_A_class.Info(); i.IsInstance = A_arbace_pprint_get_sub_section_A_InstanceOf; i.Init = A_arbace_pprint_get_sub_section_A_Init; i.Table = A_arbace_pprint_get_sub_section_A_members; jrt.RegisterGoType(A_arbace_pprint_get_sub_section_A_class, reflect.TypeFor[A_arbace_pprint_get_sub_section_A]()) }

func A_arbace_pprint_get_sub_section_fn__1820000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_sub_section_fn__1820000118_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_sub_section_fn__1820000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_sub_section_fn__1820000118_A_New_O(args[0])}; return nil }

func A_arbace_pprint_get_sub_section_fn__1820000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_sub_section_fn__1820000118_A_fn_class)}; return nil }

var A_arbace_pprint_get_sub_section_fn__1820000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_sub_section_fn__1820000118_A_invoke, New: A_arbace_pprint_get_sub_section_fn__1820000118_A_new, Get: A_arbace_pprint_get_sub_section_fn__1820000118_A_get}

var A_arbace_pprint_get_sub_section_fn__1820000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_sub_section$fn__1820000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_get_sub_section_A_class, Simple: "fn__1820000118", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_sub_section_fn__1820000118_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_get_sub_section_fn__1820000118_A_class.Info(); i.IsInstance = A_arbace_pprint_get_sub_section_fn__1820000118_A_InstanceOf; i.Init = A_arbace_pprint_get_sub_section_fn__1820000118_A_Init; i.Table = A_arbace_pprint_get_sub_section_fn__1820000118_A_members; jrt.RegisterGoType(A_arbace_pprint_get_sub_section_fn__1820000118_A_class, reflect.TypeFor[A_arbace_pprint_get_sub_section_fn__1820000118_A]()) }

func A_arbace_pprint_get_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_get_writer_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_get_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_get_writer_A_New()}; return nil }

func A_arbace_pprint_get_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_get_writer_A_fn_class)}; return nil }

var A_arbace_pprint_get_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_get_writer_A_invoke, New: A_arbace_pprint_get_writer_A_new, Get: A_arbace_pprint_get_writer_A_get}

var A_arbace_pprint_get_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$get_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "get_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_get_writer_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_get_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_get_writer_A_InstanceOf; i.Init = A_arbace_pprint_get_writer_A_Init; i.Table = A_arbace_pprint_get_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_get_writer_A_class, reflect.TypeFor[A_arbace_pprint_get_writer_A]()) }

func A_arbace_pprint_getf_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_getf_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_getf_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_getf_A_New()}; return nil }

func A_arbace_pprint_getf_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_getf_A_fn_class)}; return nil }

var A_arbace_pprint_getf_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_getf_A_invoke, New: A_arbace_pprint_getf_A_new, Get: A_arbace_pprint_getf_A_get}

var A_arbace_pprint_getf_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$getf", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "getf", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_getf_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_getf_A_class.Info(); i.IsInstance = A_arbace_pprint_getf_A_InstanceOf; i.Init = A_arbace_pprint_getf_A_Init; i.Table = A_arbace_pprint_getf_A_members; jrt.RegisterGoType(A_arbace_pprint_getf_A_class, reflect.TypeFor[A_arbace_pprint_getf_A]()) }

func A_arbace_pprint_group_by_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_group_by_STAR__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_group_by_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_group_by_STAR__A_New()}; return nil }

func A_arbace_pprint_group_by_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_group_by_STAR__A_fn_class)}; return nil }

var A_arbace_pprint_group_by_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_group_by_STAR__A_invoke, New: A_arbace_pprint_group_by_STAR__A_new, Get: A_arbace_pprint_group_by_STAR__A_get}

var A_arbace_pprint_group_by_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$group_by_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "group_by_STAR_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_group_by_STAR__A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_group_by_STAR__A_class.Info(); i.IsInstance = A_arbace_pprint_group_by_STAR__A_InstanceOf; i.Init = A_arbace_pprint_group_by_STAR__A_Init; i.Table = A_arbace_pprint_group_by_STAR__A_members; jrt.RegisterGoType(A_arbace_pprint_group_by_STAR__A_class, reflect.TypeFor[A_arbace_pprint_group_by_STAR__A]()) }

func A_arbace_pprint_group_by_STAR__fn__1819000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_group_by_STAR__fn__1819000043_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_group_by_STAR__fn__1819000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_group_by_STAR__fn__1819000043_A_New_O(args[0])}; return nil }

func A_arbace_pprint_group_by_STAR__fn__1819000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_group_by_STAR__fn__1819000043_A_fn_class)}; return nil }

var A_arbace_pprint_group_by_STAR__fn__1819000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_group_by_STAR__fn__1819000043_A_invoke, New: A_arbace_pprint_group_by_STAR__fn__1819000043_A_new, Get: A_arbace_pprint_group_by_STAR__fn__1819000043_A_get}

var A_arbace_pprint_group_by_STAR__fn__1819000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$group_by_STAR_$fn__1819000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_group_by_STAR__A_class, Simple: "fn__1819000043", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_group_by_STAR__fn__1819000043_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_group_by_STAR__fn__1819000043_A_class.Info(); i.IsInstance = A_arbace_pprint_group_by_STAR__fn__1819000043_A_InstanceOf; i.Init = A_arbace_pprint_group_by_STAR__fn__1819000043_A_Init; i.Table = A_arbace_pprint_group_by_STAR__fn__1819000043_A_members; jrt.RegisterGoType(A_arbace_pprint_group_by_STAR__fn__1819000043_A_class, reflect.TypeFor[A_arbace_pprint_group_by_STAR__fn__1819000043_A]()) }

func A_arbace_pprint_inc_s_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_inc_s_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_inc_s_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_inc_s_A_New()}; return nil }

func A_arbace_pprint_inc_s_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_inc_s_A_fn_class)}; return nil }

var A_arbace_pprint_inc_s_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_inc_s_A_invoke, New: A_arbace_pprint_inc_s_A_new, Get: A_arbace_pprint_inc_s_A_get}

var A_arbace_pprint_inc_s_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$inc_s", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "inc_s", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_inc_s_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_inc_s_A_class.Info(); i.IsInstance = A_arbace_pprint_inc_s_A_InstanceOf; i.Init = A_arbace_pprint_inc_s_A_Init; i.Table = A_arbace_pprint_inc_s_A_members; jrt.RegisterGoType(A_arbace_pprint_inc_s_A_class, reflect.TypeFor[A_arbace_pprint_inc_s_A]()) }

func A_arbace_pprint_indent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_indent_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_indent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_indent_A_New()}; return nil }

func A_arbace_pprint_indent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_indent_A_fn_class)}; return nil }

var A_arbace_pprint_indent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_indent_A_invoke, New: A_arbace_pprint_indent_A_new, Get: A_arbace_pprint_indent_A_get}

var A_arbace_pprint_indent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$indent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "indent", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_indent_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_indent_A_class.Info(); i.IsInstance = A_arbace_pprint_indent_A_InstanceOf; i.Init = A_arbace_pprint_indent_A_Init; i.Table = A_arbace_pprint_indent_A_members; jrt.RegisterGoType(A_arbace_pprint_indent_A_class, reflect.TypeFor[A_arbace_pprint_indent_A]()) }

func A_arbace_pprint_indent_fn__1820000199_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_indent_fn__1820000199_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_indent_fn__1820000199_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_indent_fn__1820000199_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_indent_fn__1820000199_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_indent_fn__1820000199_A_fn_class)}; return nil }

var A_arbace_pprint_indent_fn__1820000199_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_indent_fn__1820000199_A_invoke, New: A_arbace_pprint_indent_fn__1820000199_A_new, Get: A_arbace_pprint_indent_fn__1820000199_A_get}

var A_arbace_pprint_indent_fn__1820000199_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$indent$fn__1820000199", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_indent_A_class, Simple: "fn__1820000199", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_indent_fn__1820000199_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_indent_fn__1820000199_A_class.Info(); i.IsInstance = A_arbace_pprint_indent_fn__1820000199_A_InstanceOf; i.Init = A_arbace_pprint_indent_fn__1820000199_A_Init; i.Table = A_arbace_pprint_indent_fn__1820000199_A_members; jrt.RegisterGoType(A_arbace_pprint_indent_fn__1820000199_A_class, reflect.TypeFor[A_arbace_pprint_indent_fn__1820000199_A]()) }

func A_arbace_pprint_indent_t_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_indent_t_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_indent_t_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_indent_t_QMARK__A_New()}; return nil }

func A_arbace_pprint_indent_t_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_indent_t_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_indent_t_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_indent_t_QMARK__A_invoke, New: A_arbace_pprint_indent_t_QMARK__A_new, Get: A_arbace_pprint_indent_t_QMARK__A_get}

var A_arbace_pprint_indent_t_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$indent_t_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "indent_t_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_indent_t_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_indent_t_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_indent_t_QMARK__A_Init; i.Table = A_arbace_pprint_indent_t_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_indent_t_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_indent_t_QMARK__A]()) }

func A_arbace_pprint_init_cap_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_init_cap_writer_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_init_cap_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_init_cap_writer_A_New()}; return nil }

func A_arbace_pprint_init_cap_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_init_cap_writer_A_fn_class)}; return nil }

var A_arbace_pprint_init_cap_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_init_cap_writer_A_invoke, New: A_arbace_pprint_init_cap_writer_A_new, Get: A_arbace_pprint_init_cap_writer_A_get}

var A_arbace_pprint_init_cap_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$init_cap_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "init_cap_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_init_cap_writer_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_init_cap_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_init_cap_writer_A_InstanceOf; i.Init = A_arbace_pprint_init_cap_writer_A_Init; i.Table = A_arbace_pprint_init_cap_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_init_cap_writer_A_class, reflect.TypeFor[A_arbace_pprint_init_cap_writer_A]()) }

func A_arbace_pprint_init_cap_writer_fn__1819000250_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_init_cap_writer_fn__1819000250_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000250_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_init_cap_writer_fn__1819000250_A_New_O(args[0])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000250_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_init_cap_writer_fn__1819000250_A_fn_class)}; return nil }

var A_arbace_pprint_init_cap_writer_fn__1819000250_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_init_cap_writer_fn__1819000250_A_invoke, New: A_arbace_pprint_init_cap_writer_fn__1819000250_A_new, Get: A_arbace_pprint_init_cap_writer_fn__1819000250_A_get}

var A_arbace_pprint_init_cap_writer_fn__1819000250_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$init_cap_writer$fn__1819000250", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_init_cap_writer_A_class, Simple: "fn__1819000250", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_init_cap_writer_fn__1819000250_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_init_cap_writer_fn__1819000250_A_class.Info(); i.IsInstance = A_arbace_pprint_init_cap_writer_fn__1819000250_A_InstanceOf; i.Init = A_arbace_pprint_init_cap_writer_fn__1819000250_A_Init; i.Table = A_arbace_pprint_init_cap_writer_fn__1819000250_A_members; jrt.RegisterGoType(A_arbace_pprint_init_cap_writer_fn__1819000250_A_class, reflect.TypeFor[A_arbace_pprint_init_cap_writer_fn__1819000250_A]()) }

func A_arbace_pprint_init_cap_writer_fn__1819000252_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_init_cap_writer_fn__1819000252_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000252_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_init_cap_writer_fn__1819000252_A_New_O(args[0])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000252_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_init_cap_writer_fn__1819000252_A_fn_class)}; return nil }

var A_arbace_pprint_init_cap_writer_fn__1819000252_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_init_cap_writer_fn__1819000252_A_invoke, New: A_arbace_pprint_init_cap_writer_fn__1819000252_A_new, Get: A_arbace_pprint_init_cap_writer_fn__1819000252_A_get}

var A_arbace_pprint_init_cap_writer_fn__1819000252_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$init_cap_writer$fn__1819000252", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_init_cap_writer_A_class, Simple: "fn__1819000252", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_init_cap_writer_fn__1819000252_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_init_cap_writer_fn__1819000252_A_class.Info(); i.IsInstance = A_arbace_pprint_init_cap_writer_fn__1819000252_A_InstanceOf; i.Init = A_arbace_pprint_init_cap_writer_fn__1819000252_A_Init; i.Table = A_arbace_pprint_init_cap_writer_fn__1819000252_A_members; jrt.RegisterGoType(A_arbace_pprint_init_cap_writer_fn__1819000252_A_class, reflect.TypeFor[A_arbace_pprint_init_cap_writer_fn__1819000252_A]()) }

func A_arbace_pprint_init_cap_writer_fn__1819000254_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_init_cap_writer_fn__1819000254_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_pprint_init_cap_writer_fn__1819000254_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000254_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_init_cap_writer_fn__1819000254_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000254_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_init_cap_writer_fn__1819000254_A_fn_class)}; return nil }

var A_arbace_pprint_init_cap_writer_fn__1819000254_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_init_cap_writer_fn__1819000254_A_invoke, New: A_arbace_pprint_init_cap_writer_fn__1819000254_A_new, Get: A_arbace_pprint_init_cap_writer_fn__1819000254_A_get}

var A_arbace_pprint_init_cap_writer_fn__1819000254_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$init_cap_writer$fn__1819000254", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_init_cap_writer_A_class, Simple: "fn__1819000254", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_init_cap_writer_fn__1819000254_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_init_cap_writer_fn__1819000254_A_class.Info(); i.IsInstance = A_arbace_pprint_init_cap_writer_fn__1819000254_A_InstanceOf; i.Init = A_arbace_pprint_init_cap_writer_fn__1819000254_A_Init; i.Table = A_arbace_pprint_init_cap_writer_fn__1819000254_A_members; jrt.RegisterGoType(A_arbace_pprint_init_cap_writer_fn__1819000254_A_class, reflect.TypeFor[A_arbace_pprint_init_cap_writer_fn__1819000254_A]()) }

func A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_New_O(args[0])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_fn_class)}; return nil }

var A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_invoke, New: A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_new, Get: A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_get}

var A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$init_cap_writer$fn__1819000254$fn__1819000257", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_init_cap_writer_fn__1819000254_A_class, Simple: "fn__1819000257", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_class.Info(); i.IsInstance = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_InstanceOf; i.Init = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_Init; i.Table = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_members; jrt.RegisterGoType(A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A_class, reflect.TypeFor[A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000257_A]()) }

func A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_New_O(args[0])}; return nil }

func A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_fn_class)}; return nil }

var A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_invoke, New: A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_new, Get: A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_get}

var A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$init_cap_writer$fn__1819000254$fn__1819000259", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_init_cap_writer_fn__1819000254_A_class, Simple: "fn__1819000259", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_class.Info(); i.IsInstance = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_InstanceOf; i.Init = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_Init; i.Table = A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_members; jrt.RegisterGoType(A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A_class, reflect.TypeFor[A_arbace_pprint_init_cap_writer_fn__1819000254_fn__1819000259_A]()) }

func A_arbace_pprint_init_navigator_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_init_navigator_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_init_navigator_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_init_navigator_A_New()}; return nil }

func A_arbace_pprint_init_navigator_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_init_navigator_A_fn_class)}; return nil }

var A_arbace_pprint_init_navigator_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_init_navigator_A_invoke, New: A_arbace_pprint_init_navigator_A_new, Get: A_arbace_pprint_init_navigator_A_get}

var A_arbace_pprint_init_navigator_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$init_navigator", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "init_navigator", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_init_navigator_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_init_navigator_A_class.Info(); i.IsInstance = A_arbace_pprint_init_navigator_A_InstanceOf; i.Init = A_arbace_pprint_init_navigator_A_Init; i.Table = A_arbace_pprint_init_navigator_A_members; jrt.RegisterGoType(A_arbace_pprint_init_navigator_A_class, reflect.TypeFor[A_arbace_pprint_init_navigator_A]()) }

func A_arbace_pprint_insert_decimal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_insert_decimal_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_insert_decimal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_insert_decimal_A_New()}; return nil }

func A_arbace_pprint_insert_decimal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_insert_decimal_A_fn_class)}; return nil }

var A_arbace_pprint_insert_decimal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_insert_decimal_A_invoke, New: A_arbace_pprint_insert_decimal_A_new, Get: A_arbace_pprint_insert_decimal_A_get}

var A_arbace_pprint_insert_decimal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$insert_decimal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "insert_decimal", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_insert_decimal_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_insert_decimal_A_class.Info(); i.IsInstance = A_arbace_pprint_insert_decimal_A_InstanceOf; i.Init = A_arbace_pprint_insert_decimal_A_Init; i.Table = A_arbace_pprint_insert_decimal_A_members; jrt.RegisterGoType(A_arbace_pprint_insert_decimal_A_class, reflect.TypeFor[A_arbace_pprint_insert_decimal_A]()) }

func A_arbace_pprint_insert_scaled_decimal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_insert_scaled_decimal_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_insert_scaled_decimal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_insert_scaled_decimal_A_New()}; return nil }

func A_arbace_pprint_insert_scaled_decimal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_insert_scaled_decimal_A_fn_class)}; return nil }

var A_arbace_pprint_insert_scaled_decimal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_insert_scaled_decimal_A_invoke, New: A_arbace_pprint_insert_scaled_decimal_A_new, Get: A_arbace_pprint_insert_scaled_decimal_A_get}

var A_arbace_pprint_insert_scaled_decimal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$insert_scaled_decimal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "insert_scaled_decimal", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_insert_scaled_decimal_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_insert_scaled_decimal_A_class.Info(); i.IsInstance = A_arbace_pprint_insert_scaled_decimal_A_InstanceOf; i.Init = A_arbace_pprint_insert_scaled_decimal_A_Init; i.Table = A_arbace_pprint_insert_scaled_decimal_A_members; jrt.RegisterGoType(A_arbace_pprint_insert_scaled_decimal_A_class, reflect.TypeFor[A_arbace_pprint_insert_scaled_decimal_A]()) }

func A_arbace_pprint_integral_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_integral_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_integral_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_integral_QMARK__A_New()}; return nil }

func A_arbace_pprint_integral_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_integral_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_integral_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_integral_QMARK__A_invoke, New: A_arbace_pprint_integral_QMARK__A_new, Get: A_arbace_pprint_integral_QMARK__A_get}

var A_arbace_pprint_integral_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$integral_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "integral_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_integral_QMARK__A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_integral_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_integral_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_integral_QMARK__A_Init; i.Table = A_arbace_pprint_integral_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_integral_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_integral_QMARK__A]()) }

func A_arbace_pprint_iterate_list_of_sublists_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_iterate_list_of_sublists_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_iterate_list_of_sublists_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_iterate_list_of_sublists_A_New()}; return nil }

func A_arbace_pprint_iterate_list_of_sublists_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_iterate_list_of_sublists_A_fn_class)}; return nil }

var A_arbace_pprint_iterate_list_of_sublists_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_iterate_list_of_sublists_A_invoke, New: A_arbace_pprint_iterate_list_of_sublists_A_new, Get: A_arbace_pprint_iterate_list_of_sublists_A_get}

var A_arbace_pprint_iterate_list_of_sublists_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$iterate_list_of_sublists", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "iterate_list_of_sublists", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_iterate_list_of_sublists_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_iterate_list_of_sublists_A_class.Info(); i.IsInstance = A_arbace_pprint_iterate_list_of_sublists_A_InstanceOf; i.Init = A_arbace_pprint_iterate_list_of_sublists_A_Init; i.Table = A_arbace_pprint_iterate_list_of_sublists_A_members; jrt.RegisterGoType(A_arbace_pprint_iterate_list_of_sublists_A_class, reflect.TypeFor[A_arbace_pprint_iterate_list_of_sublists_A]()) }

func A_arbace_pprint_iterate_main_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_iterate_main_list_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_iterate_main_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_iterate_main_list_A_New()}; return nil }

func A_arbace_pprint_iterate_main_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_iterate_main_list_A_fn_class)}; return nil }

var A_arbace_pprint_iterate_main_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_iterate_main_list_A_invoke, New: A_arbace_pprint_iterate_main_list_A_new, Get: A_arbace_pprint_iterate_main_list_A_get}

var A_arbace_pprint_iterate_main_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$iterate_main_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "iterate_main_list", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_iterate_main_list_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_iterate_main_list_A_class.Info(); i.IsInstance = A_arbace_pprint_iterate_main_list_A_InstanceOf; i.Init = A_arbace_pprint_iterate_main_list_A_Init; i.Table = A_arbace_pprint_iterate_main_list_A_members; jrt.RegisterGoType(A_arbace_pprint_iterate_main_list_A_class, reflect.TypeFor[A_arbace_pprint_iterate_main_list_A]()) }

func A_arbace_pprint_iterate_main_sublists_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_iterate_main_sublists_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_iterate_main_sublists_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_iterate_main_sublists_A_New()}; return nil }

func A_arbace_pprint_iterate_main_sublists_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_iterate_main_sublists_A_fn_class)}; return nil }

var A_arbace_pprint_iterate_main_sublists_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_iterate_main_sublists_A_invoke, New: A_arbace_pprint_iterate_main_sublists_A_new, Get: A_arbace_pprint_iterate_main_sublists_A_get}

var A_arbace_pprint_iterate_main_sublists_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$iterate_main_sublists", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "iterate_main_sublists", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_iterate_main_sublists_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_iterate_main_sublists_A_class.Info(); i.IsInstance = A_arbace_pprint_iterate_main_sublists_A_InstanceOf; i.Init = A_arbace_pprint_iterate_main_sublists_A_Init; i.Table = A_arbace_pprint_iterate_main_sublists_A_members; jrt.RegisterGoType(A_arbace_pprint_iterate_main_sublists_A_class, reflect.TypeFor[A_arbace_pprint_iterate_main_sublists_A]()) }

func A_arbace_pprint_iterate_sublist_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_iterate_sublist_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_iterate_sublist_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_iterate_sublist_A_New()}; return nil }

func A_arbace_pprint_iterate_sublist_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_iterate_sublist_A_fn_class)}; return nil }

var A_arbace_pprint_iterate_sublist_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_iterate_sublist_A_invoke, New: A_arbace_pprint_iterate_sublist_A_new, Get: A_arbace_pprint_iterate_sublist_A_get}

var A_arbace_pprint_iterate_sublist_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$iterate_sublist", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "iterate_sublist", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_iterate_sublist_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_iterate_sublist_A_class.Info(); i.IsInstance = A_arbace_pprint_iterate_sublist_A_InstanceOf; i.Init = A_arbace_pprint_iterate_sublist_A_Init; i.Table = A_arbace_pprint_iterate_sublist_A_members; jrt.RegisterGoType(A_arbace_pprint_iterate_sublist_A_class, reflect.TypeFor[A_arbace_pprint_iterate_sublist_A]()) }

func A_arbace_pprint_justify_clauses_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_justify_clauses_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_justify_clauses_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_justify_clauses_A_New()}; return nil }

func A_arbace_pprint_justify_clauses_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_justify_clauses_A_fn_class)}; return nil }

var A_arbace_pprint_justify_clauses_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_justify_clauses_A_invoke, New: A_arbace_pprint_justify_clauses_A_new, Get: A_arbace_pprint_justify_clauses_A_get}

var A_arbace_pprint_justify_clauses_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$justify_clauses", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "justify_clauses", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_justify_clauses_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_justify_clauses_A_class.Info(); i.IsInstance = A_arbace_pprint_justify_clauses_A_InstanceOf; i.Init = A_arbace_pprint_justify_clauses_A_Init; i.Table = A_arbace_pprint_justify_clauses_A_members; jrt.RegisterGoType(A_arbace_pprint_justify_clauses_A_class, reflect.TypeFor[A_arbace_pprint_justify_clauses_A]()) }

func A_arbace_pprint_level_exceeded_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_level_exceeded_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_level_exceeded_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_level_exceeded_A_New()}; return nil }

func A_arbace_pprint_level_exceeded_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_level_exceeded_A_fn_class)}; return nil }

var A_arbace_pprint_level_exceeded_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_level_exceeded_A_invoke, New: A_arbace_pprint_level_exceeded_A_new, Get: A_arbace_pprint_level_exceeded_A_get}

var A_arbace_pprint_level_exceeded_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$level_exceeded", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_A_class, Simple: "level_exceeded", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_level_exceeded_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_level_exceeded_A_class.Info(); i.IsInstance = A_arbace_pprint_level_exceeded_A_InstanceOf; i.Init = A_arbace_pprint_level_exceeded_A_Init; i.Table = A_arbace_pprint_level_exceeded_A_members; jrt.RegisterGoType(A_arbace_pprint_level_exceeded_A_class, reflect.TypeFor[A_arbace_pprint_level_exceeded_A]()) }

func A_arbace_pprint_linear_nl_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_linear_nl_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_linear_nl_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_linear_nl_QMARK__A_New()}; return nil }

func A_arbace_pprint_linear_nl_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_linear_nl_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_linear_nl_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_linear_nl_QMARK__A_invoke, New: A_arbace_pprint_linear_nl_QMARK__A_new, Get: A_arbace_pprint_linear_nl_QMARK__A_get}

var A_arbace_pprint_linear_nl_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$linear_nl_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "linear_nl_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_linear_nl_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_linear_nl_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_linear_nl_QMARK__A_Init; i.Table = A_arbace_pprint_linear_nl_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_linear_nl_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_linear_nl_QMARK__A]()) }

func A_arbace_pprint_logical_block_or_justify_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_logical_block_or_justify_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_logical_block_or_justify_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_logical_block_or_justify_A_New()}; return nil }

func A_arbace_pprint_logical_block_or_justify_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_logical_block_or_justify_A_fn_class)}; return nil }

var A_arbace_pprint_logical_block_or_justify_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_logical_block_or_justify_A_invoke, New: A_arbace_pprint_logical_block_or_justify_A_new, Get: A_arbace_pprint_logical_block_or_justify_A_get}

var A_arbace_pprint_logical_block_or_justify_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$logical_block_or_justify", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "logical_block_or_justify", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_logical_block_or_justify_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_logical_block_or_justify_A_class.Info(); i.IsInstance = A_arbace_pprint_logical_block_or_justify_A_InstanceOf; i.Init = A_arbace_pprint_logical_block_or_justify_A_Init; i.Table = A_arbace_pprint_logical_block_or_justify_A_members; jrt.RegisterGoType(A_arbace_pprint_logical_block_or_justify_A_class, reflect.TypeFor[A_arbace_pprint_logical_block_or_justify_A]()) }

func A_arbace_pprint_ltrim_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_ltrim_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_ltrim_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_ltrim_A_New()}; return nil }

func A_arbace_pprint_ltrim_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_ltrim_A_fn_class)}; return nil }

var A_arbace_pprint_ltrim_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_ltrim_A_invoke, New: A_arbace_pprint_ltrim_A_new, Get: A_arbace_pprint_ltrim_A_get}

var A_arbace_pprint_ltrim_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$ltrim", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "ltrim", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_ltrim_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_ltrim_A_class.Info(); i.IsInstance = A_arbace_pprint_ltrim_A_InstanceOf; i.Init = A_arbace_pprint_ltrim_A_Init; i.Table = A_arbace_pprint_ltrim_A_members; jrt.RegisterGoType(A_arbace_pprint_ltrim_A_class, reflect.TypeFor[A_arbace_pprint_ltrim_A]()) }

func A_arbace_pprint_make_buffer_blob_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_make_buffer_blob_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_make_buffer_blob_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_make_buffer_blob_A_New()}; return nil }

func A_arbace_pprint_make_buffer_blob_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_make_buffer_blob_A_fn_class)}; return nil }

var A_arbace_pprint_make_buffer_blob_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_make_buffer_blob_A_invoke, New: A_arbace_pprint_make_buffer_blob_A_new, Get: A_arbace_pprint_make_buffer_blob_A_get}

var A_arbace_pprint_make_buffer_blob_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$make_buffer_blob", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_A_class, Simple: "make_buffer_blob", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_make_buffer_blob_A_class.Info(); i.IsInstance = A_arbace_pprint_make_buffer_blob_A_InstanceOf; i.Init = A_arbace_pprint_make_buffer_blob_A_Init; i.Table = A_arbace_pprint_make_buffer_blob_A_members; jrt.RegisterGoType(A_arbace_pprint_make_buffer_blob_A_class, reflect.TypeFor[A_arbace_pprint_make_buffer_blob_A]()) }

func A_arbace_pprint_make_end_block_t_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_make_end_block_t_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_make_end_block_t_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_make_end_block_t_A_New()}; return nil }

func A_arbace_pprint_make_end_block_t_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_make_end_block_t_A_fn_class)}; return nil }

var A_arbace_pprint_make_end_block_t_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_make_end_block_t_A_invoke, New: A_arbace_pprint_make_end_block_t_A_new, Get: A_arbace_pprint_make_end_block_t_A_get}

var A_arbace_pprint_make_end_block_t_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$make_end_block_t", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_A_class, Simple: "make_end_block_t", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_make_end_block_t_A_class.Info(); i.IsInstance = A_arbace_pprint_make_end_block_t_A_InstanceOf; i.Init = A_arbace_pprint_make_end_block_t_A_Init; i.Table = A_arbace_pprint_make_end_block_t_A_members; jrt.RegisterGoType(A_arbace_pprint_make_end_block_t_A_class, reflect.TypeFor[A_arbace_pprint_make_end_block_t_A]()) }

func A_arbace_pprint_make_indent_t_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_make_indent_t_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_make_indent_t_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_make_indent_t_A_New()}; return nil }

func A_arbace_pprint_make_indent_t_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_make_indent_t_A_fn_class)}; return nil }

var A_arbace_pprint_make_indent_t_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_make_indent_t_A_invoke, New: A_arbace_pprint_make_indent_t_A_new, Get: A_arbace_pprint_make_indent_t_A_get}

var A_arbace_pprint_make_indent_t_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$make_indent_t", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_A_class, Simple: "make_indent_t", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_make_indent_t_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_make_indent_t_A_class.Info(); i.IsInstance = A_arbace_pprint_make_indent_t_A_InstanceOf; i.Init = A_arbace_pprint_make_indent_t_A_Init; i.Table = A_arbace_pprint_make_indent_t_A_members; jrt.RegisterGoType(A_arbace_pprint_make_indent_t_A_class, reflect.TypeFor[A_arbace_pprint_make_indent_t_A]()) }

func A_arbace_pprint_make_nl_t_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_make_nl_t_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_make_nl_t_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_make_nl_t_A_New()}; return nil }

func A_arbace_pprint_make_nl_t_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_make_nl_t_A_fn_class)}; return nil }

var A_arbace_pprint_make_nl_t_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_make_nl_t_A_invoke, New: A_arbace_pprint_make_nl_t_A_new, Get: A_arbace_pprint_make_nl_t_A_get}

var A_arbace_pprint_make_nl_t_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$make_nl_t", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_A_class, Simple: "make_nl_t", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_make_nl_t_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_make_nl_t_A_class.Info(); i.IsInstance = A_arbace_pprint_make_nl_t_A_InstanceOf; i.Init = A_arbace_pprint_make_nl_t_A_Init; i.Table = A_arbace_pprint_make_nl_t_A_members; jrt.RegisterGoType(A_arbace_pprint_make_nl_t_A_class, reflect.TypeFor[A_arbace_pprint_make_nl_t_A]()) }

func A_arbace_pprint_make_pretty_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_make_pretty_writer_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_make_pretty_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_make_pretty_writer_A_New()}; return nil }

func A_arbace_pprint_make_pretty_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_make_pretty_writer_A_fn_class)}; return nil }

var A_arbace_pprint_make_pretty_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_make_pretty_writer_A_invoke, New: A_arbace_pprint_make_pretty_writer_A_new, Get: A_arbace_pprint_make_pretty_writer_A_get}

var A_arbace_pprint_make_pretty_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$make_pretty_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "make_pretty_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_make_pretty_writer_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_make_pretty_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_make_pretty_writer_A_InstanceOf; i.Init = A_arbace_pprint_make_pretty_writer_A_Init; i.Table = A_arbace_pprint_make_pretty_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_make_pretty_writer_A_class, reflect.TypeFor[A_arbace_pprint_make_pretty_writer_A]()) }

func A_arbace_pprint_make_start_block_t_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_make_start_block_t_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_make_start_block_t_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_make_start_block_t_A_New()}; return nil }

func A_arbace_pprint_make_start_block_t_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_make_start_block_t_A_fn_class)}; return nil }

var A_arbace_pprint_make_start_block_t_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_make_start_block_t_A_invoke, New: A_arbace_pprint_make_start_block_t_A_new, Get: A_arbace_pprint_make_start_block_t_A_get}

var A_arbace_pprint_make_start_block_t_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$make_start_block_t", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_A_class, Simple: "make_start_block_t", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_make_start_block_t_A_class.Info(); i.IsInstance = A_arbace_pprint_make_start_block_t_A_InstanceOf; i.Init = A_arbace_pprint_make_start_block_t_A_Init; i.Table = A_arbace_pprint_make_start_block_t_A_members; jrt.RegisterGoType(A_arbace_pprint_make_start_block_t_A_class, reflect.TypeFor[A_arbace_pprint_make_start_block_t_A]()) }

func A_arbace_pprint_map_params_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_map_params_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_map_params_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_map_params_A_New()}; return nil }

func A_arbace_pprint_map_params_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_map_params_A_fn_class)}; return nil }

var A_arbace_pprint_map_params_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_map_params_A_invoke, New: A_arbace_pprint_map_params_A_new, Get: A_arbace_pprint_map_params_A_get}

var A_arbace_pprint_map_params_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$map_params", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_A_class, Simple: "map_params", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_map_params_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_map_params_A_class.Info(); i.IsInstance = A_arbace_pprint_map_params_A_InstanceOf; i.Init = A_arbace_pprint_map_params_A_Init; i.Table = A_arbace_pprint_map_params_A_members; jrt.RegisterGoType(A_arbace_pprint_map_params_A_class, reflect.TypeFor[A_arbace_pprint_map_params_A]()) }

func A_arbace_pprint_map_params_fn__1819000492_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_map_params_fn__1819000492_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_map_params_fn__1819000492_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_map_params_fn__1819000492_A_New_O(args[0])}; return nil }

func A_arbace_pprint_map_params_fn__1819000492_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_map_params_fn__1819000492_A_fn_class)}; return nil }

var A_arbace_pprint_map_params_fn__1819000492_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_map_params_fn__1819000492_A_invoke, New: A_arbace_pprint_map_params_fn__1819000492_A_new, Get: A_arbace_pprint_map_params_fn__1819000492_A_get}

var A_arbace_pprint_map_params_fn__1819000492_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$map_params$fn__1819000492", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_map_params_A_class, Simple: "fn__1819000492", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_map_params_fn__1819000492_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_map_params_fn__1819000492_A_class.Info(); i.IsInstance = A_arbace_pprint_map_params_fn__1819000492_A_InstanceOf; i.Init = A_arbace_pprint_map_params_fn__1819000492_A_Init; i.Table = A_arbace_pprint_map_params_fn__1819000492_A_members; jrt.RegisterGoType(A_arbace_pprint_map_params_fn__1819000492_A_class, reflect.TypeFor[A_arbace_pprint_map_params_fn__1819000492_A]()) }

func A_arbace_pprint_map_params_fn__1819000516_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_map_params_fn__1819000516_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_map_params_fn__1819000516_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_map_params_fn__1819000516_A_New()}; return nil }

func A_arbace_pprint_map_params_fn__1819000516_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_map_params_fn__1819000516_A_fn_class)}; return nil }

var A_arbace_pprint_map_params_fn__1819000516_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_map_params_fn__1819000516_A_invoke, New: A_arbace_pprint_map_params_fn__1819000516_A_new, Get: A_arbace_pprint_map_params_fn__1819000516_A_get}

var A_arbace_pprint_map_params_fn__1819000516_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$map_params$fn__1819000516", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_map_params_A_class, Simple: "fn__1819000516", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_map_params_fn__1819000516_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_map_params_fn__1819000516_A_class.Info(); i.IsInstance = A_arbace_pprint_map_params_fn__1819000516_A_InstanceOf; i.Init = A_arbace_pprint_map_params_fn__1819000516_A_Init; i.Table = A_arbace_pprint_map_params_fn__1819000516_A_members; jrt.RegisterGoType(A_arbace_pprint_map_params_fn__1819000516_A_class, reflect.TypeFor[A_arbace_pprint_map_params_fn__1819000516_A]()) }

func A_arbace_pprint_map_params_fn__1819000518_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_map_params_fn__1819000518_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_map_params_fn__1819000518_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_map_params_fn__1819000518_A_New()}; return nil }

func A_arbace_pprint_map_params_fn__1819000518_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_map_params_fn__1819000518_A_fn_class)}; return nil }

var A_arbace_pprint_map_params_fn__1819000518_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_map_params_fn__1819000518_A_invoke, New: A_arbace_pprint_map_params_fn__1819000518_A_new, Get: A_arbace_pprint_map_params_fn__1819000518_A_get}

var A_arbace_pprint_map_params_fn__1819000518_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$map_params$fn__1819000518", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_map_params_A_class, Simple: "fn__1819000518", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_map_params_fn__1819000518_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_map_params_fn__1819000518_A_class.Info(); i.IsInstance = A_arbace_pprint_map_params_fn__1819000518_A_InstanceOf; i.Init = A_arbace_pprint_map_params_fn__1819000518_A_Init; i.Table = A_arbace_pprint_map_params_fn__1819000518_A_members; jrt.RegisterGoType(A_arbace_pprint_map_params_fn__1819000518_A_class, reflect.TypeFor[A_arbace_pprint_map_params_fn__1819000518_A]()) }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_map_params_iter__1819000494__1819000498_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_map_params_iter__1819000494__1819000498_A_New_O(args[0])}; return nil }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_map_params_iter__1819000494__1819000498_A_fn_class)}; return nil }

var A_arbace_pprint_map_params_iter__1819000494__1819000498_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_map_params_iter__1819000494__1819000498_A_invoke, New: A_arbace_pprint_map_params_iter__1819000494__1819000498_A_new, Get: A_arbace_pprint_map_params_iter__1819000494__1819000498_A_get}

var A_arbace_pprint_map_params_iter__1819000494__1819000498_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$map_params$iter__1819000494__1819000498", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_map_params_A_class, Simple: "iter__1819000494__1819000498", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_map_params_iter__1819000494__1819000498_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_map_params_iter__1819000494__1819000498_A_class.Info(); i.IsInstance = A_arbace_pprint_map_params_iter__1819000494__1819000498_A_InstanceOf; i.Init = A_arbace_pprint_map_params_iter__1819000494__1819000498_A_Init; i.Table = A_arbace_pprint_map_params_iter__1819000494__1819000498_A_members; jrt.RegisterGoType(A_arbace_pprint_map_params_iter__1819000494__1819000498_A_class, reflect.TypeFor[A_arbace_pprint_map_params_iter__1819000494__1819000498_A]()) }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_fn_class)}; return nil }

var A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_invoke, New: A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_new, Get: A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_get}

var A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$map_params$iter__1819000494__1819000498$fn__1819000499", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_map_params_iter__1819000494__1819000498_A_class, Simple: "fn__1819000499", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_class.Info(); i.IsInstance = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_InstanceOf; i.Init = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_Init; i.Table = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_members; jrt.RegisterGoType(A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_class, reflect.TypeFor[A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A]()) }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_fn_class)}; return nil }

var A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_invoke, New: A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_new, Get: A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_get}

var A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$map_params$iter__1819000494__1819000498$fn__1819000499$fn__1819000500", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_A_class, Simple: "fn__1819000500", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_class.Info(); i.IsInstance = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_InstanceOf; i.Init = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_Init; i.Table = A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_members; jrt.RegisterGoType(A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A_class, reflect.TypeFor[A_arbace_pprint_map_params_iter__1819000494__1819000498_fn__1819000499_fn__1819000500_A]()) }

func A_arbace_pprint_map_passing_context_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_map_passing_context_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_map_passing_context_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_map_passing_context_A_New()}; return nil }

func A_arbace_pprint_map_passing_context_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_map_passing_context_A_fn_class)}; return nil }

var A_arbace_pprint_map_passing_context_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_map_passing_context_A_invoke, New: A_arbace_pprint_map_passing_context_A_new, Get: A_arbace_pprint_map_passing_context_A_get}

var A_arbace_pprint_map_passing_context_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$map_passing_context", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "map_passing_context", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_map_passing_context_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_map_passing_context_A_class.Info(); i.IsInstance = A_arbace_pprint_map_passing_context_A_InstanceOf; i.Init = A_arbace_pprint_map_passing_context_A_Init; i.Table = A_arbace_pprint_map_passing_context_A_members; jrt.RegisterGoType(A_arbace_pprint_map_passing_context_A_class, reflect.TypeFor[A_arbace_pprint_map_passing_context_A]()) }

func A_arbace_pprint_miser_nl_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_miser_nl_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_miser_nl_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_miser_nl_QMARK__A_New()}; return nil }

func A_arbace_pprint_miser_nl_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_miser_nl_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_miser_nl_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_miser_nl_QMARK__A_invoke, New: A_arbace_pprint_miser_nl_QMARK__A_new, Get: A_arbace_pprint_miser_nl_QMARK__A_get}

var A_arbace_pprint_miser_nl_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$miser_nl_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "miser_nl_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_miser_nl_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_miser_nl_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_miser_nl_QMARK__A_Init; i.Table = A_arbace_pprint_miser_nl_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_miser_nl_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_miser_nl_QMARK__A]()) }

func A_arbace_pprint_modify_case_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_modify_case_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_modify_case_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_modify_case_A_New()}; return nil }

func A_arbace_pprint_modify_case_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_modify_case_A_fn_class)}; return nil }

var A_arbace_pprint_modify_case_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_modify_case_A_invoke, New: A_arbace_pprint_modify_case_A_new, Get: A_arbace_pprint_modify_case_A_get}

var A_arbace_pprint_modify_case_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$modify_case", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_A_class, Simple: "modify_case", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_modify_case_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_modify_case_A_class.Info(); i.IsInstance = A_arbace_pprint_modify_case_A_InstanceOf; i.Init = A_arbace_pprint_modify_case_A_Init; i.Table = A_arbace_pprint_modify_case_A_members; jrt.RegisterGoType(A_arbace_pprint_modify_case_A_class, reflect.TypeFor[A_arbace_pprint_modify_case_A]()) }

func A_arbace_pprint_multi_defn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_multi_defn_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_multi_defn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_multi_defn_A_New()}; return nil }

func A_arbace_pprint_multi_defn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_multi_defn_A_fn_class)}; return nil }

var A_arbace_pprint_multi_defn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_multi_defn_A_invoke, New: A_arbace_pprint_multi_defn_A_new, Get: A_arbace_pprint_multi_defn_A_get}

var A_arbace_pprint_multi_defn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$multi_defn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "multi_defn", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_multi_defn_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_multi_defn_A_class.Info(); i.IsInstance = A_arbace_pprint_multi_defn_A_InstanceOf; i.Init = A_arbace_pprint_multi_defn_A_Init; i.Table = A_arbace_pprint_multi_defn_A_members; jrt.RegisterGoType(A_arbace_pprint_multi_defn_A_class, reflect.TypeFor[A_arbace_pprint_multi_defn_A]()) }

func A_arbace_pprint_multi_defn_fn__740000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_multi_defn_fn__740000118_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_multi_defn_fn__740000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_multi_defn_fn__740000118_A_New_O(args[0])}; return nil }

func A_arbace_pprint_multi_defn_fn__740000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_multi_defn_fn__740000118_A_fn_class)}; return nil }

var A_arbace_pprint_multi_defn_fn__740000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_multi_defn_fn__740000118_A_invoke, New: A_arbace_pprint_multi_defn_fn__740000118_A_new, Get: A_arbace_pprint_multi_defn_fn__740000118_A_get}

var A_arbace_pprint_multi_defn_fn__740000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$multi_defn$fn__740000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_multi_defn_A_class, Simple: "fn__740000118", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_multi_defn_fn__740000118_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_multi_defn_fn__740000118_A_class.Info(); i.IsInstance = A_arbace_pprint_multi_defn_fn__740000118_A_InstanceOf; i.Init = A_arbace_pprint_multi_defn_fn__740000118_A_Init; i.Table = A_arbace_pprint_multi_defn_fn__740000118_A_members; jrt.RegisterGoType(A_arbace_pprint_multi_defn_fn__740000118_A_class, reflect.TypeFor[A_arbace_pprint_multi_defn_fn__740000118_A]()) }

func A_arbace_pprint_needs_pretty_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_needs_pretty_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_needs_pretty_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_needs_pretty_A_New()}; return nil }

func A_arbace_pprint_needs_pretty_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_needs_pretty_A_fn_class)}; return nil }

var A_arbace_pprint_needs_pretty_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_needs_pretty_A_invoke, New: A_arbace_pprint_needs_pretty_A_new, Get: A_arbace_pprint_needs_pretty_A_get}

var A_arbace_pprint_needs_pretty_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$needs_pretty", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "needs_pretty", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_needs_pretty_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_needs_pretty_A_class.Info(); i.IsInstance = A_arbace_pprint_needs_pretty_A_InstanceOf; i.Init = A_arbace_pprint_needs_pretty_A_Init; i.Table = A_arbace_pprint_needs_pretty_A_members; jrt.RegisterGoType(A_arbace_pprint_needs_pretty_A_class, reflect.TypeFor[A_arbace_pprint_needs_pretty_A]()) }

func A_arbace_pprint_next_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_next_arg_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_next_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_next_arg_A_New()}; return nil }

func A_arbace_pprint_next_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_next_arg_A_fn_class)}; return nil }

var A_arbace_pprint_next_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_next_arg_A_invoke, New: A_arbace_pprint_next_arg_A_new, Get: A_arbace_pprint_next_arg_A_get}

var A_arbace_pprint_next_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$next_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "next_arg", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_next_arg_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_next_arg_A_class.Info(); i.IsInstance = A_arbace_pprint_next_arg_A_InstanceOf; i.Init = A_arbace_pprint_next_arg_A_Init; i.Table = A_arbace_pprint_next_arg_A_members; jrt.RegisterGoType(A_arbace_pprint_next_arg_A_class, reflect.TypeFor[A_arbace_pprint_next_arg_A]()) }

func A_arbace_pprint_next_arg_or_nil_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_next_arg_or_nil_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_next_arg_or_nil_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_next_arg_or_nil_A_New()}; return nil }

func A_arbace_pprint_next_arg_or_nil_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_next_arg_or_nil_A_fn_class)}; return nil }

var A_arbace_pprint_next_arg_or_nil_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_next_arg_or_nil_A_invoke, New: A_arbace_pprint_next_arg_or_nil_A_new, Get: A_arbace_pprint_next_arg_or_nil_A_get}

var A_arbace_pprint_next_arg_or_nil_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$next_arg_or_nil", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "next_arg_or_nil", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_next_arg_or_nil_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_next_arg_or_nil_A_class.Info(); i.IsInstance = A_arbace_pprint_next_arg_or_nil_A_InstanceOf; i.Init = A_arbace_pprint_next_arg_or_nil_A_Init; i.Table = A_arbace_pprint_next_arg_or_nil_A_members; jrt.RegisterGoType(A_arbace_pprint_next_arg_or_nil_A_class, reflect.TypeFor[A_arbace_pprint_next_arg_or_nil_A]()) }

func A_arbace_pprint_nl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_nl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_nl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_nl_A_New()}; return nil }

func A_arbace_pprint_nl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_nl_A_fn_class)}; return nil }

var A_arbace_pprint_nl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_nl_A_invoke, New: A_arbace_pprint_nl_A_new, Get: A_arbace_pprint_nl_A_get}

var A_arbace_pprint_nl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$nl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "nl", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_nl_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_nl_A_class.Info(); i.IsInstance = A_arbace_pprint_nl_A_InstanceOf; i.Init = A_arbace_pprint_nl_A_Init; i.Table = A_arbace_pprint_nl_A_members; jrt.RegisterGoType(A_arbace_pprint_nl_A_class, reflect.TypeFor[A_arbace_pprint_nl_A]()) }

func A_arbace_pprint_nl_fn__1820000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_nl_fn__1820000196_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_nl_fn__1820000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_nl_fn__1820000196_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_nl_fn__1820000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_nl_fn__1820000196_A_fn_class)}; return nil }

var A_arbace_pprint_nl_fn__1820000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_nl_fn__1820000196_A_invoke, New: A_arbace_pprint_nl_fn__1820000196_A_new, Get: A_arbace_pprint_nl_fn__1820000196_A_get}

var A_arbace_pprint_nl_fn__1820000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$nl$fn__1820000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_nl_A_class, Simple: "fn__1820000196", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_nl_fn__1820000196_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_nl_fn__1820000196_A_class.Info(); i.IsInstance = A_arbace_pprint_nl_fn__1820000196_A_InstanceOf; i.Init = A_arbace_pprint_nl_fn__1820000196_A_Init; i.Table = A_arbace_pprint_nl_fn__1820000196_A_members; jrt.RegisterGoType(A_arbace_pprint_nl_fn__1820000196_A_class, reflect.TypeFor[A_arbace_pprint_nl_fn__1820000196_A]()) }

func A_arbace_pprint_nl_t_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_nl_t_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_nl_t_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_nl_t_QMARK__A_New()}; return nil }

func A_arbace_pprint_nl_t_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_nl_t_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_nl_t_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_nl_t_QMARK__A_invoke, New: A_arbace_pprint_nl_t_QMARK__A_new, Get: A_arbace_pprint_nl_t_QMARK__A_get}

var A_arbace_pprint_nl_t_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$nl_t_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "nl_t_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_nl_t_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_nl_t_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_nl_t_QMARK__A_Init; i.Table = A_arbace_pprint_nl_t_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_nl_t_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_nl_t_QMARK__A]()) }

func A_arbace_pprint_opt_base_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_opt_base_str_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_opt_base_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_opt_base_str_A_New()}; return nil }

func A_arbace_pprint_opt_base_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_opt_base_str_A_fn_class)}; return nil }

var A_arbace_pprint_opt_base_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_opt_base_str_A_invoke, New: A_arbace_pprint_opt_base_str_A_new, Get: A_arbace_pprint_opt_base_str_A_get}

var A_arbace_pprint_opt_base_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$opt_base_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "opt_base_str", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_opt_base_str_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_opt_base_str_A_class.Info(); i.IsInstance = A_arbace_pprint_opt_base_str_A_InstanceOf; i.Init = A_arbace_pprint_opt_base_str_A_Init; i.Table = A_arbace_pprint_opt_base_str_A_members; jrt.RegisterGoType(A_arbace_pprint_opt_base_str_A_class, reflect.TypeFor[A_arbace_pprint_opt_base_str_A]()) }

func A_arbace_pprint_p_write_char_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_p_write_char_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_p_write_char_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_p_write_char_A_New()}; return nil }

func A_arbace_pprint_p_write_char_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_p_write_char_A_fn_class)}; return nil }

var A_arbace_pprint_p_write_char_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_p_write_char_A_invoke, New: A_arbace_pprint_p_write_char_A_new, Get: A_arbace_pprint_p_write_char_A_get}

var A_arbace_pprint_p_write_char_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$p_write_char", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "p_write_char", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_p_write_char_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_p_write_char_A_class.Info(); i.IsInstance = A_arbace_pprint_p_write_char_A_InstanceOf; i.Init = A_arbace_pprint_p_write_char_A_Init; i.Table = A_arbace_pprint_p_write_char_A_members; jrt.RegisterGoType(A_arbace_pprint_p_write_char_A_class, reflect.TypeFor[A_arbace_pprint_p_write_char_A]()) }

func A_arbace_pprint_p_write_char_fn__1820000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_p_write_char_fn__1820000170_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_p_write_char_fn__1820000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_p_write_char_fn__1820000170_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_p_write_char_fn__1820000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_p_write_char_fn__1820000170_A_fn_class)}; return nil }

var A_arbace_pprint_p_write_char_fn__1820000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_p_write_char_fn__1820000170_A_invoke, New: A_arbace_pprint_p_write_char_fn__1820000170_A_new, Get: A_arbace_pprint_p_write_char_fn__1820000170_A_get}

var A_arbace_pprint_p_write_char_fn__1820000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$p_write_char$fn__1820000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_p_write_char_A_class, Simple: "fn__1820000170", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_p_write_char_fn__1820000170_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_p_write_char_fn__1820000170_A_class.Info(); i.IsInstance = A_arbace_pprint_p_write_char_fn__1820000170_A_InstanceOf; i.Init = A_arbace_pprint_p_write_char_fn__1820000170_A_Init; i.Table = A_arbace_pprint_p_write_char_fn__1820000170_A_members; jrt.RegisterGoType(A_arbace_pprint_p_write_char_fn__1820000170_A_class, reflect.TypeFor[A_arbace_pprint_p_write_char_fn__1820000170_A]()) }

func A_arbace_pprint_parse_lb_options_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_parse_lb_options_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_parse_lb_options_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_parse_lb_options_A_New()}; return nil }

func A_arbace_pprint_parse_lb_options_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_parse_lb_options_A_fn_class)}; return nil }

var A_arbace_pprint_parse_lb_options_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_parse_lb_options_A_invoke, New: A_arbace_pprint_parse_lb_options_A_new, Get: A_arbace_pprint_parse_lb_options_A_get}

var A_arbace_pprint_parse_lb_options_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$parse_lb_options", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "parse_lb_options", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_parse_lb_options_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_parse_lb_options_A_class.Info(); i.IsInstance = A_arbace_pprint_parse_lb_options_A_InstanceOf; i.Init = A_arbace_pprint_parse_lb_options_A_Init; i.Table = A_arbace_pprint_parse_lb_options_A_members; jrt.RegisterGoType(A_arbace_pprint_parse_lb_options_A_class, reflect.TypeFor[A_arbace_pprint_parse_lb_options_A]()) }

func A_arbace_pprint_plain_character_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_plain_character_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_plain_character_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_plain_character_A_New()}; return nil }

func A_arbace_pprint_plain_character_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_plain_character_A_fn_class)}; return nil }

var A_arbace_pprint_plain_character_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_plain_character_A_invoke, New: A_arbace_pprint_plain_character_A_new, Get: A_arbace_pprint_plain_character_A_get}

var A_arbace_pprint_plain_character_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$plain_character", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "plain_character", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_plain_character_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_plain_character_A_class.Info(); i.IsInstance = A_arbace_pprint_plain_character_A_InstanceOf; i.Init = A_arbace_pprint_plain_character_A_Init; i.Table = A_arbace_pprint_plain_character_A_members; jrt.RegisterGoType(A_arbace_pprint_plain_character_A_class, reflect.TypeFor[A_arbace_pprint_plain_character_A]()) }

func A_arbace_pprint_pll_mod_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pll_mod_body_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_pll_mod_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pll_mod_body_A_New()}; return nil }

func A_arbace_pprint_pll_mod_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pll_mod_body_A_fn_class)}; return nil }

var A_arbace_pprint_pll_mod_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pll_mod_body_A_invoke, New: A_arbace_pprint_pll_mod_body_A_new, Get: A_arbace_pprint_pll_mod_body_A_get}

var A_arbace_pprint_pll_mod_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pll_mod_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "pll_mod_body", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pll_mod_body_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pll_mod_body_A_class.Info(); i.IsInstance = A_arbace_pprint_pll_mod_body_A_InstanceOf; i.Init = A_arbace_pprint_pll_mod_body_A_Init; i.Table = A_arbace_pprint_pll_mod_body_A_members; jrt.RegisterGoType(A_arbace_pprint_pll_mod_body_A_class, reflect.TypeFor[A_arbace_pprint_pll_mod_body_A]()) }

func A_arbace_pprint_pll_mod_body_inner__693000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pll_mod_body_inner__693000059_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pll_mod_body_inner__693000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pll_mod_body_inner__693000059_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pll_mod_body_inner__693000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pll_mod_body_inner__693000059_A_fn_class)}; return nil }

var A_arbace_pprint_pll_mod_body_inner__693000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pll_mod_body_inner__693000059_A_invoke, New: A_arbace_pprint_pll_mod_body_inner__693000059_A_new, Get: A_arbace_pprint_pll_mod_body_inner__693000059_A_get}

var A_arbace_pprint_pll_mod_body_inner__693000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pll_mod_body$inner__693000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_pll_mod_body_A_class, Simple: "inner__693000059", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pll_mod_body_inner__693000059_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pll_mod_body_inner__693000059_A_class.Info(); i.IsInstance = A_arbace_pprint_pll_mod_body_inner__693000059_A_InstanceOf; i.Init = A_arbace_pprint_pll_mod_body_inner__693000059_A_Init; i.Table = A_arbace_pprint_pll_mod_body_inner__693000059_A_members; jrt.RegisterGoType(A_arbace_pprint_pll_mod_body_inner__693000059_A_class, reflect.TypeFor[A_arbace_pprint_pll_mod_body_inner__693000059_A]()) }

func A_arbace_pprint_pp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pp_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_pp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pp_A_New()}; return nil }

func A_arbace_pprint_pp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pp_A_fn_class)}; return nil }

var A_arbace_pprint_pp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pp_A_invoke, New: A_arbace_pprint_pp_A_new, Get: A_arbace_pprint_pp_A_get}

var A_arbace_pprint_pp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "pp", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pp_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pp_A_class.Info(); i.IsInstance = A_arbace_pprint_pp_A_InstanceOf; i.Init = A_arbace_pprint_pp_A_Init; i.Table = A_arbace_pprint_pp_A_members; jrt.RegisterGoType(A_arbace_pprint_pp_A_class, reflect.TypeFor[A_arbace_pprint_pp_A]()) }

func A_arbace_pprint_pprint_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_pprint_pprint_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_pprint_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_A_New()}; return nil }

func A_arbace_pprint_pprint_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_A_invoke, New: A_arbace_pprint_pprint_A_new, Get: A_arbace_pprint_pprint_A_get}

var A_arbace_pprint_pprint_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pprint_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_A_InstanceOf; i.Init = A_arbace_pprint_pprint_A_Init; i.Table = A_arbace_pprint_pprint_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_A_class, reflect.TypeFor[A_arbace_pprint_pprint_A]()) }

func A_arbace_pprint_pprint_fn__693000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_fn__693000031_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_fn__693000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_fn__693000031_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_fn__693000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_fn__693000031_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_fn__693000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_fn__693000031_A_invoke, New: A_arbace_pprint_pprint_fn__693000031_A_new, Get: A_arbace_pprint_pprint_fn__693000031_A_get}

var A_arbace_pprint_pprint_fn__693000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint$fn__693000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_A_class, Simple: "fn__693000031", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_fn__693000031_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pprint_fn__693000031_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_fn__693000031_A_InstanceOf; i.Init = A_arbace_pprint_pprint_fn__693000031_A_Init; i.Table = A_arbace_pprint_pprint_fn__693000031_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_fn__693000031_A_class, reflect.TypeFor[A_arbace_pprint_pprint_fn__693000031_A]()) }

func A_arbace_pprint_pprint_anon_func_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_anon_func_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_anon_func_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_anon_func_A_New()}; return nil }

func A_arbace_pprint_pprint_anon_func_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_anon_func_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_anon_func_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_anon_func_A_invoke, New: A_arbace_pprint_pprint_anon_func_A_new, Get: A_arbace_pprint_pprint_anon_func_A_get}

var A_arbace_pprint_pprint_anon_func_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_anon_func", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_anon_func", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_anon_func_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_anon_func_A_InstanceOf; i.Init = A_arbace_pprint_pprint_anon_func_A_Init; i.Table = A_arbace_pprint_pprint_anon_func_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_anon_func_A_class, reflect.TypeFor[A_arbace_pprint_pprint_anon_func_A]()) }

func A_arbace_pprint_pprint_anon_func_fn__740000172_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_anon_func_fn__740000172_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_pprint_anon_func_fn__740000172_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_anon_func_fn__740000172_A_New()}; return nil }

func A_arbace_pprint_pprint_anon_func_fn__740000172_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_anon_func_fn__740000172_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_anon_func_fn__740000172_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_anon_func_fn__740000172_A_invoke, New: A_arbace_pprint_pprint_anon_func_fn__740000172_A_new, Get: A_arbace_pprint_pprint_anon_func_fn__740000172_A_get}

var A_arbace_pprint_pprint_anon_func_fn__740000172_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_anon_func$fn__740000172", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_pprint_anon_func_A_class, Simple: "fn__740000172", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_fn__740000172_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_anon_func_fn__740000172_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_anon_func_fn__740000172_A_InstanceOf; i.Init = A_arbace_pprint_pprint_anon_func_fn__740000172_A_Init; i.Table = A_arbace_pprint_pprint_anon_func_fn__740000172_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_anon_func_fn__740000172_A_class, reflect.TypeFor[A_arbace_pprint_pprint_anon_func_fn__740000172_A]()) }

func A_arbace_pprint_pprint_anon_func_fn__740000174_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_anon_func_fn__740000174_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_anon_func_fn__740000174_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_anon_func_fn__740000174_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_anon_func_fn__740000174_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_anon_func_fn__740000174_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_anon_func_fn__740000174_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_anon_func_fn__740000174_A_invoke, New: A_arbace_pprint_pprint_anon_func_fn__740000174_A_new, Get: A_arbace_pprint_pprint_anon_func_fn__740000174_A_get}

var A_arbace_pprint_pprint_anon_func_fn__740000174_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_anon_func$fn__740000174", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_anon_func_A_class, Simple: "fn__740000174", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_fn__740000174_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_anon_func_fn__740000174_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_anon_func_fn__740000174_A_InstanceOf; i.Init = A_arbace_pprint_pprint_anon_func_fn__740000174_A_Init; i.Table = A_arbace_pprint_pprint_anon_func_fn__740000174_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_anon_func_fn__740000174_A_class, reflect.TypeFor[A_arbace_pprint_pprint_anon_func_fn__740000174_A]()) }

func A_arbace_pprint_pprint_binding_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_binding_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_binding_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_binding_form_A_New()}; return nil }

func A_arbace_pprint_pprint_binding_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_binding_form_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_binding_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_binding_form_A_invoke, New: A_arbace_pprint_pprint_binding_form_A_new, Get: A_arbace_pprint_pprint_binding_form_A_get}

var A_arbace_pprint_pprint_binding_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_binding_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_binding_form", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_binding_form_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_binding_form_A_InstanceOf; i.Init = A_arbace_pprint_pprint_binding_form_A_Init; i.Table = A_arbace_pprint_pprint_binding_form_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_binding_form_A_class, reflect.TypeFor[A_arbace_pprint_pprint_binding_form_A]()) }

func A_arbace_pprint_pprint_binding_form_fn__740000139_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_binding_form_fn__740000139_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_binding_form_fn__740000139_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_binding_form_fn__740000139_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_binding_form_fn__740000139_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_binding_form_fn__740000139_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_binding_form_fn__740000139_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_binding_form_fn__740000139_A_invoke, New: A_arbace_pprint_pprint_binding_form_fn__740000139_A_new, Get: A_arbace_pprint_pprint_binding_form_fn__740000139_A_get}

var A_arbace_pprint_pprint_binding_form_fn__740000139_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_binding_form$fn__740000139", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_binding_form_A_class, Simple: "fn__740000139", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_fn__740000139_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_binding_form_fn__740000139_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_binding_form_fn__740000139_A_InstanceOf; i.Init = A_arbace_pprint_pprint_binding_form_fn__740000139_A_Init; i.Table = A_arbace_pprint_pprint_binding_form_fn__740000139_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_binding_form_fn__740000139_A_class, reflect.TypeFor[A_arbace_pprint_pprint_binding_form_fn__740000139_A]()) }

func A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_invoke, New: A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_new, Get: A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_get}

var A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_binding_form$fn__740000139$fn__740000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_binding_form_fn__740000139_A_class, Simple: "fn__740000141", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_InstanceOf; i.Init = A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_Init; i.Table = A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A_class, reflect.TypeFor[A_arbace_pprint_pprint_binding_form_fn__740000139_fn__740000141_A]()) }

func A_arbace_pprint_pprint_code_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_code_list_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_code_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_code_list_A_New()}; return nil }

func A_arbace_pprint_pprint_code_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_code_list_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_code_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_code_list_A_invoke, New: A_arbace_pprint_pprint_code_list_A_new, Get: A_arbace_pprint_pprint_code_list_A_get}

var A_arbace_pprint_pprint_code_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_code_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_code_list", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_code_list_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_code_list_A_InstanceOf; i.Init = A_arbace_pprint_pprint_code_list_A_Init; i.Table = A_arbace_pprint_pprint_code_list_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_code_list_A_class, reflect.TypeFor[A_arbace_pprint_pprint_code_list_A]()) }

func A_arbace_pprint_pprint_code_symbol_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_code_symbol_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_code_symbol_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_code_symbol_A_New()}; return nil }

func A_arbace_pprint_pprint_code_symbol_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_code_symbol_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_code_symbol_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_code_symbol_A_invoke, New: A_arbace_pprint_pprint_code_symbol_A_new, Get: A_arbace_pprint_pprint_code_symbol_A_get}

var A_arbace_pprint_pprint_code_symbol_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_code_symbol", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_code_symbol", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_code_symbol_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_code_symbol_A_InstanceOf; i.Init = A_arbace_pprint_pprint_code_symbol_A_Init; i.Table = A_arbace_pprint_pprint_code_symbol_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_code_symbol_A_class, reflect.TypeFor[A_arbace_pprint_pprint_code_symbol_A]()) }

func A_arbace_pprint_pprint_cond_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_cond_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_cond_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_cond_A_New()}; return nil }

func A_arbace_pprint_pprint_cond_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_cond_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_cond_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_cond_A_invoke, New: A_arbace_pprint_pprint_cond_A_new, Get: A_arbace_pprint_pprint_cond_A_get}

var A_arbace_pprint_pprint_cond_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_cond", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_cond", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_cond_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_cond_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_cond_A_InstanceOf; i.Init = A_arbace_pprint_pprint_cond_A_Init; i.Table = A_arbace_pprint_pprint_cond_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_cond_A_class, reflect.TypeFor[A_arbace_pprint_pprint_cond_A]()) }

func A_arbace_pprint_pprint_cond_fn__740000156_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_cond_fn__740000156_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_cond_fn__740000156_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_cond_fn__740000156_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_cond_fn__740000156_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_cond_fn__740000156_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_cond_fn__740000156_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_cond_fn__740000156_A_invoke, New: A_arbace_pprint_pprint_cond_fn__740000156_A_new, Get: A_arbace_pprint_pprint_cond_fn__740000156_A_get}

var A_arbace_pprint_pprint_cond_fn__740000156_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_cond$fn__740000156", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_cond_A_class, Simple: "fn__740000156", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_cond_fn__740000156_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_cond_fn__740000156_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_cond_fn__740000156_A_InstanceOf; i.Init = A_arbace_pprint_pprint_cond_fn__740000156_A_Init; i.Table = A_arbace_pprint_pprint_cond_fn__740000156_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_cond_fn__740000156_A_class, reflect.TypeFor[A_arbace_pprint_pprint_cond_fn__740000156_A]()) }

func A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_invoke, New: A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_new, Get: A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_get}

var A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_cond$fn__740000156$fn__740000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_cond_fn__740000156_A_class, Simple: "fn__740000158", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_InstanceOf; i.Init = A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_Init; i.Table = A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A_class, reflect.TypeFor[A_arbace_pprint_pprint_cond_fn__740000156_fn__740000158_A]()) }

func A_arbace_pprint_pprint_condp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_condp_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_condp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_condp_A_New()}; return nil }

func A_arbace_pprint_pprint_condp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_condp_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_condp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_condp_A_invoke, New: A_arbace_pprint_pprint_condp_A_new, Get: A_arbace_pprint_pprint_condp_A_get}

var A_arbace_pprint_pprint_condp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_condp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_condp", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_condp_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_condp_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_condp_A_InstanceOf; i.Init = A_arbace_pprint_pprint_condp_A_Init; i.Table = A_arbace_pprint_pprint_condp_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_condp_A_class, reflect.TypeFor[A_arbace_pprint_pprint_condp_A]()) }

func A_arbace_pprint_pprint_condp_fn__740000162_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_condp_fn__740000162_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_condp_fn__740000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_condp_fn__740000162_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_condp_fn__740000162_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_condp_fn__740000162_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_condp_fn__740000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_condp_fn__740000162_A_invoke, New: A_arbace_pprint_pprint_condp_fn__740000162_A_new, Get: A_arbace_pprint_pprint_condp_fn__740000162_A_get}

var A_arbace_pprint_pprint_condp_fn__740000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_condp$fn__740000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_condp_A_class, Simple: "fn__740000162", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_condp_fn__740000162_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_condp_fn__740000162_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_condp_fn__740000162_A_InstanceOf; i.Init = A_arbace_pprint_pprint_condp_fn__740000162_A_Init; i.Table = A_arbace_pprint_pprint_condp_fn__740000162_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_condp_fn__740000162_A_class, reflect.TypeFor[A_arbace_pprint_pprint_condp_fn__740000162_A]()) }

func A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_invoke, New: A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_new, Get: A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_get}

var A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_condp$fn__740000162$fn__740000163", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_condp_fn__740000162_A_class, Simple: "fn__740000163", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_InstanceOf; i.Init = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_Init; i.Table = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A_class, reflect.TypeFor[A_arbace_pprint_pprint_condp_fn__740000162_fn__740000163_A]()) }

func A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_invoke, New: A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_new, Get: A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_get}

var A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_condp$fn__740000162$fn__740000166", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_condp_fn__740000162_A_class, Simple: "fn__740000166", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_InstanceOf; i.Init = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_Init; i.Table = A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A_class, reflect.TypeFor[A_arbace_pprint_pprint_condp_fn__740000162_fn__740000166_A]()) }

func A_arbace_pprint_pprint_defn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_defn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_defn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_defn_A_New()}; return nil }

func A_arbace_pprint_pprint_defn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_defn_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_defn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_defn_A_invoke, New: A_arbace_pprint_pprint_defn_A_new, Get: A_arbace_pprint_pprint_defn_A_get}

var A_arbace_pprint_pprint_defn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_defn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_defn", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_defn_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_defn_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_defn_A_InstanceOf; i.Init = A_arbace_pprint_pprint_defn_A_Init; i.Table = A_arbace_pprint_pprint_defn_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_defn_A_class, reflect.TypeFor[A_arbace_pprint_pprint_defn_A]()) }

func A_arbace_pprint_pprint_defn_fn__740000130_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_defn_fn__740000130_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_defn_fn__740000130_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_defn_fn__740000130_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_pprint_defn_fn__740000130_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_defn_fn__740000130_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_defn_fn__740000130_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_defn_fn__740000130_A_invoke, New: A_arbace_pprint_pprint_defn_fn__740000130_A_new, Get: A_arbace_pprint_pprint_defn_fn__740000130_A_get}

var A_arbace_pprint_pprint_defn_fn__740000130_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_defn$fn__740000130", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_defn_A_class, Simple: "fn__740000130", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_defn_fn__740000130_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_defn_fn__740000130_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_defn_fn__740000130_A_InstanceOf; i.Init = A_arbace_pprint_pprint_defn_fn__740000130_A_Init; i.Table = A_arbace_pprint_pprint_defn_fn__740000130_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_defn_fn__740000130_A_class, reflect.TypeFor[A_arbace_pprint_pprint_defn_fn__740000130_A]()) }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_invoke, New: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_new, Get: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_get}

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_defn$fn__740000130$fn__740000131", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_defn_fn__740000130_A_class, Simple: "fn__740000131", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_InstanceOf; i.Init = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_Init; i.Table = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A_class, reflect.TypeFor[A_arbace_pprint_pprint_defn_fn__740000130_fn__740000131_A]()) }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_invoke, New: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_new, Get: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_get}

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_defn$fn__740000130$fn__740000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_defn_fn__740000130_A_class, Simple: "fn__740000133", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_InstanceOf; i.Init = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_Init; i.Table = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A_class, reflect.TypeFor[A_arbace_pprint_pprint_defn_fn__740000130_fn__740000133_A]()) }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_invoke, New: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_new, Get: A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_get}

var A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_defn$fn__740000130$fn__740000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_defn_fn__740000130_A_class, Simple: "fn__740000135", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_InstanceOf; i.Init = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_Init; i.Table = A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A_class, reflect.TypeFor[A_arbace_pprint_pprint_defn_fn__740000130_fn__740000135_A]()) }

func A_arbace_pprint_pprint_ideref_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ideref_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ideref_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ideref_A_New()}; return nil }

func A_arbace_pprint_pprint_ideref_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ideref_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ideref_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ideref_A_invoke, New: A_arbace_pprint_pprint_ideref_A_new, Get: A_arbace_pprint_pprint_ideref_A_get}

var A_arbace_pprint_pprint_ideref_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ideref", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_ideref", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ideref_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ideref_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ideref_A_Init; i.Table = A_arbace_pprint_pprint_ideref_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ideref_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ideref_A]()) }

func A_arbace_pprint_pprint_indent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_indent_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_pprint_indent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_indent_A_New()}; return nil }

func A_arbace_pprint_pprint_indent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_indent_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_indent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_indent_A_invoke, New: A_arbace_pprint_pprint_indent_A_new, Get: A_arbace_pprint_pprint_indent_A_get}

var A_arbace_pprint_pprint_indent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_indent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_indent", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_indent_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pprint_indent_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_indent_A_InstanceOf; i.Init = A_arbace_pprint_pprint_indent_A_Init; i.Table = A_arbace_pprint_pprint_indent_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_indent_A_class, reflect.TypeFor[A_arbace_pprint_pprint_indent_A]()) }

func A_arbace_pprint_pprint_let_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_let_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_let_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_let_A_New()}; return nil }

func A_arbace_pprint_pprint_let_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_let_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_let_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_let_A_invoke, New: A_arbace_pprint_pprint_let_A_new, Get: A_arbace_pprint_pprint_let_A_get}

var A_arbace_pprint_pprint_let_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_let", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_let", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_let_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_let_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_let_A_InstanceOf; i.Init = A_arbace_pprint_pprint_let_A_Init; i.Table = A_arbace_pprint_pprint_let_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_let_A_class, reflect.TypeFor[A_arbace_pprint_pprint_let_A]()) }

func A_arbace_pprint_pprint_let_fn__740000145_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_let_fn__740000145_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_let_fn__740000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_let_fn__740000145_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_let_fn__740000145_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_let_fn__740000145_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_let_fn__740000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_let_fn__740000145_A_invoke, New: A_arbace_pprint_pprint_let_fn__740000145_A_new, Get: A_arbace_pprint_pprint_let_fn__740000145_A_get}

var A_arbace_pprint_pprint_let_fn__740000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_let$fn__740000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_let_A_class, Simple: "fn__740000145", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_let_fn__740000145_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_let_fn__740000145_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_let_fn__740000145_A_InstanceOf; i.Init = A_arbace_pprint_pprint_let_fn__740000145_A_Init; i.Table = A_arbace_pprint_pprint_let_fn__740000145_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_let_fn__740000145_A_class, reflect.TypeFor[A_arbace_pprint_pprint_let_fn__740000145_A]()) }

func A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_invoke, New: A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_new, Get: A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_get}

var A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_let$fn__740000145$fn__740000146", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_let_fn__740000145_A_class, Simple: "fn__740000146", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_InstanceOf; i.Init = A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_Init; i.Table = A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A_class, reflect.TypeFor[A_arbace_pprint_pprint_let_fn__740000145_fn__740000146_A]()) }

func A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_invoke, New: A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_new, Get: A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_get}

var A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_let$fn__740000145$fn__740000148", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_let_fn__740000145_A_class, Simple: "fn__740000148", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_InstanceOf; i.Init = A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_Init; i.Table = A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A_class, reflect.TypeFor[A_arbace_pprint_pprint_let_fn__740000145_fn__740000148_A]()) }

func A_arbace_pprint_pprint_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_list_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_list_A_New()}; return nil }

func A_arbace_pprint_pprint_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_list_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_list_A_invoke, New: A_arbace_pprint_pprint_list_A_new, Get: A_arbace_pprint_pprint_list_A_get}

var A_arbace_pprint_pprint_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_list", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_list_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_list_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_list_A_InstanceOf; i.Init = A_arbace_pprint_pprint_list_A_Init; i.Table = A_arbace_pprint_pprint_list_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_list_A_class, reflect.TypeFor[A_arbace_pprint_pprint_list_A]()) }

func A_arbace_pprint_pprint_logical_block_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_logical_block_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_pprint_logical_block_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_logical_block_A_New()}; return nil }

func A_arbace_pprint_pprint_logical_block_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_logical_block_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_logical_block_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_logical_block_A_invoke, New: A_arbace_pprint_pprint_logical_block_A_new, Get: A_arbace_pprint_pprint_logical_block_A_get}

var A_arbace_pprint_pprint_logical_block_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_logical_block", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_logical_block", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_logical_block_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pprint_logical_block_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_logical_block_A_InstanceOf; i.Init = A_arbace_pprint_pprint_logical_block_A_Init; i.Table = A_arbace_pprint_pprint_logical_block_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_logical_block_A_class, reflect.TypeFor[A_arbace_pprint_pprint_logical_block_A]()) }

func A_arbace_pprint_pprint_map_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_map_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_map_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_map_A_New()}; return nil }

func A_arbace_pprint_pprint_map_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_map_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_map_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_map_A_invoke, New: A_arbace_pprint_pprint_map_A_new, Get: A_arbace_pprint_pprint_map_A_get}

var A_arbace_pprint_pprint_map_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_map", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_map", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_map_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_map_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_map_A_InstanceOf; i.Init = A_arbace_pprint_pprint_map_A_Init; i.Table = A_arbace_pprint_pprint_map_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_map_A_class, reflect.TypeFor[A_arbace_pprint_pprint_map_A]()) }

func A_arbace_pprint_pprint_map_fn__740000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_map_fn__740000021_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_map_fn__740000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_map_fn__740000021_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_map_fn__740000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_map_fn__740000021_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_map_fn__740000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_map_fn__740000021_A_invoke, New: A_arbace_pprint_pprint_map_fn__740000021_A_new, Get: A_arbace_pprint_pprint_map_fn__740000021_A_get}

var A_arbace_pprint_pprint_map_fn__740000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_map$fn__740000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_map_A_class, Simple: "fn__740000021", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_map_fn__740000021_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_map_fn__740000021_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_map_fn__740000021_A_InstanceOf; i.Init = A_arbace_pprint_pprint_map_fn__740000021_A_Init; i.Table = A_arbace_pprint_pprint_map_fn__740000021_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_map_fn__740000021_A_class, reflect.TypeFor[A_arbace_pprint_pprint_map_fn__740000021_A]()) }

func A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_invoke, New: A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_new, Get: A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_get}

var A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_map$fn__740000021$fn__740000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_map_fn__740000021_A_class, Simple: "fn__740000023", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_InstanceOf; i.Init = A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_Init; i.Table = A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A_class, reflect.TypeFor[A_arbace_pprint_pprint_map_fn__740000021_fn__740000023_A]()) }

func A_arbace_pprint_pprint_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_meta_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_meta_A_New()}; return nil }

func A_arbace_pprint_pprint_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_meta_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_meta_A_invoke, New: A_arbace_pprint_pprint_meta_A_new, Get: A_arbace_pprint_pprint_meta_A_get}

var A_arbace_pprint_pprint_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_meta", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_meta_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_meta_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_meta_A_InstanceOf; i.Init = A_arbace_pprint_pprint_meta_A_Init; i.Table = A_arbace_pprint_pprint_meta_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_meta_A_class, reflect.TypeFor[A_arbace_pprint_pprint_meta_A]()) }

func A_arbace_pprint_pprint_newline_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_newline_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_newline_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_newline_A_New()}; return nil }

func A_arbace_pprint_pprint_newline_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_newline_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_newline_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_newline_A_invoke, New: A_arbace_pprint_pprint_newline_A_new, Get: A_arbace_pprint_pprint_newline_A_get}

var A_arbace_pprint_pprint_newline_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_newline", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_newline", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_newline_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pprint_newline_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_newline_A_InstanceOf; i.Init = A_arbace_pprint_pprint_newline_A_Init; i.Table = A_arbace_pprint_pprint_newline_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_newline_A_class, reflect.TypeFor[A_arbace_pprint_pprint_newline_A]()) }

func A_arbace_pprint_pprint_ns_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_A_New()}; return nil }

func A_arbace_pprint_pprint_ns_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_A_invoke, New: A_arbace_pprint_pprint_ns_A_new, Get: A_arbace_pprint_pprint_ns_A_get}

var A_arbace_pprint_pprint_ns_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_ns", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_A_Init; i.Table = A_arbace_pprint_pprint_ns_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_A]()) }

func A_arbace_pprint_pprint_ns_fn__740000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_fn__740000098_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_fn__740000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_fn__740000098_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_pprint_ns_fn__740000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_fn__740000098_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_fn__740000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_fn__740000098_A_invoke, New: A_arbace_pprint_pprint_ns_fn__740000098_A_new, Get: A_arbace_pprint_pprint_ns_fn__740000098_A_get}

var A_arbace_pprint_pprint_ns_fn__740000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns$fn__740000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_ns_A_class, Simple: "fn__740000098", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_fn__740000098_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_fn__740000098_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_fn__740000098_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_fn__740000098_A_Init; i.Table = A_arbace_pprint_pprint_ns_fn__740000098_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_fn__740000098_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_fn__740000098_A]()) }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_invoke, New: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_new, Get: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_get}

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns$fn__740000098$fn__740000099", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_fn__740000098_A_class, Simple: "fn__740000099", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_Init; i.Table = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_fn__740000098_fn__740000099_A]()) }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_invoke, New: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_new, Get: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_get}

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns$fn__740000098$fn__740000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_fn__740000098_A_class, Simple: "fn__740000101", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_Init; i.Table = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_fn__740000098_fn__740000101_A]()) }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_invoke, New: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_new, Get: A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_get}

var A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns$fn__740000098$fn__740000103", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_fn__740000098_A_class, Simple: "fn__740000103", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_Init; i.Table = A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_fn__740000098_fn__740000103_A]()) }

func A_arbace_pprint_pprint_ns_reference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_reference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_A_New()}; return nil }

func A_arbace_pprint_pprint_ns_reference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_A_invoke, New: A_arbace_pprint_pprint_ns_reference_A_new, Get: A_arbace_pprint_pprint_ns_reference_A_get}

var A_arbace_pprint_pprint_ns_reference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_ns_reference", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_A_class, Simple: "fn__740000064", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_fn__740000064_A_class, Simple: "fn__740000065", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000065_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_fn__740000064_A_class, Simple: "fn__740000067", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000067_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_fn__740000064_A_class, Simple: "fn__740000072", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000072$fn__740000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_class, Simple: "fn__740000076", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000076_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000072$fn__740000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_class, Simple: "fn__740000078", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000078_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000072$fn__740000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_A_class, Simple: "fn__740000080", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000072_fn__740000080_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000083", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_fn__740000064_A_class, Simple: "fn__740000083", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000083_A]()) }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_invoke, New: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_new, Get: A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_get}

var A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_pprint_ns_reference_fn__740000064_A_class, Simple: "fn__740000085", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_InstanceOf; i.Init = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_Init; i.Table = A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A_class, reflect.TypeFor[A_arbace_pprint_pprint_ns_reference_fn__740000064_fn__740000085_A]()) }

func A_arbace_pprint_pprint_reader_macro_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_reader_macro_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_reader_macro_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_reader_macro_A_New()}; return nil }

func A_arbace_pprint_pprint_reader_macro_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_reader_macro_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_reader_macro_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_reader_macro_A_invoke, New: A_arbace_pprint_pprint_reader_macro_A_new, Get: A_arbace_pprint_pprint_reader_macro_A_get}

var A_arbace_pprint_pprint_reader_macro_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_reader_macro", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_reader_macro", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_reader_macro_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_reader_macro_A_InstanceOf; i.Init = A_arbace_pprint_pprint_reader_macro_A_Init; i.Table = A_arbace_pprint_pprint_reader_macro_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_reader_macro_A_class, reflect.TypeFor[A_arbace_pprint_pprint_reader_macro_A]()) }

func A_arbace_pprint_pprint_set_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_set_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_set_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_set_A_New()}; return nil }

func A_arbace_pprint_pprint_set_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_set_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_set_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_set_A_invoke, New: A_arbace_pprint_pprint_set_A_new, Get: A_arbace_pprint_pprint_set_A_get}

var A_arbace_pprint_pprint_set_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_set", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_set", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_set_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_set_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_set_A_InstanceOf; i.Init = A_arbace_pprint_pprint_set_A_Init; i.Table = A_arbace_pprint_pprint_set_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_set_A_class, reflect.TypeFor[A_arbace_pprint_pprint_set_A]()) }

func A_arbace_pprint_pprint_set_fn__740000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_set_fn__740000027_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_set_fn__740000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_set_fn__740000027_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_set_fn__740000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_set_fn__740000027_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_set_fn__740000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_set_fn__740000027_A_invoke, New: A_arbace_pprint_pprint_set_fn__740000027_A_new, Get: A_arbace_pprint_pprint_set_fn__740000027_A_get}

var A_arbace_pprint_pprint_set_fn__740000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_set$fn__740000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_set_A_class, Simple: "fn__740000027", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_set_fn__740000027_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_set_fn__740000027_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_set_fn__740000027_A_InstanceOf; i.Init = A_arbace_pprint_pprint_set_fn__740000027_A_Init; i.Table = A_arbace_pprint_pprint_set_fn__740000027_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_set_fn__740000027_A_class, reflect.TypeFor[A_arbace_pprint_pprint_set_fn__740000027_A]()) }

func A_arbace_pprint_pprint_simple_code_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_simple_code_list_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_simple_code_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_simple_code_list_A_New()}; return nil }

func A_arbace_pprint_pprint_simple_code_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_simple_code_list_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_simple_code_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_simple_code_list_A_invoke, New: A_arbace_pprint_pprint_simple_code_list_A_new, Get: A_arbace_pprint_pprint_simple_code_list_A_get}

var A_arbace_pprint_pprint_simple_code_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_simple_code_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_simple_code_list", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_simple_code_list_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_simple_code_list_A_InstanceOf; i.Init = A_arbace_pprint_pprint_simple_code_list_A_Init; i.Table = A_arbace_pprint_pprint_simple_code_list_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_simple_code_list_A_class, reflect.TypeFor[A_arbace_pprint_pprint_simple_code_list_A]()) }

func A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_simple_code_list_fn__740000177_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_invoke, New: A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_new, Get: A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_get}

var A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_simple_code_list$fn__740000177", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_simple_code_list_A_class, Simple: "fn__740000177", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_fn__740000177_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_InstanceOf; i.Init = A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_Init; i.Table = A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_simple_code_list_fn__740000177_A_class, reflect.TypeFor[A_arbace_pprint_pprint_simple_code_list_fn__740000177_A]()) }

func A_arbace_pprint_pprint_simple_default_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_simple_default_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_simple_default_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_simple_default_A_New()}; return nil }

func A_arbace_pprint_pprint_simple_default_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_simple_default_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_simple_default_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_simple_default_A_invoke, New: A_arbace_pprint_pprint_simple_default_A_new, Get: A_arbace_pprint_pprint_simple_default_A_get}

var A_arbace_pprint_pprint_simple_default_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_simple_default", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_simple_default", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_simple_default_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_simple_default_A_InstanceOf; i.Init = A_arbace_pprint_pprint_simple_default_A_Init; i.Table = A_arbace_pprint_pprint_simple_default_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_simple_default_A_class, reflect.TypeFor[A_arbace_pprint_pprint_simple_default_A]()) }

func A_arbace_pprint_pprint_simple_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_simple_list_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_simple_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_simple_list_A_New()}; return nil }

func A_arbace_pprint_pprint_simple_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_simple_list_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_simple_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_simple_list_A_invoke, New: A_arbace_pprint_pprint_simple_list_A_new, Get: A_arbace_pprint_pprint_simple_list_A_get}

var A_arbace_pprint_pprint_simple_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_simple_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_simple_list", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_simple_list_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_simple_list_A_InstanceOf; i.Init = A_arbace_pprint_pprint_simple_list_A_Init; i.Table = A_arbace_pprint_pprint_simple_list_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_simple_list_A_class, reflect.TypeFor[A_arbace_pprint_pprint_simple_list_A]()) }

func A_arbace_pprint_pprint_simple_list_fn__740000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_simple_list_fn__740000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_simple_list_fn__740000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_simple_list_fn__740000005_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_simple_list_fn__740000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_simple_list_fn__740000005_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_simple_list_fn__740000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_simple_list_fn__740000005_A_invoke, New: A_arbace_pprint_pprint_simple_list_fn__740000005_A_new, Get: A_arbace_pprint_pprint_simple_list_fn__740000005_A_get}

var A_arbace_pprint_pprint_simple_list_fn__740000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_simple_list$fn__740000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_simple_list_A_class, Simple: "fn__740000005", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_fn__740000005_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_simple_list_fn__740000005_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_simple_list_fn__740000005_A_InstanceOf; i.Init = A_arbace_pprint_pprint_simple_list_fn__740000005_A_Init; i.Table = A_arbace_pprint_pprint_simple_list_fn__740000005_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_simple_list_fn__740000005_A_class, reflect.TypeFor[A_arbace_pprint_pprint_simple_list_fn__740000005_A]()) }

func A_arbace_pprint_pprint_tab_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_tab_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_pprint_tab_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_tab_A_New()}; return nil }

func A_arbace_pprint_pprint_tab_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_tab_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_tab_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_tab_A_invoke, New: A_arbace_pprint_pprint_tab_A_new, Get: A_arbace_pprint_pprint_tab_A_get}

var A_arbace_pprint_pprint_tab_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_tab", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_tab", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_tab_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pprint_tab_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_tab_A_InstanceOf; i.Init = A_arbace_pprint_pprint_tab_A_Init; i.Table = A_arbace_pprint_pprint_tab_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_tab_A_class, reflect.TypeFor[A_arbace_pprint_pprint_tab_A]()) }

func A_arbace_pprint_pprint_vector_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_vector_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pprint_vector_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_vector_A_New()}; return nil }

func A_arbace_pprint_pprint_vector_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_vector_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_vector_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_vector_A_invoke, New: A_arbace_pprint_pprint_vector_A_new, Get: A_arbace_pprint_pprint_vector_A_get}

var A_arbace_pprint_pprint_vector_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_vector", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pprint_vector", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_vector_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_vector_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_vector_A_InstanceOf; i.Init = A_arbace_pprint_pprint_vector_A_Init; i.Table = A_arbace_pprint_pprint_vector_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_vector_A_class, reflect.TypeFor[A_arbace_pprint_pprint_vector_A]()) }

func A_arbace_pprint_pprint_vector_fn__740000010_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pprint_vector_fn__740000010_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pprint_vector_fn__740000010_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pprint_vector_fn__740000010_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pprint_vector_fn__740000010_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pprint_vector_fn__740000010_A_fn_class)}; return nil }

var A_arbace_pprint_pprint_vector_fn__740000010_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pprint_vector_fn__740000010_A_invoke, New: A_arbace_pprint_pprint_vector_fn__740000010_A_new, Get: A_arbace_pprint_pprint_vector_fn__740000010_A_get}

var A_arbace_pprint_pprint_vector_fn__740000010_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pprint_vector$fn__740000010", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pprint_vector_A_class, Simple: "fn__740000010", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pprint_vector_fn__740000010_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_pprint_vector_fn__740000010_A_class.Info(); i.IsInstance = A_arbace_pprint_pprint_vector_fn__740000010_A_InstanceOf; i.Init = A_arbace_pprint_pprint_vector_fn__740000010_A_Init; i.Table = A_arbace_pprint_pprint_vector_fn__740000010_A_members; jrt.RegisterGoType(A_arbace_pprint_pprint_vector_fn__740000010_A_class, reflect.TypeFor[A_arbace_pprint_pprint_vector_fn__740000010_A]()) }

func A_arbace_pprint_pr_with_base_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pr_with_base_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pr_with_base_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pr_with_base_A_New()}; return nil }

func A_arbace_pprint_pr_with_base_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pr_with_base_A_fn_class)}; return nil }

var A_arbace_pprint_pr_with_base_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pr_with_base_A_invoke, New: A_arbace_pprint_pr_with_base_A_new, Get: A_arbace_pprint_pr_with_base_A_get}

var A_arbace_pprint_pr_with_base_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pr_with_base", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pr_with_base", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pr_with_base_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pr_with_base_A_class.Info(); i.IsInstance = A_arbace_pprint_pr_with_base_A_InstanceOf; i.Init = A_arbace_pprint_pr_with_base_A_Init; i.Table = A_arbace_pprint_pr_with_base_A_members; jrt.RegisterGoType(A_arbace_pprint_pr_with_base_A_class, reflect.TypeFor[A_arbace_pprint_pr_with_base_A]()) }

func A_arbace_pprint_prefix_count_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_prefix_count_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_prefix_count_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_prefix_count_A_New()}; return nil }

func A_arbace_pprint_prefix_count_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_prefix_count_A_fn_class)}; return nil }

var A_arbace_pprint_prefix_count_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_prefix_count_A_invoke, New: A_arbace_pprint_prefix_count_A_new, Get: A_arbace_pprint_prefix_count_A_get}

var A_arbace_pprint_prefix_count_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$prefix_count", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "prefix_count", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_prefix_count_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_prefix_count_A_class.Info(); i.IsInstance = A_arbace_pprint_prefix_count_A_InstanceOf; i.Init = A_arbace_pprint_prefix_count_A_Init; i.Table = A_arbace_pprint_prefix_count_A_members; jrt.RegisterGoType(A_arbace_pprint_prefix_count_A_class, reflect.TypeFor[A_arbace_pprint_prefix_count_A]()) }

func A_arbace_pprint_prerr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_prerr_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_prerr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_prerr_A_New()}; return nil }

func A_arbace_pprint_prerr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_prerr_A_fn_class)}; return nil }

var A_arbace_pprint_prerr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_prerr_A_invoke, New: A_arbace_pprint_prerr_A_new, Get: A_arbace_pprint_prerr_A_get}

var A_arbace_pprint_prerr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$prerr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_A_class, Simple: "prerr", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_prerr_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_prerr_A_class.Info(); i.IsInstance = A_arbace_pprint_prerr_A_InstanceOf; i.Init = A_arbace_pprint_prerr_A_Init; i.Table = A_arbace_pprint_prerr_A_members; jrt.RegisterGoType(A_arbace_pprint_prerr_A_class, reflect.TypeFor[A_arbace_pprint_prerr_A]()) }

func A_arbace_pprint_pretty_character_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_character_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_pretty_character_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_character_A_New()}; return nil }

func A_arbace_pprint_pretty_character_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_character_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_character_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_character_A_invoke, New: A_arbace_pprint_pretty_character_A_new, Get: A_arbace_pprint_pretty_character_A_get}

var A_arbace_pprint_pretty_character_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_character", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "pretty_character", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_character_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_pretty_character_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_character_A_InstanceOf; i.Init = A_arbace_pprint_pretty_character_A_Init; i.Table = A_arbace_pprint_pretty_character_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_character_A_class, reflect.TypeFor[A_arbace_pprint_pretty_character_A]()) }

func A_arbace_pprint_pretty_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_pretty_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_A_New()}; return nil }

func A_arbace_pprint_pretty_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_A_invoke, New: A_arbace_pprint_pretty_writer_A_new, Get: A_arbace_pprint_pretty_writer_A_get}

var A_arbace_pprint_pretty_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "pretty_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_pretty_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_A_Init; i.Table = A_arbace_pprint_pretty_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_A]()) }

func A_arbace_pprint_pretty_writer_fn__1820000173_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_fn__1820000173_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000173_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_fn__1820000173_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000173_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_fn__1820000173_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_fn__1820000173_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_fn__1820000173_A_invoke, New: A_arbace_pprint_pretty_writer_fn__1820000173_A_new, Get: A_arbace_pprint_pretty_writer_fn__1820000173_A_get}

var A_arbace_pprint_pretty_writer_fn__1820000173_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer$fn__1820000173", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_pretty_writer_A_class, Simple: "fn__1820000173", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_fn__1820000173_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_pretty_writer_fn__1820000173_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_fn__1820000173_A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_fn__1820000173_A_Init; i.Table = A_arbace_pprint_pretty_writer_fn__1820000173_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_fn__1820000173_A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_fn__1820000173_A]()) }

func A_arbace_pprint_pretty_writer_fn__1820000175_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_fn__1820000175_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_pprint_pretty_writer_fn__1820000175_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000175_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_fn__1820000175_A_New()}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000175_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_fn__1820000175_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_fn__1820000175_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_fn__1820000175_A_invoke, New: A_arbace_pprint_pretty_writer_fn__1820000175_A_new, Get: A_arbace_pprint_pretty_writer_fn__1820000175_A_get}

var A_arbace_pprint_pretty_writer_fn__1820000175_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer$fn__1820000175", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_pretty_writer_A_class, Simple: "fn__1820000175", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_fn__1820000175_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_pretty_writer_fn__1820000175_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_fn__1820000175_A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_fn__1820000175_A_Init; i.Table = A_arbace_pprint_pretty_writer_fn__1820000175_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_fn__1820000175_A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_fn__1820000175_A]()) }

func A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_invoke, New: A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_new, Get: A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_get}

var A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer$fn__1820000175$fn__1820000178", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pretty_writer_fn__1820000175_A_class, Simple: "fn__1820000178", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_Init; i.Table = A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_fn__1820000175_fn__1820000178_A]()) }

func A_arbace_pprint_pretty_writer_fn__1820000181_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_fn__1820000181_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000181_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_fn__1820000181_A_New()}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000181_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_fn__1820000181_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_fn__1820000181_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_fn__1820000181_A_invoke, New: A_arbace_pprint_pretty_writer_fn__1820000181_A_new, Get: A_arbace_pprint_pretty_writer_fn__1820000181_A_get}

var A_arbace_pprint_pretty_writer_fn__1820000181_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer$fn__1820000181", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_pretty_writer_A_class, Simple: "fn__1820000181", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_fn__1820000181_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_pretty_writer_fn__1820000181_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_fn__1820000181_A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_fn__1820000181_A_Init; i.Table = A_arbace_pprint_pretty_writer_fn__1820000181_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_fn__1820000181_A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_fn__1820000181_A]()) }

func A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_New_O(args[0])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_invoke, New: A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_new, Get: A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_get}

var A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer$fn__1820000181$fn__1820000182", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_pretty_writer_fn__1820000181_A_class, Simple: "fn__1820000182", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_Init; i.Table = A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_fn__1820000181_fn__1820000182_A]()) }

func A_arbace_pprint_pretty_writer_fn__1820000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_fn__1820000185_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_fn__1820000185_A_New()}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_fn__1820000185_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_fn__1820000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_fn__1820000185_A_invoke, New: A_arbace_pprint_pretty_writer_fn__1820000185_A_new, Get: A_arbace_pprint_pretty_writer_fn__1820000185_A_get}

var A_arbace_pprint_pretty_writer_fn__1820000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer$fn__1820000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_pretty_writer_A_class, Simple: "fn__1820000185", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_fn__1820000185_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_pretty_writer_fn__1820000185_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_fn__1820000185_A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_fn__1820000185_A_Init; i.Table = A_arbace_pprint_pretty_writer_fn__1820000185_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_fn__1820000185_A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_fn__1820000185_A]()) }

func A_arbace_pprint_pretty_writer_fn__1820000187_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_fn__1820000187_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000187_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_fn__1820000187_A_New()}; return nil }

func A_arbace_pprint_pretty_writer_fn__1820000187_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_fn__1820000187_A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_fn__1820000187_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_fn__1820000187_A_invoke, New: A_arbace_pprint_pretty_writer_fn__1820000187_A_new, Get: A_arbace_pprint_pretty_writer_fn__1820000187_A_get}

var A_arbace_pprint_pretty_writer_fn__1820000187_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer$fn__1820000187", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_pretty_writer_A_class, Simple: "fn__1820000187", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_fn__1820000187_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_pretty_writer_fn__1820000187_A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_fn__1820000187_A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_fn__1820000187_A_Init; i.Table = A_arbace_pprint_pretty_writer_fn__1820000187_A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_fn__1820000187_A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_fn__1820000187_A]()) }

func A_arbace_pprint_pretty_writer_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_pretty_writer_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_pretty_writer_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_pretty_writer_QMARK__A_New()}; return nil }

func A_arbace_pprint_pretty_writer_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_pretty_writer_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_pretty_writer_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_pretty_writer_QMARK__A_invoke, New: A_arbace_pprint_pretty_writer_QMARK__A_new, Get: A_arbace_pprint_pretty_writer_QMARK__A_get}

var A_arbace_pprint_pretty_writer_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$pretty_writer_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "pretty_writer_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_pretty_writer_QMARK__A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_pretty_writer_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_pretty_writer_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_pretty_writer_QMARK__A_Init; i.Table = A_arbace_pprint_pretty_writer_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_pretty_writer_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_pretty_writer_QMARK__A]()) }

func A_arbace_pprint_print_length_loop_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_length_loop_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_print_length_loop_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_length_loop_A_New()}; return nil }

func A_arbace_pprint_print_length_loop_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_length_loop_A_fn_class)}; return nil }

var A_arbace_pprint_print_length_loop_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_length_loop_A_invoke, New: A_arbace_pprint_print_length_loop_A_new, Get: A_arbace_pprint_print_length_loop_A_get}

var A_arbace_pprint_print_length_loop_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_length_loop", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_pprint_A_class, Simple: "print_length_loop", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_length_loop_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_print_length_loop_A_class.Info(); i.IsInstance = A_arbace_pprint_print_length_loop_A_InstanceOf; i.Init = A_arbace_pprint_print_length_loop_A_Init; i.Table = A_arbace_pprint_print_length_loop_A_members; jrt.RegisterGoType(A_arbace_pprint_print_length_loop_A_class, reflect.TypeFor[A_arbace_pprint_print_length_loop_A]()) }

func A_arbace_pprint_print_table_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_pprint_print_table_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_print_table_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_A_New()}; return nil }

func A_arbace_pprint_print_table_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_A_invoke, New: A_arbace_pprint_print_table_A_new, Get: A_arbace_pprint_print_table_A_get}

var A_arbace_pprint_print_table_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "print_table", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_A_InstanceOf; i.Init = A_arbace_pprint_print_table_A_Init; i.Table = A_arbace_pprint_print_table_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_A_class, reflect.TypeFor[A_arbace_pprint_print_table_A]()) }

func A_arbace_pprint_print_table_fmt_row__1821000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fmt_row__1821000014_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fmt_row__1821000014_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fmt_row__1821000014_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fmt_row__1821000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fmt_row__1821000014_A_invoke, New: A_arbace_pprint_print_table_fmt_row__1821000014_A_new, Get: A_arbace_pprint_print_table_fmt_row__1821000014_A_get}

var A_arbace_pprint_print_table_fmt_row__1821000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fmt_row__1821000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_print_table_A_class, Simple: "fmt_row__1821000014", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fmt_row__1821000014_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fmt_row__1821000014_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fmt_row__1821000014_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fmt_row__1821000014_A_Init; i.Table = A_arbace_pprint_print_table_fmt_row__1821000014_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fmt_row__1821000014_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fmt_row__1821000014_A]()) }

func A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_New_O(args[0])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_invoke, New: A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_new, Get: A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_get}

var A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fmt_row__1821000014$fn__1821000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_print_table_fmt_row__1821000014_A_class, Simple: "fn__1821000031", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_Init; i.Table = A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fmt_row__1821000014_fn__1821000031_A]()) }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_New()}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_invoke, New: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_new, Get: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_get}

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fmt_row__1821000014$iter__1821000015__1821000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_print_table_fmt_row__1821000014_A_class, Simple: "iter__1821000015__1821000019", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_Init; i.Table = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A]()) }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_invoke, New: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_new, Get: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_get}

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fmt_row__1821000014$iter__1821000015__1821000019$fn__1821000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_A_class, Simple: "fn__1821000020", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_Init; i.Table = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A]()) }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_invoke, New: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_new, Get: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_get}

var A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fmt_row__1821000014$iter__1821000015__1821000019$fn__1821000020$fn__1821000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_A_class, Simple: "fn__1821000021", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_Init; i.Table = A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fmt_row__1821000014_iter__1821000015__1821000019_fn__1821000020_fn__1821000021_A]()) }

func A_arbace_pprint_print_table_fn__1821000006_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fn__1821000006_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_print_table_fn__1821000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fn__1821000006_A_New_O(args[0])}; return nil }

func A_arbace_pprint_print_table_fn__1821000006_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fn__1821000006_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fn__1821000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fn__1821000006_A_invoke, New: A_arbace_pprint_print_table_fn__1821000006_A_new, Get: A_arbace_pprint_print_table_fn__1821000006_A_get}

var A_arbace_pprint_print_table_fn__1821000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fn__1821000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_print_table_A_class, Simple: "fn__1821000006", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fn__1821000006_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fn__1821000006_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fn__1821000006_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fn__1821000006_A_Init; i.Table = A_arbace_pprint_print_table_fn__1821000006_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fn__1821000006_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fn__1821000006_A]()) }

func A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_New_O(args[0])}; return nil }

func A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_invoke, New: A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_new, Get: A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_get}

var A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fn__1821000006$fn__1821000007", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_print_table_fn__1821000006_A_class, Simple: "fn__1821000007", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_Init; i.Table = A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fn__1821000006_fn__1821000007_A]()) }

func A_arbace_pprint_print_table_fn__1821000010_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fn__1821000010_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_print_table_fn__1821000010_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fn__1821000010_A_New()}; return nil }

func A_arbace_pprint_print_table_fn__1821000010_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fn__1821000010_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fn__1821000010_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fn__1821000010_A_invoke, New: A_arbace_pprint_print_table_fn__1821000010_A_new, Get: A_arbace_pprint_print_table_fn__1821000010_A_get}

var A_arbace_pprint_print_table_fn__1821000010_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fn__1821000010", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_print_table_A_class, Simple: "fn__1821000010", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fn__1821000010_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fn__1821000010_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fn__1821000010_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fn__1821000010_A_Init; i.Table = A_arbace_pprint_print_table_fn__1821000010_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fn__1821000010_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fn__1821000010_A]()) }

func A_arbace_pprint_print_table_fn__1821000012_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_print_table_fn__1821000012_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_print_table_fn__1821000012_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_print_table_fn__1821000012_A_New()}; return nil }

func A_arbace_pprint_print_table_fn__1821000012_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_print_table_fn__1821000012_A_fn_class)}; return nil }

var A_arbace_pprint_print_table_fn__1821000012_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_print_table_fn__1821000012_A_invoke, New: A_arbace_pprint_print_table_fn__1821000012_A_new, Get: A_arbace_pprint_print_table_fn__1821000012_A_get}

var A_arbace_pprint_print_table_fn__1821000012_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$print_table$fn__1821000012", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_print_table_A_class, Simple: "fn__1821000012", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_print_table_fn__1821000012_A", Source: "print_table.ae"})

func init() { i := A_arbace_pprint_print_table_fn__1821000012_A_class.Info(); i.IsInstance = A_arbace_pprint_print_table_fn__1821000012_A_InstanceOf; i.Init = A_arbace_pprint_print_table_fn__1821000012_A_Init; i.Table = A_arbace_pprint_print_table_fn__1821000012_A_members; jrt.RegisterGoType(A_arbace_pprint_print_table_fn__1821000012_A_class, reflect.TypeFor[A_arbace_pprint_print_table_fn__1821000012_A]()) }

func A_arbace_pprint_prlabel_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_prlabel_A).DoInvoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_pprint_prlabel_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_prlabel_A_New()}; return nil }

func A_arbace_pprint_prlabel_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_prlabel_A_fn_class)}; return nil }

var A_arbace_pprint_prlabel_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_prlabel_A_invoke, New: A_arbace_pprint_prlabel_A_new, Get: A_arbace_pprint_prlabel_A_get}

var A_arbace_pprint_prlabel_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$prlabel", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR4_class}, Declaring: A_arbace_pprint_A_class, Simple: "prlabel", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_prlabel_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_prlabel_A_class.Info(); i.IsInstance = A_arbace_pprint_prlabel_A_InstanceOf; i.Init = A_arbace_pprint_prlabel_A_Init; i.Table = A_arbace_pprint_prlabel_A_members; jrt.RegisterGoType(A_arbace_pprint_prlabel_A_class, reflect.TypeFor[A_arbace_pprint_prlabel_A]()) }

func A_arbace_pprint_prlabel_fn__1470000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_prlabel_fn__1470000081_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_prlabel_fn__1470000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_prlabel_fn__1470000081_A_New()}; return nil }

func A_arbace_pprint_prlabel_fn__1470000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_prlabel_fn__1470000081_A_fn_class)}; return nil }

var A_arbace_pprint_prlabel_fn__1470000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_prlabel_fn__1470000081_A_invoke, New: A_arbace_pprint_prlabel_fn__1470000081_A_new, Get: A_arbace_pprint_prlabel_fn__1470000081_A_get}

var A_arbace_pprint_prlabel_fn__1470000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$prlabel$fn__1470000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_prlabel_A_class, Simple: "fn__1470000081", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_prlabel_fn__1470000081_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_prlabel_fn__1470000081_A_class.Info(); i.IsInstance = A_arbace_pprint_prlabel_fn__1470000081_A_InstanceOf; i.Init = A_arbace_pprint_prlabel_fn__1470000081_A_Init; i.Table = A_arbace_pprint_prlabel_fn__1470000081_A_members; jrt.RegisterGoType(A_arbace_pprint_prlabel_fn__1470000081_A_class, reflect.TypeFor[A_arbace_pprint_prlabel_fn__1470000081_A]()) }

func A_arbace_pprint_process_bracket_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_process_bracket_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_process_bracket_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_process_bracket_A_New()}; return nil }

func A_arbace_pprint_process_bracket_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_process_bracket_A_fn_class)}; return nil }

var A_arbace_pprint_process_bracket_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_process_bracket_A_invoke, New: A_arbace_pprint_process_bracket_A_new, Get: A_arbace_pprint_process_bracket_A_get}

var A_arbace_pprint_process_bracket_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$process_bracket", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "process_bracket", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_process_bracket_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_process_bracket_A_class.Info(); i.IsInstance = A_arbace_pprint_process_bracket_A_InstanceOf; i.Init = A_arbace_pprint_process_bracket_A_Init; i.Table = A_arbace_pprint_process_bracket_A_members; jrt.RegisterGoType(A_arbace_pprint_process_bracket_A_class, reflect.TypeFor[A_arbace_pprint_process_bracket_A]()) }

func A_arbace_pprint_process_clause_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_process_clause_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_process_clause_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_process_clause_A_New()}; return nil }

func A_arbace_pprint_process_clause_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_process_clause_A_fn_class)}; return nil }

var A_arbace_pprint_process_clause_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_process_clause_A_invoke, New: A_arbace_pprint_process_clause_A_new, Get: A_arbace_pprint_process_clause_A_get}

var A_arbace_pprint_process_clause_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$process_clause", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "process_clause", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_process_clause_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_process_clause_A_class.Info(); i.IsInstance = A_arbace_pprint_process_clause_A_InstanceOf; i.Init = A_arbace_pprint_process_clause_A_Init; i.Table = A_arbace_pprint_process_clause_A_members; jrt.RegisterGoType(A_arbace_pprint_process_clause_A_class, reflect.TypeFor[A_arbace_pprint_process_clause_A]()) }

func A_arbace_pprint_process_clause_fn__1819000544_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_process_clause_fn__1819000544_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_process_clause_fn__1819000544_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_process_clause_fn__1819000544_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_process_clause_fn__1819000544_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_process_clause_fn__1819000544_A_fn_class)}; return nil }

var A_arbace_pprint_process_clause_fn__1819000544_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_process_clause_fn__1819000544_A_invoke, New: A_arbace_pprint_process_clause_fn__1819000544_A_new, Get: A_arbace_pprint_process_clause_fn__1819000544_A_get}

var A_arbace_pprint_process_clause_fn__1819000544_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$process_clause$fn__1819000544", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_process_clause_A_class, Simple: "fn__1819000544", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_process_clause_fn__1819000544_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_process_clause_fn__1819000544_A_class.Info(); i.IsInstance = A_arbace_pprint_process_clause_fn__1819000544_A_InstanceOf; i.Init = A_arbace_pprint_process_clause_fn__1819000544_A_Init; i.Table = A_arbace_pprint_process_clause_fn__1819000544_A_members; jrt.RegisterGoType(A_arbace_pprint_process_clause_fn__1819000544_A_class, reflect.TypeFor[A_arbace_pprint_process_clause_fn__1819000544_A]()) }

func A_arbace_pprint_process_directive_table_element_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_process_directive_table_element_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_process_directive_table_element_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_process_directive_table_element_A_New()}; return nil }

func A_arbace_pprint_process_directive_table_element_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_process_directive_table_element_A_fn_class)}; return nil }

var A_arbace_pprint_process_directive_table_element_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_process_directive_table_element_A_invoke, New: A_arbace_pprint_process_directive_table_element_A_new, Get: A_arbace_pprint_process_directive_table_element_A_get}

var A_arbace_pprint_process_directive_table_element_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$process_directive_table_element", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "process_directive_table_element", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_process_directive_table_element_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_process_directive_table_element_A_class.Info(); i.IsInstance = A_arbace_pprint_process_directive_table_element_A_InstanceOf; i.Init = A_arbace_pprint_process_directive_table_element_A_Init; i.Table = A_arbace_pprint_process_directive_table_element_A_members; jrt.RegisterGoType(A_arbace_pprint_process_directive_table_element_A_class, reflect.TypeFor[A_arbace_pprint_process_directive_table_element_A]()) }

func A_arbace_pprint_process_nesting_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_process_nesting_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_process_nesting_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_process_nesting_A_New()}; return nil }

func A_arbace_pprint_process_nesting_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_process_nesting_A_fn_class)}; return nil }

var A_arbace_pprint_process_nesting_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_process_nesting_A_invoke, New: A_arbace_pprint_process_nesting_A_new, Get: A_arbace_pprint_process_nesting_A_get}

var A_arbace_pprint_process_nesting_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$process_nesting", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "process_nesting", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_process_nesting_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_process_nesting_A_class.Info(); i.IsInstance = A_arbace_pprint_process_nesting_A_InstanceOf; i.Init = A_arbace_pprint_process_nesting_A_Init; i.Table = A_arbace_pprint_process_nesting_A_members; jrt.RegisterGoType(A_arbace_pprint_process_nesting_A_class, reflect.TypeFor[A_arbace_pprint_process_nesting_A]()) }

func A_arbace_pprint_process_nesting_fn__1819000560_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_process_nesting_fn__1819000560_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_process_nesting_fn__1819000560_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_process_nesting_fn__1819000560_A_New()}; return nil }

func A_arbace_pprint_process_nesting_fn__1819000560_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_process_nesting_fn__1819000560_A_fn_class)}; return nil }

var A_arbace_pprint_process_nesting_fn__1819000560_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_process_nesting_fn__1819000560_A_invoke, New: A_arbace_pprint_process_nesting_fn__1819000560_A_new, Get: A_arbace_pprint_process_nesting_fn__1819000560_A_get}

var A_arbace_pprint_process_nesting_fn__1819000560_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$process_nesting$fn__1819000560", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_process_nesting_A_class, Simple: "fn__1819000560", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_process_nesting_fn__1819000560_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_process_nesting_fn__1819000560_A_class.Info(); i.IsInstance = A_arbace_pprint_process_nesting_fn__1819000560_A_InstanceOf; i.Init = A_arbace_pprint_process_nesting_fn__1819000560_A_Init; i.Table = A_arbace_pprint_process_nesting_fn__1819000560_A_members; jrt.RegisterGoType(A_arbace_pprint_process_nesting_fn__1819000560_A_class, reflect.TypeFor[A_arbace_pprint_process_nesting_fn__1819000560_A]()) }

func A_arbace_pprint_readable_character_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_readable_character_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_readable_character_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_readable_character_A_New()}; return nil }

func A_arbace_pprint_readable_character_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_readable_character_A_fn_class)}; return nil }

var A_arbace_pprint_readable_character_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_readable_character_A_invoke, New: A_arbace_pprint_readable_character_A_new, Get: A_arbace_pprint_readable_character_A_get}

var A_arbace_pprint_readable_character_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$readable_character", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "readable_character", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_readable_character_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_readable_character_A_class.Info(); i.IsInstance = A_arbace_pprint_readable_character_A_InstanceOf; i.Init = A_arbace_pprint_readable_character_A_Init; i.Table = A_arbace_pprint_readable_character_A_members; jrt.RegisterGoType(A_arbace_pprint_readable_character_A_class, reflect.TypeFor[A_arbace_pprint_readable_character_A]()) }

func A_arbace_pprint_realize_parameter_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_realize_parameter_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_realize_parameter_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_realize_parameter_A_New()}; return nil }

func A_arbace_pprint_realize_parameter_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_realize_parameter_A_fn_class)}; return nil }

var A_arbace_pprint_realize_parameter_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_realize_parameter_A_invoke, New: A_arbace_pprint_realize_parameter_A_new, Get: A_arbace_pprint_realize_parameter_A_get}

var A_arbace_pprint_realize_parameter_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$realize_parameter", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "realize_parameter", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_realize_parameter_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_realize_parameter_A_class.Info(); i.IsInstance = A_arbace_pprint_realize_parameter_A_InstanceOf; i.Init = A_arbace_pprint_realize_parameter_A_Init; i.Table = A_arbace_pprint_realize_parameter_A_members; jrt.RegisterGoType(A_arbace_pprint_realize_parameter_A_class, reflect.TypeFor[A_arbace_pprint_realize_parameter_A]()) }

func A_arbace_pprint_realize_parameter_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_realize_parameter_list_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_realize_parameter_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_realize_parameter_list_A_New()}; return nil }

func A_arbace_pprint_realize_parameter_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_realize_parameter_list_A_fn_class)}; return nil }

var A_arbace_pprint_realize_parameter_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_realize_parameter_list_A_invoke, New: A_arbace_pprint_realize_parameter_list_A_new, Get: A_arbace_pprint_realize_parameter_list_A_get}

var A_arbace_pprint_realize_parameter_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$realize_parameter_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "realize_parameter_list", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_realize_parameter_list_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_realize_parameter_list_A_class.Info(); i.IsInstance = A_arbace_pprint_realize_parameter_list_A_InstanceOf; i.Init = A_arbace_pprint_realize_parameter_list_A_Init; i.Table = A_arbace_pprint_realize_parameter_list_A_members; jrt.RegisterGoType(A_arbace_pprint_realize_parameter_list_A_class, reflect.TypeFor[A_arbace_pprint_realize_parameter_list_A]()) }

func A_arbace_pprint_relative_reposition_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_relative_reposition_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_relative_reposition_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_relative_reposition_A_New()}; return nil }

func A_arbace_pprint_relative_reposition_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_relative_reposition_A_fn_class)}; return nil }

var A_arbace_pprint_relative_reposition_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_relative_reposition_A_invoke, New: A_arbace_pprint_relative_reposition_A_new, Get: A_arbace_pprint_relative_reposition_A_get}

var A_arbace_pprint_relative_reposition_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$relative_reposition", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "relative_reposition", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_relative_reposition_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_relative_reposition_A_class.Info(); i.IsInstance = A_arbace_pprint_relative_reposition_A_InstanceOf; i.Init = A_arbace_pprint_relative_reposition_A_Init; i.Table = A_arbace_pprint_relative_reposition_A_members; jrt.RegisterGoType(A_arbace_pprint_relative_reposition_A_class, reflect.TypeFor[A_arbace_pprint_relative_reposition_A]()) }

func A_arbace_pprint_relative_tabulation_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_relative_tabulation_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_relative_tabulation_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_relative_tabulation_A_New()}; return nil }

func A_arbace_pprint_relative_tabulation_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_relative_tabulation_A_fn_class)}; return nil }

var A_arbace_pprint_relative_tabulation_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_relative_tabulation_A_invoke, New: A_arbace_pprint_relative_tabulation_A_new, Get: A_arbace_pprint_relative_tabulation_A_get}

var A_arbace_pprint_relative_tabulation_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$relative_tabulation", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "relative_tabulation", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_relative_tabulation_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_relative_tabulation_A_class.Info(); i.IsInstance = A_arbace_pprint_relative_tabulation_A_InstanceOf; i.Init = A_arbace_pprint_relative_tabulation_A_Init; i.Table = A_arbace_pprint_relative_tabulation_A_members; jrt.RegisterGoType(A_arbace_pprint_relative_tabulation_A_class, reflect.TypeFor[A_arbace_pprint_relative_tabulation_A]()) }

func A_arbace_pprint_remainders_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_remainders_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_remainders_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_remainders_A_New()}; return nil }

func A_arbace_pprint_remainders_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_remainders_A_fn_class)}; return nil }

var A_arbace_pprint_remainders_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_remainders_A_invoke, New: A_arbace_pprint_remainders_A_new, Get: A_arbace_pprint_remainders_A_get}

var A_arbace_pprint_remainders_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$remainders", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "remainders", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_remainders_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_remainders_A_class.Info(); i.IsInstance = A_arbace_pprint_remainders_A_InstanceOf; i.Init = A_arbace_pprint_remainders_A_Init; i.Table = A_arbace_pprint_remainders_A_members; jrt.RegisterGoType(A_arbace_pprint_remainders_A_class, reflect.TypeFor[A_arbace_pprint_remainders_A]()) }

func A_arbace_pprint_remainders_fn__1819000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_remainders_fn__1819000035_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_remainders_fn__1819000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_remainders_fn__1819000035_A_New_O(args[0])}; return nil }

func A_arbace_pprint_remainders_fn__1819000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_remainders_fn__1819000035_A_fn_class)}; return nil }

var A_arbace_pprint_remainders_fn__1819000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_remainders_fn__1819000035_A_invoke, New: A_arbace_pprint_remainders_fn__1819000035_A_new, Get: A_arbace_pprint_remainders_fn__1819000035_A_get}

var A_arbace_pprint_remainders_fn__1819000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$remainders$fn__1819000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_remainders_A_class, Simple: "fn__1819000035", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_remainders_fn__1819000035_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_remainders_fn__1819000035_A_class.Info(); i.IsInstance = A_arbace_pprint_remainders_fn__1819000035_A_InstanceOf; i.Init = A_arbace_pprint_remainders_fn__1819000035_A_Init; i.Table = A_arbace_pprint_remainders_fn__1819000035_A_members; jrt.RegisterGoType(A_arbace_pprint_remainders_fn__1819000035_A_class, reflect.TypeFor[A_arbace_pprint_remainders_fn__1819000035_A]()) }

func A_arbace_pprint_render_clauses_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_render_clauses_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_render_clauses_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_render_clauses_A_New()}; return nil }

func A_arbace_pprint_render_clauses_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_render_clauses_A_fn_class)}; return nil }

var A_arbace_pprint_render_clauses_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_render_clauses_A_invoke, New: A_arbace_pprint_render_clauses_A_new, Get: A_arbace_pprint_render_clauses_A_get}

var A_arbace_pprint_render_clauses_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$render_clauses", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "render_clauses", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_render_clauses_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_render_clauses_A_class.Info(); i.IsInstance = A_arbace_pprint_render_clauses_A_InstanceOf; i.Init = A_arbace_pprint_render_clauses_A_Init; i.Table = A_arbace_pprint_render_clauses_A_members; jrt.RegisterGoType(A_arbace_pprint_render_clauses_A_class, reflect.TypeFor[A_arbace_pprint_render_clauses_A]()) }

func A_arbace_pprint_render_clauses_fn__1819000200_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_render_clauses_fn__1819000200_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_render_clauses_fn__1819000200_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_render_clauses_fn__1819000200_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_render_clauses_fn__1819000200_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_render_clauses_fn__1819000200_A_fn_class)}; return nil }

var A_arbace_pprint_render_clauses_fn__1819000200_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_render_clauses_fn__1819000200_A_invoke, New: A_arbace_pprint_render_clauses_fn__1819000200_A_new, Get: A_arbace_pprint_render_clauses_fn__1819000200_A_get}

var A_arbace_pprint_render_clauses_fn__1819000200_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$render_clauses$fn__1819000200", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_render_clauses_A_class, Simple: "fn__1819000200", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_render_clauses_fn__1819000200_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_render_clauses_fn__1819000200_A_class.Info(); i.IsInstance = A_arbace_pprint_render_clauses_fn__1819000200_A_InstanceOf; i.Init = A_arbace_pprint_render_clauses_fn__1819000200_A_Init; i.Table = A_arbace_pprint_render_clauses_fn__1819000200_A_members; jrt.RegisterGoType(A_arbace_pprint_render_clauses_fn__1819000200_A_class, reflect.TypeFor[A_arbace_pprint_render_clauses_fn__1819000200_A]()) }

func A_arbace_pprint_right_bracket_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_right_bracket_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_right_bracket_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_right_bracket_A_New()}; return nil }

func A_arbace_pprint_right_bracket_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_right_bracket_A_fn_class)}; return nil }

var A_arbace_pprint_right_bracket_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_right_bracket_A_invoke, New: A_arbace_pprint_right_bracket_A_new, Get: A_arbace_pprint_right_bracket_A_get}

var A_arbace_pprint_right_bracket_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$right_bracket", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "right_bracket", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_right_bracket_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_right_bracket_A_class.Info(); i.IsInstance = A_arbace_pprint_right_bracket_A_InstanceOf; i.Init = A_arbace_pprint_right_bracket_A_Init; i.Table = A_arbace_pprint_right_bracket_A_members; jrt.RegisterGoType(A_arbace_pprint_right_bracket_A_class, reflect.TypeFor[A_arbace_pprint_right_bracket_A]()) }

func A_arbace_pprint_round_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_round_str_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_round_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_round_str_A_New()}; return nil }

func A_arbace_pprint_round_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_round_str_A_fn_class)}; return nil }

var A_arbace_pprint_round_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_round_str_A_invoke, New: A_arbace_pprint_round_str_A_new, Get: A_arbace_pprint_round_str_A_get}

var A_arbace_pprint_round_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$round_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_A_class, Simple: "round_str", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_round_str_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_round_str_A_class.Info(); i.IsInstance = A_arbace_pprint_round_str_A_InstanceOf; i.Init = A_arbace_pprint_round_str_A_Init; i.Table = A_arbace_pprint_round_str_A_members; jrt.RegisterGoType(A_arbace_pprint_round_str_A_class, reflect.TypeFor[A_arbace_pprint_round_str_A]()) }

func A_arbace_pprint_rtrim_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_rtrim_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_rtrim_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_rtrim_A_New()}; return nil }

func A_arbace_pprint_rtrim_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_rtrim_A_fn_class)}; return nil }

var A_arbace_pprint_rtrim_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_rtrim_A_invoke, New: A_arbace_pprint_rtrim_A_new, Get: A_arbace_pprint_rtrim_A_get}

var A_arbace_pprint_rtrim_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$rtrim", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "rtrim", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_rtrim_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_rtrim_A_class.Info(); i.IsInstance = A_arbace_pprint_rtrim_A_InstanceOf; i.Init = A_arbace_pprint_rtrim_A_Init; i.Table = A_arbace_pprint_rtrim_A_members; jrt.RegisterGoType(A_arbace_pprint_rtrim_A_class, reflect.TypeFor[A_arbace_pprint_rtrim_A]()) }

func A_arbace_pprint_separator_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_separator_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_separator_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_separator_QMARK__A_New()}; return nil }

func A_arbace_pprint_separator_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_separator_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_separator_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_separator_QMARK__A_invoke, New: A_arbace_pprint_separator_QMARK__A_new, Get: A_arbace_pprint_separator_QMARK__A_get}

var A_arbace_pprint_separator_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$separator_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "separator_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_separator_QMARK__A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_separator_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_separator_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_separator_QMARK__A_Init; i.Table = A_arbace_pprint_separator_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_separator_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_separator_QMARK__A]()) }

func A_arbace_pprint_set_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_field_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_set_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_field_A_New()}; return nil }

func A_arbace_pprint_set_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_field_A_fn_class)}; return nil }

var A_arbace_pprint_set_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_field_A_invoke, New: A_arbace_pprint_set_field_A_new, Get: A_arbace_pprint_set_field_A_get}

var A_arbace_pprint_set_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "set_field", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_field_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_set_field_A_class.Info(); i.IsInstance = A_arbace_pprint_set_field_A_InstanceOf; i.Init = A_arbace_pprint_set_field_A_Init; i.Table = A_arbace_pprint_set_field_A_members; jrt.RegisterGoType(A_arbace_pprint_set_field_A_class, reflect.TypeFor[A_arbace_pprint_set_field_A]()) }

func A_arbace_pprint_set_indent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_indent_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_set_indent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_indent_A_New()}; return nil }

func A_arbace_pprint_set_indent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_indent_A_fn_class)}; return nil }

var A_arbace_pprint_set_indent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_indent_A_invoke, New: A_arbace_pprint_set_indent_A_new, Get: A_arbace_pprint_set_indent_A_get}

var A_arbace_pprint_set_indent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_indent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "set_indent", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_indent_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_set_indent_A_class.Info(); i.IsInstance = A_arbace_pprint_set_indent_A_InstanceOf; i.Init = A_arbace_pprint_set_indent_A_Init; i.Table = A_arbace_pprint_set_indent_A_members; jrt.RegisterGoType(A_arbace_pprint_set_indent_A_class, reflect.TypeFor[A_arbace_pprint_set_indent_A]()) }

func A_arbace_pprint_set_logical_block_callback_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_logical_block_callback_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_set_logical_block_callback_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_logical_block_callback_A_New()}; return nil }

func A_arbace_pprint_set_logical_block_callback_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_logical_block_callback_A_fn_class)}; return nil }

var A_arbace_pprint_set_logical_block_callback_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_logical_block_callback_A_invoke, New: A_arbace_pprint_set_logical_block_callback_A_new, Get: A_arbace_pprint_set_logical_block_callback_A_get}

var A_arbace_pprint_set_logical_block_callback_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_logical_block_callback", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "set_logical_block_callback", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_set_logical_block_callback_A_class.Info(); i.IsInstance = A_arbace_pprint_set_logical_block_callback_A_InstanceOf; i.Init = A_arbace_pprint_set_logical_block_callback_A_Init; i.Table = A_arbace_pprint_set_logical_block_callback_A_members; jrt.RegisterGoType(A_arbace_pprint_set_logical_block_callback_A_class, reflect.TypeFor[A_arbace_pprint_set_logical_block_callback_A]()) }

func A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_logical_block_callback_fn__1820000208_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_fn_class)}; return nil }

var A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_invoke, New: A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_new, Get: A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_get}

var A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_logical_block_callback$fn__1820000208", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_set_logical_block_callback_A_class, Simple: "fn__1820000208", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_fn__1820000208_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_class.Info(); i.IsInstance = A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_InstanceOf; i.Init = A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_Init; i.Table = A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_members; jrt.RegisterGoType(A_arbace_pprint_set_logical_block_callback_fn__1820000208_A_class, reflect.TypeFor[A_arbace_pprint_set_logical_block_callback_fn__1820000208_A]()) }

func A_arbace_pprint_set_max_column_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_max_column_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_set_max_column_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_max_column_A_New()}; return nil }

func A_arbace_pprint_set_max_column_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_max_column_A_fn_class)}; return nil }

var A_arbace_pprint_set_max_column_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_max_column_A_invoke, New: A_arbace_pprint_set_max_column_A_new, Get: A_arbace_pprint_set_max_column_A_get}

var A_arbace_pprint_set_max_column_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_max_column", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "set_max_column", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_max_column_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_set_max_column_A_class.Info(); i.IsInstance = A_arbace_pprint_set_max_column_A_InstanceOf; i.Init = A_arbace_pprint_set_max_column_A_Init; i.Table = A_arbace_pprint_set_max_column_A_members; jrt.RegisterGoType(A_arbace_pprint_set_max_column_A_class, reflect.TypeFor[A_arbace_pprint_set_max_column_A]()) }

func A_arbace_pprint_set_max_column_fn__44000011_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_max_column_fn__44000011_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_set_max_column_fn__44000011_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_max_column_fn__44000011_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_set_max_column_fn__44000011_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_max_column_fn__44000011_A_fn_class)}; return nil }

var A_arbace_pprint_set_max_column_fn__44000011_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_max_column_fn__44000011_A_invoke, New: A_arbace_pprint_set_max_column_fn__44000011_A_new, Get: A_arbace_pprint_set_max_column_fn__44000011_A_get}

var A_arbace_pprint_set_max_column_fn__44000011_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_max_column$fn__44000011", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_set_max_column_A_class, Simple: "fn__44000011", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_max_column_fn__44000011_A", Source: "column_writer.ae"})

func init() { i := A_arbace_pprint_set_max_column_fn__44000011_A_class.Info(); i.IsInstance = A_arbace_pprint_set_max_column_fn__44000011_A_InstanceOf; i.Init = A_arbace_pprint_set_max_column_fn__44000011_A_Init; i.Table = A_arbace_pprint_set_max_column_fn__44000011_A_members; jrt.RegisterGoType(A_arbace_pprint_set_max_column_fn__44000011_A_class, reflect.TypeFor[A_arbace_pprint_set_max_column_fn__44000011_A]()) }

func A_arbace_pprint_set_miser_width_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_miser_width_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_set_miser_width_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_miser_width_A_New()}; return nil }

func A_arbace_pprint_set_miser_width_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_miser_width_A_fn_class)}; return nil }

var A_arbace_pprint_set_miser_width_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_miser_width_A_invoke, New: A_arbace_pprint_set_miser_width_A_new, Get: A_arbace_pprint_set_miser_width_A_get}

var A_arbace_pprint_set_miser_width_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_miser_width", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "set_miser_width", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_miser_width_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_set_miser_width_A_class.Info(); i.IsInstance = A_arbace_pprint_set_miser_width_A_InstanceOf; i.Init = A_arbace_pprint_set_miser_width_A_Init; i.Table = A_arbace_pprint_set_miser_width_A_members; jrt.RegisterGoType(A_arbace_pprint_set_miser_width_A_class, reflect.TypeFor[A_arbace_pprint_set_miser_width_A]()) }

func A_arbace_pprint_set_miser_width_fn__1820000205_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_miser_width_fn__1820000205_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_set_miser_width_fn__1820000205_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_miser_width_fn__1820000205_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_set_miser_width_fn__1820000205_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_miser_width_fn__1820000205_A_fn_class)}; return nil }

var A_arbace_pprint_set_miser_width_fn__1820000205_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_miser_width_fn__1820000205_A_invoke, New: A_arbace_pprint_set_miser_width_fn__1820000205_A_new, Get: A_arbace_pprint_set_miser_width_fn__1820000205_A_get}

var A_arbace_pprint_set_miser_width_fn__1820000205_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_miser_width$fn__1820000205", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_set_miser_width_A_class, Simple: "fn__1820000205", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_miser_width_fn__1820000205_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_set_miser_width_fn__1820000205_A_class.Info(); i.IsInstance = A_arbace_pprint_set_miser_width_fn__1820000205_A_InstanceOf; i.Init = A_arbace_pprint_set_miser_width_fn__1820000205_A_Init; i.Table = A_arbace_pprint_set_miser_width_fn__1820000205_A_members; jrt.RegisterGoType(A_arbace_pprint_set_miser_width_fn__1820000205_A_class, reflect.TypeFor[A_arbace_pprint_set_miser_width_fn__1820000205_A]()) }

func A_arbace_pprint_set_pprint_dispatch_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_set_pprint_dispatch_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_set_pprint_dispatch_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_set_pprint_dispatch_A_New()}; return nil }

func A_arbace_pprint_set_pprint_dispatch_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_set_pprint_dispatch_A_fn_class)}; return nil }

var A_arbace_pprint_set_pprint_dispatch_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_set_pprint_dispatch_A_invoke, New: A_arbace_pprint_set_pprint_dispatch_A_new, Get: A_arbace_pprint_set_pprint_dispatch_A_get}

var A_arbace_pprint_set_pprint_dispatch_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$set_pprint_dispatch", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "set_pprint_dispatch", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_set_pprint_dispatch_A_class.Info(); i.IsInstance = A_arbace_pprint_set_pprint_dispatch_A_InstanceOf; i.Init = A_arbace_pprint_set_pprint_dispatch_A_Init; i.Table = A_arbace_pprint_set_pprint_dispatch_A_members; jrt.RegisterGoType(A_arbace_pprint_set_pprint_dispatch_A_class, reflect.TypeFor[A_arbace_pprint_set_pprint_dispatch_A]()) }

func A_arbace_pprint_setf_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_setf_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_setf_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_setf_A_New()}; return nil }

func A_arbace_pprint_setf_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_setf_A_fn_class)}; return nil }

var A_arbace_pprint_setf_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_setf_A_invoke, New: A_arbace_pprint_setf_A_new, Get: A_arbace_pprint_setf_A_get}

var A_arbace_pprint_setf_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$setf", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_A_class, Simple: "setf", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_setf_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_setf_A_class.Info(); i.IsInstance = A_arbace_pprint_setf_A_InstanceOf; i.Init = A_arbace_pprint_setf_A_Init; i.Table = A_arbace_pprint_setf_A_members; jrt.RegisterGoType(A_arbace_pprint_setf_A_class, reflect.TypeFor[A_arbace_pprint_setf_A]()) }

func A_arbace_pprint_single_defn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_single_defn_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_single_defn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_single_defn_A_New()}; return nil }

func A_arbace_pprint_single_defn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_single_defn_A_fn_class)}; return nil }

var A_arbace_pprint_single_defn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_single_defn_A_invoke, New: A_arbace_pprint_single_defn_A_new, Get: A_arbace_pprint_single_defn_A_get}

var A_arbace_pprint_single_defn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$single_defn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "single_defn", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_single_defn_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_single_defn_A_class.Info(); i.IsInstance = A_arbace_pprint_single_defn_A_InstanceOf; i.Init = A_arbace_pprint_single_defn_A_Init; i.Table = A_arbace_pprint_single_defn_A_members; jrt.RegisterGoType(A_arbace_pprint_single_defn_A_class, reflect.TypeFor[A_arbace_pprint_single_defn_A]()) }

func A_arbace_pprint_single_defn_fn__740000111_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_single_defn_fn__740000111_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_single_defn_fn__740000111_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_single_defn_fn__740000111_A_New_O(args[0])}; return nil }

func A_arbace_pprint_single_defn_fn__740000111_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_single_defn_fn__740000111_A_fn_class)}; return nil }

var A_arbace_pprint_single_defn_fn__740000111_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_single_defn_fn__740000111_A_invoke, New: A_arbace_pprint_single_defn_fn__740000111_A_new, Get: A_arbace_pprint_single_defn_fn__740000111_A_get}

var A_arbace_pprint_single_defn_fn__740000111_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$single_defn$fn__740000111", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_single_defn_A_class, Simple: "fn__740000111", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_single_defn_fn__740000111_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_single_defn_fn__740000111_A_class.Info(); i.IsInstance = A_arbace_pprint_single_defn_fn__740000111_A_InstanceOf; i.Init = A_arbace_pprint_single_defn_fn__740000111_A_Init; i.Table = A_arbace_pprint_single_defn_fn__740000111_A_members; jrt.RegisterGoType(A_arbace_pprint_single_defn_fn__740000111_A_class, reflect.TypeFor[A_arbace_pprint_single_defn_fn__740000111_A]()) }

func A_arbace_pprint_single_defn_fn__740000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_single_defn_fn__740000113_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_single_defn_fn__740000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_single_defn_fn__740000113_A_New_O(args[0])}; return nil }

func A_arbace_pprint_single_defn_fn__740000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_single_defn_fn__740000113_A_fn_class)}; return nil }

var A_arbace_pprint_single_defn_fn__740000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_single_defn_fn__740000113_A_invoke, New: A_arbace_pprint_single_defn_fn__740000113_A_new, Get: A_arbace_pprint_single_defn_fn__740000113_A_get}

var A_arbace_pprint_single_defn_fn__740000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$single_defn$fn__740000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_single_defn_A_class, Simple: "fn__740000113", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_single_defn_fn__740000113_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_single_defn_fn__740000113_A_class.Info(); i.IsInstance = A_arbace_pprint_single_defn_fn__740000113_A_InstanceOf; i.Init = A_arbace_pprint_single_defn_fn__740000113_A_Init; i.Table = A_arbace_pprint_single_defn_fn__740000113_A_members; jrt.RegisterGoType(A_arbace_pprint_single_defn_fn__740000113_A_class, reflect.TypeFor[A_arbace_pprint_single_defn_fn__740000113_A]()) }

func A_arbace_pprint_single_defn_fn__740000115_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_single_defn_fn__740000115_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_single_defn_fn__740000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_single_defn_fn__740000115_A_New_O(args[0])}; return nil }

func A_arbace_pprint_single_defn_fn__740000115_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_single_defn_fn__740000115_A_fn_class)}; return nil }

var A_arbace_pprint_single_defn_fn__740000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_single_defn_fn__740000115_A_invoke, New: A_arbace_pprint_single_defn_fn__740000115_A_new, Get: A_arbace_pprint_single_defn_fn__740000115_A_get}

var A_arbace_pprint_single_defn_fn__740000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$single_defn$fn__740000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_pprint_single_defn_A_class, Simple: "fn__740000115", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_single_defn_fn__740000115_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_single_defn_fn__740000115_A_class.Info(); i.IsInstance = A_arbace_pprint_single_defn_fn__740000115_A_InstanceOf; i.Init = A_arbace_pprint_single_defn_fn__740000115_A_Init; i.Table = A_arbace_pprint_single_defn_fn__740000115_A_members; jrt.RegisterGoType(A_arbace_pprint_single_defn_fn__740000115_A_class, reflect.TypeFor[A_arbace_pprint_single_defn_fn__740000115_A]()) }

func A_arbace_pprint_split_at_newline_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_split_at_newline_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_split_at_newline_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_split_at_newline_A_New()}; return nil }

func A_arbace_pprint_split_at_newline_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_split_at_newline_A_fn_class)}; return nil }

var A_arbace_pprint_split_at_newline_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_split_at_newline_A_invoke, New: A_arbace_pprint_split_at_newline_A_new, Get: A_arbace_pprint_split_at_newline_A_get}

var A_arbace_pprint_split_at_newline_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$split_at_newline", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "split_at_newline", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_split_at_newline_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_split_at_newline_A_class.Info(); i.IsInstance = A_arbace_pprint_split_at_newline_A_InstanceOf; i.Init = A_arbace_pprint_split_at_newline_A_Init; i.Table = A_arbace_pprint_split_at_newline_A_members; jrt.RegisterGoType(A_arbace_pprint_split_at_newline_A_class, reflect.TypeFor[A_arbace_pprint_split_at_newline_A]()) }

func A_arbace_pprint_split_at_newline_fn__1820000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_split_at_newline_fn__1820000128_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_split_at_newline_fn__1820000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_split_at_newline_fn__1820000128_A_New()}; return nil }

func A_arbace_pprint_split_at_newline_fn__1820000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_split_at_newline_fn__1820000128_A_fn_class)}; return nil }

var A_arbace_pprint_split_at_newline_fn__1820000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_split_at_newline_fn__1820000128_A_invoke, New: A_arbace_pprint_split_at_newline_fn__1820000128_A_new, Get: A_arbace_pprint_split_at_newline_fn__1820000128_A_get}

var A_arbace_pprint_split_at_newline_fn__1820000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$split_at_newline$fn__1820000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_split_at_newline_A_class, Simple: "fn__1820000128", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_split_at_newline_fn__1820000128_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_split_at_newline_fn__1820000128_A_class.Info(); i.IsInstance = A_arbace_pprint_split_at_newline_fn__1820000128_A_InstanceOf; i.Init = A_arbace_pprint_split_at_newline_fn__1820000128_A_Init; i.Table = A_arbace_pprint_split_at_newline_fn__1820000128_A_members; jrt.RegisterGoType(A_arbace_pprint_split_at_newline_fn__1820000128_A_class, reflect.TypeFor[A_arbace_pprint_split_at_newline_fn__1820000128_A]()) }

func A_arbace_pprint_start_block_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_start_block_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_start_block_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_start_block_A_New()}; return nil }

func A_arbace_pprint_start_block_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_start_block_A_fn_class)}; return nil }

var A_arbace_pprint_start_block_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_start_block_A_invoke, New: A_arbace_pprint_start_block_A_new, Get: A_arbace_pprint_start_block_A_get}

var A_arbace_pprint_start_block_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$start_block", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_pprint_A_class, Simple: "start_block", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_start_block_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_start_block_A_class.Info(); i.IsInstance = A_arbace_pprint_start_block_A_InstanceOf; i.Init = A_arbace_pprint_start_block_A_Init; i.Table = A_arbace_pprint_start_block_A_members; jrt.RegisterGoType(A_arbace_pprint_start_block_A_class, reflect.TypeFor[A_arbace_pprint_start_block_A]()) }

func A_arbace_pprint_start_block_fn__1820000190_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_start_block_fn__1820000190_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_start_block_fn__1820000190_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_start_block_fn__1820000190_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_start_block_fn__1820000190_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_start_block_fn__1820000190_A_fn_class)}; return nil }

var A_arbace_pprint_start_block_fn__1820000190_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_start_block_fn__1820000190_A_invoke, New: A_arbace_pprint_start_block_fn__1820000190_A_new, Get: A_arbace_pprint_start_block_fn__1820000190_A_get}

var A_arbace_pprint_start_block_fn__1820000190_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$start_block$fn__1820000190", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_start_block_A_class, Simple: "fn__1820000190", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_start_block_fn__1820000190_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_start_block_fn__1820000190_A_class.Info(); i.IsInstance = A_arbace_pprint_start_block_fn__1820000190_A_InstanceOf; i.Init = A_arbace_pprint_start_block_fn__1820000190_A_Init; i.Table = A_arbace_pprint_start_block_fn__1820000190_A_members; jrt.RegisterGoType(A_arbace_pprint_start_block_fn__1820000190_A_class, reflect.TypeFor[A_arbace_pprint_start_block_fn__1820000190_A]()) }

func A_arbace_pprint_start_block_t_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_start_block_t_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_start_block_t_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_start_block_t_QMARK__A_New()}; return nil }

func A_arbace_pprint_start_block_t_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_start_block_t_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_start_block_t_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_start_block_t_QMARK__A_invoke, New: A_arbace_pprint_start_block_t_QMARK__A_new, Get: A_arbace_pprint_start_block_t_QMARK__A_get}

var A_arbace_pprint_start_block_t_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$start_block_t_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "start_block_t_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_start_block_t_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_start_block_t_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_start_block_t_QMARK__A_Init; i.Table = A_arbace_pprint_start_block_t_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_start_block_t_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_start_block_t_QMARK__A]()) }

func A_arbace_pprint_table_ize_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_table_ize_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_table_ize_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_table_ize_A_New()}; return nil }

func A_arbace_pprint_table_ize_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_table_ize_A_fn_class)}; return nil }

var A_arbace_pprint_table_ize_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_table_ize_A_invoke, New: A_arbace_pprint_table_ize_A_new, Get: A_arbace_pprint_table_ize_A_get}

var A_arbace_pprint_table_ize_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$table_ize", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "table_ize", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_table_ize_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_table_ize_A_class.Info(); i.IsInstance = A_arbace_pprint_table_ize_A_InstanceOf; i.Init = A_arbace_pprint_table_ize_A_Init; i.Table = A_arbace_pprint_table_ize_A_members; jrt.RegisterGoType(A_arbace_pprint_table_ize_A_class, reflect.TypeFor[A_arbace_pprint_table_ize_A]()) }

func A_arbace_pprint_table_ize_fn__693000011_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_table_ize_fn__693000011_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_table_ize_fn__693000011_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_table_ize_fn__693000011_A_New_O(args[0])}; return nil }

func A_arbace_pprint_table_ize_fn__693000011_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_table_ize_fn__693000011_A_fn_class)}; return nil }

var A_arbace_pprint_table_ize_fn__693000011_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_table_ize_fn__693000011_A_invoke, New: A_arbace_pprint_table_ize_fn__693000011_A_new, Get: A_arbace_pprint_table_ize_fn__693000011_A_get}

var A_arbace_pprint_table_ize_fn__693000011_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$table_ize$fn__693000011", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_table_ize_A_class, Simple: "fn__693000011", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_table_ize_fn__693000011_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_table_ize_fn__693000011_A_class.Info(); i.IsInstance = A_arbace_pprint_table_ize_fn__693000011_A_InstanceOf; i.Init = A_arbace_pprint_table_ize_fn__693000011_A_Init; i.Table = A_arbace_pprint_table_ize_fn__693000011_A_members; jrt.RegisterGoType(A_arbace_pprint_table_ize_fn__693000011_A_class, reflect.TypeFor[A_arbace_pprint_table_ize_fn__693000011_A]()) }

func A_arbace_pprint_tokens_fit_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_tokens_fit_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_tokens_fit_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_tokens_fit_QMARK__A_New()}; return nil }

func A_arbace_pprint_tokens_fit_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_tokens_fit_QMARK__A_fn_class)}; return nil }

var A_arbace_pprint_tokens_fit_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_tokens_fit_QMARK__A_invoke, New: A_arbace_pprint_tokens_fit_QMARK__A_new, Get: A_arbace_pprint_tokens_fit_QMARK__A_get}

var A_arbace_pprint_tokens_fit_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$tokens_fit_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "tokens_fit_QMARK_", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_tokens_fit_QMARK__A_class.Info(); i.IsInstance = A_arbace_pprint_tokens_fit_QMARK__A_InstanceOf; i.Init = A_arbace_pprint_tokens_fit_QMARK__A_Init; i.Table = A_arbace_pprint_tokens_fit_QMARK__A_members; jrt.RegisterGoType(A_arbace_pprint_tokens_fit_QMARK__A_class, reflect.TypeFor[A_arbace_pprint_tokens_fit_QMARK__A]()) }

func A_arbace_pprint_toks_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_toks_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_toks_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_toks_A_New()}; return nil }

func A_arbace_pprint_toks_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_toks_A_fn_class)}; return nil }

var A_arbace_pprint_toks_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_toks_A_invoke, New: A_arbace_pprint_toks_A_new, Get: A_arbace_pprint_toks_A_get}

var A_arbace_pprint_toks_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$toks", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "toks", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_toks_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_toks_A_class.Info(); i.IsInstance = A_arbace_pprint_toks_A_InstanceOf; i.Init = A_arbace_pprint_toks_A_Init; i.Table = A_arbace_pprint_toks_A_members; jrt.RegisterGoType(A_arbace_pprint_toks_A_class, reflect.TypeFor[A_arbace_pprint_toks_A]()) }

func A_arbace_pprint_translate_param_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_translate_param_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_translate_param_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_translate_param_A_New()}; return nil }

func A_arbace_pprint_translate_param_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_translate_param_A_fn_class)}; return nil }

var A_arbace_pprint_translate_param_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_translate_param_A_invoke, New: A_arbace_pprint_translate_param_A_new, Get: A_arbace_pprint_translate_param_A_get}

var A_arbace_pprint_translate_param_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$translate_param", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "translate_param", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_translate_param_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_translate_param_A_class.Info(); i.IsInstance = A_arbace_pprint_translate_param_A_InstanceOf; i.Init = A_arbace_pprint_translate_param_A_Init; i.Table = A_arbace_pprint_translate_param_A_members; jrt.RegisterGoType(A_arbace_pprint_translate_param_A_class, reflect.TypeFor[A_arbace_pprint_translate_param_A]()) }

func A_arbace_pprint_tuple_map_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_tuple_map_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_tuple_map_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_tuple_map_A_New()}; return nil }

func A_arbace_pprint_tuple_map_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_tuple_map_A_fn_class)}; return nil }

var A_arbace_pprint_tuple_map_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_tuple_map_A_invoke, New: A_arbace_pprint_tuple_map_A_new, Get: A_arbace_pprint_tuple_map_A_get}

var A_arbace_pprint_tuple_map_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$tuple_map", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "tuple_map", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_tuple_map_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_tuple_map_A_class.Info(); i.IsInstance = A_arbace_pprint_tuple_map_A_InstanceOf; i.Init = A_arbace_pprint_tuple_map_A_Init; i.Table = A_arbace_pprint_tuple_map_A_members; jrt.RegisterGoType(A_arbace_pprint_tuple_map_A_class, reflect.TypeFor[A_arbace_pprint_tuple_map_A]()) }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_New_O(args[0])}; return nil }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_fn_class)}; return nil }

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_invoke, New: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_new, Get: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_get}

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$tuple_map$iter__1470000059__1470000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_tuple_map_A_class, Simple: "iter__1470000059__1470000063", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_class.Info(); i.IsInstance = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_InstanceOf; i.Init = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_Init; i.Table = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_members; jrt.RegisterGoType(A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_class, reflect.TypeFor[A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A]()) }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_fn_class)}; return nil }

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_invoke, New: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_new, Get: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_get}

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$tuple_map$iter__1470000059__1470000063$fn__1470000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_A_class, Simple: "fn__1470000064", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_class.Info(); i.IsInstance = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_InstanceOf; i.Init = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_Init; i.Table = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_members; jrt.RegisterGoType(A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_class, reflect.TypeFor[A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A]()) }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_fn_class)}; return nil }

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_invoke, New: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_new, Get: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_get}

var A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$tuple_map$iter__1470000059__1470000063$fn__1470000064$fn__1470000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_A_class, Simple: "fn__1470000065", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_class.Info(); i.IsInstance = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_InstanceOf; i.Init = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_Init; i.Table = A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_members; jrt.RegisterGoType(A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A_class, reflect.TypeFor[A_arbace_pprint_tuple_map_iter__1470000059__1470000063_fn__1470000064_fn__1470000065_A]()) }

func A_arbace_pprint_two_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_two_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_two_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_two_forms_A_New()}; return nil }

func A_arbace_pprint_two_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_two_forms_A_fn_class)}; return nil }

var A_arbace_pprint_two_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_two_forms_A_invoke, New: A_arbace_pprint_two_forms_A_new, Get: A_arbace_pprint_two_forms_A_get}

var A_arbace_pprint_two_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$two_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "two_forms", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_two_forms_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_two_forms_A_class.Info(); i.IsInstance = A_arbace_pprint_two_forms_A_InstanceOf; i.Init = A_arbace_pprint_two_forms_A_Init; i.Table = A_arbace_pprint_two_forms_A_members; jrt.RegisterGoType(A_arbace_pprint_two_forms_A_class, reflect.TypeFor[A_arbace_pprint_two_forms_A]()) }

func A_arbace_pprint_two_forms_iter__740000181__740000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_two_forms_iter__740000181__740000185_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_two_forms_iter__740000181__740000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_two_forms_iter__740000181__740000185_A_New()}; return nil }

func A_arbace_pprint_two_forms_iter__740000181__740000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_two_forms_iter__740000181__740000185_A_fn_class)}; return nil }

var A_arbace_pprint_two_forms_iter__740000181__740000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_two_forms_iter__740000181__740000185_A_invoke, New: A_arbace_pprint_two_forms_iter__740000181__740000185_A_new, Get: A_arbace_pprint_two_forms_iter__740000181__740000185_A_get}

var A_arbace_pprint_two_forms_iter__740000181__740000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$two_forms$iter__740000181__740000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_two_forms_A_class, Simple: "iter__740000181__740000185", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_two_forms_iter__740000181__740000185_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_two_forms_iter__740000181__740000185_A_class.Info(); i.IsInstance = A_arbace_pprint_two_forms_iter__740000181__740000185_A_InstanceOf; i.Init = A_arbace_pprint_two_forms_iter__740000181__740000185_A_Init; i.Table = A_arbace_pprint_two_forms_iter__740000181__740000185_A_members; jrt.RegisterGoType(A_arbace_pprint_two_forms_iter__740000181__740000185_A_class, reflect.TypeFor[A_arbace_pprint_two_forms_iter__740000181__740000185_A]()) }

func A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_fn_class)}; return nil }

var A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_invoke, New: A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_new, Get: A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_get}

var A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$two_forms$iter__740000181__740000185$fn__740000186", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_two_forms_iter__740000181__740000185_A_class, Simple: "fn__740000186", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_class.Info(); i.IsInstance = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_InstanceOf; i.Init = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_Init; i.Table = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_members; jrt.RegisterGoType(A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_class, reflect.TypeFor[A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A]()) }

func A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_fn_class)}; return nil }

var A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_invoke, New: A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_new, Get: A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_get}

var A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$two_forms$iter__740000181__740000185$fn__740000186$fn__740000187", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_A_class, Simple: "fn__740000187", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_class.Info(); i.IsInstance = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_InstanceOf; i.Init = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_Init; i.Table = A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_members; jrt.RegisterGoType(A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A_class, reflect.TypeFor[A_arbace_pprint_two_forms_iter__740000181__740000185_fn__740000186_fn__740000187_A]()) }

func A_arbace_pprint_unzip_map_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_unzip_map_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_unzip_map_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_unzip_map_A_New()}; return nil }

func A_arbace_pprint_unzip_map_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_unzip_map_A_fn_class)}; return nil }

var A_arbace_pprint_unzip_map_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_unzip_map_A_invoke, New: A_arbace_pprint_unzip_map_A_new, Get: A_arbace_pprint_unzip_map_A_get}

var A_arbace_pprint_unzip_map_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$unzip_map", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "unzip_map", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_unzip_map_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_unzip_map_A_class.Info(); i.IsInstance = A_arbace_pprint_unzip_map_A_InstanceOf; i.Init = A_arbace_pprint_unzip_map_A_Init; i.Table = A_arbace_pprint_unzip_map_A_members; jrt.RegisterGoType(A_arbace_pprint_unzip_map_A_class, reflect.TypeFor[A_arbace_pprint_unzip_map_A]()) }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_New()}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_fn_class)}; return nil }

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_invoke, New: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_new, Get: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_get}

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$unzip_map$iter__1470000014__1470000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_unzip_map_A_class, Simple: "iter__1470000014__1470000018", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_class.Info(); i.IsInstance = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_InstanceOf; i.Init = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_Init; i.Table = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_members; jrt.RegisterGoType(A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_class, reflect.TypeFor[A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A]()) }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_fn_class)}; return nil }

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_invoke, New: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_new, Get: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_get}

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$unzip_map$iter__1470000014__1470000018$fn__1470000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_A_class, Simple: "fn__1470000019", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_class.Info(); i.IsInstance = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_InstanceOf; i.Init = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_Init; i.Table = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_members; jrt.RegisterGoType(A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_class, reflect.TypeFor[A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A]()) }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_fn_class)}; return nil }

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_invoke, New: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_new, Get: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_get}

var A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$unzip_map$iter__1470000014__1470000018$fn__1470000019$fn__1470000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_A_class, Simple: "fn__1470000020", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_class.Info(); i.IsInstance = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_InstanceOf; i.Init = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_Init; i.Table = A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_members; jrt.RegisterGoType(A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A_class, reflect.TypeFor[A_arbace_pprint_unzip_map_iter__1470000014__1470000018_fn__1470000019_fn__1470000020_A]()) }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_New()}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_fn_class)}; return nil }

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_invoke, New: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_new, Get: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_get}

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$unzip_map$iter__1470000036__1470000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_unzip_map_A_class, Simple: "iter__1470000036__1470000040", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_class.Info(); i.IsInstance = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_InstanceOf; i.Init = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_Init; i.Table = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_members; jrt.RegisterGoType(A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_class, reflect.TypeFor[A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A]()) }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_fn_class)}; return nil }

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_invoke, New: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_new, Get: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_get}

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$unzip_map$iter__1470000036__1470000040$fn__1470000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_A_class, Simple: "fn__1470000041", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_class.Info(); i.IsInstance = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_InstanceOf; i.Init = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_Init; i.Table = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_members; jrt.RegisterGoType(A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_class, reflect.TypeFor[A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A]()) }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_fn_class)}; return nil }

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_invoke, New: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_new, Get: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_get}

var A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$unzip_map$iter__1470000036__1470000040$fn__1470000041$fn__1470000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_A_class, Simple: "fn__1470000042", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A", Source: "utilities.ae"})

func init() { i := A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_class.Info(); i.IsInstance = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_InstanceOf; i.Init = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_Init; i.Table = A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_members; jrt.RegisterGoType(A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A_class, reflect.TypeFor[A_arbace_pprint_unzip_map_iter__1470000036__1470000040_fn__1470000041_fn__1470000042_A]()) }

func A_arbace_pprint_upcase_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_upcase_writer_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_upcase_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_upcase_writer_A_New()}; return nil }

func A_arbace_pprint_upcase_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_upcase_writer_A_fn_class)}; return nil }

var A_arbace_pprint_upcase_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_upcase_writer_A_invoke, New: A_arbace_pprint_upcase_writer_A_new, Get: A_arbace_pprint_upcase_writer_A_get}

var A_arbace_pprint_upcase_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$upcase_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "upcase_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_upcase_writer_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_upcase_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_upcase_writer_A_InstanceOf; i.Init = A_arbace_pprint_upcase_writer_A_Init; i.Table = A_arbace_pprint_upcase_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_upcase_writer_A_class, reflect.TypeFor[A_arbace_pprint_upcase_writer_A]()) }

func A_arbace_pprint_upcase_writer_fn__1819000225_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_upcase_writer_fn__1819000225_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_upcase_writer_fn__1819000225_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_upcase_writer_fn__1819000225_A_New_O(args[0])}; return nil }

func A_arbace_pprint_upcase_writer_fn__1819000225_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_upcase_writer_fn__1819000225_A_fn_class)}; return nil }

var A_arbace_pprint_upcase_writer_fn__1819000225_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_upcase_writer_fn__1819000225_A_invoke, New: A_arbace_pprint_upcase_writer_fn__1819000225_A_new, Get: A_arbace_pprint_upcase_writer_fn__1819000225_A_get}

var A_arbace_pprint_upcase_writer_fn__1819000225_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$upcase_writer$fn__1819000225", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_upcase_writer_A_class, Simple: "fn__1819000225", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_upcase_writer_fn__1819000225_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_upcase_writer_fn__1819000225_A_class.Info(); i.IsInstance = A_arbace_pprint_upcase_writer_fn__1819000225_A_InstanceOf; i.Init = A_arbace_pprint_upcase_writer_fn__1819000225_A_Init; i.Table = A_arbace_pprint_upcase_writer_fn__1819000225_A_members; jrt.RegisterGoType(A_arbace_pprint_upcase_writer_fn__1819000225_A_class, reflect.TypeFor[A_arbace_pprint_upcase_writer_fn__1819000225_A]()) }

func A_arbace_pprint_upcase_writer_fn__1819000227_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_upcase_writer_fn__1819000227_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_upcase_writer_fn__1819000227_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_upcase_writer_fn__1819000227_A_New_O(args[0])}; return nil }

func A_arbace_pprint_upcase_writer_fn__1819000227_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_upcase_writer_fn__1819000227_A_fn_class)}; return nil }

var A_arbace_pprint_upcase_writer_fn__1819000227_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_upcase_writer_fn__1819000227_A_invoke, New: A_arbace_pprint_upcase_writer_fn__1819000227_A_new, Get: A_arbace_pprint_upcase_writer_fn__1819000227_A_get}

var A_arbace_pprint_upcase_writer_fn__1819000227_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$upcase_writer$fn__1819000227", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_upcase_writer_A_class, Simple: "fn__1819000227", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_upcase_writer_fn__1819000227_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_upcase_writer_fn__1819000227_A_class.Info(); i.IsInstance = A_arbace_pprint_upcase_writer_fn__1819000227_A_InstanceOf; i.Init = A_arbace_pprint_upcase_writer_fn__1819000227_A_Init; i.Table = A_arbace_pprint_upcase_writer_fn__1819000227_A_members; jrt.RegisterGoType(A_arbace_pprint_upcase_writer_fn__1819000227_A_class, reflect.TypeFor[A_arbace_pprint_upcase_writer_fn__1819000227_A]()) }

func A_arbace_pprint_upcase_writer_fn__1819000229_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_upcase_writer_fn__1819000229_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_pprint_upcase_writer_fn__1819000229_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_upcase_writer_fn__1819000229_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_upcase_writer_fn__1819000229_A_New_O(args[0])}; return nil }

func A_arbace_pprint_upcase_writer_fn__1819000229_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_upcase_writer_fn__1819000229_A_fn_class)}; return nil }

var A_arbace_pprint_upcase_writer_fn__1819000229_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_upcase_writer_fn__1819000229_A_invoke, New: A_arbace_pprint_upcase_writer_fn__1819000229_A_new, Get: A_arbace_pprint_upcase_writer_fn__1819000229_A_get}

var A_arbace_pprint_upcase_writer_fn__1819000229_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$upcase_writer$fn__1819000229", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_upcase_writer_A_class, Simple: "fn__1819000229", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_upcase_writer_fn__1819000229_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_upcase_writer_fn__1819000229_A_class.Info(); i.IsInstance = A_arbace_pprint_upcase_writer_fn__1819000229_A_InstanceOf; i.Init = A_arbace_pprint_upcase_writer_fn__1819000229_A_Init; i.Table = A_arbace_pprint_upcase_writer_fn__1819000229_A_members; jrt.RegisterGoType(A_arbace_pprint_upcase_writer_fn__1819000229_A_class, reflect.TypeFor[A_arbace_pprint_upcase_writer_fn__1819000229_A]()) }

func A_arbace_pprint_update_nl_state_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_update_nl_state_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_update_nl_state_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_update_nl_state_A_New()}; return nil }

func A_arbace_pprint_update_nl_state_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_update_nl_state_A_fn_class)}; return nil }

var A_arbace_pprint_update_nl_state_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_update_nl_state_A_invoke, New: A_arbace_pprint_update_nl_state_A_new, Get: A_arbace_pprint_update_nl_state_A_get}

var A_arbace_pprint_update_nl_state_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$update_nl_state", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "update_nl_state", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_update_nl_state_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_update_nl_state_A_class.Info(); i.IsInstance = A_arbace_pprint_update_nl_state_A_InstanceOf; i.Init = A_arbace_pprint_update_nl_state_A_Init; i.Table = A_arbace_pprint_update_nl_state_A_members; jrt.RegisterGoType(A_arbace_pprint_update_nl_state_A_class, reflect.TypeFor[A_arbace_pprint_update_nl_state_A]()) }

func A_arbace_pprint_update_nl_state_fn__1820000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_update_nl_state_fn__1820000121_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_update_nl_state_fn__1820000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_update_nl_state_fn__1820000121_A_New_O(args[0])}; return nil }

func A_arbace_pprint_update_nl_state_fn__1820000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_update_nl_state_fn__1820000121_A_fn_class)}; return nil }

var A_arbace_pprint_update_nl_state_fn__1820000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_update_nl_state_fn__1820000121_A_invoke, New: A_arbace_pprint_update_nl_state_fn__1820000121_A_new, Get: A_arbace_pprint_update_nl_state_fn__1820000121_A_get}

var A_arbace_pprint_update_nl_state_fn__1820000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$update_nl_state$fn__1820000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_update_nl_state_A_class, Simple: "fn__1820000121", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_update_nl_state_fn__1820000121_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_update_nl_state_fn__1820000121_A_class.Info(); i.IsInstance = A_arbace_pprint_update_nl_state_fn__1820000121_A_InstanceOf; i.Init = A_arbace_pprint_update_nl_state_fn__1820000121_A_Init; i.Table = A_arbace_pprint_update_nl_state_fn__1820000121_A_members; jrt.RegisterGoType(A_arbace_pprint_update_nl_state_fn__1820000121_A_class, reflect.TypeFor[A_arbace_pprint_update_nl_state_fn__1820000121_A]()) }

func A_arbace_pprint_use_method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_use_method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_use_method_A_New()}; return nil }

func A_arbace_pprint_use_method_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_use_method_A_fn_class)}; return nil }

var A_arbace_pprint_use_method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_use_method_A_invoke, New: A_arbace_pprint_use_method_A_new, Get: A_arbace_pprint_use_method_A_get}

var A_arbace_pprint_use_method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$use_method", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "use_method", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_use_method_A", Source: "dispatch.ae"})

func init() { i := A_arbace_pprint_use_method_A_class.Info(); i.IsInstance = A_arbace_pprint_use_method_A_InstanceOf; i.Init = A_arbace_pprint_use_method_A_Init; i.Table = A_arbace_pprint_use_method_A_members; jrt.RegisterGoType(A_arbace_pprint_use_method_A_class, reflect.TypeFor[A_arbace_pprint_use_method_A]()) }

func A_arbace_pprint_with_pprint_dispatch_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_with_pprint_dispatch_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_with_pprint_dispatch_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_with_pprint_dispatch_A_New()}; return nil }

func A_arbace_pprint_with_pprint_dispatch_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_with_pprint_dispatch_A_fn_class)}; return nil }

var A_arbace_pprint_with_pprint_dispatch_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_with_pprint_dispatch_A_invoke, New: A_arbace_pprint_with_pprint_dispatch_A_new, Get: A_arbace_pprint_with_pprint_dispatch_A_get}

var A_arbace_pprint_with_pprint_dispatch_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$with_pprint_dispatch", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_pprint_A_class, Simple: "with_pprint_dispatch", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_with_pprint_dispatch_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_with_pprint_dispatch_A_class.Info(); i.IsInstance = A_arbace_pprint_with_pprint_dispatch_A_InstanceOf; i.Init = A_arbace_pprint_with_pprint_dispatch_A_Init; i.Table = A_arbace_pprint_with_pprint_dispatch_A_members; jrt.RegisterGoType(A_arbace_pprint_with_pprint_dispatch_A_class, reflect.TypeFor[A_arbace_pprint_with_pprint_dispatch_A]()) }

func A_arbace_pprint_with_pretty_writer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_with_pretty_writer_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_pprint_with_pretty_writer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_with_pretty_writer_A_New()}; return nil }

func A_arbace_pprint_with_pretty_writer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_with_pretty_writer_A_fn_class)}; return nil }

var A_arbace_pprint_with_pretty_writer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_with_pretty_writer_A_invoke, New: A_arbace_pprint_with_pretty_writer_A_new, Get: A_arbace_pprint_with_pretty_writer_A_get}

var A_arbace_pprint_with_pretty_writer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$with_pretty_writer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_pprint_A_class, Simple: "with_pretty_writer", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_with_pretty_writer_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_with_pretty_writer_A_class.Info(); i.IsInstance = A_arbace_pprint_with_pretty_writer_A_InstanceOf; i.Init = A_arbace_pprint_with_pretty_writer_A_Init; i.Table = A_arbace_pprint_with_pretty_writer_A_members; jrt.RegisterGoType(A_arbace_pprint_with_pretty_writer_A_class, reflect.TypeFor[A_arbace_pprint_with_pretty_writer_A]()) }

func A_arbace_pprint_write_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_write_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_A_New()}; return nil }

func A_arbace_pprint_write_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_A_fn_class)}; return nil }

var A_arbace_pprint_write_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_A_invoke, New: A_arbace_pprint_write_A_new, Get: A_arbace_pprint_write_A_get}

var A_arbace_pprint_write_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_pprint_A_class, Simple: "write", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_write_A_class.Info(); i.IsInstance = A_arbace_pprint_write_A_InstanceOf; i.Init = A_arbace_pprint_write_A_Init; i.Table = A_arbace_pprint_write_A_members; jrt.RegisterGoType(A_arbace_pprint_write_A_class, reflect.TypeFor[A_arbace_pprint_write_A]()) }

func A_arbace_pprint_write_fn__693000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_fn__693000026_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_write_fn__693000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_fn__693000026_A_New_O(args[0])}; return nil }

func A_arbace_pprint_write_fn__693000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_fn__693000026_A_fn_class)}; return nil }

var A_arbace_pprint_write_fn__693000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_fn__693000026_A_invoke, New: A_arbace_pprint_write_fn__693000026_A_new, Get: A_arbace_pprint_write_fn__693000026_A_get}

var A_arbace_pprint_write_fn__693000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write$fn__693000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_write_A_class, Simple: "fn__693000026", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_fn__693000026_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_write_fn__693000026_A_class.Info(); i.IsInstance = A_arbace_pprint_write_fn__693000026_A_InstanceOf; i.Init = A_arbace_pprint_write_fn__693000026_A_Init; i.Table = A_arbace_pprint_write_fn__693000026_A_members; jrt.RegisterGoType(A_arbace_pprint_write_fn__693000026_A_class, reflect.TypeFor[A_arbace_pprint_write_fn__693000026_A]()) }

func A_arbace_pprint_write_fn__693000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_fn__693000028_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_write_fn__693000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_fn__693000028_A_New_O(args[0])}; return nil }

func A_arbace_pprint_write_fn__693000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_fn__693000028_A_fn_class)}; return nil }

var A_arbace_pprint_write_fn__693000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_fn__693000028_A_invoke, New: A_arbace_pprint_write_fn__693000028_A_new, Get: A_arbace_pprint_write_fn__693000028_A_get}

var A_arbace_pprint_write_fn__693000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write$fn__693000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_write_A_class, Simple: "fn__693000028", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_fn__693000028_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_write_fn__693000028_A_class.Info(); i.IsInstance = A_arbace_pprint_write_fn__693000028_A_InstanceOf; i.Init = A_arbace_pprint_write_fn__693000028_A_Init; i.Table = A_arbace_pprint_write_fn__693000028_A_members; jrt.RegisterGoType(A_arbace_pprint_write_fn__693000028_A_class, reflect.TypeFor[A_arbace_pprint_write_fn__693000028_A]()) }

func A_arbace_pprint_write_buffered_output_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_buffered_output_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_write_buffered_output_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_buffered_output_A_New()}; return nil }

func A_arbace_pprint_write_buffered_output_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_buffered_output_A_fn_class)}; return nil }

var A_arbace_pprint_write_buffered_output_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_buffered_output_A_invoke, New: A_arbace_pprint_write_buffered_output_A_new, Get: A_arbace_pprint_write_buffered_output_A_get}

var A_arbace_pprint_write_buffered_output_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_buffered_output", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "write_buffered_output", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_buffered_output_A_class.Info(); i.IsInstance = A_arbace_pprint_write_buffered_output_A_InstanceOf; i.Init = A_arbace_pprint_write_buffered_output_A_Init; i.Table = A_arbace_pprint_write_buffered_output_A_members; jrt.RegisterGoType(A_arbace_pprint_write_buffered_output_A_class, reflect.TypeFor[A_arbace_pprint_write_buffered_output_A]()) }

func A_arbace_pprint_write_initial_lines_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_initial_lines_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_write_initial_lines_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_initial_lines_A_New()}; return nil }

func A_arbace_pprint_write_initial_lines_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_initial_lines_A_fn_class)}; return nil }

var A_arbace_pprint_write_initial_lines_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_initial_lines_A_invoke, New: A_arbace_pprint_write_initial_lines_A_new, Get: A_arbace_pprint_write_initial_lines_A_get}

var A_arbace_pprint_write_initial_lines_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_initial_lines", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "write_initial_lines", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_initial_lines_A_class.Info(); i.IsInstance = A_arbace_pprint_write_initial_lines_A_InstanceOf; i.Init = A_arbace_pprint_write_initial_lines_A_Init; i.Table = A_arbace_pprint_write_initial_lines_A_members; jrt.RegisterGoType(A_arbace_pprint_write_initial_lines_A_class, reflect.TypeFor[A_arbace_pprint_write_initial_lines_A]()) }

func A_arbace_pprint_write_initial_lines_fn__1820000163_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_initial_lines_fn__1820000163_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_write_initial_lines_fn__1820000163_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_initial_lines_fn__1820000163_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_pprint_write_initial_lines_fn__1820000163_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_initial_lines_fn__1820000163_A_fn_class)}; return nil }

var A_arbace_pprint_write_initial_lines_fn__1820000163_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_initial_lines_fn__1820000163_A_invoke, New: A_arbace_pprint_write_initial_lines_fn__1820000163_A_new, Get: A_arbace_pprint_write_initial_lines_fn__1820000163_A_get}

var A_arbace_pprint_write_initial_lines_fn__1820000163_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_initial_lines$fn__1820000163", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_write_initial_lines_A_class, Simple: "fn__1820000163", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_initial_lines_fn__1820000163_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_initial_lines_fn__1820000163_A_class.Info(); i.IsInstance = A_arbace_pprint_write_initial_lines_fn__1820000163_A_InstanceOf; i.Init = A_arbace_pprint_write_initial_lines_fn__1820000163_A_Init; i.Table = A_arbace_pprint_write_initial_lines_fn__1820000163_A_members; jrt.RegisterGoType(A_arbace_pprint_write_initial_lines_fn__1820000163_A_class, reflect.TypeFor[A_arbace_pprint_write_initial_lines_fn__1820000163_A]()) }

func A_arbace_pprint_write_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_line_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_write_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_line_A_New()}; return nil }

func A_arbace_pprint_write_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_line_A_fn_class)}; return nil }

var A_arbace_pprint_write_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_line_A_invoke, New: A_arbace_pprint_write_line_A_new, Get: A_arbace_pprint_write_line_A_get}

var A_arbace_pprint_write_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "write_line", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_line_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_line_A_class.Info(); i.IsInstance = A_arbace_pprint_write_line_A_InstanceOf; i.Init = A_arbace_pprint_write_line_A_Init; i.Table = A_arbace_pprint_write_line_A_members; jrt.RegisterGoType(A_arbace_pprint_write_line_A_class, reflect.TypeFor[A_arbace_pprint_write_line_A]()) }

func A_arbace_pprint_write_line_fn__1820000153_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_line_fn__1820000153_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_write_line_fn__1820000153_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_line_fn__1820000153_A_New_O(args[0])}; return nil }

func A_arbace_pprint_write_line_fn__1820000153_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_line_fn__1820000153_A_fn_class)}; return nil }

var A_arbace_pprint_write_line_fn__1820000153_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_line_fn__1820000153_A_invoke, New: A_arbace_pprint_write_line_fn__1820000153_A_new, Get: A_arbace_pprint_write_line_fn__1820000153_A_get}

var A_arbace_pprint_write_line_fn__1820000153_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_line$fn__1820000153", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_write_line_A_class, Simple: "fn__1820000153", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_line_fn__1820000153_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_line_fn__1820000153_A_class.Info(); i.IsInstance = A_arbace_pprint_write_line_fn__1820000153_A_InstanceOf; i.Init = A_arbace_pprint_write_line_fn__1820000153_A_Init; i.Table = A_arbace_pprint_write_line_fn__1820000153_A_members; jrt.RegisterGoType(A_arbace_pprint_write_line_fn__1820000153_A_class, reflect.TypeFor[A_arbace_pprint_write_line_fn__1820000153_A]()) }

func A_arbace_pprint_write_out_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_out_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_write_out_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_out_A_New()}; return nil }

func A_arbace_pprint_write_out_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_out_A_fn_class)}; return nil }

var A_arbace_pprint_write_out_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_out_A_invoke, New: A_arbace_pprint_write_out_A_new, Get: A_arbace_pprint_write_out_A_get}

var A_arbace_pprint_write_out_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_out", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "write_out", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_out_A", Source: "pprint_base.ae"})

func init() { i := A_arbace_pprint_write_out_A_class.Info(); i.IsInstance = A_arbace_pprint_write_out_A_InstanceOf; i.Init = A_arbace_pprint_write_out_A_Init; i.Table = A_arbace_pprint_write_out_A_members; jrt.RegisterGoType(A_arbace_pprint_write_out_A_class, reflect.TypeFor[A_arbace_pprint_write_out_A]()) }

func A_arbace_pprint_write_to_base_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_to_base_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_write_to_base_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_to_base_A_New()}; return nil }

func A_arbace_pprint_write_to_base_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_to_base_A_fn_class)}; return nil }

var A_arbace_pprint_write_to_base_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_to_base_A_invoke, New: A_arbace_pprint_write_to_base_A_new, Get: A_arbace_pprint_write_to_base_A_get}

var A_arbace_pprint_write_to_base_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_to_base", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_pprint_A_class, Simple: "write_to_base", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_to_base_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_to_base_A_class.Info(); i.IsInstance = A_arbace_pprint_write_to_base_A_InstanceOf; i.Init = A_arbace_pprint_write_to_base_A_Init; i.Table = A_arbace_pprint_write_to_base_A_members; jrt.RegisterGoType(A_arbace_pprint_write_to_base_A_class, reflect.TypeFor[A_arbace_pprint_write_to_base_A]()) }

func A_arbace_pprint_write_token_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_token_string_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_pprint_write_token_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_token_string_A_New()}; return nil }

func A_arbace_pprint_write_token_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_token_string_A_fn_class)}; return nil }

var A_arbace_pprint_write_token_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_token_string_A_invoke, New: A_arbace_pprint_write_token_string_A_new, Get: A_arbace_pprint_write_token_string_A_get}

var A_arbace_pprint_write_token_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_token_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_pprint_A_class, Simple: "write_token_string", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_token_string_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_token_string_A_class.Info(); i.IsInstance = A_arbace_pprint_write_token_string_A_InstanceOf; i.Init = A_arbace_pprint_write_token_string_A_Init; i.Table = A_arbace_pprint_write_token_string_A_members; jrt.RegisterGoType(A_arbace_pprint_write_token_string_A_class, reflect.TypeFor[A_arbace_pprint_write_token_string_A]()) }

func A_arbace_pprint_write_tokens_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_tokens_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_pprint_write_tokens_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_tokens_A_New()}; return nil }

func A_arbace_pprint_write_tokens_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_tokens_A_fn_class)}; return nil }

var A_arbace_pprint_write_tokens_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_tokens_A_invoke, New: A_arbace_pprint_write_tokens_A_new, Get: A_arbace_pprint_write_tokens_A_get}

var A_arbace_pprint_write_tokens_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_tokens", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_pprint_A_class, Simple: "write_tokens", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_tokens_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_tokens_A_class.Info(); i.IsInstance = A_arbace_pprint_write_tokens_A_InstanceOf; i.Init = A_arbace_pprint_write_tokens_A_Init; i.Table = A_arbace_pprint_write_tokens_A_members; jrt.RegisterGoType(A_arbace_pprint_write_tokens_A_class, reflect.TypeFor[A_arbace_pprint_write_tokens_A]()) }

func A_arbace_pprint_write_white_space_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_white_space_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_pprint_write_white_space_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_white_space_A_New()}; return nil }

func A_arbace_pprint_write_white_space_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_white_space_A_fn_class)}; return nil }

var A_arbace_pprint_write_white_space_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_white_space_A_invoke, New: A_arbace_pprint_write_white_space_A_new, Get: A_arbace_pprint_write_white_space_A_get}

var A_arbace_pprint_write_white_space_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_white_space", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_pprint_A_class, Simple: "write_white_space", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_white_space_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_white_space_A_class.Info(); i.IsInstance = A_arbace_pprint_write_white_space_A_InstanceOf; i.Init = A_arbace_pprint_write_white_space_A_Init; i.Table = A_arbace_pprint_write_white_space_A_members; jrt.RegisterGoType(A_arbace_pprint_write_white_space_A_class, reflect.TypeFor[A_arbace_pprint_write_white_space_A]()) }

func A_arbace_pprint_write_white_space_fn__1820000160_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_pprint_write_white_space_fn__1820000160_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_pprint_write_white_space_fn__1820000160_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_write_white_space_fn__1820000160_A_New_O(args[0])}; return nil }

func A_arbace_pprint_write_white_space_fn__1820000160_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_pprint_write_white_space_fn__1820000160_A_fn_class)}; return nil }

var A_arbace_pprint_write_white_space_fn__1820000160_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_pprint_write_white_space_fn__1820000160_A_invoke, New: A_arbace_pprint_write_white_space_fn__1820000160_A_new, Get: A_arbace_pprint_write_white_space_fn__1820000160_A_get}

var A_arbace_pprint_write_white_space_fn__1820000160_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint$write_white_space$fn__1820000160", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_pprint_write_white_space_A_class, Simple: "fn__1820000160", Go: "arbace/aot_arbace_pprint.A_arbace_pprint_write_white_space_fn__1820000160_A", Source: "pretty_writer.ae"})

func init() { i := A_arbace_pprint_write_white_space_fn__1820000160_A_class.Info(); i.IsInstance = A_arbace_pprint_write_white_space_fn__1820000160_A_InstanceOf; i.Init = A_arbace_pprint_write_white_space_fn__1820000160_A_Init; i.Table = A_arbace_pprint_write_white_space_fn__1820000160_A_members; jrt.RegisterGoType(A_arbace_pprint_write_white_space_fn__1820000160_A_class, reflect.TypeFor[A_arbace_pprint_write_white_space_fn__1820000160_A]()) }

func A_arbace_pprint_PrettyFlush_A_invoke(i int32, this any, args []any) any { switch i { case 0: this.(A_arbace_pprint_PrettyFlush_A).Ppflush__V(); return nil}; return nil }

var A_arbace_pprint_PrettyFlush_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 ppflush ()V", Invoke: A_arbace_pprint_PrettyFlush_A_invoke}

var A_arbace_pprint_PrettyFlush_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint.PrettyFlush", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_pprint.A_arbace_pprint_PrettyFlush_A"})

func init() { i := A_arbace_pprint_PrettyFlush_A_class.Info(); i.IsInstance = A_arbace_pprint_PrettyFlush_A_InstanceOf; i.Table = A_arbace_pprint_PrettyFlush_A_members }

func A_arbace_pprint__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_pprint__init_A_Load__O(); case 1: return A_arbace_pprint__init_A_Unit0__O(); case 2: return A_arbace_pprint__init_A_Unit1__O(); case 3: return A_arbace_pprint__init_A_Unit10__O(); case 4: return A_arbace_pprint__init_A_Unit11__O(); case 5: return A_arbace_pprint__init_A_Unit12__O(); case 6: return A_arbace_pprint__init_A_Unit2__O(); case 7: return A_arbace_pprint__init_A_Unit3__O(); case 8: return A_arbace_pprint__init_A_Unit4__O(); case 9: return A_arbace_pprint__init_A_Unit5__O(); case 10: return A_arbace_pprint__init_A_Unit6__O(); case 11: return A_arbace_pprint__init_A_Unit7__O(); case 12: return A_arbace_pprint__init_A_Unit8__O(); case 13: return A_arbace_pprint__init_A_Unit9__O()}; return nil }

func A_arbace_pprint__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint__init_A_New()}; return nil }

var A_arbace_pprint__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_pprint__init_A_invoke, New: A_arbace_pprint__init_A_new}

var A_arbace_pprint__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_pprint.A_arbace_pprint__init_A", Source: "pprint.ae"})

func init() { i := A_arbace_pprint__init_A_class.Info(); i.IsInstance = A_arbace_pprint__init_A_InstanceOf; i.Init = A_arbace_pprint__init_A_Init; i.Table = A_arbace_pprint__init_A_members; jrt.RegisterGoType(A_arbace_pprint__init_A_class, reflect.TypeFor[A_arbace_pprint__init_A]()) }
