//line j2g_strings.ae:1
package aot_arbace_pprint

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.walkkn4,onlyyn4,walkyn11,arbace.corekn7,excludeyn7,deftypekn4,linekn6,columnkn6,authorkn3,dockn5,addedys13,arbace.pprint5,prerryn5,quotekn3,curkn3,maxkn4,baseys11,arbace.core5,derefyn4,thisys11,arbace.core5,alterys11,arbace.core5,assocyn2,doys11,arbace.core9,defstructkn8,type-tagys11,arbace.core11,alter-meta!yn3,varkn7,privateys11,arbace.core5,defn-yn1,&yn24,vals__1820000016__auto__ys11,arbace.core5,applyys11,arbace.core6,structyn21,x__1820000017__auto__ys11,arbace.core1,=ys11,arbace.core3,letyn21,w__1820000023__auto__kn3,tagyn14,java.io.Writerys13,arbace.pprint4,getfyn6,.writekn6,parentkn4,elsekn7,end-poskn9,start-poskn11,buffer-blobkn4,nl-tkn13,start-block-tkn11,end-block-tkn8,indent-tkn13,logical-blockkn6,indentkn6,prefixkn9,start-colkn22,logical-block-callbackkn5,startkn6,suffixkn3,endkn6,offsetkn11,relative-tokn5,blockkn7,currentkn4,datakn20,trailing-white-spacekn4,typekn9,mandatorykn4,fillkn7,done-nlkn14,intra-block-nlkn15,per-line-prefixkn6,bufferkn14,logical-blockskn9,bufferingkn4,modekn3,poskn7,writingkn13,pretty-writerkn8,sectionskn12,buffer-blockkn12,buffer-levelkn11,miser-widthyn1,.yn15,arbace.lang.Varys13,arbace.pprint18,pushThreadBindingsyn3,tryyn7,finallyys13,arbace.pprint17,popThreadBindingsyn30,base-writer__693000016__auto__yn29,new-writer__693000017__auto__ys11,arbace.core3,notys13,arbace.pprint14,pretty-writer?ys11,arbace.core7,bindingys11,arbace.core5,*out*yn2,ifys13,arbace.pprint18,make-pretty-writerys13,arbace.pprint20,*print-right-margin*ys13,arbace.pprint19,*print-miser-width*yn8,.ppflushyn25,arbace.pprint.PrettyFlushkn6,streamys13,arbace.pprint6,pprintys11,arbace.core2,*1ys13,arbace.pprint23,*print-pprint-dispatch*ys13,arbace.pprint14,level-exceededys11,arbace.core20,push-thread-bindingsys13,arbace.pprint15,*current-level*ys11,arbace.core3,incys11,arbace.core7,var-getys13,arbace.pprint16,*current-length*ys13,arbace.pprint11,start-blockys13,arbace.pprint9,end-blockys11,arbace.core19,pop-thread-bindingskn5,miserkn6,linearkn7,sectionkn13,line-relativekn16,section-relativeyn5,recuryn5,loop*ys11,arbace.core4,loopys11,arbace.core2,orys11,arbace.core14,*print-length*ys11,arbace.core1,<kn4,restkn3,seqkn5,colonkn2,atkn19,parameter-from-argskn19,remaining-arg-countkn6,minpadkn6,mincolkn6,colinckn7,padcharkn13,commaintervalkn9,commacharkn11,char-formatkn8,up-arrowkn14,colon-up-arrowkn6,paramskn9,base-argskn4,funckn1,wkn1,dkn1,kkn12,overflowcharkn1,ekn12,exponentcharkn1,nkn8,selectorkn7,clauseskn14,max-iterationskn12,right-paramskn11,else-paramskn13,min-remainingkn11,max-columnskn6,colnumkn6,stringkn9,directiveys11,arbace.core9,array-mapkn5,flagskn12,bracket-infokn12,generator-fnyn2,fnyn6,paramsyn6,offsetyn3,defys13,arbace.pprint15,directive-tableys11,arbace.core8,hash-mapkn5,countkn4,arg1kn4,arg2kn4,arg3kn5,levelkn6,lengthkn6,prettykn4,bothkn5,rightkn3,defkn9,separatorkn13,right-bracketkn5,firstkn16,allows-separatoryn29,format-in__1819000582__auto__yn26,my-c-c__1819000583__auto__ys11,arbace.core3,getys11,arbace.core10,ns-internsys11,arbace.core6,the-nsyn13,arbace.pprintyn14,cached-compileyn26,my-e-f__1819000584__auto__yn14,execute-formatyn26,my-i-n__1819000585__auto__yn14,init-navigatoryn22,cf__1819000586__auto__ys11,arbace.core7,string?ys11,arbace.core2,fnyn26,stream__1819000587__auto__yn24,args__1819000588__auto__yn29,navigator__1819000589__auto__yn29,format-in__1819000595__auto__yn22,cf__1819000596__auto__ys13,arbace.pprint14,cached-compileyn24,args__1819000597__auto__yn29,navigator__1819000598__auto__ys13,arbace.pprint14,init-navigatorys13,arbace.pprint14,execute-formatv11,arbace.core3,useV3,R0,R1,V1,R2,v11,arbace.core5,referR3,R4,ML1,R5,m4,R6,i38,R7,i30,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.pprintm6,R8,s13,Tom FaulhaberR9,s1084,A Pretty Printer for Clojure\n\narbace.pprint implements a flexible system for printing structured data\nin a pleasing, easy-to-understand format. Basic use of the pretty printer is\nsimple, just call pprint instead of println. More advanced users can use\nthe building blocks provided to create custom output formats.\n\nOut of the box, pprint supports a simple structured format for basic data\nand a specialized format for Clojure source code. More advanced formats,\nincluding formats that don't look like Clojure data at all like XML and\nJSON, can be rendered by creating custom dispatch functions.\n\nIn addition to the pprint function, this module contains cl-format, a text\nformatting function which is fully compatible with the format function in\nCommon Lisp. Because pretty printing directives are directly integrated with\ncl-format, it supports very concise custom dispatch. It also provides\na more powerful alternative to Clojure's standard format function.\n\nSee documentation for pprint and cl-format for more information or\ncomplete documentation on the Clojure web site on GitHub.R10,s3,1.2v11,arbace.core6,empty?v11,arbace.core5,firstv11,arbace.core4,nextv11,arbace.core5,applyv11,arbace.core3,notv11,arbace.core4,intov11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core4,subsl0,v11,arbace.core5,coll?v11,arbace.core3,setv11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core6,concatv11,arbace.core4,listR11,R12,v11,arbace.core6,mapcatR12,v11,arbace.core5,alterv11,arbace.core5,assocv13,arbace.pprint9,get-fieldR13,R6,R14,v13,arbace.pprint9,set-fieldR15,c10,v11,arbace.core3,refv11,arbace.core10,init-proxyv11,arbace.core1,=v11,arbace.core5,classv13,arbace.pprint12,c-write-charC16,java.lang.Stringv11,arbace.core6,filterC17,java.lang.IntegerC14,java.lang.Longv13,arbace.pprint13,column-writerv13,arbace.pprint20,*default-page-width*R16,R17,R18,R17,R19,v11,arbace.core4,nameR20,R21,R22,R23,R24,R19,R25,R26,v11,arbace.core6,symbolv11,arbace.core6,vectorR27,R28,R29,R30,v11,arbace.core7,keywordR26,R31,R32,R33,v11,arbace.core9,with-metaR34,R35,R36,R37,R38,R39,R40,R41,v11,arbace.core4,lastR42,v11,arbace.core6,structv13,arbace.pprint11,buffer-blobR43,v13,arbace.pprint4,nl-tR44,v13,arbace.pprint13,start-block-tR45,v13,arbace.pprint11,end-block-tR46,v13,arbace.pprint8,indent-tR47,R48,v13,arbace.pprint10,get-columnv11,arbace.core7,ref-setR49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,v13,arbace.pprint7,emit-nlv13,arbace.pprint11,write-tokenv13,arbace.pprint14,get-max-columnv13,arbace.pprint13,buffer-lengthv13,arbace.pprint11,tokens-fit?v13,arbace.pprint15,get-miser-widthv13,arbace.pprint10,linear-nl?v13,arbace.pprint9,miser-nl?R66,v11,arbace.core10,take-whilev13,arbace.pprint5,nl-t?v13,arbace.pprint9,ancestor?v11,arbace.core4,dropR67,v13,arbace.pprint15,update-nl-statev13,arbace.pprint10,pp-newlinev11,arbace.core3,strv11,arbace.core6,repeatc32,v11,arbace.core3,mapv13,arbace.pprint3,tokv13,arbace.pprint16,split-at-newlinev13,arbace.pprint11,get-sectionv13,arbace.pprint8,emit-nl?v13,arbace.pprint18,write-token-stringv13,arbace.pprint12,write-tokensv13,arbace.pprint15,get-sub-sectionR68,v13,arbace.pprint10,write-linel-1,R69,R70,R71,R72,v13,arbace.pprint21,write-buffered-outputv11,arbace.core7,butlastR73,v13,arbace.pprint13,add-to-bufferv13,arbace.pprint16,make-buffer-blobv13,arbace.pprint17,write-white-spacev13,arbace.pprint19,write-initial-linesv13,arbace.pprint13,logical-blockR74,R75,R76,R77,l1,R78,v13,arbace.pprint12,p-write-charv13,arbace.pprint18,make-start-block-tv13,arbace.pprint16,make-end-block-tv13,arbace.pprint9,make-nl-tv13,arbace.pprint13,make-indent-tv13,arbace.pprint20,format-simple-numberv11,arbace.core5,printv13,arbace.pprint7,orig-prR20,R79,R80,R81,R82,R83,R79,R80,R84,v11,arbace.core3,keyv11,arbace.core8,find-varv11,arbace.core3,valv13,arbace.pprint13,pretty-writerR33,R85,R86,R87,R88,R89,R90,R91,R92,R93,R94,R95,R90,R96,v13,arbace.pprint16,*current-length*v11,arbace.core14,*print-length*v13,arbace.pprint14,*print-pretty*v11,arbace.core2,prv13,arbace.pprint23,*print-pprint-dispatch*v11,arbace.core5,mergem2,R97,Tv11,arbace.core9,contains?R97,v13,arbace.pprint9,table-izev13,arbace.pprint18,write-option-tablev13,arbace.pprint12,*print-base*v13,arbace.pprint13,*print-radix*v13,arbace.pprint12,pr-with-basev13,arbace.pprint14,pretty-writer?v13,arbace.pprint9,write-outv13,arbace.pprint18,make-pretty-writerv13,arbace.pprint20,*print-right-margin*v13,arbace.pprint19,*print-miser-width*v11,arbace.core3,prnv13,arbace.pprint6,pprintR98,R99,v11,arbace.core11,alter-meta!v11,arbace.core10,constantlyv11,arbace.core14,alter-var-rootR89,R100,l2,v11,arbace.core4,takev11,arbace.core13,*print-level*v13,arbace.pprint15,*current-level*v13,arbace.pprint16,parse-lb-optionsS3,R54,R50,R67,R20,R91,R101,R38,R90,R36,R20,R102,R103,R104,R105,R103,R106,R82,R107,R90,R108,R90,R83,R109,v13,arbace.pprint2,nlv13,arbace.pprint20,check-enumerated-argS4,R63,R110,R64,R111,v13,arbace.pprint6,indentS2,R58,R59,S4,R112,R6,R113,R114,v11,arbace.core4,seq?v11,arbace.core11,macroexpandR115,R104,v11,arbace.walk4,walkv11,arbace.core8,identityR116,R115,v11,arbace.core6,gensymv13,arbace.pprint12,pll-mod-bodyR117,R91,R118,R87,R119,R120,R119,R20,R38,R90,R36,v11,arbace.core7,string?v13,arbace.pprint14,compile-formatv13,arbace.pprint14,init-navigatorv13,arbace.pprint14,execute-formatv13,arbace.pprint12,*format-str*v13,arbace.pprint13,arg-navigatorR121,R122,v13,arbace.pprint8,next-argv13,arbace.pprint19,relative-repositionv13,arbace.pprint19,absolute-repositionS2,R123,R124,R125,R126,v13,arbace.pprint19,map-passing-contextv13,arbace.pprint17,realize-parameterv11,arbace.core8,integer?v13,arbace.pprint21,special-radix-markersv13,arbace.pprint12,opt-base-strv11,arbace.core6,ratio?R127,R128,R129,R130,R124,v11,arbace.core8,decimal?v11,arbace.core6,bigdecv11,arbace.core6,float?v11,arbace.core7,reversev13,arbace.pprint7,consumeV2,nnc48,c97,v13,arbace.pprint10,remaindersv13,arbace.pprint17,java-base-formatsv11,arbace.core6,formatv13,arbace.pprint8,base-strv13,arbace.pprint9,integral?R123,v13,arbace.pprint9,group-by*R131,R132,v11,arbace.core10,interleavev13,arbace.pprint12,format-asciiv11,arbace.core9,print-strv13,arbace.pprint22,english-cardinal-unitsv13,arbace.pprint21,english-cardinal-tensv11,arbace.core9,interposev13,arbace.pprint21,english-scale-numbersl1000,v13,arbace.pprint22,format-simple-cardinalv13,arbace.pprint18,add-english-scalesv13,arbace.pprint14,format-integerl10,m10,R128,l0,R130,c32,R132,c44,R131,l3,R123,Tm8,R128,l0,R130,l0,R132,l0,R131,l0,v13,arbace.pprint21,english-ordinal-unitsv13,arbace.pprint20,english-ordinal-tensl1000,v11,arbace.core9,drop-lastv13,arbace.pprint21,format-simple-ordinalm10,R128,l0,R130,c32,R132,c44,R131,l3,R123,Tm8,R128,l0,R130,l0,R132,l0,R131,l0,v11,arbace.core7,number?m10,R128,l0,R130,c32,R132,c44,R131,l3,R123,Tm8,R128,l0,R130,l0,R132,l0,R131,l0,v13,arbace.pprint12,format-romanv13,arbace.pprint15,old-roman-tablev13,arbace.pprint15,new-roman-tablev13,arbace.pprint13,special-charsR133,v13,arbace.pprint9,cl-formatc111,c117,R134,R135,v11,arbace.core6,secondv13,arbace.pprint6,abort?v13,arbace.pprint22,realize-parameter-listR136,v13,arbace.pprint9,unzip-mapR137,R138,c101,c46,v13,arbace.pprint16,float-parts-basev13,arbace.pprint5,rtrimv13,arbace.pprint5,ltrimc43,V2,s1,0l0,c57,V3,s1,0l0,Fc53,v13,arbace.pprint5,inc-sv13,arbace.pprint14,insert-decimalv13,arbace.pprint12,expand-fixedv11,arbace.core4,not=R139,R140,v13,arbace.pprint13,convert-ratiov13,arbace.pprint11,float-partsR141,v13,arbace.pprint9,round-strv13,arbace.pprint9,get-fixedR142,R143,R144,c69,c45,v13,arbace.pprint21,insert-scaled-decimall4,v11,arbace.core2,<=v13,arbace.pprint11,fixed-floatv13,arbace.pprint17,exponential-floatR145,R146,R147,v13,arbace.pprint18,execute-sub-formatR148,v13,arbace.pprint14,get-format-argR149,v13,arbace.pprint15,next-arg-or-nilv13,arbace.pprint20,format-logical-blockv13,arbace.pprint15,justify-clausesv13,arbace.pprint14,render-clausesR150,R151,R152,v11,arbace.core6,reducev11,arbace.core1,+v11,arbace.core5,countV2,nnv11,arbace.core10,re-matcherp4,\\W\\wv11,arbace.core7,re-findv13,arbace.pprint17,capitalize-stringp2,\\SR153,R154,v13,arbace.pprint14,level-exceededv13,arbace.pprint9,end-blockv13,arbace.pprint11,start-blockv11,arbace.core7,var-getv13,arbace.pprint13,pprint-indentR110,R111,v13,arbace.pprint14,pprint-newlineR155,R156,R157,R158,R159,ML2,R160,V2,R161,R162,m4,R6,i1319,R7,i28,R163,R164,R165,v13,arbace.pprint31,process-directive-table-elementv11,arbace.core6,pr-strl8,l16,v13,arbace.pprint16,format-old-romanv13,arbace.pprint16,format-new-romanv13,arbace.pprint22,format-ordinal-englishv13,arbace.pprint23,format-cardinal-englishV2,s1,ys3,iesV2,s0,s1,sv13,arbace.pprint16,pretty-characterv13,arbace.pprint18,readable-characterv13,arbace.pprint15,plain-characterv13,arbace.pprint13,general-floatv13,arbace.pprint12,dollar-floatR166,v13,arbace.pprint10,fresh-linec12,c126,v13,arbace.pprint19,relative-tabulationv13,arbace.pprint19,absolute-tabulationv13,arbace.pprint13,upcase-writerv13,arbace.pprint22,capitalize-word-writerv13,arbace.pprint15,init-cap-writerv13,arbace.pprint15,downcase-writerv13,arbace.pprint11,modify-casev13,arbace.pprint19,boolean-conditionalv13,arbace.pprint21,check-arg-conditionalv13,arbace.pprint18,choice-conditionalv13,arbace.pprint21,iterate-main-sublistsv13,arbace.pprint24,iterate-list-of-sublistsv13,arbace.pprint17,iterate-main-listv13,arbace.pprint15,iterate-sublistv13,arbace.pprint24,logical-block-or-justifyR167,R168,R169,V4,R170,nR171,nV2,R172,Tv13,arbace.pprint5,writev13,arbace.pprint19,conditional-newlinev13,arbace.pprint10,set-indentv13,arbace.pprint13,param-patternv11,arbace.core9,re-groupsc44,v13,arbace.pprint12,format-errorv13,arbace.pprint13,extract-paramS2,c86,c118,c35,c39,v13,arbace.pprint9,flag-defsR173,v11,arbace.core9,array-mapv11,arbace.core6,zipmapv11,arbace.core4,keysv13,arbace.pprint11,check-flagsv11,arbace.core5,doallv13,arbace.pprint14,special-paramsv11,arbace.core9,instance?v13,arbace.pprint14,extract-paramsv13,arbace.pprint13,extract-flagsv13,arbace.pprint15,directive-tablev13,arbace.pprint10,map-paramsv13,arbace.pprint15,translate-paramv13,arbace.pprint18,compiled-directivev13,arbace.pprint12,prefix-countV2,c32,c9,R174,R175,R176,v13,arbace.pprint15,collect-clausesv13,arbace.pprint9,tuple-mapv13,arbace.pprint13,right-bracketv13,arbace.pprint15,process-bracketv13,arbace.pprint15,else-separator?v13,arbace.pprint10,separator?R177,v13,arbace.pprint14,process-clauseR178,R179,v11,arbace.core10,merge-withv13,arbace.pprint15,process-nestingv13,arbace.pprint17,compile-directivev13,arbace.pprint18,compile-raw-stringR172,v11,arbace.core4,somev13,arbace.pprint12,needs-prettyv11,arbace.core5,true?v13,arbace.pprint17,get-pretty-writerR33,R180,R181,R105,R182,R183,R184,R12,R185,R186,R187,R105,R182,R183,R184,R185,R188,R189,R105,R182,R183,R184,R185,R190,R191,R91,R192,R193,R194,R27,R195,R33,R196,R33,R197,R198,R91,R192,R199,R193,R27,R200,R33,R201,R202,R203,v13,arbace.pprint13,reader-macrosv11,arbace.core12,*print-meta*v13,arbace.pprint10,pprint-mapv13,arbace.pprint11,pprint-metav13,arbace.pprint19,pprint-reader-macrov13,arbace.pprint18,pprint-simple-listv13,arbace.pprint14,cached-compilev11,arbace.core7,record?v11,arbace.core7,lift-nsv11,arbace.core6,ffirstv11,arbace.core5,fnextv11,arbace.core12,deref-as-mapv13,arbace.pprint12,pprint-arrayv13,arbace.pprint27,*print-suppress-namespaces*v11,arbace.core7,symbol?v11,arbace.core7,vector?V2,s1,[s1,]V2,s1,(s1,)v11,arbace.core11,sequential?v13,arbace.pprint8,bracketsv11,arbace.core8,keyword?v11,arbace.core4,map?v13,arbace.pprint19,pprint-ns-referencev13,arbace.pprint23,pprint-simple-code-listv13,arbace.pprint11,single-defnv13,arbace.pprint10,multi-defnv13,arbace.pprint19,pprint-binding-forml3,v13,arbace.pprint12,*symbol-map*v11,arbace.core5,rangev11,arbace.core9,namespacev11,arbace.core15,special-symbol?v13,arbace.pprint12,*code-table*v11,arbace.core3,maxv13,arbace.pprint11,print-table")

var Lit_1 *jrt.String = jrt.Intern("arbace.core")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint$add_core_ns$fn__740000193")

var Lit_3 *jrt.String = jrt.Intern(", ")

var Lit_4 *jrt.String = jrt.Intern(" ")

var Lit_5 *jrt.String = jrt.Intern("arbace.pprint$add_to_buffer$fn__1820000156")

var Lit_6 *jrt.String = jrt.Intern("0")

var Lit_7 *jrt.String = jrt.Intern("arbace.pprint$base_str$fn__1819000039")

var Lit_8 *jrt.String = jrt.Intern("arbace.pprint$c_write_char$fn__44000015")

var Lit_9 *jrt.String = jrt.Intern("arbace.pprint$capitalize_string$fn__1819000234")

var Lit_10 *jrt.String = jrt.Intern("arbace.pprint.proxy$java.io.Writer$ff19274a")

var Lit_11 *jrt.String = jrt.Intern("close")

var Lit_12 *jrt.String = jrt.Intern("arbace.pprint$capitalize_word_writer$fn__1819000237")

var Lit_13 *jrt.String = jrt.Intern("flush")

var Lit_14 *jrt.String = jrt.Intern("arbace.pprint$capitalize_word_writer$fn__1819000239")

var Lit_15 *jrt.String = jrt.Intern("write")

var Lit_16 *jrt.String = jrt.Intern("arbace.pprint$capitalize_word_writer$fn__1819000241")

var Lit_17 *jrt.String = jrt.Intern("arbace.pprint$capitalize_word_writer$fn__1819000241$fn__1819000244")

var Lit_18 *jrt.String = jrt.Intern("arbace.pprint$capitalize_word_writer$fn__1819000241$fn__1819000246")

var Lit_19 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_20 *jrt.String = jrt.Intern("Bad argument: ")

var Lit_21 *jrt.String = jrt.Intern(". It must be one of ")

var Lit_22 *jrt.String = jrt.Intern("\"@\" is an illegal flag for format directive \"")

var Lit_23 *jrt.String = jrt.Intern("\"")

var Lit_24 *jrt.String = jrt.Intern("\":\" is an illegal flag for format directive \"")

var Lit_25 *jrt.String = jrt.Intern("Cannot combine \"@\" and \":\" flags for format directive \"")

var Lit_26 *jrt.String = jrt.Intern("arbace.pprint$collect_clauses$fn__1819000548")

var Lit_27 *jrt.String = jrt.Intern("Two else clauses (\"~:;\") inside bracket construction.")

var Lit_28 *jrt.String = jrt.Intern("An else clause (\"~:;\") is in a bracket type that doesn't support it.")

var Lit_29 *jrt.String = jrt.Intern("The else clause (\"~:;\") is only allowed in the first position for this directive.")

var Lit_30 *jrt.String = jrt.Intern("A plain clause (with \"~;\") follows an else clause (\"~:;\") inside bracket construction.")

var Lit_31 *jrt.String = jrt.Intern("A separator (\"~;\") is in a bracket type that doesn't support it.")

var Lit_32 *jrt.String = jrt.Intern("arbace.pprint.proxy$java.io.Writer$IDeref$a9558fb3")

var Lit_33 *jrt.String = jrt.Intern("deref")

var Lit_34 *jrt.String = jrt.Intern("arbace.pprint$column_writer$fn__44000019")

var Lit_35 *jrt.String = jrt.Intern("arbace.pprint$column_writer$fn__44000021")

var Lit_36 *jrt.String = jrt.Intern("arbace.pprint$column_writer$fn__44000023")

var Lit_37 *jrt.String = jrt.Intern("arbace.pprint$column_writer$fn__44000023$fn__44000026")

var Lit_38 *jrt.String = jrt.Intern("arbace.pprint$column_writer$fn__44000023$fn__44000026$fn__44000027")

var Lit_39 *jrt.String = jrt.Intern("Format string ended in the middle of a directive")

var Lit_40 *jrt.String = jrt.Intern("Directive \"")

var Lit_41 *jrt.String = jrt.Intern("\" is undefined")

var Lit_42 *jrt.String = jrt.Intern("arbace.pprint$compile_format$fn__1819000564")

var Lit_43 *jrt.String = jrt.Intern("")

var Lit_44 *jrt.String = jrt.Intern("arbace.pprint$compile_raw_string$fn__1819000534")

var Lit_45 *jrt.String = jrt.Intern("make-")

var Lit_46 *jrt.String = jrt.Intern("?")

var Lit_47 *jrt.String = jrt.Intern("arbace.pprint$downcase_writer$fn__1819000216")

var Lit_48 *jrt.String = jrt.Intern("arbace.pprint$downcase_writer$fn__1819000218")

var Lit_49 *jrt.String = jrt.Intern("arbace.pprint$downcase_writer$fn__1819000220")

var Lit_50 *jrt.String = jrt.Intern("arbace.pprint$emit_nl$fn__1820000124")

var Lit_51 *jrt.String = jrt.Intern("arbace.pprint$end_block$fn__1820000193")

var Lit_52 *jrt.String = jrt.Intern("arbace.pprint$eval1820000059$fn__1820000060$fn__1820000061")

var Lit_53 *jrt.String = jrt.Intern("arbace.pprint$eval1820000079$fn__1820000080$fn__1820000081")

var Lit_54 *jrt.String = jrt.Intern("arbace.pprint$execute_format$fn__1819000571")

var Lit_55 *jrt.String = jrt.Intern("arbace.pprint$execute_format$fn__1819000573")

var Lit_56 *jrt.String = jrt.Intern("arbace.pprint$execute_sub_format$fn__1819000085")

var Lit_57 *jrt.String = jrt.Intern("arbace.pprint$extract_flags$fn__1819000480")

var Lit_58 *jrt.String = jrt.Intern("Flag \"")

var Lit_59 *jrt.String = jrt.Intern("\" appears more than once in a directive")

var Lit_60 *jrt.String = jrt.Intern("Badly formed parameters in format directive")

var Lit_61 *jrt.String = jrt.Intern("-")

var Lit_62 *jrt.String = jrt.Intern("+")

var Lit_63 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000328$fn__1819000329")

var Lit_64 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000332$fn__1819000333")

var Lit_65 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000336$fn__1819000337")

var Lit_66 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000340$fn__1819000341")

var Lit_67 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000344$fn__1819000345")

var Lit_68 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000348$fn__1819000349")

var Lit_69 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000352$fn__1819000353")

var Lit_70 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000352$fn__1819000355")

var Lit_71 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000352$fn__1819000357")

var Lit_72 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000352$fn__1819000359")

var Lit_73 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000352$fn__1819000361")

var Lit_74 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000364$fn__1819000365")

var Lit_75 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000381$fn__1819000382")

var Lit_76 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000385$fn__1819000386")

var Lit_77 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000389$fn__1819000390")

var Lit_78 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000393$fn__1819000394")

var Lit_79 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000397$fn__1819000398")

var Lit_80 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000401$fn__1819000402")

var Lit_81 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000401$fn__1819000404")

var Lit_82 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000407$fn__1819000408")

var Lit_83 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000407$fn__1819000410")

var Lit_84 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000413$fn__1819000414")

var Lit_85 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000413$fn__1819000419")

var Lit_86 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000428$fn__1819000429")

var Lit_87 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000448$fn__1819000449")

var Lit_88 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000452$fn__1819000453")

var Lit_89 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000452$fn__1819000458")

var Lit_90 *jrt.String = jrt.Intern("line.separator")

var Lit_91 *jrt.String = jrt.Intern("~<[~;~@{~w~^, ~:_~}~;]~:>")

var Lit_92 *jrt.String = jrt.Intern("arbace.pprint$fn__740000014$fn__740000015")

var Lit_93 *jrt.String = jrt.Intern("~<<-(~;~@{~w~^ ~_~}~;)-<~:>")

var Lit_94 *jrt.String = jrt.Intern("arbace.pprint$fn__740000032$fn__740000033")

var Lit_95 *jrt.String = jrt.Intern("~:<~w~^ ~@_~w~^ ~_~@{~w~^ ~_~}~:>")

var Lit_96 *jrt.String = jrt.Intern("arbace.pprint$fn__740000107$fn__740000108")

var Lit_97 *jrt.String = jrt.Intern("~:<~1I~w~^ ~@_~w~@{ ~_~w~}~:>")

var Lit_98 *jrt.String = jrt.Intern("arbace.pprint$fn__740000152$fn__740000153")

var Lit_99 *jrt.String = jrt.Intern("zero")

var Lit_100 *jrt.String = jrt.Intern("minus ")

var Lit_101 *jrt.String = jrt.Intern("arbace.pprint$format_integer$fn__1819000050")

var Lit_102 *jrt.String = jrt.Intern("(")

var Lit_103 *jrt.String = jrt.Intern(")")

var Lit_104 *jrt.String = jrt.Intern("#")

var Lit_105 *jrt.String = jrt.Intern("arbace.pprint$format_logical_block$fn__1819000271")

var Lit_106 *jrt.String = jrt.Intern("zeroth")

var Lit_107 *jrt.String = jrt.Intern("th")

var Lit_108 *jrt.String = jrt.Intern("st")

var Lit_109 *jrt.String = jrt.Intern("nd")

var Lit_110 *jrt.String = jrt.Intern("rd")

var Lit_111 *jrt.String = jrt.Intern(" hundred")

var Lit_112 *jrt.String = jrt.Intern(".")

var Lit_113 *jrt.String = jrt.Intern("r")

var Lit_114 *jrt.String = jrt.Intern("/")

var Lit_115 *jrt.String = jrt.Intern("arbace.pprint$get_section$fn__1820000114")

var Lit_116 *jrt.String = jrt.Intern("arbace.pprint$get_sub_section$fn__1820000118")

var Lit_117 *jrt.String = jrt.Intern("arbace.pprint$group_by_STAR_$fn__1819000043")

var Lit_118 *jrt.String = jrt.Intern("1")

var Lit_119 *jrt.String = jrt.Intern("arbace.pprint$indent$fn__1820000199")

var Lit_120 *jrt.String = jrt.Intern("arbace.pprint$init_cap_writer$fn__1819000250")

var Lit_121 *jrt.String = jrt.Intern("arbace.pprint$init_cap_writer$fn__1819000252")

var Lit_122 *jrt.String = jrt.Intern("arbace.pprint$init_cap_writer$fn__1819000254")

var Lit_123 *jrt.String = jrt.Intern("arbace.pprint$init_cap_writer$fn__1819000254$fn__1819000257")

var Lit_124 *jrt.String = jrt.Intern("arbace.pprint$init_cap_writer$fn__1819000254$fn__1819000259")

var Lit_125 *jrt.String = jrt.Intern("%@{ construct not consuming any arguments: Infinite loop!")

var Lit_126 *jrt.String = jrt.Intern("%{ construct not consuming any arguments: Infinite loop!")

var Lit_127 *jrt.String = jrt.Intern("Too many parameters for directive \"~C\": ~D~:* ~[were~;was~:;were~] specified but only ~D~:* ~[are~;is~:;are~] allowed")

var Lit_128 *jrt.String = jrt.Intern("arbace.pprint$map_params$fn__1819000492")

var Lit_129 *jrt.String = jrt.Intern("arbace.pprint$map_params$iter__1819000494__1819000498")

var Lit_130 *jrt.String = jrt.Intern("arbace.pprint$map_params$fn__1819000516")

var Lit_131 *jrt.String = jrt.Intern("arbace.pprint$map_params$fn__1819000518")

var Lit_132 *jrt.String = jrt.Intern("Parameter ")

var Lit_133 *jrt.String = jrt.Intern(" has bad type in directive \"")

var Lit_134 *jrt.String = jrt.Intern("\": ")

var Lit_135 *jrt.String = jrt.Intern("arbace.pprint$map_params$iter__1819000494__1819000498$fn__1819000499")

var Lit_136 *jrt.String = jrt.Intern("arbace.pprint$map_params$iter__1819000494__1819000498$fn__1819000499$fn__1819000500")

var Lit_137 *jrt.String = jrt.Intern(" ~_~{~w~^ ~_~}")

var Lit_138 *jrt.String = jrt.Intern("arbace.pprint$multi_defn$fn__740000118")

var Lit_139 *jrt.String = jrt.Intern("Not enough arguments for format definition")

var Lit_140 *jrt.String = jrt.Intern("arbace.pprint$nl$fn__1820000196")

var Lit_141 *jrt.String = jrt.Intern("\n")

var Lit_142 *jrt.String = jrt.Intern("arbace.pprint$p_write_char$fn__1820000170")

var Lit_143 *jrt.String = jrt.Intern("arbace.pprint$pll_mod_body$inner__693000059")

var Lit_144 *jrt.String = jrt.Intern("arbace.pprint$pprint$fn__693000031")

var Lit_145 *jrt.String = jrt.Intern("ppflush")

var Lit_146 *jrt.String = jrt.Intern("%")

var Lit_147 *jrt.String = jrt.Intern("arbace.pprint$pprint_anon_func$fn__740000172")

var Lit_148 *jrt.String = jrt.Intern("~<#(~;~@{~w~^ ~_~}~;)~:>")

var Lit_149 *jrt.String = jrt.Intern("arbace.pprint$pprint_anon_func$fn__740000174")

var Lit_150 *jrt.String = jrt.Intern("arbace.pprint$pprint_binding_form$fn__740000139")

var Lit_151 *jrt.String = jrt.Intern("[")

var Lit_152 *jrt.String = jrt.Intern("]")

var Lit_153 *jrt.String = jrt.Intern("arbace.pprint$pprint_binding_form$fn__740000139$fn__740000141")

var Lit_154 *jrt.String = jrt.Intern("...")

var Lit_155 *jrt.String = jrt.Intern("arbace.pprint$pprint_cond$fn__740000156")

var Lit_156 *jrt.String = jrt.Intern("arbace.pprint$pprint_cond$fn__740000156$fn__740000158")

var Lit_157 *jrt.String = jrt.Intern("arbace.pprint$pprint_condp$fn__740000162")

var Lit_158 *jrt.String = jrt.Intern("~w ~@_~w ~@_~w ~_")

var Lit_159 *jrt.String = jrt.Intern("arbace.pprint$pprint_condp$fn__740000162$fn__740000163")

var Lit_160 *jrt.String = jrt.Intern("arbace.pprint$pprint_condp$fn__740000162$fn__740000166")

var Lit_161 *jrt.String = jrt.Intern("arbace.pprint$pprint_defn$fn__740000130")

var Lit_162 *jrt.String = jrt.Intern("~w ~1I~@_~w")

var Lit_163 *jrt.String = jrt.Intern("arbace.pprint$pprint_defn$fn__740000130$fn__740000131")

var Lit_164 *jrt.String = jrt.Intern(" ~_~w")

var Lit_165 *jrt.String = jrt.Intern("arbace.pprint$pprint_defn$fn__740000130$fn__740000133")

var Lit_166 *jrt.String = jrt.Intern("arbace.pprint$pprint_defn$fn__740000130$fn__740000135")

var Lit_167 *jrt.String = jrt.Intern("#object[")

var Lit_168 *jrt.String = jrt.Intern("0x%x")

var Lit_169 *jrt.String = jrt.Intern("arbace.pprint$pprint_let$fn__740000145")

var Lit_170 *jrt.String = jrt.Intern("~w ~1I~@_")

var Lit_171 *jrt.String = jrt.Intern("arbace.pprint$pprint_let$fn__740000145$fn__740000146")

var Lit_172 *jrt.String = jrt.Intern("arbace.pprint$pprint_let$fn__740000145$fn__740000148")

var Lit_173 *jrt.String = jrt.Intern("#:")

var Lit_174 *jrt.String = jrt.Intern("{")

var Lit_175 *jrt.String = jrt.Intern("arbace.pprint$pprint_map$fn__740000021")

var Lit_176 *jrt.String = jrt.Intern("}")

var Lit_177 *jrt.String = jrt.Intern("arbace.pprint$pprint_map$fn__740000021$fn__740000023")

var Lit_178 *jrt.String = jrt.Intern("^")

var Lit_179 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns$fn__740000098")

var Lit_180 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns$fn__740000098$fn__740000099")

var Lit_181 *jrt.String = jrt.Intern("~@:_")

var Lit_182 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns$fn__740000098$fn__740000101")

var Lit_183 *jrt.String = jrt.Intern("\"~a\"~:[~;~:@_~]")

var Lit_184 *jrt.String = jrt.Intern("~w~:[~;~:@_~]")

var Lit_185 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns$fn__740000098$fn__740000103")

var Lit_186 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064")

var Lit_187 *jrt.String = jrt.Intern("~w~:i")

var Lit_188 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000065")

var Lit_189 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000067")

var Lit_190 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000072")

var Lit_191 *jrt.String = jrt.Intern("~_")

var Lit_192 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000083")

var Lit_193 *jrt.String = jrt.Intern("~:_")

var Lit_194 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000085")

var Lit_195 *jrt.String = jrt.Intern("~w ~w ")

var Lit_196 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000072$fn__740000076")

var Lit_197 *jrt.String = jrt.Intern("~<[~;~@{~w~^ ~:_~}~;]~:>")

var Lit_198 *jrt.String = jrt.Intern("~<(~;~@{~w~^ ~:_~}~;)~:>")

var Lit_199 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000072$fn__740000078")

var Lit_200 *jrt.String = jrt.Intern("~w ~:i~@{~w~^ ~:_~}")

var Lit_201 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference$fn__740000064$fn__740000072$fn__740000080")

var Lit_202 *jrt.String = jrt.Intern("arbace.pprint$pprint_set$fn__740000027")

var Lit_203 *jrt.String = jrt.Intern("#{")

var Lit_204 *jrt.String = jrt.Intern("arbace.pprint$pprint_simple_code_list$fn__740000177")

var Lit_205 *jrt.String = jrt.Intern("arbace.pprint$pprint_simple_list$fn__740000005")

var Lit_206 *jrt.String = jrt.Intern("pprint-tab is not yet implemented")

var Lit_207 *jrt.String = jrt.Intern("arbace.pprint$pprint_vector$fn__740000010")

var Lit_208 *jrt.String = jrt.Intern("Meta-")

var Lit_209 *jrt.String = jrt.Intern("Control-")

var Lit_210 *jrt.String = jrt.Intern("Control-?")

var Lit_211 *jrt.String = jrt.Intern("arbace.pprint.proxy$java.io.Writer$IDeref$PrettyFlush$f374094e")

var Lit_212 *jrt.String = jrt.Intern("arbace.pprint$pretty_writer$fn__1820000173")

var Lit_213 *jrt.String = jrt.Intern("arbace.pprint$pretty_writer$fn__1820000175")

var Lit_214 *jrt.String = jrt.Intern("arbace.pprint$pretty_writer$fn__1820000181")

var Lit_215 *jrt.String = jrt.Intern("arbace.pprint$pretty_writer$fn__1820000185")

var Lit_216 *jrt.String = jrt.Intern("arbace.pprint$pretty_writer$fn__1820000187")

var Lit_217 *jrt.String = jrt.Intern("replaceFirst")

var Lit_218 *jrt.String = jrt.Intern("\\s+$")

var Lit_219 *jrt.String = jrt.Intern("arbace.pprint$pretty_writer$fn__1820000175$fn__1820000178")

var Lit_220 *jrt.String = jrt.Intern("arbace.pprint$pretty_writer$fn__1820000181$fn__1820000182")

var Lit_221 *jrt.String = jrt.Intern("length-count")

var Lit_222 *jrt.String = jrt.Intern("arbace.pprint$print_table$fn__1821000006")

var Lit_223 *jrt.String = jrt.Intern("arbace.pprint$print_table$fn__1821000010")

var Lit_224 *jrt.String = jrt.Intern("arbace.pprint$print_table$fn__1821000012")

var Lit_225 *jrt.String = jrt.Intern("arbace.pprint$print_table$fmt_row__1821000014")

var Lit_226 *jrt.String = jrt.Intern("| ")

var Lit_227 *jrt.String = jrt.Intern(" | ")

var Lit_228 *jrt.String = jrt.Intern(" |")

var Lit_229 *jrt.String = jrt.Intern("|-")

var Lit_230 *jrt.String = jrt.Intern("-+-")

var Lit_231 *jrt.String = jrt.Intern("-|")

var Lit_232 *jrt.String = jrt.Intern("arbace.pprint$print_table$fmt_row__1821000014$iter__1821000015__1821000019")

var Lit_233 *jrt.String = jrt.Intern("arbace.pprint$print_table$fmt_row__1821000014$fn__1821000031")

var Lit_234 *jrt.String = jrt.Intern("arbace.pprint$print_table$fmt_row__1821000014$iter__1821000015__1821000019$fn__1821000020")

var Lit_235 *jrt.String = jrt.Intern("arbace.pprint$print_table$fmt_row__1821000014$iter__1821000015__1821000019$fn__1821000020$fn__1821000021")

var Lit_236 *jrt.String = jrt.Intern("arbace.pprint$print_table$fn__1821000006$fn__1821000007")

var Lit_237 *jrt.String = jrt.Intern("s")

var Lit_238 *jrt.String = jrt.Intern("arbace.pprint$prlabel$fn__1470000081")

var Lit_239 *jrt.String = jrt.Intern("=")

var Lit_240 *jrt.String = jrt.Intern("arbace.pprint$process_clause$fn__1819000544")

var Lit_241 *jrt.String = jrt.Intern("No closing bracket found.")

var Lit_242 *jrt.String = jrt.Intern("arbace.pprint$process_nesting$fn__1819000560")

var Lit_243 *jrt.String = jrt.Intern("\\o~3,'0o")

var Lit_244 *jrt.String = jrt.Intern("\\u~4,'0x")

var Lit_245 *jrt.String = jrt.Intern("arbace.pprint$remainders$fn__1819000035")

var Lit_246 *jrt.String = jrt.Intern("arbace.pprint$render_clauses$fn__1819000200")

var Lit_247 *jrt.String = jrt.Intern("arbace.pprint$set_logical_block_callback$fn__1820000208")

var Lit_248 *jrt.String = jrt.Intern("arbace.pprint$set_max_column$fn__44000011")

var Lit_249 *jrt.String = jrt.Intern("arbace.pprint$set_miser_width$fn__1820000205")

var Lit_250 *jrt.String = jrt.Intern(" ~_")

var Lit_251 *jrt.String = jrt.Intern("arbace.pprint$single_defn$fn__740000111")

var Lit_252 *jrt.String = jrt.Intern(" ~@_")

var Lit_253 *jrt.String = jrt.Intern("arbace.pprint$single_defn$fn__740000113")

var Lit_254 *jrt.String = jrt.Intern("~{~w~^ ~_~}")

var Lit_255 *jrt.String = jrt.Intern("arbace.pprint$single_defn$fn__740000115")

var Lit_256 *jrt.String = jrt.Intern("arbace.pprint$split_at_newline$fn__1820000128")

var Lit_257 *jrt.String = jrt.Intern("arbace.pprint$start_block$fn__1820000190")

var Lit_258 *jrt.String = jrt.Intern("arbace.pprint$table_ize$fn__693000011")

var Lit_259 *jrt.String = jrt.Intern("arbace.pprint$tuple_map$iter__1470000059__1470000063")

var Lit_260 *jrt.String = jrt.Intern("arbace.pprint$tuple_map$iter__1470000059__1470000063$fn__1470000064")

var Lit_261 *jrt.String = jrt.Intern("arbace.pprint$tuple_map$iter__1470000059__1470000063$fn__1470000064$fn__1470000065")

var Lit_262 *jrt.String = jrt.Intern("arbace.pprint$two_forms$iter__740000181__740000185")

var Lit_263 *jrt.String = jrt.Intern("arbace.pprint$two_forms$iter__740000181__740000185$fn__740000186")

var Lit_264 *jrt.String = jrt.Intern("arbace.pprint$two_forms$iter__740000181__740000185$fn__740000186$fn__740000187")

var Lit_265 *jrt.String = jrt.Intern("arbace.pprint$unzip_map$iter__1470000014__1470000018")

var Lit_266 *jrt.String = jrt.Intern("arbace.pprint$unzip_map$iter__1470000036__1470000040")

var Lit_267 *jrt.String = jrt.Intern("arbace.pprint$unzip_map$iter__1470000014__1470000018$fn__1470000019")

var Lit_268 *jrt.String = jrt.Intern("arbace.pprint$unzip_map$iter__1470000014__1470000018$fn__1470000019$fn__1470000020")

var Lit_269 *jrt.String = jrt.Intern("arbace.pprint$unzip_map$iter__1470000036__1470000040$fn__1470000041")

var Lit_270 *jrt.String = jrt.Intern("arbace.pprint$unzip_map$iter__1470000036__1470000040$fn__1470000041$fn__1470000042")

var Lit_271 *jrt.String = jrt.Intern("arbace.pprint$upcase_writer$fn__1819000225")

var Lit_272 *jrt.String = jrt.Intern("arbace.pprint$upcase_writer$fn__1819000227")

var Lit_273 *jrt.String = jrt.Intern("arbace.pprint$upcase_writer$fn__1819000229")

var Lit_274 *jrt.String = jrt.Intern("arbace.pprint$update_nl_state$fn__1820000121")

var Lit_275 *jrt.String = jrt.Intern("arbace.pprint$write$fn__693000026")

var Lit_276 *jrt.String = jrt.Intern("arbace.pprint$write$fn__693000028")

var Lit_277 *jrt.String = jrt.Intern("split")

var Lit_278 *jrt.String = jrt.Intern("arbace.pprint$write_initial_lines$fn__1820000163")

var Lit_279 *jrt.String = jrt.Intern("arbace.pprint$write_line$fn__1820000153")

var Lit_280 *jrt.String = jrt.Intern("arbace.pprint$write_white_space$fn__1820000160")

var Lit_281 *jrt.String = jrt.Intern("kn6,authorkn3,dockn5,addedyn11,arbace.corev11,arbace.core5,in-nsMyn13,arbace.pprintm6,R0,s13,Tom FaulhaberR1,s1084,A Pretty Printer for Clojure\n\narbace.pprint implements a flexible system for printing structured data\nin a pleasing, easy-to-understand format. Basic use of the pretty printer is\nsimple, just call pprint instead of println. More advanced users can use\nthe building blocks provided to create custom output formats.\n\nOut of the box, pprint supports a simple structured format for basic data\nand a specialized format for Clojure source code. More advanced formats,\nincluding formats that don't look like Clojure data at all like XML and\nJSON, can be rendered by creating custom dispatch functions.\n\nIn addition to the pprint function, this module contains cl-format, a text\nformatting function which is fully compatible with the format function in\nCommon Lisp. Because pretty printing directives are directly integrated with\ncl-format, it supports very concise custom dispatch. It also provides\na more powerful alternative to Clojure's standard format function.\n\nSee documentation for pprint and cl-format for more information or\ncomplete documentation on the Clojure web site on GitHub.R2,s3,1.2m6,R0,s13,Tom FaulhaberR1,s1084,A Pretty Printer for Clojure\n\narbace.pprint implements a flexible system for printing structured data\nin a pleasing, easy-to-understand format. Basic use of the pretty printer is\nsimple, just call pprint instead of println. More advanced users can use\nthe building blocks provided to create custom output formats.\n\nOut of the box, pprint supports a simple structured format for basic data\nand a specialized format for Clojure source code. More advanced formats,\nincluding formats that don't look like Clojure data at all like XML and\nJSON, can be rendered by creating custom dispatch functions.\n\nIn addition to the pprint function, this module contains cl-format, a text\nformatting function which is fully compatible with the format function in\nCommon Lisp. Because pretty printing directives are directly integrated with\ncl-format, it supports very concise custom dispatch. It also provides\na more powerful alternative to Clojure's standard format function.\n\nSee documentation for pprint and cl-format for more information or\ncomplete documentation on the Clojure web site on GitHub.R2,s3,1.2R3,v11,arbace.core20,*warn-on-reflection*v11,arbace.core4,load")

var Lit_282 *jrt.String = jrt.Intern("arbace.pprint$eval1513000004$loading__1927001464__auto____1513000005")

var Lit_283 *jrt.String = jrt.Intern("arbace.pprint$eval1513000008$fn__1513000009")

var Lit_284 *jrt.String = jrt.Intern("pprint/utilities")

var Lit_285 *jrt.String = jrt.Intern("pprint/column_writer")

var Lit_286 *jrt.String = jrt.Intern("pprint/pretty_writer")

var Lit_287 *jrt.String = jrt.Intern("pprint/pprint_base")

var Lit_288 *jrt.String = jrt.Intern("pprint/cl_format")

var Lit_289 *jrt.String = jrt.Intern("pprint/dispatch")

var Lit_290 *jrt.String = jrt.Intern("pprint/print_table")
