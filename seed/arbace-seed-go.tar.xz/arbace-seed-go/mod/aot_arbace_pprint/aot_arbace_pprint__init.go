//line aot_arbace_pprint__init.ae:1
package aot_arbace_pprint

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_pprint__init_A_Unit12__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return nil }



func A_arbace_pprint__init_A_Load__O() any { A_arbace_pprint__init_A_Init(); A_arbace_pprint__init_A_Unit0__O(); A_arbace_pprint__init_A_Unit1__O(); A_arbace_pprint__init_A_Unit2__O(); A_arbace_pprint__init_A_Unit3__O(); A_arbace_pprint__init_A_Unit4__O(); A_arbace_pprint__init_A_Unit5__O(); A_arbace_pprint__init_A_Unit6__O(); A_arbace_pprint__init_A_Unit7__O(); A_arbace_pprint__init_A_Unit8__O(); A_arbace_pprint__init_A_Unit9__O(); A_arbace_pprint__init_A_Unit10__O(); A_arbace_pprint__init_A_Unit11__O(); A_arbace_pprint__init_A_Unit12__O(); return nil }








func A_arbace_pprint__init_A_Unit0__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_pprint__init_A_const_1) }
//line :14:1
func A_arbace_pprint__init_A_Unit1__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_pprint__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_pprint__init_A_const_2)) }
//line :14:1
func A_arbace_pprint__init_A_Unit2__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 any = A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_New(); var tmp2 *jrt.Class; A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_Init(); tmp2 = A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :14:1
func A_arbace_pprint__init_A_Unit3__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_pprint__init_A_const_1)).Equals_O__Z(A_arbace_pprint__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_pprint_eval1513000008_fn__1513000009_A_New(); var tmp2 *jrt.Class; A_arbace_pprint_eval1513000008_fn__1513000009_A_Init(); tmp2 = A_arbace_pprint_eval1513000008_fn__1513000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }


























func A_arbace_pprint__init_A_Unit4__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 *lang.Var = A_arbace_pprint__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }

func A_arbace_pprint__init_A_Unit5__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(43, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint__init_A_const_5).GetRawRoot__O()).Invoke_O__O(Lit_1008) }
func A_arbace_pprint__init_A_Unit6__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint__init_A_const_5).GetRawRoot__O()).Invoke_O__O(Lit_1009) }
func A_arbace_pprint__init_A_Unit7__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint__init_A_const_5).GetRawRoot__O()).Invoke_O__O(Lit_1010) }
func A_arbace_pprint__init_A_Unit8__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint__init_A_const_5).GetRawRoot__O()).Invoke_O__O(Lit_1011) }
func A_arbace_pprint__init_A_Unit9__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint__init_A_const_5).GetRawRoot__O()).Invoke_O__O(Lit_1012) }
func A_arbace_pprint__init_A_Unit10__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint__init_A_const_5).GetRawRoot__O()).Invoke_O__O(Lit_1013) }
func A_arbace_pprint__init_A_Unit11__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint__init_A_const_5).GetRawRoot__O()).Invoke_O__O(Lit_1014) }



type A_arbace_pprint__init_A struct{ jrt.Object }

var A_arbace_pprint__init_A_const_0 *lang.Var

var A_arbace_pprint__init_A_const_1 any

var A_arbace_pprint__init_A_const_2 any

var A_arbace_pprint__init_A_const_3 any

var A_arbace_pprint__init_A_const_4 *lang.Var

var A_arbace_pprint__init_A_const_5 *lang.Var

var A_arbace_pprint__init_A_init jrt.ClassInit

func A_arbace_pprint__init_A_Init() { if !A_arbace_pprint__init_A_init.Done() { A_arbace_pprint__init_A_init.Run(A_arbace_pprint__init_A_clinit) } }

func A_arbace_pprint__init_A_clinit() { A_arbace_pprint__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1005); A_arbace_pprint__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19))); A_arbace_pprint__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19)); A_arbace_pprint__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_pprint__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_1006); A_arbace_pprint__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_1007) }

func A_arbace_pprint__init_A_New() *A_arbace_pprint__init_A { A_arbace_pprint__init_A_Init(); t := &A_arbace_pprint__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint__init_A) Ctor() {}

func (t *A_arbace_pprint__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint__init_A_class }

func (t *A_arbace_pprint__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint__init_A); return ok }

func A_arbace_pprint__init_A_Cast(x any) *A_arbace_pprint__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint__init_A_class)) }; return v }
