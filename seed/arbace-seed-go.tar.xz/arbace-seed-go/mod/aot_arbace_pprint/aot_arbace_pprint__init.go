//line aot_arbace_pprint__init.ae:1
package aot_arbace_pprint

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_pprint__init_A_Unit12__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return nil }



func A_arbace_pprint__init_A_Load__O() any { A_arbace_pprint__init_A_Init(); A_arbace_pprint__init_A_Unit0__O(); A_arbace_pprint__init_A_Unit1__O(); A_arbace_pprint__init_A_Unit2__O(); A_arbace_pprint__init_A_Unit3__O(); A_arbace_pprint__init_A_Unit4__O(); A_arbace_pprint__init_A_Unit5__O(); A_arbace_pprint__init_A_Unit6__O(); A_arbace_pprint__init_A_Unit7__O(); A_arbace_pprint__init_A_Unit8__O(); A_arbace_pprint__init_A_Unit9__O(); A_arbace_pprint__init_A_Unit10__O(); A_arbace_pprint__init_A_Unit11__O(); A_arbace_pprint__init_A_Unit12__O(); return nil }








func A_arbace_pprint__init_A_Unit0__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); return lang.IFn_Cast(A_arbace_pprint__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint__init_A_const_1) }
//line :14:1
func A_arbace_pprint__init_A_Unit1__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_pprint__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_pprint__init_A_const_2)) }
//line :14:1
func A_arbace_pprint__init_A_Unit2__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 any = A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_282, false); A_arbace_pprint_eval1513000004_loading__1927001464__auto____1513000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :14:1
func A_arbace_pprint__init_A_Unit3__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_pprint__init_A_const_1)).Equals_O__Z(A_arbace_pprint__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_pprint_eval1513000008_fn__1513000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_pprint_eval1513000008_fn__1513000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_283, false); A_arbace_pprint_eval1513000008_fn__1513000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }


























func A_arbace_pprint__init_A_Unit4__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 *lang.Var = A_arbace_pprint__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return tmp1.Set_O__O(tmp2.Ref()) }

func A_arbace_pprint__init_A_Unit5__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(43, 1); return lang.IFn_Cast(A_arbace_pprint__init_A_const_5.GetRawRoot__O()).Invoke_O__O(Lit_284) }
func A_arbace_pprint__init_A_Unit6__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); return lang.IFn_Cast(A_arbace_pprint__init_A_const_5.GetRawRoot__O()).Invoke_O__O(Lit_285) }
func A_arbace_pprint__init_A_Unit7__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); return lang.IFn_Cast(A_arbace_pprint__init_A_const_5.GetRawRoot__O()).Invoke_O__O(Lit_286) }
func A_arbace_pprint__init_A_Unit8__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); return lang.IFn_Cast(A_arbace_pprint__init_A_const_5.GetRawRoot__O()).Invoke_O__O(Lit_287) }
func A_arbace_pprint__init_A_Unit9__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); return lang.IFn_Cast(A_arbace_pprint__init_A_const_5.GetRawRoot__O()).Invoke_O__O(Lit_288) }
func A_arbace_pprint__init_A_Unit10__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return lang.IFn_Cast(A_arbace_pprint__init_A_const_5.GetRawRoot__O()).Invoke_O__O(Lit_289) }
func A_arbace_pprint__init_A_Unit11__O() any { A_arbace_pprint__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); return lang.IFn_Cast(A_arbace_pprint__init_A_const_5.GetRawRoot__O()).Invoke_O__O(Lit_290) }



type A_arbace_pprint__init_A struct{ jrt.Object }

var A_arbace_pprint__init_A_const_pool *jrt.RefArray

var A_arbace_pprint__init_A_const_0 *lang.Var

var A_arbace_pprint__init_A_const_1 any

var A_arbace_pprint__init_A_const_2 any

var A_arbace_pprint__init_A_const_3 any

var A_arbace_pprint__init_A_const_4 *lang.Var

var A_arbace_pprint__init_A_const_5 *lang.Var

var A_arbace_pprint__init_A_init jrt.ClassInit

func A_arbace_pprint__init_A_Init() { if !A_arbace_pprint__init_A_init.Done() { A_arbace_pprint__init_A_init.Run(A_arbace_pprint__init_A_clinit) } }

func A_arbace_pprint__init_A_clinit() { A_arbace_pprint__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_281, 10); A_arbace_pprint__init_A_const_0 = lang.Var_Cast(A_arbace_pprint__init_A_const_pool.A[4]); A_arbace_pprint__init_A_const_1 = A_arbace_pprint__init_A_const_pool.A[5]; A_arbace_pprint__init_A_const_2 = A_arbace_pprint__init_A_const_pool.A[6]; A_arbace_pprint__init_A_const_3 = A_arbace_pprint__init_A_const_pool.A[7]; A_arbace_pprint__init_A_const_4 = lang.Var_Cast(A_arbace_pprint__init_A_const_pool.A[8]); A_arbace_pprint__init_A_const_5 = lang.Var_Cast(A_arbace_pprint__init_A_const_pool.A[9]) }

func A_arbace_pprint__init_A_New() *A_arbace_pprint__init_A { A_arbace_pprint__init_A_Init(); t := &A_arbace_pprint__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint__init_A) Ctor() {}

func (t *A_arbace_pprint__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint__init_A_class }

func (t *A_arbace_pprint__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint__init_A); return ok }

func A_arbace_pprint__init_A_Cast(x any) *A_arbace_pprint__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint__init_A_class)) }; return v }
