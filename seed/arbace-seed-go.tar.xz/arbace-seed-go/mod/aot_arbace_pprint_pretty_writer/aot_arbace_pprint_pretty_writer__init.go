//line aot_arbace_pprint_pretty_writer__init.ae:1
package aot_arbace_pprint_pretty_writer

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_pretty_writer__init_A_Load__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); jrt.StartCheck(); A_arbace_pprint_pretty_writer__init_A_Unit0__O(); A_arbace_pprint_pretty_writer__init_A_Unit1__O(); A_arbace_pprint_pretty_writer__init_A_Unit2__O(); A_arbace_pprint_pretty_writer__init_A_Unit3__O(); A_arbace_pprint_pretty_writer__init_A_Unit4__O(); A_arbace_pprint_pretty_writer__init_A_Unit5__O(); A_arbace_pprint_pretty_writer__init_A_Unit6__O(); A_arbace_pprint_pretty_writer__init_A_Unit7__O(); A_arbace_pprint_pretty_writer__init_A_Unit8__O(); A_arbace_pprint_pretty_writer__init_A_Unit9__O(); A_arbace_pprint_pretty_writer__init_A_Unit10__O(); A_arbace_pprint_pretty_writer__init_A_Unit11__O(); A_arbace_pprint_pretty_writer__init_A_Unit12__O(); A_arbace_pprint_pretty_writer__init_A_Unit13__O(); A_arbace_pprint_pretty_writer__init_A_Unit14__O(); A_arbace_pprint_pretty_writer__init_A_Unit15__O(); A_arbace_pprint_pretty_writer__init_A_Unit16__O(); A_arbace_pprint_pretty_writer__init_A_Unit17__O(); A_arbace_pprint_pretty_writer__init_A_Unit18__O(); A_arbace_pprint_pretty_writer__init_A_Unit19__O(); A_arbace_pprint_pretty_writer__init_A_Unit20__O(); A_arbace_pprint_pretty_writer__init_A_Unit21__O(); A_arbace_pprint_pretty_writer__init_A_Unit22__O(); A_arbace_pprint_pretty_writer__init_A_Unit23__O(); A_arbace_pprint_pretty_writer__init_A_Unit24__O(); A_arbace_pprint_pretty_writer__init_A_Unit25__O(); A_arbace_pprint_pretty_writer__init_A_Unit26__O(); A_arbace_pprint_pretty_writer__init_A_Unit27__O(); A_arbace_pprint_pretty_writer__init_A_Unit28__O(); A_arbace_pprint_pretty_writer__init_A_Unit29__O(); A_arbace_pprint_pretty_writer__init_A_Unit30__O(); A_arbace_pprint_pretty_writer__init_A_Unit31__O(); A_arbace_pprint_pretty_writer__init_A_Unit32__O(); A_arbace_pprint_pretty_writer__init_A_Unit33__O(); A_arbace_pprint_pretty_writer__init_A_Unit34__O(); A_arbace_pprint_pretty_writer__init_A_Unit35__O(); A_arbace_pprint_pretty_writer__init_A_Unit36__O(); A_arbace_pprint_pretty_writer__init_A_Unit37__O(); A_arbace_pprint_pretty_writer__init_A_Unit38__O(); A_arbace_pprint_pretty_writer__init_A_Unit39__O(); A_arbace_pprint_pretty_writer__init_A_Unit40__O(); A_arbace_pprint_pretty_writer__init_A_Unit41__O(); A_arbace_pprint_pretty_writer__init_A_Unit42__O(); A_arbace_pprint_pretty_writer__init_A_Unit43__O(); A_arbace_pprint_pretty_writer__init_A_Unit44__O(); A_arbace_pprint_pretty_writer__init_A_Unit45__O(); A_arbace_pprint_pretty_writer__init_A_Unit46__O(); A_arbace_pprint_pretty_writer__init_A_Unit47__O(); A_arbace_pprint_pretty_writer__init_A_Unit48__O(); A_arbace_pprint_pretty_writer__init_A_Unit49__O(); A_arbace_pprint_pretty_writer__init_A_Unit50__O(); A_arbace_pprint_pretty_writer__init_A_Unit51__O(); A_arbace_pprint_pretty_writer__init_A_Unit52__O(); A_arbace_pprint_pretty_writer__init_A_Unit53__O(); A_arbace_pprint_pretty_writer__init_A_Unit54__O(); A_arbace_pprint_pretty_writer__init_A_Unit55__O(); A_arbace_pprint_pretty_writer__init_A_Unit56__O(); A_arbace_pprint_pretty_writer__init_A_Unit57__O(); A_arbace_pprint_pretty_writer__init_A_Unit58__O(); A_arbace_pprint_pretty_writer__init_A_Unit59__O(); A_arbace_pprint_pretty_writer__init_A_Unit60__O(); A_arbace_pprint_pretty_writer__init_A_Unit61__O(); A_arbace_pprint_pretty_writer__init_A_Unit62__O(); A_arbace_pprint_pretty_writer__init_A_Unit63__O(); A_arbace_pprint_pretty_writer__init_A_Unit64__O(); A_arbace_pprint_pretty_writer__init_A_Unit65__O(); A_arbace_pprint_pretty_writer__init_A_Unit66__O(); A_arbace_pprint_pretty_writer__init_A_Unit67__O(); A_arbace_pprint_pretty_writer__init_A_Unit68__O(); A_arbace_pprint_pretty_writer__init_A_Unit69__O(); A_arbace_pprint_pretty_writer__init_A_Unit70__O(); A_arbace_pprint_pretty_writer__init_A_Unit71__O(); A_arbace_pprint_pretty_writer__init_A_Unit72__O(); A_arbace_pprint_pretty_writer__init_A_Unit73__O(); A_arbace_pprint_pretty_writer__init_A_Unit74__O(); A_arbace_pprint_pretty_writer__init_A_Unit75__O(); A_arbace_pprint_pretty_writer__init_A_Unit76__O(); A_arbace_pprint_pretty_writer__init_A_Unit77__O(); A_arbace_pprint_pretty_writer__init_A_Unit78__O(); A_arbace_pprint_pretty_writer__init_A_Unit79__O(); A_arbace_pprint_pretty_writer__init_A_Unit80__O(); A_arbace_pprint_pretty_writer__init_A_Unit81__O(); return nil }












func A_arbace_pprint_pretty_writer__init_A_Unit0__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pretty_writer__init_A_const_1) }

func A_arbace_pprint_pretty_writer__init_A_Unit1__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }
//line :20:1
func A_arbace_pprint_pretty_writer__init_A_Unit2__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)).Ref() }








func A_arbace_pprint_pretty_writer__init_A_Unit3__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_3)); return A_arbace_pprint_pretty_writer__init_A_const_2 }






func A_arbace_pprint_pretty_writer__init_A_Unit4__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = aot_arbace_pprint.A_arbace_pprint_getf_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_getf_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); aot_arbace_pprint.A_arbace_pprint_getf_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_5)); return A_arbace_pprint_pretty_writer__init_A_const_4 }
//line :36:1
func A_arbace_pprint_pretty_writer__init_A_Unit5__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); A_arbace_pprint_pretty_writer__init_A_const_4.SetMacro__V(); return nil }
//line :36:1
func A_arbace_pprint_pretty_writer__init_A_Unit6__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); return A_arbace_pprint_pretty_writer__init_A_const_4 }





func A_arbace_pprint_pretty_writer__init_A_Unit7__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = aot_arbace_pprint.A_arbace_pprint_setf_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_setf_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); aot_arbace_pprint.A_arbace_pprint_setf_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_7)); return A_arbace_pprint_pretty_writer__init_A_const_6 }
//line :42:1
func A_arbace_pprint_pretty_writer__init_A_Unit8__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_pprint_pretty_writer__init_A_const_6.SetMacro__V(); return nil }
//line :42:1
func A_arbace_pprint_pretty_writer__init_A_Unit9__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); return A_arbace_pprint_pretty_writer__init_A_const_6 }





func A_arbace_pprint_pretty_writer__init_A_Unit10__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_8; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__6 any = aot_arbace_pprint.A_arbace_pprint_deftype_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_deftype_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, true, nil); aot_arbace_pprint.A_arbace_pprint_deftype_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__6, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_9)); return A_arbace_pprint_pretty_writer__init_A_const_8 }
//line :48:1
func A_arbace_pprint_pretty_writer__init_A_Unit11__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); A_arbace_pprint_pretty_writer__init_A_const_8.SetMacro__V(); return nil }
//line :48:1
func A_arbace_pprint_pretty_writer__init_A_Unit12__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_pprint_pretty_writer__init_A_const_8 }









func A_arbace_pprint_pretty_writer__init_A_Unit13__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_10; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__8 any = aot_arbace_pprint.A_arbace_pprint_write_to_base_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_to_base_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, true, nil); aot_arbace_pprint.A_arbace_pprint_write_to_base_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__8, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_11)); return A_arbace_pprint_pretty_writer__init_A_const_10 }
//line :58:1
func A_arbace_pprint_pretty_writer__init_A_Unit14__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_pprint_pretty_writer__init_A_const_10.SetMacro__V(); return nil }
//line :58:1
func A_arbace_pprint_pretty_writer__init_A_Unit15__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); return A_arbace_pprint_pretty_writer__init_A_const_10 }











func A_arbace_pprint_pretty_writer__init_A_Unit16__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_12; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_14, A_arbace_pprint_pretty_writer__init_A_const_15, A_arbace_pprint_pretty_writer__init_A_const_16, A_arbace_pprint_pretty_writer__init_A_const_17, A_arbace_pprint_pretty_writer__init_A_const_18, A_arbace_pprint_pretty_writer__init_A_const_19, A_arbace_pprint_pretty_writer__init_A_const_20, A_arbace_pprint_pretty_writer__init_A_const_21, A_arbace_pprint_pretty_writer__init_A_const_22, A_arbace_pprint_pretty_writer__init_A_const_23)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_24)); return A_arbace_pprint_pretty_writer__init_A_const_12 }





func A_arbace_pprint_pretty_writer__init_A_Unit17__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__23 any = aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__23, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_26)); return A_arbace_pprint_pretty_writer__init_A_const_25 }






func A_arbace_pprint_pretty_writer__init_A_Unit18__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_27; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pretty_writer__init_A_const_14)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_27; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_28)); return A_arbace_pprint_pretty_writer__init_A_const_27 }

func A_arbace_pprint_pretty_writer__init_A_Unit19__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__29 any = aot_arbace_pprint.A_arbace_pprint_buffer_length_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_buffer_length_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); aot_arbace_pprint.A_arbace_pprint_buffer_length_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__29, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_30)); return A_arbace_pprint_pretty_writer__init_A_const_29 }






func A_arbace_pprint_pretty_writer__init_A_Unit20__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_31; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_33, A_arbace_pprint_pretty_writer__init_A_const_34, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_31; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_37)); return A_arbace_pprint_pretty_writer__init_A_const_31 }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit21__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_31; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit22__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_41; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__46 any = aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, true, nil); aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__46, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_42)); return A_arbace_pprint_pretty_writer__init_A_const_41 }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit23__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_44)); return A_arbace_pprint_pretty_writer__init_A_const_43 }


func A_arbace_pprint_pretty_writer__init_A_Unit24__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_45; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_46, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_45; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_48)); return A_arbace_pprint_pretty_writer__init_A_const_45 }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit25__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_45; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit26__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_49; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__65 any = aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, true, nil); aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__65, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_50)); return A_arbace_pprint_pretty_writer__init_A_const_49 }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit27__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__67 any = aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__67, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_52)); return A_arbace_pprint_pretty_writer__init_A_const_51 }

func A_arbace_pprint_pretty_writer__init_A_Unit28__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_53; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_53; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_54)); return A_arbace_pprint_pretty_writer__init_A_const_53 }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit29__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_53; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit30__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_55; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__83 any = aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, true, nil); aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__83, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_56)); return A_arbace_pprint_pretty_writer__init_A_const_55 }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit31__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__85 any = aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_58)); return A_arbace_pprint_pretty_writer__init_A_const_57 }

func A_arbace_pprint_pretty_writer__init_A_Unit32__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_59; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_59; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_60)); return A_arbace_pprint_pretty_writer__init_A_const_59 }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit33__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_59; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit34__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_61; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__101 any = aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_New(); var tmp3 *jrt.Class; var fncls__100 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, true, nil); aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_fn_class = fncls__100d; tmp3 = fncls__100d } else { tmp3 = fncls__100 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__101, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_62)); return A_arbace_pprint_pretty_writer__init_A_const_61 }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit35__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__103 any = aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_64)); return A_arbace_pprint_pretty_writer__init_A_const_63 }

func A_arbace_pprint_pretty_writer__init_A_Unit36__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_65; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_66, A_arbace_pprint_pretty_writer__init_A_const_67, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_65; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_68)); return A_arbace_pprint_pretty_writer__init_A_const_65 }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit37__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_65; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit38__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_69; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__121 any = aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_New(); var tmp3 *jrt.Class; var fncls__120 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, true, nil); aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_fn_class = fncls__120d; tmp3 = fncls__120d } else { tmp3 = fncls__120 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__121, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_70)); return A_arbace_pprint_pretty_writer__init_A_const_69 }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit39__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__123 any = aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__122 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_fn_class = fncls__122d; tmp3 = fncls__122d } else { tmp3 = fncls__122 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__123, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_72)); return A_arbace_pprint_pretty_writer__init_A_const_71 }





func A_arbace_pprint_pretty_writer__init_A_Unit40__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_73; var tmp2 any; var root_124 any = A_arbace_pprint_pretty_writer__init_A_const_74.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_memoize_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var fnbody__129 any = aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_New(); var tmp3 *jrt.Class; var fncls__128 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_fn_class = fncls__128d; tmp3 = fncls__128d } else { tmp3 = fncls__128 }; arg_127 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__129, tmp3, nil); if linked_125 == nil { tmp2 = ifn_126.Invoke_O__O(arg_127) } else { tmp2 = linked_125.(*aot_arbace_core.A_arbace_core_memoize_A).Invoke_O_O__O(root_124, arg_127) }; tmp1.BindRoot_O__V(tmp2); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_75)); return A_arbace_pprint_pretty_writer__init_A_const_73 }

func A_arbace_pprint_pretty_writer__init_A_Unit41__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_77)); return A_arbace_pprint_pretty_writer__init_A_const_76 }

func A_arbace_pprint_pretty_writer__init_A_Unit42__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_79)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_78; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_130 any = A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = v__1927000386__auto____1; if linked_131 == nil { tmp3 = ifn_132.Invoke_O__O(arg_133) } else { tmp3 = linked_131.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_130, arg_133) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_83)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; var tmp6 *jrt.String = Lit_20; var tmp7 *lang.Compiler_AOTFn; var fnbody__135 any = aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_New(); var tmp8 *jrt.Class; var fncls__134 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class = fncls__134d; tmp8 = fncls__134d } else { tmp8 = fncls__134 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp8, nil); var tmp9 lang.IFn = Up_Compiler_AOTFn_IFn(tmp7); var tmp10 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_78 } }
func A_arbace_pprint_pretty_writer__init_A_Unit43__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_84; var tmp3 *lang.Compiler_AOTFn; var fnbody__137 any = aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_New(); var tmp4 *jrt.Class; var fncls__136 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class = fncls__136d; tmp4 = fncls__136d } else { tmp4 = fncls__136 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__137, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }









func A_arbace_pprint_pretty_writer__init_A_Unit44__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_85; var tmp3 *lang.Compiler_AOTFn; var fnbody__139 any = aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_New(); var tmp4 *jrt.Class; var fncls__138 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class = fncls__138d; tmp4 = fncls__138d } else { tmp4 = fncls__138 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__139, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_pprint_pretty_writer__init_A_Unit45__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_86; var tmp3 *lang.Compiler_AOTFn; var fnbody__141 any = aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_New(); var tmp4 *jrt.Class; var fncls__140 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class = fncls__140d; tmp4 = fncls__140d } else { tmp4 = fncls__140 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__141, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }







func A_arbace_pprint_pretty_writer__init_A_Unit46__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_87; var tmp3 *lang.Compiler_AOTFn; var fnbody__143 any = aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_New(); var tmp4 *jrt.Class; var fncls__142 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class = fncls__142d; tmp4 = fncls__142d } else { tmp4 = fncls__142 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__143, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_pprint_pretty_writer__init_A_Unit47__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(138, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_88; var tmp3 *lang.Compiler_AOTFn; var fnbody__145 any = aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_New(); var tmp4 *jrt.Class; var fncls__144 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class = fncls__144d; tmp4 = fncls__144d } else { tmp4 = fncls__144 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__145, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }










func A_arbace_pprint_pretty_writer__init_A_Unit48__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__147 any = aot_arbace_pprint.A_arbace_pprint_write_tokens_A_New(); var tmp3 *jrt.Class; var fncls__146 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_tokens_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); aot_arbace_pprint.A_arbace_pprint_write_tokens_A_fn_class = fncls__146d; tmp3 = fncls__146d } else { tmp3 = fncls__146 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__147, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_90)); return A_arbace_pprint_pretty_writer__init_A_const_89 }
















func A_arbace_pprint_pretty_writer__init_A_Unit49__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__149 any = aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__149, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_92)); return A_arbace_pprint_pretty_writer__init_A_const_91 }






func A_arbace_pprint_pretty_writer__init_A_Unit50__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__151 any = aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__151, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_94)); return A_arbace_pprint_pretty_writer__init_A_const_93 }




func A_arbace_pprint_pretty_writer__init_A_Unit51__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__153 any = aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__152 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_fn_class = fncls__152d; tmp3 = fncls__152d } else { tmp3 = fncls__152 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__153, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_96)); return A_arbace_pprint_pretty_writer__init_A_const_95 }






func A_arbace_pprint_pretty_writer__init_A_Unit52__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_98)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_97; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_154 any = A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = v__1927000386__auto____1; if linked_155 == nil { tmp3 = ifn_156.Invoke_O__O(arg_157) } else { tmp3 = linked_155.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_154, arg_157) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_99)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; var tmp6 *jrt.String = Lit_31; var tmp7 *lang.Compiler_AOTFn; var fnbody__159 any = aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_New(); var tmp8 *jrt.Class; var fncls__158 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class = fncls__158d; tmp8 = fncls__158d } else { tmp8 = fncls__158 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__159, tmp8, nil); var tmp9 lang.IFn = Up_Compiler_AOTFn_IFn(tmp7); var tmp10 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_97 } }

func A_arbace_pprint_pretty_writer__init_A_Unit53__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_100; var tmp3 *lang.Compiler_AOTFn; var fnbody__161 any = aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_New(); var tmp4 *jrt.Class; var fncls__160 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class = fncls__160d; tmp4 = fncls__160d } else { tmp4 = fncls__160 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__161, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_pprint_pretty_writer__init_A_Unit54__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_101; var tmp3 *lang.Compiler_AOTFn; var fnbody__163 any = aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_New(); var tmp4 *jrt.Class; var fncls__162 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class; if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class = fncls__162d; tmp4 = fncls__162d } else { tmp4 = fncls__162 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__163, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_pprint_pretty_writer__init_A_Unit55__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_102; var tmp3 *lang.Compiler_AOTFn; var fnbody__165 any = aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_New(); var tmp4 *jrt.Class; var fncls__164 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class = fncls__164d; tmp4 = fncls__164d } else { tmp4 = fncls__164 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__165, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit56__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_103; var tmp3 *lang.Compiler_AOTFn; var fnbody__167 any = aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_New(); var tmp4 *jrt.Class; var fncls__166 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class = fncls__166d; tmp4 = fncls__166d } else { tmp4 = fncls__166 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__167, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit57__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__169 any = aot_arbace_pprint.A_arbace_pprint_get_section_A_New(); var tmp3 *jrt.Class; var fncls__168 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_section_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); aot_arbace_pprint.A_arbace_pprint_get_section_A_fn_class = fncls__168d; tmp3 = fncls__168d } else { tmp3 = fncls__168 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__169, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_105)); return A_arbace_pprint_pretty_writer__init_A_const_104 }






func A_arbace_pprint_pretty_writer__init_A_Unit58__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__171 any = aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_New(); var tmp3 *jrt.Class; var fncls__170 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_fn_class = fncls__170d; tmp3 = fncls__170d } else { tmp3 = fncls__170 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__171, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_107)); return A_arbace_pprint_pretty_writer__init_A_const_106 }







func A_arbace_pprint_pretty_writer__init_A_Unit59__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__173 any = aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_New(); var tmp3 *jrt.Class; var fncls__172 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_fn_class = fncls__172d; tmp3 = fncls__172d } else { tmp3 = fncls__172 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__173, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_109)); return A_arbace_pprint_pretty_writer__init_A_const_108 }









func A_arbace_pprint_pretty_writer__init_A_Unit60__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__175 any = aot_arbace_pprint.A_arbace_pprint_emit_nl_A_New(); var tmp3 *jrt.Class; var fncls__174 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_emit_nl_A_fn_class; if fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); aot_arbace_pprint.A_arbace_pprint_emit_nl_A_fn_class = fncls__174d; tmp3 = fncls__174d } else { tmp3 = fncls__174 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__175, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_110)); return A_arbace_pprint_pretty_writer__init_A_const_76 }











func A_arbace_pprint_pretty_writer__init_A_Unit61__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__177 any = aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_New(); var tmp3 *jrt.Class; var fncls__176 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_fn_class = fncls__176d; tmp3 = fncls__176d } else { tmp3 = fncls__176 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__177, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_112)); return A_arbace_pprint_pretty_writer__init_A_const_111 }





func A_arbace_pprint_pretty_writer__init_A_Unit62__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_114)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_113; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_178 any = A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = v__1927000386__auto____1; if linked_179 == nil { tmp3 = ifn_180.Invoke_O__O(arg_181) } else { tmp3 = linked_179.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_178, arg_181) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_115)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; var tmp6 *jrt.String = Lit_42; var tmp7 lang.IFn = A_arbace_pprint_pretty_writer__init_A_const_32; var tmp8 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_113 } }
func A_arbace_pprint_pretty_writer__init_A_Unit63__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(252, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_88; var tmp3 *lang.Compiler_AOTFn; var fnbody__183 any = aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_New(); var tmp4 *jrt.Class; var fncls__182 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class; if fncls__182 == nil { var fncls__182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class = fncls__182d; tmp4 = fncls__182d } else { tmp4 = fncls__182 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__183, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit64__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_87; var tmp3 *lang.Compiler_AOTFn; var fnbody__185 any = aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_New(); var tmp4 *jrt.Class; var fncls__184 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class; if fncls__184 == nil { var fncls__184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class = fncls__184d; tmp4 = fncls__184d } else { tmp4 = fncls__184 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__185, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit65__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_81; var tmp3 *lang.Compiler_AOTFn; var fnbody__187 any = aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_New(); var tmp4 *jrt.Class; var fncls__186 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class = fncls__186d; tmp4 = fncls__186d } else { tmp4 = fncls__186 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__187, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit66__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__189 any = aot_arbace_pprint.A_arbace_pprint_toks_A_New(); var tmp3 *jrt.Class; var fncls__188 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_toks_A_fn_class; if fncls__188 == nil { var fncls__188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); aot_arbace_pprint.A_arbace_pprint_toks_A_fn_class = fncls__188d; tmp3 = fncls__188d } else { tmp3 = fncls__188 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__189, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_117)); return A_arbace_pprint_pretty_writer__init_A_const_116 }




func A_arbace_pprint_pretty_writer__init_A_Unit67__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__191 any = aot_arbace_pprint.A_arbace_pprint_write_token_string_A_New(); var tmp3 *jrt.Class; var fncls__190 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_token_string_A_fn_class; if fncls__190 == nil { var fncls__190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); aot_arbace_pprint.A_arbace_pprint_write_token_string_A_fn_class = fncls__190d; tmp3 = fncls__190d } else { tmp3 = fncls__190 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__191, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_119)); return A_arbace_pprint_pretty_writer__init_A_const_118 }





























func A_arbace_pprint_pretty_writer__init_A_Unit68__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(293, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__193 any = aot_arbace_pprint.A_arbace_pprint_write_line_A_New(); var tmp3 *jrt.Class; var fncls__192 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_line_A_fn_class; if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); aot_arbace_pprint.A_arbace_pprint_write_line_A_fn_class = fncls__192d; tmp3 = fncls__192d } else { tmp3 = fncls__192 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__193, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_121)); return A_arbace_pprint_pretty_writer__init_A_const_120 }












func A_arbace_pprint_pretty_writer__init_A_Unit69__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__195 any = aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_New(); var tmp3 *jrt.Class; var fncls__194 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_fn_class = fncls__194d; tmp3 = fncls__194d } else { tmp3 = fncls__194 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__195, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_123)); return A_arbace_pprint_pretty_writer__init_A_const_122 }







func A_arbace_pprint_pretty_writer__init_A_Unit70__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__197 any = aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_New(); var tmp3 *jrt.Class; var fncls__196 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_fn_class; if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_fn_class = fncls__196d; tmp3 = fncls__196d } else { tmp3 = fncls__196 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__197, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_125)); return A_arbace_pprint_pretty_writer__init_A_const_124 }






func A_arbace_pprint_pretty_writer__init_A_Unit71__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__199 any = aot_arbace_pprint.A_arbace_pprint_write_white_space_A_New(); var tmp3 *jrt.Class; var fncls__198 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_white_space_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); aot_arbace_pprint.A_arbace_pprint_write_white_space_A_fn_class = fncls__198d; tmp3 = fncls__198d } else { tmp3 = fncls__198 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__199, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_127)); return A_arbace_pprint_pretty_writer__init_A_const_126 }








func A_arbace_pprint_pretty_writer__init_A_Unit72__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__201 any = aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_New(); var tmp3 *jrt.Class; var fncls__200 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_fn_class; if fncls__200 == nil { var fncls__200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_fn_class = fncls__200d; tmp3 = fncls__200d } else { tmp3 = fncls__200 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__201, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_129)); return A_arbace_pprint_pretty_writer__init_A_const_128 }

























func A_arbace_pprint_pretty_writer__init_A_Unit73__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__203 any = aot_arbace_pprint.A_arbace_pprint_p_write_char_A_New(); var tmp3 *jrt.Class; var fncls__202 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_p_write_char_A_fn_class; if fncls__202 == nil { var fncls__202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); aot_arbace_pprint.A_arbace_pprint_p_write_char_A_fn_class = fncls__202d; tmp3 = fncls__202d } else { tmp3 = fncls__202 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__203, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_131)); return A_arbace_pprint_pretty_writer__init_A_const_130 }
















func A_arbace_pprint_pretty_writer__init_A_Unit74__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(373, 1); var tmp1 any = A_arbace_pprint_pretty_writer__init_A_const_135; lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_134.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_pprint_pretty_writer__init_A_const_136, A_arbace_pprint_pretty_writer__init_A_const_137)))); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_132; var tmp3 *lang.Compiler_AOTFn; var fnbody__205 any = aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_New(); var tmp4 *jrt.Class; var fncls__204 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_fn_class; if fncls__204 == nil { var fncls__204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_fn_class = fncls__204d; tmp4 = fncls__204d } else { tmp4 = fncls__204 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__205, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_132; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_133)); return A_arbace_pprint_pretty_writer__init_A_const_132 }





























































func A_arbace_pprint_pretty_writer__init_A_Unit75__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(435, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__207 any = aot_arbace_pprint.A_arbace_pprint_start_block_A_New(); var tmp3 *jrt.Class; var fncls__206 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_start_block_A_fn_class; if fncls__206 == nil { var fncls__206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); aot_arbace_pprint.A_arbace_pprint_start_block_A_fn_class = fncls__206d; tmp3 = fncls__206d } else { tmp3 = fncls__206 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__207, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_139)); return A_arbace_pprint_pretty_writer__init_A_const_138 }





















func A_arbace_pprint_pretty_writer__init_A_Unit76__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(457, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__209 any = aot_arbace_pprint.A_arbace_pprint_end_block_A_New(); var tmp3 *jrt.Class; var fncls__208 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_end_block_A_fn_class; if fncls__208 == nil { var fncls__208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); aot_arbace_pprint.A_arbace_pprint_end_block_A_fn_class = fncls__208d; tmp3 = fncls__208d } else { tmp3 = fncls__208 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__209, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_141)); return A_arbace_pprint_pretty_writer__init_A_const_140 }















func A_arbace_pprint_pretty_writer__init_A_Unit77__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(473, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__211 any = aot_arbace_pprint.A_arbace_pprint_nl_A_New(); var tmp3 *jrt.Class; var fncls__210 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_nl_A_fn_class; if fncls__210 == nil { var fncls__210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); aot_arbace_pprint.A_arbace_pprint_nl_A_fn_class = fncls__210d; tmp3 = fncls__210d } else { tmp3 = fncls__210 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__211, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_143)); return A_arbace_pprint_pretty_writer__init_A_const_142 }





func A_arbace_pprint_pretty_writer__init_A_Unit78__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(479, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__213 any = aot_arbace_pprint.A_arbace_pprint_indent_A_New(); var tmp3 *jrt.Class; var fncls__212 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_indent_A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); aot_arbace_pprint.A_arbace_pprint_indent_A_fn_class = fncls__212d; tmp3 = fncls__212d } else { tmp3 = fncls__212 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__213, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_145)); return A_arbace_pprint_pretty_writer__init_A_const_144 }












func A_arbace_pprint_pretty_writer__init_A_Unit79__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(492, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__215 any = aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_New(); var tmp3 *jrt.Class; var fncls__214 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_fn_class = fncls__214d; tmp3 = fncls__214d } else { tmp3 = fncls__214 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__215, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_146)); return A_arbace_pprint_pretty_writer__init_A_const_2 }


func A_arbace_pprint_pretty_writer__init_A_Unit80__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(495, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__217 any = aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_New(); var tmp3 *jrt.Class; var fncls__216 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, nil); aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_fn_class = fncls__216d; tmp3 = fncls__216d } else { tmp3 = fncls__216 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__217, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_148)); return A_arbace_pprint_pretty_writer__init_A_const_147 }


func A_arbace_pprint_pretty_writer__init_A_Unit81__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(498, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__219 any = aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_New(); var tmp3 *jrt.Class; var fncls__218 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, nil); aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_fn_class = fncls__218d; tmp3 = fncls__218d } else { tmp3 = fncls__218 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__219, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_150)); return A_arbace_pprint_pretty_writer__init_A_const_149 }



type A_arbace_pprint_pretty_writer__init_A struct{ jrt.Object }

var A_arbace_pprint_pretty_writer__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_pretty_writer__init_A_const_0 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_1 any

var A_arbace_pprint_pretty_writer__init_A_const_2 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_3 any

var A_arbace_pprint_pretty_writer__init_A_const_4 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_5 any

var A_arbace_pprint_pretty_writer__init_A_const_6 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_7 any

var A_arbace_pprint_pretty_writer__init_A_const_8 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_9 any

var A_arbace_pprint_pretty_writer__init_A_const_10 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_11 any

var A_arbace_pprint_pretty_writer__init_A_const_12 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_13 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_14 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_15 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_16 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_17 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_18 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_19 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_20 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_21 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_22 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_23 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_24 any

var A_arbace_pprint_pretty_writer__init_A_const_25 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_26 any

var A_arbace_pprint_pretty_writer__init_A_const_27 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_28 any

var A_arbace_pprint_pretty_writer__init_A_const_29 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_30 any

var A_arbace_pprint_pretty_writer__init_A_const_31 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_32 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_33 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_34 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_35 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_36 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_37 any

var A_arbace_pprint_pretty_writer__init_A_const_38 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_39 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_40 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_41 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_42 any

var A_arbace_pprint_pretty_writer__init_A_const_43 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_44 any

var A_arbace_pprint_pretty_writer__init_A_const_45 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_46 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_47 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_48 any

var A_arbace_pprint_pretty_writer__init_A_const_49 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_50 any

var A_arbace_pprint_pretty_writer__init_A_const_51 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_52 any

var A_arbace_pprint_pretty_writer__init_A_const_53 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_54 any

var A_arbace_pprint_pretty_writer__init_A_const_55 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_56 any

var A_arbace_pprint_pretty_writer__init_A_const_57 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_58 any

var A_arbace_pprint_pretty_writer__init_A_const_59 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_60 any

var A_arbace_pprint_pretty_writer__init_A_const_61 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_62 any

var A_arbace_pprint_pretty_writer__init_A_const_63 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_64 any

var A_arbace_pprint_pretty_writer__init_A_const_65 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_66 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_67 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_68 any

var A_arbace_pprint_pretty_writer__init_A_const_69 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_70 any

var A_arbace_pprint_pretty_writer__init_A_const_71 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_72 any

var A_arbace_pprint_pretty_writer__init_A_const_73 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_74 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_75 any

var A_arbace_pprint_pretty_writer__init_A_const_76 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_77 any

var A_arbace_pprint_pretty_writer__init_A_const_78 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_79 any

var A_arbace_pprint_pretty_writer__init_A_const_80 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_81 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_82 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_83 any

var A_arbace_pprint_pretty_writer__init_A_const_84 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_85 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_86 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_87 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_88 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_89 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_90 any

var A_arbace_pprint_pretty_writer__init_A_const_91 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_92 any

var A_arbace_pprint_pretty_writer__init_A_const_93 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_94 any

var A_arbace_pprint_pretty_writer__init_A_const_95 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_96 any

var A_arbace_pprint_pretty_writer__init_A_const_97 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_98 any

var A_arbace_pprint_pretty_writer__init_A_const_99 any

var A_arbace_pprint_pretty_writer__init_A_const_100 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_101 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_102 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_103 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_104 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_105 any

var A_arbace_pprint_pretty_writer__init_A_const_106 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_107 any

var A_arbace_pprint_pretty_writer__init_A_const_108 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_109 any

var A_arbace_pprint_pretty_writer__init_A_const_110 any

var A_arbace_pprint_pretty_writer__init_A_const_111 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_112 any

var A_arbace_pprint_pretty_writer__init_A_const_113 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_114 any

var A_arbace_pprint_pretty_writer__init_A_const_115 any

var A_arbace_pprint_pretty_writer__init_A_const_116 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_117 any

var A_arbace_pprint_pretty_writer__init_A_const_118 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_119 any

var A_arbace_pprint_pretty_writer__init_A_const_120 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_121 any

var A_arbace_pprint_pretty_writer__init_A_const_122 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_123 any

var A_arbace_pprint_pretty_writer__init_A_const_124 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_125 any

var A_arbace_pprint_pretty_writer__init_A_const_126 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_127 any

var A_arbace_pprint_pretty_writer__init_A_const_128 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_129 any

var A_arbace_pprint_pretty_writer__init_A_const_130 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_131 any

var A_arbace_pprint_pretty_writer__init_A_const_132 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_133 any

var A_arbace_pprint_pretty_writer__init_A_const_134 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_135 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_136 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_137 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_138 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_139 any

var A_arbace_pprint_pretty_writer__init_A_const_140 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_141 any

var A_arbace_pprint_pretty_writer__init_A_const_142 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_143 any

var A_arbace_pprint_pretty_writer__init_A_const_144 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_145 any

var A_arbace_pprint_pretty_writer__init_A_const_146 any

var A_arbace_pprint_pretty_writer__init_A_const_147 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_148 any

var A_arbace_pprint_pretty_writer__init_A_const_149 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_150 any

var A_arbace_pprint_pretty_writer__init_A_init jrt.ClassInit

func A_arbace_pprint_pretty_writer__init_A_Init() { if !A_arbace_pprint_pretty_writer__init_A_init.Done() { A_arbace_pprint_pretty_writer__init_A_init.Run(A_arbace_pprint_pretty_writer__init_A_clinit) } }

func A_arbace_pprint_pretty_writer__init_A_clinit() { A_arbace_pprint_pretty_writer__init_A_clinit_p0(); A_arbace_pprint_pretty_writer__init_A_clinit_p1(); A_arbace_pprint_pretty_writer__init_A_clinit_p2(); A_arbace_pprint_pretty_writer__init_A_clinit_p3(); A_arbace_pprint_pretty_writer__init_A_clinit_p4(); A_arbace_pprint_pretty_writer__init_A_clinit_p5(); A_arbace_pprint_pretty_writer__init_A_clinit_p6(); A_arbace_pprint_pretty_writer__init_A_clinit_p7(); A_arbace_pprint_pretty_writer__init_A_clinit_p8(); A_arbace_pprint_pretty_writer__init_A_clinit_p9(); A_arbace_pprint_pretty_writer__init_A_clinit_p10(); A_arbace_pprint_pretty_writer__init_A_clinit_p11() }

func A_arbace_pprint_pretty_writer__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_pprint_pretty_writer__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 220); A_arbace_pprint_pretty_writer__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[69]); A_arbace_pprint_pretty_writer__init_A_const_1 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[70]; A_arbace_pprint_pretty_writer__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[71]); A_arbace_pprint_pretty_writer__init_A_const_3 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[72]; A_arbace_pprint_pretty_writer__init_A_const_4 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[73]); A_arbace_pprint_pretty_writer__init_A_const_5 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[74]; A_arbace_pprint_pretty_writer__init_A_const_6 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[75]); A_arbace_pprint_pretty_writer__init_A_const_7 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[76]; A_arbace_pprint_pretty_writer__init_A_const_8 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[77]); A_arbace_pprint_pretty_writer__init_A_const_9 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[78]; A_arbace_pprint_pretty_writer__init_A_const_10 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[79]); A_arbace_pprint_pretty_writer__init_A_const_11 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[80] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p1() { A_arbace_pprint_pretty_writer__init_A_const_12 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[81]); A_arbace_pprint_pretty_writer__init_A_const_13 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[82]); A_arbace_pprint_pretty_writer__init_A_const_14 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[83]); A_arbace_pprint_pretty_writer__init_A_const_15 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[84]); A_arbace_pprint_pretty_writer__init_A_const_16 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[85]); A_arbace_pprint_pretty_writer__init_A_const_17 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[86]); A_arbace_pprint_pretty_writer__init_A_const_18 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[87]); A_arbace_pprint_pretty_writer__init_A_const_19 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[88]); A_arbace_pprint_pretty_writer__init_A_const_20 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[89]); A_arbace_pprint_pretty_writer__init_A_const_21 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[90]); A_arbace_pprint_pretty_writer__init_A_const_22 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[91]); A_arbace_pprint_pretty_writer__init_A_const_23 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[92]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p2() { A_arbace_pprint_pretty_writer__init_A_const_24 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[93]; A_arbace_pprint_pretty_writer__init_A_const_25 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[94]); A_arbace_pprint_pretty_writer__init_A_const_26 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[95]; A_arbace_pprint_pretty_writer__init_A_const_27 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[96]); A_arbace_pprint_pretty_writer__init_A_const_28 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[97]; A_arbace_pprint_pretty_writer__init_A_const_29 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[98]); A_arbace_pprint_pretty_writer__init_A_const_30 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[99]; A_arbace_pprint_pretty_writer__init_A_const_31 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[100]); A_arbace_pprint_pretty_writer__init_A_const_32 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[101]); A_arbace_pprint_pretty_writer__init_A_const_33 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[102]); A_arbace_pprint_pretty_writer__init_A_const_34 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[103]); A_arbace_pprint_pretty_writer__init_A_const_35 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[104]); A_arbace_pprint_pretty_writer__init_A_const_36 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[105]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p3() { A_arbace_pprint_pretty_writer__init_A_const_37 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[106]; A_arbace_pprint_pretty_writer__init_A_const_38 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[107]); A_arbace_pprint_pretty_writer__init_A_const_39 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[108]); A_arbace_pprint_pretty_writer__init_A_const_40 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[109]); A_arbace_pprint_pretty_writer__init_A_const_41 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[110]); A_arbace_pprint_pretty_writer__init_A_const_42 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[111]; A_arbace_pprint_pretty_writer__init_A_const_43 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[112]); A_arbace_pprint_pretty_writer__init_A_const_44 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[113]; A_arbace_pprint_pretty_writer__init_A_const_45 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[114]); A_arbace_pprint_pretty_writer__init_A_const_46 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[115]); A_arbace_pprint_pretty_writer__init_A_const_47 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[116]); A_arbace_pprint_pretty_writer__init_A_const_48 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[117]; A_arbace_pprint_pretty_writer__init_A_const_49 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[118]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p4() { A_arbace_pprint_pretty_writer__init_A_const_50 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[119]; A_arbace_pprint_pretty_writer__init_A_const_51 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[120]); A_arbace_pprint_pretty_writer__init_A_const_52 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[121]; A_arbace_pprint_pretty_writer__init_A_const_53 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[122]); A_arbace_pprint_pretty_writer__init_A_const_54 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[123]; A_arbace_pprint_pretty_writer__init_A_const_55 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[124]); A_arbace_pprint_pretty_writer__init_A_const_56 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[125]; A_arbace_pprint_pretty_writer__init_A_const_57 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[126]); A_arbace_pprint_pretty_writer__init_A_const_58 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[127]; A_arbace_pprint_pretty_writer__init_A_const_59 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[128]); A_arbace_pprint_pretty_writer__init_A_const_60 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[129]; A_arbace_pprint_pretty_writer__init_A_const_61 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[130]); A_arbace_pprint_pretty_writer__init_A_const_62 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[131] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p5() { A_arbace_pprint_pretty_writer__init_A_const_63 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[132]); A_arbace_pprint_pretty_writer__init_A_const_64 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[133]; A_arbace_pprint_pretty_writer__init_A_const_65 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[134]); A_arbace_pprint_pretty_writer__init_A_const_66 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[135]); A_arbace_pprint_pretty_writer__init_A_const_67 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[136]); A_arbace_pprint_pretty_writer__init_A_const_68 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[137]; A_arbace_pprint_pretty_writer__init_A_const_69 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[138]); A_arbace_pprint_pretty_writer__init_A_const_70 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[139]; A_arbace_pprint_pretty_writer__init_A_const_71 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[140]); A_arbace_pprint_pretty_writer__init_A_const_72 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[141]; A_arbace_pprint_pretty_writer__init_A_const_73 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[142]); A_arbace_pprint_pretty_writer__init_A_const_74 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[143]); A_arbace_pprint_pretty_writer__init_A_const_75 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[144] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p6() { A_arbace_pprint_pretty_writer__init_A_const_76 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[145]); A_arbace_pprint_pretty_writer__init_A_const_77 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[146]; A_arbace_pprint_pretty_writer__init_A_const_78 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[147]); A_arbace_pprint_pretty_writer__init_A_const_79 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[148]; A_arbace_pprint_pretty_writer__init_A_const_80 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[149]); A_arbace_pprint_pretty_writer__init_A_const_81 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[150]); A_arbace_pprint_pretty_writer__init_A_const_82 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[151]); A_arbace_pprint_pretty_writer__init_A_const_83 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[152]; A_arbace_pprint_pretty_writer__init_A_const_84 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[153]); A_arbace_pprint_pretty_writer__init_A_const_85 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[154]); A_arbace_pprint_pretty_writer__init_A_const_86 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[155]); A_arbace_pprint_pretty_writer__init_A_const_87 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[156]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p7() { A_arbace_pprint_pretty_writer__init_A_const_88 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[157]); A_arbace_pprint_pretty_writer__init_A_const_89 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[158]); A_arbace_pprint_pretty_writer__init_A_const_90 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[159]; A_arbace_pprint_pretty_writer__init_A_const_91 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[160]); A_arbace_pprint_pretty_writer__init_A_const_92 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[161]; A_arbace_pprint_pretty_writer__init_A_const_93 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[162]); A_arbace_pprint_pretty_writer__init_A_const_94 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[163]; A_arbace_pprint_pretty_writer__init_A_const_95 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[164]); A_arbace_pprint_pretty_writer__init_A_const_96 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[165]; A_arbace_pprint_pretty_writer__init_A_const_97 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[166]); A_arbace_pprint_pretty_writer__init_A_const_98 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[167]; A_arbace_pprint_pretty_writer__init_A_const_99 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[168]; A_arbace_pprint_pretty_writer__init_A_const_100 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[169]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p8() { A_arbace_pprint_pretty_writer__init_A_const_101 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[170]); A_arbace_pprint_pretty_writer__init_A_const_102 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[171]); A_arbace_pprint_pretty_writer__init_A_const_103 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[172]); A_arbace_pprint_pretty_writer__init_A_const_104 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[173]); A_arbace_pprint_pretty_writer__init_A_const_105 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[174]; A_arbace_pprint_pretty_writer__init_A_const_106 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[175]); A_arbace_pprint_pretty_writer__init_A_const_107 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[176]; A_arbace_pprint_pretty_writer__init_A_const_108 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[177]); A_arbace_pprint_pretty_writer__init_A_const_109 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[178]; A_arbace_pprint_pretty_writer__init_A_const_110 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[179]; A_arbace_pprint_pretty_writer__init_A_const_111 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[180]); A_arbace_pprint_pretty_writer__init_A_const_112 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[181]; A_arbace_pprint_pretty_writer__init_A_const_113 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[182]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p9() { A_arbace_pprint_pretty_writer__init_A_const_114 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[183]; A_arbace_pprint_pretty_writer__init_A_const_115 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[184]; A_arbace_pprint_pretty_writer__init_A_const_116 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[185]); A_arbace_pprint_pretty_writer__init_A_const_117 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[186]; A_arbace_pprint_pretty_writer__init_A_const_118 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[187]); A_arbace_pprint_pretty_writer__init_A_const_119 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[188]; A_arbace_pprint_pretty_writer__init_A_const_120 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[189]); A_arbace_pprint_pretty_writer__init_A_const_121 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[190]; A_arbace_pprint_pretty_writer__init_A_const_122 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[191]); A_arbace_pprint_pretty_writer__init_A_const_123 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[192]; A_arbace_pprint_pretty_writer__init_A_const_124 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[193]); A_arbace_pprint_pretty_writer__init_A_const_125 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[194]; A_arbace_pprint_pretty_writer__init_A_const_126 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[195]); A_arbace_pprint_pretty_writer__init_A_const_127 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[196] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p10() { A_arbace_pprint_pretty_writer__init_A_const_128 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[197]); A_arbace_pprint_pretty_writer__init_A_const_129 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[198]; A_arbace_pprint_pretty_writer__init_A_const_130 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[199]); A_arbace_pprint_pretty_writer__init_A_const_131 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[200]; A_arbace_pprint_pretty_writer__init_A_const_132 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[201]); A_arbace_pprint_pretty_writer__init_A_const_133 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[202]; A_arbace_pprint_pretty_writer__init_A_const_134 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[203]); A_arbace_pprint_pretty_writer__init_A_const_135 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[204]); A_arbace_pprint_pretty_writer__init_A_const_136 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[205]); A_arbace_pprint_pretty_writer__init_A_const_137 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[206]); A_arbace_pprint_pretty_writer__init_A_const_138 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[207]); A_arbace_pprint_pretty_writer__init_A_const_139 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[208]; A_arbace_pprint_pretty_writer__init_A_const_140 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[209]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p11() { A_arbace_pprint_pretty_writer__init_A_const_141 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[210]; A_arbace_pprint_pretty_writer__init_A_const_142 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[211]); A_arbace_pprint_pretty_writer__init_A_const_143 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[212]; A_arbace_pprint_pretty_writer__init_A_const_144 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[213]); A_arbace_pprint_pretty_writer__init_A_const_145 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[214]; A_arbace_pprint_pretty_writer__init_A_const_146 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[215]; A_arbace_pprint_pretty_writer__init_A_const_147 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[216]); A_arbace_pprint_pretty_writer__init_A_const_148 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[217]; A_arbace_pprint_pretty_writer__init_A_const_149 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[218]); A_arbace_pprint_pretty_writer__init_A_const_150 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[219] }

func A_arbace_pprint_pretty_writer__init_A_New() *A_arbace_pprint_pretty_writer__init_A { A_arbace_pprint_pretty_writer__init_A_Init(); t := &A_arbace_pprint_pretty_writer__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_pretty_writer__init_A) Ctor() {}

func (t *A_arbace_pprint_pretty_writer__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_pretty_writer__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_pretty_writer__init_A_class }

func (t *A_arbace_pprint_pretty_writer__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_pretty_writer__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_pretty_writer__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_pretty_writer__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_pretty_writer__init_A); return ok }

func A_arbace_pprint_pretty_writer__init_A_Cast(x any) *A_arbace_pprint_pretty_writer__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_pretty_writer__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_pretty_writer__init_A_class)) }; return v }
