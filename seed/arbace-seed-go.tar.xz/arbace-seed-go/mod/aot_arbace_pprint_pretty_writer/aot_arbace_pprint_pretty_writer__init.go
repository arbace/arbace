//line aot_arbace_pprint_pretty_writer__init.ae:1
package aot_arbace_pprint_pretty_writer

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_pretty_writer__init_A_Load__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); jrt.StartCheck(); A_arbace_pprint_pretty_writer__init_A_Unit0__O(); A_arbace_pprint_pretty_writer__init_A_Unit1__O(); A_arbace_pprint_pretty_writer__init_A_Unit2__O(); A_arbace_pprint_pretty_writer__init_A_Unit3__O(); A_arbace_pprint_pretty_writer__init_A_Unit4__O(); A_arbace_pprint_pretty_writer__init_A_Unit5__O(); A_arbace_pprint_pretty_writer__init_A_Unit6__O(); A_arbace_pprint_pretty_writer__init_A_Unit7__O(); A_arbace_pprint_pretty_writer__init_A_Unit8__O(); A_arbace_pprint_pretty_writer__init_A_Unit9__O(); A_arbace_pprint_pretty_writer__init_A_Unit10__O(); A_arbace_pprint_pretty_writer__init_A_Unit11__O(); A_arbace_pprint_pretty_writer__init_A_Unit12__O(); A_arbace_pprint_pretty_writer__init_A_Unit13__O(); A_arbace_pprint_pretty_writer__init_A_Unit14__O(); A_arbace_pprint_pretty_writer__init_A_Unit15__O(); A_arbace_pprint_pretty_writer__init_A_Unit16__O(); A_arbace_pprint_pretty_writer__init_A_Unit17__O(); A_arbace_pprint_pretty_writer__init_A_Unit18__O(); A_arbace_pprint_pretty_writer__init_A_Unit19__O(); A_arbace_pprint_pretty_writer__init_A_Unit20__O(); A_arbace_pprint_pretty_writer__init_A_Unit21__O(); A_arbace_pprint_pretty_writer__init_A_Unit22__O(); A_arbace_pprint_pretty_writer__init_A_Unit23__O(); A_arbace_pprint_pretty_writer__init_A_Unit24__O(); A_arbace_pprint_pretty_writer__init_A_Unit25__O(); A_arbace_pprint_pretty_writer__init_A_Unit26__O(); A_arbace_pprint_pretty_writer__init_A_Unit27__O(); A_arbace_pprint_pretty_writer__init_A_Unit28__O(); A_arbace_pprint_pretty_writer__init_A_Unit29__O(); A_arbace_pprint_pretty_writer__init_A_Unit30__O(); A_arbace_pprint_pretty_writer__init_A_Unit31__O(); A_arbace_pprint_pretty_writer__init_A_Unit32__O(); A_arbace_pprint_pretty_writer__init_A_Unit33__O(); A_arbace_pprint_pretty_writer__init_A_Unit34__O(); A_arbace_pprint_pretty_writer__init_A_Unit35__O(); A_arbace_pprint_pretty_writer__init_A_Unit36__O(); A_arbace_pprint_pretty_writer__init_A_Unit37__O(); A_arbace_pprint_pretty_writer__init_A_Unit38__O(); A_arbace_pprint_pretty_writer__init_A_Unit39__O(); A_arbace_pprint_pretty_writer__init_A_Unit40__O(); A_arbace_pprint_pretty_writer__init_A_Unit41__O(); A_arbace_pprint_pretty_writer__init_A_Unit42__O(); A_arbace_pprint_pretty_writer__init_A_Unit43__O(); A_arbace_pprint_pretty_writer__init_A_Unit44__O(); A_arbace_pprint_pretty_writer__init_A_Unit45__O(); A_arbace_pprint_pretty_writer__init_A_Unit46__O(); A_arbace_pprint_pretty_writer__init_A_Unit47__O(); A_arbace_pprint_pretty_writer__init_A_Unit48__O(); A_arbace_pprint_pretty_writer__init_A_Unit49__O(); A_arbace_pprint_pretty_writer__init_A_Unit50__O(); A_arbace_pprint_pretty_writer__init_A_Unit51__O(); A_arbace_pprint_pretty_writer__init_A_Unit52__O(); A_arbace_pprint_pretty_writer__init_A_Unit53__O(); A_arbace_pprint_pretty_writer__init_A_Unit54__O(); A_arbace_pprint_pretty_writer__init_A_Unit55__O(); A_arbace_pprint_pretty_writer__init_A_Unit56__O(); A_arbace_pprint_pretty_writer__init_A_Unit57__O(); A_arbace_pprint_pretty_writer__init_A_Unit58__O(); A_arbace_pprint_pretty_writer__init_A_Unit59__O(); A_arbace_pprint_pretty_writer__init_A_Unit60__O(); A_arbace_pprint_pretty_writer__init_A_Unit61__O(); A_arbace_pprint_pretty_writer__init_A_Unit62__O(); A_arbace_pprint_pretty_writer__init_A_Unit63__O(); A_arbace_pprint_pretty_writer__init_A_Unit64__O(); A_arbace_pprint_pretty_writer__init_A_Unit65__O(); A_arbace_pprint_pretty_writer__init_A_Unit66__O(); A_arbace_pprint_pretty_writer__init_A_Unit67__O(); A_arbace_pprint_pretty_writer__init_A_Unit68__O(); A_arbace_pprint_pretty_writer__init_A_Unit69__O(); A_arbace_pprint_pretty_writer__init_A_Unit70__O(); A_arbace_pprint_pretty_writer__init_A_Unit71__O(); A_arbace_pprint_pretty_writer__init_A_Unit72__O(); A_arbace_pprint_pretty_writer__init_A_Unit73__O(); A_arbace_pprint_pretty_writer__init_A_Unit74__O(); A_arbace_pprint_pretty_writer__init_A_Unit75__O(); A_arbace_pprint_pretty_writer__init_A_Unit76__O(); A_arbace_pprint_pretty_writer__init_A_Unit77__O(); A_arbace_pprint_pretty_writer__init_A_Unit78__O(); A_arbace_pprint_pretty_writer__init_A_Unit79__O(); A_arbace_pprint_pretty_writer__init_A_Unit80__O(); A_arbace_pprint_pretty_writer__init_A_Unit81__O(); return nil }












func A_arbace_pprint_pretty_writer__init_A_Unit0__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pretty_writer__init_A_const_1) }

func A_arbace_pprint_pretty_writer__init_A_Unit1__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }
//line :20:1
func A_arbace_pprint_pretty_writer__init_A_Unit2__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)).Ref() }








func A_arbace_pprint_pretty_writer__init_A_Unit3__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_3)); return A_arbace_pprint_pretty_writer__init_A_const_2 }






func A_arbace_pprint_pretty_writer__init_A_Unit4__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_4; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_getf_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_getf_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_pprint.A_arbace_pprint_getf_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_5)); return A_arbace_pprint_pretty_writer__init_A_const_4 }
//line :36:1
func A_arbace_pprint_pretty_writer__init_A_Unit5__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); A_arbace_pprint_pretty_writer__init_A_const_4.SetMacro__V(); return nil }
//line :36:1
func A_arbace_pprint_pretty_writer__init_A_Unit6__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); return A_arbace_pprint_pretty_writer__init_A_const_4 }





func A_arbace_pprint_pretty_writer__init_A_Unit7__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_6; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_setf_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_setf_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_pprint.A_arbace_pprint_setf_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_7)); return A_arbace_pprint_pretty_writer__init_A_const_6 }
//line :42:1
func A_arbace_pprint_pretty_writer__init_A_Unit8__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_pprint_pretty_writer__init_A_const_6.SetMacro__V(); return nil }
//line :42:1
func A_arbace_pprint_pretty_writer__init_A_Unit9__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); return A_arbace_pprint_pretty_writer__init_A_const_6 }





func A_arbace_pprint_pretty_writer__init_A_Unit10__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_8; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_deftype_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_deftype_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, true); aot_arbace_pprint.A_arbace_pprint_deftype_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_9)); return A_arbace_pprint_pretty_writer__init_A_const_8 }
//line :48:1
func A_arbace_pprint_pretty_writer__init_A_Unit11__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); A_arbace_pprint_pretty_writer__init_A_const_8.SetMacro__V(); return nil }
//line :48:1
func A_arbace_pprint_pretty_writer__init_A_Unit12__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_pprint_pretty_writer__init_A_const_8 }









func A_arbace_pprint_pretty_writer__init_A_Unit13__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_10; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_to_base_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_to_base_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, true); aot_arbace_pprint.A_arbace_pprint_write_to_base_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_11)); return A_arbace_pprint_pretty_writer__init_A_const_10 }
//line :58:1
func A_arbace_pprint_pretty_writer__init_A_Unit14__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_pprint_pretty_writer__init_A_const_10.SetMacro__V(); return nil }
//line :58:1
func A_arbace_pprint_pretty_writer__init_A_Unit15__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); return A_arbace_pprint_pretty_writer__init_A_const_10 }











func A_arbace_pprint_pretty_writer__init_A_Unit16__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_12; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_14, A_arbace_pprint_pretty_writer__init_A_const_15, A_arbace_pprint_pretty_writer__init_A_const_16, A_arbace_pprint_pretty_writer__init_A_const_17, A_arbace_pprint_pretty_writer__init_A_const_18, A_arbace_pprint_pretty_writer__init_A_const_19, A_arbace_pprint_pretty_writer__init_A_const_20, A_arbace_pprint_pretty_writer__init_A_const_21, A_arbace_pprint_pretty_writer__init_A_const_22, A_arbace_pprint_pretty_writer__init_A_const_23)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_24)); return A_arbace_pprint_pretty_writer__init_A_const_12 }





func A_arbace_pprint_pretty_writer__init_A_Unit17__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_25; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_26)); return A_arbace_pprint_pretty_writer__init_A_const_25 }






func A_arbace_pprint_pretty_writer__init_A_Unit18__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_27; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pretty_writer__init_A_const_14)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_27; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_28)); return A_arbace_pprint_pretty_writer__init_A_const_27 }

func A_arbace_pprint_pretty_writer__init_A_Unit19__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_29; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_buffer_length_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_buffer_length_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_pprint.A_arbace_pprint_buffer_length_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_30)); return A_arbace_pprint_pretty_writer__init_A_const_29 }






func A_arbace_pprint_pretty_writer__init_A_Unit20__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_31; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_33, A_arbace_pprint_pretty_writer__init_A_const_34, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_31; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_37)); return A_arbace_pprint_pretty_writer__init_A_const_31 }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit21__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_31; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit22__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_41; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, true); aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_42)); return A_arbace_pprint_pretty_writer__init_A_const_41 }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit23__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_43; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_44)); return A_arbace_pprint_pretty_writer__init_A_const_43 }


func A_arbace_pprint_pretty_writer__init_A_Unit24__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_45; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_46, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_45; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_48)); return A_arbace_pprint_pretty_writer__init_A_const_45 }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit25__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_45; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit26__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_49; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, true); aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_50)); return A_arbace_pprint_pretty_writer__init_A_const_49 }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit27__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_51; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_52)); return A_arbace_pprint_pretty_writer__init_A_const_51 }

func A_arbace_pprint_pretty_writer__init_A_Unit28__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_53; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_53; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_54)); return A_arbace_pprint_pretty_writer__init_A_const_53 }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit29__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_53; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit30__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_55; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, true); aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_56)); return A_arbace_pprint_pretty_writer__init_A_const_55 }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit31__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_57; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_58)); return A_arbace_pprint_pretty_writer__init_A_const_57 }

func A_arbace_pprint_pretty_writer__init_A_Unit32__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_59; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_59; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_60)); return A_arbace_pprint_pretty_writer__init_A_const_59 }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit33__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_59; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit34__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_61; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_New(); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, true); aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_62)); return A_arbace_pprint_pretty_writer__init_A_const_61 }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit35__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_63; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_64)); return A_arbace_pprint_pretty_writer__init_A_const_63 }

func A_arbace_pprint_pretty_writer__init_A_Unit36__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_65; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_32, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_66, A_arbace_pprint_pretty_writer__init_A_const_67, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_65; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_68)); return A_arbace_pprint_pretty_writer__init_A_const_65 }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit37__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_65; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(), A_arbace_pprint_pretty_writer__init_A_const_40, jrt.Boolean_TRUE.Ref()) }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit38__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_69; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_New(); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, true); aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_70)); return A_arbace_pprint_pretty_writer__init_A_const_69 }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit39__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_71; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_72)); return A_arbace_pprint_pretty_writer__init_A_const_71 }





func A_arbace_pprint_pretty_writer__init_A_Unit40__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_73; var tmp2 any; var root_109 any = A_arbace_pprint_pretty_writer__init_A_const_74.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_memoize_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_New(); var tmp4 *jrt.Class; var fncls__108 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_fn_class = fncls__108d; tmp4 = fncls__108d } else { tmp4 = fncls__108 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_110 == nil { tmp2 = ifn_111.Invoke_O__O(arg_112) } else { tmp2 = linked_110.(*aot_arbace_core.A_arbace_core_memoize_A).Invoke_O_O__O(root_109, arg_112) }; tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_73; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_75)); return A_arbace_pprint_pretty_writer__init_A_const_73 }

func A_arbace_pprint_pretty_writer__init_A_Unit41__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_77)); return A_arbace_pprint_pretty_writer__init_A_const_76 }

func A_arbace_pprint_pretty_writer__init_A_Unit42__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_79)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_78; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_113 any = A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = v__1927000386__auto____1; if linked_114 == nil { tmp3 = ifn_115.Invoke_O__O(arg_116) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_113, arg_116) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_83)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; var tmp6 *jrt.String = Lit_20; var tmp7 any = aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_New(); var tmp8 *jrt.Class; var fncls__117 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class = fncls__117d; tmp8 = fncls__117d } else { tmp8 = fncls__117 }; var tmp9 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_78 } }
func A_arbace_pprint_pretty_writer__init_A_Unit43__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_84; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_New(); var tmp4 *jrt.Class; var fncls__118 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class = fncls__118d; tmp4 = fncls__118d } else { tmp4 = fncls__118 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }









func A_arbace_pprint_pretty_writer__init_A_Unit44__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_85; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_New(); var tmp4 *jrt.Class; var fncls__119 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class = fncls__119d; tmp4 = fncls__119d } else { tmp4 = fncls__119 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_pprint_pretty_writer__init_A_Unit45__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_86; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_New(); var tmp4 *jrt.Class; var fncls__120 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class = fncls__120d; tmp4 = fncls__120d } else { tmp4 = fncls__120 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_pprint_pretty_writer__init_A_Unit46__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_87; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_New(); var tmp4 *jrt.Class; var fncls__121 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class = fncls__121d; tmp4 = fncls__121d } else { tmp4 = fncls__121 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_pprint_pretty_writer__init_A_Unit47__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(138, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_88; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_New(); var tmp4 *jrt.Class; var fncls__122 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class = fncls__122d; tmp4 = fncls__122d } else { tmp4 = fncls__122 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_pprint_pretty_writer__init_A_Unit48__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_89; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_tokens_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_tokens_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); aot_arbace_pprint.A_arbace_pprint_write_tokens_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_90)); return A_arbace_pprint_pretty_writer__init_A_const_89 }
















func A_arbace_pprint_pretty_writer__init_A_Unit49__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_91; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__124 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_fn_class = fncls__124d; tmp3 = fncls__124d } else { tmp3 = fncls__124 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_92)); return A_arbace_pprint_pretty_writer__init_A_const_91 }






func A_arbace_pprint_pretty_writer__init_A_Unit50__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_93; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_94)); return A_arbace_pprint_pretty_writer__init_A_const_93 }




func A_arbace_pprint_pretty_writer__init_A_Unit51__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_95; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__126 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_fn_class = fncls__126d; tmp3 = fncls__126d } else { tmp3 = fncls__126 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_96)); return A_arbace_pprint_pretty_writer__init_A_const_95 }






func A_arbace_pprint_pretty_writer__init_A_Unit52__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_98)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_97; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_127 any = A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = v__1927000386__auto____1; if linked_128 == nil { tmp3 = ifn_129.Invoke_O__O(arg_130) } else { tmp3 = linked_128.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_127, arg_130) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_99)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; var tmp6 *jrt.String = Lit_31; var tmp7 any = aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_New(); var tmp8 *jrt.Class; var fncls__131 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class = fncls__131d; tmp8 = fncls__131d } else { tmp8 = fncls__131 }; var tmp9 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_97 } }

func A_arbace_pprint_pretty_writer__init_A_Unit53__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_100; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_New(); var tmp4 *jrt.Class; var fncls__132 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class = fncls__132d; tmp4 = fncls__132d } else { tmp4 = fncls__132 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_pprint_pretty_writer__init_A_Unit54__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_101; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_New(); var tmp4 *jrt.Class; var fncls__133 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class = fncls__133d; tmp4 = fncls__133d } else { tmp4 = fncls__133 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_pprint_pretty_writer__init_A_Unit55__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_102; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_New(); var tmp4 *jrt.Class; var fncls__134 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class = fncls__134d; tmp4 = fncls__134d } else { tmp4 = fncls__134 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit56__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_103; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_New(); var tmp4 *jrt.Class; var fncls__135 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class = fncls__135d; tmp4 = fncls__135d } else { tmp4 = fncls__135 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit57__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_104; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_section_A_New(); var tmp3 *jrt.Class; var fncls__136 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_section_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); aot_arbace_pprint.A_arbace_pprint_get_section_A_fn_class = fncls__136d; tmp3 = fncls__136d } else { tmp3 = fncls__136 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_105)); return A_arbace_pprint_pretty_writer__init_A_const_104 }






func A_arbace_pprint_pretty_writer__init_A_Unit58__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_106; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_107)); return A_arbace_pprint_pretty_writer__init_A_const_106 }







func A_arbace_pprint_pretty_writer__init_A_Unit59__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_108; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_New(); var tmp3 *jrt.Class; var fncls__138 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_fn_class = fncls__138d; tmp3 = fncls__138d } else { tmp3 = fncls__138 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_109)); return A_arbace_pprint_pretty_writer__init_A_const_108 }









func A_arbace_pprint_pretty_writer__init_A_Unit60__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_emit_nl_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_emit_nl_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); aot_arbace_pprint.A_arbace_pprint_emit_nl_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_110)); return A_arbace_pprint_pretty_writer__init_A_const_76 }











func A_arbace_pprint_pretty_writer__init_A_Unit61__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_111; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_New(); var tmp3 *jrt.Class; var fncls__140 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_fn_class = fncls__140d; tmp3 = fncls__140d } else { tmp3 = fncls__140 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_112)); return A_arbace_pprint_pretty_writer__init_A_const_111 }





func A_arbace_pprint_pretty_writer__init_A_Unit62__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_114)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_113; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_141 any = A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = v__1927000386__auto____1; if linked_142 == nil { tmp3 = ifn_143.Invoke_O__O(arg_144) } else { tmp3 = linked_142.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_141, arg_144) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_115)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; var tmp6 *jrt.String = Lit_42; var tmp7 lang.IFn = A_arbace_pprint_pretty_writer__init_A_const_32; var tmp8 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_113 } }
func A_arbace_pprint_pretty_writer__init_A_Unit63__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(252, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_88; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_New(); var tmp4 *jrt.Class; var fncls__145 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class = fncls__145d; tmp4 = fncls__145d } else { tmp4 = fncls__145 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit64__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_87; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_New(); var tmp4 *jrt.Class; var fncls__146 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class = fncls__146d; tmp4 = fncls__146d } else { tmp4 = fncls__146 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit65__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_81; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_New(); var tmp4 *jrt.Class; var fncls__147 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class = fncls__147d; tmp4 = fncls__147d } else { tmp4 = fncls__147 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit66__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_116; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_toks_A_New(); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_toks_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); aot_arbace_pprint.A_arbace_pprint_toks_A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_117)); return A_arbace_pprint_pretty_writer__init_A_const_116 }




func A_arbace_pprint_pretty_writer__init_A_Unit67__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_118; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_token_string_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_token_string_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); aot_arbace_pprint.A_arbace_pprint_write_token_string_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_119)); return A_arbace_pprint_pretty_writer__init_A_const_118 }





























func A_arbace_pprint_pretty_writer__init_A_Unit68__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(293, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_120; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_line_A_New(); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_line_A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); aot_arbace_pprint.A_arbace_pprint_write_line_A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_121)); return A_arbace_pprint_pretty_writer__init_A_const_120 }












func A_arbace_pprint_pretty_writer__init_A_Unit69__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_122; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_123)); return A_arbace_pprint_pretty_writer__init_A_const_122 }







func A_arbace_pprint_pretty_writer__init_A_Unit70__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_124; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_New(); var tmp3 *jrt.Class; var fncls__152 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_fn_class = fncls__152d; tmp3 = fncls__152d } else { tmp3 = fncls__152 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_125)); return A_arbace_pprint_pretty_writer__init_A_const_124 }






func A_arbace_pprint_pretty_writer__init_A_Unit71__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_126; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_white_space_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_white_space_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); aot_arbace_pprint.A_arbace_pprint_write_white_space_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_127)); return A_arbace_pprint_pretty_writer__init_A_const_126 }








func A_arbace_pprint_pretty_writer__init_A_Unit72__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_128; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_New(); var tmp3 *jrt.Class; var fncls__154 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_fn_class; if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_fn_class = fncls__154d; tmp3 = fncls__154d } else { tmp3 = fncls__154 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_129)); return A_arbace_pprint_pretty_writer__init_A_const_128 }

























func A_arbace_pprint_pretty_writer__init_A_Unit73__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_130; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_p_write_char_A_New(); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_p_write_char_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); aot_arbace_pprint.A_arbace_pprint_p_write_char_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_131)); return A_arbace_pprint_pretty_writer__init_A_const_130 }
















func A_arbace_pprint_pretty_writer__init_A_Unit74__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(373, 1); var tmp1 any = A_arbace_pprint_pretty_writer__init_A_const_135; lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_134.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_pprint_pretty_writer__init_A_const_136, A_arbace_pprint_pretty_writer__init_A_const_137)))); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_132; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_New(); var tmp4 *jrt.Class; var fncls__156 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_fn_class = fncls__156d; tmp4 = fncls__156d } else { tmp4 = fncls__156 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_132; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_133)); return A_arbace_pprint_pretty_writer__init_A_const_132 }





























































func A_arbace_pprint_pretty_writer__init_A_Unit75__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(435, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_138; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_start_block_A_New(); var tmp3 *jrt.Class; var fncls__157 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_start_block_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); aot_arbace_pprint.A_arbace_pprint_start_block_A_fn_class = fncls__157d; tmp3 = fncls__157d } else { tmp3 = fncls__157 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_139)); return A_arbace_pprint_pretty_writer__init_A_const_138 }





















func A_arbace_pprint_pretty_writer__init_A_Unit76__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(457, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_140; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_end_block_A_New(); var tmp3 *jrt.Class; var fncls__158 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_end_block_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); aot_arbace_pprint.A_arbace_pprint_end_block_A_fn_class = fncls__158d; tmp3 = fncls__158d } else { tmp3 = fncls__158 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_141)); return A_arbace_pprint_pretty_writer__init_A_const_140 }















func A_arbace_pprint_pretty_writer__init_A_Unit77__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(473, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_142; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_nl_A_New(); var tmp3 *jrt.Class; var fncls__159 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_nl_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); aot_arbace_pprint.A_arbace_pprint_nl_A_fn_class = fncls__159d; tmp3 = fncls__159d } else { tmp3 = fncls__159 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_143)); return A_arbace_pprint_pretty_writer__init_A_const_142 }





func A_arbace_pprint_pretty_writer__init_A_Unit78__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(479, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_144; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_indent_A_New(); var tmp3 *jrt.Class; var fncls__160 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_indent_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); aot_arbace_pprint.A_arbace_pprint_indent_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_145)); return A_arbace_pprint_pretty_writer__init_A_const_144 }












func A_arbace_pprint_pretty_writer__init_A_Unit79__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(492, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_146)); return A_arbace_pprint_pretty_writer__init_A_const_2 }


func A_arbace_pprint_pretty_writer__init_A_Unit80__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(495, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_147; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_New(); var tmp3 *jrt.Class; var fncls__162 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_fn_class; if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_fn_class = fncls__162d; tmp3 = fncls__162d } else { tmp3 = fncls__162 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_148)); return A_arbace_pprint_pretty_writer__init_A_const_147 }


func A_arbace_pprint_pretty_writer__init_A_Unit81__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(498, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_149; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_New(); var tmp3 *jrt.Class; var fncls__163 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_fn_class = fncls__163d; tmp3 = fncls__163d } else { tmp3 = fncls__163 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_150)); return A_arbace_pprint_pretty_writer__init_A_const_149 }



type A_arbace_pprint_pretty_writer__init_A struct{ jrt.Object }

var A_arbace_pprint_pretty_writer__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_pretty_writer__init_A_const_0 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_1 any

var A_arbace_pprint_pretty_writer__init_A_const_2 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_3 any

var A_arbace_pprint_pretty_writer__init_A_const_4 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_5 any

var A_arbace_pprint_pretty_writer__init_A_const_6 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_7 any

var A_arbace_pprint_pretty_writer__init_A_const_8 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_9 any

var A_arbace_pprint_pretty_writer__init_A_const_10 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_11 any

var A_arbace_pprint_pretty_writer__init_A_const_12 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_13 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_14 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_15 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_16 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_17 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_18 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_19 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_20 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_21 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_22 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_23 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_24 any

var A_arbace_pprint_pretty_writer__init_A_const_25 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_26 any

var A_arbace_pprint_pretty_writer__init_A_const_27 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_28 any

var A_arbace_pprint_pretty_writer__init_A_const_29 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_30 any

var A_arbace_pprint_pretty_writer__init_A_const_31 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_32 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_33 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_34 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_35 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_36 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_37 any

var A_arbace_pprint_pretty_writer__init_A_const_38 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_39 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_40 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_41 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_42 any

var A_arbace_pprint_pretty_writer__init_A_const_43 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_44 any

var A_arbace_pprint_pretty_writer__init_A_const_45 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_46 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_47 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_48 any

var A_arbace_pprint_pretty_writer__init_A_const_49 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_50 any

var A_arbace_pprint_pretty_writer__init_A_const_51 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_52 any

var A_arbace_pprint_pretty_writer__init_A_const_53 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_54 any

var A_arbace_pprint_pretty_writer__init_A_const_55 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_56 any

var A_arbace_pprint_pretty_writer__init_A_const_57 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_58 any

var A_arbace_pprint_pretty_writer__init_A_const_59 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_60 any

var A_arbace_pprint_pretty_writer__init_A_const_61 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_62 any

var A_arbace_pprint_pretty_writer__init_A_const_63 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_64 any

var A_arbace_pprint_pretty_writer__init_A_const_65 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_66 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_67 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_68 any

var A_arbace_pprint_pretty_writer__init_A_const_69 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_70 any

var A_arbace_pprint_pretty_writer__init_A_const_71 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_72 any

var A_arbace_pprint_pretty_writer__init_A_const_73 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_74 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_75 any

var A_arbace_pprint_pretty_writer__init_A_const_76 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_77 any

var A_arbace_pprint_pretty_writer__init_A_const_78 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_79 any

var A_arbace_pprint_pretty_writer__init_A_const_80 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_81 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_82 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_83 any

var A_arbace_pprint_pretty_writer__init_A_const_84 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_85 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_86 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_87 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_88 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_89 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_90 any

var A_arbace_pprint_pretty_writer__init_A_const_91 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_92 any

var A_arbace_pprint_pretty_writer__init_A_const_93 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_94 any

var A_arbace_pprint_pretty_writer__init_A_const_95 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_96 any

var A_arbace_pprint_pretty_writer__init_A_const_97 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_98 any

var A_arbace_pprint_pretty_writer__init_A_const_99 any

var A_arbace_pprint_pretty_writer__init_A_const_100 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_101 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_102 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_103 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_104 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_105 any

var A_arbace_pprint_pretty_writer__init_A_const_106 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_107 any

var A_arbace_pprint_pretty_writer__init_A_const_108 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_109 any

var A_arbace_pprint_pretty_writer__init_A_const_110 any

var A_arbace_pprint_pretty_writer__init_A_const_111 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_112 any

var A_arbace_pprint_pretty_writer__init_A_const_113 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_114 any

var A_arbace_pprint_pretty_writer__init_A_const_115 any

var A_arbace_pprint_pretty_writer__init_A_const_116 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_117 any

var A_arbace_pprint_pretty_writer__init_A_const_118 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_119 any

var A_arbace_pprint_pretty_writer__init_A_const_120 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_121 any

var A_arbace_pprint_pretty_writer__init_A_const_122 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_123 any

var A_arbace_pprint_pretty_writer__init_A_const_124 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_125 any

var A_arbace_pprint_pretty_writer__init_A_const_126 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_127 any

var A_arbace_pprint_pretty_writer__init_A_const_128 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_129 any

var A_arbace_pprint_pretty_writer__init_A_const_130 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_131 any

var A_arbace_pprint_pretty_writer__init_A_const_132 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_133 any

var A_arbace_pprint_pretty_writer__init_A_const_134 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_135 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_136 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_137 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_138 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_139 any

var A_arbace_pprint_pretty_writer__init_A_const_140 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_141 any

var A_arbace_pprint_pretty_writer__init_A_const_142 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_143 any

var A_arbace_pprint_pretty_writer__init_A_const_144 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_145 any

var A_arbace_pprint_pretty_writer__init_A_const_146 any

var A_arbace_pprint_pretty_writer__init_A_const_147 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_148 any

var A_arbace_pprint_pretty_writer__init_A_const_149 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_150 any

var A_arbace_pprint_pretty_writer__init_A_init jrt.ClassInit

func A_arbace_pprint_pretty_writer__init_A_Init() { if !A_arbace_pprint_pretty_writer__init_A_init.Done() { A_arbace_pprint_pretty_writer__init_A_init.Run(A_arbace_pprint_pretty_writer__init_A_clinit) } }

func A_arbace_pprint_pretty_writer__init_A_clinit() { A_arbace_pprint_pretty_writer__init_A_clinit_p0(); A_arbace_pprint_pretty_writer__init_A_clinit_p1(); A_arbace_pprint_pretty_writer__init_A_clinit_p2(); A_arbace_pprint_pretty_writer__init_A_clinit_p3(); A_arbace_pprint_pretty_writer__init_A_clinit_p4(); A_arbace_pprint_pretty_writer__init_A_clinit_p5(); A_arbace_pprint_pretty_writer__init_A_clinit_p6(); A_arbace_pprint_pretty_writer__init_A_clinit_p7(); A_arbace_pprint_pretty_writer__init_A_clinit_p8(); A_arbace_pprint_pretty_writer__init_A_clinit_p9(); A_arbace_pprint_pretty_writer__init_A_clinit_p10(); A_arbace_pprint_pretty_writer__init_A_clinit_p11() }

func A_arbace_pprint_pretty_writer__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_pprint_pretty_writer__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 220); A_arbace_pprint_pretty_writer__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[69]); A_arbace_pprint_pretty_writer__init_A_const_1 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[70]; A_arbace_pprint_pretty_writer__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[71]); A_arbace_pprint_pretty_writer__init_A_const_3 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[72]; A_arbace_pprint_pretty_writer__init_A_const_4 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[73]); A_arbace_pprint_pretty_writer__init_A_const_5 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[74]; A_arbace_pprint_pretty_writer__init_A_const_6 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[75]); A_arbace_pprint_pretty_writer__init_A_const_7 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[76]; A_arbace_pprint_pretty_writer__init_A_const_8 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[77]); A_arbace_pprint_pretty_writer__init_A_const_9 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[78]; A_arbace_pprint_pretty_writer__init_A_const_10 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[79]); A_arbace_pprint_pretty_writer__init_A_const_11 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[80] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p1() { A_arbace_pprint_pretty_writer__init_A_const_12 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[81]); A_arbace_pprint_pretty_writer__init_A_const_13 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[82]); A_arbace_pprint_pretty_writer__init_A_const_14 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[83]); A_arbace_pprint_pretty_writer__init_A_const_15 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[84]); A_arbace_pprint_pretty_writer__init_A_const_16 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[85]); A_arbace_pprint_pretty_writer__init_A_const_17 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[86]); A_arbace_pprint_pretty_writer__init_A_const_18 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[87]); A_arbace_pprint_pretty_writer__init_A_const_19 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[88]); A_arbace_pprint_pretty_writer__init_A_const_20 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[89]); A_arbace_pprint_pretty_writer__init_A_const_21 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[90]); A_arbace_pprint_pretty_writer__init_A_const_22 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[91]); A_arbace_pprint_pretty_writer__init_A_const_23 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[92]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p2() { A_arbace_pprint_pretty_writer__init_A_const_24 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[93]; A_arbace_pprint_pretty_writer__init_A_const_25 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[94]); A_arbace_pprint_pretty_writer__init_A_const_26 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[95]; A_arbace_pprint_pretty_writer__init_A_const_27 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[96]); A_arbace_pprint_pretty_writer__init_A_const_28 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[97]; A_arbace_pprint_pretty_writer__init_A_const_29 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[98]); A_arbace_pprint_pretty_writer__init_A_const_30 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[99]; A_arbace_pprint_pretty_writer__init_A_const_31 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[100]); A_arbace_pprint_pretty_writer__init_A_const_32 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[101]); A_arbace_pprint_pretty_writer__init_A_const_33 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[102]); A_arbace_pprint_pretty_writer__init_A_const_34 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[103]); A_arbace_pprint_pretty_writer__init_A_const_35 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[104]); A_arbace_pprint_pretty_writer__init_A_const_36 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[105]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p3() { A_arbace_pprint_pretty_writer__init_A_const_37 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[106]; A_arbace_pprint_pretty_writer__init_A_const_38 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[107]); A_arbace_pprint_pretty_writer__init_A_const_39 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[108]); A_arbace_pprint_pretty_writer__init_A_const_40 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[109]); A_arbace_pprint_pretty_writer__init_A_const_41 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[110]); A_arbace_pprint_pretty_writer__init_A_const_42 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[111]; A_arbace_pprint_pretty_writer__init_A_const_43 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[112]); A_arbace_pprint_pretty_writer__init_A_const_44 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[113]; A_arbace_pprint_pretty_writer__init_A_const_45 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[114]); A_arbace_pprint_pretty_writer__init_A_const_46 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[115]); A_arbace_pprint_pretty_writer__init_A_const_47 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[116]); A_arbace_pprint_pretty_writer__init_A_const_48 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[117]; A_arbace_pprint_pretty_writer__init_A_const_49 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[118]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p4() { A_arbace_pprint_pretty_writer__init_A_const_50 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[119]; A_arbace_pprint_pretty_writer__init_A_const_51 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[120]); A_arbace_pprint_pretty_writer__init_A_const_52 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[121]; A_arbace_pprint_pretty_writer__init_A_const_53 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[122]); A_arbace_pprint_pretty_writer__init_A_const_54 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[123]; A_arbace_pprint_pretty_writer__init_A_const_55 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[124]); A_arbace_pprint_pretty_writer__init_A_const_56 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[125]; A_arbace_pprint_pretty_writer__init_A_const_57 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[126]); A_arbace_pprint_pretty_writer__init_A_const_58 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[127]; A_arbace_pprint_pretty_writer__init_A_const_59 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[128]); A_arbace_pprint_pretty_writer__init_A_const_60 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[129]; A_arbace_pprint_pretty_writer__init_A_const_61 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[130]); A_arbace_pprint_pretty_writer__init_A_const_62 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[131] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p5() { A_arbace_pprint_pretty_writer__init_A_const_63 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[132]); A_arbace_pprint_pretty_writer__init_A_const_64 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[133]; A_arbace_pprint_pretty_writer__init_A_const_65 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[134]); A_arbace_pprint_pretty_writer__init_A_const_66 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[135]); A_arbace_pprint_pretty_writer__init_A_const_67 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[136]); A_arbace_pprint_pretty_writer__init_A_const_68 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[137]; A_arbace_pprint_pretty_writer__init_A_const_69 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[138]); A_arbace_pprint_pretty_writer__init_A_const_70 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[139]; A_arbace_pprint_pretty_writer__init_A_const_71 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[140]); A_arbace_pprint_pretty_writer__init_A_const_72 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[141]; A_arbace_pprint_pretty_writer__init_A_const_73 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[142]); A_arbace_pprint_pretty_writer__init_A_const_74 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[143]); A_arbace_pprint_pretty_writer__init_A_const_75 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[144] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p6() { A_arbace_pprint_pretty_writer__init_A_const_76 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[145]); A_arbace_pprint_pretty_writer__init_A_const_77 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[146]; A_arbace_pprint_pretty_writer__init_A_const_78 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[147]); A_arbace_pprint_pretty_writer__init_A_const_79 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[148]; A_arbace_pprint_pretty_writer__init_A_const_80 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[149]); A_arbace_pprint_pretty_writer__init_A_const_81 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[150]); A_arbace_pprint_pretty_writer__init_A_const_82 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[151]); A_arbace_pprint_pretty_writer__init_A_const_83 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[152]; A_arbace_pprint_pretty_writer__init_A_const_84 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[153]); A_arbace_pprint_pretty_writer__init_A_const_85 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[154]); A_arbace_pprint_pretty_writer__init_A_const_86 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[155]); A_arbace_pprint_pretty_writer__init_A_const_87 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[156]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p7() { A_arbace_pprint_pretty_writer__init_A_const_88 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[157]); A_arbace_pprint_pretty_writer__init_A_const_89 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[158]); A_arbace_pprint_pretty_writer__init_A_const_90 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[159]; A_arbace_pprint_pretty_writer__init_A_const_91 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[160]); A_arbace_pprint_pretty_writer__init_A_const_92 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[161]; A_arbace_pprint_pretty_writer__init_A_const_93 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[162]); A_arbace_pprint_pretty_writer__init_A_const_94 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[163]; A_arbace_pprint_pretty_writer__init_A_const_95 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[164]); A_arbace_pprint_pretty_writer__init_A_const_96 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[165]; A_arbace_pprint_pretty_writer__init_A_const_97 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[166]); A_arbace_pprint_pretty_writer__init_A_const_98 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[167]; A_arbace_pprint_pretty_writer__init_A_const_99 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[168]; A_arbace_pprint_pretty_writer__init_A_const_100 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[169]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p8() { A_arbace_pprint_pretty_writer__init_A_const_101 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[170]); A_arbace_pprint_pretty_writer__init_A_const_102 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[171]); A_arbace_pprint_pretty_writer__init_A_const_103 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[172]); A_arbace_pprint_pretty_writer__init_A_const_104 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[173]); A_arbace_pprint_pretty_writer__init_A_const_105 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[174]; A_arbace_pprint_pretty_writer__init_A_const_106 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[175]); A_arbace_pprint_pretty_writer__init_A_const_107 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[176]; A_arbace_pprint_pretty_writer__init_A_const_108 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[177]); A_arbace_pprint_pretty_writer__init_A_const_109 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[178]; A_arbace_pprint_pretty_writer__init_A_const_110 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[179]; A_arbace_pprint_pretty_writer__init_A_const_111 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[180]); A_arbace_pprint_pretty_writer__init_A_const_112 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[181]; A_arbace_pprint_pretty_writer__init_A_const_113 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[182]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p9() { A_arbace_pprint_pretty_writer__init_A_const_114 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[183]; A_arbace_pprint_pretty_writer__init_A_const_115 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[184]; A_arbace_pprint_pretty_writer__init_A_const_116 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[185]); A_arbace_pprint_pretty_writer__init_A_const_117 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[186]; A_arbace_pprint_pretty_writer__init_A_const_118 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[187]); A_arbace_pprint_pretty_writer__init_A_const_119 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[188]; A_arbace_pprint_pretty_writer__init_A_const_120 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[189]); A_arbace_pprint_pretty_writer__init_A_const_121 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[190]; A_arbace_pprint_pretty_writer__init_A_const_122 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[191]); A_arbace_pprint_pretty_writer__init_A_const_123 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[192]; A_arbace_pprint_pretty_writer__init_A_const_124 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[193]); A_arbace_pprint_pretty_writer__init_A_const_125 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[194]; A_arbace_pprint_pretty_writer__init_A_const_126 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[195]); A_arbace_pprint_pretty_writer__init_A_const_127 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[196] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p10() { A_arbace_pprint_pretty_writer__init_A_const_128 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[197]); A_arbace_pprint_pretty_writer__init_A_const_129 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[198]; A_arbace_pprint_pretty_writer__init_A_const_130 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[199]); A_arbace_pprint_pretty_writer__init_A_const_131 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[200]; A_arbace_pprint_pretty_writer__init_A_const_132 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[201]); A_arbace_pprint_pretty_writer__init_A_const_133 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[202]; A_arbace_pprint_pretty_writer__init_A_const_134 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[203]); A_arbace_pprint_pretty_writer__init_A_const_135 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[204]); A_arbace_pprint_pretty_writer__init_A_const_136 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[205]); A_arbace_pprint_pretty_writer__init_A_const_137 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[206]); A_arbace_pprint_pretty_writer__init_A_const_138 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[207]); A_arbace_pprint_pretty_writer__init_A_const_139 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[208]; A_arbace_pprint_pretty_writer__init_A_const_140 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[209]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p11() { A_arbace_pprint_pretty_writer__init_A_const_141 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[210]; A_arbace_pprint_pretty_writer__init_A_const_142 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[211]); A_arbace_pprint_pretty_writer__init_A_const_143 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[212]; A_arbace_pprint_pretty_writer__init_A_const_144 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[213]); A_arbace_pprint_pretty_writer__init_A_const_145 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[214]; A_arbace_pprint_pretty_writer__init_A_const_146 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[215]; A_arbace_pprint_pretty_writer__init_A_const_147 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[216]); A_arbace_pprint_pretty_writer__init_A_const_148 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[217]; A_arbace_pprint_pretty_writer__init_A_const_149 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[218]); A_arbace_pprint_pretty_writer__init_A_const_150 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[219] }

func A_arbace_pprint_pretty_writer__init_A_New() *A_arbace_pprint_pretty_writer__init_A { A_arbace_pprint_pretty_writer__init_A_Init(); t := &A_arbace_pprint_pretty_writer__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_pretty_writer__init_A) Ctor() {}

func (t *A_arbace_pprint_pretty_writer__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_pretty_writer__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_pretty_writer__init_A_class }

func (t *A_arbace_pprint_pretty_writer__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_pretty_writer__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_pretty_writer__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_pretty_writer__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_pretty_writer__init_A); return ok }

func A_arbace_pprint_pretty_writer__init_A_Cast(x any) *A_arbace_pprint_pretty_writer__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_pretty_writer__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_pretty_writer__init_A_class)) }; return v }
