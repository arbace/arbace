//line aot_arbace_pprint_pretty_writer__init.ae:1
package aot_arbace_pprint_pretty_writer

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_pretty_writer__init_A_Load__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); A_arbace_pprint_pretty_writer__init_A_Unit0__O(); A_arbace_pprint_pretty_writer__init_A_Unit1__O(); A_arbace_pprint_pretty_writer__init_A_Unit2__O(); A_arbace_pprint_pretty_writer__init_A_Unit3__O(); A_arbace_pprint_pretty_writer__init_A_Unit4__O(); A_arbace_pprint_pretty_writer__init_A_Unit5__O(); A_arbace_pprint_pretty_writer__init_A_Unit6__O(); A_arbace_pprint_pretty_writer__init_A_Unit7__O(); A_arbace_pprint_pretty_writer__init_A_Unit8__O(); A_arbace_pprint_pretty_writer__init_A_Unit9__O(); A_arbace_pprint_pretty_writer__init_A_Unit10__O(); A_arbace_pprint_pretty_writer__init_A_Unit11__O(); A_arbace_pprint_pretty_writer__init_A_Unit12__O(); A_arbace_pprint_pretty_writer__init_A_Unit13__O(); A_arbace_pprint_pretty_writer__init_A_Unit14__O(); A_arbace_pprint_pretty_writer__init_A_Unit15__O(); A_arbace_pprint_pretty_writer__init_A_Unit16__O(); A_arbace_pprint_pretty_writer__init_A_Unit17__O(); A_arbace_pprint_pretty_writer__init_A_Unit18__O(); A_arbace_pprint_pretty_writer__init_A_Unit19__O(); A_arbace_pprint_pretty_writer__init_A_Unit20__O(); A_arbace_pprint_pretty_writer__init_A_Unit21__O(); A_arbace_pprint_pretty_writer__init_A_Unit22__O(); A_arbace_pprint_pretty_writer__init_A_Unit23__O(); A_arbace_pprint_pretty_writer__init_A_Unit24__O(); A_arbace_pprint_pretty_writer__init_A_Unit25__O(); A_arbace_pprint_pretty_writer__init_A_Unit26__O(); A_arbace_pprint_pretty_writer__init_A_Unit27__O(); A_arbace_pprint_pretty_writer__init_A_Unit28__O(); A_arbace_pprint_pretty_writer__init_A_Unit29__O(); A_arbace_pprint_pretty_writer__init_A_Unit30__O(); A_arbace_pprint_pretty_writer__init_A_Unit31__O(); A_arbace_pprint_pretty_writer__init_A_Unit32__O(); A_arbace_pprint_pretty_writer__init_A_Unit33__O(); A_arbace_pprint_pretty_writer__init_A_Unit34__O(); A_arbace_pprint_pretty_writer__init_A_Unit35__O(); A_arbace_pprint_pretty_writer__init_A_Unit36__O(); A_arbace_pprint_pretty_writer__init_A_Unit37__O(); A_arbace_pprint_pretty_writer__init_A_Unit38__O(); A_arbace_pprint_pretty_writer__init_A_Unit39__O(); A_arbace_pprint_pretty_writer__init_A_Unit40__O(); A_arbace_pprint_pretty_writer__init_A_Unit41__O(); A_arbace_pprint_pretty_writer__init_A_Unit42__O(); A_arbace_pprint_pretty_writer__init_A_Unit43__O(); A_arbace_pprint_pretty_writer__init_A_Unit44__O(); A_arbace_pprint_pretty_writer__init_A_Unit45__O(); A_arbace_pprint_pretty_writer__init_A_Unit46__O(); A_arbace_pprint_pretty_writer__init_A_Unit47__O(); A_arbace_pprint_pretty_writer__init_A_Unit48__O(); A_arbace_pprint_pretty_writer__init_A_Unit49__O(); A_arbace_pprint_pretty_writer__init_A_Unit50__O(); A_arbace_pprint_pretty_writer__init_A_Unit51__O(); A_arbace_pprint_pretty_writer__init_A_Unit52__O(); A_arbace_pprint_pretty_writer__init_A_Unit53__O(); A_arbace_pprint_pretty_writer__init_A_Unit54__O(); A_arbace_pprint_pretty_writer__init_A_Unit55__O(); A_arbace_pprint_pretty_writer__init_A_Unit56__O(); A_arbace_pprint_pretty_writer__init_A_Unit57__O(); A_arbace_pprint_pretty_writer__init_A_Unit58__O(); A_arbace_pprint_pretty_writer__init_A_Unit59__O(); A_arbace_pprint_pretty_writer__init_A_Unit60__O(); A_arbace_pprint_pretty_writer__init_A_Unit61__O(); A_arbace_pprint_pretty_writer__init_A_Unit62__O(); A_arbace_pprint_pretty_writer__init_A_Unit63__O(); A_arbace_pprint_pretty_writer__init_A_Unit64__O(); A_arbace_pprint_pretty_writer__init_A_Unit65__O(); A_arbace_pprint_pretty_writer__init_A_Unit66__O(); A_arbace_pprint_pretty_writer__init_A_Unit67__O(); A_arbace_pprint_pretty_writer__init_A_Unit68__O(); A_arbace_pprint_pretty_writer__init_A_Unit69__O(); A_arbace_pprint_pretty_writer__init_A_Unit70__O(); A_arbace_pprint_pretty_writer__init_A_Unit71__O(); A_arbace_pprint_pretty_writer__init_A_Unit72__O(); A_arbace_pprint_pretty_writer__init_A_Unit73__O(); A_arbace_pprint_pretty_writer__init_A_Unit74__O(); A_arbace_pprint_pretty_writer__init_A_Unit75__O(); A_arbace_pprint_pretty_writer__init_A_Unit76__O(); A_arbace_pprint_pretty_writer__init_A_Unit77__O(); A_arbace_pprint_pretty_writer__init_A_Unit78__O(); A_arbace_pprint_pretty_writer__init_A_Unit79__O(); A_arbace_pprint_pretty_writer__init_A_Unit80__O(); A_arbace_pprint_pretty_writer__init_A_Unit81__O(); return nil }












func A_arbace_pprint_pretty_writer__init_A_Unit0__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pretty_writer__init_A_const_1) }

func A_arbace_pprint_pretty_writer__init_A_Unit1__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_116)); return nil }
//line :20:1
func A_arbace_pprint_pretty_writer__init_A_Unit2__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_115)); return nil }








func A_arbace_pprint_pretty_writer__init_A_Unit3__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_3)); return A_arbace_pprint_pretty_writer__init_A_const_2.Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit4__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_4; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_getf_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_getf_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_getf_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_5)); return A_arbace_pprint_pretty_writer__init_A_const_4.Ref() }
//line :36:1
func A_arbace_pprint_pretty_writer__init_A_Unit5__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_4).SetMacro__V(); return nil }
//line :36:1
func A_arbace_pprint_pretty_writer__init_A_Unit6__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); return A_arbace_pprint_pretty_writer__init_A_const_4.Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit7__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_6; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_setf_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_setf_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_setf_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_7)); return A_arbace_pprint_pretty_writer__init_A_const_6.Ref() }
//line :42:1
func A_arbace_pprint_pretty_writer__init_A_Unit8__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_6).SetMacro__V(); return nil }
//line :42:1
func A_arbace_pprint_pretty_writer__init_A_Unit9__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); return A_arbace_pprint_pretty_writer__init_A_const_6.Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit10__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_8; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_deftype_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_deftype_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_deftype_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_9)); return A_arbace_pprint_pretty_writer__init_A_const_8.Ref() }
//line :48:1
func A_arbace_pprint_pretty_writer__init_A_Unit11__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_8).SetMacro__V(); return nil }
//line :48:1
func A_arbace_pprint_pretty_writer__init_A_Unit12__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_pprint_pretty_writer__init_A_const_8.Ref() }









func A_arbace_pprint_pretty_writer__init_A_Unit13__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_10; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_to_base_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_to_base_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_to_base_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_11)); return A_arbace_pprint_pretty_writer__init_A_const_10.Ref() }
//line :58:1
func A_arbace_pprint_pretty_writer__init_A_Unit14__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_10).SetMacro__V(); return nil }
//line :58:1
func A_arbace_pprint_pretty_writer__init_A_Unit15__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); return A_arbace_pprint_pretty_writer__init_A_const_10.Ref() }











func A_arbace_pprint_pretty_writer__init_A_Unit16__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_12; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_13).GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_15.Ref(), A_arbace_pprint_pretty_writer__init_A_const_16.Ref(), A_arbace_pprint_pretty_writer__init_A_const_17.Ref(), A_arbace_pprint_pretty_writer__init_A_const_18.Ref(), A_arbace_pprint_pretty_writer__init_A_const_19.Ref(), A_arbace_pprint_pretty_writer__init_A_const_20.Ref(), A_arbace_pprint_pretty_writer__init_A_const_21.Ref(), A_arbace_pprint_pretty_writer__init_A_const_22.Ref(), A_arbace_pprint_pretty_writer__init_A_const_23.Ref(), A_arbace_pprint_pretty_writer__init_A_const_24.Ref())); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_12; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_14)); return A_arbace_pprint_pretty_writer__init_A_const_12.Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit17__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_25; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_26)); return A_arbace_pprint_pretty_writer__init_A_const_25.Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit18__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_27; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_13).GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pretty_writer__init_A_const_15.Ref())); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_27; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_28)); return A_arbace_pprint_pretty_writer__init_A_const_27.Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit19__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_29; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_buffer_length_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_buffer_length_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_buffer_length_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_30)); return A_arbace_pprint_pretty_writer__init_A_const_29.Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit20__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_31; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_13).GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33.Ref(), A_arbace_pprint_pretty_writer__init_A_const_34.Ref(), A_arbace_pprint_pretty_writer__init_A_const_35.Ref(), A_arbace_pprint_pretty_writer__init_A_const_36.Ref(), A_arbace_pprint_pretty_writer__init_A_const_37.Ref())); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_31; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_32)); return A_arbace_pprint_pretty_writer__init_A_const_31.Ref() }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit21__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_38).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_31.Ref(); var tmp3 any = jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_39).GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40.Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit22__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_41; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_42)); return A_arbace_pprint_pretty_writer__init_A_const_41.Ref() }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit23__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_43; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_44)); return A_arbace_pprint_pretty_writer__init_A_const_43.Ref() }


func A_arbace_pprint_pretty_writer__init_A_Unit24__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_45; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_13).GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33.Ref(), A_arbace_pprint_pretty_writer__init_A_const_47.Ref(), A_arbace_pprint_pretty_writer__init_A_const_48.Ref(), A_arbace_pprint_pretty_writer__init_A_const_36.Ref(), A_arbace_pprint_pretty_writer__init_A_const_37.Ref())); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_45; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_46)); return A_arbace_pprint_pretty_writer__init_A_const_45.Ref() }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit25__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_38).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_45.Ref(); var tmp3 any = jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_39).GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40.Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit26__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_49; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_50)); return A_arbace_pprint_pretty_writer__init_A_const_49.Ref() }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit27__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_51; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_52)); return A_arbace_pprint_pretty_writer__init_A_const_51.Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit28__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_53; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_13).GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33.Ref(), A_arbace_pprint_pretty_writer__init_A_const_48.Ref(), A_arbace_pprint_pretty_writer__init_A_const_36.Ref(), A_arbace_pprint_pretty_writer__init_A_const_37.Ref())); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_53; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_54)); return A_arbace_pprint_pretty_writer__init_A_const_53.Ref() }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit29__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_38).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_53.Ref(); var tmp3 any = jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_39).GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40.Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit30__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_55; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_56)); return A_arbace_pprint_pretty_writer__init_A_const_55.Ref() }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit31__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_57; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_58)); return A_arbace_pprint_pretty_writer__init_A_const_57.Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit32__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_59; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_13).GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33.Ref(), A_arbace_pprint_pretty_writer__init_A_const_48.Ref(), A_arbace_pprint_pretty_writer__init_A_const_36.Ref(), A_arbace_pprint_pretty_writer__init_A_const_37.Ref())); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_59; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_60)); return A_arbace_pprint_pretty_writer__init_A_const_59.Ref() }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit33__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_38).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_59.Ref(); var tmp3 any = jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_39).GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40.Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit34__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_61; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_62)); return A_arbace_pprint_pretty_writer__init_A_const_61.Ref() }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit35__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_63; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_63; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_64)); return A_arbace_pprint_pretty_writer__init_A_const_63.Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit36__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_65; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_13).GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33.Ref(), A_arbace_pprint_pretty_writer__init_A_const_48.Ref(), A_arbace_pprint_pretty_writer__init_A_const_67.Ref(), A_arbace_pprint_pretty_writer__init_A_const_68.Ref(), A_arbace_pprint_pretty_writer__init_A_const_36.Ref(), A_arbace_pprint_pretty_writer__init_A_const_37.Ref())); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_65; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_66)); return A_arbace_pprint_pretty_writer__init_A_const_65.Ref() }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit37__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_38).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_65.Ref(); var tmp3 any = jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_39).GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40.Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit38__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_69; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_69; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_70)); return A_arbace_pprint_pretty_writer__init_A_const_69.Ref() }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit39__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_71; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_71; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_72)); return A_arbace_pprint_pretty_writer__init_A_const_71.Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit40__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_73; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_74).GetRawRoot__O()); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_73; jrt.NN(tmp5).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_75)); return A_arbace_pprint_pretty_writer__init_A_const_73.Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit41__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_77)); return A_arbace_pprint_pretty_writer__init_A_const_76.Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit42__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_79)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_78.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_80).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_83)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; var tmp5 *jrt.String = Lit_71; var tmp6 any = aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_New(); var tmp7 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_Init(); tmp7 = aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class; var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_pprint_pretty_writer__init_A_const_81.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, Up_Var_IRef(A_arbace_pprint_pretty_writer__init_A_const_82))); return A_arbace_pprint_pretty_writer__init_A_const_78.Ref() } }
func A_arbace_pprint_pretty_writer__init_A_Unit43__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(112, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_78).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_84.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }









func A_arbace_pprint_pretty_writer__init_A_Unit44__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_78).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_85.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_pprint_pretty_writer__init_A_Unit45__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(127, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_78).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_86.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_pprint_pretty_writer__init_A_Unit46__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(135, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_78).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_87.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_pprint_pretty_writer__init_A_Unit47__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_78).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_88.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_pprint_pretty_writer__init_A_Unit48__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(149, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_89; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_tokens_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_tokens_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_tokens_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_89; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_90)); return A_arbace_pprint_pretty_writer__init_A_const_89.Ref() }
















func A_arbace_pprint_pretty_writer__init_A_Unit49__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_91; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_91; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_92)); return A_arbace_pprint_pretty_writer__init_A_const_91.Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit50__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_93; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_93; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_94)); return A_arbace_pprint_pretty_writer__init_A_const_93.Ref() }




func A_arbace_pprint_pretty_writer__init_A_Unit51__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_95; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_95; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_96)); return A_arbace_pprint_pretty_writer__init_A_const_95.Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit52__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_98)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_97.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_80).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_99)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; var tmp5 *jrt.String = Lit_85; var tmp6 any = aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_New(); var tmp7 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_Init(); tmp7 = aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class; var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_pprint_pretty_writer__init_A_const_81.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, Up_Var_IRef(A_arbace_pprint_pretty_writer__init_A_const_82))); return A_arbace_pprint_pretty_writer__init_A_const_97.Ref() } }

func A_arbace_pprint_pretty_writer__init_A_Unit53__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(187, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_97).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_100.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_pprint_pretty_writer__init_A_Unit54__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(191, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_97).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_101.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_pprint_pretty_writer__init_A_Unit55__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(195, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_97).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_102.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit56__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_97).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_103.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit57__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(208, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_104; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_section_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_get_section_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_get_section_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_104; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_105)); return A_arbace_pprint_pretty_writer__init_A_const_104.Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit58__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(215, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_106; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_106; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_107)); return A_arbace_pprint_pretty_writer__init_A_const_106.Ref() }







func A_arbace_pprint_pretty_writer__init_A_Unit59__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(223, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_108; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_108; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_109)); return A_arbace_pprint_pretty_writer__init_A_const_108.Ref() }









func A_arbace_pprint_pretty_writer__init_A_Unit60__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(233, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_emit_nl_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_emit_nl_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_emit_nl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_110)); return A_arbace_pprint_pretty_writer__init_A_const_76.Ref() }











func A_arbace_pprint_pretty_writer__init_A_Unit61__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(245, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_111; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_111; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_112)); return A_arbace_pprint_pretty_writer__init_A_const_111.Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit62__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(251, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_114)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_113.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_80).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_115)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; var tmp5 *jrt.String = Lit_96; var tmp6 lang.IFn = Up_Keyword_IFn(A_arbace_pprint_pretty_writer__init_A_const_33); var tmp7 any = A_arbace_pprint_pretty_writer__init_A_const_81.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, Up_Var_IRef(A_arbace_pprint_pretty_writer__init_A_const_82))); return A_arbace_pprint_pretty_writer__init_A_const_113.Ref() } }
func A_arbace_pprint_pretty_writer__init_A_Unit63__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(252, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_113).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_88.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit64__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(254, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_113).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_87.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit65__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(256, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_113).GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_81.Ref(); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit66__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(258, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_116; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_toks_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_toks_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_toks_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_116; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_117)); return A_arbace_pprint_pretty_writer__init_A_const_116.Ref() }




func A_arbace_pprint_pretty_writer__init_A_Unit67__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(263, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_118; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_token_string_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_token_string_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_token_string_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_118; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_119)); return A_arbace_pprint_pretty_writer__init_A_const_118.Ref() }





























func A_arbace_pprint_pretty_writer__init_A_Unit68__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(293, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_120; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_line_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_line_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_120; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_121)); return A_arbace_pprint_pretty_writer__init_A_const_120.Ref() }












func A_arbace_pprint_pretty_writer__init_A_Unit69__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(306, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_122; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_122; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_123)); return A_arbace_pprint_pretty_writer__init_A_const_122.Ref() }







func A_arbace_pprint_pretty_writer__init_A_Unit70__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_124; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_124; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_125)); return A_arbace_pprint_pretty_writer__init_A_const_124.Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit71__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(321, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_126; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_white_space_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_white_space_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_white_space_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_126; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_127)); return A_arbace_pprint_pretty_writer__init_A_const_126.Ref() }








func A_arbace_pprint_pretty_writer__init_A_Unit72__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(330, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_128; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_128; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_129)); return A_arbace_pprint_pretty_writer__init_A_const_128.Ref() }

























func A_arbace_pprint_pretty_writer__init_A_Unit73__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(356, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_130; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_p_write_char_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_p_write_char_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_p_write_char_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_130; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_131)); return A_arbace_pprint_pretty_writer__init_A_const_130.Ref() }
















func A_arbace_pprint_pretty_writer__init_A_Unit74__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(373, 1); var tmp1 any = A_arbace_pprint_pretty_writer__init_A_const_135.Ref(); lang.IFn_Cast(jrt.NN(A_arbace_pprint_pretty_writer__init_A_const_134).GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq(tmp1, lang.RT_Seq_O__ISeq(jrt.RefArrayOf(jrt.Object_class, A_arbace_pprint_pretty_writer__init_A_const_136.Ref(), A_arbace_pprint_pretty_writer__init_A_const_137.Ref())))); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_132; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_fn_class; jrt.NN(tmp2).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_132; jrt.NN(tmp5).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_133)); return A_arbace_pprint_pretty_writer__init_A_const_132.Ref() }





























































func A_arbace_pprint_pretty_writer__init_A_Unit75__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(435, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_138; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_start_block_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_start_block_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_start_block_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_138; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_139)); return A_arbace_pprint_pretty_writer__init_A_const_138.Ref() }





















func A_arbace_pprint_pretty_writer__init_A_Unit76__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(457, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_140; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_end_block_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_end_block_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_end_block_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_140; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_141)); return A_arbace_pprint_pretty_writer__init_A_const_140.Ref() }















func A_arbace_pprint_pretty_writer__init_A_Unit77__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(473, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_142; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_nl_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_nl_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_nl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_142; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_143)); return A_arbace_pprint_pretty_writer__init_A_const_142.Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit78__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(479, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_144; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_indent_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_indent_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_indent_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_144; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_145)); return A_arbace_pprint_pretty_writer__init_A_const_144.Ref() }












func A_arbace_pprint_pretty_writer__init_A_Unit79__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(492, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_146)); return A_arbace_pprint_pretty_writer__init_A_const_2.Ref() }


func A_arbace_pprint_pretty_writer__init_A_Unit80__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(495, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_147; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_147; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_148)); return A_arbace_pprint_pretty_writer__init_A_const_147.Ref() }


func A_arbace_pprint_pretty_writer__init_A_Unit81__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(498, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_149; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_149; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_150)); return A_arbace_pprint_pretty_writer__init_A_const_149.Ref() }



type A_arbace_pprint_pretty_writer__init_A struct{ jrt.Object }

var A_arbace_pprint_pretty_writer__init_A_const_0 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_1 any

var A_arbace_pprint_pretty_writer__init_A_const_2 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_3 any

var A_arbace_pprint_pretty_writer__init_A_const_4 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_5 any

var A_arbace_pprint_pretty_writer__init_A_const_6 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_7 any

var A_arbace_pprint_pretty_writer__init_A_const_8 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_9 any

var A_arbace_pprint_pretty_writer__init_A_const_10 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_11 any

var A_arbace_pprint_pretty_writer__init_A_const_12 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_13 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_14 any

var A_arbace_pprint_pretty_writer__init_A_const_15 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_16 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_17 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_18 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_19 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_20 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_21 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_22 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_23 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_24 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_25 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_26 any

var A_arbace_pprint_pretty_writer__init_A_const_27 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_28 any

var A_arbace_pprint_pretty_writer__init_A_const_29 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_30 any

var A_arbace_pprint_pretty_writer__init_A_const_31 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_32 any

var A_arbace_pprint_pretty_writer__init_A_const_33 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_34 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_35 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_36 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_37 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_38 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_39 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_40 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_41 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_42 any

var A_arbace_pprint_pretty_writer__init_A_const_43 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_44 any

var A_arbace_pprint_pretty_writer__init_A_const_45 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_46 any

var A_arbace_pprint_pretty_writer__init_A_const_47 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_48 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_49 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_50 any

var A_arbace_pprint_pretty_writer__init_A_const_51 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_52 any

var A_arbace_pprint_pretty_writer__init_A_const_53 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_54 any

var A_arbace_pprint_pretty_writer__init_A_const_55 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_56 any

var A_arbace_pprint_pretty_writer__init_A_const_57 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_58 any

var A_arbace_pprint_pretty_writer__init_A_const_59 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_60 any

var A_arbace_pprint_pretty_writer__init_A_const_61 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_62 any

var A_arbace_pprint_pretty_writer__init_A_const_63 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_64 any

var A_arbace_pprint_pretty_writer__init_A_const_65 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_66 any

var A_arbace_pprint_pretty_writer__init_A_const_67 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_68 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_69 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_70 any

var A_arbace_pprint_pretty_writer__init_A_const_71 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_72 any

var A_arbace_pprint_pretty_writer__init_A_const_73 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_74 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_75 any

var A_arbace_pprint_pretty_writer__init_A_const_76 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_77 any

var A_arbace_pprint_pretty_writer__init_A_const_78 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_79 any

var A_arbace_pprint_pretty_writer__init_A_const_80 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_81 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_82 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_83 any

var A_arbace_pprint_pretty_writer__init_A_const_84 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_85 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_86 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_87 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_88 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_89 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_90 any

var A_arbace_pprint_pretty_writer__init_A_const_91 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_92 any

var A_arbace_pprint_pretty_writer__init_A_const_93 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_94 any

var A_arbace_pprint_pretty_writer__init_A_const_95 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_96 any

var A_arbace_pprint_pretty_writer__init_A_const_97 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_98 any

var A_arbace_pprint_pretty_writer__init_A_const_99 any

var A_arbace_pprint_pretty_writer__init_A_const_100 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_101 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_102 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_103 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_104 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_105 any

var A_arbace_pprint_pretty_writer__init_A_const_106 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_107 any

var A_arbace_pprint_pretty_writer__init_A_const_108 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_109 any

var A_arbace_pprint_pretty_writer__init_A_const_110 any

var A_arbace_pprint_pretty_writer__init_A_const_111 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_112 any

var A_arbace_pprint_pretty_writer__init_A_const_113 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_114 any

var A_arbace_pprint_pretty_writer__init_A_const_115 any

var A_arbace_pprint_pretty_writer__init_A_const_116 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_117 any

var A_arbace_pprint_pretty_writer__init_A_const_118 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_119 any

var A_arbace_pprint_pretty_writer__init_A_const_120 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_121 any

var A_arbace_pprint_pretty_writer__init_A_const_122 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_123 any

var A_arbace_pprint_pretty_writer__init_A_const_124 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_125 any

var A_arbace_pprint_pretty_writer__init_A_const_126 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_127 any

var A_arbace_pprint_pretty_writer__init_A_const_128 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_129 any

var A_arbace_pprint_pretty_writer__init_A_const_130 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_131 any

var A_arbace_pprint_pretty_writer__init_A_const_132 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_133 any

var A_arbace_pprint_pretty_writer__init_A_const_134 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_135 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_136 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_137 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_138 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_139 any

var A_arbace_pprint_pretty_writer__init_A_const_140 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_141 any

var A_arbace_pprint_pretty_writer__init_A_const_142 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_143 any

var A_arbace_pprint_pretty_writer__init_A_const_144 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_145 any

var A_arbace_pprint_pretty_writer__init_A_const_146 any

var A_arbace_pprint_pretty_writer__init_A_const_147 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_148 any

var A_arbace_pprint_pretty_writer__init_A_const_149 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_150 any

var A_arbace_pprint_pretty_writer__init_A_init jrt.ClassInit

func A_arbace_pprint_pretty_writer__init_A_Init() { if !A_arbace_pprint_pretty_writer__init_A_init.Done() { A_arbace_pprint_pretty_writer__init_A_init.Run(A_arbace_pprint_pretty_writer__init_A_clinit) } }

func A_arbace_pprint_pretty_writer__init_A_clinit() { A_arbace_pprint_pretty_writer__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_pprint_pretty_writer__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_2).Ref(); A_arbace_pprint_pretty_writer__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_2, Lit_3); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_pprint_pretty_writer__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_2, Lit_9); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_pprint_pretty_writer__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_14, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_2, Lit_15); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_pprint_pretty_writer__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_17, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_2, Lit_18); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_pprint_pretty_writer__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_2, Lit_22); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_pprint_pretty_writer__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_24, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_2, Lit_25); A_arbace_pprint_pretty_writer__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_pprint_pretty_writer__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_pprint_pretty_writer__init_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_pprint_pretty_writer__init_A_const_17 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_pprint_pretty_writer__init_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_30); A_arbace_pprint_pretty_writer__init_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_pprint_pretty_writer__init_A_const_20 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_pprint_pretty_writer__init_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_pprint_pretty_writer__init_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_34); A_arbace_pprint_pretty_writer__init_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_pprint_pretty_writer__init_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_36); A_arbace_pprint_pretty_writer__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_2, Lit_37); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_pprint_pretty_writer__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(76).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_2, Lit_28); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_pprint_pretty_writer__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(83).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_2, Lit_39); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_pprint_pretty_writer__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(85).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_2, Lit_41); A_arbace_pprint_pretty_writer__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(92).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_pprint_pretty_writer__init_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_pprint_pretty_writer__init_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_pprint_pretty_writer__init_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_pprint_pretty_writer__init_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_pprint_pretty_writer__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_pprint_pretty_writer__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_pprint_pretty_writer__init_A_const_40 = lang.RT_Keyword_String_String__Keyword(nil, Lit_10); A_arbace_pprint_pretty_writer__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_2, Lit_49); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_pprint_pretty_writer__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(92).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_2, Lit_51); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_pprint_pretty_writer__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(92).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_2, Lit_53); A_arbace_pprint_pretty_writer__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_pprint_pretty_writer__init_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_pprint_pretty_writer__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_2, Lit_55); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_pprint_pretty_writer__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_2, Lit_56); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_pprint_pretty_writer__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_2, Lit_57); A_arbace_pprint_pretty_writer__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_2, Lit_58); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_pprint_pretty_writer__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_2, Lit_59); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_pprint_pretty_writer__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_2, Lit_60); A_arbace_pprint_pretty_writer__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_2, Lit_61); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_pprint_pretty_writer__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_2, Lit_62); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_pprint_pretty_writer__init_A_const_64 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_65 = lang.RT_Var_String_String__Var(Lit_2, Lit_63); A_arbace_pprint_pretty_writer__init_A_const_66 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(101).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_64); A_arbace_pprint_pretty_writer__init_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_65); A_arbace_pprint_pretty_writer__init_A_const_69 = lang.RT_Var_String_String__Var(Lit_2, Lit_66); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_pprint_pretty_writer__init_A_const_70 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(101).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_71 = lang.RT_Var_String_String__Var(Lit_2, Lit_67); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_pprint_pretty_writer__init_A_const_72 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(101).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_73 = lang.RT_Var_String_String__Var(Lit_2, Lit_68); A_arbace_pprint_pretty_writer__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_pprint_pretty_writer__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(107).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_2, Lit_70); var tmp61 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp62 *jrt.Boolean; jrt.Boolean_Init(); tmp62 = jrt.Boolean_TRUE; var tmp63 any = tmp62.Ref(); A_arbace_pprint_pretty_writer__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp61, tmp63, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_2, Lit_71); var tmp64 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp65 *jrt.Boolean; jrt.Boolean_Init(); tmp65 = jrt.Boolean_TRUE; var tmp66 any = tmp65.Ref(); A_arbace_pprint_pretty_writer__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64, tmp66, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_pprint_pretty_writer__init_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_pprint_pretty_writer__init_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); var tmp67 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; var tmp69 any = tmp68.Ref(); A_arbace_pprint_pretty_writer__init_A_const_83 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp67, tmp69, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_pprint_pretty_writer__init_A_const_85 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_pprint_pretty_writer__init_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_pprint_pretty_writer__init_A_const_87 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_pprint_pretty_writer__init_A_const_88 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_pprint_pretty_writer__init_A_const_89 = lang.RT_Var_String_String__Var(Lit_2, Lit_75); var tmp70 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp71 *jrt.Boolean; jrt.Boolean_Init(); tmp71 = jrt.Boolean_TRUE; var tmp72 any = tmp71.Ref(); A_arbace_pprint_pretty_writer__init_A_const_90 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp72, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(149).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_91 = lang.RT_Var_String_String__Var(Lit_2, Lit_81); var tmp73 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp74 *jrt.Boolean; jrt.Boolean_Init(); tmp74 = jrt.Boolean_TRUE; var tmp75 any = tmp74.Ref(); A_arbace_pprint_pretty_writer__init_A_const_92 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp75, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(166).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_93 = lang.RT_Var_String_String__Var(Lit_2, Lit_82); var tmp76 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp77 *jrt.Boolean; jrt.Boolean_Init(); tmp77 = jrt.Boolean_TRUE; var tmp78 any = tmp77.Ref(); A_arbace_pprint_pretty_writer__init_A_const_94 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp76, tmp78, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(173).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_95 = lang.RT_Var_String_String__Var(Lit_2, Lit_84); var tmp79 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp80 *jrt.Boolean; jrt.Boolean_Init(); tmp80 = jrt.Boolean_TRUE; var tmp81 any = tmp80.Ref(); A_arbace_pprint_pretty_writer__init_A_const_96 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp79, tmp81, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(178).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_97 = lang.RT_Var_String_String__Var(Lit_2, Lit_85); var tmp82 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp83 *jrt.Boolean; jrt.Boolean_Init(); tmp83 = jrt.Boolean_TRUE; var tmp84 any = tmp83.Ref(); A_arbace_pprint_pretty_writer__init_A_const_98 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp82, tmp84, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(185).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); var tmp85 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp86 *jrt.Boolean; jrt.Boolean_Init(); tmp86 = jrt.Boolean_TRUE; var tmp87 any = tmp86.Ref(); A_arbace_pprint_pretty_writer__init_A_const_99 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp85, tmp87, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(185).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_100 = lang.RT_Keyword_String_String__Keyword(nil, Lit_86); A_arbace_pprint_pretty_writer__init_A_const_101 = lang.RT_Keyword_String_String__Keyword(nil, Lit_87); A_arbace_pprint_pretty_writer__init_A_const_102 = lang.RT_Keyword_String_String__Keyword(nil, Lit_88); A_arbace_pprint_pretty_writer__init_A_const_103 = lang.RT_Keyword_String_String__Keyword(nil, Lit_89); A_arbace_pprint_pretty_writer__init_A_const_104 = lang.RT_Var_String_String__Var(Lit_2, Lit_90); var tmp88 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp89 *jrt.Boolean; jrt.Boolean_Init(); tmp89 = jrt.Boolean_TRUE; var tmp90 any = tmp89.Ref(); A_arbace_pprint_pretty_writer__init_A_const_105 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp88, tmp90, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(208).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_106 = lang.RT_Var_String_String__Var(Lit_2, Lit_92); var tmp91 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp92 *jrt.Boolean; jrt.Boolean_Init(); tmp92 = jrt.Boolean_TRUE; var tmp93 any = tmp92.Ref(); A_arbace_pprint_pretty_writer__init_A_const_107 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp91, tmp93, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(215).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_108 = lang.RT_Var_String_String__Var(Lit_2, Lit_93); var tmp94 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp95 *jrt.Boolean; jrt.Boolean_Init(); tmp95 = jrt.Boolean_TRUE; var tmp96 any = tmp95.Ref(); A_arbace_pprint_pretty_writer__init_A_const_109 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp94, tmp96, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(223).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); var tmp97 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp98 *jrt.Boolean; jrt.Boolean_Init(); tmp98 = jrt.Boolean_TRUE; var tmp99 any = tmp98.Ref(); A_arbace_pprint_pretty_writer__init_A_const_110 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp97, tmp99, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(233).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_111 = lang.RT_Var_String_String__Var(Lit_2, Lit_95); var tmp100 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp101 *jrt.Boolean; jrt.Boolean_Init(); tmp101 = jrt.Boolean_TRUE; var tmp102 any = tmp101.Ref(); A_arbace_pprint_pretty_writer__init_A_const_112 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp100, tmp102, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(245).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_113 = lang.RT_Var_String_String__Var(Lit_2, Lit_96); var tmp103 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp104 *jrt.Boolean; jrt.Boolean_Init(); tmp104 = jrt.Boolean_TRUE; var tmp105 any = tmp104.Ref(); A_arbace_pprint_pretty_writer__init_A_const_114 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp103, tmp105, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(251).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); var tmp106 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp107 *jrt.Boolean; jrt.Boolean_Init(); tmp107 = jrt.Boolean_TRUE; var tmp108 any = tmp107.Ref(); A_arbace_pprint_pretty_writer__init_A_const_115 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp106, tmp108, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(251).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_116 = lang.RT_Var_String_String__Var(Lit_2, Lit_97); var tmp109 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp110 *jrt.Boolean; jrt.Boolean_Init(); tmp110 = jrt.Boolean_TRUE; var tmp111 any = tmp110.Ref(); A_arbace_pprint_pretty_writer__init_A_const_117 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp109, tmp111, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(258).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_118 = lang.RT_Var_String_String__Var(Lit_2, Lit_98); var tmp112 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp113 *jrt.Boolean; jrt.Boolean_Init(); tmp113 = jrt.Boolean_TRUE; var tmp114 any = tmp113.Ref(); A_arbace_pprint_pretty_writer__init_A_const_119 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp112, tmp114, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(263).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_120 = lang.RT_Var_String_String__Var(Lit_2, Lit_99); var tmp115 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp116 *jrt.Boolean; jrt.Boolean_Init(); tmp116 = jrt.Boolean_TRUE; var tmp117 any = tmp116.Ref(); A_arbace_pprint_pretty_writer__init_A_const_121 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp115, tmp117, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(293).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_122 = lang.RT_Var_String_String__Var(Lit_2, Lit_100); var tmp118 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp119 *jrt.Boolean; jrt.Boolean_Init(); tmp119 = jrt.Boolean_TRUE; var tmp120 any = tmp119.Ref(); A_arbace_pprint_pretty_writer__init_A_const_123 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp118, tmp120, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(306).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_124 = lang.RT_Var_String_String__Var(Lit_2, Lit_102); var tmp121 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp122 *jrt.Boolean; jrt.Boolean_Init(); tmp122 = jrt.Boolean_TRUE; var tmp123 any = tmp122.Ref(); A_arbace_pprint_pretty_writer__init_A_const_125 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp121, tmp123, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(314).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_126 = lang.RT_Var_String_String__Var(Lit_2, Lit_103); var tmp124 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp125 *jrt.Boolean; jrt.Boolean_Init(); tmp125 = jrt.Boolean_TRUE; var tmp126 any = tmp125.Ref(); A_arbace_pprint_pretty_writer__init_A_const_127 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp124, tmp126, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(321).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_128 = lang.RT_Var_String_String__Var(Lit_2, Lit_104); var tmp127 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp128 *jrt.Boolean; jrt.Boolean_Init(); tmp128 = jrt.Boolean_TRUE; var tmp129 any = tmp128.Ref(); A_arbace_pprint_pretty_writer__init_A_const_129 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp127, tmp129, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_105)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(330).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_130 = lang.RT_Var_String_String__Var(Lit_2, Lit_107); var tmp130 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp131 *jrt.Boolean; jrt.Boolean_Init(); tmp131 = jrt.Boolean_TRUE; var tmp132 any = tmp131.Ref(); A_arbace_pprint_pretty_writer__init_A_const_131 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp130, tmp132, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_132 = lang.RT_Var_String_String__Var(Lit_2, Lit_110); var tmp133 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp134 *jrt.Boolean; jrt.Boolean_Init(); tmp134 = jrt.Boolean_TRUE; var tmp135 any = tmp134.Ref(); A_arbace_pprint_pretty_writer__init_A_const_133 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp133, tmp135, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_113).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(373).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_134 = lang.RT_Var_String_String__Var(Lit_0, Lit_114); A_arbace_pprint_pretty_writer__init_A_const_135 = lang.RT_ClassForNameNonLoading_String__Class(Lit_115); A_arbace_pprint_pretty_writer__init_A_const_136 = lang.RT_ClassForNameNonLoading_String__Class(Lit_116); A_arbace_pprint_pretty_writer__init_A_const_137 = lang.RT_ClassForNameNonLoading_String__Class(Lit_117); A_arbace_pprint_pretty_writer__init_A_const_138 = lang.RT_Var_String_String__Var(Lit_2, Lit_118); var tmp136 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp137 *jrt.Boolean; jrt.Boolean_Init(); tmp137 = jrt.Boolean_TRUE; var tmp138 any = tmp137.Ref(); A_arbace_pprint_pretty_writer__init_A_const_139 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp136, tmp138, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_35)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(435).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_140 = lang.RT_Var_String_String__Var(Lit_2, Lit_119); var tmp139 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp140 *jrt.Boolean; jrt.Boolean_Init(); tmp140 = jrt.Boolean_TRUE; var tmp141 any = tmp140.Ref(); A_arbace_pprint_pretty_writer__init_A_const_141 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp139, tmp141, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(457).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_142 = lang.RT_Var_String_String__Var(Lit_2, Lit_94); var tmp142 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp143 *jrt.Boolean; jrt.Boolean_Init(); tmp143 = jrt.Boolean_TRUE; var tmp144 any = tmp143.Ref(); A_arbace_pprint_pretty_writer__init_A_const_143 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp142, tmp144, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_54).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(473).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_144 = lang.RT_Var_String_String__Var(Lit_2, Lit_30); var tmp145 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp146 *jrt.Boolean; jrt.Boolean_Init(); tmp146 = jrt.Boolean_TRUE; var tmp147 any = tmp146.Ref(); A_arbace_pprint_pretty_writer__init_A_const_145 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp145, tmp147, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_64).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(479).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); var tmp148 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp149 *jrt.Boolean; jrt.Boolean_Init(); tmp149 = jrt.Boolean_TRUE; var tmp150 any = tmp149.Ref(); A_arbace_pprint_pretty_writer__init_A_const_146 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp148, tmp150, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(492).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_147 = lang.RT_Var_String_String__Var(Lit_2, Lit_120); var tmp151 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp152 *jrt.Boolean; jrt.Boolean_Init(); tmp152 = jrt.Boolean_TRUE; var tmp153 any = tmp152.Ref(); A_arbace_pprint_pretty_writer__init_A_const_148 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp151, tmp153, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(495).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)); A_arbace_pprint_pretty_writer__init_A_const_149 = lang.RT_Var_String_String__Var(Lit_2, Lit_122); var tmp154 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(); var tmp155 *jrt.Boolean; jrt.Boolean_Init(); tmp155 = jrt.Boolean_TRUE; var tmp156 any = tmp155.Ref(); A_arbace_pprint_pretty_writer__init_A_const_150 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp154, tmp156, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(498).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8)) }

func A_arbace_pprint_pretty_writer__init_A_New() *A_arbace_pprint_pretty_writer__init_A { A_arbace_pprint_pretty_writer__init_A_Init(); t := &A_arbace_pprint_pretty_writer__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_pretty_writer__init_A) Ctor() {}

func (t *A_arbace_pprint_pretty_writer__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_pretty_writer__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_pretty_writer__init_A_class }

func (t *A_arbace_pprint_pretty_writer__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_pretty_writer__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_pretty_writer__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_pretty_writer__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_pretty_writer__init_A); return ok }

func A_arbace_pprint_pretty_writer__init_A_Cast(x any) *A_arbace_pprint_pretty_writer__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_pretty_writer__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_pretty_writer__init_A_class)) }; return v }
