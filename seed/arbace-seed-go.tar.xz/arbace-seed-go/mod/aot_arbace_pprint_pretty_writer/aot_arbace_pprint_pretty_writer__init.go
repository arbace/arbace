//line aot_arbace_pprint_pretty_writer__init.ae:1
package aot_arbace_pprint_pretty_writer

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_pretty_writer__init_A_Load__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); A_arbace_pprint_pretty_writer__init_A_Unit0__O(); A_arbace_pprint_pretty_writer__init_A_Unit1__O(); A_arbace_pprint_pretty_writer__init_A_Unit2__O(); A_arbace_pprint_pretty_writer__init_A_Unit3__O(); A_arbace_pprint_pretty_writer__init_A_Unit4__O(); A_arbace_pprint_pretty_writer__init_A_Unit5__O(); A_arbace_pprint_pretty_writer__init_A_Unit6__O(); A_arbace_pprint_pretty_writer__init_A_Unit7__O(); A_arbace_pprint_pretty_writer__init_A_Unit8__O(); A_arbace_pprint_pretty_writer__init_A_Unit9__O(); A_arbace_pprint_pretty_writer__init_A_Unit10__O(); A_arbace_pprint_pretty_writer__init_A_Unit11__O(); A_arbace_pprint_pretty_writer__init_A_Unit12__O(); A_arbace_pprint_pretty_writer__init_A_Unit13__O(); A_arbace_pprint_pretty_writer__init_A_Unit14__O(); A_arbace_pprint_pretty_writer__init_A_Unit15__O(); A_arbace_pprint_pretty_writer__init_A_Unit16__O(); A_arbace_pprint_pretty_writer__init_A_Unit17__O(); A_arbace_pprint_pretty_writer__init_A_Unit18__O(); A_arbace_pprint_pretty_writer__init_A_Unit19__O(); A_arbace_pprint_pretty_writer__init_A_Unit20__O(); A_arbace_pprint_pretty_writer__init_A_Unit21__O(); A_arbace_pprint_pretty_writer__init_A_Unit22__O(); A_arbace_pprint_pretty_writer__init_A_Unit23__O(); A_arbace_pprint_pretty_writer__init_A_Unit24__O(); A_arbace_pprint_pretty_writer__init_A_Unit25__O(); A_arbace_pprint_pretty_writer__init_A_Unit26__O(); A_arbace_pprint_pretty_writer__init_A_Unit27__O(); A_arbace_pprint_pretty_writer__init_A_Unit28__O(); A_arbace_pprint_pretty_writer__init_A_Unit29__O(); A_arbace_pprint_pretty_writer__init_A_Unit30__O(); A_arbace_pprint_pretty_writer__init_A_Unit31__O(); A_arbace_pprint_pretty_writer__init_A_Unit32__O(); A_arbace_pprint_pretty_writer__init_A_Unit33__O(); A_arbace_pprint_pretty_writer__init_A_Unit34__O(); A_arbace_pprint_pretty_writer__init_A_Unit35__O(); A_arbace_pprint_pretty_writer__init_A_Unit36__O(); A_arbace_pprint_pretty_writer__init_A_Unit37__O(); A_arbace_pprint_pretty_writer__init_A_Unit38__O(); A_arbace_pprint_pretty_writer__init_A_Unit39__O(); A_arbace_pprint_pretty_writer__init_A_Unit40__O(); A_arbace_pprint_pretty_writer__init_A_Unit41__O(); A_arbace_pprint_pretty_writer__init_A_Unit42__O(); A_arbace_pprint_pretty_writer__init_A_Unit43__O(); A_arbace_pprint_pretty_writer__init_A_Unit44__O(); A_arbace_pprint_pretty_writer__init_A_Unit45__O(); A_arbace_pprint_pretty_writer__init_A_Unit46__O(); A_arbace_pprint_pretty_writer__init_A_Unit47__O(); A_arbace_pprint_pretty_writer__init_A_Unit48__O(); A_arbace_pprint_pretty_writer__init_A_Unit49__O(); A_arbace_pprint_pretty_writer__init_A_Unit50__O(); A_arbace_pprint_pretty_writer__init_A_Unit51__O(); A_arbace_pprint_pretty_writer__init_A_Unit52__O(); A_arbace_pprint_pretty_writer__init_A_Unit53__O(); A_arbace_pprint_pretty_writer__init_A_Unit54__O(); A_arbace_pprint_pretty_writer__init_A_Unit55__O(); A_arbace_pprint_pretty_writer__init_A_Unit56__O(); A_arbace_pprint_pretty_writer__init_A_Unit57__O(); A_arbace_pprint_pretty_writer__init_A_Unit58__O(); A_arbace_pprint_pretty_writer__init_A_Unit59__O(); A_arbace_pprint_pretty_writer__init_A_Unit60__O(); A_arbace_pprint_pretty_writer__init_A_Unit61__O(); A_arbace_pprint_pretty_writer__init_A_Unit62__O(); A_arbace_pprint_pretty_writer__init_A_Unit63__O(); A_arbace_pprint_pretty_writer__init_A_Unit64__O(); A_arbace_pprint_pretty_writer__init_A_Unit65__O(); A_arbace_pprint_pretty_writer__init_A_Unit66__O(); A_arbace_pprint_pretty_writer__init_A_Unit67__O(); A_arbace_pprint_pretty_writer__init_A_Unit68__O(); A_arbace_pprint_pretty_writer__init_A_Unit69__O(); A_arbace_pprint_pretty_writer__init_A_Unit70__O(); A_arbace_pprint_pretty_writer__init_A_Unit71__O(); A_arbace_pprint_pretty_writer__init_A_Unit72__O(); A_arbace_pprint_pretty_writer__init_A_Unit73__O(); A_arbace_pprint_pretty_writer__init_A_Unit74__O(); A_arbace_pprint_pretty_writer__init_A_Unit75__O(); A_arbace_pprint_pretty_writer__init_A_Unit76__O(); A_arbace_pprint_pretty_writer__init_A_Unit77__O(); A_arbace_pprint_pretty_writer__init_A_Unit78__O(); A_arbace_pprint_pretty_writer__init_A_Unit79__O(); A_arbace_pprint_pretty_writer__init_A_Unit80__O(); A_arbace_pprint_pretty_writer__init_A_Unit81__O(); return nil }












func A_arbace_pprint_pretty_writer__init_A_Unit0__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); return lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pretty_writer__init_A_const_1) }

func A_arbace_pprint_pretty_writer__init_A_Unit1__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1)); return nil }
//line :20:1
func A_arbace_pprint_pretty_writer__init_A_Unit2__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_2)); return nil }








func A_arbace_pprint_pretty_writer__init_A_Unit3__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_3)); return A_arbace_pprint_pretty_writer__init_A_const_2 }






func A_arbace_pprint_pretty_writer__init_A_Unit4__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_4; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_getf_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_getf_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); aot_arbace_pprint.A_arbace_pprint_getf_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_5)); return A_arbace_pprint_pretty_writer__init_A_const_4 }
//line :36:1
func A_arbace_pprint_pretty_writer__init_A_Unit5__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); A_arbace_pprint_pretty_writer__init_A_const_4.SetMacro__V(); return nil }
//line :36:1
func A_arbace_pprint_pretty_writer__init_A_Unit6__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); return A_arbace_pprint_pretty_writer__init_A_const_4 }





func A_arbace_pprint_pretty_writer__init_A_Unit7__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_6; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_setf_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_setf_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); aot_arbace_pprint.A_arbace_pprint_setf_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_7)); return A_arbace_pprint_pretty_writer__init_A_const_6 }
//line :42:1
func A_arbace_pprint_pretty_writer__init_A_Unit8__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); A_arbace_pprint_pretty_writer__init_A_const_6.SetMacro__V(); return nil }
//line :42:1
func A_arbace_pprint_pretty_writer__init_A_Unit9__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); return A_arbace_pprint_pretty_writer__init_A_const_6 }





func A_arbace_pprint_pretty_writer__init_A_Unit10__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_8; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_deftype_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_deftype_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, true); aot_arbace_pprint.A_arbace_pprint_deftype_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_9)); return A_arbace_pprint_pretty_writer__init_A_const_8 }
//line :48:1
func A_arbace_pprint_pretty_writer__init_A_Unit11__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); A_arbace_pprint_pretty_writer__init_A_const_8.SetMacro__V(); return nil }
//line :48:1
func A_arbace_pprint_pretty_writer__init_A_Unit12__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_pprint_pretty_writer__init_A_const_8 }









func A_arbace_pprint_pretty_writer__init_A_Unit13__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_10; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_to_base_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_to_base_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, true); aot_arbace_pprint.A_arbace_pprint_write_to_base_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_11)); return A_arbace_pprint_pretty_writer__init_A_const_10 }
//line :58:1
func A_arbace_pprint_pretty_writer__init_A_Unit14__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); A_arbace_pprint_pretty_writer__init_A_const_10.SetMacro__V(); return nil }
//line :58:1
func A_arbace_pprint_pretty_writer__init_A_Unit15__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); return A_arbace_pprint_pretty_writer__init_A_const_10 }











func A_arbace_pprint_pretty_writer__init_A_Unit16__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_12; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_15, A_arbace_pprint_pretty_writer__init_A_const_16, A_arbace_pprint_pretty_writer__init_A_const_17, A_arbace_pprint_pretty_writer__init_A_const_18, A_arbace_pprint_pretty_writer__init_A_const_19, A_arbace_pprint_pretty_writer__init_A_const_20, A_arbace_pprint_pretty_writer__init_A_const_21, A_arbace_pprint_pretty_writer__init_A_const_22, A_arbace_pprint_pretty_writer__init_A_const_23, A_arbace_pprint_pretty_writer__init_A_const_24)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_14)); return A_arbace_pprint_pretty_writer__init_A_const_12 }





func A_arbace_pprint_pretty_writer__init_A_Unit17__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_25; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); aot_arbace_pprint.A_arbace_pprint_ancestor_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_26)); return A_arbace_pprint_pretty_writer__init_A_const_25 }






func A_arbace_pprint_pretty_writer__init_A_Unit18__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_27; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pretty_writer__init_A_const_15)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_27; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_28)); return A_arbace_pprint_pretty_writer__init_A_const_27 }

func A_arbace_pprint_pretty_writer__init_A_Unit19__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_29; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_buffer_length_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_buffer_length_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); aot_arbace_pprint.A_arbace_pprint_buffer_length_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_30)); return A_arbace_pprint_pretty_writer__init_A_const_29 }






func A_arbace_pprint_pretty_writer__init_A_Unit20__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_31; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33, A_arbace_pprint_pretty_writer__init_A_const_34, A_arbace_pprint_pretty_writer__init_A_const_35, A_arbace_pprint_pretty_writer__init_A_const_36, A_arbace_pprint_pretty_writer__init_A_const_37)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_31; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_32)); return A_arbace_pprint_pretty_writer__init_A_const_31 }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit21__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_31; var tmp3 any = A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit22__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_41; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, true); aot_arbace_pprint.A_arbace_pprint_make_buffer_blob_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_42)); return A_arbace_pprint_pretty_writer__init_A_const_41 }
//line :92:1
func A_arbace_pprint_pretty_writer__init_A_Unit23__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_43; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); aot_arbace_pprint.A_arbace_pprint_buffer_blob_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_44)); return A_arbace_pprint_pretty_writer__init_A_const_43 }


func A_arbace_pprint_pretty_writer__init_A_Unit24__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_45; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33, A_arbace_pprint_pretty_writer__init_A_const_47, A_arbace_pprint_pretty_writer__init_A_const_48, A_arbace_pprint_pretty_writer__init_A_const_36, A_arbace_pprint_pretty_writer__init_A_const_37)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_45; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_46)); return A_arbace_pprint_pretty_writer__init_A_const_45 }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit25__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_45; var tmp3 any = A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit26__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_49; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, true); aot_arbace_pprint.A_arbace_pprint_make_nl_t_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_50)); return A_arbace_pprint_pretty_writer__init_A_const_49 }
//line :95:1
func A_arbace_pprint_pretty_writer__init_A_Unit27__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_51; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); aot_arbace_pprint.A_arbace_pprint_nl_t_QMARK__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_52)); return A_arbace_pprint_pretty_writer__init_A_const_51 }

func A_arbace_pprint_pretty_writer__init_A_Unit28__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_53; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33, A_arbace_pprint_pretty_writer__init_A_const_48, A_arbace_pprint_pretty_writer__init_A_const_36, A_arbace_pprint_pretty_writer__init_A_const_37)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_53; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_54)); return A_arbace_pprint_pretty_writer__init_A_const_53 }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit29__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_53; var tmp3 any = A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit30__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_55; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, true); aot_arbace_pprint.A_arbace_pprint_make_start_block_t_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_56)); return A_arbace_pprint_pretty_writer__init_A_const_55 }
//line :97:1
func A_arbace_pprint_pretty_writer__init_A_Unit31__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_57; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); aot_arbace_pprint.A_arbace_pprint_start_block_t_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_58)); return A_arbace_pprint_pretty_writer__init_A_const_57 }

func A_arbace_pprint_pretty_writer__init_A_Unit32__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_59; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33, A_arbace_pprint_pretty_writer__init_A_const_48, A_arbace_pprint_pretty_writer__init_A_const_36, A_arbace_pprint_pretty_writer__init_A_const_37)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_59; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_60)); return A_arbace_pprint_pretty_writer__init_A_const_59 }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit33__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_59; var tmp3 any = A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit34__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_61; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, true); aot_arbace_pprint.A_arbace_pprint_make_end_block_t_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_62)); return A_arbace_pprint_pretty_writer__init_A_const_61 }
//line :99:1
func A_arbace_pprint_pretty_writer__init_A_Unit35__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_63; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); aot_arbace_pprint.A_arbace_pprint_end_block_t_QMARK__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_64)); return A_arbace_pprint_pretty_writer__init_A_const_63 }

func A_arbace_pprint_pretty_writer__init_A_Unit36__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_65; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_pprint_pretty_writer__init_A_const_33, A_arbace_pprint_pretty_writer__init_A_const_48, A_arbace_pprint_pretty_writer__init_A_const_67, A_arbace_pprint_pretty_writer__init_A_const_68, A_arbace_pprint_pretty_writer__init_A_const_36, A_arbace_pprint_pretty_writer__init_A_const_37)); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_65; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_66)); return A_arbace_pprint_pretty_writer__init_A_const_65 }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit37__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_65; var tmp3 any = A_arbace_pprint_pretty_writer__init_A_const_39.GetRawRoot__O(); var tmp4 any = A_arbace_pprint_pretty_writer__init_A_const_40; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()) }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit38__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_69; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, true); aot_arbace_pprint.A_arbace_pprint_make_indent_t_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_70)); return A_arbace_pprint_pretty_writer__init_A_const_69 }
//line :101:1
func A_arbace_pprint_pretty_writer__init_A_Unit39__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_71; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); aot_arbace_pprint.A_arbace_pprint_indent_t_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_72)); return A_arbace_pprint_pretty_writer__init_A_const_71 }





func A_arbace_pprint_pretty_writer__init_A_Unit40__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_73; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_74.GetRawRoot__O()); var tmp3 any = aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_New(); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); aot_arbace_pprint.A_arbace_pprint_fn__1820000051_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; tmp1.BindRoot_O__V(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_73; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_75)); return A_arbace_pprint_pretty_writer__init_A_const_73 }

func A_arbace_pprint_pretty_writer__init_A_Unit41__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_77)); return A_arbace_pprint_pretty_writer__init_A_const_76 }

func A_arbace_pprint_pretty_writer__init_A_Unit42__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_79)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_78; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_83)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_78; var tmp5 *jrt.String = Lit_20; var tmp6 any = aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_New(); var tmp7 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); aot_arbace_pprint.A_arbace_pprint_eval1820000055_fn__1820000056_A_fn_class = fncls__18d; tmp7 = fncls__18d } else { tmp7 = fncls__18 }; var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_78 } }
func A_arbace_pprint_pretty_writer__init_A_Unit43__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(112, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_84; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_New(); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); aot_arbace_pprint.A_arbace_pprint_eval1820000059_fn__1820000060_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }









func A_arbace_pprint_pretty_writer__init_A_Unit44__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_85; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_New(); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); aot_arbace_pprint.A_arbace_pprint_eval1820000065_fn__1820000066_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_pprint_pretty_writer__init_A_Unit45__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(127, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_86; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_New(); var tmp4 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); aot_arbace_pprint.A_arbace_pprint_eval1820000069_fn__1820000070_A_fn_class = fncls__21d; tmp4 = fncls__21d } else { tmp4 = fncls__21 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_pprint_pretty_writer__init_A_Unit46__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(135, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_87; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_New(); var tmp4 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); aot_arbace_pprint.A_arbace_pprint_eval1820000075_fn__1820000076_A_fn_class = fncls__22d; tmp4 = fncls__22d } else { tmp4 = fncls__22 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_pprint_pretty_writer__init_A_Unit47__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_88; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_New(); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); aot_arbace_pprint.A_arbace_pprint_eval1820000079_fn__1820000080_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_pprint_pretty_writer__init_A_Unit48__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(149, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_89; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_tokens_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_tokens_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); aot_arbace_pprint.A_arbace_pprint_write_tokens_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_90)); return A_arbace_pprint_pretty_writer__init_A_const_89 }
















func A_arbace_pprint_pretty_writer__init_A_Unit49__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_91; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); aot_arbace_pprint.A_arbace_pprint_tokens_fit_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_92)); return A_arbace_pprint_pretty_writer__init_A_const_91 }






func A_arbace_pprint_pretty_writer__init_A_Unit50__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_93; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); aot_arbace_pprint.A_arbace_pprint_linear_nl_QMARK__A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_94)); return A_arbace_pprint_pretty_writer__init_A_const_93 }




func A_arbace_pprint_pretty_writer__init_A_Unit51__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_95; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); aot_arbace_pprint.A_arbace_pprint_miser_nl_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_96)); return A_arbace_pprint_pretty_writer__init_A_const_95 }






func A_arbace_pprint_pretty_writer__init_A_Unit52__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_98)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_97; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_99)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_97; var tmp5 *jrt.String = Lit_31; var tmp6 any = aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_New(); var tmp7 *jrt.Class; var fncls__28 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); aot_arbace_pprint.A_arbace_pprint_eval1820000093_fn__1820000094_A_fn_class = fncls__28d; tmp7 = fncls__28d } else { tmp7 = fncls__28 }; var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_97 } }

func A_arbace_pprint_pretty_writer__init_A_Unit53__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(187, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_100; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_New(); var tmp4 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); aot_arbace_pprint.A_arbace_pprint_eval1820000097_fn__1820000098_A_fn_class = fncls__29d; tmp4 = fncls__29d } else { tmp4 = fncls__29 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_pprint_pretty_writer__init_A_Unit54__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(191, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_101; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_New(); var tmp4 *jrt.Class; var fncls__30 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); aot_arbace_pprint.A_arbace_pprint_eval1820000101_fn__1820000102_A_fn_class = fncls__30d; tmp4 = fncls__30d } else { tmp4 = fncls__30 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_pprint_pretty_writer__init_A_Unit55__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(195, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_102; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_New(); var tmp4 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); aot_arbace_pprint.A_arbace_pprint_eval1820000105_fn__1820000106_A_fn_class = fncls__31d; tmp4 = fncls__31d } else { tmp4 = fncls__31 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_pprint_pretty_writer__init_A_Unit56__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_97.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_103; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_New(); var tmp4 *jrt.Class; var fncls__32 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); aot_arbace_pprint.A_arbace_pprint_eval1820000109_fn__1820000110_A_fn_class = fncls__32d; tmp4 = fncls__32d } else { tmp4 = fncls__32 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_pprint_pretty_writer__init_A_Unit57__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(208, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_104; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_section_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_section_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); aot_arbace_pprint.A_arbace_pprint_get_section_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_105)); return A_arbace_pprint_pretty_writer__init_A_const_104 }






func A_arbace_pprint_pretty_writer__init_A_Unit58__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(215, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_106; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); aot_arbace_pprint.A_arbace_pprint_get_sub_section_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_107)); return A_arbace_pprint_pretty_writer__init_A_const_106 }







func A_arbace_pprint_pretty_writer__init_A_Unit59__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(223, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_108; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); aot_arbace_pprint.A_arbace_pprint_update_nl_state_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_109)); return A_arbace_pprint_pretty_writer__init_A_const_108 }









func A_arbace_pprint_pretty_writer__init_A_Unit60__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(233, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_emit_nl_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_emit_nl_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); aot_arbace_pprint.A_arbace_pprint_emit_nl_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_110)); return A_arbace_pprint_pretty_writer__init_A_const_76 }











func A_arbace_pprint_pretty_writer__init_A_Unit61__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(245, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_111; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); aot_arbace_pprint.A_arbace_pprint_split_at_newline_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_112)); return A_arbace_pprint_pretty_writer__init_A_const_111 }





func A_arbace_pprint_pretty_writer__init_A_Unit62__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(251, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_114)); v__1927000386__auto____1 = A_arbace_pprint_pretty_writer__init_A_const_113; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_80.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_115)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_113; var tmp5 *jrt.String = Lit_42; var tmp6 lang.IFn = A_arbace_pprint_pretty_writer__init_A_const_33; var tmp7 any = A_arbace_pprint_pretty_writer__init_A_const_81; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, A_arbace_pprint_pretty_writer__init_A_const_82)); return A_arbace_pprint_pretty_writer__init_A_const_113 } }
func A_arbace_pprint_pretty_writer__init_A_Unit63__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(252, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_88; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_New(); var tmp4 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); aot_arbace_pprint.A_arbace_pprint_eval1820000133_fn__1820000134_A_fn_class = fncls__38d; tmp4 = fncls__38d } else { tmp4 = fncls__38 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit64__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(254, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_87; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_New(); var tmp4 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); aot_arbace_pprint.A_arbace_pprint_eval1820000137_fn__1820000138_A_fn_class = fncls__39d; tmp4 = fncls__39d } else { tmp4 = fncls__39 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit65__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(256, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_113.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_pretty_writer__init_A_const_81; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_New(); var tmp4 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); aot_arbace_pprint.A_arbace_pprint_eval1820000141_fn__1820000142_A_fn_class = fncls__40d; tmp4 = fncls__40d } else { tmp4 = fncls__40 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_pprint_pretty_writer__init_A_Unit66__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(258, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_116; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_toks_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_toks_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); aot_arbace_pprint.A_arbace_pprint_toks_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_117)); return A_arbace_pprint_pretty_writer__init_A_const_116 }




func A_arbace_pprint_pretty_writer__init_A_Unit67__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(263, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_118; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_token_string_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_token_string_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); aot_arbace_pprint.A_arbace_pprint_write_token_string_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_119)); return A_arbace_pprint_pretty_writer__init_A_const_118 }





























func A_arbace_pprint_pretty_writer__init_A_Unit68__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(293, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_120; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_line_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_line_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); aot_arbace_pprint.A_arbace_pprint_write_line_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_121)); return A_arbace_pprint_pretty_writer__init_A_const_120 }












func A_arbace_pprint_pretty_writer__init_A_Unit69__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(306, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_122; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); aot_arbace_pprint.A_arbace_pprint_add_to_buffer_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_123)); return A_arbace_pprint_pretty_writer__init_A_const_122 }







func A_arbace_pprint_pretty_writer__init_A_Unit70__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_124; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); aot_arbace_pprint.A_arbace_pprint_write_buffered_output_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_125)); return A_arbace_pprint_pretty_writer__init_A_const_124 }






func A_arbace_pprint_pretty_writer__init_A_Unit71__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(321, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_126; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_white_space_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_white_space_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); aot_arbace_pprint.A_arbace_pprint_write_white_space_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_127)); return A_arbace_pprint_pretty_writer__init_A_const_126 }








func A_arbace_pprint_pretty_writer__init_A_Unit72__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(330, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_128; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); aot_arbace_pprint.A_arbace_pprint_write_initial_lines_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_129)); return A_arbace_pprint_pretty_writer__init_A_const_128 }

























func A_arbace_pprint_pretty_writer__init_A_Unit73__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(356, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_130; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_p_write_char_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_p_write_char_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); aot_arbace_pprint.A_arbace_pprint_p_write_char_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_131)); return A_arbace_pprint_pretty_writer__init_A_const_130 }
















func A_arbace_pprint_pretty_writer__init_A_Unit74__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(373, 1); var tmp1 any = A_arbace_pprint_pretty_writer__init_A_const_135; lang.IFn_Cast(A_arbace_pprint_pretty_writer__init_A_const_134.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq(tmp1, lang.RT_Seq_O__ISeq(jrt.RefArrayOf(jrt.Object_class, A_arbace_pprint_pretty_writer__init_A_const_136, A_arbace_pprint_pretty_writer__init_A_const_137)))); var tmp2 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_132; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_New(); var tmp4 *jrt.Class; var fncls__49 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); aot_arbace_pprint.A_arbace_pprint_pretty_writer_A_fn_class = fncls__49d; tmp4 = fncls__49d } else { tmp4 = fncls__49 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_132; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_133)); return A_arbace_pprint_pretty_writer__init_A_const_132 }





























































func A_arbace_pprint_pretty_writer__init_A_Unit75__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(435, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_138; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_start_block_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_start_block_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); aot_arbace_pprint.A_arbace_pprint_start_block_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_139)); return A_arbace_pprint_pretty_writer__init_A_const_138 }





















func A_arbace_pprint_pretty_writer__init_A_Unit76__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(457, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_140; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_end_block_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_end_block_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); aot_arbace_pprint.A_arbace_pprint_end_block_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_141)); return A_arbace_pprint_pretty_writer__init_A_const_140 }















func A_arbace_pprint_pretty_writer__init_A_Unit77__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(473, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_142; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_nl_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_nl_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); aot_arbace_pprint.A_arbace_pprint_nl_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_143)); return A_arbace_pprint_pretty_writer__init_A_const_142 }





func A_arbace_pprint_pretty_writer__init_A_Unit78__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(479, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_144; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_indent_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_indent_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); aot_arbace_pprint.A_arbace_pprint_indent_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_145)); return A_arbace_pprint_pretty_writer__init_A_const_144 }












func A_arbace_pprint_pretty_writer__init_A_Unit79__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(492, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); aot_arbace_pprint.A_arbace_pprint_get_miser_width_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_146)); return A_arbace_pprint_pretty_writer__init_A_const_2 }


func A_arbace_pprint_pretty_writer__init_A_Unit80__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(495, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_147; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); aot_arbace_pprint.A_arbace_pprint_set_miser_width_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_148)); return A_arbace_pprint_pretty_writer__init_A_const_147 }


func A_arbace_pprint_pretty_writer__init_A_Unit81__O() any { A_arbace_pprint_pretty_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(498, 1); var tmp1 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_149; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); aot_arbace_pprint.A_arbace_pprint_set_logical_block_callback_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pretty_writer__init_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pretty_writer__init_A_const_150)); return A_arbace_pprint_pretty_writer__init_A_const_149 }



type A_arbace_pprint_pretty_writer__init_A struct{ jrt.Object }

var A_arbace_pprint_pretty_writer__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_pretty_writer__init_A_const_0 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_1 any

var A_arbace_pprint_pretty_writer__init_A_const_2 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_3 any

var A_arbace_pprint_pretty_writer__init_A_const_4 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_5 any

var A_arbace_pprint_pretty_writer__init_A_const_6 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_7 any

var A_arbace_pprint_pretty_writer__init_A_const_8 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_9 any

var A_arbace_pprint_pretty_writer__init_A_const_10 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_11 any

var A_arbace_pprint_pretty_writer__init_A_const_12 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_13 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_14 any

var A_arbace_pprint_pretty_writer__init_A_const_15 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_16 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_17 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_18 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_19 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_20 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_21 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_22 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_23 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_24 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_25 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_26 any

var A_arbace_pprint_pretty_writer__init_A_const_27 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_28 any

var A_arbace_pprint_pretty_writer__init_A_const_29 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_30 any

var A_arbace_pprint_pretty_writer__init_A_const_31 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_32 any

var A_arbace_pprint_pretty_writer__init_A_const_33 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_34 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_35 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_36 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_37 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_38 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_39 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_40 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_41 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_42 any

var A_arbace_pprint_pretty_writer__init_A_const_43 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_44 any

var A_arbace_pprint_pretty_writer__init_A_const_45 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_46 any

var A_arbace_pprint_pretty_writer__init_A_const_47 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_48 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_49 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_50 any

var A_arbace_pprint_pretty_writer__init_A_const_51 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_52 any

var A_arbace_pprint_pretty_writer__init_A_const_53 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_54 any

var A_arbace_pprint_pretty_writer__init_A_const_55 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_56 any

var A_arbace_pprint_pretty_writer__init_A_const_57 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_58 any

var A_arbace_pprint_pretty_writer__init_A_const_59 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_60 any

var A_arbace_pprint_pretty_writer__init_A_const_61 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_62 any

var A_arbace_pprint_pretty_writer__init_A_const_63 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_64 any

var A_arbace_pprint_pretty_writer__init_A_const_65 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_66 any

var A_arbace_pprint_pretty_writer__init_A_const_67 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_68 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_69 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_70 any

var A_arbace_pprint_pretty_writer__init_A_const_71 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_72 any

var A_arbace_pprint_pretty_writer__init_A_const_73 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_74 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_75 any

var A_arbace_pprint_pretty_writer__init_A_const_76 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_77 any

var A_arbace_pprint_pretty_writer__init_A_const_78 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_79 any

var A_arbace_pprint_pretty_writer__init_A_const_80 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_81 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_82 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_83 any

var A_arbace_pprint_pretty_writer__init_A_const_84 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_85 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_86 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_87 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_88 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_89 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_90 any

var A_arbace_pprint_pretty_writer__init_A_const_91 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_92 any

var A_arbace_pprint_pretty_writer__init_A_const_93 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_94 any

var A_arbace_pprint_pretty_writer__init_A_const_95 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_96 any

var A_arbace_pprint_pretty_writer__init_A_const_97 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_98 any

var A_arbace_pprint_pretty_writer__init_A_const_99 any

var A_arbace_pprint_pretty_writer__init_A_const_100 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_101 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_102 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_103 *lang.Keyword

var A_arbace_pprint_pretty_writer__init_A_const_104 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_105 any

var A_arbace_pprint_pretty_writer__init_A_const_106 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_107 any

var A_arbace_pprint_pretty_writer__init_A_const_108 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_109 any

var A_arbace_pprint_pretty_writer__init_A_const_110 any

var A_arbace_pprint_pretty_writer__init_A_const_111 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_112 any

var A_arbace_pprint_pretty_writer__init_A_const_113 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_114 any

var A_arbace_pprint_pretty_writer__init_A_const_115 any

var A_arbace_pprint_pretty_writer__init_A_const_116 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_117 any

var A_arbace_pprint_pretty_writer__init_A_const_118 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_119 any

var A_arbace_pprint_pretty_writer__init_A_const_120 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_121 any

var A_arbace_pprint_pretty_writer__init_A_const_122 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_123 any

var A_arbace_pprint_pretty_writer__init_A_const_124 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_125 any

var A_arbace_pprint_pretty_writer__init_A_const_126 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_127 any

var A_arbace_pprint_pretty_writer__init_A_const_128 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_129 any

var A_arbace_pprint_pretty_writer__init_A_const_130 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_131 any

var A_arbace_pprint_pretty_writer__init_A_const_132 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_133 any

var A_arbace_pprint_pretty_writer__init_A_const_134 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_135 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_136 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_137 *jrt.Class

var A_arbace_pprint_pretty_writer__init_A_const_138 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_139 any

var A_arbace_pprint_pretty_writer__init_A_const_140 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_141 any

var A_arbace_pprint_pretty_writer__init_A_const_142 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_143 any

var A_arbace_pprint_pretty_writer__init_A_const_144 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_145 any

var A_arbace_pprint_pretty_writer__init_A_const_146 any

var A_arbace_pprint_pretty_writer__init_A_const_147 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_148 any

var A_arbace_pprint_pretty_writer__init_A_const_149 *lang.Var

var A_arbace_pprint_pretty_writer__init_A_const_150 any

var A_arbace_pprint_pretty_writer__init_A_init jrt.ClassInit

func A_arbace_pprint_pretty_writer__init_A_Init() { if !A_arbace_pprint_pretty_writer__init_A_init.Done() { A_arbace_pprint_pretty_writer__init_A_init.Run(A_arbace_pprint_pretty_writer__init_A_clinit) } }

func A_arbace_pprint_pretty_writer__init_A_clinit() { A_arbace_pprint_pretty_writer__init_A_clinit_p0(); A_arbace_pprint_pretty_writer__init_A_clinit_p1(); A_arbace_pprint_pretty_writer__init_A_clinit_p2(); A_arbace_pprint_pretty_writer__init_A_clinit_p3(); A_arbace_pprint_pretty_writer__init_A_clinit_p4(); A_arbace_pprint_pretty_writer__init_A_clinit_p5(); A_arbace_pprint_pretty_writer__init_A_clinit_p6(); A_arbace_pprint_pretty_writer__init_A_clinit_p7(); A_arbace_pprint_pretty_writer__init_A_clinit_p8(); A_arbace_pprint_pretty_writer__init_A_clinit_p9(); A_arbace_pprint_pretty_writer__init_A_clinit_p10(); A_arbace_pprint_pretty_writer__init_A_clinit_p11() }

func A_arbace_pprint_pretty_writer__init_A_clinit_p0() { A_arbace_pprint_pretty_writer__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 220); A_arbace_pprint_pretty_writer__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[69]); A_arbace_pprint_pretty_writer__init_A_const_1 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[70]; A_arbace_pprint_pretty_writer__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[71]); A_arbace_pprint_pretty_writer__init_A_const_3 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[72]; A_arbace_pprint_pretty_writer__init_A_const_4 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[73]); A_arbace_pprint_pretty_writer__init_A_const_5 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[74]; A_arbace_pprint_pretty_writer__init_A_const_6 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[75]); A_arbace_pprint_pretty_writer__init_A_const_7 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[76]; A_arbace_pprint_pretty_writer__init_A_const_8 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[77]); A_arbace_pprint_pretty_writer__init_A_const_9 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[78]; A_arbace_pprint_pretty_writer__init_A_const_10 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[79]); A_arbace_pprint_pretty_writer__init_A_const_11 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[80]; A_arbace_pprint_pretty_writer__init_A_const_12 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[81]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p1() { A_arbace_pprint_pretty_writer__init_A_const_13 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[82]); A_arbace_pprint_pretty_writer__init_A_const_14 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[83]; A_arbace_pprint_pretty_writer__init_A_const_15 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[84]); A_arbace_pprint_pretty_writer__init_A_const_16 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[85]); A_arbace_pprint_pretty_writer__init_A_const_17 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[86]); A_arbace_pprint_pretty_writer__init_A_const_18 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[87]); A_arbace_pprint_pretty_writer__init_A_const_19 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[88]); A_arbace_pprint_pretty_writer__init_A_const_20 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[89]); A_arbace_pprint_pretty_writer__init_A_const_21 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[90]); A_arbace_pprint_pretty_writer__init_A_const_22 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[91]); A_arbace_pprint_pretty_writer__init_A_const_23 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[92]); A_arbace_pprint_pretty_writer__init_A_const_24 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[93]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p2() { A_arbace_pprint_pretty_writer__init_A_const_25 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[94]); A_arbace_pprint_pretty_writer__init_A_const_26 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[95]; A_arbace_pprint_pretty_writer__init_A_const_27 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[96]); A_arbace_pprint_pretty_writer__init_A_const_28 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[97]; A_arbace_pprint_pretty_writer__init_A_const_29 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[98]); A_arbace_pprint_pretty_writer__init_A_const_30 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[99]; A_arbace_pprint_pretty_writer__init_A_const_31 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[100]); A_arbace_pprint_pretty_writer__init_A_const_32 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[101]; A_arbace_pprint_pretty_writer__init_A_const_33 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[102]); A_arbace_pprint_pretty_writer__init_A_const_34 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[103]); A_arbace_pprint_pretty_writer__init_A_const_35 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[104]); A_arbace_pprint_pretty_writer__init_A_const_36 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[105]); A_arbace_pprint_pretty_writer__init_A_const_37 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[106]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p3() { A_arbace_pprint_pretty_writer__init_A_const_38 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[107]); A_arbace_pprint_pretty_writer__init_A_const_39 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[108]); A_arbace_pprint_pretty_writer__init_A_const_40 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[109]); A_arbace_pprint_pretty_writer__init_A_const_41 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[110]); A_arbace_pprint_pretty_writer__init_A_const_42 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[111]; A_arbace_pprint_pretty_writer__init_A_const_43 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[112]); A_arbace_pprint_pretty_writer__init_A_const_44 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[113]; A_arbace_pprint_pretty_writer__init_A_const_45 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[114]); A_arbace_pprint_pretty_writer__init_A_const_46 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[115]; A_arbace_pprint_pretty_writer__init_A_const_47 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[116]); A_arbace_pprint_pretty_writer__init_A_const_48 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[117]); A_arbace_pprint_pretty_writer__init_A_const_49 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[118]); A_arbace_pprint_pretty_writer__init_A_const_50 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[119] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p4() { A_arbace_pprint_pretty_writer__init_A_const_51 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[120]); A_arbace_pprint_pretty_writer__init_A_const_52 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[121]; A_arbace_pprint_pretty_writer__init_A_const_53 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[122]); A_arbace_pprint_pretty_writer__init_A_const_54 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[123]; A_arbace_pprint_pretty_writer__init_A_const_55 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[124]); A_arbace_pprint_pretty_writer__init_A_const_56 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[125]; A_arbace_pprint_pretty_writer__init_A_const_57 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[126]); A_arbace_pprint_pretty_writer__init_A_const_58 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[127]; A_arbace_pprint_pretty_writer__init_A_const_59 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[128]); A_arbace_pprint_pretty_writer__init_A_const_60 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[129]; A_arbace_pprint_pretty_writer__init_A_const_61 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[130]); A_arbace_pprint_pretty_writer__init_A_const_62 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[131]; A_arbace_pprint_pretty_writer__init_A_const_63 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[132]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p5() { A_arbace_pprint_pretty_writer__init_A_const_64 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[133]; A_arbace_pprint_pretty_writer__init_A_const_65 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[134]); A_arbace_pprint_pretty_writer__init_A_const_66 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[135]; A_arbace_pprint_pretty_writer__init_A_const_67 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[136]); A_arbace_pprint_pretty_writer__init_A_const_68 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[137]); A_arbace_pprint_pretty_writer__init_A_const_69 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[138]); A_arbace_pprint_pretty_writer__init_A_const_70 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[139]; A_arbace_pprint_pretty_writer__init_A_const_71 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[140]); A_arbace_pprint_pretty_writer__init_A_const_72 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[141]; A_arbace_pprint_pretty_writer__init_A_const_73 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[142]); A_arbace_pprint_pretty_writer__init_A_const_74 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[143]); A_arbace_pprint_pretty_writer__init_A_const_75 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[144]; A_arbace_pprint_pretty_writer__init_A_const_76 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[145]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p6() { A_arbace_pprint_pretty_writer__init_A_const_77 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[146]; A_arbace_pprint_pretty_writer__init_A_const_78 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[147]); A_arbace_pprint_pretty_writer__init_A_const_79 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[148]; A_arbace_pprint_pretty_writer__init_A_const_80 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[149]); A_arbace_pprint_pretty_writer__init_A_const_81 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[150]); A_arbace_pprint_pretty_writer__init_A_const_82 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[151]); A_arbace_pprint_pretty_writer__init_A_const_83 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[152]; A_arbace_pprint_pretty_writer__init_A_const_84 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[153]); A_arbace_pprint_pretty_writer__init_A_const_85 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[154]); A_arbace_pprint_pretty_writer__init_A_const_86 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[155]); A_arbace_pprint_pretty_writer__init_A_const_87 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[156]); A_arbace_pprint_pretty_writer__init_A_const_88 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[157]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p7() { A_arbace_pprint_pretty_writer__init_A_const_89 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[158]); A_arbace_pprint_pretty_writer__init_A_const_90 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[159]; A_arbace_pprint_pretty_writer__init_A_const_91 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[160]); A_arbace_pprint_pretty_writer__init_A_const_92 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[161]; A_arbace_pprint_pretty_writer__init_A_const_93 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[162]); A_arbace_pprint_pretty_writer__init_A_const_94 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[163]; A_arbace_pprint_pretty_writer__init_A_const_95 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[164]); A_arbace_pprint_pretty_writer__init_A_const_96 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[165]; A_arbace_pprint_pretty_writer__init_A_const_97 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[166]); A_arbace_pprint_pretty_writer__init_A_const_98 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[167]; A_arbace_pprint_pretty_writer__init_A_const_99 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[168]; A_arbace_pprint_pretty_writer__init_A_const_100 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[169]); A_arbace_pprint_pretty_writer__init_A_const_101 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[170]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p8() { A_arbace_pprint_pretty_writer__init_A_const_102 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[171]); A_arbace_pprint_pretty_writer__init_A_const_103 = lang.Keyword_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[172]); A_arbace_pprint_pretty_writer__init_A_const_104 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[173]); A_arbace_pprint_pretty_writer__init_A_const_105 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[174]; A_arbace_pprint_pretty_writer__init_A_const_106 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[175]); A_arbace_pprint_pretty_writer__init_A_const_107 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[176]; A_arbace_pprint_pretty_writer__init_A_const_108 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[177]); A_arbace_pprint_pretty_writer__init_A_const_109 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[178]; A_arbace_pprint_pretty_writer__init_A_const_110 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[179]; A_arbace_pprint_pretty_writer__init_A_const_111 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[180]); A_arbace_pprint_pretty_writer__init_A_const_112 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[181]; A_arbace_pprint_pretty_writer__init_A_const_113 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[182]); A_arbace_pprint_pretty_writer__init_A_const_114 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[183] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p9() { A_arbace_pprint_pretty_writer__init_A_const_115 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[184]; A_arbace_pprint_pretty_writer__init_A_const_116 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[185]); A_arbace_pprint_pretty_writer__init_A_const_117 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[186]; A_arbace_pprint_pretty_writer__init_A_const_118 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[187]); A_arbace_pprint_pretty_writer__init_A_const_119 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[188]; A_arbace_pprint_pretty_writer__init_A_const_120 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[189]); A_arbace_pprint_pretty_writer__init_A_const_121 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[190]; A_arbace_pprint_pretty_writer__init_A_const_122 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[191]); A_arbace_pprint_pretty_writer__init_A_const_123 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[192]; A_arbace_pprint_pretty_writer__init_A_const_124 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[193]); A_arbace_pprint_pretty_writer__init_A_const_125 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[194]; A_arbace_pprint_pretty_writer__init_A_const_126 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[195]); A_arbace_pprint_pretty_writer__init_A_const_127 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[196] }

func A_arbace_pprint_pretty_writer__init_A_clinit_p10() { A_arbace_pprint_pretty_writer__init_A_const_128 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[197]); A_arbace_pprint_pretty_writer__init_A_const_129 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[198]; A_arbace_pprint_pretty_writer__init_A_const_130 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[199]); A_arbace_pprint_pretty_writer__init_A_const_131 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[200]; A_arbace_pprint_pretty_writer__init_A_const_132 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[201]); A_arbace_pprint_pretty_writer__init_A_const_133 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[202]; A_arbace_pprint_pretty_writer__init_A_const_134 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[203]); A_arbace_pprint_pretty_writer__init_A_const_135 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[204]); A_arbace_pprint_pretty_writer__init_A_const_136 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[205]); A_arbace_pprint_pretty_writer__init_A_const_137 = jrt.Class_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[206]); A_arbace_pprint_pretty_writer__init_A_const_138 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[207]); A_arbace_pprint_pretty_writer__init_A_const_139 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[208]; A_arbace_pprint_pretty_writer__init_A_const_140 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[209]) }

func A_arbace_pprint_pretty_writer__init_A_clinit_p11() { A_arbace_pprint_pretty_writer__init_A_const_141 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[210]; A_arbace_pprint_pretty_writer__init_A_const_142 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[211]); A_arbace_pprint_pretty_writer__init_A_const_143 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[212]; A_arbace_pprint_pretty_writer__init_A_const_144 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[213]); A_arbace_pprint_pretty_writer__init_A_const_145 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[214]; A_arbace_pprint_pretty_writer__init_A_const_146 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[215]; A_arbace_pprint_pretty_writer__init_A_const_147 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[216]); A_arbace_pprint_pretty_writer__init_A_const_148 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[217]; A_arbace_pprint_pretty_writer__init_A_const_149 = lang.Var_Cast(A_arbace_pprint_pretty_writer__init_A_const_pool.A[218]); A_arbace_pprint_pretty_writer__init_A_const_150 = A_arbace_pprint_pretty_writer__init_A_const_pool.A[219] }

func A_arbace_pprint_pretty_writer__init_A_New() *A_arbace_pprint_pretty_writer__init_A { A_arbace_pprint_pretty_writer__init_A_Init(); t := &A_arbace_pprint_pretty_writer__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_pretty_writer__init_A) Ctor() {}

func (t *A_arbace_pprint_pretty_writer__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_pretty_writer__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_pretty_writer__init_A_class }

func (t *A_arbace_pprint_pretty_writer__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_pretty_writer__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_pretty_writer__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_pretty_writer__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_pretty_writer__init_A); return ok }

func A_arbace_pprint_pretty_writer__init_A_Cast(x any) *A_arbace_pprint_pretty_writer__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_pretty_writer__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_pretty_writer__init_A_class)) }; return v }
