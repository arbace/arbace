//line a2g_strings.ae:1
package aot_arbace_pprint_pretty_writer

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.pprintkn8,declaredkn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn3,symkn3,docyn7,new-valyn9,type-nameyn1,&yn6,fieldsyn4,argskn6,parentkn7,sectionkn9,start-colkn6,indentkn7,done-nlkn14,intra-block-nlkn6,prefixkn15,per-line-prefixkn6,suffixkn22,logical-block-callbackyn6,parentyn5,childyn1,lkn8,type-tagkn4,datakn20,trailing-white-spacekn9,start-poskn7,end-posyn24,vals__1820000016__auto__yn21,x__1820000017__auto__kn4,typekn13,logical-blockkn11,relative-tokn6,offsetkn7,defaultkn13,start-block-tkn11,end-block-tkn8,indent-tkn11,buffer-blobkn4,nl-tkn3,tagyn6,Writeryn6,tokensyn25,force-trailing-whitespaceyn4,thisyn2,lbyn7,sectionkn6,linearkn5,miserkn4,fillkn9,mandatoryyn6,bufferyn2,nlyn4,toksyn5,tokenyn6,Stringyn7,Integeryn6,writeryn11,max-columnsyn11,miser-widthyn4,typeyn11,relative-toyn6,offsetyn15,new-miser-widthyn1,fv11,arbace.core5,in-nsR0,v13,arbace.pprint15,get-miser-widthm8,R1,TR2,i29,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint4,getfm12,R5,TR6,L1,V1,R7,R8,s77,Get the value of the field named by the argument (which should be a keyword).R2,i36,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint4,setfm12,R5,TR6,L1,V2,R7,R9,R8,s41,Set the value of the field SYM to NEW-VALR2,i42,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint7,deftypem10,R5,TR6,L1,V3,R10,R11,R12,R2,i48,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint13,write-to-basem12,R5,TR6,L1,V2,R11,R13,R8,s82,Call .write on Writer (getf :base) with proper type-hinting to\n  avoid reflection.R2,i58,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint13,logical-blockv11,arbace.core13,create-structm8,R5,TR2,i70,R3,i1,R4,s30,arbace/pprint/pretty_writer.aeR14,R15,R16,R17,R18,R19,R20,R21,R22,R23,v13,arbace.pprint9,ancestor?m10,R5,TR6,L1,V2,R24,R25,R2,i76,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint7,sectionm8,R5,TR2,i83,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint13,buffer-lengthm10,R5,TR6,L1,V1,R26,R2,i85,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint11,buffer-blobm6,R2,i92,R3,i1,R4,s30,arbace/pprint/pretty_writer.aeR27,R28,R29,R30,R31,v11,arbace.core11,alter-meta!v11,arbace.core5,assocR5,v13,arbace.pprint16,make-buffer-blobm10,R5,TR6,L1,V2,R11,R32,R2,i92,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint12,buffer-blob?m10,R5,TR6,L1,V1,R33,R2,i92,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint4,nl-tm6,R2,i95,R3,i1,R4,s30,arbace/pprint/pretty_writer.aeR34,R35,v13,arbace.pprint9,make-nl-tm10,R5,TR6,L1,V2,R11,R32,R2,i95,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint5,nl-t?m10,R5,TR6,L1,V1,R33,R2,i95,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint13,start-block-tm6,R2,i97,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint18,make-start-block-tm10,R5,TR6,L1,V2,R11,R32,R2,i97,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint14,start-block-t?m10,R5,TR6,L1,V1,R33,R2,i97,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint11,end-block-tm6,R2,i99,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint16,make-end-block-tm10,R5,TR6,L1,V2,R11,R32,R2,i99,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint12,end-block-t?m10,R5,TR6,L1,V1,R33,R2,i99,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint8,indent-tm6,R2,i101,R3,i1,R4,s30,arbace/pprint/pretty_writer.aeR36,R37,v13,arbace.pprint13,make-indent-tm10,R5,TR6,L1,V2,R11,R32,R2,i101,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint9,indent-t?m10,R5,TR6,L1,V1,R33,R2,i101,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint10,pp-newlinev11,arbace.core7,memoizem8,R5,TR2,i107,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint7,emit-nlm8,R1,TR2,i109,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint11,write-tokenm8,R5,TR2,i111,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev11,arbace.core5,derefR38,v11,arbace.core16,global-hierarchym8,R5,TR2,i111,R3,i1,R4,s30,arbace/pprint/pretty_writer.aeR39,R40,R41,R42,R43,v13,arbace.pprint12,write-tokensm10,R5,TR6,L1,V3,Myn4,thism2,R44,R45,R46,R47,R2,i149,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint11,tokens-fit?m10,R5,TR6,L1,V2,Myn4,thism2,R44,R45,R46,R2,i166,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint10,linear-nl?m10,R5,TR6,L1,V3,R48,R49,R50,R2,i173,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint9,miser-nl?m10,R5,TR6,L1,V3,Myn4,thism2,R44,R45,R49,R50,R2,i178,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint8,emit-nl?m8,R5,TR2,i185,R3,i1,R4,s30,arbace/pprint/pretty_writer.aem8,R5,TR2,i185,R3,i1,R4,s30,arbace/pprint/pretty_writer.aeR51,R52,R53,R54,v13,arbace.pprint11,get-sectionm10,R5,TR6,L1,V1,R55,R2,i208,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint15,get-sub-sectionm10,R5,TR6,L1,V1,R55,R2,i215,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint15,update-nl-statem10,R5,TR6,L1,V1,R49,R2,i223,R3,i1,R4,s30,arbace/pprint/pretty_writer.aem10,R5,TR6,L1,V2,Myn4,thism2,R44,R45,R56,R2,i233,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint16,split-at-newlinem10,R5,TR6,L1,V1,R46,R2,i245,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint3,tokm8,R5,TR2,i251,R3,i1,R4,s30,arbace/pprint/pretty_writer.aem8,R5,TR2,i251,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint4,toksm10,R5,TR6,L1,V1,R57,R2,i258,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint18,write-token-stringm10,R5,TR6,L1,V2,R48,R46,R2,i263,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint10,write-linem10,R5,TR6,L1,V1,Myn4,thism2,R44,R45,R2,i293,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint13,add-to-bufferm10,R5,TR6,L1,V2,Myn4,thism2,R44,R45,R58,R2,i306,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint21,write-buffered-outputm10,R5,TR6,L1,V1,Myn4,thism2,R44,R45,R2,i314,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint17,write-white-spacem10,R5,TR6,L1,V1,Myn4,thism2,R44,R45,R2,i321,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint19,write-initial-linesm10,R5,TR6,L1,V2,Myn4,thism2,R44,R45,Myn1,sm2,R44,R59,R2,i330,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint12,p-write-charm10,R5,TR6,L1,V2,Myn4,thism2,R44,R45,Myn1,cm2,R44,R60,R2,i356,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint13,pretty-writerm10,R5,TR6,L1,V3,R61,R62,R63,R2,i373,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev11,arbace.core15,get-proxy-classC14,java.io.WriterC18,arbace.lang.IDerefC25,arbace.pprint.PrettyFlushv13,arbace.pprint11,start-blockm10,R5,TR6,L1,V4,Myn4,thism2,R44,R45,Myn6,prefixm2,R44,R59,Myn15,per-line-prefixm2,R44,R59,Myn6,suffixm2,R44,R59,R2,i435,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint9,end-blockm10,R5,TR6,L1,V1,Myn4,thism2,R44,R45,R2,i457,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint2,nlm10,R5,TR6,L1,V2,Myn4,thism2,R44,R45,R64,R2,i473,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint6,indentm10,R5,TR6,L1,V3,Myn4,thism2,R44,R45,R65,R66,R2,i479,R3,i1,R4,s30,arbace/pprint/pretty_writer.aem10,R5,TR6,L1,V1,Myn4,thism2,R44,R45,R2,i492,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint15,set-miser-widthm10,R5,TR6,L1,V2,Myn4,thism2,R44,R45,R67,R2,i495,R3,i1,R4,s30,arbace/pprint/pretty_writer.aev13,arbace.pprint26,set-logical-block-callbackm10,R5,TR6,L1,V2,Myn4,thism2,R44,R45,R68,R2,i498,R3,i1,R4,s30,arbace/pprint/pretty_writer.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.lang.IDeref")

var Lit_2 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_3 *jrt.String = jrt.Intern("arbace.pprint$getf")

var Lit_4 *jrt.String = jrt.Intern("arbace.pprint$setf")

var Lit_5 *jrt.String = jrt.Intern("arbace.pprint$deftype")

var Lit_6 *jrt.String = jrt.Intern("arbace.pprint$write_to_base")

var Lit_7 *jrt.String = jrt.Intern("arbace.pprint$ancestor_QMARK_")

var Lit_8 *jrt.String = jrt.Intern("arbace.pprint$buffer_length")

var Lit_9 *jrt.String = jrt.Intern("arbace.pprint$make_buffer_blob")

var Lit_10 *jrt.String = jrt.Intern("arbace.pprint$buffer_blob_QMARK_")

var Lit_11 *jrt.String = jrt.Intern("arbace.pprint$make_nl_t")

var Lit_12 *jrt.String = jrt.Intern("arbace.pprint$nl_t_QMARK_")

var Lit_13 *jrt.String = jrt.Intern("arbace.pprint$make_start_block_t")

var Lit_14 *jrt.String = jrt.Intern("arbace.pprint$start_block_t_QMARK_")

var Lit_15 *jrt.String = jrt.Intern("arbace.pprint$make_end_block_t")

var Lit_16 *jrt.String = jrt.Intern("arbace.pprint$end_block_t_QMARK_")

var Lit_17 *jrt.String = jrt.Intern("arbace.pprint$make_indent_t")

var Lit_18 *jrt.String = jrt.Intern("arbace.pprint$indent_t_QMARK_")

var Lit_19 *jrt.String = jrt.Intern("arbace.pprint$fn__1820000051")

var Lit_20 *jrt.String = jrt.Intern("write-token")

var Lit_21 *jrt.String = jrt.Intern("arbace.pprint$eval1820000055$fn__1820000056")

var Lit_22 *jrt.String = jrt.Intern("arbace.pprint$eval1820000059$fn__1820000060")

var Lit_23 *jrt.String = jrt.Intern("arbace.pprint$eval1820000065$fn__1820000066")

var Lit_24 *jrt.String = jrt.Intern("arbace.pprint$eval1820000069$fn__1820000070")

var Lit_25 *jrt.String = jrt.Intern("arbace.pprint$eval1820000075$fn__1820000076")

var Lit_26 *jrt.String = jrt.Intern("arbace.pprint$eval1820000079$fn__1820000080")

var Lit_27 *jrt.String = jrt.Intern("arbace.pprint$write_tokens")

var Lit_28 *jrt.String = jrt.Intern("arbace.pprint$tokens_fit_QMARK_")

var Lit_29 *jrt.String = jrt.Intern("arbace.pprint$linear_nl_QMARK_")

var Lit_30 *jrt.String = jrt.Intern("arbace.pprint$miser_nl_QMARK_")

var Lit_31 *jrt.String = jrt.Intern("emit-nl?")

var Lit_32 *jrt.String = jrt.Intern("arbace.pprint$eval1820000093$fn__1820000094")

var Lit_33 *jrt.String = jrt.Intern("arbace.pprint$eval1820000097$fn__1820000098")

var Lit_34 *jrt.String = jrt.Intern("arbace.pprint$eval1820000101$fn__1820000102")

var Lit_35 *jrt.String = jrt.Intern("arbace.pprint$eval1820000105$fn__1820000106")

var Lit_36 *jrt.String = jrt.Intern("arbace.pprint$eval1820000109$fn__1820000110")

var Lit_37 *jrt.String = jrt.Intern("arbace.pprint$get_section")

var Lit_38 *jrt.String = jrt.Intern("arbace.pprint$get_sub_section")

var Lit_39 *jrt.String = jrt.Intern("arbace.pprint$update_nl_state")

var Lit_40 *jrt.String = jrt.Intern("arbace.pprint$emit_nl")

var Lit_41 *jrt.String = jrt.Intern("arbace.pprint$split_at_newline")

var Lit_42 *jrt.String = jrt.Intern("tok")

var Lit_43 *jrt.String = jrt.Intern("arbace.pprint$eval1820000133$fn__1820000134")

var Lit_44 *jrt.String = jrt.Intern("arbace.pprint$eval1820000137$fn__1820000138")

var Lit_45 *jrt.String = jrt.Intern("arbace.pprint$eval1820000141$fn__1820000142")

var Lit_46 *jrt.String = jrt.Intern("arbace.pprint$toks")

var Lit_47 *jrt.String = jrt.Intern("arbace.pprint$write_token_string")

var Lit_48 *jrt.String = jrt.Intern("arbace.pprint$write_line")

var Lit_49 *jrt.String = jrt.Intern("arbace.pprint$add_to_buffer")

var Lit_50 *jrt.String = jrt.Intern("arbace.pprint$write_buffered_output")

var Lit_51 *jrt.String = jrt.Intern("arbace.pprint$write_white_space")

var Lit_52 *jrt.String = jrt.Intern("arbace.pprint$write_initial_lines")

var Lit_53 *jrt.String = jrt.Intern("arbace.pprint$p_write_char")

var Lit_54 *jrt.String = jrt.Intern("arbace.pprint$pretty_writer")

var Lit_55 *jrt.String = jrt.Intern("arbace.pprint$start_block")

var Lit_56 *jrt.String = jrt.Intern("arbace.pprint$end_block")

var Lit_57 *jrt.String = jrt.Intern("arbace.pprint$nl")

var Lit_58 *jrt.String = jrt.Intern("arbace.pprint$indent")

var Lit_59 *jrt.String = jrt.Intern("arbace.pprint$get_miser_width")

var Lit_60 *jrt.String = jrt.Intern("arbace.pprint$set_miser_width")

var Lit_61 *jrt.String = jrt.Intern("arbace.pprint$set_logical_block_callback")
