//line a2g_strings.ae:1
package aot_arbace_pprint_pretty_writer

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_3 *jrt.String = jrt.Intern("get-miser-width")

var Lit_4 *jrt.String = jrt.Intern("declared")

var Lit_5 *jrt.String = jrt.Intern("line")

var Lit_6 *jrt.String = jrt.Intern("column")

var Lit_7 *jrt.String = jrt.Intern("file")

var Lit_8 *jrt.String = jrt.Intern("arbace/pprint/pretty_writer.ae")

var Lit_9 *jrt.String = jrt.Intern("getf")

var Lit_10 *jrt.String = jrt.Intern("private")

var Lit_11 *jrt.String = jrt.Intern("arglists")

var Lit_12 *jrt.String = jrt.Intern("sym")

var Lit_13 *jrt.String = jrt.Intern("doc")

var Lit_14 *jrt.String = jrt.Intern("Get the value of the field named by the argument (which should be a keyword).")

var Lit_15 *jrt.String = jrt.Intern("setf")

var Lit_16 *jrt.String = jrt.Intern("new-val")

var Lit_17 *jrt.String = jrt.Intern("Set the value of the field SYM to NEW-VAL")

var Lit_18 *jrt.String = jrt.Intern("deftype")

var Lit_19 *jrt.String = jrt.Intern("type-name")

var Lit_20 *jrt.String = jrt.Intern("&")

var Lit_21 *jrt.String = jrt.Intern("fields")

var Lit_22 *jrt.String = jrt.Intern("write-to-base")

var Lit_23 *jrt.String = jrt.Intern("args")

var Lit_24 *jrt.String = jrt.Intern("Call .write on Writer (getf :base) with proper type-hinting to\n  avoid reflection.")

var Lit_25 *jrt.String = jrt.Intern("logical-block")

var Lit_26 *jrt.String = jrt.Intern("create-struct")

var Lit_27 *jrt.String = jrt.Intern("parent")

var Lit_28 *jrt.String = jrt.Intern("section")

var Lit_29 *jrt.String = jrt.Intern("start-col")

var Lit_30 *jrt.String = jrt.Intern("indent")

var Lit_31 *jrt.String = jrt.Intern("done-nl")

var Lit_32 *jrt.String = jrt.Intern("intra-block-nl")

var Lit_33 *jrt.String = jrt.Intern("prefix")

var Lit_34 *jrt.String = jrt.Intern("per-line-prefix")

var Lit_35 *jrt.String = jrt.Intern("suffix")

var Lit_36 *jrt.String = jrt.Intern("logical-block-callback")

var Lit_37 *jrt.String = jrt.Intern("ancestor?")

var Lit_38 *jrt.String = jrt.Intern("child")

var Lit_39 *jrt.String = jrt.Intern("buffer-length")

var Lit_40 *jrt.String = jrt.Intern("l")

var Lit_41 *jrt.String = jrt.Intern("buffer-blob")

var Lit_42 *jrt.String = jrt.Intern("type-tag")

var Lit_43 *jrt.String = jrt.Intern("data")

var Lit_44 *jrt.String = jrt.Intern("trailing-white-space")

var Lit_45 *jrt.String = jrt.Intern("start-pos")

var Lit_46 *jrt.String = jrt.Intern("end-pos")

var Lit_47 *jrt.String = jrt.Intern("alter-meta!")

var Lit_48 *jrt.String = jrt.Intern("assoc")

var Lit_49 *jrt.String = jrt.Intern("make-buffer-blob")

var Lit_50 *jrt.String = jrt.Intern("vals__1820000016__auto__")

var Lit_51 *jrt.String = jrt.Intern("buffer-blob?")

var Lit_52 *jrt.String = jrt.Intern("x__1820000017__auto__")

var Lit_53 *jrt.String = jrt.Intern("nl-t")

var Lit_54 *jrt.String = jrt.Intern("type")

var Lit_55 *jrt.String = jrt.Intern("make-nl-t")

var Lit_56 *jrt.String = jrt.Intern("nl-t?")

var Lit_57 *jrt.String = jrt.Intern("start-block-t")

var Lit_58 *jrt.String = jrt.Intern("make-start-block-t")

var Lit_59 *jrt.String = jrt.Intern("start-block-t?")

var Lit_60 *jrt.String = jrt.Intern("end-block-t")

var Lit_61 *jrt.String = jrt.Intern("make-end-block-t")

var Lit_62 *jrt.String = jrt.Intern("end-block-t?")

var Lit_63 *jrt.String = jrt.Intern("indent-t")

var Lit_64 *jrt.String = jrt.Intern("relative-to")

var Lit_65 *jrt.String = jrt.Intern("offset")

var Lit_66 *jrt.String = jrt.Intern("make-indent-t")

var Lit_67 *jrt.String = jrt.Intern("indent-t?")

var Lit_68 *jrt.String = jrt.Intern("pp-newline")

var Lit_69 *jrt.String = jrt.Intern("memoize")

var Lit_70 *jrt.String = jrt.Intern("emit-nl")

var Lit_71 *jrt.String = jrt.Intern("write-token")

var Lit_72 *jrt.String = jrt.Intern("deref")

var Lit_73 *jrt.String = jrt.Intern("default")

var Lit_74 *jrt.String = jrt.Intern("global-hierarchy")

var Lit_75 *jrt.String = jrt.Intern("write-tokens")

var Lit_76 *jrt.String = jrt.Intern("this")

var Lit_77 *jrt.String = jrt.Intern("tag")

var Lit_78 *jrt.String = jrt.Intern("Writer")

var Lit_79 *jrt.String = jrt.Intern("tokens")

var Lit_80 *jrt.String = jrt.Intern("force-trailing-whitespace")

var Lit_81 *jrt.String = jrt.Intern("tokens-fit?")

var Lit_82 *jrt.String = jrt.Intern("linear-nl?")

var Lit_83 *jrt.String = jrt.Intern("lb")

var Lit_84 *jrt.String = jrt.Intern("miser-nl?")

var Lit_85 *jrt.String = jrt.Intern("emit-nl?")

var Lit_86 *jrt.String = jrt.Intern("linear")

var Lit_87 *jrt.String = jrt.Intern("miser")

var Lit_88 *jrt.String = jrt.Intern("fill")

var Lit_89 *jrt.String = jrt.Intern("mandatory")

var Lit_90 *jrt.String = jrt.Intern("get-section")

var Lit_91 *jrt.String = jrt.Intern("buffer")

var Lit_92 *jrt.String = jrt.Intern("get-sub-section")

var Lit_93 *jrt.String = jrt.Intern("update-nl-state")

var Lit_94 *jrt.String = jrt.Intern("nl")

var Lit_95 *jrt.String = jrt.Intern("split-at-newline")

var Lit_96 *jrt.String = jrt.Intern("tok")

var Lit_97 *jrt.String = jrt.Intern("toks")

var Lit_98 *jrt.String = jrt.Intern("write-token-string")

var Lit_99 *jrt.String = jrt.Intern("write-line")

var Lit_100 *jrt.String = jrt.Intern("add-to-buffer")

var Lit_101 *jrt.String = jrt.Intern("token")

var Lit_102 *jrt.String = jrt.Intern("write-buffered-output")

var Lit_103 *jrt.String = jrt.Intern("write-white-space")

var Lit_104 *jrt.String = jrt.Intern("write-initial-lines")

var Lit_105 *jrt.String = jrt.Intern("s")

var Lit_106 *jrt.String = jrt.Intern("String")

var Lit_107 *jrt.String = jrt.Intern("p-write-char")

var Lit_108 *jrt.String = jrt.Intern("c")

var Lit_109 *jrt.String = jrt.Intern("Integer")

var Lit_110 *jrt.String = jrt.Intern("pretty-writer")

var Lit_111 *jrt.String = jrt.Intern("writer")

var Lit_112 *jrt.String = jrt.Intern("max-columns")

var Lit_113 *jrt.String = jrt.Intern("miser-width")

var Lit_114 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_115 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_116 *jrt.String = jrt.Intern("arbace.lang.IDeref")

var Lit_117 *jrt.String = jrt.Intern("arbace.pprint.PrettyFlush")

var Lit_118 *jrt.String = jrt.Intern("start-block")

var Lit_119 *jrt.String = jrt.Intern("end-block")

var Lit_120 *jrt.String = jrt.Intern("set-miser-width")

var Lit_121 *jrt.String = jrt.Intern("new-miser-width")

var Lit_122 *jrt.String = jrt.Intern("set-logical-block-callback")

var Lit_123 *jrt.String = jrt.Intern("f")
