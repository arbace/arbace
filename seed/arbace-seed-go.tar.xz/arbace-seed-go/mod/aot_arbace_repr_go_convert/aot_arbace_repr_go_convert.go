//line aot_arbace_repr_go_convert.ae:1
package aot_arbace_repr_go_convert

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_convert_eval1114000004_loading__1927001464__auto____1114000005_A_New() *A_arbace_repr_go_convert_eval1114000004_loading__1927001464__auto____1114000005_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_eval1114000004_loading__1927001464__auto____1114000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_convert_eval1114000004_loading__1927001464__auto____1114000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_convert_eval1114000004_loading__1927001464__auto____1114000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_go_convert_A_const_3, A_arbace_repr_go_convert_A_const_4, A_arbace_repr_go_convert_A_const_5, A_arbace_repr_go_convert_A_const_6); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_repr_go_convert_eval1114000008_fn__1114000009_A_New() *A_arbace_repr_go_convert_eval1114000008_fn__1114000009_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_eval1114000008_fn__1114000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_convert_eval1114000008_fn__1114000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_convert_eval1114000008_fn__1114000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_11), A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_10) }

























func A_arbace_repr_go_convert_note_BANG__A_New() *A_arbace_repr_go_convert_note_BANG__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_note_BANG__A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_repr_go_convert_note_BANG__A) Ctor() {}
//line :27:1
func (t *A_arbace_repr_go_convert_note_BANG__A) Invoke_O_O__O(self, k__0 any) any { if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_12.Get__O()) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_go_convert_A_const_12.Get__O(), A_arbace_repr_go_convert_A_const_14.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_convert_A_const_16, k__0), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_17.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_18)) } else { return nil } }
func A_arbace_repr_go_convert_count_node_BANG__A_New() *A_arbace_repr_go_convert_count_node_BANG__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_count_node_BANG__A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_repr_go_convert_count_node_BANG__A) Ctor() {}
//line :28:1
func (t *A_arbace_repr_go_convert_count_node_BANG__A) Invoke_O_O__O(self, n__0 any) any { if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_12.Get__O()) { var tmp1 any = A_arbace_repr_go_convert_A_const_19; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_go_convert_A_const_12.Get__O(), A_arbace_repr_go_convert_A_const_14.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(n__0)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_17.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_18)) } else { return nil } }

func A_arbace_repr_go_convert_fail_A_New() *A_arbace_repr_go_convert_fail_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_fail_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_repr_go_convert_fail_A) Ctor() {}
//line :30:1
func (t *A_arbace_repr_go_convert_fail_A) Invoke_O_O_O__O(self, msg__0, n__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_21.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_126, nil, nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_22.GetRawRoot__O()); var tmp4 any; if
											jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(n__1)) { tmp4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(n__1) } else { tmp4 = n__1 }; var tmp5 any = /*line :30:1*/tmp3.Invoke_O__O(tmp4); var tmp6 *jrt.String; var temp__1927000414__auto____7 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(n__1); if

	jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(n__1)); if jrt.J2g_Truth(and__1927000168__auto____8) { var G__1114000015__9_ any = n__1; var G__1114000015__10_ any; if lang.Util_Identical_O_O__Z(G__1114000015__9_, nil) { G__1114000015__10_ = nil } else { G__1114000015__10_ = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(G__1114000015__9_) }; if lang.Util_Identical_O_O__Z(G__1114000015__10_, nil) { temp__1927000414__auto____7 = nil } else { temp__1927000414__auto____7 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_26.GetRawRoot__O()).Invoke_O__O(G__1114000015__10_) } } else { temp__1927000414__auto____7 = and__1927000168__auto____8 } } else { temp__1927000414__auto____7 = and__1927000168__auto____7 }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var p__8 any = temp__1927000414__auto____7; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_127, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_28.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_convert_fail_fn__1114000016_A_New(); var tmp11 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_convert_fail_fn__1114000016_A_fn_class
		if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_repr_go_convert_fail_fn__1114000016_A_fn_class = fncls__1d; tmp11 = fncls__1d } else { tmp11 = fncls__1 }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), p__8)))) } else {
//line :32:1
			tmp6 = nil }; var tmp12 any = /*line :30:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, msg__0, nil, tmp5, tmp6.Ref())).Ref(); var tmp13 any = A_arbace_repr_go_convert_A_const_27; var tmp14 any; if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(n__1)) { tmp14 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(n__1) } else { tmp14 = n__1 }; /*line :30:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1.Invoke_O_O__O(tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14)))))) }


func A_arbace_repr_go_convert_fail_fn__1114000016_A_New() *A_arbace_repr_go_convert_fail_fn__1114000016_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_fail_fn__1114000016_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_repr_go_convert_fail_fn__1114000016_A) Ctor() {}
//line :33:1
func (t *A_arbace_repr_go_convert_fail_fn__1114000016_A) Invoke_O_O__O(self, p1__1114000014_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_29.GetRawRoot__O()).Invoke_O__O(p1__1114000014_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_31, p1__1114000014_SHARP___1) } else { return and__1927000168__auto____2 } }




func A_arbace_repr_go_convert_nt_A_New() *A_arbace_repr_go_convert_nt_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_nt_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_repr_go_convert_nt_A) Ctor() {}
//line :38:1
func (t *A_arbace_repr_go_convert_nt_A) Invoke_O_O__O(self, n__0 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(n__0)) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(n__0) } else { return nil } }
func A_arbace_repr_go_convert_nf_A_New() *A_arbace_repr_go_convert_nf_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_nf_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_repr_go_convert_nf_A) Ctor() {}
//line :39:1
func (t *A_arbace_repr_go_convert_nf_A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(n__0) }
func A_arbace_repr_go_convert_an_A_New() *A_arbace_repr_go_convert_an_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_an_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_repr_go_convert_an_A) Ctor() {}
//line :40:1
func (t *A_arbace_repr_go_convert_an_A) Invoke_O_O__O(self, n__0 any) any { return lang.RT_Meta_O__IPersistentMap(n__0) }

func A_arbace_repr_go_convert_unparen_A_New() *A_arbace_repr_go_convert_unparen_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_unparen_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_convert_unparen_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_convert_unparen_A) Invoke_O_O__O(self, n__0 any) any { { var n__0_2 any = n__0; L1: for { var tmp1 any = A_arbace_repr_go_convert_A_const_32; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0_2)) { var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; n__0_2 = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0_2)); continue L1 } else { return n__0_2 } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_convert_parse_pos_A_New() *A_arbace_repr_go_convert_parse_pos_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_parse_pos_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_convert_parse_pos_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_convert_parse_pos_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = s__0; if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_36, s__0) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_32); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_18; return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(tmp2.Invoke_O_O_O__O(s__0, tmp3, jrt.Integer_ValueOf_I__Integer(i__2).Ref())))).Ref(), jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()).Invoke_O_O__O(s__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(i__2))).Ref())))).Ref()) } else { return nil
	}
}

func A_arbace_repr_go_convert_pos_line_A_New() *A_arbace_repr_go_convert_pos_line_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_pos_line_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_repr_go_convert_pos_line_A) Ctor() {}
//line :49:1
func (t *A_arbace_repr_go_convert_pos_line_A) Invoke_O_O__O(self, s__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(s__0)) }

func A_arbace_repr_go_convert_start_A_New() *A_arbace_repr_go_convert_start_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_start_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_go_convert_start_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_go_convert_start_A) Invoke_O_O__O(self, n__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var G__1114000025__3_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0); switch



	lang.Util_Hash_O__I(G__1114000025__3_) >> 2 & 511 { case 4: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_39) {























		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_47.Invoke_O__O(f__2)) }
//line :55:1
	case 40: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_41) {











		return A_arbace_repr_go_convert_A_const_42.Invoke_O__O(f__2) }
//line :55:1
	case 45: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_43) {

















		return A_arbace_repr_go_convert_A_const_43.Invoke_O__O(f__2) }
//line :55:1
	case 58: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_44) {































		return A_arbace_repr_go_convert_A_const_45.Invoke_O__O(f__2) }
//line :55:1
	case 66: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_48) {







































		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_49.Invoke_O__O(f__2)) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_49.Invoke_O__O(f__2)) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_51.Invoke_O__O(f__2)) } }
//line :55:1
	case 80: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_50) {








































		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_54.Invoke_O__O(f__2))) }
//line :55:1
	case 93: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_52) {









		return A_arbace_repr_go_convert_A_const_53.Invoke_O__O(f__2) }
//line :55:1
	case 95: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_55) {
		return A_arbace_repr_go_convert_A_const_56.Invoke_O__O(f__2) }
//line :55:1
	case 98: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_57) {




























		return A_arbace_repr_go_convert_A_const_58.Invoke_O__O(f__2) }
//line :55:1
	case 101: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_59) {


		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_60.Invoke_O__O(f__2)) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_60.Invoke_O__O(f__2)) } else { return A_arbace_repr_go_convert_A_const_61.Invoke_O__O(f__2) } }
//line :55:1
	case 109: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_62) {
















		return A_arbace_repr_go_convert_A_const_63.Invoke_O__O(f__2) }
//line :55:1
	case 145: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_64) {



















		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_54.Invoke_O__O(f__2))) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_54.Invoke_O__O(f__2))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_60.Invoke_O__O(f__2)) } }
//line :55:1
	case 154: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_66) {















		return A_arbace_repr_go_convert_A_const_67.Invoke_O__O(f__2) }
//line :55:1
	case 160: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_68) {
































		return A_arbace_repr_go_convert_A_const_69.Invoke_O__O(f__2) }
//line :55:1
	case 161: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_70) { var or__1927000174__auto____4 any = A_arbace_repr_go_convert_A_const_71.Invoke_O__O(f__2)


















		if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var G__1114000026__5_ any = A_arbace_repr_go_convert_A_const_72.Invoke_O__O(f__2); var G__1114000026__6_ any; if lang.Util_Identical_O_O__Z(G__1114000026__5_, nil) { G__1114000026__6_ = nil } else { G__1114000026__6_ = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(G__1114000026__5_) }; if lang.Util_Identical_O_O__Z(G__1114000026__6_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(G__1114000026__6_) } } }
//line :55:1
	case 185: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_73) {






		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)) }
//line :55:1
	case 186: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_74) {




















		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_76.Invoke_O__O(f__2)) }
//line :55:1
	case 190: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_75) {






















		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)) }
//line :55:1
	case 195: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_77) {

























		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_79.Invoke_O__O(f__2))) }
//line :55:1
	case 197: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_78) {






		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)) }
//line :55:1
	case 221: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_80) {







		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_83.Invoke_O__O(f__2)) }
//line :55:1
	case 254: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_81) {














		return A_arbace_repr_go_convert_A_const_82.Invoke_O__O(f__2) }
//line :55:1
	case 256: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_84) {










		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_86.Invoke_O__O(f__2)) }
//line :55:1
	case 262: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_85) {






		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)) }
//line :55:1
	case 271: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_87) {




































		return A_arbace_repr_go_convert_A_const_88.Invoke_O__O(f__2) }
//line :55:1
	case 284: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_89) {









































		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_49.Invoke_O__O(f__2)) }
//line :55:1
	case 285: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_90) {





































		return A_arbace_repr_go_convert_A_const_91.Invoke_O__O(f__2) }
//line :55:1
	case 297: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_92) {
























		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)) }
//line :55:1
	case 302: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_93) {



































		return A_arbace_repr_go_convert_A_const_94.Invoke_O__O(f__2) }
//line :55:1
	case 313: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_95) {





















		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_97.Invoke_O__O(f__2)) }
//line :55:1
	case 314: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_96) {



		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_60.Invoke_O__O(f__2)) }
//line :55:1
	case 321: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_98) {








		return A_arbace_repr_go_convert_A_const_99.Invoke_O__O(f__2) }
//line :55:1
	case 366: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_100) { var or__1927000174__auto____4_2 any = A_arbace_repr_go_convert_A_const_101.Invoke_O__O(f__2)













		if jrt.J2g_Truth(or__1927000174__auto____4_2) { return or__1927000174__auto____4_2 } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_103.Invoke_O__O(f__2)) } }
//line :55:1
	case 370: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_102) {






		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)) }
//line :55:1
	case 384: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_104) {






		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)) }
//line :55:1
	case 392: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_105) {

































		return A_arbace_repr_go_convert_A_const_106.Invoke_O__O(f__2) }
//line :55:1
	case 400: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_107) {



























		return A_arbace_repr_go_convert_A_const_108.Invoke_O__O(f__2) }
//line :55:1
	case 410: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_109) {

		return A_arbace_repr_go_convert_A_const_110.Invoke_O__O(f__2) }
//line :55:1
	case 416: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_111) {

































		return A_arbace_repr_go_convert_A_const_106.Invoke_O__O(f__2) }
//line :55:1
	case 428: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_112) {












		return A_arbace_repr_go_convert_A_const_113.Invoke_O__O(f__2) }
//line :55:1
	case 436: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_114) {



































		return A_arbace_repr_go_convert_A_const_94.Invoke_O__O(f__2) }
//line :55:1
	case 444: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_32) {




		return A_arbace_repr_go_convert_A_const_115.Invoke_O__O(f__2) }
//line :55:1
	case 458: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_116) {






		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)) }
//line :55:1
	case 465: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_117) {


































		return A_arbace_repr_go_convert_A_const_118.Invoke_O__O(f__2) }
//line :55:1
	case 473: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_119) {





























		return A_arbace_repr_go_convert_A_const_91.Invoke_O__O(f__2) }
//line :55:1
	case 482: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_120) {


























		return A_arbace_repr_go_convert_A_const_121.Invoke_O__O(f__2) }
//line :55:1
	case 485: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_122) {
































		return A_arbace_repr_go_convert_A_const_69.Invoke_O__O(f__2) }
//line :55:1
	case 489: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_123) {






































		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_60.Invoke_O__O(f__2)) }
//line :55:1
	case 491: if any(G__1114000025__3_) == any(A_arbace_repr_go_convert_A_const_124) {






























		return A_arbace_repr_go_convert_A_const_61.Invoke_O__O(f__2) }
//line :55:1
	default:}; return /*line :98:1*/ lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_219, n__0) }

func A_arbace_repr_go_convert_line_of_A_New() *A_arbace_repr_go_convert_line_of_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_line_of_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_repr_go_convert_line_of_A) Ctor() {}
//line :100:1
func (t *A_arbace_repr_go_convert_line_of_A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_125.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(n__0)) }

func A_arbace_repr_go_convert_positions_A_New() *A_arbace_repr_go_convert_positions_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_positions_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_repr_go_convert_positions_A) Ctor() {}
//line :102:1
func (t *A_arbace_repr_go_convert_positions_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_127.GetRawRoot__O()).Invoke__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_128.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_positions_fn__1114000030_A_New(); var tmp5 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_convert_positions_fn__1114000030_A_fn_class
	if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_181, false); A_arbace_repr_go_convert_positions_fn__1114000030_A_fn_class = fncls__3d; tmp5 = fncls__3d } else { tmp5 = fncls__3 }
//line :105:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0)) }
func A_arbace_repr_go_convert_positions_fn__1114000030_A_New() *A_arbace_repr_go_convert_positions_fn__1114000030_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_positions_fn__1114000030_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_repr_go_convert_positions_fn__1114000030_A) Ctor() {}
//line :106:1
func (t *A_arbace_repr_go_convert_positions_fn__1114000030_A) Invoke_O_O__O(self, p__1114000029__1 any) any { var vec__1114000031__2 any = p__1114000029__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1114000031__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1114000031__2, lang.RT_IntCast_J__I(1), nil); var temp__1927000414__auto____5 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_29.GetRawRoot__O()).Invoke_O__O(v__4); if jrt.J2g_Truth(and__1927000168__auto____5) { temp__1927000414__auto____5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(v__4) } else { temp__1927000414__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var p__6 any = temp__1927000414__auto____5; return lang.Tuple_Create_O_O__IPersistentVector(k__3, p__6) } else { return nil } }


func A_arbace_repr_go_convert_max_pos_A_New() *A_arbace_repr_go_convert_max_pos_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_max_pos_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_repr_go_convert_max_pos_A) Ctor() {}
//line :109:1
func (t *A_arbace_repr_go_convert_max_pos_A) Invoke_O_O__O(self, n__0 any) any { var best__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_137); var walk__3 any; var tmp1 any = A_arbace_repr_go_convert_max_pos_walk__1114000036_A_New_O(best__2); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_go_convert_max_pos_walk__1114000036_A_fn_class; if



	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_178, false); A_arbace_repr_go_convert_max_pos_walk__1114000036_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);






	lang.IFn_Cast(walk__3).Invoke_O__O(n__0); return /*line :112:1*/ lang.IFn_Cast(A_arbace_repr_go_convert_A_const_8.GetRawRoot__O()).Invoke_O__O(best__2) }
func A_arbace_repr_go_convert_max_pos_walk__1114000036_A_New_O(p0 any) *A_arbace_repr_go_convert_max_pos_walk__1114000036_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_max_pos_walk__1114000036_A{}; t.Ctor_O(p0); return t }
//line :113:1
func (t *A_arbace_repr_go_convert_max_pos_walk__1114000036_A) Ctor_O(c__best any) { t.F_best = c__best }
//line :113:1
func (t *A_arbace_repr_go_convert_max_pos_walk__1114000036_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(x__1)) {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1))) { var seq_1114000037__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1))); var chunk_1114000038__3 any; var count_1114000039__4 int64 = 0; var i_1114000040__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z(i_1114000040__5, count_1114000039__4) { var v__6 any = lang.Indexed_Cast(chunk_1114000038__3).Nth_I__O(lang.RT_IntCast_J__I(i_1114000040__5)); lang.IFn_Cast(self).Invoke_O__O(v__6); seq_1114000037__2, chunk_1114000038__3, count_1114000039__4, i_1114000040__5 = seq_1114000037__2, chunk_1114000038__3, count_1114000039__4, lang.Numbers_Unchecked_inc_J__J(i_1114000040__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1114000037__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1114000037__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(seq_1114000037__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(seq_1114000037__7); seq_1114000037__2, chunk_1114000038__3, count_1114000039__4, i_1114000040__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_1114000037__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var v__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1114000037__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1114000037__2, chunk_1114000038__3, count_1114000039__4, i_1114000040__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq_1114000037__7), nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :115:1
				return nil } } else {
//line :114:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_132.GetRawRoot__O()).Invoke_O__O(x__1)) {


						return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_133.GetRawRoot__O()).Invoke_O_O__O(self, x__1) } else {
//line :114:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_29.GetRawRoot__O()).Invoke_O__O(x__1)) { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(x__1)



								if jrt.J2g_Truth(temp__1927000414__auto____2) { var p__3 any = temp__1927000414__auto____2
									if lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(p__3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_8.GetRawRoot__O()).Invoke_O__O(t.F_best)))) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_134.GetRawRoot__O()).Invoke_O_O__O(t.F_best, p__3) } else { return nil } } else {
//line :118:1
										return nil } } else {
//line :114:1
											return nil } } }
//line :113:1
	panic("j2g: unreachable")
}










func A_arbace_repr_go_convert_form_A_New() *A_arbace_repr_go_convert_form_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_form_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_repr_go_convert_form_A) Ctor() {}
//line :125:1
func (t *A_arbace_repr_go_convert_form_A) DoInvoke_O_O_O_O__O(self, n__0, l__1, xs__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O(), xs__2); var tmp3 any; var G__1114000043__4_ any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_140, l__1)); if jrt.J2g_Truth(n__0) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_143; tmp3 = tmp4.Invoke_O_O_O__O(G__1114000043__4_, tmp5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_144.GetRawRoot__O()).Invoke_O__O(n__0)) } else { tmp3 = G__1114000043__4_ }; return tmp1.Invoke_O_O__O(tmp2, tmp3)
}
func A_arbace_repr_go_convert_at_A_New() *A_arbace_repr_go_convert_at_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_at_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_repr_go_convert_at_A) Ctor() {}
//line :130:1
func (t *A_arbace_repr_go_convert_at_A) Invoke_O_O_O_O__O(self, x__0, n__1, l__2 any) any {


	if lang.IObj_InstanceOf(x__0) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_at_fn__1114000046_A_New_O_O(l__2, n__1); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_go_convert_at_fn__1114000046_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_repr_go_convert_at_fn__1114000046_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; return tmp1.Invoke_O_O__O(x__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else {
//line :133:1
			return x__0 } }
func A_arbace_repr_go_convert_at_fn__1114000046_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_at_fn__1114000046_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_at_fn__1114000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :134:1
func (t *A_arbace_repr_go_convert_at_fn__1114000046_A) Ctor_O_O(c__l, c__n any) { t.F_l = c__l; t.F_n = c__n }
//line :134:1
func (t *A_arbace_repr_go_convert_at_fn__1114000046_A) Invoke_O_O__O(self, m__1 any) any { var G__1114000047__2_ any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = m__1; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp3 any = tmp2; var tmp4 any = A_arbace_repr_go_convert_A_const_140; var tmp5 any; var or__1927000174__auto____2_2 any = A_arbace_repr_go_convert_A_const_140.Invoke_O__O(m__1); if jrt.J2g_Truth(or__1927000174__auto____2_2) { tmp5 = or__1927000174__auto____2_2 } else { tmp5 = t.F_l }; G__1114000047__2_ = tmp1.Invoke_O_O_O__O(tmp3, tmp4, tmp5); if jrt.J2g_Truth(t.F_n) {
												var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_143; var tmp8 any = A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A_New_O(t.F_n); var tmp9 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A_fn_class = fncls__5d; tmp9 = fncls__5d } else { tmp9 = fncls__5 }; return tmp6.Invoke_O_O_O__O(G__1114000047__2_, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) } else {
//line :134:1
		return G__1114000047__2_ } }
func A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A_New_O(p0 any) *A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A{}; t.Ctor_O(p0); return t }
//line :135:1
func (t *A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :135:1
func (t *A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A) Invoke_O_O__O(self, p1__1114000045_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_144.GetRawRoot__O()).Invoke_O__O(t.F_n), p1__1114000045_SHARP___1) }


func A_arbace_repr_go_convert_line_A_New() *A_arbace_repr_go_convert_line_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_line_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_repr_go_convert_line_A) Ctor() {}
//line :138:1
func (t *A_arbace_repr_go_convert_line_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_140; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) }

func A_arbace_repr_go_convert_with_pos_A_New() *A_arbace_repr_go_convert_with_pos_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_with_pos_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_repr_go_convert_with_pos_A) Ctor() {}
//line :140:1
func (t *A_arbace_repr_go_convert_with_pos_A) Invoke_O_O_O__O(self, x__0, m__1 any) any { var ps__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;


	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_128.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_with_pos_fn__1114000055_A_New(); var tmp6 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_convert_with_pos_fn__1114000055_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_244, false); A_arbace_repr_go_convert_with_pos_fn__1114000055_A_fn_class = fncls__7d; tmp6 = fncls__7d } else { tmp6 = fncls__7 }; ps__3 = tmp1.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)), m__1); var tmp7 any; var and__1927000168__auto____4 any =
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(ps__3); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(lang.IObj_InstanceOf(x__0)).Ref() } else { tmp7 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp7) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_A_const_146.GetRawRoot__O(); var tmp10 any = A_arbace_repr_go_convert_A_const_143; var tmp11 any = A_arbace_repr_go_convert_with_pos_fn__1114000060_A_New_O(ps__3); var tmp12 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_go_convert_with_pos_fn__1114000060_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_245, false); A_arbace_repr_go_convert_with_pos_fn__1114000060_A_fn_class = fncls__8d; tmp12 = fncls__8d } else { tmp12 = fncls__8 }; return tmp8.Invoke_O_O_O_O__O(x__0, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)) } else {
//line :144:1
			return x__0 } }
//line :143:1
func A_arbace_repr_go_convert_with_pos_fn__1114000055_A_New() *A_arbace_repr_go_convert_with_pos_fn__1114000055_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_with_pos_fn__1114000055_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_repr_go_convert_with_pos_fn__1114000055_A) Ctor() {}
//line :143:1
func (t *A_arbace_repr_go_convert_with_pos_fn__1114000055_A) Invoke_O_O__O(self, p__1114000054__1 any) any { var vec__1114000056__2 any = p__1114000054__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1114000056__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1114000056__2, lang.RT_IntCast_J__I(1), nil); var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(v__4); if jrt.J2g_Truth(temp__1927000414__auto____5) { var p__6 any = temp__1927000414__auto____5; return lang.Tuple_Create_O_O__IPersistentVector(k__3, p__6) } else { return nil } }

func A_arbace_repr_go_convert_with_pos_fn__1114000060_A_New_O(p0 any) *A_arbace_repr_go_convert_with_pos_fn__1114000060_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_with_pos_fn__1114000060_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_repr_go_convert_with_pos_fn__1114000060_A) Ctor_O(c__ps any) { t.F_ps = c__ps }
//line :145:1
func (t *A_arbace_repr_go_convert_with_pos_fn__1114000060_A) Invoke_O_O__O(self, p1__1114000053_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_147.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = p1__1114000053_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_127.GetRawRoot__O()).Invoke__O() }; return tmp1.Invoke_O_O__O(tmp2, t.F_ps) }


func A_arbace_repr_go_convert_full_meta_A_New() *A_arbace_repr_go_convert_full_meta_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_full_meta_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_repr_go_convert_full_meta_A) Ctor() {}
//line :148:1
func (t *A_arbace_repr_go_convert_full_meta_A) Invoke_O_O_O__O(self, x__0, m__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 any = A_arbace_repr_go_convert_A_const_148.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(m__1); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.IObj_InstanceOf(x__0)).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_146.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_convert_A_const_149; return tmp2.Invoke_O_O_O_O_O__O(x__0, tmp3, tmp4, A_arbace_repr_go_convert_A_const_147.GetRawRoot__O(), m__1) } else {
//line :151:1
			return x__0
		}
}

func A_arbace_repr_go_convert_add_parens_A_New() *A_arbace_repr_go_convert_add_parens_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_add_parens_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_repr_go_convert_add_parens_A) Ctor() {}
//line :155:1
func (t *A_arbace_repr_go_convert_add_parens_A) Invoke_O_O_O__O(self, x__0, p__1 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_148.Get__O())) { return x__0 } else { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_115; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_153; var pr__3 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(p__1))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(p__1))))


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(x__0)) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_A_const_154; var tmp5 any = A_arbace_repr_go_convert_add_parens_fn__1114000066_A_New_O(pr__3); var tmp6 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_go_convert_add_parens_fn__1114000066_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_repr_go_convert_add_parens_fn__1114000066_A_fn_class = fncls__9d; tmp6 = fncls__9d } else { tmp6 = fncls__9 }; return tmp3.Invoke_O_O_O__O(x__0, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) } else {
//line :162:1
				if lang.IObj_InstanceOf(x__0) {

					var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_A_const_14.GetRawRoot__O(); var tmp9 any = A_arbace_repr_go_convert_A_const_155; var tmp10 any = A_arbace_repr_go_convert_add_parens_fn__1114000068_A_New_O(pr__3); var tmp11 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repr_go_convert_add_parens_fn__1114000068_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_repr_go_convert_add_parens_fn__1114000068_A_fn_class = fncls__10d; tmp11 = fncls__10d } else { tmp11 = fncls__10 }; return tmp7.Invoke_O_O_O_O__O(x__0, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)) } else {
//line :162:1
						if A_arbace_repr_go_convert_A_const_152 != nil { return x__0 } else { return nil } } } } }
func A_arbace_repr_go_convert_add_parens_fn__1114000066_A_New_O(p0 any) *A_arbace_repr_go_convert_add_parens_fn__1114000066_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_add_parens_fn__1114000066_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_repr_go_convert_add_parens_fn__1114000066_A) Ctor_O(c__pr any) { t.F_pr = c__pr }
//line :163:1
func (t *A_arbace_repr_go_convert_add_parens_fn__1114000066_A) Invoke_O_O__O(self, p1__1114000064_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(t.F_pr), p1__1114000064_SHARP___1) }
func A_arbace_repr_go_convert_add_parens_fn__1114000068_A_New_O(p0 any) *A_arbace_repr_go_convert_add_parens_fn__1114000068_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_add_parens_fn__1114000068_A{}; t.Ctor_O(p0); return t }
//line :164:1
func (t *A_arbace_repr_go_convert_add_parens_fn__1114000068_A) Ctor_O(c__pr any) { t.F_pr = c__pr }
//line :164:1
func (t *A_arbace_repr_go_convert_add_parens_fn__1114000068_A) Invoke_O_O__O(self, p1__1114000065_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(t.F_pr), p1__1114000065_SHARP___1) }


func A_arbace_repr_go_convert_reparen_A_New() *A_arbace_repr_go_convert_reparen_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_reparen_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_repr_go_convert_reparen_A) Ctor() {}
//line :167:1
func (t *A_arbace_repr_go_convert_reparen_A) Invoke_O_O_O__O(self, x__0, n__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 any = A_arbace_repr_go_convert_A_const_148.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 any = A_arbace_repr_go_convert_A_const_32; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__1))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_156.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_157.GetRawRoot__O()).Invoke_O_O__O(x__0, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__1))), n__1) } else {
//line :170:1
			return x__0
		}
}

func A_arbace_repr_go_convert_block_pos_A_New() *A_arbace_repr_go_convert_block_pos_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_block_pos_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_repr_go_convert_block_pos_A) Ctor() {}
//line :174:1
func (t *A_arbace_repr_go_convert_block_pos_A) Invoke_O_O__O(self, b__0 any) any { if jrt.J2g_Truth(b__0) { var tmp1 any = A_arbace_repr_go_convert_A_const_61; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_61; var tmp3 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(b__0)); var tmp4 any = A_arbace_repr_go_convert_A_const_158; var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_158; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(b__0)))) } else { return nil } }

func A_arbace_repr_go_convert_with_line_A_New() *A_arbace_repr_go_convert_with_line_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_with_line_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_repr_go_convert_with_line_A) Ctor() {}
//line :176:1
func (t *A_arbace_repr_go_convert_with_line_A) Invoke_O_O_O__O(self, l__0, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool = lang.IObj_InstanceOf(x__1); if and__1927000168__auto____3 { tmp1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_159.GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()).Invoke_O_O_O_O__O(x__1, A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_140, l__0) } else { return x__1
	} }
func A_arbace_repr_go_convert_vec_at_A_New() *A_arbace_repr_go_convert_vec_at_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_vec_at_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_repr_go_convert_vec_at_A) Ctor() {}
//line :179:1
func (t *A_arbace_repr_go_convert_vec_at_A) Invoke_O_O_O__O(self, l__0, xs__1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(xs__1), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_140, l__0))) }

func A_arbace_repr_go_convert_add_meta_A_New() *A_arbace_repr_go_convert_add_meta_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_add_meta_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_repr_go_convert_add_meta_A) Ctor() {}
//line :181:1
func (t *A_arbace_repr_go_convert_add_meta_A) Invoke_O_O_O__O(self, x__0, m__1 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_161.GetRawRoot__O()).Invoke_O__O(m__1)) { return x__0 } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_repr_go_convert_A_const_147.GetRawRoot__O(), m__1)
	} }
func A_arbace_repr_go_convert_lit_at_A_New() *A_arbace_repr_go_convert_lit_at_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_lit_at_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_repr_go_convert_lit_at_A) Ctor() {}
//line :186:1
func (t *A_arbace_repr_go_convert_lit_at_A) Invoke_O_O_O_O__O(self, l__0, x__1, pos__2 any) any {


	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()).Invoke_O_O_O_O_O__O(x__1, A_arbace_repr_go_convert_A_const_162, l__0, A_arbace_repr_go_convert_A_const_163, pos__2)
}
func A_arbace_repr_go_convert_relined_A_New() *A_arbace_repr_go_convert_relined_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_relined_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_repr_go_convert_relined_A) Ctor() {}
//line :191:1
func (t *A_arbace_repr_go_convert_relined_A) Invoke_O_O_O__O(self, l__0, x__1 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(x__1)) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(x__1, A_arbace_repr_go_convert_A_const_162, l__0, A_arbace_repr_go_convert_A_const_163, nil, A_arbace_repr_go_convert_A_const_165, nil, A_arbace_repr_go_convert_A_const_154, nil, A_arbace_repr_go_convert_A_const_166, nil) } else {
//line :194:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(x__1)) {

				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_142.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_relined_fn__1114000080_A_New_O(l__0); var tmp6 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_convert_relined_fn__1114000080_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_182, false); A_arbace_repr_go_convert_relined_fn__1114000080_A_fn_class = fncls__11d; tmp6 = fncls__11d } else { tmp6 = fncls__11 }; return tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), x__1)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_167.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()).Invoke_O_O_O__O(lang.RT_Meta_O__IPersistentMap(x__1), A_arbace_repr_go_convert_A_const_140, l__0), A_arbace_repr_go_convert_A_const_143, A_arbace_repr_go_convert_A_const_149)) } else {
//line :194:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_132.GetRawRoot__O()).Invoke_O__O(x__1)) {



						var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_170.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_relined_fn__1114000082_A_New_O(l__0); var tmp10 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_go_convert_relined_fn__1114000082_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_183, false); A_arbace_repr_go_convert_relined_fn__1114000082_A_fn_class = fncls__12d; tmp10 = fncls__12d } else { tmp10 = fncls__12 }; return tmp7.Invoke_O_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), x__1), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_167.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()).Invoke_O_O_O__O(lang.RT_Meta_O__IPersistentMap(x__1), A_arbace_repr_go_convert_A_const_140, l__0), A_arbace_repr_go_convert_A_const_143, A_arbace_repr_go_convert_A_const_149)) } else {
//line :194:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(x__1)) {




								var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp12 any = A_arbace_repr_go_convert_relined_fn__1114000084_A_New_O(l__0); var tmp13 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_convert_relined_fn__1114000084_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_184, false); A_arbace_repr_go_convert_relined_fn__1114000084_A_fn_class = fncls__13d; tmp13 = fncls__13d } else { tmp13 = fncls__13 }; return tmp11.Invoke_O_O__O(x__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)) } else {
//line :194:1
									if A_arbace_repr_go_convert_A_const_152 != nil { return x__1 } else { return nil
									} } } } } }
func A_arbace_repr_go_convert_relined_fn__1114000080_A_New_O(p0 any) *A_arbace_repr_go_convert_relined_fn__1114000080_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_relined_fn__1114000080_A{}; t.Ctor_O(p0); return t }
//line :196:1
func (t *A_arbace_repr_go_convert_relined_fn__1114000080_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :196:1
func (t *A_arbace_repr_go_convert_relined_fn__1114000080_A) Invoke_O_O__O(self, p1__1114000077_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_169.GetRawRoot__O()).Invoke_O_O__O(t.F_l, p1__1114000077_SHARP___1) }

func A_arbace_repr_go_convert_relined_fn__1114000082_A_New_O(p0 any) *A_arbace_repr_go_convert_relined_fn__1114000082_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_relined_fn__1114000082_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_repr_go_convert_relined_fn__1114000082_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :198:1
func (t *A_arbace_repr_go_convert_relined_fn__1114000082_A) Invoke_O_O__O(self, p1__1114000078_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_169.GetRawRoot__O()).Invoke_O_O__O(t.F_l, p1__1114000078_SHARP___1) }
func A_arbace_repr_go_convert_relined_fn__1114000084_A_New_O(p0 any) *A_arbace_repr_go_convert_relined_fn__1114000084_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_relined_fn__1114000084_A{}; t.Ctor_O(p0); return t }
//line :199:1
func (t *A_arbace_repr_go_convert_relined_fn__1114000084_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :199:1
func (t *A_arbace_repr_go_convert_relined_fn__1114000084_A) Invoke_O_O__O(self, p1__1114000079_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_167.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()).Invoke_O_O_O__O(p1__1114000079_SHARP___1, A_arbace_repr_go_convert_A_const_140, t.F_l), A_arbace_repr_go_convert_A_const_143, A_arbace_repr_go_convert_A_const_149) }




















func A_arbace_repr_go_convert_ident_name_A_New() *A_arbace_repr_go_convert_ident_name_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_ident_name_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_go_convert_ident_name_A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_go_convert_ident_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0)) }

func A_arbace_repr_go_convert_obj_A_New() *A_arbace_repr_go_convert_obj_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_obj_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_repr_go_convert_obj_A) Ctor() {}
//line :222:1
func (t *A_arbace_repr_go_convert_obj_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_171; var or__1927000174__auto____2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_173; return tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0)) } }

func A_arbace_repr_go_convert_targs_A_New() *A_arbace_repr_go_convert_targs_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_targs_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_repr_go_convert_targs_A) Ctor() {}
//line :224:1
func (t *A_arbace_repr_go_convert_targs_A) Invoke_O_O__O(self, inst__0 any) any {


	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_174.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_175.Invoke_O__O(inst__0))
}
func A_arbace_repr_go_convert_inst_meta_A_New() *A_arbace_repr_go_convert_inst_meta_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_inst_meta_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_repr_go_convert_inst_meta_A) Ctor() {}
//line :229:1
func (t *A_arbace_repr_go_convert_inst_meta_A) Invoke_O_O_O__O(self, n__0, explicit__1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_176; var inst__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0)); var o__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_177.GetRawRoot__O()).Invoke_O__O(n__0); var tmp2 any; var and__1927000168__auto____5 any = inst__3; if





	jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any = A_arbace_repr_go_convert_A_const_101; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(tmp3, A_arbace_repr_go_convert_A_const_178.Invoke_O__O(o__4)); if and__1927000168__auto____6 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_O_J__Z(explicit__1, int64(lang.RT_Count_O__I(A_arbace_repr_go_convert_A_const_175.Invoke_O__O(inst__3))))).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) { var tmp4 any = A_arbace_repr_go_convert_A_const_176; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_179.GetRawRoot__O()).Invoke_O__O(inst__3))) } else { return nil } }


func A_arbace_repr_go_convert_ident_A_New() *A_arbace_repr_go_convert_ident_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_ident_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_repr_go_convert_ident_A) Ctor() {}
//line :238:1
func (t *A_arbace_repr_go_convert_ident_A) Invoke_O_O_O__O(self, n__0, explicit__1 any) any {



	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :238:1
	var name__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(n__0); var l__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var o__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_177.GetRawRoot__O()).Invoke_O__O(n__0)







	if lang.Util_Equiv_O_O__Z(name__3, Lit_28) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(Lit_28), n__0, l__4) } else {
//line :246:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_183).Invoke_O__O(name__3)) {


				var tmp1 any; var or__1927000174__auto____6 any = A_arbace_repr_go_convert_A_const_184.Invoke_O__O(o__5); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var tmp2 any = A_arbace_repr_go_convert_A_const_185; var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_186; var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp2, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0))); if or__1927000174__auto____7 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z(o__5, nil); if and__1927000168__auto____8 { var tmp4 any = A_arbace_repr_go_convert_A_const_187; var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_186; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } }; if jrt.J2g_Truth(tmp1) {
					return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(l__4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(name__3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_194).Invoke_O__O(name__3)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(n__0))) } else {
						lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_196); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_197; return tmp6.Invoke_O_O_O_O__O(n__0, l__4, tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(name__3), name__3)) } } else {
//line :246:1
							if A_arbace_repr_go_convert_A_const_152 != nil {





								return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(name__3), n__0, l__4), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_199.GetRawRoot__O()).Invoke_O_O__O(n__0, explicit__1)) } else {
//line :246:1
									return nil } } } }
//line :238:1
func (t *A_arbace_repr_go_convert_ident_A) Invoke_O_O__O(self, n__0 any) any {

	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O_O__O(n__0, A_arbace_repr_go_convert_A_const_18)
}












func A_arbace_repr_go_convert_label_kw_A_New() *A_arbace_repr_go_convert_label_kw_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_label_kw_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_repr_go_convert_label_kw_A) Ctor() {}
//line :254:1
func (t *A_arbace_repr_go_convert_label_kw_A) Invoke_O_O__O(self, n__0 any) any { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_201.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(n__0)) }

func A_arbace_repr_go_convert_pkg_ident_QMARK__A_New() *A_arbace_repr_go_convert_pkg_ident_QMARK__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_pkg_ident_QMARK__A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_repr_go_convert_pkg_ident_QMARK__A) Ctor() {}
//line :256:1
func (t *A_arbace_repr_go_convert_pkg_ident_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any = A_arbace_repr_go_convert_A_const_202; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_178; var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_171; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, tmp2.Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(n__0)))))).Ref() }



func A_arbace_repr_go_convert_spelled_A_New() *A_arbace_repr_go_convert_spelled_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_spelled_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_repr_go_convert_spelled_A) Ctor() {}
//line :260:1
func (t *A_arbace_repr_go_convert_spelled_A) Invoke_O_O_O_O__O(self, x__0, raw__1, printed__2 any) any {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_148.Get__O())) { return x__0 } else { var p__4 any = lang.IFn_Cast(printed__2).Invoke_O__O(x__0)


		if lang.Util_Equiv_O_O__Z(p__4, raw__1) { return x__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(x__0)) {

			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_repr_go_convert_A_const_165, raw__1) } else {
//line :268:1
				if A_arbace_repr_go_convert_A_const_152 != nil {


					return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_204.GetRawRoot__O()).Invoke_O_O__O(x__0, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_205, raw__1))) } else {
//line :268:1
						return nil
					}
			}
		}
	} }
func A_arbace_repr_go_convert_lit_spelling_A_New() *A_arbace_repr_go_convert_lit_spelling_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_lit_spelling_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_repr_go_convert_lit_spelling_A) Ctor() {}
//line :273:1
func (t *A_arbace_repr_go_convert_lit_spelling_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(x__0)) { var v__2 any = A_arbace_repr_go_convert_A_const_206.Invoke_O__O(x__0)

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_29.GetRawRoot__O()).Invoke_O__O(v__2)) {
			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_207.GetRawRoot__O()).Invoke_O__O(v__2) } else {
//line :278:1
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(v__2)) {

					return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_209.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(lang.RT_IntCast_O__I(v__2))).Ref()) } else {
//line :278:1
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_210.GetRawRoot__O()).Invoke_O__O(v__2)) {


							return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_211.GetRawRoot__O()).Invoke_O__O(v__2) } else {
//line :278:1
								if A_arbace_repr_go_convert_A_const_152 != nil {



									return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_212.GetRawRoot__O()).Invoke_O__O(v__2) } else {
//line :278:1
										return nil } } } } } else {
//line :276:1
											var G__1114000095__2_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_212.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(x__0))






											switch lang.Util_Hash_O__I(G__1114000095__2_) >> 1 & 3 { case 0: if lang.Util_Equiv_O_O__Z(G__1114000095__2_, Lit_173) {

												var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_206; return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_174), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_211.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0))), nil)).Ref() }
//line :283:1
											case 1: if lang.Util_Equiv_O_O__Z(G__1114000095__2_, Lit_175) {
												var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_206; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_209.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0)))).Ref()) }
//line :283:1
											case 3: if lang.Util_Equiv_O_O__Z(G__1114000095__2_, Lit_176) {


												var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_A_const_206; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_213.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(x__0))) }
//line :283:1
											default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1114000095__2_)))))
										}
}


func A_arbace_repr_go_convert_basic_lit_A_New() *A_arbace_repr_go_convert_basic_lit_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_basic_lit_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_repr_go_convert_basic_lit_A) Ctor() {}
//line :288:1
func (t *A_arbace_repr_go_convert_basic_lit_A) Invoke_O_O__O(self, n__0 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :288:1
	var map__1114000097__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var map__1114000097__3 any

	if lang.ISeq_InstanceOf(map__1114000097__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000097__2)) { map__1114000097__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000097__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000097__2)) { map__1114000097__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000097__2) } else { lang.PersistentArrayMap_Init(); map__1114000097__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000097__3 = map__1114000097__2 }
//line :288:1
	var kind__4 any = lang.RT_Get_O_O__O(map__1114000097__3, A_arbace_repr_go_convert_A_const_178); var value__5 any = lang.RT_Get_O_O__O(map__1114000097__3, A_arbace_repr_go_convert_A_const_206); var l__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var p__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(n__0)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_216.GetRawRoot__O()); var tmp2 any
	var G__1114000099__8_ any = kind__4



L1: switch { default: switch lang.Util_Hash_O__I(G__1114000099__8_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z(G__1114000099__8_, Lit_10) { var r__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_217.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_220.GetRawRoot__O()).Invoke_O__O(value__5))






	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(r__9)) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(l__6, r__9, p__7) } else { tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()).Invoke_O_O__O(r__9, nil), n__0, l__6) }
//line :293:1
	break L1 }; case 2: if lang.Util_Equiv_O_O__Z(G__1114000099__8_, Lit_11) {


		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_A_const_221; tmp2 = tmp3.Invoke_O_O_O_O__O(n__0, l__6, tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_222.GetRawRoot__O()).Invoke_O__O(value__5))
//line :293:1
		break L1 }; case 4: if lang.Util_Equiv_O_O__Z(G__1114000099__8_, Lit_12) {

			tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(l__6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_223.GetRawRoot__O()).Invoke_O__O(value__5), p__7)
//line :293:1
			break L1 }; case 6: if lang.Util_Equiv_O_O__Z(G__1114000099__8_, Lit_13) { var r__9_2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_224.GetRawRoot__O()).Invoke_O__O(value__5))




				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(r__9_2)) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(l__6, r__9_2, p__7) } else { tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()).Invoke_O_O__O(r__9_2, nil), n__0, l__6) }
//line :293:1
				break L1 }; case 7: if lang.Util_Equiv_O_O__Z(G__1114000099__8_, Lit_14) {
					tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(l__6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_225.GetRawRoot__O()).Invoke_O__O(value__5), p__7)
//line :293:1
					break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1114000099__8_)))))
}






	return tmp1.Invoke_O_O_O__O(tmp2, value__5, A_arbace_repr_go_convert_A_const_219.GetRawRoot__O())
}
func A_arbace_repr_go_convert_string_value_A_New() *A_arbace_repr_go_convert_string_value_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_string_value_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_repr_go_convert_string_value_A) Ctor() {}
//line :303:1
func (t *A_arbace_repr_go_convert_string_value_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_206; return jrt.String_New_B1_Charset(jrt.J2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_220.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0))), jrt.Prim_byte.ArrayClass()), jrt.StandardCharsets_UTF_8) }








func A_arbace_repr_go_convert_tagged_A_New() *A_arbace_repr_go_convert_tagged_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_tagged_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_repr_go_convert_tagged_A) Ctor() {}
//line :312:1
func (t *A_arbace_repr_go_convert_tagged_A) Invoke_O_O_O__O(self, sym__0, t__1 any) any {


	if jrt.J2g_Truth(t__1) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()).Invoke_O_O_O_O__O(sym__0, A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_226, t__1) } else { return sym__0
	} }
func A_arbace_repr_go_convert_group_marks_A_New() *A_arbace_repr_go_convert_group_marks_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_group_marks_A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_repr_go_convert_group_marks_A) Ctor() {}
//line :317:1
func (t *A_arbace_repr_go_convert_group_marks_A) Invoke_O_O__O(self, syms__0 any) any {



	if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_227.Get__O()) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(syms__0); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_group_marks_fn__1114000104_A_New(); var tmp5 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_go_convert_group_marks_fn__1114000104_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_150, false); A_arbace_repr_go_convert_group_marks_fn__1114000104_A_fn_class = fncls__16d; tmp5 = fncls__16d } else { tmp5 = fncls__16 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(syms__0))) } else {
//line :321:1
			return syms__0 } }
func A_arbace_repr_go_convert_group_marks_fn__1114000104_A_New() *A_arbace_repr_go_convert_group_marks_fn__1114000104_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_group_marks_fn__1114000104_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_repr_go_convert_group_marks_fn__1114000104_A) Ctor() {}
//line :322:1
func (t *A_arbace_repr_go_convert_group_marks_fn__1114000104_A) Invoke_O_O__O(self, p1__1114000103_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp3 any = A_arbace_repr_go_convert_A_const_229; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(p1__1114000103_SHARP___1, tmp2, tmp3, tmp4.Ref()) }


func A_arbace_repr_go_convert_mark_ungrouped_A_New() *A_arbace_repr_go_convert_mark_ungrouped_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_mark_ungrouped_A{}; t.Ctor(); return t }
//line :325:1
func (t *A_arbace_repr_go_convert_mark_ungrouped_A) Ctor() {}
//line :325:1
func (t *A_arbace_repr_go_convert_mark_ungrouped_A) Invoke_O_O_O__O(self, elems__0, names_only__1 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_227.Get__O())) { return elems__0 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A_New_O_O(names_only__1, elems__0); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A_fn_class
		if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_177, false); A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }
//line :331:1
		return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), elems__0)) } }
func A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A{}; t.Ctor_O_O(p0, p1); return t }
//line :332:1
func (t *A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A) Ctor_O_O(c__names_only, c__elems any) { t.F_names_only = c__names_only; t.F_elems = c__elems }
//line :332:1
func (t *A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { var prev__3 any; if
														lang.Numbers_IsPos_O__Z(i__1) { var tmp1 any = t.F_elems; prev__3 = lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(i__1))) } else { prev__3 = nil }; var tmp2 any; var and__1927000168__auto____4 any =
														lang.IFn_Cast(A_arbace_repr_go_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(x__2); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(prev__3); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(x__2), A_arbace_repr_go_convert_A_const_229)); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(t.F_names_only)
															if jrt.J2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7 = or__1927000174__auto____7 } else { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_226; var and__1927000168__auto____8 any = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__2)); if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_226; and__1927000168__auto____7 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(prev__3)) } else { and__1927000168__auto____7 = and__1927000168__auto____8 } }
//line :334:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {

			var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_226; var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_226; tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__2)), tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(prev__3)))).Ref() } else {
//line :334:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) {


					var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp9 any = A_arbace_repr_go_convert_A_const_229; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; return tmp7.Invoke_O_O_O_O__O(x__2, tmp8, tmp9, tmp10.Ref()) } else {
//line :334:1
						return x__2 } }






func A_arbace_repr_go_convert_doc_of_A_New() *A_arbace_repr_go_convert_doc_of_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_doc_of_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_repr_go_convert_doc_of_A) Ctor() {}
//line :341:1
func (t *A_arbace_repr_go_convert_doc_of_A) Invoke_O_O_O__O(self, pos_str__0, groups__1 any) any {


	if jrt.J2g_Truth(pos_str__0) { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O(groups__1, pos_str__0)
		if jrt.J2g_Truth(temp__1927000414__auto____3) { var g__4 any = temp__1927000414__auto____3
			if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_234.Get__O()) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_convert_A_const_234.Get__O(), A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), pos_str__0) }
//line :345:1
			var t__5 any = A_arbace_repr_go_convert_A_const_232.Invoke_O__O(g__4); var tmp1 any
			var and__1927000168__auto____6 any = t__5

			if jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(t__5, Lit_9) } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { return t__5 } else { return nil } } else {
//line :345:1
				return nil } } else {
//line :344:1
					return nil
				}
}





func A_arbace_repr_go_convert_fields_A_New() *A_arbace_repr_go_convert_fields_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_fields_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_repr_go_convert_fields_A) Ctor() {}
//line :352:1
func (t *A_arbace_repr_go_convert_fields_A) Invoke_O_O_O__O(self, field_list__0, p__1114000111__1 any) any { var map__1114000112__3 any = p__1114000111__1; var map__1114000112__4 any; if lang.ISeq_InstanceOf(map__1114000112__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000112__3)) { map__1114000112__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000112__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000112__3)) { map__1114000112__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000112__3) } else { lang.PersistentArrayMap_Init(); map__1114000112__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000112__4 = map__1114000112__3 }; var struct_QMARK___5 any = lang.RT_Get_O_O__O(map__1114000112__4, A_arbace_repr_go_convert_A_const_235);




	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(field_list__0); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_236.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_237.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_fields_fn__1114000114_A_New_O(struct_QMARK___5); var tmp5 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_go_convert_fields_fn__1114000114_A_fn_class; if


	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_repr_go_convert_fields_fn__1114000114_A_fn_class = fncls__21d; tmp5 = fncls__21d } else { tmp5 = fncls__21 }; var tmp6 /*line :358:1*/*lang.Keyword = A_arbace_repr_go_convert_A_const_72; var tmp7 any = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(field_list__0)))); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(tmp7, tmp8.Ref()) }


func A_arbace_repr_go_convert_fields_fn__1114000114_A_New_O(p0 any) *A_arbace_repr_go_convert_fields_fn__1114000114_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_fields_fn__1114000114_A{}; t.Ctor_O(p0); return t }
//line :361:1
func (t *A_arbace_repr_go_convert_fields_fn__1114000114_A) Ctor_O(c__struct_QMARK_ any) { t.F_struct_QMARK_ = c__struct_QMARK_ }
//line :361:1
func (t *A_arbace_repr_go_convert_fields_fn__1114000114_A) Invoke_O_O__O(self, fld__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(fld__1)
//line :361:1
	var map__1114000115__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(fld__1); var map__1114000115__3 any

	if lang.ISeq_InstanceOf(map__1114000115__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000115__2)) { map__1114000115__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000115__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000115__2)) { map__1114000115__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000115__2) } else { lang.PersistentArrayMap_Init(); map__1114000115__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000115__3 = map__1114000115__2 }
//line :361:1
	var names__4 any = lang.RT_Get_O_O__O(map__1114000115__3, A_arbace_repr_go_convert_A_const_54); var type__5 any = lang.RT_Get_O_O__O(map__1114000115__3, A_arbace_repr_go_convert_A_const_60); var tag__6 any = lang.RT_Get_O_O__O(map__1114000115__3, A_arbace_repr_go_convert_A_const_226); var doc__7 any = lang.RT_Get_O_O__O(map__1114000115__3, A_arbace_repr_go_convert_A_const_238); var tmp1 any = A_arbace_repr_go_convert_A_const_43; var variadic__8 bool = lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(type__5)); var ___9 any; _ = ___9



	if variadic__8 { ___9 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(type__5) } else { ___9 = nil }
//line :361:1
	var ___10 any; var tmp2 any; var and__1927000168__auto____10 any = t.F_struct_QMARK_; _ = ___10




	if jrt.J2g_Truth(and__1927000168__auto____10) { tmp2 = tag__6 } else { tmp2 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp2) { ___10 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(tag__6) } else { ___10 = nil }
//line :361:1
	var t__11 any





	if variadic__8 {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(type__5); var tmp5 any = A_arbace_repr_go_convert_A_const_244; var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_245; t__11 = tmp3.Invoke_O_O_O_O__O(type__5, tmp4, tmp5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(type__5)))) } else {
			t__11 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__5) }
//line :361:1
	var extra__12 any; var G__1114000117__12_ any; lang.PersistentArrayMap_Init(); G__1114000117__12_ = lang.PersistentArrayMap_EMPTY.Ref(); var G__1114000117__13_ any; var tmp7 any; var and__1927000168__auto____13 any = t.F_struct_QMARK_









	if jrt.J2g_Truth(and__1927000168__auto____13) { tmp7 = tag__6 } else { tmp7 = and__1927000168__auto____13 }
//line :370:1
	if jrt.J2g_Truth(tmp7) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_A_const_246; G__1114000117__13_ = tmp8.Invoke_O_O_O__O(G__1114000117__12_, tmp9, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_247.GetRawRoot__O()).Invoke_O__O(tag__6)) } else {
//line :370:1
			G__1114000117__13_ = G__1114000117__12_ }; var tmp10 any; var and__1927000168__auto____14 any = t.F_struct_QMARK_

	if jrt.J2g_Truth(and__1927000168__auto____14) { tmp10 = doc__7 } else { tmp10 = and__1927000168__auto____14 }
//line :370:1
	if jrt.J2g_Truth(tmp10) { var m__14 any = G__1114000117__13_; var temp__1927000408__auto____15 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_240.GetRawRoot__O()).Invoke_O_O__O(doc__7, A_arbace_repr_go_convert_A_const_248.Get__O())

		if jrt.J2g_Truth(temp__1927000408__auto____15) { var d__16 any = temp__1927000408__auto____15; extra__12 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()).Invoke_O_O_O__O(m__14, A_arbace_repr_go_convert_A_const_238, d__16) } else { extra__12 = m__14 } } else {
//line :370:1
			extra__12 = G__1114000117__13_ }
//line :361:1
	var tag_full__13 any; var tmp11 any; var and__1927000168__auto____13_2 any = t.F_struct_QMARK_












	if jrt.J2g_Truth(and__1927000168__auto____13_2) { tmp11 = tag__6 } else { tmp11 = and__1927000168__auto____13_2 }; if jrt.J2g_Truth(tmp11) { var tmp12 any = A_arbace_repr_go_convert_A_const_241; var tmp13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(tag__6)); var tmp14 any = A_arbace_repr_go_convert_A_const_242; var tmp15 *lang.Keyword = A_arbace_repr_go_convert_A_const_206; tag_full__13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(tag__6)))) } else { tag_full__13 = nil
	}
	var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp17 any
	if variadic__8 { tmp17 = A_arbace_repr_go_convert_A_const_249 } else { tmp17 = nil }
//line :376:1
	var tmp18 any = tmp17; var tmp19 any

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(names__4)) {
		var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_250.GetRawRoot__O()); var tmp21 any; var iter__1927001039__auto____14 any; var tmp22 any = A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A_New_O_O_O(extra__12, tag_full__13, t__11); var tmp23 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A_fn_class
		if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A_fn_class = fncls__20d; tmp23 = fncls__20d } else { tmp23 = fncls__20 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); tmp21 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(names__4)
//line :379:1
		tmp19 = tmp20.Invoke_O__O(tmp21) } else {
//line :378:1
			tmp19 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_204.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(t__11, extra__12), tag_full__13)) }
//line :376:1
	return tmp16.Invoke_O_O__O(tmp18, tmp19)
}


func A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :380:1
func (t *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A) Ctor_O_O_O(c__extra, c__tag_full, c__t any) { t.F_extra = c__extra; t.F_tag_full = c__tag_full; t.F_t = c__t }
//line :380:1
func (t *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A) Invoke_O_O__O(self, s__1114000119__1 any) any { var tmp1 any = A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A_New_O_O_O_O_O(self, t.F_extra, t.F_tag_full, t.F_t, s__1114000119__1); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :380:1
func A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :380:1
func (t *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A) Ctor_O_O_O_O_O(c__iter__1114000118, c__extra, c__tag_full, c__t, c__s__1114000119 any) { t.F_iter__1114000118 = c__iter__1114000118; t.F_extra = c__extra; t.F_tag_full = c__tag_full; t.F_t = c__t; t.F_s__1114000119 = c__s__1114000119 }
//line :380:1
func (t *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A) Invoke_O__O(self any) any { { var s__1114000119__1 any; var t_ any = t.F_s__1114000119; t.F_s__1114000119 = nil; s__1114000119__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000119__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000119__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000119__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000119__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000121__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A_New_O_O_O_I_O_O(t.F_extra, t.F_tag_full, t.F_t, size__1927001038__auto____5, c__1927001037__auto____4, b__1114000121__6); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, false); A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000118); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000121__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000119__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000121__6), nil) } } else { var nm__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000119__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1114000118); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_204.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_253.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(nm__4), t.F_t), t.F_extra), t.F_tag_full), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000119__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :380:1
func A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :380:1
func (t *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A) Ctor_O_O_O_I_O_O(c__extra, c__tag_full, c__t any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1114000121 any) { t.F_extra = c__extra; t.F_tag_full = c__tag_full; t.F_t = c__t; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1114000121 = c__b__1114000121 }
//line :380:1
func (t *A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A) Invoke_O__O(self any) any { { var i__1114000120__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000120__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000120__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000121; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_204.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_253.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(nm__2), t.F_t), t.F_extra), t.F_tag_full)); i__1114000120__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000120__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_repr_go_convert_interface_elems_A_New() *A_arbace_repr_go_convert_interface_elems_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_interface_elems_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_repr_go_convert_interface_elems_A) Ctor() {}
//line :386:1
func (t *A_arbace_repr_go_convert_interface_elems_A) Invoke_O_O__O(self, field_list__0 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(field_list__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A_fn_class
	if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_170, false); A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(field_list__0)))
//line :388:1
	return tmp1.Invoke_O__O(tmp2) }
func A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A_New() *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A{}; t.Ctor(); return t }
//line :389:1
func (t *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A) Ctor() {}
//line :389:1
func (t *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A) Invoke_O_O__O(self, s__1114000131__1 any) any { var tmp1 any = A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A_New_O_O(s__1114000131__1, self); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_171, false); A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :389:1
func A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A{}; t.Ctor_O_O(p0, p1); return t }
//line :389:1
func (t *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A) Ctor_O_O(c__s__1114000131, c__iter__1114000130 any) { t.F_s__1114000131 = c__s__1114000131; t.F_iter__1114000130 = c__iter__1114000130 }
//line :389:1
func (t *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A) Invoke_O__O(self any) any { { var s__1114000131__1 any; var t_ any = t.F_s__1114000131; t.F_s__1114000131 = nil; s__1114000131__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000131__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000131__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000131__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000131__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000133__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A_New_O_I_O(b__1114000133__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_172, false); A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000130); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000133__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000131__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000133__6), nil) } } else { var fld__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000131__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp5 any; var map__1114000143__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(fld__4); var map__1114000143__6 any
																if lang.ISeq_InstanceOf(map__1114000143__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000143__5)) { map__1114000143__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000143__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000143__5)) { map__1114000143__6 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000143__5) } else { lang.PersistentArrayMap_Init(); map__1114000143__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000143__6 = map__1114000143__5 }
//line :389:1
	var names__7 any = lang.RT_Get_O_O__O(map__1114000143__6, A_arbace_repr_go_convert_A_const_54); var type__8 any = lang.RT_Get_O_O__O(map__1114000143__6, A_arbace_repr_go_convert_A_const_60); var doc__9 any = lang.RT_Get_O_O__O(map__1114000143__6, A_arbace_repr_go_convert_A_const_238); var d__10 any

	if jrt.J2g_Truth(doc__9) { d__10 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_240.GetRawRoot__O()).Invoke_O_O__O(doc__9, A_arbace_repr_go_convert_A_const_248.Get__O()) } else { d__10 = nil }
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(fld__4)
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(names__7)) { var nm__11 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(names__7); var ___12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(type__8); var vec__1114000145__13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_256.GetRawRoot__O()).Invoke_O__O(type__8); var seq__1114000146__14 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(vec__1114000145__13); var first__1114000147__15 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1114000146__14); var seq__1114000146__16 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq__1114000146__14); var ps__17 any = first__1114000147__15; var rs__18 any = seq__1114000146__16; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_A_const_142.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(nm__11); var tmp11 lang.IPersistentMap; _ = ___12



		if jrt.J2g_Truth(d__10) { tmp11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_238, d__10)) } else { tmp11 = nil }; tmp5 = tmp6.Invoke_O_O_O__O(tmp7.Invoke_O_O_O_O__O(tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11), ps__17, rs__18), fld__4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(fld__4)) } else {
			var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__8); var tmp14 lang.IPersistentMap; if jrt.J2g_Truth(d__10) { tmp14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_238, d__10)) } else { tmp14 = nil }; tmp5 = tmp12.Invoke_O_O__O(tmp13, tmp14) }
//line :389:1
	var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1114000130); return tmp4.Invoke_O_O__O(tmp5, tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000131__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :389:1
func A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :389:1
func (t *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A) Ctor_O_I_O(c__b__1114000133 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000133 = c__b__1114000133; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :389:1
func (t *A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A) Invoke_O__O(self any) any { { var i__1114000132__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000132__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fld__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000132__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000133; var tmp4 any; var map__1114000137__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(fld__2); var map__1114000137__4 any
																		if lang.ISeq_InstanceOf(map__1114000137__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000137__3)) { map__1114000137__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000137__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000137__3)) { map__1114000137__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000137__3) } else { lang.PersistentArrayMap_Init(); map__1114000137__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000137__4 = map__1114000137__3 }
//line :389:1
	var names__5 any = lang.RT_Get_O_O__O(map__1114000137__4, A_arbace_repr_go_convert_A_const_54); var type__6 any = lang.RT_Get_O_O__O(map__1114000137__4, A_arbace_repr_go_convert_A_const_60); var doc__7 any = lang.RT_Get_O_O__O(map__1114000137__4, A_arbace_repr_go_convert_A_const_238); var d__8 any

	if jrt.J2g_Truth(doc__7) { d__8 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_240.GetRawRoot__O()).Invoke_O_O__O(doc__7, A_arbace_repr_go_convert_A_const_248.Get__O()) } else { d__8 = nil }
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(fld__2)
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(names__5)) { var nm__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(names__5); var ___10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(type__6); var vec__1114000139__11 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_256.GetRawRoot__O()).Invoke_O__O(type__6); var seq__1114000140__12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(vec__1114000139__11); var first__1114000141__13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1114000140__12); var seq__1114000140__14 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq__1114000140__12); var ps__15 any = first__1114000141__13; var rs__16 any = seq__1114000140__14; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_142.GetRawRoot__O(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(nm__9); var tmp10 lang.IPersistentMap; _ = ___10



		if jrt.J2g_Truth(d__8) { tmp10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_238, d__8)) } else { tmp10 = nil }; tmp4 = tmp5.Invoke_O_O_O__O(tmp6.Invoke_O_O_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10), ps__15, rs__16), fld__2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(fld__2)) } else {
			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__6); var tmp13 lang.IPersistentMap; if jrt.J2g_Truth(d__8) { tmp13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_238, d__8)) } else { tmp13 = nil }; tmp4 = tmp11.Invoke_O_O__O(tmp12, tmp13) }
//line :389:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1114000132__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000132__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_repr_go_convert_type_form_A_New() *A_arbace_repr_go_convert_type_form_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_form_A{}; t.Ctor(); return t }
//line :400:1
func (t *A_arbace_repr_go_convert_type_form_A) Ctor() {}
//line :400:1
func (t *A_arbace_repr_go_convert_type_form_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any = A_arbace_repr_go_convert_A_const_55; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0)) { } else { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :400:1
	var f__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var l__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var G__1114000151__4_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0)





	switch lang.Util_Hash_O__I(G__1114000151__4_) >> 7 & 63 { case 1: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_43) {

















































		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_264; return tmp2.Invoke_O_O_O_O__O(n__0, l__3, tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_245.Invoke_O__O(f__2))) }
//line :406:1
	case 3: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_62) { var G__1114000152__5_ any = A_arbace_repr_go_convert_A_const_257.Invoke_O__O(f__2)














		switch lang.Util_Hash_O__I(G__1114000152__5_) >> 7 & 3 { case 0: if any(G__1114000152__5_) == any(A_arbace_repr_go_convert_A_const_258) {


			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_265; var tmp6 any = A_arbace_repr_go_convert_A_const_258; return tmp4.Invoke_O_O_O_O_O__O(n__0, l__3, tmp5, tmp6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_206.Invoke_O__O(f__2))) }
//line :421:1
		case 2: if any(G__1114000152__5_) == any(A_arbace_repr_go_convert_A_const_259) {
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_A_const_266; return tmp7.Invoke_O_O_O_O__O(n__0, l__3, tmp8, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_206.Invoke_O__O(f__2))) }
//line :421:1
		case 3: if any(G__1114000152__5_) == any(A_arbace_repr_go_convert_A_const_260) {

			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_convert_A_const_267; var tmp11 any = A_arbace_repr_go_convert_A_const_260; return tmp9.Invoke_O_O_O_O_O__O(n__0, l__3, tmp10, tmp11, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_206.Invoke_O__O(f__2))) }
//line :421:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1114000152__5_))))) }
//line :406:1
	case 7: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_81) {



























		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp14 any = A_arbace_repr_go_convert_A_const_269; var tmp15 any = A_arbace_repr_go_convert_A_const_61; var tmp16 *lang.Keyword = A_arbace_repr_go_convert_A_const_71; var tmp17 any = tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_271.Invoke_O__O(f__2))); var tmp18 any = A_arbace_repr_go_convert_A_const_158; var tmp19 *lang.Keyword = A_arbace_repr_go_convert_A_const_268; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(tmp12.Invoke_O_O_O_O_O__O(tmp13, n__0, l__3, tmp14, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_270.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_271.Invoke_O__O(f__2))), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp17, tmp18, tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_271.Invoke_O__O(f__2)))))) }
//line :406:1
	case 21: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_73) { var g__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)); var args__6 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp21 any = A_arbace_repr_go_convert_A_const_239.GetRawRoot__O(); var tmp22 any
		var tmp23 any = A_arbace_repr_go_convert_A_const_73





























		if lang.Util_Equiv_O_O__Z(tmp23, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp22 = lang.Tuple_Create_O__IPersistentVector(A_arbace_repr_go_convert_A_const_273.Invoke_O__O(f__2)) } else { tmp22 = A_arbace_repr_go_convert_A_const_272.Invoke_O__O(f__2) }; args__6 = tmp20.Invoke_O_O__O(tmp21, tmp22)
		var tmp24 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(g__5); if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_262.GetRawRoot__O()).Invoke_O__O(g__5), nil); if and__1927000168__auto____8 { tmp24 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_263.GetRawRoot__O()).Invoke_O__O(g__5) } else { tmp24 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp24 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp24) {
			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__3, A_arbace_repr_go_convert_A_const_274, g__5, args__6) } else {
				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__3, g__5, args__6) } }
//line :406:1
	case 27: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_102) { var g__5_2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)); var args__6_2 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp26 any = A_arbace_repr_go_convert_A_const_239.GetRawRoot__O(); var tmp27 any
		var tmp28 any = A_arbace_repr_go_convert_A_const_73





























		if lang.Util_Equiv_O_O__Z(tmp28, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp27 = lang.Tuple_Create_O__IPersistentVector(A_arbace_repr_go_convert_A_const_273.Invoke_O__O(f__2)) } else { tmp27 = A_arbace_repr_go_convert_A_const_272.Invoke_O__O(f__2) }; args__6_2 = tmp25.Invoke_O_O__O(tmp26, tmp27)
		var tmp29 any; var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(g__5_2); if jrt.J2g_Truth(and__1927000168__auto____7_2) { var and__1927000168__auto____8_2 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_262.GetRawRoot__O()).Invoke_O__O(g__5_2), nil); if and__1927000168__auto____8_2 { tmp29 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_263.GetRawRoot__O()).Invoke_O__O(g__5_2) } else { tmp29 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8_2).Ref() } } else { tmp29 = and__1927000168__auto____7_2 }; if jrt.J2g_Truth(tmp29) {
			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__3, A_arbace_repr_go_convert_A_const_274, g__5_2, args__6_2) } else {
				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__3, g__5_2, args__6_2) } }
//line :406:1
	case 29: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_112) {

























		var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp31 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp32 any = A_arbace_repr_go_convert_A_const_276; var tmp33 any = A_arbace_repr_go_convert_A_const_61; var tmp34 *lang.Keyword = A_arbace_repr_go_convert_A_const_71; var tmp35 any = tmp34.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_278.Invoke_O__O(f__2))); var tmp36 any = A_arbace_repr_go_convert_A_const_158; var tmp37 *lang.Keyword = A_arbace_repr_go_convert_A_const_268; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(tmp30.Invoke_O_O_O_O_O__O(tmp31, n__0, l__3, tmp32, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_277.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_278.Invoke_O__O(f__2), A_arbace_repr_go_convert_A_const_279)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp35, tmp36, tmp37.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_278.Invoke_O__O(f__2)))))) }
//line :406:1
	case 33: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_41) {








		if lang.Util_Identical_O_O__Z(A_arbace_repr_go_convert_A_const_275.Invoke_O__O(f__2), nil) {
			var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp39 any = A_arbace_repr_go_convert_A_const_281; return tmp38.Invoke_O_O_O_O__O(n__0, l__3, tmp39, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_245.Invoke_O__O(f__2))) } else {
//line :415:1
				var tmp40 any = A_arbace_repr_go_convert_A_const_43; if lang.Util_Equiv_O_O__Z(tmp40, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_275.Invoke_O__O(f__2))) {

					lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_275.Invoke_O__O(f__2))
					var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp42 any = A_arbace_repr_go_convert_A_const_282; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()); var tmp44 any = A_arbace_repr_go_convert_A_const_283; return tmp41.Invoke_O_O_O_O_O__O(n__0, l__3, tmp42, tmp43.Invoke_O_O_O__O(tmp44, A_arbace_repr_go_convert_A_const_275.Invoke_O__O(f__2), l__3), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_245.Invoke_O__O(f__2))) } else {
//line :415:1
						if A_arbace_repr_go_convert_A_const_152 != nil {



							var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp46 any = A_arbace_repr_go_convert_A_const_284; return tmp45.Invoke_O_O_O_O_O__O(n__0, l__3, tmp46, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_275.Invoke_O__O(f__2)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_245.Invoke_O__O(f__2))) } else {
//line :415:1
								return nil } } } }
//line :406:1
	case 34: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_52) {














































		if lang.Util_Equiv_O_O__Z(Lit_116, A_arbace_repr_go_convert_A_const_280.Invoke_O__O(f__2)) {
			var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp48 any = A_arbace_repr_go_convert_A_const_286; return tmp47.Invoke_O_O_O_O__O(n__0, l__3, tmp48, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2))) } else {
				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_232, n__0) } }
//line :406:1
	case 36: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_66) {













		var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp50 any = A_arbace_repr_go_convert_A_const_288; return tmp49.Invoke_O_O_O_O_O__O(n__0, l__3, tmp50, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_86.Invoke_O__O(f__2)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_206.Invoke_O__O(f__2))) }
//line :406:1
	case 40: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_85) {


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_287.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2))) {
			lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2))); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(f__2))

			var tmp51 any = A_arbace_repr_go_convert_A_const_291; var tmp52 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)); var tmp53 any = A_arbace_repr_go_convert_A_const_56; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(f__2))), n__0, l__3), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp51, tmp52, tmp53, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(f__2))))) } else {
				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_233, n__0) } }
//line :406:1
	case 44: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_104) {


































		if lang.Util_Equiv_O_O__Z(Lit_234, A_arbace_repr_go_convert_A_const_280.Invoke_O__O(f__2)) { var vec__1114000153__5 any; var tmp54 any = A_arbace_repr_go_convert_type_form_fn__1114000156_A_New_O(f__2); var tmp55 *jrt.Class
			var fncls__27 /*line :441:1*/*jrt.Class = A_arbace_repr_go_convert_type_form_fn__1114000156_A_fn_class

			if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_235, false); A_arbace_repr_go_convert_type_form_fn__1114000156_A_fn_class = fncls__27d; tmp55 = fncls__27d } else { tmp55 = fncls__27 }; vec__1114000153__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp54, tmp55, nil).Invoke__O()
//line :441:1
			var terms__6 any = lang.RT_Nth_O_I_O__O(vec__1114000153__5, lang.RT_IntCast_J__I(0), nil); var ops__7 any = lang.RT_Nth_O_I_O__O(vec__1114000153__5, lang.RT_IntCast_J__I(1), nil); var G__1114000158__8_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__3, A_arbace_repr_go_convert_A_const_292, terms__6)








			if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ops__7)), 1) {
				var tmp56 any = A_arbace_repr_go_convert_A_const_293; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_204.GetRawRoot__O()).Invoke_O_O__O(G__1114000158__8_, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp56, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(ops__7)))) } else {
//line :450:1
					return G__1114000158__8_ } } else {

						return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_236, n__0) } }
//line :406:1
	case 45: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_32) {

		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_156.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)), n__0) }
//line :406:1
	case 50: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_55) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :406:1
	case 58: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_98) {







		var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp58 any = A_arbace_repr_go_convert_A_const_297; return tmp57.Invoke_O_O_O_O__O(n__0, l__3, tmp58, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2))) }
//line :406:1
	case 59: if any(G__1114000151__4_) == any(A_arbace_repr_go_convert_A_const_100) { var ps__5 any; var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_277.GetRawRoot__O()); var tmp60 any = A_arbace_repr_go_convert_A_const_103.Invoke_O__O(f__2); var tmp61 *lang.PersistentArrayMap


















		lang.PersistentArrayMap_Init(); tmp61 = lang.PersistentArrayMap_EMPTY; ps__5 = tmp59.Invoke_O_O__O(tmp60, tmp61.Ref())
//line :406:1
		var rs__6 any



















		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2)) { var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_277.GetRawRoot__O()); var tmp63 any = A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2); var tmp64 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp64 = lang.PersistentArrayMap_EMPTY; rs__6 = tmp62.Invoke_O_O__O(tmp63, tmp64.Ref()) } else { rs__6 = nil }
//line :406:1
		var fl_pos__7 any; var tmp65 any = A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A_New(); var tmp66 *jrt.Class
		var fncls__28 /*line :406:1*/*jrt.Class = A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A_fn_class




















		if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_237, false); A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A_fn_class = fncls__28d; tmp66 = fncls__28d } else { tmp66 = fncls__28 }; fl_pos__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp65, tmp66, nil)
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(rs__6)) {
			var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp68 any = A_arbace_repr_go_convert_A_const_298; return tmp67.Invoke_O_O_O_O_O__O(n__0, l__3, tmp68, lang.IFn_Cast(fl_pos__7).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__3, ps__5), A_arbace_repr_go_convert_A_const_103.Invoke_O__O(f__2)), lang.IFn_Cast(fl_pos__7).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__3, rs__6), A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2))) } else {
				var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp70 any = A_arbace_repr_go_convert_A_const_300; return tmp69.Invoke_O_O_O_O__O(n__0, l__3, tmp70, lang.IFn_Cast(fl_pos__7).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__3, ps__5), A_arbace_repr_go_convert_A_const_103.Invoke_O__O(f__2))) } }
//line :406:1
	default:
	}

















































	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_101, n__0) }
//line :427:1
func A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A_New() *A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A{}; t.Ctor(); return t }
//line :427:1
func (t *A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A) Ctor() {}
//line :427:1
func (t *A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A) Invoke_O_O_O__O(self, v__1, fl__2 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(v__1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_295.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(fl__2), A_arbace_repr_go_convert_A_const_296)) }















func A_arbace_repr_go_convert_type_form_fn__1114000156_A_New_O(p0 any) *A_arbace_repr_go_convert_type_form_fn__1114000156_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_form_fn__1114000156_A{}; t.Ctor_O(p0); return t }
//line :443:1
func (t *A_arbace_repr_go_convert_type_form_fn__1114000156_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :443:1
func (t *A_arbace_repr_go_convert_type_form_fn__1114000156_A) Invoke_O__O(self any) any { { var x__1 any = A_arbace_repr_go_convert_A_const_34.Invoke_O__O(t.F_f); var acc__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_289.Invoke_O__O(t.F_f))); var ops__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_53; var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; ops__3 = tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4))); L1: for {
											var tmp5 any = A_arbace_repr_go_convert_A_const_32; if lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(x__1)) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :443:1
	var x__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(x__1); var tmp6 bool; var tmp7 any = A_arbace_repr_go_convert_A_const_104; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(x__4))


	if and__1927000168__auto____5 { var tmp8 *lang.Keyword = A_arbace_repr_go_convert_A_const_280; tmp6 = lang.Util_Equiv_O_O__Z(Lit_234, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4))) } else { tmp6 = and__1927000168__auto____5 }; if tmp6 {
		var tmp9 any; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(x__4); var tmp10 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; tmp9 = tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)); var tmp11 *lang.Keyword = A_arbace_repr_go_convert_A_const_289; var tmp12 *lang.Keyword = A_arbace_repr_go_convert_A_const_53; x__1, acc__2, ops__3 = tmp9, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4))), acc__2), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4))), ops__3); continue L1 } else {
//line :446:1
			return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(x__4), acc__2), ops__3) } } }; /*line :443:1*/panic("j2g: unreachable") }

















func A_arbace_repr_go_convert_signature_A_New() *A_arbace_repr_go_convert_signature_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_signature_A{}; t.Ctor(); return t }
//line :461:1
func (t *A_arbace_repr_go_convert_signature_A) Ctor() {}
//line :461:1
func (t *A_arbace_repr_go_convert_signature_A) Invoke_O_O__O(self, ft__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(ft__0); var l__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(ft__0); var ps__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_71; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_125.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_103.Invoke_O__O(f__2)))); if





	jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { tmp3 = l__3 }; var tmp5 any = tmp3; var tmp6 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_277.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_103.Invoke_O__O(f__2); var tmp8 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp8 = lang.PersistentArrayMap_EMPTY; ps__4 = tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8.Ref())), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_295.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_103.Invoke_O__O(f__2)), A_arbace_repr_go_convert_A_const_301)); var rlist__5 any; if
	jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2)) { var tmp9 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; rlist__5 = tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2))) } else { rlist__5 = nil }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_161.GetRawRoot__O()).Invoke_O__O(rlist__5)) {
		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2)) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2)) }
//line :470:1
		return lang.Tuple_Create_O__IPersistentVector(ps__4) } else { var tmp10 any; var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(rlist__5)))

			if and__1927000168__auto____6 { var tmp11 *lang.Keyword = A_arbace_repr_go_convert_A_const_54; tmp10 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_161.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rlist__5)))) } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() }
//line :470:1
			if jrt.J2g_Truth(tmp10) {


				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rlist__5)); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2))
//line :470:1
				var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp14 any = A_arbace_repr_go_convert_A_const_226; var tmp15 *lang.Keyword = A_arbace_repr_go_convert_A_const_60; var tmp16 any = A_arbace_repr_go_convert_A_const_302; var tmp17 *lang.Keyword = A_arbace_repr_go_convert_A_const_71; var tmp18 any = tmp17.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2))); var tmp19 any = A_arbace_repr_go_convert_A_const_303; var tmp20 *lang.Keyword = A_arbace_repr_go_convert_A_const_268; return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(tmp12.Invoke_O_O_O_O__O(ps__4, tmp13, tmp14, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rlist__5))))), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2))))))) } else { if A_arbace_repr_go_convert_A_const_152 != nil { var tmp21 any = A_arbace_repr_go_convert_A_const_294; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_277.GetRawRoot__O()); var tmp25 any = A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2); var tmp26 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp26 = lang.PersistentArrayMap_EMPTY; return lang.Tuple_Create_O_O_O__IPersistentVector(ps__4, tmp21, tmp22.Invoke_O_O__O(tmp23.Invoke_O_O__O(l__3, tmp24.Invoke_O_O__O(tmp25, tmp26.Ref())), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_295.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__2)), A_arbace_repr_go_convert_A_const_304))) } else { return nil } } } }











func A_arbace_repr_go_convert_type_params_A_New() *A_arbace_repr_go_convert_type_params_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_params_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_repr_go_convert_type_params_A) Ctor() {}
//line :482:1
func (t *A_arbace_repr_go_convert_type_params_A) Invoke_O_O__O(self, field_list__0 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_305.GetRawRoot__O()).Invoke_O__O(field_list__0); if


	jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(v__3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_295.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(field_list__0), A_arbace_repr_go_convert_A_const_306)) } else {
//line :485:1
			return nil } }


func A_arbace_repr_go_convert_type_params_STAR__A_New() *A_arbace_repr_go_convert_type_params_STAR__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_params_STAR__A{}; t.Ctor(); return t }
//line :488:1
func (t *A_arbace_repr_go_convert_type_params_STAR__A) Ctor() {}
//line :488:1
func (t *A_arbace_repr_go_convert_type_params_STAR__A) Invoke_O_O__O(self, field_list__0 any) any {
	if jrt.J2g_Truth(field_list__0) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(field_list__0) }
	var tmp1 any; var and__1927000168__auto____2 any = field_list__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; tmp1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(field_list__0))) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_227; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, tmp6.Ref()))
//line :490:1
		var tmp7 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			{ var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_236.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_237.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A_New(); var tmp12 *jrt.Class
				var fncls__32 /*line :492:1*/*jrt.Class = A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A_fn_class

				if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_238, false); A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A_fn_class = fncls__32d; tmp12 = fncls__32d } else { tmp12 = fncls__32 }
//line :492:1
				var tmp13 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; var tmp14 any = tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(field_list__0)))); var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_FALSE; tmp7 = tmp8.Invoke_O_O__O(tmp14, tmp15.Ref()) }
//line :490:1
			return nil }()
		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O()
//line :490:1
		if tmp16 != nil { panic(tmp16) }; return tmp7 } else { return nil
		}
}

func A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A_New() *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A) Ctor() {}
//line :494:1
func (t *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A) Invoke_O_O__O(self, fld__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(fld__1)
//line :494:1
	var map__1114000165__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(fld__1); var map__1114000165__3 any

	if lang.ISeq_InstanceOf(map__1114000165__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000165__2)) { map__1114000165__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000165__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000165__2)) { map__1114000165__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000165__2) } else { lang.PersistentArrayMap_Init(); map__1114000165__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000165__3 = map__1114000165__2 }
//line :494:1
	var names__4 any = lang.RT_Get_O_O__O(map__1114000165__3, A_arbace_repr_go_convert_A_const_54); var type__5 any = lang.RT_Get_O_O__O(map__1114000165__3, A_arbace_repr_go_convert_A_const_60); var c__6 any; var u__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(type__5); var tmp1 any; var tmp2 any = A_arbace_repr_go_convert_A_const_55; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(u__6))



	if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(Lit_239, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(u__6)); if and__1927000168__auto____8 {
		var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_184; tmp1 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_177.GetRawRoot__O()).Invoke_O__O(u__6)) } else {
//line :498:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(type__5)
//line :498:1
				c__6 = nil } else {


					c__6 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__5) }
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_convert_A_const_227; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Ref()))
//line :494:1
	var tmp8 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








		{ var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_250.GetRawRoot__O()); var tmp10 any; var iter__1927001039__auto____9 any; var tmp11 any = A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A_New_O(c__6); var tmp12 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_240, false); A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A_fn_class = fncls__31d; tmp12 = fncls__31d } else { tmp12 = fncls__31 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(names__4); tmp8 = tmp9.Invoke_O__O(tmp10) }
//line :494:1
		return nil
	}()






	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O()
//line :494:1
	if tmp13 != nil { panic(tmp13) }; return tmp8
}







func A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A_New_O(p0 any) *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A{}; t.Ctor_O(p0); return t }
//line :503:1
func (t *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :503:1
func (t *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A) Invoke_O_O__O(self, s__1114000168__1 any) any { var tmp1 any = A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A_New_O_O_O(s__1114000168__1, t.F_c, self); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_241, false); A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :503:1
func A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :503:1
func (t *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A) Ctor_O_O_O(c__s__1114000168, c__c, c__iter__1114000167 any) { t.F_s__1114000168 = c__s__1114000168; t.F_c = c__c; t.F_iter__1114000167 = c__iter__1114000167 }
//line :503:1
func (t *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A) Invoke_O__O(self any) any { { var s__1114000168__1 any; var t_ any = t.F_s__1114000168; t.F_s__1114000168 = nil; s__1114000168__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000168__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000168__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000168__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000168__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000170__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A_New_O_I_O_O(b__1114000170__6, size__1927001038__auto____5, t.F_c, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_242, false); A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000167); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000170__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000168__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000170__6), nil) } } else { var nm__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000168__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1114000167); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_253.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(nm__4), t.F_c), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000168__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :503:1
func A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :503:1
func (t *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A) Ctor_O_I_O_O(c__b__1114000170 any, c__size__1927001038__auto__ int32, c__c, c__c__1927001037__auto__ any) { t.F_b__1114000170 = c__b__1114000170; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c = c__c; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :503:1
func (t *A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A) Invoke_O__O(self any) any { { var i__1114000169__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000169__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000169__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000170; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_253.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(nm__2), t.F_c)); i__1114000169__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000169__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_repr_go_convert_untyped_const_QMARK__A_New() *A_arbace_repr_go_convert_untyped_const_QMARK__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_untyped_const_QMARK__A{}; t.Ctor(); return t }
//line :521:1
func (t *A_arbace_repr_go_convert_untyped_const_QMARK__A) Ctor() {}
//line :521:1
func (t *A_arbace_repr_go_convert_untyped_const_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var n__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(n__0); var f__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__2); var a__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__2); var tmp1 any = A_arbace_repr_go_convert_A_const_187; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp1, A_arbace_repr_go_convert_A_const_186.Invoke_O__O(a__4)); if and__1927000168__auto____5 {





	var G__1114000179__6_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__2)
	switch lang.Util_Hash_O__I(G__1114000179__6_) >> 9 & 7 { case 0: if any(G__1114000179__6_) == any(A_arbace_repr_go_convert_A_const_52) {




		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_310.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)) }
//line :528:1
	case 1: if any(G__1114000179__6_) == any(A_arbace_repr_go_convert_A_const_80) { var tmp2 any = A_arbace_repr_go_convert_A_const_311; var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_186; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp2, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_83.Invoke_O__O(f__3)))))








		if and__1927000168__auto____7 { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_312); var and__1927000168__auto____8 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_83.Invoke_O__O(f__3)))); if jrt.J2g_Truth(and__1927000168__auto____8) {

			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_313.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_310.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_317.Invoke_O__O(f__3)) } else {
//line :537:1
				return and__1927000168__auto____8 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } }
//line :528:1
	case 2: if any(G__1114000179__6_) == any(A_arbace_repr_go_convert_A_const_85) { var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_171; var o__7 any = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(f__3))); var tmp6 any = A_arbace_repr_go_convert_A_const_187; var and__1927000168__auto____8_2 bool = lang.Util_Equiv_O_O__Z(tmp6, A_arbace_repr_go_convert_A_const_178.Invoke_O__O(o__7))



		if and__1927000168__auto____8_2 { var and__1927000168__auto____9 any = A_arbace_repr_go_convert_A_const_314.Invoke_O__O(o__7); if jrt.J2g_Truth(and__1927000168__auto____9) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_315.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_314.Invoke_O__O(o__7)) } else { return and__1927000168__auto____9 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8_2).Ref() } }
//line :528:1
	case 3: if any(G__1114000179__6_) == any(A_arbace_repr_go_convert_A_const_104) {





		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_316); if jrt.J2g_Truth(tmp7.Invoke_O__O(A_arbace_repr_go_convert_A_const_280.Invoke_O__O(f__3))) {
			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_310.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)) } else {
//line :534:1
				var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_310.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3))

				if jrt.J2g_Truth(and__1927000168__auto____7_2) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_310.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_289.Invoke_O__O(f__3)) } else { return and__1927000168__auto____7_2 } } }
//line :528:1
	case 4: if any(G__1114000179__6_) == any(A_arbace_repr_go_convert_A_const_55) { var o__7_2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_177.GetRawRoot__O()).Invoke_O__O(n__2); var tmp8 any = A_arbace_repr_go_convert_A_const_187; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z(tmp8, A_arbace_repr_go_convert_A_const_178.Invoke_O__O(o__7_2))

		if and__1927000168__auto____8_3 { var and__1927000168__auto____9_2 any = A_arbace_repr_go_convert_A_const_314.Invoke_O__O(o__7_2); if jrt.J2g_Truth(and__1927000168__auto____9_2) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_315.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_314.Invoke_O__O(o__7_2)) } else { return and__1927000168__auto____9_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8_3).Ref() } }
//line :528:1
	case 7: if any(G__1114000179__6_) == any(A_arbace_repr_go_convert_A_const_109) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else {
//line :527:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }














func A_arbace_repr_go_convert_as_inst_A_New() *A_arbace_repr_go_convert_as_inst_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_as_inst_A{}; t.Ctor(); return t }
//line :542:1
func (t *A_arbace_repr_go_convert_as_inst_A) Ctor() {}
//line :542:1
func (t *A_arbace_repr_go_convert_as_inst_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(t__0)); if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_318); var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(t__0))); if jrt.J2g_Truth(and__1927000168__auto____4) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()); var tmp4 any; var and__1927000168__auto____5 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_262.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(t__0)), nil); if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_263.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(t__0)) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; tmp1 = tmp3.Invoke_O__O(tmp4) } else {
//line :546:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {

				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_319, t__0), lang.RT_Meta_O__IPersistentMap(t__0)) } else {
//line :546:1
					return t__0
				}
}


func A_arbace_repr_go_convert_selection_via_A_New() *A_arbace_repr_go_convert_selection_via_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_selection_via_A{}; t.Ctor(); return t }
//line :551:1
func (t *A_arbace_repr_go_convert_selection_via_A) Ctor() {}
//line :551:1
func (t *A_arbace_repr_go_convert_selection_via_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_320; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(a__0)); if
											jrt.J2g_Truth(temp__1927000414__auto____2) { var via__3 any = temp__1927000414__auto____2; var tmp2 any = A_arbace_repr_go_convert_A_const_321; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O(), via__3))) } else { return nil } }


func A_arbace_repr_go_convert_selector_form_A_New() *A_arbace_repr_go_convert_selector_form_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_selector_form_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_repr_go_convert_selector_form_A) Ctor() {}
//line :555:1
func (t *A_arbace_repr_go_convert_selector_form_A) Invoke_O_O__O(self, n__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var a__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0); var l__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var x__5 any = A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2); var sel__6 any = A_arbace_repr_go_convert_A_const_290.Invoke_O__O(f__2); var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_178; var k__7 any = tmp1.Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(a__3));








	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0);
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sel__6); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_287.GetRawRoot__O()).Invoke_O__O(x__5)) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(x__5)) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_287.GetRawRoot__O()).Invoke_O__O(x__5)) {


		var tmp2 any = A_arbace_repr_go_convert_A_const_291; var tmp3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(x__5); var tmp4 any = A_arbace_repr_go_convert_A_const_56; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(x__5)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(sel__6)), n__0, l__4), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_199.GetRawRoot__O()).Invoke_O_O__O(sel__6, A_arbace_repr_go_convert_A_const_18)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(sel__6)))) } else {
//line :567:1
			if lang.Util_Equiv_O_O__Z(k__7, A_arbace_repr_go_convert_A_const_322) {



				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_convert_A_const_324; return tmp5.Invoke_O_O_O_O_O__O(n__0, l__4, tmp6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_325.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(x__5)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(sel__6)), sel__6, l__4)) } else {
//line :567:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_323).Invoke_O__O(k__7)) {







						var tmp7 any = A_arbace_repr_go_convert_A_const_56; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()).Invoke_O_O_O_O__O(n__0, l__4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_169, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(sel__6))).Ref()), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_199.GetRawRoot__O()).Invoke_O_O__O(sel__6, A_arbace_repr_go_convert_A_const_18)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(x__5)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_326.GetRawRoot__O()).Invoke_O__O(a__3)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(sel__6)))) } else {
//line :567:1
							if A_arbace_repr_go_convert_A_const_152 != nil {








								return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_185, n__0) } else {
//line :567:1
									return nil } } } } }










func A_arbace_repr_go_convert_call_args_A_New() *A_arbace_repr_go_convert_call_args_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_call_args_A{}; t.Ctor(); return t }
//line :578:1
func (t *A_arbace_repr_go_convert_call_args_A) Ctor() {}
//line :578:1
func (t *A_arbace_repr_go_convert_call_args_A) Invoke_O_O_O__O(self, args__0, ellipsis__1 any) any { var xs__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O(), args__0); if

	jrt.J2g_Truth(ellipsis__1) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_159.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_329.GetRawRoot__O()).Invoke_O__O(xs__3)); var tmp3 any = A_arbace_repr_go_convert_A_const_328; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_9.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_327.GetRawRoot__O()).Invoke_O__O(xs__3), tmp1.Invoke_O_O_O_O__O(nil, tmp2, tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_329.GetRawRoot__O()).Invoke_O__O(xs__3))) } else {
//line :580:1
			return xs__3 } }



func A_arbace_repr_go_convert_builtin_name_A_New() *A_arbace_repr_go_convert_builtin_name_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_builtin_name_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_repr_go_convert_builtin_name_A) Ctor() {}
//line :584:1
func (t *A_arbace_repr_go_convert_builtin_name_A) Invoke_O_O__O(self, fun__0 any) any { var fun__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(fun__0); var G__1114000185__3_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(fun__2); switch



	lang.Util_Hash_O__I(G__1114000185__3_) >> 0 & 1 { case 0: if any(G__1114000185__3_) == any(A_arbace_repr_go_convert_A_const_55) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(fun__2)) }
//line :588:1
	case 1: if any(G__1114000185__3_) == any(A_arbace_repr_go_convert_A_const_85) {

		var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(fun__2)))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(fun__2)))) }
//line :588:1
	default:}; return /*line :591:1*/ lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_20, fun__2) }

func A_arbace_repr_go_convert_call_A_New() *A_arbace_repr_go_convert_call_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_call_A{}; t.Ctor(); return t }
//line :593:1
func (t *A_arbace_repr_go_convert_call_A) Ctor() {}
//line :593:1
func (t *A_arbace_repr_go_convert_call_A) Invoke_O_O__O(self, n__0 any) any { var map__1114000187__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var map__1114000187__3 any; if
										lang.ISeq_InstanceOf(map__1114000187__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000187__2)) { map__1114000187__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000187__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000187__2)) { map__1114000187__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000187__2) } else { lang.PersistentArrayMap_Init(); map__1114000187__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000187__3 = map__1114000187__2 }; var fun__4 any = /*line :593:1*/lang.RT_Get_O_O__O(map__1114000187__3, A_arbace_repr_go_convert_A_const_83); var args__5 any = lang.RT_Get_O_O__O(map__1114000187__3, A_arbace_repr_go_convert_A_const_317); var ellipsis__6 any = lang.RT_Get_O_O__O(map__1114000187__3, A_arbace_repr_go_convert_A_const_43); var l__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var u__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(fun__4); var fa__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(u__8); var ua__10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__8);





	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any = A_arbace_repr_go_convert_A_const_60; if
	lang.Util_Equiv_O_O__Z(tmp1, A_arbace_repr_go_convert_A_const_186.Invoke_O__O(fa__9)) {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_334; if jrt.J2g_Truth(tmp2.Invoke_O_O__O(tmp3, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(args__5)).Ref())) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_21, n__0) }
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_335; return tmp4.Invoke_O_O_O_O_O__O(n__0, l__7, tmp5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(fun__4), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(args__5))) } else {
//line :600:1
			var tmp6 any = A_arbace_repr_go_convert_A_const_311; if lang.Util_Equiv_O_O__Z(tmp6, A_arbace_repr_go_convert_A_const_186.Invoke_O__O(fa__9)) { var ___11 any; var tmp7 any = A_arbace_repr_go_convert_call_fn__1114000192_A_New_O(fun__4); var tmp8 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_go_convert_call_fn__1114000192_A_fn_class; _ = ___11





				if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_repr_go_convert_call_fn__1114000192_A_fn_class = fncls__35d; tmp8 = fncls__35d } else { tmp8 = fncls__35 }; ___11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :600:1
				var head__12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_330.GetRawRoot__O()).Invoke_O__O(fun__4); var head_form__13 any; var G__1114000194__13_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(head__12, u__8, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(u__8)), fun__4)
				var tmp9 any = A_arbace_repr_go_convert_A_const_85






				if lang.Util_Equiv_O_O__Z(tmp9, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(u__8)) {

					var tmp10 any = A_arbace_repr_go_convert_A_const_291; var tmp11 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__8))); var tmp13 any = A_arbace_repr_go_convert_A_const_56; var tmp14 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; head_form__13 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(G__1114000194__13_, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__8)))))) } else {
//line :608:1
						head_form__13 = G__1114000194__13_ }
//line :600:1
				var vec__1114000189__14 any = args__5; var seq__1114000190__15 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(vec__1114000189__14); var first__1114000191__16 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1114000190__15); var seq__1114000190__17 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq__1114000190__15); var a0__18 any = first__1114000191__16; var more__19 any = seq__1114000190__17; var a0f__20 any











				if jrt.J2g_Truth(a0__18) { var tmp15 any = A_arbace_repr_go_convert_A_const_60; var tmp16 *lang.Keyword = A_arbace_repr_go_convert_A_const_186; if lang.Util_Equiv_O_O__Z(tmp15, tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(a0__18)))) { var G__1114000195__20_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(a0__18)
					if lang.Util_Equiv_O_O__Z(A_arbace_repr_go_convert_A_const_331, head__12) { a0f__20 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_325.GetRawRoot__O()).Invoke_O__O(G__1114000195__20_) } else { a0f__20 = G__1114000195__20_ } } else {
						a0f__20 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(a0__18) } } else {
//line :612:1
							a0f__20 = nil
						}

				var tmp17 any = A_arbace_repr_go_convert_A_const_85; if lang.Util_Equiv_O_O__Z(tmp17, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(u__8)) {
					lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(u__8); var tmp18 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__8))); var tmp19 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__8)))) } else {
						lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(u__8) }
				if jrt.J2g_Truth(a0__18) { var xs__21 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(a0f__20), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O(), more__19)); var xs__22 any

					if jrt.J2g_Truth(ellipsis__6) { var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp21 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_159.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_329.GetRawRoot__O()).Invoke_O__O(xs__21)); var tmp22 any = A_arbace_repr_go_convert_A_const_336; xs__22 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_9.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_327.GetRawRoot__O()).Invoke_O__O(xs__21), tmp20.Invoke_O_O_O_O__O(nil, tmp21, tmp22, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_329.GetRawRoot__O()).Invoke_O__O(xs__21))) } else { xs__22 = xs__21 }
					return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__7, head_form__13, xs__22) } else {
						return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()).Invoke_O_O_O__O(n__0, l__7, head_form__13) } } else {
//line :600:1
							var tmp23 any; var tmp24 any = A_arbace_repr_go_convert_A_const_85; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z(tmp24, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(u__8))























							if and__1927000168__auto____11 { var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_287.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(ua__10))); if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp25 any = A_arbace_repr_go_convert_A_const_332; var tmp26 *lang.Keyword = A_arbace_repr_go_convert_A_const_178; tmp23 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp25, tmp26.Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(fa__9)))).Ref() } else { tmp23 = and__1927000168__auto____12 } } else { tmp23 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() }
//line :600:1
							if jrt.J2g_Truth(tmp23) {
























								lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(u__8); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(ua__10))





								var tmp27 any = A_arbace_repr_go_convert_A_const_337; var tmp28 any = A_arbace_repr_go_convert_A_const_337.Invoke_O__O(ua__10); var tmp29 any = A_arbace_repr_go_convert_A_const_56; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(ua__10)))).Ref()), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(ua__10), A_arbace_repr_go_convert_A_const_18)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(ua__10)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_338.GetRawRoot__O()).Invoke_O_O__O(args__5, ellipsis__6)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_326.GetRawRoot__O()).Invoke_O__O(fa__9)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp29, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_290.Invoke_O__O(ua__10))))) } else {
//line :600:1
									var tmp30 any = A_arbace_repr_go_convert_A_const_55; if lang.Util_Equiv_O_O__Z(tmp30, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(u__8)) { var callee__11 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(u__8), fun__4); var tmp31 any; var and__1927000168__auto____12_2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(callee__11)


































										if jrt.J2g_Truth(and__1927000168__auto____12_2) { tmp31 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_333.GetRawRoot__O()).Invoke_O__O(callee__11) } else { tmp31 = and__1927000168__auto____12_2 }; if jrt.J2g_Truth(tmp31) {
											lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_339)
											var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp33 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp34 any = A_arbace_repr_go_convert_A_const_340; return tmp32.Invoke_O_O_O_O_O_O__O(tmp33, n__0, l__7, tmp34, callee__11, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_338.GetRawRoot__O()).Invoke_O_O__O(args__5, ellipsis__6)) } else {
												return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__7, callee__11, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_338.GetRawRoot__O()).Invoke_O_O__O(args__5, ellipsis__6)) } } else {
//line :600:1
													if A_arbace_repr_go_convert_A_const_152 != nil {







































														return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(fun__4), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_338.GetRawRoot__O()).Invoke_O_O__O(args__5, ellipsis__6)) } else {
//line :600:1
															return nil } } } } } }





func A_arbace_repr_go_convert_call_fn__1114000192_A_New_O(p0 any) *A_arbace_repr_go_convert_call_fn__1114000192_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_call_fn__1114000192_A{}; t.Ctor_O(p0); return t }
//line :606:1
func (t *A_arbace_repr_go_convert_call_fn__1114000192_A) Ctor_O(c__fun any) { t.F_fun = c__fun }
//line :606:1
func (t *A_arbace_repr_go_convert_call_fn__1114000192_A) Invoke_O__O(self any) any { { var x__1 any; var t_ any = t.F_fun; t.F_fun = nil; x__1 = t_; L1: for { var tmp1 any = A_arbace_repr_go_convert_A_const_32; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(x__1)) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(x__1); var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; x__1 = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__1)); continue L1 } else { return nil } } }; panic("j2g: unreachable") }



































func A_arbace_repr_go_convert_instantiation_A_New() *A_arbace_repr_go_convert_instantiation_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_instantiation_A{}; t.Ctor(); return t }
//line :642:1
func (t *A_arbace_repr_go_convert_instantiation_A) Ctor() {}
//line :642:1
func (t *A_arbace_repr_go_convert_instantiation_A) Invoke_O_O__O(self, n__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var idx__3 any; var tmp1 any = A_arbace_repr_go_convert_A_const_73; if



	lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0)) { idx__3 = lang.Tuple_Create_O__IPersistentVector(A_arbace_repr_go_convert_A_const_273.Invoke_O__O(f__2)) } else { idx__3 = A_arbace_repr_go_convert_A_const_272.Invoke_O__O(f__2) }; var x__4 any = /*line :642:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__2)); var fx__5 any; var G__1114000197__5_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(x__4); L1:





	switch { default: switch lang.Util_Hash_O__I(G__1114000197__5_) >> 0 & 1 { case 0: if any(G__1114000197__5_) == any(A_arbace_repr_go_convert_A_const_55) {
		fx__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O_O__O(x__4, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(idx__3)).Ref())
//line :648:1
		break L1 }; case 1: if any(G__1114000197__5_) == any(A_arbace_repr_go_convert_A_const_85) {

			var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_287.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))) {




				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()); var tmp6 any
//line :651:1
				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(x__4); var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))
				var tmp8 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4))))
				var tmp9 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; var tmp10 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; tmp6 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4))))

				var tmp11 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; var tmp12 any = A_arbace_repr_go_convert_A_const_291; var tmp13 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; var tmp14 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4))); var tmp15 any = A_arbace_repr_go_convert_A_const_56; var tmp16 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; fx__5 = tmp3.Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5.Invoke_O_O_O__O(tmp6, x__4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__4)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_199.GetRawRoot__O()).Invoke_O_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(idx__3)).Ref())), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp14, tmp15, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))))) } else {
					var tmp17 any = A_arbace_repr_go_convert_A_const_322; var tmp18 *lang.Keyword = A_arbace_repr_go_convert_A_const_178; var tmp19 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; if lang.Util_Equiv_O_O__Z(tmp17, tmp18.Invoke_O__O(tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(x__4)))) {
						lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(x__4); var tmp20 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))
						var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp22 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__4); var tmp23 any = A_arbace_repr_go_convert_A_const_341; var tmp24 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; var tmp25 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; var tmp26 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; fx__5 = tmp21.Invoke_O_O_O_O_O__O(x__4, tmp22, tmp23, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_325.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(tmp24.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(tmp25.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_199.GetRawRoot__O()).Invoke_O_O__O(tmp26.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(idx__3)).Ref()))) } else {







							var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp29 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__4); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp31 any
//line :662:1
							lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(x__4); var tmp32 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(tmp32.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))
							var tmp33 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; tmp31 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_169, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(tmp33.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4))))).Ref())


							var tmp34 *lang.Keyword = A_arbace_repr_go_convert_A_const_290; var tmp35 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; fx__5 = tmp27.Invoke_O_O__O(tmp28.Invoke_O_O_O_O__O(x__4, tmp29, tmp30.Invoke_O_O__O(tmp31, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_199.GetRawRoot__O()).Invoke_O_O__O(tmp34.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(idx__3)).Ref())), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(tmp35.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__4)))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_326.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(x__4))) } }
//line :648:1
			break L1 }; default:
	}

















		fx__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(x__4)}; var tmp36 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp37 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp38 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var tmp39 any = A_arbace_repr_go_convert_A_const_342; return tmp36.Invoke_O_O_O_O_O_O__O(tmp37, n__0, tmp38, tmp39, fx__5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O(), idx__3)) }

func A_arbace_repr_go_convert_composite_A_New() *A_arbace_repr_go_convert_composite_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_composite_A{}; t.Ctor(); return t }
//line :670:1
func (t *A_arbace_repr_go_convert_composite_A) Ctor() {}
//line :670:1
func (t *A_arbace_repr_go_convert_composite_A) Invoke_O_O__O(self, n__0 any) any { var map__1114000199__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var map__1114000199__3 any; if
											lang.ISeq_InstanceOf(map__1114000199__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000199__2)) { map__1114000199__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000199__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000199__2)) { map__1114000199__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000199__2) } else { lang.PersistentArrayMap_Init(); map__1114000199__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000199__3 = map__1114000199__2 }; var type__4 any = /*line :670:1*/lang.RT_Get_O_O__O(map__1114000199__3, A_arbace_repr_go_convert_A_const_60); var elts__5 any = lang.RT_Get_O_O__O(map__1114000199__3, A_arbace_repr_go_convert_A_const_343); var l__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var t__7 any; if


	jrt.J2g_Truth(type__4) { t__7 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__4) } else { t__7 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(Lit_28), nil, l__6) }; var via__8 any; var tmp1 lang.IFn = /*line :670:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_127.GetRawRoot__O()).Invoke__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_128.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_composite_fn__1114000201_A_New(); var tmp5 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_go_convert_composite_fn__1114000201_A_fn_class; if




	fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_repr_go_convert_composite_fn__1114000201_A_fn_class = fncls__37d; tmp5 = fncls__37d } else { tmp5 = fncls__37 }; via__8 = /*line :674:1*/tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)), elts__5); var els__9 any; var tmp6 lang.IFn = /*line :670:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_237.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_composite_fn__1114000203_A_New(); var tmp8 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_repr_go_convert_composite_fn__1114000203_A_fn_class; if








	fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_repr_go_convert_composite_fn__1114000203_A_fn_class = fncls__38d; tmp8 = fncls__38d } else { tmp8 = fncls__38 }; els__9 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), elts__5);














	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); var tmp9 lang.IFn =

	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__6, A_arbace_repr_go_convert_A_const_344, t__7, els__9); var tmp11 lang.IPersistentMap; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(via__8)) { tmp11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_321, via__8)) } else { tmp11 = nil }; return tmp9.Invoke_O_O__O(tmp10, tmp11) }
//line :675:1
func A_arbace_repr_go_convert_composite_fn__1114000201_A_New() *A_arbace_repr_go_convert_composite_fn__1114000201_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_composite_fn__1114000201_A{}; t.Ctor(); return t }
//line :675:1
func (t *A_arbace_repr_go_convert_composite_fn__1114000201_A) Ctor() {}
//line :675:1
func (t *A_arbace_repr_go_convert_composite_fn__1114000201_A) Invoke_O_O__O(self, e__1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_320; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_64; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(e__1))); if
												jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_86; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_201.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(e__1))))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O(), v__3)) } else { return nil } }


func A_arbace_repr_go_convert_composite_fn__1114000203_A_New() *A_arbace_repr_go_convert_composite_fn__1114000203_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_composite_fn__1114000203_A{}; t.Ctor(); return t }
//line :679:1
func (t *A_arbace_repr_go_convert_composite_fn__1114000203_A) Ctor() {}
//line :679:1
func (t *A_arbace_repr_go_convert_composite_fn__1114000203_A) Invoke_O_O__O(self, e__1 any) any {
	var tmp1 any = A_arbace_repr_go_convert_A_const_84; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(e__1)) { var map__1114000204__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(e__1); var map__1114000204__3 any
		if lang.ISeq_InstanceOf(map__1114000204__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000204__2)) { map__1114000204__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000204__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000204__2)) { map__1114000204__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000204__2) } else { lang.PersistentArrayMap_Init(); map__1114000204__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000204__3 = map__1114000204__2 }
//line :680:1
		var key__4 any = lang.RT_Get_O_O__O(map__1114000204__3, A_arbace_repr_go_convert_A_const_86); var value__5 any = lang.RT_Get_O_O__O(map__1114000204__3, A_arbace_repr_go_convert_A_const_206)

		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(e__1)
		var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_64; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(e__1))) { var k__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(key__4)
			var tmp3 any = A_arbace_repr_go_convert_A_const_55
			if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(k__6)) { } else { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_31, k__6) }
			lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(k__6)
//line :683:1
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(k__6), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_32, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(k__6))).Ref(), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_201.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(k__6))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(k__6))); var tmp6 any = A_arbace_repr_go_convert_A_const_166; var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_166; return lang.Tuple_Create_O_O__IPersistentVector(tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(e__1)))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(value__5)) } else { var tmp8 any = A_arbace_repr_go_convert_A_const_166; var tmp9 *lang.Keyword = A_arbace_repr_go_convert_A_const_166; return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(e__1), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(key__4), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(value__5))), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(e__1)))))) } } else {
//line :680:1
				return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(e__1))
			}
}

















func A_arbace_repr_go_convert_func_lit_A_New() *A_arbace_repr_go_convert_func_lit_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_func_lit_A{}; t.Ctor(); return t }
//line :700:1
func (t *A_arbace_repr_go_convert_func_lit_A) Ctor() {}
//line :700:1
func (t *A_arbace_repr_go_convert_func_lit_A) Invoke_O_O__O(self, n__0 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :700:1
	var map__1114000208__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var map__1114000208__3 any

	if lang.ISeq_InstanceOf(map__1114000208__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000208__2)) { map__1114000208__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000208__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000208__2)) { map__1114000208__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000208__2) } else { lang.PersistentArrayMap_Init(); map__1114000208__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000208__3 = map__1114000208__2 }
//line :700:1
	var type__4 any = lang.RT_Get_O_O__O(map__1114000208__3, A_arbace_repr_go_convert_A_const_60); var body__5 any = lang.RT_Get_O_O__O(map__1114000208__3, A_arbace_repr_go_convert_A_const_345); var l__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_294; var has_results__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(type__4))))); var ___8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(type__4); var sig__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_346.GetRawRoot__O()).Invoke_O__O(type__4); var ret__10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_347.GetRawRoot__O()).Invoke_O__O(nil); var body_forms__11 any; _ = ___8







	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_351, ret__10)); var tmp3 any = A_arbace_repr_go_convert_func_lit_fn__1114000210_A_New_O_O(has_results__7, body__5); var tmp4 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_go_convert_func_lit_fn__1114000210_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_139, false); A_arbace_repr_go_convert_func_lit_fn__1114000210_A_fn_class = fncls__39d; tmp4 = fncls__39d } else { tmp4 = fncls__39 }; body_forms__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp7 any = A_arbace_repr_go_convert_A_const_353; var tmp8 any = A_arbace_repr_go_convert_A_const_352; var tmp9 *lang.Keyword = A_arbace_repr_go_convert_A_const_158; var tmp10 any = A_arbace_repr_go_convert_A_const_101; var tmp11 *lang.Keyword = A_arbace_repr_go_convert_A_const_101; var tmp12 any = tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(type__4)); var tmp13 any = A_arbace_repr_go_convert_A_const_58; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O_O_O_O_O__O(tmp6, n__0, l__6, tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(sig__9, body_forms__11)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_125.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(body__5)))))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_8.GetRawRoot__O()).Invoke_O__O(ret__10))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_354.GetRawRoot__O()).Invoke_O__O(body__5))) }
//line :708:1
func A_arbace_repr_go_convert_func_lit_fn__1114000210_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_func_lit_fn__1114000210_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_func_lit_fn__1114000210_A{}; t.Ctor_O_O(p0, p1); return t }
//line :708:1
func (t *A_arbace_repr_go_convert_func_lit_fn__1114000210_A) Ctor_O_O(c__has_results, c__body any) { t.F_has_results = c__has_results; t.F_body = c__body }
//line :708:1
func (t *A_arbace_repr_go_convert_func_lit_fn__1114000210_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_348.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_349.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_body; t.F_body = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_repr_go_convert_A_const_350; var tmp7 any; var t__2 any = t.F_has_results; t.F_has_results = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp7)).Ref())))) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }




func A_arbace_repr_go_convert_expr_A_New() *A_arbace_repr_go_convert_expr_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_expr_A{}; t.Ctor(); return t }
//line :713:1
func (t *A_arbace_repr_go_convert_expr_A) Ctor() {}
//line :713:1
func (t *A_arbace_repr_go_convert_expr_A) Invoke_O_O__O(self, n__0 any) any { var a__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any = A_arbace_repr_go_convert_A_const_60; if



	lang.Util_Equiv_O_O__Z(tmp1, A_arbace_repr_go_convert_A_const_186.Invoke_O__O(a__2)) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(n__0) } else {
//line :717:1
			var f__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var l__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var G__1114000215__5_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0)



			switch lang.Util_Hash_O__I(G__1114000215__5_) >> 6 & 63 { case 2: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_43) {






































































				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_113, n__0) }
//line :721:1
			case 5: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_52) {






















				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :721:1
				var temp__1927000408__auto____6 any; var x__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)); var tmp2 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(Lit_114, A_arbace_repr_go_convert_A_const_280.Invoke_O__O(f__3))
























				if and__1927000168__auto____7 { var tmp3 any = A_arbace_repr_go_convert_A_const_109; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(x__6)); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()); var tmp5 any; var and__1927000168__auto____9_2 any = A_arbace_repr_go_convert_A_const_148.Get__O()

					if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp6 any = A_arbace_repr_go_convert_A_const_32; tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)))).Ref() } else { tmp5 = and__1927000168__auto____9_2 }; and__1927000168__auto____9 = tmp4.Invoke_O__O(tmp5)
//line :746:1
					if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_355); var tmp8 *lang.Keyword = A_arbace_repr_go_convert_A_const_178; var and__1927000168__auto____10 any = tmp7.Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(x__6))); if jrt.J2g_Truth(and__1927000168__auto____10) { var v__11 any; var tmp9 *lang.Keyword = A_arbace_repr_go_convert_A_const_206; var tmp10 any





						lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_12, nil)); var tmp11 any = A_arbace_repr_go_convert_expr_fn__1114000216_A_New_O(x__6); var tmp12 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_go_convert_expr_fn__1114000216_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_repr_go_convert_expr_fn__1114000216_A_fn_class = fncls__41d; tmp12 = fncls__41d } else { tmp12 = fncls__41 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O(); v__11 = tmp9.Invoke_O__O(tmp10)
//line :746:1
						var or__1927000174__auto____12 bool = jrt.Double_InstanceOf(v__11)






						if or__1927000174__auto____12 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____12).Ref() } else { tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(v__11)).Ref()) } } else {
//line :746:1
							tmp2 = and__1927000168__auto____10 } } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp2) {







								var tmp13 any = A_arbace_repr_go_convert_A_const_32; if lang.Util_Equiv_O_O__Z(tmp13, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3))) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)) }
//line :746:1
								var v__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_356.GetRawRoot__O()).Invoke_O__O(x__6)









								lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_363)
								var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp15 any = A_arbace_repr_go_convert_A_const_232; var tmp16 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_convert_A_const_232.Invoke_O__O(v__7))).Ref(); var tmp17 any = A_arbace_repr_go_convert_A_const_206; var tmp18 any = lang.Numbers_MinusP_O__Number(A_arbace_repr_go_convert_A_const_206.Invoke_O__O(v__7)); var tmp19 any = A_arbace_repr_go_convert_A_const_162; var tmp20 any = A_arbace_repr_go_convert_A_const_163; temp__1927000408__auto____6 = tmp14.Invoke_O_O_O_O_O_O_O_O_O__O(v__7, tmp15, tmp16, tmp17, tmp18, tmp19, l__4, tmp20, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_53.Invoke_O__O(f__3))) } else {
//line :746:1
									temp__1927000408__auto____6 = nil }
//line :745:1
				if jrt.J2g_Truth(temp__1927000408__auto____6) { var neg__7 any = temp__1927000408__auto____6; return neg__7 } else { var temp__1927000408__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_357.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_280.Invoke_O__O(f__3))














					if jrt.J2g_Truth(temp__1927000408__auto____7) { var op__8 any = temp__1927000408__auto____7
						return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()).Invoke_O_O_O_O__O(n__0, l__4, op__8, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3))) } else {
							if lang.Util_Equiv_O_O__Z(Lit_116, A_arbace_repr_go_convert_A_const_280.Invoke_O__O(f__3)) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(n__0) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_117, n__0) } } } }
//line :721:1
			case 6: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_59) {


				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_358.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :721:1
			case 12: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_78) { var map__1114000218__6 any = f__3; var map__1114000218__7 any











				if lang.ISeq_InstanceOf(map__1114000218__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000218__6)) { map__1114000218__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000218__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000218__6)) { map__1114000218__7 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000218__6) } else { lang.PersistentArrayMap_Init(); map__1114000218__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000218__7 = map__1114000218__6 }
//line :721:1
				var x__8 any = lang.RT_Get_O_O__O(map__1114000218__7, A_arbace_repr_go_convert_A_const_34); var low__9 any = lang.RT_Get_O_O__O(map__1114000218__7, A_arbace_repr_go_convert_A_const_359); var high__10 any = lang.RT_Get_O_O__O(map__1114000218__7, A_arbace_repr_go_convert_A_const_360); var max__11 any = lang.RT_Get_O_O__O(map__1114000218__7, A_arbace_repr_go_convert_A_const_361); var parts__12 any












				if jrt.J2g_Truth(max__11) { parts__12 = lang.Tuple_Create_O_O_O__IPersistentVector(low__9, high__10, max__11) } else { if jrt.J2g_Truth(high__10) { parts__12 = lang.Tuple_Create_O_O__IPersistentVector(low__9, high__10) } else { if jrt.J2g_Truth(low__9) { parts__12 = lang.Tuple_Create_O__IPersistentVector(low__9) } else { if A_arbace_repr_go_convert_A_const_152 != nil { lang.PersistentVector_Init(); parts__12 = lang.PersistentVector_EMPTY.Ref() } else { parts__12 = nil } } } }
				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
				var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp22 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp23 any = A_arbace_repr_go_convert_A_const_365; var tmp24 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(x__8); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp26 any = A_arbace_repr_go_convert_expr_fn__1114000220_A_New_O(l__4); var tmp27 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_repr_go_convert_expr_fn__1114000220_A_fn_class
				if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_repr_go_convert_expr_fn__1114000220_A_fn_class = fncls__42d; tmp27 = fncls__42d } else { tmp27 = fncls__42 }
//line :736:1
				return tmp21.Invoke_O_O_O_O_O_O__O(tmp22, n__0, l__4, tmp23, tmp24, tmp25.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil), parts__12)) }
//line :721:1
			case 13: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_80) {



















				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_364.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :721:1
			case 16: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_85) {





				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_366.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :721:1
			case 24: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_104) { var op__6 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_367.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_280.Invoke_O__O(f__3))










































				if jrt.J2g_Truth(or__1927000174__auto____6) { op__6 = or__1927000174__auto____6 } else { op__6 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_119, n__0) }
				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_368.GetRawRoot__O()).Invoke_O__O(op__6)) { var logical__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_369).Invoke_O__O(op__6); var operand__8 any; var tmp28 any = A_arbace_repr_go_convert_expr_operand__1114000225_A_New_O(logical__7); var tmp29 *jrt.Class
					var fncls__43 /*line :766:1*/*jrt.Class = A_arbace_repr_go_convert_expr_operand__1114000225_A_fn_class

					if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_repr_go_convert_expr_operand__1114000225_A_fn_class = fncls__43d; tmp29 = fncls__43d } else { tmp29 = fncls__43 }; operand__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil)
//line :766:1
					var vec__1114000222__9 any; var tmp30 any = A_arbace_repr_go_convert_expr_fn__1114000227_A_New_O_O_O_O_O(operand__8, logical__7, f__3, n__0, op__6); var tmp31 *jrt.Class
					var fncls__44 /*line :766:1*/*jrt.Class = A_arbace_repr_go_convert_expr_fn__1114000227_A_fn_class








					if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_repr_go_convert_expr_fn__1114000227_A_fn_class = fncls__44d; tmp31 = fncls__44d } else { tmp31 = fncls__44 }; vec__1114000222__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil).Invoke__O()
//line :766:1
					var operands__10 any = lang.RT_Nth_O_I_O__O(vec__1114000222__9, lang.RT_IntCast_J__I(0), nil); var nodes__11 any = lang.RT_Nth_O_I_O__O(vec__1114000222__9, lang.RT_IntCast_J__I(1), nil); var G__1114000229__12_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), n__0, l__4, op__6, operands__10)
















					if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(nodes__11)), 1) {

						var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_204.GetRawRoot__O()); var tmp33 any = A_arbace_repr_go_convert_A_const_293; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_170.GetRawRoot__O()); var tmp35 any = A_arbace_repr_go_convert_expr_fn__1114000230_A_New(); var tmp36 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_go_convert_expr_fn__1114000230_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_repr_go_convert_expr_fn__1114000230_A_fn_class = fncls__45d; tmp36 = fncls__45d } else { tmp36 = fncls__45 }; return tmp32.Invoke_O_O__O(G__1114000229__12_, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_373.GetRawRoot__O()).Invoke_O__O(nodes__11))))) } else {
//line :783:1
							return G__1114000229__12_ } } else {
//line :766:1
								var fm__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()).Invoke_O_O_O_O_O__O(n__0, l__4, op__6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_289.Invoke_O__O(f__3))); var tmp37 any; var and__1927000168__auto____8_2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_372).Invoke_O__O(op__6)




















								if jrt.J2g_Truth(and__1927000168__auto____8_2) { var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp39 any = A_arbace_repr_go_convert_A_const_187; var and__1927000168__auto____9_3 any = tmp38.Invoke_O_O__O(tmp39, A_arbace_repr_go_convert_A_const_186.Invoke_O__O(a__2)); if jrt.J2g_Truth(and__1927000168__auto____9_3) { var and__1927000168__auto____10_2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_310.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)); if jrt.J2g_Truth(and__1927000168__auto____10_2) { var and__1927000168__auto____11 any = A_arbace_repr_go_convert_A_const_314.Invoke_O__O(a__2); if jrt.J2g_Truth(and__1927000168__auto____11) {
									tmp37 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_315.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_314.Invoke_O__O(a__2))) } else {
//line :787:1
										tmp37 = and__1927000168__auto____11 } } else { tmp37 = and__1927000168__auto____10_2 } } else { tmp37 = and__1927000168__auto____9_3 } } else { tmp37 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp37) {

											lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_374); var tmp40 any = A_arbace_repr_go_convert_A_const_226; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(fm__7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_174.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_314.Invoke_O__O(a__2))))) } else {
//line :787:1
												return fm__7 } } }
//line :721:1
			case 27: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_32) {




				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_156.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)), n__0) }
//line :721:1
			case 28: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_116) {
















				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
				if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_60.Invoke_O__O(f__3)) { } else { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_123, n__0) }
				var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp42 any = A_arbace_repr_go_convert_A_const_375; return tmp41.Invoke_O_O_O_O_O__O(n__0, l__4, tmp42, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_60.Invoke_O__O(f__3)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3))) }
//line :721:1
			case 37: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_55) {
				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :721:1
			case 43: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_73) {






				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
				var tmp43 any = A_arbace_repr_go_convert_A_const_60; var tmp44 *lang.Keyword = A_arbace_repr_go_convert_A_const_186; if lang.Util_Equiv_O_O__Z(tmp43, tmp44.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_273.Invoke_O__O(f__3))))) {
					return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_376.GetRawRoot__O()).Invoke_O__O(n__0) } else {
						var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp46 any = A_arbace_repr_go_convert_A_const_377; return tmp45.Invoke_O_O_O_O_O__O(n__0, l__4, tmp46, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_273.Invoke_O__O(f__3))) } }
//line :721:1
			case 48: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_84) {





































































				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_124, n__0) }
//line :721:1
			case 51: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_96) {



				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_378.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :721:1
			case 52: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_98) {




















				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
				var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp49 any = A_arbace_repr_go_convert_A_const_380; var tmp50 any = tmp48.Invoke_O_O_O_O__O(n__0, l__4, tmp49, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3))); var tmp51 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp52 any = A_arbace_repr_go_convert_A_const_379; var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; return tmp47.Invoke_O_O_O_O__O(tmp50, tmp51, tmp52, tmp53.Ref()) }
//line :721:1
			case 55: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_102) {










				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_376.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :721:1
			case 57: if any(G__1114000215__5_) == any(A_arbace_repr_go_convert_A_const_109) {

				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_356.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :721:1
			default:
			}






































































			var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_362); if jrt.J2g_Truth(tmp54.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0))) {
				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(n__0) } else {
					return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_125, n__0) } } }
//line :737:1
func A_arbace_repr_go_convert_expr_fn__1114000220_A_New_O(p0 any) *A_arbace_repr_go_convert_expr_fn__1114000220_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_expr_fn__1114000220_A{}; t.Ctor_O(p0); return t }
//line :737:1
func (t *A_arbace_repr_go_convert_expr_fn__1114000220_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :737:1
func (t *A_arbace_repr_go_convert_expr_fn__1114000220_A) Invoke_O_O__O(self, p1__1114000213_SHARP___1 any) any { if jrt.J2g_Truth(p1__1114000213_SHARP___1) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(p1__1114000213_SHARP___1) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(Lit_28), nil, t.F_l) } }














func A_arbace_repr_go_convert_expr_fn__1114000216_A_New_O(p0 any) *A_arbace_repr_go_convert_expr_fn__1114000216_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_expr_fn__1114000216_A{}; t.Ctor_O(p0); return t }
//line :752:1
func (t *A_arbace_repr_go_convert_expr_fn__1114000216_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :752:1
func (t *A_arbace_repr_go_convert_expr_fn__1114000216_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_356.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_x; t.F_x = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }















func A_arbace_repr_go_convert_expr_operand__1114000225_A_New_O(p0 any) *A_arbace_repr_go_convert_expr_operand__1114000225_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_expr_operand__1114000225_A{}; t.Ctor_O(p0); return t }
//line :768:1
func (t *A_arbace_repr_go_convert_expr_operand__1114000225_A) Ctor_O(c__logical any) { t.F_logical = c__logical }
//line :768:1
func (t *A_arbace_repr_go_convert_expr_operand__1114000225_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var and__1927000168__auto____2 any = t.F_logical; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_repr_go_convert_A_const_32; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var fx__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(x__1)

	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_370)
	if lang.IObj_InstanceOf(fx__2) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(fx__2, A_arbace_repr_go_convert_A_const_371) } else { return fx__2 } } else {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(x__1) } }


func A_arbace_repr_go_convert_expr_fn__1114000227_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_convert_expr_fn__1114000227_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_expr_fn__1114000227_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :775:1
func (t *A_arbace_repr_go_convert_expr_fn__1114000227_A) Ctor_O_O_O_O_O(c__operand, c__logical, c__f, c__n, c__op any) { t.F_operand = c__operand; t.F_logical = c__logical; t.F_f = c__f; t.F_n = c__n; t.F_op = c__op }
//line :775:1
func (t *A_arbace_repr_go_convert_expr_fn__1114000227_A) Invoke_O__O(self any) any { { var x__1 any = A_arbace_repr_go_convert_A_const_34.Invoke_O__O(t.F_f); var acc__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(t.F_operand); var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_289; var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; acc__2 = tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4))); var nodes__3 any; var tmp5 any; var t__2 any = t.F_n; t.F_n = nil; tmp5 = t__2; nodes__3 = lang.Tuple_Create_O__IPersistentVector(tmp5); L1: for { var u__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(x__1); var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(x__1, u__4)

	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(t.F_logical); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_148.Get__O()); if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp7 any = t.F_op; var tmp8 *lang.Keyword = A_arbace_repr_go_convert_A_const_280; tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_367.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__4))))).Ref() } else { tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(x__1) }
	var tmp9 any; var tmp10 any = A_arbace_repr_go_convert_A_const_104; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z(tmp10, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(u__4)); if and__1927000168__auto____5_2 { var tmp11 any = t.F_op; var tmp12 *lang.Keyword = A_arbace_repr_go_convert_A_const_280; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_O_O__Z(tmp11, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_367.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__4)))); if and__1927000168__auto____6_2 {
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()); var tmp14 any; var and__1927000168__auto____7_2 any; var or__1927000174__auto____7 any = t.F_logical; if jrt.J2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7_2 = or__1927000174__auto____7 } else { and__1927000168__auto____7_2 = A_arbace_repr_go_convert_A_const_148.Get__O() }; if jrt.J2g_Truth(and__1927000168__auto____7_2) { tmp14 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(x__1, u__4) } else { tmp14 = and__1927000168__auto____7_2 }; tmp9 = tmp13.Invoke_O__O(tmp14) } else {
//line :778:1
			tmp9 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6_2).Ref() } } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp9) {

				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(u__4)
				var tmp15 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; var tmp16 lang.IFn = lang.IFn_Cast(t.F_operand); var tmp17 *lang.Keyword = A_arbace_repr_go_convert_A_const_289; x__1, acc__2, nodes__3 = tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__4)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(tmp16.Invoke_O__O(tmp17.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(u__4))), acc__2), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_9.GetRawRoot__O()).Invoke_O_O__O(nodes__3, u__4); continue L1 } else {
//line :778:1
					return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_operand).Invoke_O__O(x__1), acc__2), nodes__3) } } }; /*line :775:1*/panic("j2g: unreachable") }









func A_arbace_repr_go_convert_expr_fn__1114000230_A_New() *A_arbace_repr_go_convert_expr_fn__1114000230_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_expr_fn__1114000230_A{}; t.Ctor(); return t }
//line :785:1
func (t *A_arbace_repr_go_convert_expr_fn__1114000230_A) Ctor() {}
//line :785:1
func (t *A_arbace_repr_go_convert_expr_fn__1114000230_A) Invoke_O_O__O(self, p1__1114000214_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_53; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(p1__1114000214_SHARP___1))) }













func A_arbace_repr_go_convert_targets_A_New() *A_arbace_repr_go_convert_targets_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_targets_A{}; t.Ctor(); return t }
//line :799:1
func (t *A_arbace_repr_go_convert_targets_A) Ctor() {}
//line :799:1
func (t *A_arbace_repr_go_convert_targets_A) Invoke_O_O_O_O__O(self, lhs__0, l__1, mk__2 any) any {


	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(lhs__0))) {
		return lang.IFn_Cast(mk__2).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lhs__0)) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp3 any = A_arbace_repr_go_convert_A_const_381; return tmp1.Invoke_O_O_O_O_O__O(tmp2, nil, l__1, tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(mk__2, lhs__0))
		} }
func A_arbace_repr_go_convert_inits_A_New() *A_arbace_repr_go_convert_inits_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_inits_A{}; t.Ctor(); return t }
//line :806:1
func (t *A_arbace_repr_go_convert_inits_A) Ctor() {}
//line :806:1
func (t *A_arbace_repr_go_convert_inits_A) Invoke_O_O_O__O(self, rhs__0, l__1 any) any {
	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(rhs__0))) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rhs__0)) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rhs__0)); var tmp4 any = A_arbace_repr_go_convert_A_const_382; return tmp1.Invoke_O_O_O_O_O__O(tmp2, nil, tmp3, tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O(), rhs__0))
		} }
func A_arbace_repr_go_convert_define_target_A_New() *A_arbace_repr_go_convert_define_target_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_define_target_A{}; t.Ctor(); return t }
//line :811:1
func (t *A_arbace_repr_go_convert_define_target_A) Ctor() {}
//line :811:1
func (t *A_arbace_repr_go_convert_define_target_A) Invoke_O_O__O(self, n__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(s__2); if



	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_383, s__2); if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_173; var and__1927000168__auto____5 bool = lang.Util_Identical_O_O__Z(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0)), nil); if and__1927000168__auto____5 { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_171; tmp1 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(n__0)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp6 any = A_arbace_repr_go_convert_A_const_384; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; return tmp4.Invoke_O_O_O_O__O(s__2, tmp5, tmp6, tmp7.Ref()) } else {
//line :815:1
			return s__2 } }



func A_arbace_repr_go_convert_define_binding_A_New() *A_arbace_repr_go_convert_define_binding_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_define_binding_A{}; t.Ctor(); return t }
//line :819:1
func (t *A_arbace_repr_go_convert_define_binding_A) Ctor() {}
//line :819:1
func (t *A_arbace_repr_go_convert_define_binding_A) Invoke_O_O__O(self, st__0 any) any { var map__1114000236__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(st__0); var map__1114000236__3 any; if


	lang.ISeq_InstanceOf(map__1114000236__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000236__2)) { map__1114000236__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000236__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000236__2)) { map__1114000236__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000236__2) } else { lang.PersistentArrayMap_Init(); map__1114000236__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000236__3 = map__1114000236__2 }; var lhs__4 any = /*line :819:1*/lang.RT_Get_O_O__O(map__1114000236__3, A_arbace_repr_go_convert_A_const_79); var rhs__5 any = lang.RT_Get_O_O__O(map__1114000236__3, A_arbace_repr_go_convert_A_const_385); var l__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(st__0); var t__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_386.GetRawRoot__O()).Invoke_O_O_O__O(lhs__4, l__6, A_arbace_repr_go_convert_A_const_387.GetRawRoot__O()); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(t__7, st__0, l__6), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_388.GetRawRoot__O()).Invoke_O_O__O(rhs__5, l__6)) }







func A_arbace_repr_go_convert_const_val_A_New() *A_arbace_repr_go_convert_const_val_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_const_val_A{}; t.Ctor(); return t }
//line :827:1
func (t *A_arbace_repr_go_convert_const_val_A) Ctor() {}
//line :827:1
func (t *A_arbace_repr_go_convert_const_val_A) Invoke_O_O__O(self, nm__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_173; var o__2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(nm__0)); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(o__2, A_arbace_repr_go_convert_A_const_390)) { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_389.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_390.Invoke_O__O(o__2), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_391.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_314.Invoke_O__O(o__2)))
		if jrt.J2g_Truth(temp__1927000414__auto____3) { var v__4 any = temp__1927000414__auto____3; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_390, v__4)) } else { return nil } } else {
//line :831:1
			return nil } }



func A_arbace_repr_go_convert_decl_bindings_A_New() *A_arbace_repr_go_convert_decl_bindings_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_bindings_A{}; t.Ctor(); return t }
//line :835:1
func (t *A_arbace_repr_go_convert_decl_bindings_A) Ctor() {}
//line :835:1
func (t *A_arbace_repr_go_convert_decl_bindings_A) Invoke_O_O__O(self, st__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_76; var gd__2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(st__0)); var map__1114000241__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(gd__2); var map__1114000241__4 any; if


	lang.ISeq_InstanceOf(map__1114000241__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000241__3)) { map__1114000241__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000241__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000241__3)) { map__1114000241__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000241__3) } else { lang.PersistentArrayMap_Init(); map__1114000241__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000241__4 = map__1114000241__3 }; var tok__5 any = /*line :835:1*/lang.RT_Get_O_O__O(map__1114000241__4, A_arbace_repr_go_convert_A_const_392); var specs__6 any = lang.RT_Get_O_O__O(map__1114000241__4, A_arbace_repr_go_convert_A_const_393);




	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(gd__2); var G__1114000243__7_ any = tok__5; switch
	lang.Util_Hash_O__I(G__1114000243__7_) >> 2 & 3 { case 0: if lang.Util_Equiv_O_O__Z(G__1114000243__7_, Lit_97) { var tmp2 any = A_arbace_repr_go_convert_A_const_394; var tmp3 any = A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A_New_O_O(specs__6, gd__2); var tmp4 *jrt.Class
		var fncls__50 /*line :841:1*/*jrt.Class = A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A_fn_class


















		if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A_fn_class = fncls__50d; tmp4 = fncls__50d } else { tmp4 = fncls__50 }
//line :841:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()) }; case 1: if lang.Util_Equiv_O_O__Z(G__1114000243__7_, Lit_99) { var tmp5 any = A_arbace_repr_go_convert_A_const_394; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_237.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A_New_O_O(specs__6, gd__2); var tmp9 *jrt.Class
			var fncls__52 /*line :841:1*/*jrt.Class = A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A_fn_class




			if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_100, false); A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A_fn_class = fncls__52d; tmp9 = fncls__52d } else { tmp9 = fncls__52 }
//line :841:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), specs__6))) }; case 2: if lang.Util_Equiv_O_O__Z(G__1114000243__7_, Lit_101) { var tmp10 any = A_arbace_repr_go_convert_A_const_404; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_237.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A_New_O_O(specs__6, gd__2); var tmp14 *jrt.Class
				var fncls__53 /*line :841:1*/*jrt.Class = A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A_fn_class
















































				if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A_fn_class = fncls__53d; tmp14 = fncls__53d } else { tmp14 = fncls__53 }
//line :841:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O__O(tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), specs__6))) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1114000243__7_))))) }




func A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A{}; t.Ctor_O_O(p0, p1); return t }
//line :846:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A) Ctor_O_O(c__specs, c__gd any) { t.F_specs = c__specs; t.F_gd = c__gd }
//line :846:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A) Invoke_O_O__O(self, sp__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sp__1)
//line :846:1
	var map__1114000259__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__1); var map__1114000259__3 any

	if lang.ISeq_InstanceOf(map__1114000259__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000259__2)) { map__1114000259__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000259__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000259__2)) { map__1114000259__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000259__2) } else { lang.PersistentArrayMap_Init(); map__1114000259__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000259__3 = map__1114000259__2 }
//line :846:1
	var names__4 any = lang.RT_Get_O_O__O(map__1114000259__3, A_arbace_repr_go_convert_A_const_54); var type__5 any = lang.RT_Get_O_O__O(map__1114000259__3, A_arbace_repr_go_convert_A_const_60); var values__6 any = lang.RT_Get_O_O__O(map__1114000259__3, A_arbace_repr_go_convert_A_const_395); var l__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__1); var t__8 any



	if jrt.J2g_Truth(type__5) { t__8 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__5) } else { t__8 = nil }
//line :846:1
	var mk__9 any; var tmp1 any = A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A_New_O(t__8); var tmp2 *jrt.Class
	var fncls__51 /*line :846:1*/*jrt.Class = A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A_fn_class

	if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A_fn_class = fncls__51d; tmp2 = fncls__51d } else { tmp2 = fncls__51 }; mk__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :846:1
	var tg__10 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_386.GetRawRoot__O()).Invoke_O_O_O__O(names__4, l__7, mk__9); var tmp5 any





	if lang.Util_Equiv_O_O__Z(sp__1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(t.F_specs)) { tmp5 = t.F_gd } else { tmp5 = nil }; tg__10 = tmp3.Invoke_O_O_O__O(tmp4, tmp5, l__7)
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_161.GetRawRoot__O()).Invoke_O__O(values__6)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_402; var tmp8 any; var or__1927000174__auto____11 any = t__8
		if jrt.J2g_Truth(or__1927000174__auto____11) { tmp8 = or__1927000174__auto____11 } else { tmp8 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_107, sp__1) }
//line :853:1
		return lang.Tuple_Create_O_O__IPersistentVector(tg__10, tmp6.Invoke_O_O_O_O__O(nil, l__7, tmp7, tmp8)) } else { if jrt.J2g_Truth(t__8) { return lang.Tuple_Create_O_O__IPersistentVector(tg__10, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_388.GetRawRoot__O()).Invoke_O_O__O(values__6, l__7)) } else { if A_arbace_repr_go_convert_A_const_152 != nil { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp11 any = A_arbace_repr_go_convert_A_const_403; var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; return lang.Tuple_Create_O_O__IPersistentVector(tmp9.Invoke_O_O_O_O__O(tg__10, tmp10, tmp11, tmp12.Ref()), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_388.GetRawRoot__O()).Invoke_O_O__O(values__6, l__7)) } else { return nil } } } }
//line :848:1
func A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A_New_O(p0 any) *A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A{}; t.Ctor_O(p0); return t }
//line :848:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :848:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A) Invoke_O_O__O(self, p1__1114000240_SHARP___1 any) any {


	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_253.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(p1__1114000240_SHARP___1), t.F_t)
}







func A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A{}; t.Ctor_O_O(p0, p1); return t }
//line :860:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A) Ctor_O_O(c__specs, c__gd any) { t.F_specs = c__specs; t.F_gd = c__gd }
//line :860:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A) Invoke_O__O(self any) any { { var specs__1 any; var t_ any = t.F_specs; t.F_specs = nil; specs__1 = t_; var prev__2 any; var acc__3 any; lang.PersistentVector_Init(); acc__3 = lang.PersistentVector_EMPTY.Ref(); var iota__4 int64 = 0; var specs_STAR___5 any = specs__1; L1: for { var temp__1927000408__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(specs__1)
												if jrt.J2g_Truth(temp__1927000408__auto____6) { var sp__7 any = temp__1927000408__auto____6; var map__1114000245__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__7); var map__1114000245__9 any
													if lang.ISeq_InstanceOf(map__1114000245__8) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000245__8)) { map__1114000245__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000245__8), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000245__8)) { map__1114000245__9 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000245__8) } else { lang.PersistentArrayMap_Init(); map__1114000245__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000245__9 = map__1114000245__8 }
//line :861:1
		var names__10 any = lang.RT_Get_O_O__O(map__1114000245__9, A_arbace_repr_go_convert_A_const_54); var type__11 any = lang.RT_Get_O_O__O(map__1114000245__9, A_arbace_repr_go_convert_A_const_60); var values__12 any = lang.RT_Get_O_O__O(map__1114000245__9, A_arbace_repr_go_convert_A_const_395); var ___13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sp__7); var l__14 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__7); var vec__1114000247__15 any; _ = ___13



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(values__12)) { var tmp1 *jrt.Boolean; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE; vec__1114000247__15 = lang.Tuple_Create_O_O_O__IPersistentVector(type__11, values__12, tmp1.Ref()) } else { var tmp2 any = A_arbace_repr_go_convert_A_const_60.Invoke_O__O(prev__2); var tmp3 any = A_arbace_repr_go_convert_A_const_395.Invoke_O__O(prev__2); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; vec__1114000247__15 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, tmp4.Ref()) }
//line :861:1
		var type__16 any = lang.RT_Nth_O_I_O__O(vec__1114000247__15, lang.RT_IntCast_J__I(0), nil); var values__17 any = lang.RT_Nth_O_I_O__O(vec__1114000247__15, lang.RT_IntCast_J__I(1), nil); var implicit__18 any = lang.RT_Nth_O_I_O__O(vec__1114000247__15, lang.RT_IntCast_J__I(2), nil); var ___19 any; _ = ___19





		if jrt.J2g_Truth(implicit__18) { ___19 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_397) } else { ___19 = nil }
//line :861:1
		var t__20 any






		if jrt.J2g_Truth(type__16) { if jrt.J2g_Truth(implicit__18) {
			lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_12, nil)); var tmp5 any = A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A_New_O_O(type__16, l__14); var tmp6 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A_fn_class = fncls__47d; tmp6 = fncls__47d } else { tmp6 = fncls__47 }; t__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O() } else {
				t__20 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__16) } } else {
//line :868:1
					t__20 = nil }
//line :861:1
		var mk__21 any; var tmp7 any = A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A_New_O(t__20); var tmp8 *jrt.Class
		var fncls__48 /*line :861:1*/*jrt.Class = A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A_fn_class









		if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A_fn_class = fncls__48d; tmp8 = fncls__48d } else { tmp8 = fncls__48 }; mk__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :861:1
		var tg__22 any; var G__1114000254__22_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_386.GetRawRoot__O()).Invoke_O_O_O__O(names__10, l__14, mk__21); var G__1114000254__23_ any











		if lang.Util_Equiv_O_O__Z(sp__7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(specs_STAR___5)) {
			G__1114000254__23_ = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(G__1114000254__22_, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_295.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(t.F_gd), A_arbace_repr_go_convert_A_const_398)) } else {
//line :873:1
				G__1114000254__23_ = G__1114000254__22_ }
//line :861:1
		var G__1114000254__24_ any; var tmp9 bool; var and__1927000168__auto____24 bool = lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(specs_STAR___5)), 1)















		if and__1927000168__auto____24 { tmp9 = lang.Numbers_IsPos_J__Z(iota__4) } else { tmp9 = and__1927000168__auto____24 }
//line :873:1
		if tmp9 {



			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp12 any = A_arbace_repr_go_convert_A_const_229; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; G__1114000254__24_ = tmp10.Invoke_O_O_O_O__O(G__1114000254__23_, tmp11, tmp12, tmp13.Ref()) } else {
//line :873:1
				G__1114000254__24_ = G__1114000254__23_ }; if jrt.J2g_Truth(implicit__18) {




					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp15 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp16 any = A_arbace_repr_go_convert_A_const_399; var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; tg__22 = tmp14.Invoke_O_O_O_O__O(G__1114000254__24_, tmp15, tmp16, tmp17.Ref()) } else {
//line :873:1
						tg__22 = G__1114000254__24_ }
//line :861:1
		var init__23 any

















		if jrt.J2g_Truth(implicit__18) {
			lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_12, nil)); var tmp18 any = A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A_New_O_O(values__17, l__14); var tmp19 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A_fn_class = fncls__49d; tmp19 = fncls__49d } else { tmp19 = fncls__49 }; init__23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O() } else {
				init__23 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_388.GetRawRoot__O()).Invoke_O_O__O(values__17, l__14) }
		var tmp20 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(specs__1); var tmp21 any; if jrt.J2g_Truth(implicit__18) { tmp21 = prev__2 } else { tmp21 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__7) }; specs__1, prev__2, acc__3, iota__4, specs_STAR___5 = tmp20, tmp21, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_9.GetRawRoot__O()).Invoke_O_O_O__O(acc__3, tg__22, init__23), lang.Numbers_Inc_J__J(iota__4), specs_STAR___5; continue L1 } else {
			if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(specs_STAR___5)), 1) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_400) }
			if lang.Numbers_Gt_J_J__Z(iota__4, 1) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_401) }
//line :861:1
			return acc__3 } } }; /*line :860:1*/panic("j2g: unreachable") }








func A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :869:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A) Ctor_O_O(c__type, c__l any) { t.F_type = c__type; t.F_l = c__l }
//line :869:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_169.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_l; t.F_l = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_type; t.F_type = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5.Invoke_O__O(tmp6)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }

func A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A_New_O(p0 any) *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A{}; t.Ctor_O(p0); return t }
//line :871:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :871:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A) Invoke_O_O__O(self, nm__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_253.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(nm__1), t.F_t); var tmp4 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp5 any = A_arbace_repr_go_convert_A_const_187; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Ref()), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_396.GetRawRoot__O()).Invoke_O__O(nm__1))
}






func A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A{}; t.Ctor_O_O(p0, p1); return t }
//line :880:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A) Ctor_O_O(c__values, c__l any) { t.F_values = c__values; t.F_l = c__l }
//line :880:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_169.GetRawRoot__O()); var tmp3 any = t.F_l; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_388.GetRawRoot__O()); var tmp5 any; var t_ any = t.F_values; t.F_values = nil; tmp5 = t_; var tmp6 any = tmp5; var tmp7 any; var t__2 any = t.F_l; t.F_l = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp6, tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }









func A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A{}; t.Ctor_O_O(p0, p1); return t }
//line :890:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A) Ctor_O_O(c__specs, c__gd any) { t.F_specs = c__specs; t.F_gd = c__gd }
//line :890:1
func (t *A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A) Invoke_O_O__O(self, sp__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sp__1)
//line :890:1
	var map__1114000265__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__1); var map__1114000265__3 any

	if lang.ISeq_InstanceOf(map__1114000265__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000265__2)) { map__1114000265__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000265__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000265__2)) { map__1114000265__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000265__2) } else { lang.PersistentArrayMap_Init(); map__1114000265__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000265__3 = map__1114000265__2 }
//line :890:1
	var name__4 any = lang.RT_Get_O_O__O(map__1114000265__3, A_arbace_repr_go_convert_A_const_49); var assign__5 any = lang.RT_Get_O_O__O(map__1114000265__3, A_arbace_repr_go_convert_A_const_384); var type__6 any = lang.RT_Get_O_O__O(map__1114000265__3, A_arbace_repr_go_convert_A_const_60); var tparams__7 any = lang.RT_Get_O_O__O(map__1114000265__3, A_arbace_repr_go_convert_A_const_405); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O())
	var tmp2 any = A_arbace_repr_go_convert_A_const_227

	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_407.GetRawRoot__O()).Invoke_O__O(sp__1))).Ref()))
//line :890:1
	var tmp3 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tps__10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_406.GetRawRoot__O()).Invoke_O__O(tparams__7); var nm__11 any; var G__1114000267__11_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(name__4); var G__1114000267__12_ any




		if lang.Util_Equiv_O_O__Z(sp__1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(t.F_specs)) {
			G__1114000267__12_ = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(G__1114000267__11_, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_295.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(t.F_gd), A_arbace_repr_go_convert_A_const_408)) } else {
//line :895:1
				G__1114000267__12_ = G__1114000267__11_ }
//line :890:1
		var G__1114000267__13_ any




		if jrt.J2g_Truth(assign__5) {

			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp6 any = A_arbace_repr_go_convert_A_const_409; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; G__1114000267__13_ = tmp4.Invoke_O_O_O_O__O(G__1114000267__12_, tmp5, tmp6, tmp7.Ref()) } else {
//line :895:1
				G__1114000267__13_ = G__1114000267__12_ }; if jrt.J2g_Truth(tps__10) {


					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp10 any = A_arbace_repr_go_convert_A_const_405; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp12 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp13 any = A_arbace_repr_go_convert_A_const_140; nm__11 = tmp8.Invoke_O_O_O_O__O(G__1114000267__13_, tmp9, tmp10, tmp11.Invoke_O_O_O_O__O(tps__10, tmp12, tmp13, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__1))) } else {
//line :895:1
						nm__11 = G__1114000267__13_ }
//line :890:1
		var ___12 any; _ = ___12








		if jrt.J2g_Truth(tps__10) { ___12 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_410) } else { ___12 = nil }
//line :890:1
		tmp3 = lang.Tuple_Create_O_O__IPersistentVector(nm__11, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__6)) }; return nil }()


	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O()
//line :890:1
	if tmp14 != nil { panic(tmp14) }; return tmp3
}











func A_arbace_repr_go_convert_decl_stmt_QMARK__A_New() *A_arbace_repr_go_convert_decl_stmt_QMARK__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_stmt_QMARK__A{}; t.Ctor(); return t }
//line :903:1
func (t *A_arbace_repr_go_convert_decl_stmt_QMARK__A) Ctor() {}
//line :903:1
func (t *A_arbace_repr_go_convert_decl_stmt_QMARK__A) Invoke_O_O__O(self, st__0 any) any { var G__1114000270__2_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(st__0); switch


	lang.Util_Hash_O__I(G__1114000270__2_) >> 2 & 3 { case 1: if any(G__1114000270__2_) == any(A_arbace_repr_go_convert_A_const_95) {


		var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_412; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_411.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(st__0))) }
//line :906:1
	case 2: if any(G__1114000270__2_) == any(A_arbace_repr_go_convert_A_const_74) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__1114000270__2_) == any(A_arbace_repr_go_convert_A_const_77) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_26, tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(st__0)))).Ref() }
//line :906:1
	default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }





func A_arbace_repr_go_convert_bindings_of_A_New() *A_arbace_repr_go_convert_bindings_of_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_bindings_of_A{}; t.Ctor(); return t }
//line :912:1
func (t *A_arbace_repr_go_convert_bindings_of_A) Ctor() {}
//line :912:1
func (t *A_arbace_repr_go_convert_bindings_of_A) Invoke_O_O__O(self, st__0 any) any { var G__1114000272__2_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(st__0); switch
											lang.Util_Hash_O__I(G__1114000272__2_) >> 2 & 3 { case 1: if any(G__1114000272__2_) == any(A_arbace_repr_go_convert_A_const_95) {


		var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_412; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_413.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(st__0))) }
//line :913:1
	case 2: if any(G__1114000272__2_) == any(A_arbace_repr_go_convert_A_const_74) {

		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(st__0); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_414.GetRawRoot__O()).Invoke_O__O(st__0) }
//line :913:1
	case 3: if any(G__1114000272__2_) == any(A_arbace_repr_go_convert_A_const_77) {
		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(st__0)
//line :913:1
		var tmp2 any = A_arbace_repr_go_convert_A_const_394; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_415.GetRawRoot__O()).Invoke_O__O(st__0)) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1114000272__2_))))) }






func A_arbace_repr_go_convert_dir_form_A_New() *A_arbace_repr_go_convert_dir_form_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_dir_form_A{}; t.Ctor(); return t }
//line :920:1
func (t *A_arbace_repr_go_convert_dir_form_A) Ctor() {}
//line :920:1
func (t *A_arbace_repr_go_convert_dir_form_A) Invoke_O_O__O(self, p__1114000274__0 any) any { var vec__1114000275__2 any = p__1114000274__0; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000275__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000275__2, lang.RT_IntCast_J__I(1), nil); var text__5 any = lang.RT_Nth_O_I_O__O(vec__1114000275__2, lang.RT_IntCast_J__I(2), nil);
												lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_convert_A_const_416.Get__O(), A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4));
												lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_417); var tmp1 lang.IFn =
												lang.IFn_Cast(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_418; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(text__5), text__5)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_140, l__3))) }

func A_arbace_repr_go_convert_gap_directives_A_New() *A_arbace_repr_go_convert_gap_directives_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gap_directives_A{}; t.Ctor(); return t }
//line :925:1
func (t *A_arbace_repr_go_convert_gap_directives_A) Ctor() {}
//line :925:1
func (t *A_arbace_repr_go_convert_gap_directives_A) Invoke_O_O_O_O__O(self, stmts__0, from__1, to__2 any) any { var dirs__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_28.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_gap_directives_fn__1114000280_A_New_O_O(from__1, to__2); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_repr_go_convert_gap_directives_fn__1114000280_A_fn_class; if



	fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_140, false); A_arbace_repr_go_convert_gap_directives_fn__1114000280_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; dirs__4 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), A_arbace_repr_go_convert_A_const_422.Get__O()); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_161.GetRawRoot__O()).Invoke_O__O(dirs__4)) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_423.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(stmts__0)))).Ref(), nil)) } else {
//line :930:1
			var ranges__5 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_170.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_gap_directives_fn__1114000285_A_New(); var tmp6 *jrt.Class
			var fncls__59 /*line :930:1*/*jrt.Class = A_arbace_repr_go_convert_gap_directives_fn__1114000285_A_fn_class

			if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_141, false); A_arbace_repr_go_convert_gap_directives_fn__1114000285_A_fn_class = fncls__59d; tmp6 = fncls__59d } else { tmp6 = fncls__59 }; ranges__5 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), stmts__0)
//line :930:1
			var inside_QMARK___6 any; var tmp7 any = A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A_New_O(ranges__5); var tmp8 *jrt.Class
			var fncls__57 /*line :930:1*/*jrt.Class = A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A_fn_class


			if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_142, false); A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A_fn_class = fncls__57d; tmp8 = fncls__57d } else { tmp8 = fncls__57 }; inside_QMARK___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :930:1
			var free__7 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_420.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_convert_gap_directives_fn__1114000296_A_New_O(inside_QMARK___6); var tmp11 *jrt.Class
			var fncls__60 /*line :930:1*/*jrt.Class = A_arbace_repr_go_convert_gap_directives_fn__1114000296_A_fn_class



			if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_143, false); A_arbace_repr_go_convert_gap_directives_fn__1114000296_A_fn_class = fncls__60d; tmp11 = fncls__60d } else { tmp11 = fncls__60 }; free__7 = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), dirs__4)
			var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_421.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_convert_gap_directives_fn__1114000302_A_New_O_O(stmts__0, ranges__5); var tmp14 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_repr_go_convert_gap_directives_fn__1114000302_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_144, false); A_arbace_repr_go_convert_gap_directives_fn__1114000302_A_fn_class = fncls__62d; tmp14 = fncls__62d } else { tmp14 = fncls__62 }; return tmp12.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_423.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(stmts__0)))).Ref(), nil)), free__7) } }
//line :929:1
func A_arbace_repr_go_convert_gap_directives_fn__1114000280_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_gap_directives_fn__1114000280_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gap_directives_fn__1114000280_A{}; t.Ctor_O_O(p0, p1); return t }
//line :929:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000280_A) Ctor_O_O(c__from, c__to any) { t.F_from = c__from; t.F_to = c__to }
//line :929:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000280_A) Invoke_O_O__O(self, p__1114000279__1 any) any { var vec__1114000281__2 any = p__1114000279__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000281__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000281__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 bool = lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), t.F_from))); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), t.F_to)))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }


func A_arbace_repr_go_convert_gap_directives_fn__1114000285_A_New() *A_arbace_repr_go_convert_gap_directives_fn__1114000285_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gap_directives_fn__1114000285_A{}; t.Ctor(); return t }
//line :932:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000285_A) Ctor() {}
//line :932:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000285_A) Invoke_O_O__O(self, s__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(s__1)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_424.GetRawRoot__O()).Invoke_O__O(s__1)) }
func A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A_New_O(p0 any) *A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A{}; t.Ctor_O(p0); return t }
//line :933:1
func (t *A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A) Ctor_O(c__ranges any) { t.F_ranges = c__ranges }
//line :933:1
func (t *A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_419.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A_New_O(p__1); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_146, false); A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_ranges) }
//line :933:1
func A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A_New_O(p0 any) *A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A{}; t.Ctor_O(p0); return t }
//line :933:1
func (t *A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :933:1
func (t *A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A) Invoke_O_O__O(self, p__1114000288__1 any) any { var vec__1114000290__2 any = p__1114000288__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1114000290__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1114000290__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 bool = lang.Numbers_Lte_J_J__Z(int64(lang.Util_Compare_O_O__I(a__3, t.F_p)), 0); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lte_J_J__Z(int64(lang.Util_Compare_O_O__I(t.F_p, b__4)), 0)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }
func A_arbace_repr_go_convert_gap_directives_fn__1114000296_A_New_O(p0 any) *A_arbace_repr_go_convert_gap_directives_fn__1114000296_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gap_directives_fn__1114000296_A{}; t.Ctor_O(p0); return t }
//line :934:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000296_A) Ctor_O(c__inside_QMARK_ any) { t.F_inside_QMARK_ = c__inside_QMARK_ }
//line :934:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000296_A) Invoke_O_O__O(self, p__1114000295__1 any) any { var vec__1114000297__2 any = p__1114000295__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000297__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000297__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_inside_QMARK_); return tmp1.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4)) }
func A_arbace_repr_go_convert_gap_directives_fn__1114000302_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_gap_directives_fn__1114000302_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gap_directives_fn__1114000302_A{}; t.Ctor_O_O(p0, p1); return t }
//line :935:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000302_A) Ctor_O_O(c__stmts, c__ranges any) { t.F_stmts = c__stmts; t.F_ranges = c__ranges }
//line :935:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000302_A) Invoke_O_O_O__O(self, gaps__1, p__1114000301__2 any) any { var vec__1114000303__3 any = p__1114000301__2; var l__4 any = lang.RT_Nth_O_I_O__O(vec__1114000303__3, lang.RT_IntCast_J__I(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__1114000303__3, lang.RT_IntCast_J__I(1), nil); var d__6 any = vec__1114000303__3; var k__7 any; var or__1927000174__auto____7 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_425.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A_New_O_O(l__4, c__5); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A_fn_class; if
																fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_145, false); A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; or__1927000174__auto____7 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_ranges)); if jrt.J2g_Truth(or__1927000174__auto____7) { k__7 = or__1927000174__auto____7 } else {
																	k__7 = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_stmts)).Ref() }; var tmp5 lang.IFn =
																lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_15.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(); var tmp8 *lang.PersistentVector; lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY; return tmp5.Invoke_O_O_O_O__O(gaps__1, k__7, tmp6.Invoke_O_O__O(tmp7, tmp8.Ref()), d__6) }
//line :936:1
func A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A{}; t.Ctor_O_O(p0, p1); return t }
//line :936:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :936:1
func (t *A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A) Invoke_O_O_O__O(self, i__1, p__1114000306__2 any) any { var vec__1114000308__3 any = p__1114000306__2; var a__4 any = lang.RT_Nth_O_I_O__O(vec__1114000308__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1114000308__3, lang.RT_IntCast_J__I(1), nil); _ = ___5; if lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(a__4, lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c)))) { return i__1 } else { return nil } }





func A_arbace_repr_go_convert_stmts_forms_A_New() *A_arbace_repr_go_convert_stmts_forms_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmts_forms_A{}; t.Ctor(); return t }
//line :942:1
func (t *A_arbace_repr_go_convert_stmts_forms_A) Ctor() {}
//line :942:1
func (t *A_arbace_repr_go_convert_stmts_forms_A) Invoke_O_O_O_O_O__O(self, list__0, from__1, to__2, p__1114000316__3 any) any { var map__1114000317__5 any = p__1114000316__3; var map__1114000317__6 any; if lang.ISeq_InstanceOf(map__1114000317__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000317__5)) { map__1114000317__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000317__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000317__5)) { map__1114000317__6 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000317__5) } else { lang.PersistentArrayMap_Init(); map__1114000317__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000317__6 = map__1114000317__5 }; var tail__7 any = lang.RT_Get_O_O__O(map__1114000317__6, A_arbace_repr_go_convert_A_const_350); var stmts__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_420.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A_New(); var tmp4 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A_fn_class; if




	fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_226, false); A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A_fn_class = fncls__68d; tmp4 = fncls__68d } else { tmp4 = fncls__68 }; stmts__8 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), list__0)); var ___9 any; var tmp5 any = /*line :942:1*/A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A_New_O(list__0); var tmp6 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A_fn_class; _ = ___9; if





	fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_227, false); A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A_fn_class = fncls__63d; tmp6 = fncls__63d } else { tmp6 = fncls__63 }; ___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var gaps__10 any = /*line :942:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_426.GetRawRoot__O()).Invoke_O_O_O__O(stmts__8, from__1, to__2); var n__11 int32 = lang.RT_Count_O__I(stmts__8); var body_build__12 *A_arbace_repr_go_convert_stmts_forms_build__1114000327_A = A_arbace_repr_go_convert_stmts_forms_build__1114000327_A_New_I_O_O_O(n__11, stmts__8, tail__7, gaps__10); var build__12 any; var tmp7 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_repr_go_convert_stmts_forms_build__1114000327_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_228, false); A_arbace_repr_go_convert_stmts_forms_build__1114000327_A_fn_class = fncls__67d; tmp7 = fncls__67d } else { tmp7 = fncls__67 }; build__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_build__12), tmp7, nil); return /*line :990:1*/ lang.IFn_Cast(A_arbace_repr_go_convert_A_const_348.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(build__12).Invoke_O__O(A_arbace_repr_go_convert_A_const_18)) }
//line :947:1
func A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A_New() *A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A{}; t.Ctor(); return t }
//line :947:1
func (t *A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A) Ctor() {}
//line :947:1
func (t *A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A) Invoke_O_O__O(self, p1__1114000314_SHARP___1 any) any { var tmp1 any = A_arbace_repr_go_convert_A_const_87; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(p1__1114000314_SHARP___1))).Ref() }
func A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A_New_O(p0 any) *A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A{}; t.Ctor_O(p0); return t }
//line :948:1
func (t *A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A) Ctor_O(c__list any) { t.F_list = c__list }
//line :948:1
func (t *A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A) Invoke_O__O(self any) any { { var seq_1114000321__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_list; t.F_list = nil; tmp2 = t_; seq_1114000321__1 = tmp1.Invoke_O__O(tmp2); var chunk_1114000322__2 any; var count_1114000323__3 int64 = 0; var i_1114000324__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_1114000324__4, count_1114000323__3) { var s__5 any = lang.Indexed_Cast(chunk_1114000322__2).Nth_I__O(lang.RT_IntCast_J__I(i_1114000324__4)); var tmp3 any = A_arbace_repr_go_convert_A_const_87; if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(s__5)) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(s__5); seq_1114000321__1, chunk_1114000322__2, count_1114000323__3, i_1114000324__4 = seq_1114000321__1, chunk_1114000322__2, count_1114000323__3, lang.Numbers_Unchecked_inc_J__J(i_1114000324__4); continue L1 } else { seq_1114000321__1, chunk_1114000322__2, count_1114000323__3, i_1114000324__4 = seq_1114000321__1, chunk_1114000322__2, count_1114000323__3, lang.Numbers_Unchecked_inc_J__J(i_1114000324__4); continue L1 } } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1114000321__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1114000321__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(seq_1114000321__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(seq_1114000321__6); seq_1114000321__1, chunk_1114000322__2, count_1114000323__3, i_1114000324__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_1114000321__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var s__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1114000321__6); var tmp4 any = A_arbace_repr_go_convert_A_const_87; if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(s__7)) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(s__7); seq_1114000321__1, chunk_1114000322__2, count_1114000323__3, i_1114000324__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq_1114000321__6), nil, 0, 0; continue L1 } else { seq_1114000321__1, chunk_1114000322__2, count_1114000323__3, i_1114000324__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq_1114000321__6), nil, 0, 0; continue L1 } } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_convert_stmts_forms_build__1114000327_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_repr_go_convert_stmts_forms_build__1114000327_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmts_forms_build__1114000327_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :951:1
func (t *A_arbace_repr_go_convert_stmts_forms_build__1114000327_A) Ctor_I_O_O_O(c__n int32, c__stmts, c__tail, c__gaps any) { t.F_n = c__n; t.F_stmts = c__stmts; t.F_tail = c__tail; t.F_gaps = c__gaps }
//line :951:1
func (t *A_arbace_repr_go_convert_stmts_forms_build__1114000327_A) Invoke_O_O__O(self, i__1 any) any {
	if lang.Numbers_Gte_O_J__Z(i__1, int64(t.F_n)) {
		var tmp1 any = t.F_gaps; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_427.GetRawRoot__O(), lang.RT_Get_O_O__O(tmp1, jrt.Integer_ValueOf_I__Integer(t.F_n).Ref())) } else {
//line :952:1
			var s__2 any = lang.IFn_Cast(t.F_stmts).Invoke_O__O(i__1); var pre__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_427.GetRawRoot__O(), lang.RT_Get_O_O__O(t.F_gaps, i__1))



			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_411.GetRawRoot__O()).Invoke_O__O(s__2)) { var kind_of__4 any; var tmp2 any = A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A_fn_class
				if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_229, false); A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; kind_of__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :956:1
				var kind__5 any = lang.IFn_Cast(kind_of__4).Invoke_O__O(s__2); var vec__1114000328__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_413.GetRawRoot__O()).Invoke_O__O(s__2); var ___7 any = lang.RT_Nth_O_I_O__O(vec__1114000328__6, lang.RT_IntCast_J__I(0), nil); var bs__8 any = lang.RT_Nth_O_I_O__O(vec__1114000328__6, lang.RT_IntCast_J__I(1), nil); var bs__9 any; var tmp4 any = A_arbace_repr_go_convert_A_const_95; _ = ___7








				if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(s__2)) { var ll__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(s__2); var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_412; var dl__10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(s__2)))


					lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_428); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(s__2)
					var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_18; var tmp8 any = A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A_New_O_O_O(s__2, ll__9, dl__10); var tmp9 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_230, false); A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A_fn_class = fncls__66d; tmp9 = fncls__66d } else { tmp9 = fncls__66 }; bs__9 = tmp6.Invoke_O_O_O__O(bs__8, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) } else {
//line :965:1
						bs__9 = bs__8 }
//line :956:1
				var vec__1114000331__10 any; var tmp10 any = A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A_New_I_O_O_O_O_O_O(t.F_n, t.F_stmts, i__1, bs__9, kind__5, t.F_gaps, kind_of__4); var tmp11 *jrt.Class
				var fncls__65 /*line :956:1*/*jrt.Class = A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A_fn_class



















				if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_231, false); A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A_fn_class = fncls__65d; tmp11 = fncls__65d } else { tmp11 = fncls__65 }; vec__1114000331__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
//line :956:1
				var j__11 any = lang.RT_Nth_O_I_O__O(vec__1114000331__10, lang.RT_IntCast_J__I(0), nil); var bs__12 any = lang.RT_Nth_O_I_O__O(vec__1114000331__10, lang.RT_IntCast_J__I(1), nil); var l__13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(s__2); var lf__14 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp14 any


























				if lang.Util_Equiv_O_O__Z(kind__5, A_arbace_repr_go_convert_A_const_394) { tmp14 = A_arbace_repr_go_convert_A_const_433 } else { tmp14 = A_arbace_repr_go_convert_A_const_434 }; lf__14 = tmp12.Invoke_O_O_O_O_O_O__O(tmp13, nil, l__13, tmp14, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__13, bs__12), lang.IFn_Cast(self).Invoke_O__O(j__11))

				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(pre__3, lang.Tuple_Create_O__IPersistentVector(lf__14)) } else {

					var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_128.GetRawRoot__O()); var tmp17 any = A_arbace_repr_go_convert_A_const_435.GetRawRoot__O(); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_436.GetRawRoot__O()); var tmp19 any; var and__1927000168__auto____4 any = t.F_tail
					if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Util_Equiv_O_J__Z(i__1, lang.Numbers_Dec_J__J(int64(t.F_n))); if and__1927000168__auto____5 { var tmp20 any = t.F_gaps; tmp19 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_161.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O(tmp20, jrt.Integer_ValueOf_I__Integer(t.F_n).Ref())) } else { tmp19 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { tmp19 = and__1927000168__auto____4 }
//line :987:1
					return tmp15.Invoke_O_O_O__O(pre__3, tmp16.Invoke_O_O__O(tmp17, lang.Tuple_Create_O__IPersistentVector(tmp18.Invoke_O_O__O(s__2, tmp19))), lang.IFn_Cast(self).Invoke_O__O(lang.Numbers_Inc_O__Number(i__1))) } } }
//line :957:1
func A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A_New() *A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A{}; t.Ctor(); return t }
//line :957:1
func (t *A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A) Ctor() {}
//line :957:1
func (t *A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A) Invoke_O_O__O(self, st__1 any) any { var tmp1 bool; var tmp2 any = A_arbace_repr_go_convert_A_const_74; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(st__1)); if and__1927000168__auto____2 {
																var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_76; tmp1 = lang.Util_Equiv_O_O__Z(Lit_101, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(st__1))))) } else {
//line :957:1
		tmp1 = and__1927000168__auto____2 }; if tmp1 { return A_arbace_repr_go_convert_A_const_404 } else { return A_arbace_repr_go_convert_A_const_394 } }











func A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :969:1
func (t *A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A) Ctor_O_O_O(c__s, c__ll, c__dl any) { t.F_s = c__s; t.F_ll = c__ll; t.F_dl = c__dl }
//line :969:1
func (t *A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A) Invoke_O_O__O(self, p1__1114000315_SHARP___1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_147.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_convert_A_const_430; var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_97; var tmp6 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_431.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(t.F_s))))); var tmp7 lang.IPersistentMap; var tmp8 any; var and__1927000168__auto____2 any = t.F_ll
//line :971:1
	if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = t.F_dl; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(t.F_ll, t.F_dl); if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp10 any = t.F_ll; tmp8 = tmp9.Invoke_O_O__O(tmp10, lang.Numbers_Dec_O__Number(t.F_dl)) } else { tmp8 = and__1927000168__auto____4 } } else { tmp8 = and__1927000168__auto____3 } } else { tmp8 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp8) { tmp7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_432, t.F_ll)) } else { tmp7 = nil
	}
	var tmp11 any = A_arbace_repr_go_convert_A_const_97; var tmp12 *lang.Keyword = A_arbace_repr_go_convert_A_const_97; var tmp13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(t.F_s))); var tmp14 any = A_arbace_repr_go_convert_A_const_429; var tmp15 *lang.Keyword = A_arbace_repr_go_convert_A_const_166; return tmp1.Invoke_O_O__O(tmp2.Invoke_O_O_O_O__O(p1__1114000315_SHARP___1, tmp3, tmp6, tmp7), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp14, tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(t.F_s)))))
}

func A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A_New_I_O_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5, p6 any) *A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A{}; t.Ctor_I_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :976:1
func (t *A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A) Ctor_I_O_O_O_O_O_O(c__n int32, c__stmts, c__i, c__bs, c__kind, c__gaps, c__kind_of any) { t.F_n = c__n; t.F_stmts = c__stmts; t.F_i = c__i; t.F_bs = c__bs; t.F_kind = c__kind; t.F_gaps = c__gaps; t.F_kind_of = c__kind_of }
//line :976:1
func (t *A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any; var t_ any = t.F_i; t.F_i = nil; tmp1 = t_; j__1 = lang.Numbers_Inc_O__Number(tmp1); var bs__2 any; var t__2 any = t.F_bs; t.F_bs = nil; bs__2 = t__2; L1: for {
														var tmp2 any; var and__1927000168__auto____3 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(t.F_n)); if and__1927000168__auto____3 { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_411.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_stmts).Invoke_O__O(j__1)); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_161.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O(t.F_gaps, j__1)); if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_A_const_95; var and__1927000168__auto____6 any = tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_stmts).Invoke_O__O(j__1))); if jrt.J2g_Truth(and__1927000168__auto____6) {

		var tmp5 any = t.F_kind; var tmp6 lang.IFn = lang.IFn_Cast(t.F_kind_of); tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp5, tmp6.Invoke_O__O(lang.IFn_Cast(t.F_stmts).Invoke_O__O(j__1)))).Ref() } else {
//line :977:1
			tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp2) {


				j__1, bs__2 = lang.Numbers_Inc_O__Number(j__1), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()).Invoke_O_O__O(bs__2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_413.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_stmts).Invoke_O__O(j__1)))); continue L1 } else {
//line :977:1
					return lang.Tuple_Create_O_O__IPersistentVector(j__1, bs__2) } } }; /*line :976:1*/panic("j2g: unreachable") }















func A_arbace_repr_go_convert_stmt_list_A_New() *A_arbace_repr_go_convert_stmt_list_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmt_list_A{}; t.Ctor(); return t }
//line :992:1
func (t *A_arbace_repr_go_convert_stmt_list_A) Ctor() {}
//line :992:1
func (t *A_arbace_repr_go_convert_stmt_list_A) Invoke_O_O_O__O(self, block__0, opts__1 any) any {


	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(block__0)
//line :992:1
	var map__1114000342__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(block__0); var map__1114000342__4 any



	if lang.ISeq_InstanceOf(map__1114000342__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000342__3)) { map__1114000342__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000342__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000342__3)) { map__1114000342__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000342__3) } else { lang.PersistentArrayMap_Init(); map__1114000342__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000342__4 = map__1114000342__3 }
//line :992:1
	var list__5 any = lang.RT_Get_O_O__O(map__1114000342__4, A_arbace_repr_go_convert_A_const_72); var lbrace__6 any = lang.RT_Get_O_O__O(map__1114000342__4, A_arbace_repr_go_convert_A_const_61); var rbrace__7 any = lang.RT_Get_O_O__O(map__1114000342__4, A_arbace_repr_go_convert_A_const_158)




	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_437.GetRawRoot__O()).Invoke_O_O_O_O__O(list__5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lbrace__6), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(rbrace__7), opts__1)
}
func A_arbace_repr_go_convert_block_forms_A_New() *A_arbace_repr_go_convert_block_forms_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_block_forms_A{}; t.Ctor(); return t }
//line :999:1
func (t *A_arbace_repr_go_convert_block_forms_A) Ctor() {}
//line :999:1
func (t *A_arbace_repr_go_convert_block_forms_A) Invoke_O_O__O(self, b__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(b__0); var tmp4 any = A_arbace_repr_go_convert_A_const_438; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_349.GetRawRoot__O()); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O_O_O_O__O(tmp2, b__0, tmp3, tmp4, tmp5.Invoke_O_O__O(b__0, tmp6.Ref()))
}
func A_arbace_repr_go_convert_branch_A_New() *A_arbace_repr_go_convert_branch_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_branch_A{}; t.Ctor(); return t }
//line :1004:1
func (t *A_arbace_repr_go_convert_branch_A) Ctor() {}
//line :1004:1
func (t *A_arbace_repr_go_convert_branch_A) Invoke_O_O_O__O(self, b__0, else_QMARK___1 any) any { var fs__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_349.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;



	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; fs__3 = tmp1.Invoke_O_O__O(b__0, tmp2.Ref()); var l__4 any = /*line :1004:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(b__0); var tmp3 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(fs__3))); if and__1927000168__auto____5 {





		var f0__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(fs__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()); var tmp5 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(f0__6)

		if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp6 any = A_arbace_repr_go_convert_A_const_439; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z(tmp6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(f0__6)); if or__1927000174__auto____8 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { var and__1927000168__auto____9 any = else_QMARK___1
			if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_440); tmp5 = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(f0__6)) } else { tmp5 = and__1927000168__auto____9 } } } else {
//line :1012:1
				tmp5 = and__1927000168__auto____7 }; tmp3 = tmp4.Invoke_O__O(tmp5) } else {
//line :1010:1
					tmp3 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp3) {



						return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(fs__3) } else {
							return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), b__0, l__4, A_arbace_repr_go_convert_A_const_441, fs__3) } }

func A_arbace_repr_go_convert_init_vec_A_New() *A_arbace_repr_go_convert_init_vec_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_init_vec_A{}; t.Ctor(); return t }
//line :1017:1
func (t *A_arbace_repr_go_convert_init_vec_A) Ctor() {}
//line :1017:1
func (t *A_arbace_repr_go_convert_init_vec_A) Invoke_O_O_O__O(self, init__0, l__1 any) any {


	if lang.Util_Identical_O_O__Z(init__0, nil) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()); var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O_O__O(l__1, tmp2.Ref()) } else {
//line :1020:1
			var tmp3 bool; var tmp4 any = A_arbace_repr_go_convert_A_const_77; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(init__0))

			if and__1927000168__auto____3 { var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; tmp3 = lang.Util_Equiv_O_O__Z(Lit_26, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(init__0))) } else { tmp3 = and__1927000168__auto____3 }
//line :1020:1
			if tmp3 {


				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(init__0); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(init__0), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_415.GetRawRoot__O()).Invoke_O__O(init__0)) } else {
//line :1020:1
					if A_arbace_repr_go_convert_A_const_152 != nil {



						return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(init__0), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_442.GetRawRoot__O()).Invoke_O__O(init__0))) } else {
//line :1020:1
							return nil
						}
				}
		}
}

func A_arbace_repr_go_convert_if_form_A_New() *A_arbace_repr_go_convert_if_form_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_if_form_A{}; t.Ctor(); return t }
//line :1026:1
func (t *A_arbace_repr_go_convert_if_form_A) Ctor() {}
//line :1026:1
func (t *A_arbace_repr_go_convert_if_form_A) Invoke_O_O__O(self, n__0 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1026:1
	var map__1114000348__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var map__1114000348__3 any

	if lang.ISeq_InstanceOf(map__1114000348__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000348__2)) { map__1114000348__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000348__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000348__2)) { map__1114000348__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000348__2) } else { lang.PersistentArrayMap_Init(); map__1114000348__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000348__3 = map__1114000348__2 }
//line :1026:1
	var init__4 any = lang.RT_Get_O_O__O(map__1114000348__3, A_arbace_repr_go_convert_A_const_443); var body__5 any = lang.RT_Get_O_O__O(map__1114000348__3, A_arbace_repr_go_convert_A_const_345); var else__6 any = lang.RT_Get_O_O__O(map__1114000348__3, A_arbace_repr_go_convert_A_const_152); var test__7 any = lang.RT_Get_O_O__O(map__1114000348__3, A_arbace_repr_go_convert_A_const_444); var l__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var chain__9 any; var tmp1 any = A_arbace_repr_go_convert_if_form_fn__1114000353_A_New_O_O_O(test__7, else__6, body__5); var tmp2 *jrt.Class
	var fncls__69 /*line :1026:1*/*jrt.Class = A_arbace_repr_go_convert_if_form_fn__1114000353_A_fn_class



	if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_151, false); A_arbace_repr_go_convert_if_form_fn__1114000353_A_fn_class = fncls__69d; tmp2 = fncls__69d } else { tmp2 = fncls__69 }; chain__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :1026:1
	var vec__1114000350__10 any = chain__9; var tests__11 any = lang.RT_Nth_O_I_O__O(vec__1114000350__10, lang.RT_IntCast_J__I(0), nil); var final__12 any = lang.RT_Nth_O_I_O__O(vec__1114000350__10, lang.RT_IntCast_J__I(1), nil)








	if lang.Util_Identical_O_O__Z(else__6, nil) {


		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp6 any = A_arbace_repr_go_convert_A_const_445; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp8 lang.IPersistentVector
//line :1037:1
		if jrt.J2g_Truth(init__4) { tmp8 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_446.GetRawRoot__O()).Invoke_O_O__O(init__4, l__8)) } else { tmp8 = nil }
		var tmp9 any = tmp8; var tmp10 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(test__7)); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_349.GetRawRoot__O()); var tmp12 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp12 = lang.PersistentArrayMap_EMPTY; return tmp3.Invoke_O_O__O(tmp4.Invoke_O_O_O_O_O__O(tmp5, n__0, l__8, tmp6, tmp7.Invoke_O_O_O__O(tmp9, tmp10, tmp11.Invoke_O_O__O(body__5, tmp12.Ref()))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_354.GetRawRoot__O()).Invoke_O__O(body__5)) } else {
//line :1035:1
			var tmp13 any; var and__1927000168__auto____13 bool = lang.Util_Identical_O_O__Z(init__4, nil)




			if and__1927000168__auto____13 { var and__1927000168__auto____14 bool = lang.Numbers_Gte_J_J__Z(int64(lang.RT_Count_O__I(tests__11)), 2); if and__1927000168__auto____14 { var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp15 any = A_arbace_repr_go_convert_A_const_44; tmp13 = tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(final__12)) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14).Ref() } } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13).Ref() }
//line :1035:1
			if jrt.J2g_Truth(tmp13) {





				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_444)
//line :1035:1
				var seq_1114000355__13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(tests__11)); var chunk_1114000356__14 any; var count_1114000357__15 int64 = 0; var i_1114000358__16 int64 = 0; L1: for {






					if lang.Numbers_Lt_J_J__Z(i_1114000358__16, count_1114000357__15) { var vec__1114000359__17 any = lang.Indexed_Cast(chunk_1114000356__14).Nth_I__O(lang.RT_IntCast_J__I(i_1114000358__16)); var ___18 any = lang.RT_Nth_O_I_O__O(vec__1114000359__17, lang.RT_IntCast_J__I(0), nil); var ___19 any = lang.RT_Nth_O_I_O__O(vec__1114000359__17, lang.RT_IntCast_J__I(1), nil); var e__20 any = lang.RT_Nth_O_I_O__O(vec__1114000359__17, lang.RT_IntCast_J__I(2), nil); _ = ___18; _ = ___19; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(e__20); seq_1114000355__13, chunk_1114000356__14, count_1114000357__15, i_1114000358__16 = seq_1114000355__13, chunk_1114000356__14, count_1114000357__15, lang.Numbers_Unchecked_inc_J__J(i_1114000358__16); continue L1 } else { var temp__1927000414__auto____17 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1114000355__13); if jrt.J2g_Truth(temp__1927000414__auto____17) { var seq_1114000355__18 any = temp__1927000414__auto____17; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(seq_1114000355__18)) { var c__1927000678__auto____19 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(seq_1114000355__18); seq_1114000355__13, chunk_1114000356__14, count_1114000357__15, i_1114000358__16 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_1114000355__18), c__1927000678__auto____19, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1114000362__19 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1114000355__18); var ___20 any = lang.RT_Nth_O_I_O__O(vec__1114000362__19, lang.RT_IntCast_J__I(0), nil); var ___21 any = lang.RT_Nth_O_I_O__O(vec__1114000362__19, lang.RT_IntCast_J__I(1), nil); var e__22 any = lang.RT_Nth_O_I_O__O(vec__1114000362__19, lang.RT_IntCast_J__I(2), nil); _ = ___20; _ = ___21; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(e__22); seq_1114000355__13, chunk_1114000356__14, count_1114000357__15, i_1114000358__16 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq_1114000355__18), nil, 0, 0; continue L1 } } }
//line :1035:1
					break L1
				}











				var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_204.GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp18 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp19 any = A_arbace_repr_go_convert_A_const_448; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_237.GetRawRoot__O()); var tmp22 any = A_arbace_repr_go_convert_if_form_fn__1114000366_A_New(); var tmp23 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_repr_go_convert_if_form_fn__1114000366_A_fn_class
//line :1044:1
				if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_152, false); A_arbace_repr_go_convert_if_form_fn__1114000366_A_fn_class = fncls__70d; tmp23 = fncls__70d } else { tmp23 = fncls__70
				}


				var tmp24 any = tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), tests__11); var tmp25 lang.IPersistentVector
//line :1045:1
				if jrt.J2g_Truth(final__12) { var tmp26 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(Lit_153, A_arbace_repr_go_convert_A_const_152); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_449.GetRawRoot__O()); var tmp28 *jrt.Boolean; jrt.Boolean_Init(); tmp28 = jrt.Boolean_TRUE; tmp25 = lang.Tuple_Create_O_O__IPersistentVector(tmp26, tmp27.Invoke_O_O__O(final__12, tmp28.Ref())) } else { tmp25 = nil
				}

				var tmp29 any = tmp17.Invoke_O_O_O_O_O__O(tmp18, n__0, l__8, tmp19, tmp20.Invoke_O_O__O(tmp24, tmp25)); var tmp30 any = A_arbace_repr_go_convert_A_const_447; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()); var tmp34 any = A_arbace_repr_go_convert_if_form_fn__1114000372_A_New_O(n__0); var tmp35 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_repr_go_convert_if_form_fn__1114000372_A_fn_class
				if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_154, false); A_arbace_repr_go_convert_if_form_fn__1114000372_A_fn_class = fncls__71d; tmp35 = fncls__71d } else { tmp35 = fncls__71 }
//line :1048:1
				var tmp36 any = tmp33.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil), tests__11); var tmp37 lang.IPersistentVector




				if jrt.J2g_Truth(final__12) { var tmp38 *lang.Keyword = A_arbace_repr_go_convert_A_const_61; var tmp39 *lang.Keyword = A_arbace_repr_go_convert_A_const_158; tmp37 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(nil, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp38.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(final__12))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp39.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(final__12))))) } else { tmp37 = nil }
//line :1048:1
				return tmp16.Invoke_O_O__O(tmp29, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp31.Invoke_O__O(tmp32.Invoke_O_O__O(tmp36, tmp37))))) } else {
//line :1035:1
					if A_arbace_repr_go_convert_A_const_152 != nil {

























						var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp42 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp43 any = A_arbace_repr_go_convert_A_const_450; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp45 lang.IPersistentVector
//line :1058:1
						if jrt.J2g_Truth(init__4) { tmp45 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_446.GetRawRoot__O()).Invoke_O_O__O(init__4, l__8)) } else { tmp45 = nil
						}

						var tmp46 any = tmp45; var tmp47 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(test__7); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_449.GetRawRoot__O()); var tmp49 *jrt.Boolean; jrt.Boolean_Init(); tmp49 = jrt.Boolean_FALSE; var tmp50 any = tmp48.Invoke_O_O__O(body__5, tmp49.Ref()); var tmp51 any; var tmp52 any = A_arbace_repr_go_convert_A_const_44
//line :1060:1
						if lang.Util_Equiv_O_O__Z(tmp52, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(else__6)) { tmp51 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_451.GetRawRoot__O()).Invoke_O__O(else__6) } else { var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_449.GetRawRoot__O()); var tmp54 *jrt.Boolean; jrt.Boolean_Init(); tmp54 = jrt.Boolean_TRUE; tmp51 = tmp53.Invoke_O_O__O(else__6, tmp54.Ref()) }
						var tmp55 any = tmp41.Invoke_O_O_O_O_O__O(tmp42, n__0, l__8, tmp43, tmp44.Invoke_O_O__O(tmp46, lang.Tuple_Create_O_O_O__IPersistentVector(tmp47, tmp50, tmp51))); var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_147.GetRawRoot__O()); var tmp57 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_354.GetRawRoot__O()).Invoke_O__O(body__5); var tmp58 lang.IPersistentMap; var tmp59 any = A_arbace_repr_go_convert_A_const_124
						if lang.Util_Equiv_O_O__Z(tmp59, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(else__6)) { var tmp60 any = A_arbace_repr_go_convert_A_const_452; var tmp61 *lang.Keyword = A_arbace_repr_go_convert_A_const_61; var tmp62 any = tmp61.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(else__6)); var tmp63 any = A_arbace_repr_go_convert_A_const_453; var tmp64 *lang.Keyword = A_arbace_repr_go_convert_A_const_158; tmp58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp60, tmp62, tmp63, tmp64.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(else__6)))) } else { tmp58 = nil }
//line :1061:1
						return tmp40.Invoke_O_O__O(tmp55, tmp56.Invoke_O_O__O(tmp57, tmp58)) } else {
//line :1035:1
							return nil } } } }
//line :1030:1
func A_arbace_repr_go_convert_if_form_fn__1114000353_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_if_form_fn__1114000353_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_if_form_fn__1114000353_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1030:1
func (t *A_arbace_repr_go_convert_if_form_fn__1114000353_A) Ctor_O_O_O(c__test, c__else, c__body any) { t.F_test = c__test; t.F_else = c__else; t.F_body = c__body }
//line :1030:1
func (t *A_arbace_repr_go_convert_if_form_fn__1114000353_A) Invoke_O__O(self any) any { { var acc__1 any; var tmp1 any; var t_ any = t.F_test; t.F_test = nil; tmp1 = t_; var tmp2 any = tmp1; var tmp3 any; var t__2 any = t.F_body; t.F_body = nil; tmp3 = t__2; acc__1 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3)); var e__2 any; var t__3 any = t.F_else; t.F_else = nil; e__2 = t__3; L1: for {
											var tmp4 bool; var tmp5 any = A_arbace_repr_go_convert_A_const_44; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(e__2)); if and__1927000168__auto____3 { var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_443; tmp4 = lang.Util_Identical_O_O__Z(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(e__2)), nil) } else { tmp4 = and__1927000168__auto____3 }; if tmp4 {
												var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_444; var tmp8 *lang.Keyword = A_arbace_repr_go_convert_A_const_345; var tmp9 *lang.Keyword = A_arbace_repr_go_convert_A_const_152; acc__1, e__2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_9.GetRawRoot__O()).Invoke_O_O__O(acc__1, lang.Tuple_Create_O_O_O__IPersistentVector(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(e__2)), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(e__2)), e__2)), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(e__2)); continue L1 } else {
//line :1031:1
			return lang.Tuple_Create_O_O__IPersistentVector(acc__1, e__2) } } }; /*line :1030:1*/panic("j2g: unreachable") }













func A_arbace_repr_go_convert_if_form_fn__1114000366_A_New() *A_arbace_repr_go_convert_if_form_fn__1114000366_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_if_form_fn__1114000366_A{}; t.Ctor(); return t }
//line :1044:1
func (t *A_arbace_repr_go_convert_if_form_fn__1114000366_A) Ctor() {}
//line :1044:1
func (t *A_arbace_repr_go_convert_if_form_fn__1114000366_A) Invoke_O_O__O(self, p__1114000365__1 any) any { var vec__1114000367__2 any = p__1114000365__1; var c__3 any = lang.RT_Nth_O_I_O__O(vec__1114000367__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1114000367__2, lang.RT_IntCast_J__I(1), nil); var tmp1 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(c__3); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_449.GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Invoke_O_O__O(b__4, tmp3.Ref())) }




func A_arbace_repr_go_convert_if_form_fn__1114000372_A_New_O(p0 any) *A_arbace_repr_go_convert_if_form_fn__1114000372_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_if_form_fn__1114000372_A{}; t.Ctor_O(p0); return t }
//line :1049:1
func (t *A_arbace_repr_go_convert_if_form_fn__1114000372_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1049:1
func (t *A_arbace_repr_go_convert_if_form_fn__1114000372_A) Invoke_O_O_O__O(self, i__1, p__1114000371__2 any) any { var vec__1114000373__3 any = p__1114000371__2; var ___4 any = lang.RT_Nth_O_I_O__O(vec__1114000373__3, lang.RT_IntCast_J__I(0), nil); var b__5 any = lang.RT_Nth_O_I_O__O(vec__1114000373__3, lang.RT_IntCast_J__I(1), nil); var e__6 any = lang.RT_Nth_O_I_O__O(vec__1114000373__3, lang.RT_IntCast_J__I(2), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()); var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_45; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()); var tmp4 any; _ = ___4; if
															lang.Numbers_IsZero_O__Z(i__1) { tmp4 = t.F_n } else { tmp4 = e__6 }; var tmp5 /*line :1049:1*/*lang.Keyword = A_arbace_repr_go_convert_A_const_61; var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_158; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(b__5))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(b__5)))) }















func A_arbace_repr_go_convert_clause_bound_A_New() *A_arbace_repr_go_convert_clause_bound_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_clause_bound_A{}; t.Ctor(); return t }
//line :1065:1
func (t *A_arbace_repr_go_convert_clause_bound_A) Ctor() {}
//line :1065:1
func (t *A_arbace_repr_go_convert_clause_bound_A) Invoke_O_O_O__O(self, body__0, i__1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; var cl__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(body__0)); if



	lang.Numbers_Lt_O_J__Z(lang.Numbers_Inc_O__Number(i__1), int64(lang.RT_Count_O__I(cl__3))) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(cl__3, lang.RT_IntCast_O__I(lang.Numbers_Inc_O__Number(i__1))))) } else {
			var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_158; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(body__0))) } }

func A_arbace_repr_go_convert_case_clause_A_New() *A_arbace_repr_go_convert_case_clause_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_case_clause_A{}; t.Ctor(); return t }
//line :1073:1
func (t *A_arbace_repr_go_convert_case_clause_A) Ctor() {}
//line :1073:1
func (t *A_arbace_repr_go_convert_case_clause_A) Invoke_O_O_O_O__O(self, c__0, to__1, tswitch__2 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(c__0)
//line :1073:1
	var map__1114000379__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(c__0); var map__1114000379__5 any

	if lang.ISeq_InstanceOf(map__1114000379__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000379__4)) { map__1114000379__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000379__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000379__4)) { map__1114000379__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000379__4) } else { lang.PersistentArrayMap_Init(); map__1114000379__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000379__5 = map__1114000379__4 }
//line :1073:1
	var list__6 any = lang.RT_Get_O_O__O(map__1114000379__5, A_arbace_repr_go_convert_A_const_72); var body__7 any = lang.RT_Get_O_O__O(map__1114000379__5, A_arbace_repr_go_convert_A_const_345); var colon__8 any = lang.RT_Get_O_O__O(map__1114000379__5, A_arbace_repr_go_convert_A_const_166); var l__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(c__0); var body_forms__10 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_437.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(colon__8); var tmp3 *lang.PersistentArrayMap



	lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; body_forms__10 = tmp1.Invoke_O_O_O_O__O(body__7, tmp2, to__1, tmp3.Ref())
	if lang.Util_Identical_O_O__Z(list__6, nil) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), c__0, l__9, A_arbace_repr_go_convert_A_const_454, body_forms__10) } else {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp6 any = A_arbace_repr_go_convert_A_const_455; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(list__6)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_convert_case_clause_fn__1114000381_A_New_O(tswitch__2); var tmp11 *jrt.Class
			var fncls__72 /*line :1080:1*/*jrt.Class = A_arbace_repr_go_convert_case_clause_fn__1114000381_A_fn_class

			if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_repr_go_convert_case_clause_fn__1114000381_A_fn_class = fncls__72d; tmp11 = fncls__72d } else { tmp11 = fncls__72 }
//line :1080:1
			return tmp4.Invoke_O_O_O_O_O_O__O(tmp5, c__0, l__9, tmp6, tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), list__6)), body_forms__10)
		} }
func A_arbace_repr_go_convert_case_clause_fn__1114000381_A_New_O(p0 any) *A_arbace_repr_go_convert_case_clause_fn__1114000381_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_case_clause_fn__1114000381_A{}; t.Ctor_O(p0); return t }
//line :1082:1
func (t *A_arbace_repr_go_convert_case_clause_fn__1114000381_A) Ctor_O(c__tswitch any) { t.F_tswitch = c__tswitch }
//line :1082:1
func (t *A_arbace_repr_go_convert_case_clause_fn__1114000381_A) Invoke_O_O__O(self, e__1 any) any { if jrt.J2g_Truth(t.F_tswitch) {
													var tmp1 any = A_arbace_repr_go_convert_A_const_185; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_186; if lang.Util_Equiv_O_O__Z(tmp1, tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(e__1)))) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(e__1) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(e__1) } } else {
														return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(e__1) } }



func A_arbace_repr_go_convert_clauses_A_New() *A_arbace_repr_go_convert_clauses_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_clauses_A{}; t.Ctor(); return t }
//line :1088:1
func (t *A_arbace_repr_go_convert_clauses_A) Ctor() {}
//line :1088:1
func (t *A_arbace_repr_go_convert_clauses_A) Invoke_O_O_O__O(self, body__0, tswitch__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(body__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_clauses_fn__1114000384_A_New_O_O(body__0, tswitch__1); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_repr_go_convert_clauses_fn__1114000384_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_repr_go_convert_clauses_fn__1114000384_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(body__0))) }
//line :1090:1
func A_arbace_repr_go_convert_clauses_fn__1114000384_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_clauses_fn__1114000384_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_clauses_fn__1114000384_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1090:1
func (t *A_arbace_repr_go_convert_clauses_fn__1114000384_A) Ctor_O_O(c__body, c__tswitch any) { t.F_body = c__body; t.F_tswitch = c__tswitch }
//line :1090:1
func (t *A_arbace_repr_go_convert_clauses_fn__1114000384_A) Invoke_O_O_O__O(self, i__1, c__2 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_456.GetRawRoot__O()).Invoke_O_O_O__O(c__2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(t.F_body, i__1), t.F_tswitch) }

func A_arbace_repr_go_convert_comm_clause_A_New() *A_arbace_repr_go_convert_comm_clause_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_comm_clause_A{}; t.Ctor(); return t }
//line :1092:1
func (t *A_arbace_repr_go_convert_comm_clause_A) Ctor() {}
//line :1092:1
func (t *A_arbace_repr_go_convert_comm_clause_A) Invoke_O_O_O__O(self, c__0, to__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(c__0)
//line :1092:1
	var map__1114000387__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(c__0); var map__1114000387__4 any

	if lang.ISeq_InstanceOf(map__1114000387__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000387__3)) { map__1114000387__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000387__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000387__3)) { map__1114000387__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000387__3) } else { lang.PersistentArrayMap_Init(); map__1114000387__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000387__4 = map__1114000387__3 }
//line :1092:1
	var comm__5 any = lang.RT_Get_O_O__O(map__1114000387__4, A_arbace_repr_go_convert_A_const_458); var body__6 any = lang.RT_Get_O_O__O(map__1114000387__4, A_arbace_repr_go_convert_A_const_345); var colon__7 any = lang.RT_Get_O_O__O(map__1114000387__4, A_arbace_repr_go_convert_A_const_166); var l__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(c__0); var body_forms__9 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_437.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(colon__7); var tmp3 *lang.PersistentArrayMap



	lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; body_forms__9 = tmp1.Invoke_O_O_O_O__O(body__6, tmp2, to__1, tmp3.Ref())
	if lang.Util_Identical_O_O__Z(comm__5, nil) {
		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), c__0, l__8, A_arbace_repr_go_convert_A_const_459, body_forms__9) } else {
//line :1097:1
			var cf__10 any; var G__1114000389__10_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(comm__5)

		L1: switch { default: switch lang.Util_Hash_O__I(G__1114000389__10_) >> 2 & 3 { case 0: if any(G__1114000389__10_) == any(A_arbace_repr_go_convert_A_const_39) {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_436.GetRawRoot__O()); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; cf__10 = tmp4.Invoke_O_O__O(comm__5, tmp5.Ref())
//line :1099:1
			break L1 }; case 2: if any(G__1114000389__10_) == any(A_arbace_repr_go_convert_A_const_75) {

				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(comm__5); var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; cf__10 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(comm__5)))
//line :1099:1
				break L1 }; case 3: if any(G__1114000389__10_) == any(A_arbace_repr_go_convert_A_const_77) {


					var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; if lang.Util_Equiv_O_O__Z(Lit_26, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(comm__5))) {
						lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(comm__5); cf__10 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(comm__5), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_415.GetRawRoot__O()).Invoke_O__O(comm__5)) } else {
							var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_436.GetRawRoot__O()); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; cf__10 = tmp8.Invoke_O_O__O(comm__5, tmp9.Ref()) }
//line :1099:1
					break L1 }; default:
		}




			cf__10 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_27, comm__5)}
			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(), c__0, l__8, A_arbace_repr_go_convert_A_const_460, cf__10, body_forms__9)
		} }
func A_arbace_repr_go_convert_assign_A_New() *A_arbace_repr_go_convert_assign_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_assign_A{}; t.Ctor(); return t }
//line :1108:1
func (t *A_arbace_repr_go_convert_assign_A) Ctor() {}
//line :1108:1
func (t *A_arbace_repr_go_convert_assign_A) Invoke_O_O__O(self, n__0 any) any { var map__1114000391__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var map__1114000391__3 any; if
										lang.ISeq_InstanceOf(map__1114000391__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000391__2)) { map__1114000391__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000391__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000391__2)) { map__1114000391__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000391__2) } else { lang.PersistentArrayMap_Init(); map__1114000391__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000391__3 = map__1114000391__2 }; var lhs__4 any = /*line :1108:1*/lang.RT_Get_O_O__O(map__1114000391__3, A_arbace_repr_go_convert_A_const_79); var rhs__5 any = lang.RT_Get_O_O__O(map__1114000391__3, A_arbace_repr_go_convert_A_const_385); var tok__6 any = lang.RT_Get_O_O__O(map__1114000391__3, A_arbace_repr_go_convert_A_const_392); var l__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0);


	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); if
	lang.Util_Equiv_O_O__Z(tok__6, Lit_3) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_461.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_334; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lhs__4)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(rhs__5)).Ref())) { var p__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lhs__4)); var tmp3 any; var tmp4 any = A_arbace_repr_go_convert_A_const_73; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(p__8))

			if and__1927000168__auto____9 { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_convert_A_const_60; var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_186; var tmp8 *lang.Keyword = A_arbace_repr_go_convert_A_const_273; tmp3 = tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(p__8)))))) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp3) {
				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(p__8)

				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_convert_A_const_464; var tmp11 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; var tmp12 *lang.Keyword = A_arbace_repr_go_convert_A_const_273; var tmp13 any = A_arbace_repr_go_convert_A_const_42; var tmp14 *lang.Keyword = A_arbace_repr_go_convert_A_const_42; var tmp15 any = tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(p__8)); var tmp16 any = A_arbace_repr_go_convert_A_const_463; var tmp17 *lang.Keyword = A_arbace_repr_go_convert_A_const_463; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(tmp9.Invoke_O_O_O_O_O_O__O(n__0, l__7, tmp10, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(p__8))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(p__8))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rhs__5))), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, tmp17.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(p__8))))) } else {
					var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp19 any = A_arbace_repr_go_convert_A_const_465; return tmp18.Invoke_O_O_O_O_O__O(n__0, l__7, tmp19, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lhs__4)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rhs__5))) } } else {
						var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp21 any = A_arbace_repr_go_convert_A_const_466; return tmp20.Invoke_O_O_O_O_O__O(n__0, l__7, tmp21, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_386.GetRawRoot__O()).Invoke_O_O_O__O(lhs__4, l__7, A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_388.GetRawRoot__O()).Invoke_O_O__O(rhs__5, l__7)) } } else {
//line :1112:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_462.GetRawRoot__O()).Invoke_O__O(tok__6)) {










								var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp23 any = A_arbace_repr_go_convert_A_const_467; return tmp22.Invoke_O_O_O_O_O_O__O(n__0, l__7, tmp23, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lhs__4)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_462.GetRawRoot__O()).Invoke_O__O(tok__6), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rhs__5))) } else {
//line :1112:1
									if A_arbace_repr_go_convert_A_const_152 != nil {











										return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, tok__6)).Ref(), n__0) } else {
//line :1112:1
											return nil } } } }













func A_arbace_repr_go_convert_simple_stmt_A_New() *A_arbace_repr_go_convert_simple_stmt_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_simple_stmt_A{}; t.Ctor(); return t }
//line :1126:1
func (t *A_arbace_repr_go_convert_simple_stmt_A) Ctor() {}
//line :1126:1
func (t *A_arbace_repr_go_convert_simple_stmt_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_436.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O__O(s__0, tmp2.Ref())
}


func A_arbace_repr_go_convert_stmt_A_New() *A_arbace_repr_go_convert_stmt_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmt_A{}; t.Ctor(); return t }
//line :1133:1
func (t *A_arbace_repr_go_convert_stmt_A) Ctor() {}
//line :1133:1
func (t *A_arbace_repr_go_convert_stmt_A) Invoke_O_O_O__O(self, n__0, tail__1 any) any { var x__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_468.GetRawRoot__O()).Invoke_O_O__O(n__0, tail__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_469); if




	jrt.J2g_Truth(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0))) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_345; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(x__3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_354.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0)))) } else {
//line :1138:1
			return x__3 } }



func A_arbace_repr_go_convert_stmt_STAR__A_New() *A_arbace_repr_go_convert_stmt_STAR__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmt_STAR__A{}; t.Ctor(); return t }
//line :1142:1
func (t *A_arbace_repr_go_convert_stmt_STAR__A) Ctor() {}
//line :1142:1
func (t *A_arbace_repr_go_convert_stmt_STAR__A) Invoke_O_O_O__O(self, n__0, tail__1 any) any { var f__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(n__0); var l__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var G__1114000396__5_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0); switch



	lang.Util_Hash_O__I(G__1114000396__5_) >> 11 & 63 { case 1: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_44) {




















		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_451.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :1146:1
	case 3: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_57) {






		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1146:1
		var rs__6 any = A_arbace_repr_go_convert_A_const_294.Invoke_O__O(f__3); var tmp1 any
		var and__1927000168__auto____7 any = tail__1







		if jrt.J2g_Truth(and__1927000168__auto____7) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(rs__6)))).Ref() } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) {
			lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_471)
			if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_351.Get__O()) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_470.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_351.Get__O(), A_arbace_repr_go_convert_A_const_58.Invoke_O__O(f__3)) }
			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(rs__6)) } else {
				var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_convert_A_const_472; return tmp2.Invoke_O_O_O_O_O__O(tmp3, n__0, l__4, tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O(), rs__6)) } }
//line :1146:1
	case 6: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_95) {







































































		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1146:1
		var s__6 any = A_arbace_repr_go_convert_A_const_412.Invoke_O__O(f__3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp6 any
		var tmp7 any = A_arbace_repr_go_convert_A_const_87








































































		if lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(s__6)) {
			lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(s__6); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_A_const_473; tmp6 = tmp8.Invoke_O_O_O_O__O(n__0, l__4, tmp9, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_431.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_97.Invoke_O__O(f__3))) } else {
				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_convert_A_const_474; var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_431.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_97.Invoke_O__O(f__3)); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_436.GetRawRoot__O()); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_FALSE; tmp6 = tmp10.Invoke_O_O_O_O_O__O(n__0, l__4, tmp11, tmp12, tmp13.Invoke_O_O__O(s__6, tmp14.Ref())) }
		var tmp15 any = A_arbace_repr_go_convert_A_const_97; return tmp5.Invoke_O_O__O(tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_97.Invoke_O__O(f__3))))) }
//line :1146:1
	case 17: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_117) {











































		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_345.Invoke_O__O(f__3))
		var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp17 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp18 any = A_arbace_repr_go_convert_A_const_476; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()); var tmp20 any = A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A_New_O(f__3); var tmp21 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A_fn_class
		if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_220, false); A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A_fn_class = fncls__76d; tmp21 = fncls__76d } else { tmp21 = fncls__76 }
//line :1191:1
		var tmp22 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; return tmp16.Invoke_O_O_O_O_O__O(tmp17, n__0, l__4, tmp18, tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), tmp22.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_345.Invoke_O__O(f__3))))) }
//line :1146:1
	case 20: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_93) {
















































		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1146:1
		var map__1114000399__6 any = f__3; var map__1114000399__7 any

















































		if lang.ISeq_InstanceOf(map__1114000399__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000399__6)) { map__1114000399__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000399__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000399__6)) { map__1114000399__7 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000399__6) } else { lang.PersistentArrayMap_Init(); map__1114000399__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000399__7 = map__1114000399__6 }
//line :1146:1
		var init__8 any = lang.RT_Get_O_O__O(map__1114000399__7, A_arbace_repr_go_convert_A_const_443); var post__9 any = lang.RT_Get_O_O__O(map__1114000399__7, A_arbace_repr_go_convert_A_const_475); var body__10 any = lang.RT_Get_O_O__O(map__1114000399__7, A_arbace_repr_go_convert_A_const_345); var test__11 any = lang.RT_Get_O_O__O(map__1114000399__7, A_arbace_repr_go_convert_A_const_444); var body_forms__12 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_349.GetRawRoot__O()); var tmp24 *lang.PersistentArrayMap


















































		lang.PersistentArrayMap_Init(); tmp24 = lang.PersistentArrayMap_EMPTY; body_forms__12 = tmp23.Invoke_O_O__O(body__10, tmp24.Ref())
		var tmp25 bool; var and__1927000168__auto____13 bool = lang.Util_Identical_O_O__Z(init__8, nil)
		if and__1927000168__auto____13 { var and__1927000168__auto____14 bool = lang.Util_Identical_O_O__Z(post__9, nil); if and__1927000168__auto____14 { tmp25 = lang.Util_Identical_O_O__Z(test__11, nil) } else { tmp25 = and__1927000168__auto____14 } } else { tmp25 = and__1927000168__auto____13 }
//line :1198:1
		if tmp25 {

			var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp27 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp28 any = A_arbace_repr_go_convert_A_const_479; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()); var tmp30 *jrt.Boolean; jrt.Boolean_Init(); tmp30 = jrt.Boolean_TRUE; return tmp26.Invoke_O_O_O_O_O_O__O(tmp27, n__0, l__4, tmp28, tmp29.Invoke_O_O__O(Lit_221, tmp30.Ref()), body_forms__12) } else {
//line :1198:1
				var tmp31 any; var and__1927000168__auto____13_2 bool = lang.Util_Identical_O_O__Z(init__8, nil)


				if and__1927000168__auto____13_2 { var and__1927000168__auto____14_2 bool = lang.Util_Identical_O_O__Z(post__9, nil); if and__1927000168__auto____14_2 {
					var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()); var tmp33 any; var c__15 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(test__11); var tmp34 any = A_arbace_repr_go_convert_A_const_55; var and__1927000168__auto____16 bool = lang.Util_Equiv_O_O__Z(tmp34, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(c__15))
					if and__1927000168__auto____16 { var and__1927000168__auto____17 bool = lang.Util_Equiv_O_O__Z(Lit_221, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(c__15)); if and__1927000168__auto____17 { var tmp35 *lang.Keyword = A_arbace_repr_go_convert_A_const_184; tmp33 = tmp35.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_177.GetRawRoot__O()).Invoke_O__O(c__15)) } else { tmp33 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____17).Ref() } } else { tmp33 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____16).Ref() }
//line :1202:1
					tmp31 = tmp32.Invoke_O__O(tmp33) } else {
//line :1201:1
						tmp31 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14_2).Ref() } } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13_2).Ref() }
//line :1198:1
				if jrt.J2g_Truth(tmp31) {





					var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp37 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp38 any = A_arbace_repr_go_convert_A_const_480; return tmp36.Invoke_O_O_O_O_O_O__O(tmp37, n__0, l__4, tmp38, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(test__11), body_forms__12) } else {
//line :1198:1
						if A_arbace_repr_go_convert_A_const_152 != nil {







							var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp40 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp41 any = A_arbace_repr_go_convert_A_const_481; var tmp42 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_446.GetRawRoot__O()).Invoke_O_O__O(init__8, l__4); var tmp43 any
							if jrt.J2g_Truth(test__11) { tmp43 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(test__11) } else { tmp43 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(Lit_28), nil, l__4) }
//line :1206:1
							var tmp44 any = tmp43; var tmp45 any

							if jrt.J2g_Truth(post__9) { tmp45 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_442.GetRawRoot__O()).Invoke_O__O(post__9) } else { tmp45 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_182.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(Lit_28), nil, l__4) }
//line :1206:1
							return tmp39.Invoke_O_O_O_O_O_O_O_O__O(tmp40, n__0, l__4, tmp41, tmp42, tmp44, tmp45, body_forms__12) } else {
//line :1198:1
								return nil } } } }
//line :1146:1
	case 21: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_119) {













		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1146:1
		var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_478); var head__6 any = tmp46.Invoke_O__O(A_arbace_repr_go_convert_A_const_392.Invoke_O__O(f__3))
















		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_97.Invoke_O__O(f__3)) {
			var tmp47 any = A_arbace_repr_go_convert_A_const_97; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()).Invoke_O_O_O_O__O(n__0, l__4, head__6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_431.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_97.Invoke_O__O(f__3))), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp47, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_97.Invoke_O__O(f__3))))) } else {
				return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()).Invoke_O_O_O__O(n__0, l__4, head__6) } }
//line :1146:1
	case 32: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_77) {



		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_482.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :1146:1
	case 34: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_107) {





		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp49 any = A_arbace_repr_go_convert_A_const_483; return tmp48.Invoke_O_O_O_O__O(n__0, l__4, tmp49, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_484.Invoke_O__O(f__3))) }
//line :1146:1
	case 35: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_92) {


		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp51 any; if lang.Util_Equiv_O_O__Z(Lit_222, A_arbace_repr_go_convert_A_const_392.Invoke_O__O(f__3)) { tmp51 = A_arbace_repr_go_convert_A_const_485 } else { tmp51 = A_arbace_repr_go_convert_A_const_486 }; return tmp50.Invoke_O_O_O_O__O(n__0, l__4, tmp51, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3))) }
//line :1146:1
	case 36: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_111) {



























		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1146:1
		var as__6 any = A_arbace_repr_go_convert_A_const_384.Invoke_O__O(f__3); var ta__7 any; var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()); var tmp53 any; var G__1114000401__7_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(as__6)





























	L2: switch { default: switch lang.Util_Hash_O__I(G__1114000401__7_) >> 0 & 1 { case 0: if any(G__1114000401__7_) == any(A_arbace_repr_go_convert_A_const_75) { var tmp54 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; tmp53 = tmp54.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(as__6)); break L2 }; case 1: if any(G__1114000401__7_) == any(A_arbace_repr_go_convert_A_const_77) { var tmp55 *lang.Keyword = A_arbace_repr_go_convert_A_const_385; tmp53 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp55.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(as__6))); break L2 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1114000401__7_)))))}; ta__7 = tmp52.Invoke_O__O(tmp53)
//line :1146:1
		var guard__8 any; var G__1114000402__8_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(as__6)






























	L3: switch { default: switch lang.Util_Hash_O__I(G__1114000402__8_) >> 0 & 1 { case 0: if any(G__1114000402__8_) == any(A_arbace_repr_go_convert_A_const_75) {



		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(as__6); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(ta__7)
		var tmp56 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; guard__8 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(tmp56.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(ta__7)))
//line :1177:1
		break L3 }; case 1: if any(G__1114000402__8_) == any(A_arbace_repr_go_convert_A_const_77) { var map__1114000403__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(as__6); var map__1114000403__10 any
			if lang.ISeq_InstanceOf(map__1114000403__9) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000403__9)) { map__1114000403__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000403__9), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000403__9)) { map__1114000403__10 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000403__9) } else { lang.PersistentArrayMap_Init(); map__1114000403__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000403__10 = map__1114000403__9 }
//line :1177:1
			var lhs__11 any = lang.RT_Get_O_O__O(map__1114000403__10, A_arbace_repr_go_convert_A_const_79); var rhs__12 any = lang.RT_Get_O_O__O(map__1114000403__10, A_arbace_repr_go_convert_A_const_385); _ = rhs__12

			lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(as__6); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(ta__7)
			var tmp57 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; guard__8 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(as__6), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lhs__11)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(tmp57.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(ta__7)))))
//line :1177:1
			break L3 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1114000402__8_)))))
	}








		var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp60 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp61 any = A_arbace_repr_go_convert_A_const_491; var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp63 lang.IPersistentVector
//line :1184:1
		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_443.Invoke_O__O(f__3)) { tmp63 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_446.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_443.Invoke_O__O(f__3), l__4)) } else { tmp63 = nil
		}

		var tmp64 any = tmp63; var tmp65 any = lang.Tuple_Create_O__IPersistentVector(guard__8); var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_492.GetRawRoot__O()); var tmp67 any = A_arbace_repr_go_convert_A_const_345.Invoke_O__O(f__3); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; var tmp69 any = tmp59.Invoke_O_O_O_O_O__O(tmp60, n__0, l__4, tmp61, tmp62.Invoke_O_O_O__O(tmp64, tmp65, tmp66.Invoke_O_O__O(tmp67, tmp68.Ref()))); var tmp70 any = A_arbace_repr_go_convert_A_const_487; var tmp71 any; var tmp72 any = A_arbace_repr_go_convert_A_const_77; if lang.Util_Equiv_O_O__Z(tmp72, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(as__6)) { var tmp73 *lang.Keyword = A_arbace_repr_go_convert_A_const_91; tmp71 = tmp73.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(as__6)) } else { tmp71 = nil }; var tmp74 any = tmp71; var tmp75 any = A_arbace_repr_go_convert_A_const_488; var tmp76 *lang.Keyword = A_arbace_repr_go_convert_A_const_337; var tmp77 any = tmp76.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(ta__7)); var tmp78 any = A_arbace_repr_go_convert_A_const_489; var tmp79 *lang.Keyword = A_arbace_repr_go_convert_A_const_115; var tmp80 any = tmp79.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(ta__7)); var tmp81 any = A_arbace_repr_go_convert_A_const_490; var tmp82 *lang.Keyword = A_arbace_repr_go_convert_A_const_153; return tmp58.Invoke_O_O__O(tmp69, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp74, tmp75, tmp77, tmp78, tmp80, tmp81, tmp82.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(ta__7))))) }
//line :1146:1
	case 44: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_87) {













































































		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1146:1
		return nil }; case 45: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_114) {
































































			lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1146:1
			var map__1114000405__6 any = f__3; var map__1114000405__7 any

































































			if lang.ISeq_InstanceOf(map__1114000405__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000405__6)) { map__1114000405__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000405__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000405__6)) { map__1114000405__7 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000405__6) } else { lang.PersistentArrayMap_Init(); map__1114000405__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000405__7 = map__1114000405__6 }
//line :1146:1
			var key__8 any = lang.RT_Get_O_O__O(map__1114000405__7, A_arbace_repr_go_convert_A_const_86); var value__9 any = lang.RT_Get_O_O__O(map__1114000405__7, A_arbace_repr_go_convert_A_const_206); var tok__10 any = lang.RT_Get_O_O__O(map__1114000405__7, A_arbace_repr_go_convert_A_const_392); var x__11 any = lang.RT_Get_O_O__O(map__1114000405__7, A_arbace_repr_go_convert_A_const_34); var body__12 any = lang.RT_Get_O_O__O(map__1114000405__7, A_arbace_repr_go_convert_A_const_345); var define__13 bool = lang.Util_Equiv_O_O__Z(tok__10, Lit_26); var tgt__14 any; var tmp83 any = A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A_New_Z(define__13); var tmp84 *jrt.Class
			var fncls__79 /*line :1146:1*/*jrt.Class = A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A_fn_class



































































			if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_223, false); A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A_fn_class = fncls__79d; tmp84 = fncls__79d } else { tmp84 = fncls__79 }; tgt__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp83, tmp84, nil)
//line :1146:1
			var v__15 any; var tmp85 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()); var tmp86 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp87 lang.IPersistentVector




































































			if jrt.J2g_Truth(key__8) { tmp87 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(tgt__14).Invoke_O__O(key__8)) } else { tmp87 = nil }; var tmp88 any = tmp87; var tmp89 lang.IPersistentVector; if jrt.J2g_Truth(value__9) { tmp89 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(tgt__14).Invoke_O__O(value__9)) } else { tmp89 = nil }; v__15 = tmp85.Invoke_O_O__O(l__4, tmp86.Invoke_O_O_O__O(tmp88, tmp89, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(x__11))))
//line :1146:1
			var fm__16 any; var tmp90 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp91 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp92 any = A_arbace_repr_go_convert_A_const_493; var tmp93 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_349.GetRawRoot__O()); var tmp94 *lang.PersistentArrayMap





































































			lang.PersistentArrayMap_Init(); tmp94 = lang.PersistentArrayMap_EMPTY; fm__16 = tmp90.Invoke_O_O_O_O_O_O__O(tmp91, n__0, l__4, tmp92, v__15, tmp93.Invoke_O_O__O(body__12, tmp94.Ref()))
			if lang.Util_Equiv_O_O__Z(tok__10, Lit_3) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(fm__16, A_arbace_repr_go_convert_A_const_494) } else { return fm__16 } }
//line :1146:1
	case 48: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_105) {





















		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0)
		var tmp95 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp96 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp97 any = A_arbace_repr_go_convert_A_const_495; var tmp98 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp99 lang.IPersistentVector
		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_443.Invoke_O__O(f__3)) { tmp99 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_446.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_443.Invoke_O__O(f__3), l__4)) } else { tmp99 = nil }
//line :1169:1
		var tmp100 any = tmp99; var tmp101 lang.IPersistentVector

		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_226.Invoke_O__O(f__3)) { tmp101 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_226.Invoke_O__O(f__3))) } else { tmp101 = nil }
//line :1169:1
		var tmp102 any = tmp101; var tmp103 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_492.GetRawRoot__O()); var tmp104 any = A_arbace_repr_go_convert_A_const_345.Invoke_O__O(f__3); var tmp105 *jrt.Boolean; jrt.Boolean_Init(); tmp105 = jrt.Boolean_FALSE; return tmp95.Invoke_O_O_O_O_O__O(tmp96, n__0, l__4, tmp97, tmp98.Invoke_O_O_O__O(tmp100, tmp102, tmp103.Invoke_O_O__O(tmp104, tmp105.Ref()))) }
//line :1146:1
	case 50: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_75) {
		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_34.Invoke_O__O(f__3)) }
//line :1146:1
	case 52: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_39) {

		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); var tmp106 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp107 any = A_arbace_repr_go_convert_A_const_496; return tmp106.Invoke_O_O_O_O_O__O(n__0, l__4, tmp107, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_47.Invoke_O__O(f__3)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_206.Invoke_O__O(f__3))) }
//line :1146:1
	case 53: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_120) {




		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(n__0); var tmp108 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_189.GetRawRoot__O()); var tmp109 any = A_arbace_repr_go_convert_A_const_497; return tmp108.Invoke_O_O_O_O__O(n__0, l__4, tmp109, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_484.Invoke_O__O(f__3))) }
//line :1146:1
	case 58: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_74) {














































































		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_224, n__0) }
//line :1146:1
	case 62: if any(G__1114000396__5_) == any(A_arbace_repr_go_convert_A_const_124) {



















		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_498.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :1146:1
	default:}; return /*line :1226:1*/ lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_225, n__0) }
//line :1192:1
func A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A_New_O(p0 any) *A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A{}; t.Ctor_O(p0); return t }
//line :1192:1
func (t *A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1192:1
func (t *A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A) Invoke_O_O_O__O(self, i__1, c__2 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_477.GetRawRoot__O()).Invoke_O_O__O(c__2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_345.Invoke_O__O(t.F_f), i__1)) }





















func A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A_New_Z(p0 bool) *A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A{}; t.Ctor_Z(p0); return t }
//line :1214:1
func (t *A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A) Ctor_Z(c__define bool) { t.F_define = c__define }
//line :1214:1
func (t *A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A) Invoke_O_O__O(self, e__1 any) any { if t.F_define { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(e__1)) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_285.GetRawRoot__O()).Invoke_O__O(e__1) } }















func A_arbace_repr_go_convert_fn_sig_forms_A_New() *A_arbace_repr_go_convert_fn_sig_forms_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_fn_sig_forms_A{}; t.Ctor(); return t }
//line :1230:1
func (t *A_arbace_repr_go_convert_fn_sig_forms_A) Ctor() {}
//line :1230:1
func (t *A_arbace_repr_go_convert_fn_sig_forms_A) Invoke_O_O__O(self, ft__0 any) any {


	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_256.GetRawRoot__O()).Invoke_O__O(ft__0)
}


func A_arbace_repr_go_convert_directive_name_A_New() *A_arbace_repr_go_convert_directive_name_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_directive_name_A{}; t.Ctor(); return t }
//line :1237:1
func (t *A_arbace_repr_go_convert_directive_name_A) Ctor() {}
//line :1237:1
func (t *A_arbace_repr_go_convert_directive_name_A) Invoke_O_O__O(self, text__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(text__0, Lit_112)) { var body__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()).Invoke_O_O__O(text__0, A_arbace_repr_go_convert_A_const_501); var i__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_500.GetRawRoot__O()).Invoke_O_O__O(body__2, Lit_108)


		if jrt.J2g_Truth(i__3) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(body__2, A_arbace_repr_go_convert_A_const_18, i__3) } else { return body__2 } } else {
//line :1240:1
			return nil
		}
}


func A_arbace_repr_go_convert_directive_args_A_New() *A_arbace_repr_go_convert_directive_args_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_directive_args_A{}; t.Ctor(); return t }
//line :1245:1
func (t *A_arbace_repr_go_convert_directive_args_A) Ctor() {}
//line :1245:1
func (t *A_arbace_repr_go_convert_directive_args_A) Invoke_O_O__O(self, text__0 any) any { var body__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()).Invoke_O_O__O(text__0, A_arbace_repr_go_convert_A_const_501); var i__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_500.GetRawRoot__O()).Invoke_O_O__O(body__2, Lit_108); if


	jrt.J2g_Truth(i__3) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_502.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()).Invoke_O_O__O(body__2, lang.Numbers_Inc_O__Number(i__3))) } else { return nil } }





func A_arbace_repr_go_convert_attachable_QMARK__A_New() *A_arbace_repr_go_convert_attachable_QMARK__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_attachable_QMARK__A{}; t.Ctor(); return t }
//line :1254:1
func (t *A_arbace_repr_go_convert_attachable_QMARK__A) Ctor() {}
//line :1254:1
func (t *A_arbace_repr_go_convert_attachable_QMARK__A) Invoke_O_O_O__O(self, text__0, decl_name__1 any) any { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_503.GetRawRoot__O()).Invoke_O__O(text__0); if




	jrt.J2g_Truth(temp__1927000414__auto____3) { var nm__4 any = temp__1927000414__auto____3; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_504.GetRawRoot__O()).Invoke_O__O(nm__4))
		if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(nm__4, Lit_7)); if jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(nm__4, Lit_8)

			if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else {
				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_505.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_506.GetRawRoot__O()).Invoke_O__O(text__0); if jrt.J2g_Truth(or__1927000174__auto____8) { tmp3 = or__1927000174__auto____8 } else { tmp3 = Lit_9 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(decl_name__1, tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, A_arbace_repr_go_convert_A_const_507)))).Ref() } } else {
//line :1260:1
					return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :1259:1
						return nil } }





func A_arbace_repr_go_convert_directive_meta_A_New() *A_arbace_repr_go_convert_directive_meta_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_directive_meta_A{}; t.Ctor(); return t }
//line :1265:1
func (t *A_arbace_repr_go_convert_directive_meta_A) Ctor() {}
//line :1265:1
func (t *A_arbace_repr_go_convert_directive_meta_A) Invoke_O_O__O(self, texts__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_421.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_directive_meta_fn__1114000415_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_repr_go_convert_directive_meta_fn__1114000415_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_repr_go_convert_directive_meta_fn__1114000415_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_127.GetRawRoot__O()).Invoke__O(), texts__0) }
//line :1268:1
func A_arbace_repr_go_convert_directive_meta_fn__1114000415_A_New() *A_arbace_repr_go_convert_directive_meta_fn__1114000415_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_directive_meta_fn__1114000415_A{}; t.Ctor(); return t }
//line :1268:1
func (t *A_arbace_repr_go_convert_directive_meta_fn__1114000415_A) Ctor() {}
//line :1268:1
func (t *A_arbace_repr_go_convert_directive_meta_fn__1114000415_A) Invoke_O_O_O__O(self, m__1, t__2 any) any { var k__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_201.GetRawRoot__O()).Invoke_O_O__O(Lit_110, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_503.GetRawRoot__O()).Invoke_O__O(t__2)); var v__4 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_506.GetRawRoot__O()).Invoke_O__O(t__2); if

	jrt.J2g_Truth(or__1927000174__auto____4) { v__4 = or__1927000174__auto____4 } else { jrt.Boolean_Init(); v__4 = jrt.Boolean_TRUE.Ref() }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(m__1, k__3)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A_New_O(v__4); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; return tmp1.Invoke_O_O_O__O(m__1, k__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else {
			return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()).Invoke_O_O_O__O(m__1, k__3, v__4) } }
//line :1272:1
func A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A_New_O(p0 any) *A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A{}; t.Ctor_O(p0); return t }
//line :1272:1
func (t *A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :1272:1
func (t *A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A) Invoke_O_O__O(self, p1__1114000414_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_132.GetRawRoot__O()).Invoke_O__O(p1__1114000414_SHARP___1)) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_9.GetRawRoot__O()).Invoke_O_O__O(p1__1114000414_SHARP___1, t.F_v) } else { return lang.Tuple_Create_O_O__IPersistentVector(p1__1114000414_SHARP___1, t.F_v) } }



func A_arbace_repr_go_convert_free_directive_A_New() *A_arbace_repr_go_convert_free_directive_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_free_directive_A{}; t.Ctor(); return t }
//line :1276:1
func (t *A_arbace_repr_go_convert_free_directive_A) Ctor() {}
//line :1276:1
func (t *A_arbace_repr_go_convert_free_directive_A) Invoke_O_O__O(self, p__1114000420__0 any) any { var vec__1114000421__2 any = p__1114000420__0; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000421__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__1114000421__2, lang.RT_IntCast_J__I(1), nil); var text__5 any = lang.RT_Nth_O_I_O__O(vec__1114000421__2, lang.RT_IntCast_J__I(2), nil); _ = ___4;
													lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_508); var tmp1 lang.IFn =
													lang.IFn_Cast(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_509; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(text__5), text__5)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_140, l__3))) }



func A_arbace_repr_go_convert_generic_decl_QMARK__A_New() *A_arbace_repr_go_convert_generic_decl_QMARK__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_generic_decl_QMARK__A{}; t.Ctor(); return t }
//line :1282:1
func (t *A_arbace_repr_go_convert_generic_decl_QMARK__A) Ctor() {}
//line :1282:1
func (t *A_arbace_repr_go_convert_generic_decl_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var G__1114000425__2_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__0); switch


	lang.Util_Hash_O__I(G__1114000425__2_) >> 2 & 1 { case 0: if any(G__1114000425__2_) == any(A_arbace_repr_go_convert_A_const_89) {






		var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_405; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__0))))) }
//line :1285:1
	case 1: if any(G__1114000425__2_) == any(A_arbace_repr_go_convert_A_const_123) { var map__1114000426__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__0); var map__1114000426__4 any
		if lang.ISeq_InstanceOf(map__1114000426__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000426__3)) { map__1114000426__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000426__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000426__3)) { map__1114000426__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000426__3) } else { lang.PersistentArrayMap_Init(); map__1114000426__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000426__4 = map__1114000426__3 }
//line :1285:1
		var recv__5 any = lang.RT_Get_O_O__O(map__1114000426__4, A_arbace_repr_go_convert_A_const_258); var type__6 any = lang.RT_Get_O_O__O(map__1114000426__4, A_arbace_repr_go_convert_A_const_60); var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_405; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(type__6)))))

		if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else {
			if jrt.J2g_Truth(recv__5) { var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_60; var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; var t__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(recv__5)))))); var t__9 any
				var tmp7 any = A_arbace_repr_go_convert_A_const_98
				if lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(t__8)) { var tmp8 *lang.Keyword = A_arbace_repr_go_convert_A_const_34; t__9 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(t__8))) } else { t__9 = t__8 }
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_510); return tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(t__9)) } else {
//line :1288:1
					return nil } } }
//line :1285:1
	default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }









func A_arbace_repr_go_convert_func_decl_A_New() *A_arbace_repr_go_convert_func_decl_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_func_decl_A{}; t.Ctor(); return t }
//line :1295:1
func (t *A_arbace_repr_go_convert_func_decl_A) Ctor() {}
//line :1295:1
func (t *A_arbace_repr_go_convert_func_decl_A) Invoke_O_O_O__O(self, d__0, dmeta__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(d__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_227; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_407.GetRawRoot__O()).Invoke_O__O(d__0))).Ref()))
//line :1295:1
	var tmp3 any; tmp48 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var map__1114000429__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__0); var map__1114000429__6 any


		if lang.ISeq_InstanceOf(map__1114000429__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000429__5)) { map__1114000429__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000429__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000429__5)) { map__1114000429__6 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000429__5) } else { lang.PersistentArrayMap_Init(); map__1114000429__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000429__6 = map__1114000429__5 }
//line :1295:1
		var doc__7 any = lang.RT_Get_O_O__O(map__1114000429__6, A_arbace_repr_go_convert_A_const_238); var recv__8 any = lang.RT_Get_O_O__O(map__1114000429__6, A_arbace_repr_go_convert_A_const_258); var name__9 any = lang.RT_Get_O_O__O(map__1114000429__6, A_arbace_repr_go_convert_A_const_49); var type__10 any = lang.RT_Get_O_O__O(map__1114000429__6, A_arbace_repr_go_convert_A_const_60); var body__11 any = lang.RT_Get_O_O__O(map__1114000429__6, A_arbace_repr_go_convert_A_const_345); var l__12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(d__0); var docstr__13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_240.GetRawRoot__O()).Invoke_O_O__O(doc__7, A_arbace_repr_go_convert_A_const_248.Get__O()); var nm__14 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(name__9), dmeta__1); var tmp6 any





		if jrt.J2g_Truth(body__11) { tmp6 = nil } else { tmp6 = A_arbace_repr_go_convert_A_const_511 }; nm__14 = tmp4.Invoke_O_O__O(tmp5, tmp6)
//line :1295:1
		var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_405; var tps__15 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_406.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(type__10))); var vec__1114000431__16 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_256.GetRawRoot__O()).Invoke_O__O(type__10); var seq__1114000432__17 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(vec__1114000431__16); var first__1114000433__18 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1114000432__17); var seq__1114000432__19 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq__1114000432__17); var ps__20 any = first__1114000433__18; var rs__21 any = seq__1114000432__19; var ps__22 any








		if jrt.J2g_Truth(recv__8) {


			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_277.GetRawRoot__O()); var tmp13 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp13 = lang.PersistentArrayMap_EMPTY; var tmp14 any = tmp10.Invoke_O__O(tmp11.Invoke_O_O__O(tmp12.Invoke_O_O__O(recv__8, tmp13.Ref()), ps__20)); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp16 any = lang.RT_Meta_O__IPersistentMap(ps__20); var tmp17 any = A_arbace_repr_go_convert_A_const_140; var tmp18 any; var tmp19 *lang.Keyword = A_arbace_repr_go_convert_A_const_71; var or__1927000174__auto____22 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_125.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(recv__8)))
//line :1306:1
			if jrt.J2g_Truth(or__1927000174__auto____22) { tmp18 = or__1927000174__auto____22 } else { tmp18 = l__12 }
			var tmp20 any = A_arbace_repr_go_convert_A_const_512; var tmp21 *lang.Keyword = A_arbace_repr_go_convert_A_const_71; var tmp22 any = tmp21.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(recv__8)); var tmp23 any = A_arbace_repr_go_convert_A_const_513; var tmp24 *lang.Keyword = A_arbace_repr_go_convert_A_const_268; ps__22 = tmp8.Invoke_O_O__O(tmp9.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O_O__O(tmp16, tmp17, tmp18)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp22, tmp23, tmp24.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(recv__8))))) } else {
//line :1304:1
				ps__22 = ps__20 }
//line :1295:1
		var tmp25 *lang.Keyword = A_arbace_repr_go_convert_A_const_72; var tmp26 *lang.Keyword = A_arbace_repr_go_convert_A_const_294; var has_results__23 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(tmp25.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(tmp26.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(type__10))))); var ret__24 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_347.GetRawRoot__O()).Invoke_O__O(nil); var body_forms__25 any















		if jrt.J2g_Truth(body__11) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_351, ret__24)); var tmp27 any = A_arbace_repr_go_convert_func_decl_fn__1114000434_A_New_O_O(body__11, has_results__23); var tmp28 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_repr_go_convert_func_decl_fn__1114000434_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_138, false); A_arbace_repr_go_convert_func_decl_fn__1114000434_A_fn_class = fncls__83d; tmp28 = fncls__83d } else { tmp28 = fncls__83 }; body_forms__25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil).Invoke__O() } else { body_forms__25 = nil }
		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(type__10)





		var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp32 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp33 any
//line :1313:1
		if jrt.J2g_Truth(recv__8) { tmp33 = A_arbace_repr_go_convert_A_const_514 } else { tmp33 = A_arbace_repr_go_convert_A_const_515
		}



		var tmp34 any = tmp33; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp36 lang.IPersistentVector
//line :1314:1
		if jrt.J2g_Truth(docstr__13) { tmp36 = lang.Tuple_Create_O__IPersistentVector(docstr__13) } else { tmp36 = nil
		}


		var tmp37 any = tmp36; var tmp38 lang.IPersistentVector
//line :1315:1
		if jrt.J2g_Truth(tps__15) { var tmp39 any = A_arbace_repr_go_convert_A_const_405; tmp38 = lang.Tuple_Create_O_O__IPersistentVector(tmp39, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()).Invoke_O_O_O_O__O(tps__15, A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(), A_arbace_repr_go_convert_A_const_140, l__12)) } else { tmp38 = nil
		}

		var tmp40 any = tmp31.Invoke_O_O_O_O_O_O__O(tmp32, d__0, l__12, tmp34, nm__14, tmp35.Invoke_O_O_O_O_O__O(tmp37, tmp38, lang.Tuple_Create_O__IPersistentVector(ps__22), rs__21, body_forms__25)); var tmp41 lang.IPersistentMap
//line :1317:1
		if jrt.J2g_Truth(body__11) { var tmp42 any = A_arbace_repr_go_convert_A_const_352; var tmp43 *lang.Keyword = A_arbace_repr_go_convert_A_const_158; tmp41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp42, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_125.GetRawRoot__O()).Invoke_O__O(tmp43.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(body__11))))) } else { tmp41 = nil }
		var tmp44 any = A_arbace_repr_go_convert_A_const_101; var tmp45 *lang.Keyword = A_arbace_repr_go_convert_A_const_101; var tmp46 any = tmp45.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(type__10)); var tmp47 any = A_arbace_repr_go_convert_A_const_58; tmp3 = tmp29.Invoke_O_O__O(tmp30.Invoke_O_O__O(tmp40, tmp41), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_147.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp44, tmp46, tmp47, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_8.GetRawRoot__O()).Invoke_O__O(ret__24))), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_354.GetRawRoot__O()).Invoke_O__O(body__11))) }; return nil }()
//line :1297:1
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O()
//line :1295:1
	if tmp48 != nil { panic(tmp48) }; return tmp3
}














func A_arbace_repr_go_convert_func_decl_fn__1114000434_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_func_decl_fn__1114000434_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_func_decl_fn__1114000434_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1311:1
func (t *A_arbace_repr_go_convert_func_decl_fn__1114000434_A) Ctor_O_O(c__body, c__has_results any) { t.F_body = c__body; t.F_has_results = c__has_results }
//line :1311:1
func (t *A_arbace_repr_go_convert_func_decl_fn__1114000434_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_348.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_349.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_body; t.F_body = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_repr_go_convert_A_const_350; var tmp7 any; var t__2 any = t.F_has_results; t.F_has_results = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp7)).Ref())))) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }








func A_arbace_repr_go_convert_value_spec_target_A_New() *A_arbace_repr_go_convert_value_spec_target_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_value_spec_target_A{}; t.Ctor(); return t }
//line :1320:1
func (t *A_arbace_repr_go_convert_value_spec_target_A) Ctor() {}
//line :1320:1
func (t *A_arbace_repr_go_convert_value_spec_target_A) Invoke_O_O_O_O__O(self, sp__0, kind__1, extra__2 any) any { var map__1114000437__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__0); var map__1114000437__5 any; if



	lang.ISeq_InstanceOf(map__1114000437__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000437__4)) { map__1114000437__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000437__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000437__4)) { map__1114000437__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000437__4) } else { lang.PersistentArrayMap_Init(); map__1114000437__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000437__5 = map__1114000437__4 }; var names__6 any = /*line :1320:1*/lang.RT_Get_O_O__O(map__1114000437__5, A_arbace_repr_go_convert_A_const_54); var type__7 any = lang.RT_Get_O_O__O(map__1114000437__5, A_arbace_repr_go_convert_A_const_60); var l__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__0); var t__9 any; if





	jrt.J2g_Truth(type__7) { t__9 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__7) } else { t__9 = nil }; var mk__10 any; var tmp1 any = /*line :1320:1*/A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A_New_O_O_O(t__9, extra__2, kind__1); var tmp2 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A_fn_class; if






	fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_243, false); A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A_fn_class = fncls__84d; tmp2 = fncls__84d } else { tmp2 = fncls__84 }; mk__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if


	lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(names__6))) {
		var tmp3 lang.IFn = lang.IFn_Cast(mk__10); var tmp4 any = A_arbace_repr_go_convert_A_const_18; return tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(names__6)) } else {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp7 any = A_arbace_repr_go_convert_A_const_516; return tmp5.Invoke_O_O_O_O_O__O(tmp6, nil, l__8, tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(mk__10, names__6)) } }
//line :1327:1
func A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1327:1
func (t *A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A) Ctor_O_O_O(c__t, c__extra, c__kind any) { t.F_t = c__t; t.F_extra = c__extra; t.F_kind = c__kind }
//line :1327:1
func (t *A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A) Invoke_O_O_O__O(self, i__1, nm__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_253.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(nm__2), t.F_t); var tmp4 any
//line :1328:1
	if lang.Util_Equiv_O_O__Z(t.F_kind, A_arbace_repr_go_convert_A_const_187) { tmp4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_396.GetRawRoot__O()).Invoke_O__O(nm__2) } else { tmp4 = nil }
	var tmp5 any = tmp2.Invoke_O_O__O(tmp3, tmp4); var tmp6 any; if lang.Numbers_IsZero_O__Z(i__1) { tmp6 = t.F_extra } else { tmp6 = nil }; return tmp1.Invoke_O_O__O(tmp5, tmp6)
}



func A_arbace_repr_go_convert_gen_decl_A_New() *A_arbace_repr_go_convert_gen_decl_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gen_decl_A{}; t.Ctor(); return t }
//line :1334:1
func (t *A_arbace_repr_go_convert_gen_decl_A) Ctor() {}
//line :1334:1
func (t *A_arbace_repr_go_convert_gen_decl_A) Invoke_O_O_O__O(self, d__0, spec_meta__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(d__0)
//line :1334:1
	var map__1114000442__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__0); var map__1114000442__4 any

	if lang.ISeq_InstanceOf(map__1114000442__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000442__3)) { map__1114000442__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000442__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000442__3)) { map__1114000442__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000442__3) } else { lang.PersistentArrayMap_Init(); map__1114000442__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000442__4 = map__1114000442__3 }
//line :1334:1
	var tok__5 any = lang.RT_Get_O_O__O(map__1114000442__4, A_arbace_repr_go_convert_A_const_392); var specs__6 any = lang.RT_Get_O_O__O(map__1114000442__4, A_arbace_repr_go_convert_A_const_393); var lparen__7 any = lang.RT_Get_O_O__O(map__1114000442__4, A_arbace_repr_go_convert_A_const_115); var doc__8 any = lang.RT_Get_O_O__O(map__1114000442__4, A_arbace_repr_go_convert_A_const_238); var l__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(d__0); var docstr__10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_240.GetRawRoot__O()).Invoke_O_O__O(doc__8, A_arbace_repr_go_convert_A_const_248.Get__O()); var head__11 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O_O__O(Lit_110, tok__5)





	if lang.Util_Equiv_O_O__Z(tok__5, Lit_101) { var spec__12 any; var tmp1 any = A_arbace_repr_go_convert_gen_decl_spec__1114000444_A_New_O(spec_meta__1); var tmp2 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_repr_go_convert_gen_decl_spec__1114000444_A_fn_class
		if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_147, false); A_arbace_repr_go_convert_gen_decl_spec__1114000444_A_fn_class = fncls__85d; tmp2 = fncls__85d } else { tmp2 = fncls__85 }; spec__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)











		if jrt.J2g_Truth(lparen__7) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp6 lang.IPersistentVector; if jrt.J2g_Truth(docstr__10) { tmp6 = lang.Tuple_Create_O__IPersistentVector(docstr__10) } else { tmp6 = nil }; var tmp7 any = tmp6; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_gen_decl_fn__1114000448_A_New_O(spec__12); var tmp10 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_repr_go_convert_gen_decl_fn__1114000448_A_fn_class
			if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_148, false); A_arbace_repr_go_convert_gen_decl_fn__1114000448_A_fn_class = fncls__87d; tmp10 = fncls__87d } else { tmp10 = fncls__87 }
//line :1354:1
			return tmp3.Invoke_O_O_O_O_O__O(tmp4, d__0, l__9, head__11, tmp5.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), specs__6))) } else {
//line :1353:1
				var tmp11 lang.IFn = lang.IFn_Cast(spec__12); var tmp12 any = A_arbace_repr_go_convert_A_const_18; var vec__1114000450__13 any = tmp11.Invoke_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(specs__6), nil); var seq__1114000451__14 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(vec__1114000450__13); var first__1114000452__15 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1114000451__14); var seq__1114000451__16 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq__1114000451__14); var nm__17 any = first__1114000452__15; var more__18 any = seq__1114000451__16; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp16 lang.IPersistentVector



				if jrt.J2g_Truth(docstr__10) { tmp16 = lang.Tuple_Create_O__IPersistentVector(docstr__10) } else { tmp16 = nil }; return tmp13.Invoke_O_O_O_O_O_O__O(tmp14, d__0, l__9, head__11, nm__17, tmp15.Invoke_O_O__O(tmp16, more__18)) } } else {
//line :1340:1
					var kind__12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_201.GetRawRoot__O()).Invoke_O__O(tok__5); var spec_vec__13 any; var tmp17 any = A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A_New_O_O(spec_meta__1, kind__12); var tmp18 *jrt.Class
					var fncls__86 /*line :1340:1*/*jrt.Class = A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A_fn_class


















					if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_149, false); A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A_fn_class = fncls__86d; tmp18 = fncls__86d } else { tmp18 = fncls__86 }; spec_vec__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)





					if jrt.J2g_Truth(lparen__7) {
						var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp20 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp22 lang.IPersistentVector; if jrt.J2g_Truth(docstr__10) { tmp22 = lang.Tuple_Create_O__IPersistentVector(docstr__10) } else { tmp22 = nil }; return tmp19.Invoke_O_O_O_O_O__O(tmp20, d__0, l__9, head__11, tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(spec_vec__13, specs__6))) } else {
//line :1365:1
							var sp__14 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(specs__6); var map__1114000457__15 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__14); var map__1114000457__16 any

							if lang.ISeq_InstanceOf(map__1114000457__15) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000457__15)) { map__1114000457__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000457__15), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000457__15)) { map__1114000457__16 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000457__15) } else { lang.PersistentArrayMap_Init(); map__1114000457__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000457__16 = map__1114000457__15 }
//line :1365:1
							var values__17 any = lang.RT_Get_O_O__O(map__1114000457__16, A_arbace_repr_go_convert_A_const_395); var ___18 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sp__14); var tg__19 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_518.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_147.GetRawRoot__O()); var tmp25 any = lang.IFn_Cast(spec_meta__1).Invoke_O__O(A_arbace_repr_go_convert_A_const_18); var tmp26 lang.IPersistentMap; _ = ___18




							if jrt.J2g_Truth(docstr__10) { tmp26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_238, docstr__10)) } else { tmp26 = nil }; tg__19 = tmp23.Invoke_O_O_O__O(sp__14, kind__12, tmp24.Invoke_O_O__O(tmp25, tmp26))
							var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp28 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp29 lang.IPersistentVector; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(values__17)) { tmp29 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_388.GetRawRoot__O()).Invoke_O_O__O(values__17, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__14))) } else { tmp29 = nil }; return tmp27.Invoke_O_O_O_O_O_O__O(tmp28, d__0, l__9, head__11, tg__19, tmp29) } } }
//line :1341:1
func A_arbace_repr_go_convert_gen_decl_spec__1114000444_A_New_O(p0 any) *A_arbace_repr_go_convert_gen_decl_spec__1114000444_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gen_decl_spec__1114000444_A{}; t.Ctor_O(p0); return t }
//line :1341:1
func (t *A_arbace_repr_go_convert_gen_decl_spec__1114000444_A) Ctor_O(c__spec_meta any) { t.F_spec_meta = c__spec_meta }
//line :1341:1
func (t *A_arbace_repr_go_convert_gen_decl_spec__1114000444_A) Invoke_O_O_O_O__O(self, i__1, sp__2, extra__3 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sp__2)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_227; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_407.GetRawRoot__O()).Invoke_O__O(sp__2))).Ref()))
//line :1341:1
	var tmp3 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var map__1114000445__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__2); var map__1114000445__7 any


		if lang.ISeq_InstanceOf(map__1114000445__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000445__6)) { map__1114000445__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000445__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000445__6)) { map__1114000445__7 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000445__6) } else { lang.PersistentArrayMap_Init(); map__1114000445__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000445__7 = map__1114000445__6 }
//line :1341:1
		var name__8 any = lang.RT_Get_O_O__O(map__1114000445__7, A_arbace_repr_go_convert_A_const_49); var assign__9 any = lang.RT_Get_O_O__O(map__1114000445__7, A_arbace_repr_go_convert_A_const_384); var type__10 any = lang.RT_Get_O_O__O(map__1114000445__7, A_arbace_repr_go_convert_A_const_60); var doc__11 any = lang.RT_Get_O_O__O(map__1114000445__7, A_arbace_repr_go_convert_A_const_238); var tparams__12 any = lang.RT_Get_O_O__O(map__1114000445__7, A_arbace_repr_go_convert_A_const_405); var d2__13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_240.GetRawRoot__O()).Invoke_O_O__O(doc__11, A_arbace_repr_go_convert_A_const_248.Get__O()); var nm__14 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_190.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(name__8); var tmp9 any





		if jrt.J2g_Truth(assign__9) { tmp9 = A_arbace_repr_go_convert_A_const_517 } else { tmp9 = nil
		}

		var tmp10 any = tmp6.Invoke_O_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9), lang.IFn_Cast(t.F_spec_meta).Invoke_O__O(i__1)); var tmp11 lang.IPersistentMap
//line :1349:1
		if jrt.J2g_Truth(d2__13) { tmp11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_238, d2__13)) } else { tmp11 = nil }
		nm__14 = tmp4.Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp10, tmp11), extra__3)
//line :1341:1
		var tps__15 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_406.GetRawRoot__O()).Invoke_O__O(tparams__12); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp13 any = lang.Tuple_Create_O__IPersistentVector(nm__14); var tmp14 lang.IPersistentVector










		if jrt.J2g_Truth(tps__15) { var tmp15 any = A_arbace_repr_go_convert_A_const_405; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp17 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp18 any = A_arbace_repr_go_convert_A_const_140; tmp14 = lang.Tuple_Create_O_O__IPersistentVector(tmp15, tmp16.Invoke_O_O_O_O__O(tps__15, tmp17, tmp18, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__2))) } else { tmp14 = nil }; tmp3 = tmp12.Invoke_O_O_O__O(tmp13, tmp14, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(type__10))) }; return nil }()
//line :1343:1
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O()
//line :1341:1
	if tmp19 != nil { panic(tmp19) }; return tmp3
}












func A_arbace_repr_go_convert_gen_decl_fn__1114000448_A_New_O(p0 any) *A_arbace_repr_go_convert_gen_decl_fn__1114000448_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gen_decl_fn__1114000448_A{}; t.Ctor_O(p0); return t }
//line :1355:1
func (t *A_arbace_repr_go_convert_gen_decl_fn__1114000448_A) Ctor_O(c__spec any) { t.F_spec = c__spec }
//line :1355:1
func (t *A_arbace_repr_go_convert_gen_decl_fn__1114000448_A) Invoke_O_O_O__O(self, i__1, sp__2 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__2), lang.IFn_Cast(t.F_spec).Invoke_O_O_O__O(i__1, sp__2, nil)) }



func A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1359:1
func (t *A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A) Ctor_O_O(c__spec_meta, c__kind any) { t.F_spec_meta = c__spec_meta; t.F_kind = c__kind }
//line :1359:1
func (t *A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A) Invoke_O_O_O__O(self, i__1, sp__2 any) any {
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sp__2)
//line :1359:1
	var map__1114000454__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__2); var map__1114000454__4 any

	if lang.ISeq_InstanceOf(map__1114000454__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000454__3)) { map__1114000454__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000454__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000454__3)) { map__1114000454__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000454__3) } else { lang.PersistentArrayMap_Init(); map__1114000454__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000454__4 = map__1114000454__3 }
//line :1359:1
	var values__5 any = lang.RT_Get_O_O__O(map__1114000454__4, A_arbace_repr_go_convert_A_const_395); var doc__6 any = lang.RT_Get_O_O__O(map__1114000454__4, A_arbace_repr_go_convert_A_const_238); var d2__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_240.GetRawRoot__O()).Invoke_O_O__O(doc__6, A_arbace_repr_go_convert_A_const_248.Get__O()); var tg__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_518.GetRawRoot__O()); var tmp2 any = t.F_kind; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_147.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(t.F_spec_meta).Invoke_O__O(i__1); var tmp5 lang.IPersistentMap



	if jrt.J2g_Truth(d2__7) { tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_convert_A_const_238, d2__7)) } else { tmp5 = nil }; tg__8 = tmp1.Invoke_O_O_O__O(sp__2, tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5))
	var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__2); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tg__8); var tmp10 lang.IPersistentVector; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(values__5)) { tmp10 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_388.GetRawRoot__O()).Invoke_O_O__O(values__5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__2))) } else { tmp10 = nil }; return tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10))
}









func A_arbace_repr_go_convert_file_directives_A_New() *A_arbace_repr_go_convert_file_directives_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_file_directives_A{}; t.Ctor(); return t }
//line :1375:1
func (t *A_arbace_repr_go_convert_file_directives_A) Ctor() {}
//line :1375:1
func (t *A_arbace_repr_go_convert_file_directives_A) Invoke_O_O_O__O(self, dump__0, name__1 any) any { var prefix__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_32), jrt.RefArrayOf(jrt.Object_class, name__1, nil)).Ref(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A_New_O(prefix__3); var tmp4 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A_fn_class; if



	fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_133, false); A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A_fn_class = fncls__90d; tmp4 = fncls__90d } else { tmp4 = fncls__90 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_repr_go_convert_A_const_519.Invoke_O__O(dump__0)); return tmp1.Invoke_O__O(tmp2) }
//line :1379:1
func A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A_New_O(p0 any) *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A{}; t.Ctor_O(p0); return t }
//line :1379:1
func (t *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A) Ctor_O(c__prefix any) { t.F_prefix = c__prefix }
//line :1379:1
func (t *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A) Invoke_O_O__O(self, s__1114000461__1 any) any { var tmp1 any = A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A_New_O_O_O(t.F_prefix, s__1114000461__1, self); var tmp2 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A_fn_class = fncls__89d; tmp2 = fncls__89d } else { tmp2 = fncls__89 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1379:1
func A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1379:1
func (t *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A) Ctor_O_O_O(c__prefix, c__s__1114000461, c__iter__1114000460 any) { t.F_prefix = c__prefix; t.F_s__1114000461 = c__s__1114000461; t.F_iter__1114000460 = c__iter__1114000460 }
//line :1379:1
func (t *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A) Invoke_O__O(self any) any { { var s__1114000461__1 any; var t_ any = t.F_s__1114000461; t.F_s__1114000461 = nil; s__1114000461__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000461__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000461__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000461__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000461__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000463__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A_New_O_O_I_O(b__1114000463__6, t.F_prefix, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A_fn_class = fncls__88d; tmp2 = fncls__88d } else { tmp2 = fncls__88 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000460); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000463__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000461__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000463__6), nil) } } else { var vec__1114000474__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000461__3); var p__5 any = lang.RT_Nth_O_I_O__O(vec__1114000474__4, lang.RT_IntCast_J__I(0), nil); var text__6 any = lang.RT_Nth_O_I_O__O(vec__1114000474__4, lang.RT_IntCast_J__I(1), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(p__5, t.F_prefix)) { var vec__1114000477__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()).Invoke_O_O__O(p__5, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_prefix)).Ref())); var l__8 any = lang.RT_Nth_O_I_O__O(vec__1114000477__7, lang.RT_IntCast_J__I(0), nil); var c__9 any = lang.RT_Nth_O_I_O__O(vec__1114000477__7, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()); var tmp5 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(text__6, Lit_136)




	if jrt.J2g_Truth(and__1927000168__auto____10) { tmp5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(c__9, A_arbace_repr_go_convert_A_const_334) } else { tmp5 = and__1927000168__auto____10 }
//line :1379:1
	if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5)) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1114000460); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(l__8, c__9, text__6), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000461__3))) } else { s__1114000461__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000461__3); continue L1 } } else { s__1114000461__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000461__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1379:1
func A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1379:1
func (t *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A) Ctor_O_O_I_O(c__b__1114000463, c__prefix any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000463 = c__b__1114000463; t.F_prefix = c__prefix; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1379:1
func (t *A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A) Invoke_O__O(self any) any { { var i__1114000462__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000462__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1114000467__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000462__1)); var p__3 any = lang.RT_Nth_O_I_O__O(vec__1114000467__2, lang.RT_IntCast_J__I(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O(vec__1114000467__2, lang.RT_IntCast_J__I(1), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(p__3, t.F_prefix)) { var vec__1114000470__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()).Invoke_O_O__O(p__3, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_prefix)).Ref())); var l__6 any = lang.RT_Nth_O_I_O__O(vec__1114000470__5, lang.RT_IntCast_J__I(0), nil); var c__7 any = lang.RT_Nth_O_I_O__O(vec__1114000470__5, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()); var tmp3 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(text__4, Lit_136)




	if jrt.J2g_Truth(and__1927000168__auto____8) { tmp3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(c__7, A_arbace_repr_go_convert_A_const_334) } else { tmp3 = and__1927000168__auto____8 }
//line :1379:1
	if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp5 any = t.F_b__1114000463; tmp4.Invoke_O_O__O(tmp5, lang.Tuple_Create_O_O_O__IPersistentVector(l__6, c__7, text__4)); i__1114000462__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000462__1); continue L1 } else { i__1114000462__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000462__1); continue L1 } } else { i__1114000462__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000462__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_repr_go_convert_decl_name_A_New() *A_arbace_repr_go_convert_decl_name_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_decl_name_A{}; t.Ctor(); return t }
//line :1387:1
func (t *A_arbace_repr_go_convert_decl_name_A) Ctor() {}
//line :1387:1
func (t *A_arbace_repr_go_convert_decl_name_A) Invoke_O_O__O(self, d__0 any) any { var G__1114000483__2_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__0); switch


	lang.Util_Hash_O__I(G__1114000483__2_) >> 4 & 3 { case 0: if any(G__1114000483__2_) == any(A_arbace_repr_go_convert_A_const_50) {

		var tmp1 *lang.Keyword = A_arbace_repr_go_convert_A_const_54; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__0)))) }
//line :1390:1
	case 2: if any(G__1114000483__2_) == any(A_arbace_repr_go_convert_A_const_123) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__0))) }
//line :1390:1
	case 3: if any(G__1114000483__2_) == any(A_arbace_repr_go_convert_A_const_89) {


		var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__0))) }
//line :1390:1
	default:}; return nil }





func A_arbace_repr_go_convert_imports_of_A_New() *A_arbace_repr_go_convert_imports_of_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_A{}; t.Ctor(); return t }
//line :1396:1
func (t *A_arbace_repr_go_convert_imports_of_A) Ctor() {}
//line :1396:1
func (t *A_arbace_repr_go_convert_imports_of_A) Invoke_O_O__O(self, decls__0 any) any { var seq_1114000485__2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(decls__0); var chunk_1114000486__3 any; var count_1114000487__4 int64 = 0; var i_1114000488__5 int64 = 0; L1: for {
											if lang.Numbers_Lt_J_J__Z(i_1114000488__5, count_1114000487__4) { var d__6 any = lang.Indexed_Cast(chunk_1114000486__3).Nth_I__O(lang.RT_IntCast_J__I(i_1114000488__5)); var tmp1 bool; var tmp2 any = A_arbace_repr_go_convert_A_const_90; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__6)); if and__1927000168__auto____7 { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; tmp1 = lang.Util_Equiv_O_O__Z(Lit_54, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__6))) } else { tmp1 = and__1927000168__auto____7 }; if tmp1 { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(d__6); seq_1114000485__2, chunk_1114000486__3, count_1114000487__4, i_1114000488__5 = seq_1114000485__2, chunk_1114000486__3, count_1114000487__4, lang.Numbers_Unchecked_inc_J__J(i_1114000488__5); continue L1 } else { seq_1114000485__2, chunk_1114000486__3, count_1114000487__4, i_1114000488__5 = seq_1114000485__2, chunk_1114000486__3, count_1114000487__4, lang.Numbers_Unchecked_inc_J__J(i_1114000488__5); continue L1 } } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1114000485__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1114000485__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(seq_1114000485__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(seq_1114000485__7); seq_1114000485__2, chunk_1114000486__3, count_1114000487__4, i_1114000488__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_1114000485__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var d__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1114000485__7); var tmp4 bool; var tmp5 any = A_arbace_repr_go_convert_A_const_90; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__8)); if and__1927000168__auto____9 { var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; tmp4 = lang.Util_Equiv_O_O__Z(Lit_54, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__8))) } else { tmp4 = and__1927000168__auto____9 }; if tmp4 { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(d__8); seq_1114000485__2, chunk_1114000486__3, count_1114000487__4, i_1114000488__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq_1114000485__7), nil, 0, 0; continue L1 } else { seq_1114000485__2, chunk_1114000486__3, count_1114000487__4, i_1114000488__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(seq_1114000485__7), nil, 0, 0; continue L1 } } } }
//line :1396:1
	break L1 }; var tmp7 lang.IFn =

	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp8 any; var iter__1927001039__auto____2 any; var tmp9 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A_New(); var tmp10 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A_fn_class; if
	fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_155, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A_fn_class = fncls__100d; tmp10 = fncls__100d } else { tmp10 = fncls__100 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); tmp8 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(decls__0); return /*line :1398:1*/ tmp7.Invoke_O__O(tmp8) }
func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A_New() *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A{}; t.Ctor(); return t }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A) Ctor() {}
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A) Invoke_O_O__O(self, s__1114000490__1 any) any { var tmp1 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A_New_O_O(self, s__1114000490__1); var tmp2 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_156, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A_fn_class = fncls__99d; tmp2 = fncls__99d } else { tmp2 = fncls__99 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1399:1
func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A) Ctor_O_O(c__iter__1114000489, c__s__1114000490 any) { t.F_iter__1114000489 = c__iter__1114000489; t.F_s__1114000490 = c__s__1114000490 }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A) Invoke_O__O(self any) any { { var s__1114000490__1 any; var t_ any = t.F_s__1114000490; t.F_s__1114000490 = nil; s__1114000490__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000490__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp1 bool; var tmp2 any = A_arbace_repr_go_convert_A_const_90; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__4))
															if and__1927000168__auto____5 { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; tmp1 = lang.Util_Equiv_O_O__Z(Lit_54, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__4))) } else { tmp1 = and__1927000168__auto____5 }
//line :1399:1
	if tmp1 { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A_New_O(d__4); var tmp5 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_157, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A_fn_class = fncls__98d; tmp5 = fncls__98d } else { tmp5 = fncls__98 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_393; var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_525.GetRawRoot__O(), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__4))))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1114000489); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000490__1))) } else { s__1114000490__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000490__1); continue L1 } } else { s__1114000490__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000490__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :1399:1
func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A_New_O(p0 any) *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A{}; t.Ctor_O(p0); return t }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A) Invoke_O_O__O(self, s__1114000492__1 any) any { var tmp1 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A_New_O_O_O(t.F_d, s__1114000492__1, self); var tmp2 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_158, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A_fn_class = fncls__97d; tmp2 = fncls__97d } else { tmp2 = fncls__97 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1399:1
func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A) Ctor_O_O_O(c__d, c__s__1114000492, c__iter__1114000491 any) { t.F_d = c__d; t.F_s__1114000492 = c__s__1114000492; t.F_iter__1114000491 = c__iter__1114000491 }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A) Invoke_O__O(self any) any { { var s__1114000492__1 any; var t_ any = t.F_s__1114000492; t.F_s__1114000492 = nil; s__1114000492__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000492__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000492__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000492__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000492__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000494__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A_New_O_I_O_O(t.F_d, size__1927001038__auto____5, b__1114000494__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_159, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000491); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000494__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000492__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000494__6), nil) } } else { var vec__1114000511__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000492__3); var i__5 any = lang.RT_Nth_O_I_O__O(vec__1114000511__4, lang.RT_IntCast_J__I(0), nil); var sp__6 any = lang.RT_Nth_O_I_O__O(vec__1114000511__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp5 any; var map__1114000514__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__6); var map__1114000514__8 any


	if lang.ISeq_InstanceOf(map__1114000514__7) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000514__7)) { map__1114000514__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000514__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000514__7)) { map__1114000514__8 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000514__7) } else { lang.PersistentArrayMap_Init(); map__1114000514__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000514__8 = map__1114000514__7 }
//line :1399:1
	var name__9 any = lang.RT_Get_O_O__O(map__1114000514__8, A_arbace_repr_go_convert_A_const_49); var path__10 any = lang.RT_Get_O_O__O(map__1114000514__8, A_arbace_repr_go_convert_A_const_51); var l__11 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__6); var p__12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_247.GetRawRoot__O()).Invoke_O__O(path__10); var pv__13 any; var G__1114000516__13_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(p__12), p__12)





	if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_148.Get__O()) {

		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_163; var tmp8 *lang.Keyword = A_arbace_repr_go_convert_A_const_206; pv__13 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_216.GetRawRoot__O()).Invoke_O_O_O__O(tmp6.Invoke_O_O_O__O(G__1114000516__13_, tmp7, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(path__10))), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(path__10)), A_arbace_repr_go_convert_A_const_219.GetRawRoot__O()) } else {
//line :1405:1
			pv__13 = G__1114000516__13_ }
//line :1399:1
	var nm__14 any; var tmp9 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A_New_O(name__9); var tmp10 *jrt.Class
	var fncls__95 /*line :1399:1*/*jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A_fn_class








	if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_160, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A_fn_class = fncls__95d; tmp10 = fncls__95d } else { tmp10 = fncls__95 }; nm__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)
//line :1399:1
	var decl_pos__15 any; var tmp11 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A_New_O_O(t.F_d, i__5); var tmp12 *jrt.Class
	var fncls__96 /*line :1399:1*/*jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A_fn_class










	if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_161, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A_fn_class = fncls__96d; tmp12 = fncls__96d } else { tmp12 = fncls__96 }; decl_pos__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sp__6); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(path__10)
	var tmp13 lang.IFn = lang.IFn_Cast(decl_pos__15); var tmp14 any
	if lang.Util_Identical_O_O__Z(name__9, nil) {
		var tmp15 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var tmp16 *lang.Keyword = A_arbace_repr_go_convert_A_const_522; tmp14 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__11, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(sp__6)))), pv__13)) } else {
//line :1413:1
			var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_524); if jrt.J2g_Truth(tmp17.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(name__9))) {

				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(name__9); tmp14 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__11, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(nm__14).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(name__9)), pv__13)) } else {
//line :1413:1
					if A_arbace_repr_go_convert_A_const_152 != nil {


						lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(name__9); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp19 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__11, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(nm__14).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(name__9)), pv__13)); var tmp20 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp21 any = A_arbace_repr_go_convert_A_const_409; var tmp22 *jrt.Boolean; jrt.Boolean_Init(); tmp22 = jrt.Boolean_TRUE; tmp14 = tmp18.Invoke_O_O_O_O__O(tmp19, tmp20, tmp21, tmp22.Ref()) } else {
//line :1413:1
							tmp14 = nil } } }
//line :1412:1
	tmp5 = tmp13.Invoke_O__O(tmp14)
//line :1399:1
	var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__1114000491); return tmp4.Invoke_O_O__O(tmp5, tmp23.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000492__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1399:1
func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A) Ctor_O_I_O_O(c__d any, c__size__1927001038__auto__ int32, c__b__1114000494, c__c__1927001037__auto__ any) { t.F_d = c__d; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1114000494 = c__b__1114000494; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1399:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A) Invoke_O__O(self any) any { { var i__1114000493__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000493__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1114000500__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000493__1)); var i__3 any = lang.RT_Nth_O_I_O__O(vec__1114000500__2, lang.RT_IntCast_J__I(0), nil); var sp__4 any = lang.RT_Nth_O_I_O__O(vec__1114000500__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000494; var tmp4 any; var map__1114000503__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__4); var map__1114000503__6 any


	if lang.ISeq_InstanceOf(map__1114000503__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000503__5)) { map__1114000503__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000503__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000503__5)) { map__1114000503__6 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000503__5) } else { lang.PersistentArrayMap_Init(); map__1114000503__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000503__6 = map__1114000503__5 }
//line :1399:1
	var name__7 any = lang.RT_Get_O_O__O(map__1114000503__6, A_arbace_repr_go_convert_A_const_49); var path__8 any = lang.RT_Get_O_O__O(map__1114000503__6, A_arbace_repr_go_convert_A_const_51); var l__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__4); var p__10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_247.GetRawRoot__O()).Invoke_O__O(path__8); var pv__11 any; var G__1114000505__11_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(p__10), p__10)





	if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_148.Get__O()) {

		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_convert_A_const_163; var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_206; pv__11 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_216.GetRawRoot__O()).Invoke_O_O_O__O(tmp5.Invoke_O_O_O__O(G__1114000505__11_, tmp6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(path__8))), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(path__8)), A_arbace_repr_go_convert_A_const_219.GetRawRoot__O()) } else {
//line :1405:1
			pv__11 = G__1114000505__11_ }
//line :1399:1
	var nm__12 any; var tmp8 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A_New_O(name__7); var tmp9 *jrt.Class
	var fncls__92 /*line :1399:1*/*jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A_fn_class








	if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_162, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A_fn_class = fncls__92d; tmp9 = fncls__92d } else { tmp9 = fncls__92 }; nm__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :1399:1
	var decl_pos__13 any; var tmp10 any = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A_New_O_O(t.F_d, i__3); var tmp11 *jrt.Class
	var fncls__93 /*line :1399:1*/*jrt.Class = A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A_fn_class










	if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_163, false); A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A_fn_class = fncls__93d; tmp11 = fncls__93d } else { tmp11 = fncls__93 }; decl_pos__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(sp__4); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(path__8)
	var tmp12 lang.IFn = lang.IFn_Cast(decl_pos__13); var tmp13 any
	if lang.Util_Identical_O_O__Z(name__7, nil) {
		var tmp14 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var tmp15 *lang.Keyword = A_arbace_repr_go_convert_A_const_522; tmp13 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__9, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(tmp14.Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(sp__4)))), pv__11)) } else {
//line :1413:1
			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_521); if jrt.J2g_Truth(tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(name__7))) {

				lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(name__7); tmp13 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__9, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(nm__12).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(name__7)), pv__11)) } else {
//line :1413:1
					if A_arbace_repr_go_convert_A_const_152 != nil {


						lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(name__7); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_145.GetRawRoot__O()); var tmp18 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()).Invoke_O_O__O(l__9, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(nm__12).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(name__7)), pv__11)); var tmp19 any = A_arbace_repr_go_convert_A_const_141.GetRawRoot__O(); var tmp20 any = A_arbace_repr_go_convert_A_const_409; var tmp21 *jrt.Boolean; jrt.Boolean_Init(); tmp21 = jrt.Boolean_TRUE; tmp13 = tmp17.Invoke_O_O_O_O__O(tmp18, tmp19, tmp20, tmp21.Ref()) } else {
//line :1413:1
							tmp13 = nil } } }
//line :1412:1
	tmp4 = tmp12.Invoke_O__O(tmp13)
//line :1399:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1114000493__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000493__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A_New_O(p0 any) *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A{}; t.Ctor_O(p0); return t }
//line :1408:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :1408:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A) Invoke_O_O__O(self, s__1 any) any { if jrt.J2g_Truth(t.F_name) { var tmp1 any = A_arbace_repr_go_convert_A_const_56; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(s__1), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(t.F_name)))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(s__1) } }
//line :1408:1
func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A_New_O(p0 any) *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A{}; t.Ctor_O(p0); return t }
//line :1408:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :1408:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A) Invoke_O_O__O(self, s__1 any) any { if jrt.J2g_Truth(t.F_name) { var tmp1 any = A_arbace_repr_go_convert_A_const_56; return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(s__1), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(t.F_name)))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(s__1) } }

func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1410:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A) Ctor_O_O(c__d, c__i any) { t.F_d = c__d; t.F_i = c__i }
//line :1410:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A) Invoke_O_O__O(self, v__1 any) any { if lang.Numbers_IsZero_O__Z(t.F_i) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(v__1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_295.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(t.F_d), A_arbace_repr_go_convert_A_const_523)) } else { return v__1 } }
//line :1410:1
func A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1410:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A) Ctor_O_O(c__d, c__i any) { t.F_d = c__d; t.F_i = c__i }
//line :1410:1
func (t *A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A) Invoke_O_O__O(self, v__1 any) any { if lang.Numbers_IsZero_O__Z(t.F_i) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(v__1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_295.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(t.F_d), A_arbace_repr_go_convert_A_const_520)) } else { return v__1 } }









func A_arbace_repr_go_convert_whitespace_QMARK__A_New() *A_arbace_repr_go_convert_whitespace_QMARK__A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_whitespace_QMARK__A{}; t.Ctor(); return t }
//line :1420:1
func (t *A_arbace_repr_go_convert_whitespace_QMARK__A) Ctor() {}
//line :1420:1
func (t *A_arbace_repr_go_convert_whitespace_QMARK__A) Invoke_O_O__O(self, b__0 any) any { var or__1927000174__auto____2 bool = lang.Numbers_Equiv_O_J__Z(b__0, 32); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 bool = lang.Numbers_Equiv_O_J__Z(b__0, 9); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Numbers_Equiv_O_J__Z(b__0, 13); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = lang.Numbers_Equiv_O_J__Z(b__0, 12); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_O_J__Z(b__0, 11)).Ref() } } } } }

func A_arbace_repr_go_convert_source_text_A_New() *A_arbace_repr_go_convert_source_text_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_A{}; t.Ctor(); return t }
//line :1422:1
func (t *A_arbace_repr_go_convert_source_text_A) Ctor() {}
//line :1422:1
func (t *A_arbace_repr_go_convert_source_text_A) Invoke_O_O_O_O__O(self, bs__0, groups__1, lits__2 any) any { var n__4 int32 = lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass())); var starts__5 any; var tmp1 any = A_arbace_repr_go_convert_source_text_fn__1114000529_A_New_I_O(n__4, bs__0); var tmp2 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_repr_go_convert_source_text_fn__1114000529_A_fn_class; if









	fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_186, false); A_arbace_repr_go_convert_source_text_fn__1114000529_A_fn_class = fncls__101d; tmp2 = fncls__101d } else { tmp2 = fncls__101 }; starts__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var off__6 any; var tmp3 any = /*line :1422:1*/A_arbace_repr_go_convert_source_text_off__1114000532_A_New_O(starts__5); var tmp4 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_repr_go_convert_source_text_off__1114000532_A_fn_class; if













	fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_187, false); A_arbace_repr_go_convert_source_text_off__1114000532_A_fn_class = fncls__102d; tmp4 = fncls__102d } else { tmp4 = fncls__102 }; off__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var text__7 any; var tmp5 any = /*line :1422:1*/A_arbace_repr_go_convert_source_text_text__1114000537_A_New_O(bs__0); var tmp6 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_repr_go_convert_source_text_text__1114000537_A_fn_class; if














	fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_188, false); A_arbace_repr_go_convert_source_text_text__1114000537_A_fn_class = fncls__103d; tmp6 = fncls__103d } else { tmp6 = fncls__103 }; text__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var comments__8 any; var tmp7 lang.IFn = /*line :1422:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_534.GetRawRoot__O()); var tmp9 any; var iter__1927001039__auto____8 any; var tmp10 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A_New_O_O_I_O(text__7, off__6, n__4, bs__0); var tmp11 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A_fn_class; if















	fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_189, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A_fn_class = fncls__113d; tmp11 = fncls__113d } else { tmp11 = fncls__113 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(groups__1); comments__8 = tmp7.Invoke_O__O(tmp8.Invoke_O__O(tmp9)); var opaque__9 any; var tmp12 lang.IFn = /*line :1422:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_534.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp15 any; var iter__1927001039__auto____9 any; var tmp16 any = A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A_New_O(off__6); var tmp17 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A_fn_class; if


























	fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_190, false); A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A_fn_class = fncls__116d; tmp17 = fncls__116d } else { tmp17 = fncls__116 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); tmp15 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(comments__8); var tmp18 any = tmp15; var tmp19 any; var iter__1927001039__auto____9_2 any; var tmp20 any = A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A_New_O(off__6); var tmp21 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A_fn_class; if

	fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_191, false); A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A_fn_class = fncls__119d; tmp21 = fncls__119d } else { tmp21 = fncls__119 }; iter__1927001039__auto____9_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); tmp19 = lang.IFn_Cast(iter__1927001039__auto____9_2).Invoke_O__O(lits__2); opaque__9 = /*line :1449:1*/tmp12.Invoke_O__O(tmp13.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, tmp19))); var tail_start__10 any; var tmp22 any = /*line :1422:1*/A_arbace_repr_go_convert_source_text_fn__1114000607_A_New_I_O(n__4, bs__0); var tmp23 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_repr_go_convert_source_text_fn__1114000607_A_fn_class; if





























	fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_192, false); A_arbace_repr_go_convert_source_text_fn__1114000607_A_fn_class = fncls__104d; tmp23 = fncls__104d } else { tmp23 = fncls__104 }; tail_start__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil).Invoke__O(); var space__11 any; var tmp24 lang.IFn = /*line :1422:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_528.GetRawRoot__O()); var tmp25 *lang.PersistentVector;































	lang.PersistentVector_Init(); tmp25 = lang.PersistentVector_EMPTY; space__11 = tmp24.Invoke_O__O(tmp25.Ref()); var semis__12 any; var tmp26 lang.IFn = /*line :1422:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_528.GetRawRoot__O()); var tmp27 *lang.PersistentVector;
































	lang.PersistentVector_Init(); tmp27 = lang.PersistentVector_EMPTY; semis__12 = tmp26.Invoke_O__O(tmp27.Ref()); var commas__13 any; var tmp28 lang.IFn = /*line :1422:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_528.GetRawRoot__O()); var tmp29 *lang.PersistentVector;

































	lang.PersistentVector_Init(); tmp29 = lang.PersistentVector_EMPTY; commas__13 = tmp28.Invoke_O__O(tmp29.Ref()); var i__14 any = /*line :1422:1*/lang.RT_Box_J__Number(0); var line__15 int64 = 1; var col__16 any = lang.RT_Box_J__Number(1); var ops__17 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(opaque__9); L1: for {




































		if lang.Numbers_Lt_O_O__Z(i__14, tail_start__10) { var vec__1114000623__18 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(ops__17); var oa__19 any = lang.RT_Nth_O_I_O__O(vec__1114000623__18, lang.RT_IntCast_J__I(0), nil); var ob__20 any = lang.RT_Nth_O_I_O__O(vec__1114000623__18, lang.RT_IntCast_J__I(1), nil); var tmp30 any
			var and__1927000168__auto____21 any = oa__19

			if jrt.J2g_Truth(and__1927000168__auto____21) { tmp30 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_O_J__Z(i__14, lang.RT_LongCast_O__J(oa__19))).Ref() } else { tmp30 = and__1927000168__auto____21 }
//line :1461:1
			if jrt.J2g_Truth(tmp30) { var ob__21 int64 = lang.RT_LongCast_O__J(ob__20); var nls__22 any; var tmp31 any = A_arbace_repr_go_convert_source_text_fn__1114000629_A_New_O_O_J(bs__0, i__14, ob__21); var tmp32 *jrt.Class
				var fncls__120 /*line :1461:1*/*jrt.Class = A_arbace_repr_go_convert_source_text_fn__1114000629_A_fn_class


				if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_193, false); A_arbace_repr_go_convert_source_text_fn__1114000629_A_fn_class = fncls__120d; tmp32 = fncls__120d } else { tmp32 = fncls__120 }; nls__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O()
//line :1461:1
				var vec__1114000626__23 any = nls__22; var k__24 any = lang.RT_Nth_O_I_O__O(vec__1114000626__23, lang.RT_IntCast_J__I(0), nil); var last__25 any = lang.RT_Nth_O_I_O__O(vec__1114000626__23, lang.RT_IntCast_J__I(1), nil); var tmp33 any = lang.Numbers_Max_O_J__O(i__14, ob__21); var tmp34 int64 = lang.Numbers_Add_J_J__J(line__15, lang.RT_LongCast_O__J(k__24)); var tmp35 jrt.Number_I




				if lang.Numbers_IsPos_J__Z(lang.RT_LongCast_O__J(k__24)) { tmp35 = Up_Long_Number(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(ob__21, lang.RT_LongCast_O__J(last__25)))) } else { tmp35 = lang.Numbers_Add_O_O__Number(col__16, lang.Numbers_Minus_J_O__Number(ob__21, i__14)) }; i__14, line__15, col__16, ops__17 = tmp33, tmp34, tmp35, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(ops__17); continue L1 } else {
//line :1461:1
					if lang.Numbers_Equiv_J_J__Z(10, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(i__14))).Ref())) {





						i__14, line__15, col__16, ops__17 = lang.Numbers_Inc_O__Number(i__14), lang.Numbers_Inc_J__J(line__15), A_arbace_repr_go_convert_A_const_334, ops__17; continue L1 } else {
//line :1461:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_527.GetRawRoot__O()).Invoke_O__O(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(i__14))).Ref())) { var lim__21 any; var tmp36 jrt.Number_I







								if jrt.J2g_Truth(oa__19) { tmp36 = Up_Long_Number(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(oa__19))) } else { tmp36 = Up_Integer_Number(jrt.Integer_ValueOf_I__Integer(n__4)) }; lim__21 = lang.Numbers_Min_O_O__O(tail_start__10, tmp36)
//line :1461:1
								var e__22 any; var tmp37 any = A_arbace_repr_go_convert_source_text_fn__1114000631_A_New_O_O_O(bs__0, lim__21, i__14); var tmp38 *jrt.Class
								var fncls__121 /*line :1461:1*/*jrt.Class = A_arbace_repr_go_convert_source_text_fn__1114000631_A_fn_class








								if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_194, false); A_arbace_repr_go_convert_source_text_fn__1114000631_A_fn_class = fncls__121d; tmp38 = fncls__121d } else { tmp38 = fncls__121 }; e__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil).Invoke__O()
//line :1461:1
								var ws__23 any = lang.IFn_Cast(text__7).Invoke_O_O__O(i__14, e__22); var end_QMARK___24 bool; var or__1927000174__auto____24 bool = lang.Numbers_Gte_O_J__Z(e__22, int64(n__4))










								if or__1927000174__auto____24 { end_QMARK___24 = or__1927000174__auto____24 } else { var or__1927000174__auto____25 bool = lang.Numbers_Equiv_J_J__Z(10, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(e__22))).Ref())); if or__1927000174__auto____25 { end_QMARK___24 = or__1927000174__auto____25 } else { end_QMARK___24 = lang.Numbers_Gte_O_O__Z(e__22, tail_start__10) } }
//line :1461:1
								var ok__25 any











								if end_QMARK___24 { jrt.Boolean_Init(); ok__25 = jrt.Boolean_FALSE.Ref() } else { if lang.Numbers_Equiv_O_J__Z(col__16, 1) {

									var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_313.GetRawRoot__O()); var tmp40 any = A_arbace_repr_go_convert_source_text_fn__1114000633_A_New(); var tmp41 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_repr_go_convert_source_text_fn__1114000633_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_195, false); A_arbace_repr_go_convert_source_text_fn__1114000633_A_fn_class = fncls__122d; tmp41 = fncls__122d } else { tmp41 = fncls__122 }; ok__25 = tmp39.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil), ws__23) } else {
//line :1473:1
										if A_arbace_repr_go_convert_A_const_152 != nil {


											var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_313.GetRawRoot__O()); var tmp43 any = A_arbace_repr_go_convert_source_text_fn__1114000635_A_New(); var tmp44 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_repr_go_convert_source_text_fn__1114000635_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_196, false); A_arbace_repr_go_convert_source_text_fn__1114000635_A_fn_class = fncls__123d; tmp44 = fncls__123d } else { tmp44 = fncls__123 }; ok__25 = tmp42.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil), ws__23) } else {
//line :1473:1
												ok__25 = nil
											}
									}
								}
								if jrt.J2g_Truth(ok__25) { } else { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_538.GetRawRoot__O()).Invoke_O_O__O(space__11, lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(line__15).Ref(), col__16, ws__23)) }
								i__14, line__15, col__16, ops__17 = e__22, line__15, lang.Numbers_Add_O_O__Number(col__16, lang.Numbers_Minus_O_O__Number(e__22, i__14)), ops__17; continue L1 } else {
//line :1461:1
									if A_arbace_repr_go_convert_A_const_152 != nil {

















										if lang.Numbers_Equiv_J_J__Z(59, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(i__14))).Ref())) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_538.GetRawRoot__O()).Invoke_O_O__O(semis__12, lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(line__15).Ref(), col__16)) }
										if lang.Numbers_Equiv_J_J__Z(44, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(i__14))).Ref())) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_538.GetRawRoot__O()).Invoke_O_O__O(commas__13, lang.Tuple_Create_O_O_O__IPersistentVector(i__14, jrt.Long_ValueOf_J__Long(line__15).Ref(), col__16)) }
										i__14, line__15, col__16, ops__17 = lang.Numbers_Inc_O__Number(i__14), line__15, lang.Numbers_Inc_O__Number(col__16), ops__17; continue L1 } } } } }
//line :1422:1
		break L1 }; var tmp45 any = A_arbace_repr_go_convert_A_const_529; var tmp46 any = A_arbace_repr_go_convert_A_const_530; var tmp47 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_531.GetRawRoot__O()).Invoke_O__O(semis__12); var tmp48 any = A_arbace_repr_go_convert_A_const_532; var tmp49 any; var cstarts__14 any; var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()); var tmp51 *lang.PersistentArrayMap;






























































	lang.PersistentArrayMap_Init(); tmp51 = lang.PersistentArrayMap_EMPTY; var tmp52 any = tmp51.Ref(); var tmp53 any; var iter__1927001039__auto____14 any; var tmp54 any = A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A_New_O(off__6); var tmp55 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_197, false); A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A_fn_class = fncls__126d; tmp55 = fncls__126d } else { tmp55 = fncls__126 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp54, tmp55, nil); tmp53 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(comments__8); cstarts__14 = tmp50.Invoke_O_O__O(tmp52, tmp53); var tmp56 lang.IFn =

	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp57 any; var iter__1927001039__auto____15 any; var tmp58 any = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A_New_O_I_O(cstarts__14, n__4, bs__0); var tmp59 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_198, false); A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A_fn_class = fncls__131d; tmp59 = fncls__131d } else { tmp59 = fncls__131 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp58, tmp59, nil); tmp57 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_531.GetRawRoot__O()).Invoke_O__O(commas__13)); tmp49 = tmp56.Invoke_O__O(tmp57); var tmp60 any = tmp49; var tmp61 any = A_arbace_repr_go_convert_A_const_533; var tmp62 any = /*line :1422:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_531.GetRawRoot__O()).Invoke_O__O(space__11); var tmp63 any = A_arbace_repr_go_convert_A_const_350; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp45, comments__8, tmp46, tmp47, tmp48, tmp60, tmp61, tmp62, tmp63, lang.IFn_Cast(text__7).Invoke_O_O__O(tail_start__10, jrt.Integer_ValueOf_I__Integer(n__4).Ref()))) }









func A_arbace_repr_go_convert_source_text_fn__1114000529_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_convert_source_text_fn__1114000529_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_fn__1114000529_A{}; t.Ctor_I_O(p0, p1); return t }
//line :1432:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000529_A) Ctor_I_O(c__n int32, c__bs any) { t.F_n = c__n; t.F_bs = c__bs }
//line :1432:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000529_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var acc__2 any = A_arbace_repr_go_convert_A_const_526; L1: for {
												if lang.Numbers_Lt_J_J__Z(i__1, int64(t.F_n)) {
													var tmp1 int64 = lang.Numbers_Inc_J__J(i__1); var tmp2 any; var tmp3 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); if lang.Numbers_Equiv_J_J__Z(10, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp3, lang.RT_IntCast_J__I(i__1))).Ref())) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_9.GetRawRoot__O()).Invoke_O_O__O(acc__2, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(i__1)).Ref()) } else { tmp2 = acc__2 }; i__1, acc__2 = tmp1, tmp2; continue L1 } else {
//line :1433:1
			return acc__2 } } }; /*line :1432:1*/panic("j2g: unreachable") }



func A_arbace_repr_go_convert_source_text_off__1114000532_A_New_O(p0 any) *A_arbace_repr_go_convert_source_text_off__1114000532_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_off__1114000532_A{}; t.Ctor_O(p0); return t }
//line :1436:1
func (t *A_arbace_repr_go_convert_source_text_off__1114000532_A) Ctor_O(c__starts any) { t.F_starts = c__starts }
//line :1436:1
func (t *A_arbace_repr_go_convert_source_text_off__1114000532_A) Invoke_O_O__O(self, p__1114000531__1 any) any { var vec__1114000533__2 any = p__1114000531__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000533__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000533__2, lang.RT_IntCast_J__I(1), nil); var tmp1 any = t.F_starts; return lang.Numbers_Add_J_O__Number(lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(l__3)))), lang.Numbers_Dec_O__Number(c__4)) }
func A_arbace_repr_go_convert_source_text_text__1114000537_A_New_O(p0 any) *A_arbace_repr_go_convert_source_text_text__1114000537_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_text__1114000537_A{}; t.Ctor_O(p0); return t }
//line :1437:1
func (t *A_arbace_repr_go_convert_source_text_text__1114000537_A) Ctor_O(c__bs any) { t.F_bs = c__bs }
//line :1437:1
func (t *A_arbace_repr_go_convert_source_text_text__1114000537_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var tmp1 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); return jrt.String_New_B1_I_I_Charset(tmp1, lang.RT_IntCast_O__I(a__1), lang.RT_IntCast_O__I(lang.Numbers_Minus_O_O__Number(b__2, a__1)), jrt.StandardCharsets_UTF_8) }
func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A) Ctor_O_O_I_O(c__text, c__off any, c__n int32, c__bs any) { t.F_text = c__text; t.F_off = c__off; t.F_n = c__n; t.F_bs = c__bs }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A) Invoke_O_O__O(self, s__1114000540__1 any) any { var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A_New_O_O_O_I_O_O(t.F_text, self, t.F_off, t.F_n, t.F_bs, s__1114000540__1); var tmp2 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_199, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A_fn_class = fncls__112d; tmp2 = fncls__112d } else { tmp2 = fncls__112 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1438:1
func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A) Ctor_O_O_O_I_O_O(c__text, c__iter__1114000539, c__off any, c__n int32, c__bs, c__s__1114000540 any) { t.F_text = c__text; t.F_iter__1114000539 = c__iter__1114000539; t.F_off = c__off; t.F_n = c__n; t.F_bs = c__bs; t.F_s__1114000540 = c__s__1114000540 }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A) Invoke_O__O(self any) any { { var s__1114000540__1 any; var t_ any = t.F_s__1114000540; t.F_s__1114000540 = nil; s__1114000540__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000540__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var g__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A_New_O_O_I_O(t.F_text, t.F_off, t.F_n, t.F_bs); var tmp2 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_200, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A_fn_class = fncls__111d; tmp2 = fncls__111d } else { tmp2 = fncls__111 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_repr_go_convert_A_const_72.Invoke_O__O(g__4))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000539); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000540__1))) } else { s__1114000540__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000540__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :1438:1
func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A) Ctor_O_O_I_O(c__text, c__off any, c__n int32, c__bs any) { t.F_text = c__text; t.F_off = c__off; t.F_n = c__n; t.F_bs = c__bs }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A) Invoke_O_O__O(self, s__1114000542__1 any) any { var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A_New_O_O_I_O_O_O(t.F_text, t.F_off, t.F_n, t.F_bs, s__1114000542__1, self); var tmp2 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A_fn_class; if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_201, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A_fn_class = fncls__110d; tmp2 = fncls__110d } else { tmp2 = fncls__110 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1438:1
func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A_New_O_O_I_O_O_O(p0, p1 any, p2 int32, p3, p4, p5 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A{}; t.Ctor_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A) Ctor_O_O_I_O_O_O(c__text, c__off any, c__n int32, c__bs, c__s__1114000542, c__iter__1114000541 any) { t.F_text = c__text; t.F_off = c__off; t.F_n = c__n; t.F_bs = c__bs; t.F_s__1114000542 = c__s__1114000542; t.F_iter__1114000541 = c__iter__1114000541 }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A) Invoke_O__O(self any) any { { var s__1114000542__1 any; var t_ any = t.F_s__1114000542; t.F_s__1114000542 = nil; s__1114000542__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000542__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000542__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000542__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000542__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000544__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A_New_O_O_O_I_O_I_O(b__1114000544__6, t.F_text, t.F_off, t.F_n, t.F_bs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_202, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A_fn_class = fncls__107d; tmp2 = fncls__107d } else { tmp2 = fncls__107 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000541); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000544__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000542__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000544__6), nil) } } else { var vec__1114000561__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000542__3); var p__5 any = lang.RT_Nth_O_I_O__O(vec__1114000561__4, lang.RT_IntCast_J__I(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O(vec__1114000561__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp5 lang.IPersistentVector; var vec__1114000564__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(p__5); var l__8 any = lang.RT_Nth_O_I_O__O(vec__1114000564__7, lang.RT_IntCast_J__I(0), nil); var c__9 any = lang.RT_Nth_O_I_O__O(vec__1114000564__7, lang.RT_IntCast_J__I(1), nil); var lc__10 any = vec__1114000564__7; var o__11 any = lang.IFn_Cast(t.F_off).Invoke_O__O(lc__10); var e__12 any


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(t__6, Lit_203)) { var e__12_2 any; var tmp6 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A_New_O_I_O(o__11, t.F_n, t.F_bs); var tmp7 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A_fn_class
		if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_204, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A_fn_class = fncls__108d; tmp7 = fncls__108d } else { tmp7 = fncls__108 }; e__12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
		var tmp8 bool; var and__1927000168__auto____13 bool = lang.Numbers_Gt_O_O__Z(e__12_2, o__11); if and__1927000168__auto____13 { var tmp9 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp8 = lang.Numbers_Equiv_J_J__Z(13, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp9, lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(e__12_2)))).Ref())) } else { tmp8 = and__1927000168__auto____13 }; if tmp8 { e__12 = lang.Numbers_Dec_O__Number(e__12_2) } else { e__12 = e__12_2 } } else {
			var tmp10 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A_New_O_I_O(o__11, t.F_n, t.F_bs); var tmp11 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_205, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A_fn_class = fncls__109d; tmp11 = fncls__109d } else { tmp11 = fncls__109 }; e__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O() }
//line :1438:1
	tmp5 = lang.Tuple_Create_O_O_O__IPersistentVector(l__8, c__9, lang.IFn_Cast(t.F_text).Invoke_O_O__O(o__11, e__12)); var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1114000541); return tmp4.Invoke_O_O__O(tmp5, tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000542__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1438:1
func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A_New_O_O_O_I_O_I_O(p0, p1, p2 any, p3 int32, p4 any, p5 int32, p6 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A{}; t.Ctor_O_O_O_I_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A) Ctor_O_O_O_I_O_I_O(c__b__1114000544, c__text, c__off any, c__n int32, c__bs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000544 = c__b__1114000544; t.F_text = c__text; t.F_off = c__off; t.F_n = c__n; t.F_bs = c__bs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1438:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A) Invoke_O__O(self any) any { { var i__1114000543__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000543__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1114000550__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000543__1)); var p__3 any = lang.RT_Nth_O_I_O__O(vec__1114000550__2, lang.RT_IntCast_J__I(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O(vec__1114000550__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000544; var tmp4 lang.IPersistentVector; var vec__1114000553__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(p__3); var l__6 any = lang.RT_Nth_O_I_O__O(vec__1114000553__5, lang.RT_IntCast_J__I(0), nil); var c__7 any = lang.RT_Nth_O_I_O__O(vec__1114000553__5, lang.RT_IntCast_J__I(1), nil); var lc__8 any = vec__1114000553__5; var o__9 any = lang.IFn_Cast(t.F_off).Invoke_O__O(lc__8); var e__10 any


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(t__4, Lit_203)) { var e__10_2 any; var tmp5 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A_New_O_I_O(o__9, t.F_n, t.F_bs); var tmp6 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A_fn_class
		if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_206, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A_fn_class = fncls__105d; tmp6 = fncls__105d } else { tmp6 = fncls__105 }; e__10_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
		var tmp7 bool; var and__1927000168__auto____11 bool = lang.Numbers_Gt_O_O__Z(e__10_2, o__9); if and__1927000168__auto____11 { var tmp8 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp7 = lang.Numbers_Equiv_J_J__Z(13, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp8, lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(e__10_2)))).Ref())) } else { tmp7 = and__1927000168__auto____11 }; if tmp7 { e__10 = lang.Numbers_Dec_O__Number(e__10_2) } else { e__10 = e__10_2 } } else {
			var tmp9 any = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A_New_O_I_O(o__9, t.F_n, t.F_bs); var tmp10 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_207, false); A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A_fn_class = fncls__106d; tmp10 = fncls__106d } else { tmp10 = fncls__106 }; e__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O() }
//line :1438:1
	tmp4 = lang.Tuple_Create_O_O_O__IPersistentVector(l__6, c__7, lang.IFn_Cast(t.F_text).Invoke_O_O__O(o__9, e__10)); tmp2.Invoke_O_O__O(tmp3, tmp4); i__1114000543__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000543__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1442:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A) Ctor_O_I_O(c__o any, c__n int32, c__bs any) { t.F_o = c__o; t.F_n = c__n; t.F_bs = c__bs }
//line :1442:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_o; t.F_o = nil; j__1 = t_; L1: for { var tmp1 any; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(t.F_n)); if and__1927000168__auto____2 { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_535; var tmp4 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp1 = tmp2.Invoke_O_O__O(tmp3, jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp4, lang.RT_IntCast_O__I(j__1))).Ref()) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }
//line :1442:1
func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1442:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A) Ctor_O_I_O(c__o any, c__n int32, c__bs any) { t.F_o = c__o; t.F_n = c__n; t.F_bs = c__bs }
//line :1442:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_o; t.F_o = nil; j__1 = t_; L1: for { var tmp1 any; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(t.F_n)); if and__1927000168__auto____2 { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_535; var tmp4 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp1 = tmp2.Invoke_O_O__O(tmp3, jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp4, lang.RT_IntCast_O__I(j__1))).Ref()) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1444:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A) Ctor_O_I_O(c__o any, c__n int32, c__bs any) { t.F_o = c__o; t.F_n = c__n; t.F_bs = c__bs }
//line :1444:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any; var t_ any = t.F_o; t.F_o = nil; tmp1 = t_; j__1 = lang.Numbers_Add_O_J__Number(tmp1, 2); L1: for {
																									if lang.Numbers_Gte_O_J__Z(lang.Numbers_Inc_O__Number(j__1), int64(t.F_n)) { return jrt.Integer_ValueOf_I__Integer(t.F_n).Ref() } else { var tmp2 bool; var tmp3 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); var and__1927000168__auto____2 bool = lang.Numbers_Equiv_J_J__Z(42, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp3, lang.RT_IntCast_O__I(j__1))).Ref()))
																										if and__1927000168__auto____2 { var tmp4 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp2 = lang.Numbers_Equiv_J_J__Z(47, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp4, lang.RT_IntCast_O__I(lang.Numbers_Inc_O__Number(j__1)))).Ref())) } else { tmp2 = and__1927000168__auto____2 }
//line :1445:1
		if tmp2 {
			return lang.Numbers_Add_O_J__Number(j__1, 2) } else {
//line :1445:1
				if A_arbace_repr_go_convert_A_const_152 != nil {

					j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else {
//line :1445:1
						return nil } } } } }; /*line :1444:1*/panic("j2g: unreachable") }
//line :1444:1
func A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1444:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A) Ctor_O_I_O(c__o any, c__n int32, c__bs any) { t.F_o = c__o; t.F_n = c__n; t.F_bs = c__bs }
//line :1444:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any; var t_ any = t.F_o; t.F_o = nil; tmp1 = t_; j__1 = lang.Numbers_Add_O_J__Number(tmp1, 2); L1: for {
																							if lang.Numbers_Gte_O_J__Z(lang.Numbers_Inc_O__Number(j__1), int64(t.F_n)) { return jrt.Integer_ValueOf_I__Integer(t.F_n).Ref() } else { var tmp2 bool; var tmp3 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); var and__1927000168__auto____2 bool = lang.Numbers_Equiv_J_J__Z(42, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp3, lang.RT_IntCast_O__I(j__1))).Ref()))
																								if and__1927000168__auto____2 { var tmp4 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp2 = lang.Numbers_Equiv_J_J__Z(47, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp4, lang.RT_IntCast_O__I(lang.Numbers_Inc_O__Number(j__1)))).Ref())) } else { tmp2 = and__1927000168__auto____2 }
//line :1445:1
		if tmp2 {
			return lang.Numbers_Add_O_J__Number(j__1, 2) } else {
//line :1445:1
				if A_arbace_repr_go_convert_A_const_152 != nil {

					j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else {
//line :1445:1
						return nil } } } } }; /*line :1444:1*/panic("j2g: unreachable") }




func A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A_New_O(p0 any) *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A{}; t.Ctor_O(p0); return t }
//line :1449:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A) Ctor_O(c__off any) { t.F_off = c__off }
//line :1449:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A) Invoke_O_O__O(self, s__1114000576__1 any) any { var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A_New_O_O_O(t.F_off, s__1114000576__1, self); var tmp2 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_208, false); A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A_fn_class = fncls__115d; tmp2 = fncls__115d } else { tmp2 = fncls__115 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1449:1
func A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1449:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A) Ctor_O_O_O(c__off, c__s__1114000576, c__iter__1114000575 any) { t.F_off = c__off; t.F_s__1114000576 = c__s__1114000576; t.F_iter__1114000575 = c__iter__1114000575 }
//line :1449:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A) Invoke_O__O(self any) any { { var s__1114000576__1 any; var t_ any = t.F_s__1114000576; t.F_s__1114000576 = nil; s__1114000576__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000576__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000576__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000576__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000576__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000578__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A_New_O_O_I_O(b__1114000578__6, t.F_off, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_209, false); A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A_fn_class = fncls__114d; tmp2 = fncls__114d } else { tmp2 = fncls__114 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000575); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000578__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000576__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000578__6), nil) } } else { var vec__1114000586__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000576__3); var l__5 any = lang.RT_Nth_O_I_O__O(vec__1114000586__4, lang.RT_IntCast_J__I(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O(vec__1114000586__4, lang.RT_IntCast_J__I(1), nil); var t__7 any = lang.RT_Nth_O_I_O__O(vec__1114000586__4, lang.RT_IntCast_J__I(2), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp5 lang.IPersistentVector; var tmp6 lang.IFn = lang.IFn_Cast(t.F_off); var o__8 any = tmp6.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__5, c__6)); tmp5 = lang.Tuple_Create_O_O__IPersistentVector(o__8, lang.Numbers_Add_O_J__Number(o__8, int64(lang.RT_Count_O__I(jrt.NN(jrt.String_Cast(t__7)).GetBytes_String__B1(Lit_210).Ref())))); var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1114000575); return tmp4.Invoke_O_O__O(tmp5, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000576__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1449:1
func A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1449:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A) Ctor_O_O_I_O(c__b__1114000578, c__off any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000578 = c__b__1114000578; t.F_off = c__off; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1449:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A) Invoke_O__O(self any) any { { var i__1114000577__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000577__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1114000582__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000577__1)); var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000582__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000582__2, lang.RT_IntCast_J__I(1), nil); var t__5 any = lang.RT_Nth_O_I_O__O(vec__1114000582__2, lang.RT_IntCast_J__I(2), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000578; var tmp4 lang.IPersistentVector; var tmp5 lang.IFn = lang.IFn_Cast(t.F_off); var o__6 any = tmp5.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4)); tmp4 = lang.Tuple_Create_O_O__IPersistentVector(o__6, lang.Numbers_Add_O_J__Number(o__6, int64(lang.RT_Count_O__I(jrt.NN(jrt.String_Cast(t__5)).GetBytes_String__B1(Lit_210).Ref())))); tmp2.Invoke_O_O__O(tmp3, tmp4); i__1114000577__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000577__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A_New_O(p0 any) *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A{}; t.Ctor_O(p0); return t }
//line :1451:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A) Ctor_O(c__off any) { t.F_off = c__off }
//line :1451:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A) Invoke_O_O__O(self, s__1114000592__1 any) any { var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A_New_O_O_O(t.F_off, s__1114000592__1, self); var tmp2 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_211, false); A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A_fn_class = fncls__118d; tmp2 = fncls__118d } else { tmp2 = fncls__118 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1451:1
func A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1451:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A) Ctor_O_O_O(c__off, c__s__1114000592, c__iter__1114000591 any) { t.F_off = c__off; t.F_s__1114000592 = c__s__1114000592; t.F_iter__1114000591 = c__iter__1114000591 }
//line :1451:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A) Invoke_O__O(self any) any { { var s__1114000592__1 any; var t_ any = t.F_s__1114000592; t.F_s__1114000592 = nil; s__1114000592__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000592__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000592__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000592__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000592__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000594__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A_New_O_I_O_O(t.F_off, size__1927001038__auto____5, c__1927001037__auto____4, b__1114000594__6); var tmp2 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_212, false); A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A_fn_class = fncls__117d; tmp2 = fncls__117d } else { tmp2 = fncls__117 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000591); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000594__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000592__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000594__6), nil) } } else { var vec__1114000602__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000592__3); var a__5 any = lang.RT_Nth_O_I_O__O(vec__1114000602__4, lang.RT_IntCast_J__I(0), nil); var b__6 any = lang.RT_Nth_O_I_O__O(vec__1114000602__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1114000591); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(t.F_off).Invoke_O__O(a__5), lang.IFn_Cast(t.F_off).Invoke_O__O(b__6)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000592__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1451:1
func A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1451:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A) Ctor_O_I_O_O(c__off any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1114000594 any) { t.F_off = c__off; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1114000594 = c__b__1114000594 }
//line :1451:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A) Invoke_O__O(self any) any { { var i__1114000593__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000593__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1114000598__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000593__1)); var a__3 any = lang.RT_Nth_O_I_O__O(vec__1114000598__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1114000598__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000594; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(t.F_off).Invoke_O__O(a__3), lang.IFn_Cast(t.F_off).Invoke_O__O(b__4))); i__1114000593__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000593__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_convert_source_text_fn__1114000607_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_convert_source_text_fn__1114000607_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_fn__1114000607_A{}; t.Ctor_I_O(p0, p1); return t }
//line :1452:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000607_A) Ctor_I_O(c__n int32, c__bs any) { t.F_n = c__n; t.F_bs = c__bs }
//line :1452:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000607_A) Invoke_O__O(self any) any { { var j__1 int64 = lang.RT_LongCast_I__J(t.F_n); L1: for { var tmp1 any; var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z(j__1); if and__1927000168__auto____2 { var tmp2 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); var b__3 int8 = lang.RT_Aget_B1_I__B(tmp2, lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(j__1))); var or__1927000174__auto____4 bool = lang.Numbers_Equiv_J_J__Z(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(b__3).Ref()), 10); if or__1927000174__auto____4 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_527.GetRawRoot__O()).Invoke_O__O(jrt.Byte_ValueOf_B__Byte(b__3).Ref()) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
												j__1 = lang.Numbers_Dec_J__J(j__1); continue L1 } else {
//line :1452:1
		return jrt.Long_ValueOf_J__Long(j__1).Ref() } } }; panic("j2g: unreachable") }











func A_arbace_repr_go_convert_source_text_fn__1114000629_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_repr_go_convert_source_text_fn__1114000629_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_fn__1114000629_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :1464:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000629_A) Ctor_O_O_J(c__bs, c__i any, c__ob int64) { t.F_bs = c__bs; t.F_i = c__i; t.F_ob = c__ob }
//line :1464:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000629_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; var k__2 int64 = 0; var last__3 any = lang.RT_Box_J__Number(-1); L1: for { if lang.Numbers_Lt_O_J__Z(j__1, t.F_ob) { var tmp1 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); if lang.Numbers_Equiv_J_J__Z(10, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp1, lang.RT_IntCast_O__I(j__1))).Ref())) { j__1, k__2, last__3 = lang.Numbers_Inc_O__Number(j__1), lang.Numbers_Inc_J__J(k__2), j__1; continue L1 } else { j__1, k__2, last__3 = lang.Numbers_Inc_O__Number(j__1), k__2, last__3; continue L1 } } else { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(k__2).Ref(), last__3) } } }; panic("j2g: unreachable") }





func A_arbace_repr_go_convert_source_text_fn__1114000631_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_source_text_fn__1114000631_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_fn__1114000631_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1470:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000631_A) Ctor_O_O_O(c__bs, c__lim, c__i any) { t.F_bs = c__bs; t.F_lim = c__lim; t.F_i = c__i }
//line :1470:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000631_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 any; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_O__Z(j__1, t.F_lim); if and__1927000168__auto____2 { var tmp2 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_527.GetRawRoot__O()).Invoke_O__O(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp2, lang.RT_IntCast_O__I(j__1))).Ref()) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_convert_source_text_fn__1114000633_A_New() *A_arbace_repr_go_convert_source_text_fn__1114000633_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_fn__1114000633_A{}; t.Ctor(); return t }
//line :1475:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000633_A) Ctor() {}
//line :1475:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000633_A) Invoke_O_O__O(self, p1__1114000527_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(p1__1114000527_SHARP___1, A_arbace_repr_go_convert_A_const_536)).Ref() }
func A_arbace_repr_go_convert_source_text_fn__1114000635_A_New() *A_arbace_repr_go_convert_source_text_fn__1114000635_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_fn__1114000635_A{}; t.Ctor(); return t }
//line :1476:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000635_A) Ctor() {}
//line :1476:1
func (t *A_arbace_repr_go_convert_source_text_fn__1114000635_A) Invoke_O_O__O(self, p1__1114000528_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(p1__1114000528_SHARP___1, A_arbace_repr_go_convert_A_const_537)).Ref() }








func A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A_New_O(p0 any) *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A{}; t.Ctor_O(p0); return t }
//line :1485:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A) Ctor_O(c__off any) { t.F_off = c__off }
//line :1485:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A) Invoke_O_O__O(self, s__1114000638__1 any) any { var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A_New_O_O_O(s__1114000638__1, self, t.F_off); var tmp2 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_213, false); A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A_fn_class = fncls__125d; tmp2 = fncls__125d } else { tmp2 = fncls__125 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1485:1
func A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1485:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A) Ctor_O_O_O(c__s__1114000638, c__iter__1114000637, c__off any) { t.F_s__1114000638 = c__s__1114000638; t.F_iter__1114000637 = c__iter__1114000637; t.F_off = c__off }
//line :1485:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A) Invoke_O__O(self any) any { { var s__1114000638__1 any; var t_ any = t.F_s__1114000638; t.F_s__1114000638 = nil; s__1114000638__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000638__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000638__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000638__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000638__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000640__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A_New_O_O_I_O(b__1114000640__6, t.F_off, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_214, false); A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A_fn_class = fncls__124d; tmp2 = fncls__124d } else { tmp2 = fncls__124 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000637); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000640__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000638__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000640__6), nil) } } else { var vec__1114000648__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000638__3); var l__5 any = lang.RT_Nth_O_I_O__O(vec__1114000648__4, lang.RT_IntCast_J__I(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O(vec__1114000648__4, lang.RT_IntCast_J__I(1), nil); var t__7 any = lang.RT_Nth_O_I_O__O(vec__1114000648__4, lang.RT_IntCast_J__I(2), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp5 lang.IPersistentVector; var tmp6 lang.IFn = lang.IFn_Cast(t.F_off); var o__8 any = tmp6.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__5, c__6)); tmp5 = lang.Tuple_Create_O_O__IPersistentVector(o__8, lang.Numbers_Add_O_J__Number(o__8, int64(lang.RT_Count_O__I(jrt.NN(jrt.String_Cast(t__7)).GetBytes_String__B1(Lit_210).Ref())))); var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1114000637); return tmp4.Invoke_O_O__O(tmp5, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000638__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1485:1
func A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1485:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A) Ctor_O_O_I_O(c__b__1114000640, c__off any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000640 = c__b__1114000640; t.F_off = c__off; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1485:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A) Invoke_O__O(self any) any { { var i__1114000639__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000639__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1114000644__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000639__1)); var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000644__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000644__2, lang.RT_IntCast_J__I(1), nil); var t__5 any = lang.RT_Nth_O_I_O__O(vec__1114000644__2, lang.RT_IntCast_J__I(2), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000640; var tmp4 lang.IPersistentVector; var tmp5 lang.IFn = lang.IFn_Cast(t.F_off); var o__6 any = tmp5.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4)); tmp4 = lang.Tuple_Create_O_O__IPersistentVector(o__6, lang.Numbers_Add_O_J__Number(o__6, int64(lang.RT_Count_O__I(jrt.NN(jrt.String_Cast(t__5)).GetBytes_String__B1(Lit_210).Ref())))); tmp2.Invoke_O_O__O(tmp3, tmp4); i__1114000639__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000639__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1487:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A) Ctor_O_I_O(c__cstarts any, c__n int32, c__bs any) { t.F_cstarts = c__cstarts; t.F_n = c__n; t.F_bs = c__bs }
//line :1487:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A) Invoke_O_O__O(self, s__1114000654__1 any) any { var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A_New_O_I_O_O_O(t.F_cstarts, t.F_n, t.F_bs, s__1114000654__1, self); var tmp2 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_215, false); A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A_fn_class = fncls__130d; tmp2 = fncls__130d } else { tmp2 = fncls__130 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1487:1
func A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A_New_O_I_O_O_O(p0 any, p1 int32, p2, p3, p4 any) *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A{}; t.Ctor_O_I_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1487:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A) Ctor_O_I_O_O_O(c__cstarts any, c__n int32, c__bs, c__s__1114000654, c__iter__1114000653 any) { t.F_cstarts = c__cstarts; t.F_n = c__n; t.F_bs = c__bs; t.F_s__1114000654 = c__s__1114000654; t.F_iter__1114000653 = c__iter__1114000653 }
//line :1487:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A) Invoke_O__O(self any) any { { var s__1114000654__1 any; var t_ any = t.F_s__1114000654; t.F_s__1114000654 = nil; s__1114000654__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000654__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000654__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000654__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000654__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000656__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A_New_O_O_I_O_I_O(t.F_cstarts, b__1114000656__6, t.F_n, t.F_bs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_216, false); A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A_fn_class = fncls__128d; tmp2 = fncls__128d } else { tmp2 = fncls__128 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000653); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000656__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000654__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000656__6), nil) } } else { var vec__1114000666__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000654__3); var o__5 any = lang.RT_Nth_O_I_O__O(vec__1114000666__4, lang.RT_IntCast_J__I(0), nil); var l__6 any = lang.RT_Nth_O_I_O__O(vec__1114000666__4, lang.RT_IntCast_J__I(1), nil); var c__7 any = lang.RT_Nth_O_I_O__O(vec__1114000666__4, lang.RT_IntCast_J__I(2), nil); var nx__8 any; var tmp4 any = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A_New_O_I_O_O(t.F_cstarts, t.F_n, o__5, t.F_bs); var tmp5 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A_fn_class
															if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_217, false); A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A_fn_class = fncls__129d; tmp5 = fncls__129d } else { tmp5 = fncls__129 }; nx__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :1487:1
	var tmp6 any
	var and__1927000168__auto____9 any = nx__8





	if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 bool = lang.Numbers_Equiv_O_J__Z(nx__8, 41); if or__1927000174__auto____10 { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____10).Ref() } else { var or__1927000174__auto____11 bool = lang.Numbers_Equiv_O_J__Z(nx__8, 93); if or__1927000174__auto____11 { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11).Ref() } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_O_J__Z(nx__8, 125)).Ref() } } } else { tmp6 = and__1927000168__auto____9 }
//line :1487:1
	if jrt.J2g_Truth(tmp6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1114000653); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__6, c__7), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000654__3))) } else { s__1114000654__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000654__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1487:1
func A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A_New_O_O_I_O_I_O(p0, p1 any, p2 int32, p3 any, p4 int32, p5 any) *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A{}; t.Ctor_O_O_I_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :1487:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A) Ctor_O_O_I_O_I_O(c__cstarts, c__b__1114000656 any, c__n int32, c__bs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_cstarts = c__cstarts; t.F_b__1114000656 = c__b__1114000656; t.F_n = c__n; t.F_bs = c__bs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1487:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A) Invoke_O__O(self any) any { { var i__1114000655__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000655__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1114000660__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000655__1)); var o__3 any = lang.RT_Nth_O_I_O__O(vec__1114000660__2, lang.RT_IntCast_J__I(0), nil); var l__4 any = lang.RT_Nth_O_I_O__O(vec__1114000660__2, lang.RT_IntCast_J__I(1), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__1114000660__2, lang.RT_IntCast_J__I(2), nil); var nx__6 any; var tmp2 any = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A_New_O_I_O_O(t.F_cstarts, t.F_n, o__3, t.F_bs); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A_fn_class
																	if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_218, false); A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; nx__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :1487:1
	var tmp4 any
	var and__1927000168__auto____7 any = nx__6





	if jrt.J2g_Truth(and__1927000168__auto____7) { var or__1927000174__auto____8 bool = lang.Numbers_Equiv_O_J__Z(nx__6, 41); if or__1927000174__auto____8 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { var or__1927000174__auto____9 bool = lang.Numbers_Equiv_O_J__Z(nx__6, 93); if or__1927000174__auto____9 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____9).Ref() } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_O_J__Z(nx__6, 125)).Ref() } } } else { tmp4 = and__1927000168__auto____7 }
//line :1487:1
	if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp6 any = t.F_b__1114000656; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5)); i__1114000655__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000655__1); continue L1 } else { i__1114000655__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000655__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1488:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A) Ctor_O_I_O_O(c__cstarts any, c__n int32, c__o, c__bs any) { t.F_cstarts = c__cstarts; t.F_n = c__n; t.F_o = c__o; t.F_bs = c__bs }
//line :1488:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A) Invoke_O__O(self any) any { { var j__1 int64; var tmp1 any; var t_ any = t.F_o; t.F_o = nil; tmp1 = t_; j__1 = lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(tmp1)); L1: for {
																			if lang.Numbers_Gte_J_J__Z(j__1, int64(t.F_n)) { return nil } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_cstarts); if jrt.J2g_Truth(tmp2.Invoke_O__O(jrt.Long_ValueOf_J__Long(j__1).Ref())) {

		var tmp3 lang.IFn = lang.IFn_Cast(t.F_cstarts); j__1 = lang.RT_LongCast_O__J(tmp3.Invoke_O__O(jrt.Long_ValueOf_J__Long(j__1).Ref())); continue L1 } else {
//line :1489:1
			var tmp4 any; var tmp5 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); var or__1927000174__auto____2 bool = lang.Numbers_Equiv_J_J__Z(10, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp5, lang.RT_IntCast_J__I(j__1))).Ref()))


			if or__1927000174__auto____2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var tmp6 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_527.GetRawRoot__O()).Invoke_O__O(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp6, lang.RT_IntCast_J__I(j__1))).Ref()) }
//line :1489:1
			if jrt.J2g_Truth(tmp4) {


				j__1 = lang.Numbers_Inc_J__J(j__1); continue L1 } else {
//line :1489:1
					if A_arbace_repr_go_convert_A_const_152 != nil {



						var tmp7 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); return jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp7, lang.RT_IntCast_J__I(j__1))).Ref() } else {
//line :1489:1
							return nil } } } } } }; /*line :1488:1*/panic("j2g: unreachable") }
//line :1488:1
func A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1488:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A) Ctor_O_I_O_O(c__cstarts any, c__n int32, c__o, c__bs any) { t.F_cstarts = c__cstarts; t.F_n = c__n; t.F_o = c__o; t.F_bs = c__bs }
//line :1488:1
func (t *A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A) Invoke_O__O(self any) any { { var j__1 int64; var tmp1 any; var t_ any = t.F_o; t.F_o = nil; tmp1 = t_; j__1 = lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(tmp1)); L1: for {
																	if lang.Numbers_Gte_J_J__Z(j__1, int64(t.F_n)) { return nil } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_cstarts); if jrt.J2g_Truth(tmp2.Invoke_O__O(jrt.Long_ValueOf_J__Long(j__1).Ref())) {

		var tmp3 lang.IFn = lang.IFn_Cast(t.F_cstarts); j__1 = lang.RT_LongCast_O__J(tmp3.Invoke_O__O(jrt.Long_ValueOf_J__Long(j__1).Ref())); continue L1 } else {
//line :1489:1
			var tmp4 any; var tmp5 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); var or__1927000174__auto____2 bool = lang.Numbers_Equiv_J_J__Z(10, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp5, lang.RT_IntCast_J__I(j__1))).Ref()))


			if or__1927000174__auto____2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var tmp6 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); tmp4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_527.GetRawRoot__O()).Invoke_O__O(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp6, lang.RT_IntCast_J__I(j__1))).Ref()) }
//line :1489:1
			if jrt.J2g_Truth(tmp4) {


				j__1 = lang.Numbers_Inc_J__J(j__1); continue L1 } else {
//line :1489:1
					if A_arbace_repr_go_convert_A_const_152 != nil {



						var tmp7 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); return jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp7, lang.RT_IntCast_J__I(j__1))).Ref() } else {
//line :1489:1
							return nil } } } } } }; /*line :1488:1*/panic("j2g: unreachable") }










func A_arbace_repr_go_convert_basic_lit_extents_A_New() *A_arbace_repr_go_convert_basic_lit_extents_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_basic_lit_extents_A{}; t.Ctor(); return t }
//line :1499:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_A) Ctor() {}
//line :1499:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_A) Invoke_O_O__O(self, ast__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A_New(); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A_fn_class; if
												fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_540.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_A_const_541.GetRawRoot__O(); var tmp6 any = A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A_New(); var tmp7 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A_fn_class = fncls__135d; tmp7 = fncls__135d } else { tmp7 = fncls__135 }; return tmp3.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), ast__0)) }
//line :1500:1
func A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A_New() *A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A{}; t.Ctor(); return t }
//line :1500:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A) Ctor() {}
//line :1500:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A) Invoke_O_O__O(self, x__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(x__1)) { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_26.GetRawRoot__O()).Invoke_O__O(x__1) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(x__1) } }
//line :1500:1
func A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A_New() *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A{}; t.Ctor(); return t }
//line :1500:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A) Ctor() {}
//line :1500:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A) Invoke_O_O__O(self, s__1114000675__1 any) any { var tmp1 any = A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A_New_O_O(s__1114000675__1, self); var tmp2 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A_fn_class = fncls__133d; tmp2 = fncls__133d } else { tmp2 = fncls__133 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1500:1
func A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1500:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A) Ctor_O_O(c__s__1114000675, c__iter__1114000674 any) { t.F_s__1114000675 = c__s__1114000675; t.F_iter__1114000674 = c__iter__1114000674 }
//line :1500:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A) Invoke_O__O(self any) any { { var s__1114000675__1 any; var t_ any = t.F_s__1114000675; t.F_s__1114000675 = nil; s__1114000675__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000675__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000675__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000675__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000675__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000677__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A_New_O_I_O(b__1114000677__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A_fn_class = fncls__132d; tmp2 = fncls__132d } else { tmp2 = fncls__132 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000674); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000677__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000675__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000677__6), nil) } } else { var x__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000675__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(x__4)
																if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp5 any = A_arbace_repr_go_convert_A_const_109; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(x__4)); if and__1927000168__auto____6 { tmp4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(x__4)) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } } else { tmp4 = and__1927000168__auto____5 }
//line :1500:1
	if jrt.J2g_Truth(tmp4) { var map__1114000684__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(x__4); var map__1114000684__6 any; if lang.ISeq_InstanceOf(map__1114000684__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000684__5)) { map__1114000684__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000684__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000684__5)) { map__1114000684__6 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000684__5) } else { lang.PersistentArrayMap_Init(); map__1114000684__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000684__6 = map__1114000684__5 }; var value_pos__7 any = lang.RT_Get_O_O__O(map__1114000684__6, A_arbace_repr_go_convert_A_const_110); var value_end__8 any = lang.RT_Get_O_O__O(map__1114000684__6, A_arbace_repr_go_convert_A_const_539); var a__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(value_pos__7); var b__10 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(value_end__8); var tmp6 any
		var and__1927000168__auto____11 any = a__9


		if jrt.J2g_Truth(and__1927000168__auto____11) { tmp6 = b__10 } else { tmp6 = and__1927000168__auto____11 }
//line :1500:1
		if jrt.J2g_Truth(tmp6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1114000674); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(a__9, b__10), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000675__3))) } else { s__1114000675__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000675__3); continue L1 } } else { s__1114000675__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000675__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1500:1
func A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1500:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A) Ctor_O_I_O(c__b__1114000677 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000677 = c__b__1114000677; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1500:1
func (t *A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A) Invoke_O__O(self any) any { { var i__1114000676__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000676__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000676__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(x__2)
																		if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_repr_go_convert_A_const_109; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(x__2)); if and__1927000168__auto____4 { tmp2 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(x__2)) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp2 = and__1927000168__auto____3 }
//line :1500:1
	if jrt.J2g_Truth(tmp2) { var map__1114000681__3 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(x__2); var map__1114000681__4 any; if lang.ISeq_InstanceOf(map__1114000681__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000681__3)) { map__1114000681__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000681__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000681__3)) { map__1114000681__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000681__3) } else { lang.PersistentArrayMap_Init(); map__1114000681__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000681__4 = map__1114000681__3 }; var value_pos__5 any = lang.RT_Get_O_O__O(map__1114000681__4, A_arbace_repr_go_convert_A_const_110); var value_end__6 any = lang.RT_Get_O_O__O(map__1114000681__4, A_arbace_repr_go_convert_A_const_539); var a__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(value_pos__5); var b__8 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(value_end__6); var tmp4 any
		var and__1927000168__auto____9 any = a__7


		if jrt.J2g_Truth(and__1927000168__auto____9) { tmp4 = b__8 } else { tmp4 = and__1927000168__auto____9 }
//line :1500:1
		if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp6 any = t.F_b__1114000677; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(a__7, b__8)); i__1114000676__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000676__1); continue L1 } else { i__1114000676__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000676__1); continue L1 } } else { i__1114000676__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000676__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_repr_go_convert_convert_file_A_New() *A_arbace_repr_go_convert_convert_file_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_A{}; t.Ctor(); return t }
//line :1507:1
func (t *A_arbace_repr_go_convert_convert_file_A) Ctor() {}
//line :1507:1
func (t *A_arbace_repr_go_convert_convert_file_A) Invoke_O_O_O_O__O(self, dump__0, fe__1, ns_sym__2 any) any { var ast__4 any = A_arbace_repr_go_convert_A_const_542.Invoke_O__O(fe__1); var f__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(ast__4); var name__6 any = A_arbace_repr_go_convert_A_const_543.Invoke_O__O(fe__1); var groups__7 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;







	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____7 any; var tmp5 any = A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A_New(); var tmp6 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A_fn_class; if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A_fn_class = fncls__154d; tmp6 = fncls__154d } else { tmp6 = fncls__154 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(A_arbace_repr_go_convert_A_const_529.Invoke_O__O(fe__1)); groups__7 = tmp1.Invoke_O_O__O(tmp3, tmp4); var pkg_pos__8 any = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_553.Invoke_O__O(f__5)); var pkg_line__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(pkg_pos__8); var decls__10 any = A_arbace_repr_go_convert_A_const_544.Invoke_O__O(f__5); var dirs__11 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_545.GetRawRoot__O()).Invoke_O_O__O(dump__0, name__6); var ranges__12 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_170.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_convert_file_fn__1114000706_A_New(); var tmp9 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000706_A_fn_class; if












	fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_repr_go_convert_convert_file_fn__1114000706_A_fn_class = fncls__155d; tmp9 = fncls__155d } else { tmp9 = fncls__155 }; ranges__12 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), decls__10); var kept__13 any; var tmp10 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_347.GetRawRoot__O()); var tmp11 *lang.PersistentHashSet;













	lang.PersistentHashSet_Init(); tmp11 = lang.PersistentHashSet_EMPTY; kept__13 = tmp10.Invoke_O__O(tmp11.Ref()); var placed__14 any; var tmp12 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_347.GetRawRoot__O()); var tmp13 *lang.PersistentHashSet;














	lang.PersistentHashSet_Init(); tmp13 = lang.PersistentHashSet_EMPTY; placed__14 = tmp12.Invoke_O__O(tmp13.Ref()); var header__15 any; var tmp14 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_28.GetRawRoot__O()); var tmp15 any = A_arbace_repr_go_convert_convert_file_fn__1114000709_A_New_O(pkg_pos__8); var tmp16 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000709_A_fn_class; if















	fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_repr_go_convert_convert_file_fn__1114000709_A_fn_class = fncls__156d; tmp16 = fncls__156d } else { tmp16 = fncls__156 }; header__15 = tmp14.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), dirs__11); var body_dirs__16 any; var tmp17 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_420.GetRawRoot__O()); var tmp18 any = A_arbace_repr_go_convert_convert_file_fn__1114000715_A_New_O(pkg_pos__8); var tmp19 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000715_A_fn_class; if
















	fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_repr_go_convert_convert_file_fn__1114000715_A_fn_class = fncls__157d; tmp19 = fncls__157d } else { tmp19 = fncls__157 }; body_dirs__16 = tmp17.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil), dirs__11); var last_import__17 any; var tmp20 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_546.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_425.GetRawRoot__O()); var tmp22 any = A_arbace_repr_go_convert_convert_file_fn__1114000720_A_New_O(ranges__12); var tmp23 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000720_A_fn_class; if

















	fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_repr_go_convert_convert_file_fn__1114000720_A_fn_class = fncls__158d; tmp23 = fncls__158d } else { tmp23 = fncls__158 }; last_import__17 = tmp20.Invoke_O__O(tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), decls__10)); var inside_of__18 any; var tmp24 any = /*line :1507:1*/A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A_New_O(ranges__12); var tmp25 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A_fn_class; if




















	fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A_fn_class = fncls__137d; tmp25 = fncls__137d } else { tmp25 = fncls__137 }; inside_of__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var plan__19 any; var tmp26 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_421.GetRawRoot__O()); var tmp27 any = A_arbace_repr_go_convert_convert_file_fn__1114000735_A_New_O_O_O_O(inside_of__18, ranges__12, last_import__17, decls__10); var tmp28 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000735_A_fn_class; if


























	fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_repr_go_convert_convert_file_fn__1114000735_A_fn_class = fncls__161d; tmp28 = fncls__161d } else { tmp28 = fncls__161 }; var tmp29 any = /*line :1533:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var tmp30 any = A_arbace_repr_go_convert_A_const_549; var tmp31 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp31 = lang.PersistentArrayMap_EMPTY; var tmp32 any = tmp31.Ref(); var tmp33 any = A_arbace_repr_go_convert_A_const_562; var tmp34 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp34 = lang.PersistentArrayMap_EMPTY; var tmp35 any = tmp34.Ref(); var tmp36 any = A_arbace_repr_go_convert_A_const_570; var tmp37 *lang.PersistentVector; lang.PersistentVector_Init(); tmp37 = lang.PersistentVector_EMPTY; var tmp38 any = tmp37.Ref(); var tmp39 any = A_arbace_repr_go_convert_A_const_571; var tmp40 *lang.PersistentVector; lang.PersistentVector_Init(); tmp40 = lang.PersistentVector_EMPTY; plan__19 = tmp26.Invoke_O_O_O__O(tmp29, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp32, tmp33, tmp35, tmp36, tmp38, tmp39, tmp40.Ref())), body_dirs__16); var attach_meta__20 any; var tmp41 any = /*line :1507:1*/A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A_New_O_O(placed__14, plan__19); var tmp42 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A_fn_class; if





















































	fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A_fn_class = fncls__140d; tmp42 = fncls__140d } else { tmp42 = fncls__140 }; attach_meta__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil); var imports__21 any; var tmp43 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_572.GetRawRoot__O()); var tmp45 any = A_arbace_repr_go_convert_convert_file_fn__1114000758_A_New(); var tmp46 *jrt.Class; var fncls__162 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000758_A_fn_class; if


























































	fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_repr_go_convert_convert_file_fn__1114000758_A_fn_class = fncls__162d; tmp46 = fncls__162d } else { tmp46 = fncls__162 }; var tmp47 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp49 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_573.GetRawRoot__O()).Invoke_O__O(decls__10); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp51 any = A_arbace_repr_go_convert_convert_file_fn__1114000760_A_New_O(placed__14); var tmp52 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000760_A_fn_class; if

	fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_repr_go_convert_convert_file_fn__1114000760_A_fn_class = fncls__163d; tmp52 = fncls__163d } else { tmp52 = fncls__163 }; imports__21 = /*line :1566:1*/tmp43.Invoke_O__O(tmp44.Invoke_O_O__O(tmp47, tmp48.Invoke_O_O__O(tmp49, tmp50.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil), A_arbace_repr_go_convert_A_const_571.Invoke_O__O(plan__19))))); var doc__22 any = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_240.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_238.Invoke_O__O(f__5), groups__7); var file_form__23 any;































































	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_234, kept__13)); var tmp53 any = A_arbace_repr_go_convert_convert_file_fn__1114000762_A_New_O_O_O_O_O_O_O_O(f__5, doc__22, name__6, dump__0, imports__21, fe__1, header__15, pkg_line__9); var tmp54 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000762_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_repr_go_convert_convert_file_fn__1114000762_A_fn_class = fncls__145d; tmp54 = fncls__145d } else { tmp54 = fncls__145 }; file_form__23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil).Invoke__O(); var file_form__24 any; if













	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_148.Get__O())) { file_form__24 = file_form__23 } else { var src__24 any

		if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_557.Get__O()) { src__24 = jrt.File_New_String_String(jrt.String_Cast(A_arbace_repr_go_convert_A_const_557.Get__O()), jrt.String_Cast(name__6)) } else { src__24 = nil }
//line :1585:1
		var st__25 any; var tmp55 any
		var and__1927000168__auto____25 any = src__24

		if jrt.J2g_Truth(and__1927000168__auto____25) { tmp55 = jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(src__24)).IsFile__Z()).Ref() } else { tmp55 = and__1927000168__auto____25 }; if jrt.J2g_Truth(tmp55) {
			st__25 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_558.GetRawRoot__O()).Invoke_O_O_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(src__24)).ToPath__Path()).Ref(), A_arbace_repr_go_convert_A_const_529.Invoke_O__O(fe__1), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_574.GetRawRoot__O()).Invoke_O__O(ast__4)) } else {
//line :1588:1
				var tmp56 any = A_arbace_repr_go_convert_A_const_529; var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_534.GetRawRoot__O()); var tmp59 any; var iter__1927001039__auto____25 any; var tmp60 any = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A_New(); var tmp61 *jrt.Class
				var fncls__168 /*line :1588:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A_fn_class


				if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A_fn_class = fncls__168d; tmp61 = fncls__168d } else { tmp61 = fncls__168 }; iter__1927001039__auto____25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil); tmp59 = lang.IFn_Cast(iter__1927001039__auto____25).Invoke_O__O(A_arbace_repr_go_convert_A_const_529.Invoke_O__O(fe__1))
//line :1588:1
				var tmp62 any = tmp57.Invoke_O__O(tmp58.Invoke_O__O(tmp59)); var tmp63 any = A_arbace_repr_go_convert_A_const_533; var tmp64 *lang.PersistentVector; lang.PersistentVector_Init(); tmp64 = lang.PersistentVector_EMPTY; st__25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp56, tmp62, tmp63, tmp64.Ref(), A_arbace_repr_go_convert_A_const_350, Lit_45))
			}






		var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_204.GetRawRoot__O()); var tmp66 any = A_arbace_repr_go_convert_A_const_553; var tmp67 any = A_arbace_repr_go_convert_A_const_553.Invoke_O__O(f__5); var tmp68 any = A_arbace_repr_go_convert_A_const_49; var tmp69 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_261.GetRawRoot__O()).Invoke_O_O__O(file_form__23, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp66, tmp67, tmp68, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_49.Invoke_O__O(f__5))))); var tmp70 any; var tmp71 any = A_arbace_repr_go_convert_A_const_575; var G__1114000800__26_ any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp71, A_arbace_repr_go_convert_A_const_529.Invoke_O__O(st__25))); var G__1114000800__27_ any; if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_530.Invoke_O__O(st__25)) {
			var tmp72 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp73 any = A_arbace_repr_go_convert_A_const_576; G__1114000800__27_ = tmp72.Invoke_O_O_O__O(G__1114000800__26_, tmp73, A_arbace_repr_go_convert_A_const_530.Invoke_O__O(st__25)) } else {
//line :1596:1
				G__1114000800__27_ = G__1114000800__26_ }; var G__1114000800__28_ any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_532.Invoke_O__O(st__25))) {

					var tmp74 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp75 any = A_arbace_repr_go_convert_A_const_577; G__1114000800__28_ = tmp74.Invoke_O_O_O__O(G__1114000800__27_, tmp75, A_arbace_repr_go_convert_A_const_532.Invoke_O__O(st__25)) } else {
//line :1596:1
						G__1114000800__28_ = G__1114000800__27_ }; var G__1114000800__29_ any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_533.Invoke_O__O(st__25))) {


							var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp77 any = A_arbace_repr_go_convert_A_const_578; G__1114000800__29_ = tmp76.Invoke_O_O_O__O(G__1114000800__28_, tmp77, A_arbace_repr_go_convert_A_const_533.Invoke_O__O(st__25)) } else {
//line :1596:1
								G__1114000800__29_ = G__1114000800__28_ }; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(Lit_45, A_arbace_repr_go_convert_A_const_350.Invoke_O__O(st__25))) {



									var tmp78 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp79 any = A_arbace_repr_go_convert_A_const_579; tmp70 = tmp78.Invoke_O_O_O__O(G__1114000800__29_, tmp79, A_arbace_repr_go_convert_A_const_350.Invoke_O__O(st__25)) } else {
//line :1596:1
										tmp70 = G__1114000800__29_ }; file_form__24 = tmp65.Invoke_O_O__O(tmp69, tmp70) }; var ___25 any; var tmp80 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()); var tmp81 any = A_arbace_repr_go_convert_A_const_126.GetRawRoot__O(); var tmp82 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp83 any = A_arbace_repr_go_convert_convert_file_fn__1114000802_A_New(); var tmp84 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000802_A_fn_class; _ = ___25; if





























































































	fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_repr_go_convert_convert_file_fn__1114000802_A_fn_class = fncls__169d; tmp84 = fncls__169d } else { tmp84 = fncls__169 }; ___25 = tmp80.Invoke_O_O_O__O(placed__14, tmp81, tmp82.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp83, tmp84, nil), header__15)); var decl_forms__26 any; var tmp85 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()); var tmp86 any = A_arbace_repr_go_convert_A_const_248; var tmp87 any = A_arbace_repr_go_convert_A_const_234; var tmp88 any = A_arbace_repr_go_convert_A_const_416; var tmp89 any = A_arbace_repr_go_convert_A_const_422;






























































































	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(tmp85.Invoke_O_O_O_O_O_O_O_O__O(tmp86, groups__7, tmp87, kept__13, tmp88, placed__14, tmp89, A_arbace_repr_go_convert_A_const_570.Invoke_O__O(plan__19))); var tmp90 any = A_arbace_repr_go_convert_convert_file_fn__1114000807_A_New_O_O_O_O(attach_meta__20, placed__14, plan__19, decls__10); var tmp91 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000807_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_repr_go_convert_convert_file_fn__1114000807_A_fn_class = fncls__151d; tmp91 = fncls__151d } else { tmp91 = fncls__151 }; decl_forms__26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp90, tmp91, nil).Invoke__O(); var unplaced__27 any; var tmp92 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_420.GetRawRoot__O()); var tmp93 any = A_arbace_repr_go_convert_convert_file_fn__1114000819_A_New_O(placed__14); var tmp94 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000819_A_fn_class; if


















































































































	fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_repr_go_convert_convert_file_fn__1114000819_A_fn_class = fncls__170d; tmp94 = fncls__170d } else { tmp94 = fncls__170 }; unplaced__27 = tmp92.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp93, tmp94, nil), dirs__11); var comments__28 any; var tmp95 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_421.GetRawRoot__O()); var tmp96 any = A_arbace_repr_go_convert_convert_file_fn__1114000824_A_New_O_O(kept__13, dirs__11); var tmp97 *jrt.Class; var fncls__174 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000824_A_fn_class; if




















































































































	fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_repr_go_convert_convert_file_fn__1114000824_A_fn_class = fncls__174d; tmp97 = fncls__174d } else { tmp97 = fncls__174 }; comments__28 = /*line :1623:1*/tmp95.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp96, tmp97, nil), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_127.GetRawRoot__O()).Invoke__O(), A_arbace_repr_go_convert_A_const_529.Invoke_O__O(fe__1));












	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(ast__4);
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_49.Invoke_O__O(f__5)); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(unplaced__27)) { lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_582) }; var tmp98 any = A_arbace_repr_go_convert_A_const_49; var tmp99 any = A_arbace_repr_go_convert_A_const_566; var tmp100 lang.IFn = /*line :1507:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O()); var tmp101 any = A_arbace_repr_go_convert_A_const_584; var tmp102 any = A_arbace_repr_go_convert_A_const_140; var tmp103 any = A_arbace_repr_go_convert_A_const_583; var tmp104 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_138.GetRawRoot__O()).Invoke_O_O__O(tmp100.Invoke_O_O__O(tmp101, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_142.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_585, ns_sym__2)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp102, pkg_line__9, tmp103, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_50, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, nil, ns_sym__2, nil)).Ref()))), file_form__24), decl_forms__26); var tmp105 any = A_arbace_repr_go_convert_A_const_529; var tmp106 any = A_arbace_repr_go_convert_A_const_567; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp98, name__6, tmp99, tmp104, tmp105, comments__28, tmp106, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(unplaced__27))) }







func A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A_New() *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A{}; t.Ctor(); return t }
//line :1515:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A) Ctor() {}
//line :1515:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A) Invoke_O_O__O(self, s__1114000697__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A_New_O_O(s__1114000697__1, self); var tmp2 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A_fn_class = fncls__153d; tmp2 = fncls__153d } else { tmp2 = fncls__153 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1515:1
func A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1515:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A) Ctor_O_O(c__s__1114000697, c__iter__1114000696 any) { t.F_s__1114000697 = c__s__1114000697; t.F_iter__1114000696 = c__iter__1114000696 }
//line :1515:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A) Invoke_O__O(self any) any { { var s__1114000697__1 any; var t_ any = t.F_s__1114000697; t.F_s__1114000697 = nil; s__1114000697__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000697__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000697__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000697__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000697__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000699__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A_New_O_I_O(b__1114000699__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__152 *jrt.Class = A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A_fn_class = fncls__152d; tmp2 = fncls__152d } else { tmp2 = fncls__152 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000696); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000699__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000697__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000699__6), nil) } } else { var g__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000697__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1114000696); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_72.Invoke_O__O(g__4))), g__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000697__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1515:1
func A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1515:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A) Ctor_O_I_O(c__b__1114000699 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000699 = c__b__1114000699; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1515:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A) Invoke_O__O(self any) any { { var i__1114000698__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000698__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var g__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000698__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000699; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_72.Invoke_O__O(g__2))), g__2)); i__1114000698__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000698__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_convert_convert_file_fn__1114000706_A_New() *A_arbace_repr_go_convert_convert_file_fn__1114000706_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000706_A{}; t.Ctor(); return t }
//line :1520:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000706_A) Ctor() {}
//line :1520:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000706_A) Invoke_O_O__O(self, d__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(d__1)), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_424.GetRawRoot__O()).Invoke_O__O(d__1)) }


func A_arbace_repr_go_convert_convert_file_fn__1114000709_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000709_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000709_A{}; t.Ctor_O(p0); return t }
//line :1523:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000709_A) Ctor_O(c__pkg_pos any) { t.F_pkg_pos = c__pkg_pos }
//line :1523:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000709_A) Invoke_O_O__O(self, p__1114000708__1 any) any { var vec__1114000710__2 any = p__1114000708__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000710__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000710__2, lang.RT_IntCast_J__I(1), nil); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), t.F_pkg_pos)))).Ref() }
func A_arbace_repr_go_convert_convert_file_fn__1114000715_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000715_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000715_A{}; t.Ctor_O(p0); return t }
//line :1524:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000715_A) Ctor_O(c__pkg_pos any) { t.F_pkg_pos = c__pkg_pos }
//line :1524:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000715_A) Invoke_O_O__O(self, p__1114000714__1 any) any { var vec__1114000716__2 any = p__1114000714__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000716__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000716__2, lang.RT_IntCast_J__I(1), nil); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), t.F_pkg_pos)))).Ref() }
func A_arbace_repr_go_convert_convert_file_fn__1114000720_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000720_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000720_A{}; t.Ctor_O(p0); return t }
//line :1525:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000720_A) Ctor_O(c__ranges any) { t.F_ranges = c__ranges }
//line :1525:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000720_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 bool; var tmp2 any = A_arbace_repr_go_convert_A_const_90; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__2)); if and__1927000168__auto____3 { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; tmp1 = lang.Util_Equiv_O_O__Z(Lit_54, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__2))) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 {
														return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_ranges).Invoke_O__O(i__1)) } else {
//line :1525:1
		return nil } }


func A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A{}; t.Ctor_O(p0); return t }
//line :1528:1
func (t *A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A) Ctor_O(c__ranges any) { t.F_ranges = c__ranges }
//line :1528:1
func (t *A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A) Invoke_O_O__O(self, p__1114000722__1 any) any { var vec__1114000724__2 any = p__1114000722__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000724__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000724__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_425.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A_New_O_O(l__3, c__4); var tmp4 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A_fn_class; if
															fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A_fn_class = fncls__136d; tmp4 = fncls__136d } else { tmp4 = fncls__136 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_ranges)) }
//line :1529:1
func A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1529:1
func (t *A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :1529:1
func (t *A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A) Invoke_O_O_O__O(self, i__1, p__1114000727__2 any) any { var vec__1114000729__3 any = p__1114000727__2; var a__4 any = lang.RT_Nth_O_I_O__O(vec__1114000729__3, lang.RT_IntCast_J__I(0), nil); var b__5 any = lang.RT_Nth_O_I_O__O(vec__1114000729__3, lang.RT_IntCast_J__I(1), nil); var tmp1 bool; var and__1927000168__auto____6 bool = lang.Numbers_Lte_J_J__Z(int64(lang.Util_Compare_O_O__I(a__4, lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c))), 0); if and__1927000168__auto____6 {
																		tmp1 = lang.Numbers_Lte_J_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c), b__5)), 0) } else {
//line :1529:1
		tmp1 = and__1927000168__auto____6 }; if tmp1 { return i__1 } else { return nil } }




func A_arbace_repr_go_convert_convert_file_fn__1114000735_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_convert_convert_file_fn__1114000735_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000735_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1534:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000735_A) Ctor_O_O_O_O(c__inside_of, c__ranges, c__last_import, c__decls any) { t.F_inside_of = c__inside_of; t.F_ranges = c__ranges; t.F_last_import = c__last_import; t.F_decls = c__decls }
//line :1534:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000735_A) Invoke_O_O_O__O(self, acc__1, p__1114000734__2 any) any { var vec__1114000736__3 any = p__1114000734__2; var l__4 any = lang.RT_Nth_O_I_O__O(vec__1114000736__3, lang.RT_IntCast_J__I(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__1114000736__3, lang.RT_IntCast_J__I(1), nil); var text__6 any = lang.RT_Nth_O_I_O__O(vec__1114000736__3, lang.RT_IntCast_J__I(2), nil); var dv__7 any = vec__1114000736__3; var tmp1 lang.IFn = lang.IFn_Cast(t.F_inside_of); var temp__1927000408__auto____8 any = tmp1.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5)); if
																jrt.J2g_Truth(temp__1927000408__auto____8) { var k__9 any = temp__1927000408__auto____8; var tmp2 any = t.F_decls; var d__10 any = lang.RT_Nth_O_I__O(tmp2, lang.RT_IntCast_O__I(k__9)); var tmp3 any; var tmp4 any = A_arbace_repr_go_convert_A_const_90; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__10))

		if and__1927000168__auto____11 { var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_115; tmp3 = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__10)) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() }; if jrt.J2g_Truth(tmp3) { var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_393; var specs__11 any = tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__10)); var si__12 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_425.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A_New_O_O(l__4, c__5); var tmp10 *jrt.Class
			var fncls__159 /*line :1537:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A_fn_class

			if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A_fn_class = fncls__159d; tmp10 = fncls__159d } else { tmp10 = fncls__159 }; si__12 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), specs__11))
			var tmp11 any; var and__1927000168__auto____13 any = si__12; if jrt.J2g_Truth(and__1927000168__auto____13) { tmp11 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_568.GetRawRoot__O()).Invoke_O_O__O(text__6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_569.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(specs__11, lang.RT_IntCast_O__I(si__12)))) } else { tmp11 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp11) {
				var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_convert_A_const_549; var tmp14 any = A_arbace_repr_go_convert_A_const_146.GetRawRoot__O(); var tmp15 any = lang.Tuple_Create_O_O__IPersistentVector(k__9, si__12); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_15.GetRawRoot__O()); var tmp17 any = A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(); var tmp18 *lang.PersistentVector; lang.PersistentVector_Init(); tmp18 = lang.PersistentVector_EMPTY; return tmp12.Invoke_O_O_O_O_O_O__O(acc__1, tmp13, tmp14, tmp15, tmp16.Invoke_O_O__O(tmp17, tmp18.Ref()), dv__7) } else {
					var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp20 any = A_arbace_repr_go_convert_A_const_570; return tmp19.Invoke_O_O_O_O__O(acc__1, tmp20, A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), dv__7) } } else {
						var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp22 any = A_arbace_repr_go_convert_A_const_570; return tmp21.Invoke_O_O_O_O__O(acc__1, tmp22, A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), dv__7) } } else {
//line :1535:1
							var k__9_2 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_425.GetRawRoot__O()); var tmp25 any = A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A_New_O_O(l__4, c__5); var tmp26 *jrt.Class
							var fncls__160 /*line :1535:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A_fn_class








							if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A_fn_class = fncls__160d; tmp26 = fncls__160d } else { tmp26 = fncls__160 }; k__9_2 = tmp23.Invoke_O__O(tmp24.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil), t.F_ranges))
//line :1535:1
							var d__10_2 any









							if jrt.J2g_Truth(k__9_2) { var tmp27 any = t.F_decls; d__10_2 = lang.RT_Nth_O_I__O(tmp27, lang.RT_IntCast_O__I(k__9_2)) } else { d__10_2 = nil }
//line :1535:1
							var target__11 any










							if jrt.J2g_Truth(d__10_2) {
								var tmp28 any = A_arbace_repr_go_convert_A_const_123; if lang.Util_Equiv_O_O__Z(tmp28, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__10_2)) { target__11 = d__10_2 } else { var tmp29 any; var tmp30 any = A_arbace_repr_go_convert_A_const_90; var and__1927000168__auto____11_2 bool = lang.Util_Equiv_O_O__Z(tmp30, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__10_2))

									if and__1927000168__auto____11_2 { var tmp31 *lang.Keyword = A_arbace_repr_go_convert_A_const_115; var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(tmp31.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__10_2))); if jrt.J2g_Truth(and__1927000168__auto____12) {
										var tmp32 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; tmp29 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()).Invoke_O_O__O(Lit_54, tmp32.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__10_2))) } else {
//line :1549:1
											tmp29 = and__1927000168__auto____12 } } else { tmp29 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11_2).Ref() }
//line :1547:1
									if jrt.J2g_Truth(tmp29) {



										var tmp33 *lang.Keyword = A_arbace_repr_go_convert_A_const_393; target__11 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp33.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__10_2))) } else {
//line :1547:1
											target__11 = nil } } } else {
//line :1546:1
												target__11 = nil
											}




							var tmp34 any; var and__1927000168__auto____12_2 any = target__11
							if jrt.J2g_Truth(and__1927000168__auto____12_2) { tmp34 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_568.GetRawRoot__O()).Invoke_O_O__O(text__6, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_569.GetRawRoot__O()).Invoke_O__O(target__11)) } else { tmp34 = and__1927000168__auto____12_2 }
//line :1552:1
							if jrt.J2g_Truth(tmp34) {

								var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp36 any = A_arbace_repr_go_convert_A_const_549; var tmp37 any = A_arbace_repr_go_convert_A_const_146.GetRawRoot__O(); var tmp38 any = lang.Tuple_Create_O_O__IPersistentVector(k__9_2, A_arbace_repr_go_convert_A_const_18); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_15.GetRawRoot__O()); var tmp40 any = A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(); var tmp41 *lang.PersistentVector; lang.PersistentVector_Init(); tmp41 = lang.PersistentVector_EMPTY; return tmp35.Invoke_O_O_O_O_O_O__O(acc__1, tmp36, tmp37, tmp38, tmp39.Invoke_O_O__O(tmp40, tmp41.Ref()), dv__7) } else {
//line :1552:1
									var tmp42 any; var and__1927000168__auto____12_3 any = t.F_last_import


									if jrt.J2g_Truth(and__1927000168__auto____12_3) { tmp42 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5), t.F_last_import)))).Ref() } else { tmp42 = and__1927000168__auto____12_3 }
//line :1552:1
									if jrt.J2g_Truth(tmp42) {



										var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp44 any = A_arbace_repr_go_convert_A_const_571; return tmp43.Invoke_O_O_O_O__O(acc__1, tmp44, A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), dv__7) } else {
//line :1552:1
											if A_arbace_repr_go_convert_A_const_152 != nil {





												var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp46 any = A_arbace_repr_go_convert_A_const_562; var tmp47 any = A_arbace_repr_go_convert_A_const_146.GetRawRoot__O(); var tmp48 any; var or__1927000174__auto____12 any = k__9_2; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp48 = or__1927000174__auto____12 } else { tmp48 = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_decls)).Ref() }; var tmp49 any = tmp48; var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_15.GetRawRoot__O()); var tmp51 any = A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(); var tmp52 *lang.PersistentVector; lang.PersistentVector_Init(); tmp52 = lang.PersistentVector_EMPTY; return tmp45.Invoke_O_O_O_O_O_O__O(acc__1, tmp46, tmp47, tmp49, tmp50.Invoke_O_O__O(tmp51, tmp52.Ref()), dv__7) } else {
//line :1552:1
													return nil } } } } }
//line :1539:1
func A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1539:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :1539:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A) Invoke_O_O_O__O(self, i__1, sp__2 any) any { if lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_40.GetRawRoot__O()).Invoke_O__O(sp__2)), lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c)))) { return i__1 } else { return nil } }




func A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1544:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :1544:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A) Invoke_O_O_O__O(self, i__1, p__1114000741__2 any) any { var vec__1114000743__3 any = p__1114000741__2; var a__4 any = lang.RT_Nth_O_I_O__O(vec__1114000743__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1114000743__3, lang.RT_IntCast_J__I(1), nil); _ = ___5; if lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(a__4, lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c)))) { return i__1 } else { return nil } }
















func A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1561:1
func (t *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A) Ctor_O_O(c__placed, c__plan any) { t.F_placed = c__placed; t.F_plan = c__plan }
//line :1561:1
func (t *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A) Invoke_O_O_O__O(self, k__1, si__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_547.GetRawRoot__O()); var tmp2 any = t.F_plan; var tmp3 any = A_arbace_repr_go_convert_A_const_549; var temp__1927000414__auto____3 any = tmp1.Invoke_O_O__O(tmp2, lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Tuple_Create_O_O__IPersistentVector(k__1, si__2))); if
															jrt.J2g_Truth(temp__1927000414__auto____3) { var ds__4 any = temp__1927000414__auto____3; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()); var tmp5 any = t.F_placed; var tmp6 any = A_arbace_repr_go_convert_A_const_126.GetRawRoot__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A_New(); var tmp9 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A_fn_class
																if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A_fn_class = fncls__138d; tmp9 = fncls__138d } else { tmp9 = fncls__138 }; tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), ds__4))
																lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_550)
																var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_548.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp12 any = A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A_New(); var tmp13 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A_fn_class = fncls__139d; tmp13 = fncls__139d } else { tmp13 = fncls__139 }; return tmp10.Invoke_O__O(tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), ds__4)) } else {
//line :1562:1
			return nil } }
func A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A_New() *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A{}; t.Ctor(); return t }
//line :1563:1
func (t *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A) Ctor() {}
//line :1563:1
func (t *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A) Invoke_O_O__O(self, p__1114000749__1 any) any { var vec__1114000751__2 any = p__1114000749__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000751__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000751__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4) }

func A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A_New() *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A{}; t.Ctor(); return t }
//line :1565:1
func (t *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A) Ctor() {}
//line :1565:1
func (t *A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A) Invoke_O_O__O(self, p1__1114000691_SHARP___1 any) any { return lang.RT_Nth_O_I__O(p1__1114000691_SHARP___1, lang.RT_IntCast_J__I(2)) }
func A_arbace_repr_go_convert_convert_file_fn__1114000758_A_New() *A_arbace_repr_go_convert_convert_file_fn__1114000758_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000758_A{}; t.Ctor(); return t }
//line :1566:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000758_A) Ctor() {}
//line :1566:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000758_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_159.GetRawRoot__O()).Invoke_O__O(x__1); var tmp2 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp2 = A_arbace_repr_go_convert_A_const_18 } else { tmp2 = A_arbace_repr_go_convert_A_const_334 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_repr_go_convert_convert_file_fn__1114000760_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000760_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000760_A{}; t.Ctor_O(p0); return t }
//line :1568:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000760_A) Ctor_O(c__placed any) { t.F_placed = c__placed }
//line :1568:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000760_A) Invoke_O_O__O(self, dv__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()); var tmp2 any = t.F_placed; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_560.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_561, dv__1))); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_559.GetRawRoot__O()).Invoke_O__O(dv__1) }


func A_arbace_repr_go_convert_convert_file_fn__1114000762_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_repr_go_convert_convert_file_fn__1114000762_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000762_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :1571:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_A) Ctor_O_O_O_O_O_O_O_O(c__f, c__doc, c__name, c__dump, c__imports, c__fe, c__header, c__pkg_line any) { t.F_f = c__f; t.F_doc = c__doc; t.F_name = c__name; t.F_dump = c__dump; t.F_imports = c__imports; t.F_fe = c__fe; t.F_header = c__header; t.F_pkg_line = c__pkg_line }
//line :1571:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_A) Invoke_O__O(self any) any { var tmp1 any; tmp58 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_A_const_189.GetRawRoot__O(); var tmp4 any = t.F_pkg_line; var tmp5 any = A_arbace_repr_go_convert_A_const_551; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(t.F_name); var tmp8 any; var t_ any = t.F_name; t.F_name = nil; tmp8 = t_; var tmp9 any = tmp6.Invoke_O_O__O(tmp7, tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp11 lang.IPersistentVector; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_233.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_49.Invoke_O__O(t.F_f)); var tmp14 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var tmp15 any; var t__2 any = t.F_dump

		t.F_dump = nil; tmp15 = t__2; if jrt.J2g_Truth(tmp12.Invoke_O_O__O(tmp13, tmp14.Invoke_O__O(tmp15))) { var tmp16 any = A_arbace_repr_go_convert_A_const_553; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()); var tmp19 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var tmp20 any; var t__3 any = t.F_f
			t.F_f = nil; tmp20 = t__3
//line :1574:1
			tmp11 = lang.Tuple_Create_O_O__IPersistentVector(tmp16, tmp17.Invoke_O__O(tmp18.Invoke_O__O(tmp19.Invoke_O__O(tmp20)))) } else { tmp11 = nil }
//line :1572:1
		var tmp21 any = tmp11; var tmp22 lang.IPersistentVector; var b__3 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_28.GetRawRoot__O()); var tmp24 any = A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A_New(); var tmp25 *jrt.Class
		var fncls__141 /*line :1572:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A_fn_class



		if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A_fn_class = fncls__141d; tmp25 = fncls__141d } else { tmp25 = fncls__141 }; b__3 = tmp23.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil), t.F_header)

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(b__3)) { var tmp26 any = A_arbace_repr_go_convert_A_const_554; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp29 any = A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A_New(); var tmp30 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A_fn_class = fncls__142d; tmp30 = fncls__142d } else { tmp30 = fncls__142 }; tmp22 = lang.Tuple_Create_O_O__IPersistentVector(tmp26, tmp27.Invoke_O__O(tmp28.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), b__3))) } else { tmp22 = nil }
//line :1572:1
		var tmp31 any = tmp22; var tmp32 lang.IPersistentVector; var o__3 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_420.GetRawRoot__O()); var tmp34 any = A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A_New(); var tmp35 *jrt.Class
		var fncls__143 /*line :1572:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A_fn_class






		if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A_fn_class = fncls__143d; tmp35 = fncls__143d } else { tmp35 = fncls__143 }; var tmp36 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); var tmp37 any; var t__4 any = t.F_header; t.F_header = nil; tmp37 = t__4; o__3 = tmp33.Invoke_O_O__O(tmp36, tmp37)

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(o__3)) { var tmp38 any = A_arbace_repr_go_convert_A_const_519; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp41 any = A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A_New(); var tmp42 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A_fn_class = fncls__144d; tmp42 = fncls__144d } else { tmp42 = fncls__144 }; tmp32 = lang.Tuple_Create_O_O__IPersistentVector(tmp38, tmp39.Invoke_O__O(tmp40.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil), o__3))) } else { tmp32 = nil }
//line :1572:1
		var tmp43 any = tmp32; var tmp44 lang.IPersistentVector; var temp__1927000414__auto____3 any; var tmp45 *lang.Keyword = A_arbace_repr_go_convert_A_const_552; var tmp46 any; var t__5 any = t.F_fe









		t.F_fe = nil; tmp46 = t__5; temp__1927000414__auto____3 = tmp45.Invoke_O__O(tmp46); if jrt.J2g_Truth(temp__1927000414__auto____3) { var v__4 any = temp__1927000414__auto____3; var tmp47 any = A_arbace_repr_go_convert_A_const_555; tmp44 = lang.Tuple_Create_O_O__IPersistentVector(tmp47, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(v__4), v__4)) } else { tmp44 = nil }
//line :1572:1
		var tmp48 any = tmp44; var tmp49 lang.IPersistentVector










		if jrt.J2g_Truth(t.F_doc) { var tmp50 any = A_arbace_repr_go_convert_A_const_238; var tmp51 any; var t__6 any = t.F_doc; t.F_doc = nil; tmp51 = t__6; tmp49 = lang.Tuple_Create_O_O__IPersistentVector(tmp50, tmp51) } else { tmp49 = nil }
//line :1572:1
		var tmp52 any = tmp49; var tmp53 any = A_arbace_repr_go_convert_A_const_556; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_299.GetRawRoot__O()); var tmp55 any; var t__7 any = t.F_pkg_line











		t.F_pkg_line = nil; tmp55 = t__7
//line :1572:1
		var tmp56 any = tmp55; var tmp57 any; var t__8 any = t.F_imports











		t.F_imports = nil; tmp57 = t__8
//line :1572:1
		tmp1 = tmp2.Invoke_O_O_O_O_O_O__O(tmp3, nil, tmp4, tmp5, tmp9, tmp10.Invoke_O_O_O_O_O_O__O(tmp21, tmp31, tmp43, tmp48, tmp52, lang.Tuple_Create_O_O__IPersistentVector(tmp53, tmp54.Invoke_O_O__O(tmp56, tmp57)))) }
//line :1571:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp58 != nil { panic(tmp58) }; return tmp1 }




func A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A_New() *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A{}; t.Ctor(); return t }
//line :1576:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A) Ctor() {}
//line :1576:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A) Invoke_O_O__O(self, p1__1114000692_SHARP___1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(p1__1114000692_SHARP___1, lang.RT_IntCast_J__I(2)), Lit_61); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
																	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(p1__1114000692_SHARP___1, lang.RT_IntCast_J__I(2)), Lit_62) } }
func A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A_New() *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A{}; t.Ctor(); return t }
//line :1578:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A) Ctor() {}
//line :1578:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A) Invoke_O_O__O(self, p1__1114000693_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(p1__1114000693_SHARP___1, lang.RT_IntCast_J__I(2))), lang.RT_Nth_O_I__O(p1__1114000693_SHARP___1, lang.RT_IntCast_J__I(2))) }
func A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A_New() *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A{}; t.Ctor(); return t }
//line :1579:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A) Ctor() {}
//line :1579:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A) Invoke_O_O__O(self, p1__1114000694_SHARP___1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(p1__1114000694_SHARP___1, lang.RT_IntCast_J__I(2)), Lit_61); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
																	return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_499.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(p1__1114000694_SHARP___1, lang.RT_IntCast_J__I(2)), Lit_62) } }
func A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A_New() *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A{}; t.Ctor(); return t }
//line :1581:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A) Ctor() {}
//line :1581:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A) Invoke_O_O__O(self, p1__1114000695_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_193.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(p1__1114000695_SHARP___1, lang.RT_IntCast_J__I(2))), lang.RT_Nth_O_I__O(p1__1114000695_SHARP___1, lang.RT_IntCast_J__I(2))) }









func A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A_New() *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A{}; t.Ctor(); return t }
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A) Ctor() {}
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A) Invoke_O_O__O(self, s__1114000773__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A_New_O_O(s__1114000773__1, self); var tmp2 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A_fn_class = fncls__167d; tmp2 = fncls__167d } else { tmp2 = fncls__167 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1591:1
func A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A) Ctor_O_O(c__s__1114000773, c__iter__1114000772 any) { t.F_s__1114000773 = c__s__1114000773; t.F_iter__1114000772 = c__iter__1114000772 }
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A) Invoke_O__O(self any) any { { var s__1114000773__1 any; var t_ any = t.F_s__1114000773; t.F_s__1114000773 = nil; s__1114000773__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000773__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var g__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A_New(); var tmp2 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A_fn_class = fncls__166d; tmp2 = fncls__166d } else { tmp2 = fncls__166 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_repr_go_convert_A_const_72.Invoke_O__O(g__4))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000772); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000773__1))) } else { s__1114000773__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000773__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :1591:1
func A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A_New() *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A{}; t.Ctor(); return t }
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A) Ctor() {}
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A) Invoke_O_O__O(self, s__1114000775__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A_New_O_O(s__1114000775__1, self); var tmp2 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A_fn_class = fncls__165d; tmp2 = fncls__165d } else { tmp2 = fncls__165 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1591:1
func A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A) Ctor_O_O(c__s__1114000775, c__iter__1114000774 any) { t.F_s__1114000775 = c__s__1114000775; t.F_iter__1114000774 = c__iter__1114000774 }
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A) Invoke_O__O(self any) any { { var s__1114000775__1 any; var t_ any = t.F_s__1114000775; t.F_s__1114000775 = nil; s__1114000775__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000775__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000775__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000775__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000775__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000777__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A_New_O_I_O(b__1114000777__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A_fn_class = fncls__164d; tmp2 = fncls__164d } else { tmp2 = fncls__164 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000774); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000777__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000775__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000777__6), nil) } } else { var vec__1114000790__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000775__3); var p__5 any = lang.RT_Nth_O_I_O__O(vec__1114000790__4, lang.RT_IntCast_J__I(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O(vec__1114000790__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp5 lang.IPersistentVector; var vec__1114000793__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(p__5); var l__8 any = lang.RT_Nth_O_I_O__O(vec__1114000793__7, lang.RT_IntCast_J__I(0), nil); var c__9 any = lang.RT_Nth_O_I_O__O(vec__1114000793__7, lang.RT_IntCast_J__I(1), nil); tmp5 = lang.Tuple_Create_O_O_O__IPersistentVector(l__8, c__9, t__6); var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1114000774); return tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000775__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1591:1
func A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A) Ctor_O_I_O(c__b__1114000777 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000777 = c__b__1114000777; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1591:1
func (t *A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A) Invoke_O__O(self any) any { { var i__1114000776__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000776__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1114000783__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000776__1)); var p__3 any = lang.RT_Nth_O_I_O__O(vec__1114000783__2, lang.RT_IntCast_J__I(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O(vec__1114000783__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000777; var tmp4 lang.IPersistentVector; var vec__1114000786__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(p__3); var l__6 any = lang.RT_Nth_O_I_O__O(vec__1114000786__5, lang.RT_IntCast_J__I(0), nil); var c__7 any = lang.RT_Nth_O_I_O__O(vec__1114000786__5, lang.RT_IntCast_J__I(1), nil); tmp4 = lang.Tuple_Create_O_O_O__IPersistentVector(l__6, c__7, t__4); tmp2.Invoke_O_O__O(tmp3, tmp4); i__1114000776__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000776__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_repr_go_convert_convert_file_fn__1114000802_A_New() *A_arbace_repr_go_convert_convert_file_fn__1114000802_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000802_A{}; t.Ctor(); return t }
//line :1601:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000802_A) Ctor() {}
//line :1601:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000802_A) Invoke_O_O__O(self, p__1114000801__1 any) any { var vec__1114000803__2 any = p__1114000801__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000803__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000803__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4) }
func A_arbace_repr_go_convert_convert_file_fn__1114000807_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_convert_convert_file_fn__1114000807_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000807_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1602:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_A) Ctor_O_O_O_O(c__attach_meta, c__placed, c__plan, c__decls any) { t.F_attach_meta = c__attach_meta; t.F_placed = c__placed; t.F_plan = c__plan; t.F_decls = c__decls }
//line :1602:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_348.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_237.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A_New_O_O_O(t.F_attach_meta, t.F_placed, t.F_plan); var tmp6 *jrt.Class
		var fncls__149 /*line :1606:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A_fn_class


		if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A_fn_class = fncls__149d; tmp6 = fncls__149d } else { tmp6 = fncls__149 }
//line :1606:1
		var tmp7 any = tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_565.GetRawRoot__O()).Invoke__O(), t.F_decls); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A_New_O(t.F_placed); var tmp10 *jrt.Class
		var fncls__150 /*line :1606:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A_fn_class













		if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A_fn_class = fncls__150d; tmp10 = fncls__150d } else { tmp10 = fncls__150 }
//line :1606:1
		var tmp11 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_547.GetRawRoot__O()); var tmp13 any; var t_ any = t.F_plan














		t.F_plan = nil; tmp13 = t_
//line :1606:1
		var tmp14 any = tmp13; var tmp15 any = A_arbace_repr_go_convert_A_const_562; var tmp16 any; var t__2 any = t.F_decls














		t.F_decls = nil; tmp16 = t__2
//line :1606:1
		tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp14, lang.Tuple_Create_O_O__IPersistentVector(tmp15, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(tmp16)).Ref()))))) }
//line :1602:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp17 != nil { panic(tmp17) }; return tmp1 }






func A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1609:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A) Ctor_O_O_O(c__attach_meta, c__placed, c__plan any) { t.F_attach_meta = c__attach_meta; t.F_placed = c__placed; t.F_plan = c__plan }
//line :1609:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A) Invoke_O_O_O__O(self, k__1, d__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A_New_O(t.F_placed); var tmp4 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A_fn_class
	if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A_fn_class = fncls__147d; tmp4 = fncls__147d } else { tmp4 = fncls__147 }
//line :1610:1
	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_547.GetRawRoot__O()); var tmp6 any = t.F_plan; var tmp7 any = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_convert_A_const_562, k__1))); var tmp8 any; var G__1114000811__3_ any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__2)


L1: switch { default: switch lang.Util_Hash_O__I(G__1114000811__3_) >> 0 & 1 { case 0: if any(G__1114000811__3_) == any(A_arbace_repr_go_convert_A_const_90) {

	var tmp9 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; if lang.Util_Equiv_O_O__Z(Lit_54, tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__2))) { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() } else { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_563.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A_New_O_O(k__1, t.F_attach_meta); var tmp12 *jrt.Class
		var fncls__148 /*line :1615:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A_fn_class

		if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A_fn_class = fncls__148d; tmp12 = fncls__148d } else { tmp12 = fncls__148 }
//line :1615:1
		tmp8 = lang.Tuple_Create_O__IPersistentVector(tmp10.Invoke_O_O__O(d__2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }
//line :1613:1
	break L1 }; case 1: if any(G__1114000811__3_) == any(A_arbace_repr_go_convert_A_const_123) { tmp8 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_564.GetRawRoot__O()).Invoke_O_O__O(d__2, lang.IFn_Cast(t.F_attach_meta).Invoke_O_O__O(k__1, A_arbace_repr_go_convert_A_const_18))); break L1 }; default:
}



	tmp8 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_46.GetRawRoot__O()).Invoke_O_O__O(Lit_67, d__2)}
//line :1610:1
	return tmp1.Invoke_O_O__O(tmp7, tmp8) }
func A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A{}; t.Ctor_O(p0); return t }
//line :1611:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A) Ctor_O(c__placed any) { t.F_placed = c__placed }
//line :1611:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A) Invoke_O_O__O(self, dv__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()); var tmp2 any = t.F_placed; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_560.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_561, dv__1))); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_559.GetRawRoot__O()).Invoke_O__O(dv__1) }





func A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1617:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A) Ctor_O_O(c__k, c__attach_meta any) { t.F_k = c__k; t.F_attach_meta = c__attach_meta }
//line :1617:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A) Invoke_O_O__O(self, si__1 any) any { return lang.IFn_Cast(t.F_attach_meta).Invoke_O_O__O(t.F_k, si__1) }


func A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A{}; t.Ctor_O(p0); return t }
//line :1620:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A) Ctor_O(c__placed any) { t.F_placed = c__placed }
//line :1620:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A) Invoke_O_O__O(self, dv__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_13.GetRawRoot__O()); var tmp2 any = t.F_placed; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_560.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_561, dv__1))); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_559.GetRawRoot__O()).Invoke_O__O(dv__1) }

func A_arbace_repr_go_convert_convert_file_fn__1114000819_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000819_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000819_A{}; t.Ctor_O(p0); return t }
//line :1622:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000819_A) Ctor_O(c__placed any) { t.F_placed = c__placed }
//line :1622:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000819_A) Invoke_O_O__O(self, p__1114000818__1 any) any { var vec__1114000820__2 any = p__1114000818__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__1114000820__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__1114000820__2, lang.RT_IntCast_J__I(1), nil); return lang.IFn_Cast(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_8.GetRawRoot__O()).Invoke_O__O(t.F_placed)).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4)) }

func A_arbace_repr_go_convert_convert_file_fn__1114000824_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_fn__1114000824_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000824_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1624:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000824_A) Ctor_O_O(c__kept, c__dirs any) { t.F_kept = c__kept; t.F_dirs = c__dirs }
//line :1624:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000824_A) Invoke_O_O_O__O(self, m__1, g__2 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_8.GetRawRoot__O()).Invoke_O__O(t.F_kept)).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_72.Invoke_O__O(g__2))))) { return m__1 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_421.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A_New_O(t.F_dirs); var tmp3 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A_fn_class = fncls__173d; tmp3 = fncls__173d } else { tmp3 = fncls__173 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), m__1, A_arbace_repr_go_convert_A_const_72.Invoke_O__O(g__2)) } }
//line :1627:1
func A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A{}; t.Ctor_O(p0); return t }
//line :1627:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A) Ctor_O(c__dirs any) { t.F_dirs = c__dirs }
//line :1627:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A) Invoke_O_O_O__O(self, m__1, p__1114000825__2 any) any { var vec__1114000827__3 any = p__1114000825__2; var p__4 any = lang.RT_Nth_O_I_O__O(vec__1114000827__3, lang.RT_IntCast_J__I(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O(vec__1114000827__3, lang.RT_IntCast_J__I(1), nil); var vec__1114000830__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_38.GetRawRoot__O()).Invoke_O__O(p__4); var l__7 any = lang.RT_Nth_O_I_O__O(vec__1114000830__6, lang.RT_IntCast_J__I(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O(vec__1114000830__6, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_419.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A_New_O_O(l__7, c__8); var tmp3 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A_fn_class; if

	fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A_fn_class = fncls__171d; tmp3 = fncls__171d } else { tmp3 = fncls__171 }; if jrt.J2g_Truth(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_dirs)) { return m__1 } else { var lines__9 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_580.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_581.GetRawRoot__O()).Invoke_O_O_O__O(text__5, Lit_70, Lit_9)); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_421.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A_New_O(l__7); var tmp6 *jrt.Class
		var fncls__172 /*line :1629:1*/*jrt.Class = A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A_fn_class


		if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A_fn_class = fncls__172d; tmp6 = fncls__172d } else { tmp6 = fncls__172 }; return tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), m__1, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_525.GetRawRoot__O(), lines__9)) } }
//line :1629:1
func A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1629:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :1629:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A) Invoke_O_O__O(self, p__1114000833__1 any) any { var vec__1114000835__2 any = p__1114000833__1; var dl__3 any = lang.RT_Nth_O_I_O__O(vec__1114000835__2, lang.RT_IntCast_J__I(0), nil); var dc__4 any = lang.RT_Nth_O_I_O__O(vec__1114000835__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(dl__3, t.F_l); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(dc__4, t.F_c)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }


func A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A_New_O(p0 any) *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A{}; t.Ctor_O(p0); return t }
//line :1632:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :1632:1
func (t *A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A) Invoke_O_O_O__O(self, m__1, p__1114000839__2 any) any { var vec__1114000841__3 any = p__1114000839__2; var i__4 any = lang.RT_Nth_O_I_O__O(vec__1114000841__3, lang.RT_IntCast_J__I(0), nil); var t__5 any = lang.RT_Nth_O_I_O__O(vec__1114000841__3, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_146.GetRawRoot__O()); var tmp2 any = lang.Numbers_Add_O_O__Number(t.F_l, i__4); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_15.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_A_const_9.GetRawRoot__O(); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O_O_O_O__O(m__1, tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5.Ref()), t__5) }















func A_arbace_repr_go_convert_init_order_A_New() *A_arbace_repr_go_convert_init_order_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_init_order_A{}; t.Ctor(); return t }
//line :1648:1
func (t *A_arbace_repr_go_convert_init_order_A) Ctor() {}
//line :1648:1
func (t *A_arbace_repr_go_convert_init_order_A) Invoke_O_O__O(self, dump__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A_New(); var tmp4 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A_fn_class
	if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_164, false); A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A_fn_class = fncls__179d; tmp4 = fncls__179d } else { tmp4 = fncls__179 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(A_arbace_repr_go_convert_A_const_588.Invoke_O__O(dump__0))
//line :1649:1
	return tmp1.Invoke_O__O(tmp2) }
func A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A_New() *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A{}; t.Ctor(); return t }
//line :1650:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A) Ctor() {}
//line :1650:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A) Invoke_O_O__O(self, s__1114000849__1 any) any { var tmp1 any = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A_New_O_O(s__1114000849__1, self); var tmp2 *jrt.Class; var fncls__178 *jrt.Class = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A_fn_class; if fncls__178 == nil { var fncls__178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_165, false); A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A_fn_class = fncls__178d; tmp2 = fncls__178d } else { tmp2 = fncls__178 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1650:1
func A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1650:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A) Ctor_O_O(c__s__1114000849, c__iter__1114000848 any) { t.F_s__1114000849 = c__s__1114000849; t.F_iter__1114000848 = c__iter__1114000848 }
//line :1650:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A) Invoke_O__O(self any) any { { var s__1114000849__1 any; var t_ any = t.F_s__1114000849; t.F_s__1114000849 = nil; s__1114000849__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000849__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000849__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000849__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000849__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000851__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A_New_O_I_O(b__1114000851__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__176 *jrt.Class = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_166, false); A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A_fn_class = fncls__176d; tmp2 = fncls__176d } else { tmp2 = fncls__176 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000848); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000851__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000849__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000851__6), nil) } } else { var map__1114000867__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000849__3); var map__1114000867__5 any; if lang.ISeq_InstanceOf(map__1114000867__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000867__4)) { map__1114000867__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000867__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000867__4)) { map__1114000867__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000867__4) } else { lang.PersistentArrayMap_Init(); map__1114000867__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000867__5 = map__1114000867__4 }; var lhs__6 any = lang.RT_Get_O_O__O(map__1114000867__5, A_arbace_repr_go_convert_A_const_79); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp5 any; var one__7 any; var tmp6 any = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A_New(); var tmp7 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A_fn_class
															if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_167, false); A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A_fn_class = fncls__177d; tmp7 = fncls__177d } else { tmp7 = fncls__177 }; one__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)




	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(lhs__6))) {
		tmp5 = lang.IFn_Cast(one__7).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lhs__6)) } else {
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_convert_A_const_142.GetRawRoot__O(); var tmp10 any = A_arbace_repr_go_convert_A_const_587; tmp5 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(one__7, lhs__6)) }
//line :1650:1
	var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1114000848); return tmp4.Invoke_O_O__O(tmp5, tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000849__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1650:1
func A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1650:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A) Ctor_O_I_O(c__b__1114000851 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000851 = c__b__1114000851; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1650:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A) Invoke_O__O(self any) any { { var i__1114000850__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000850__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__1114000855__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000850__1)); var map__1114000855__3 any; if lang.ISeq_InstanceOf(map__1114000855__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000855__2)) { map__1114000855__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000855__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000855__2)) { map__1114000855__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000855__2) } else { lang.PersistentArrayMap_Init(); map__1114000855__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000855__3 = map__1114000855__2 }; var lhs__4 any = lang.RT_Get_O_O__O(map__1114000855__3, A_arbace_repr_go_convert_A_const_79); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000851; var tmp4 any; var one__5 any; var tmp5 any = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A_New(); var tmp6 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A_fn_class
																	if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_168, false); A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A_fn_class = fncls__175d; tmp6 = fncls__175d } else { tmp6 = fncls__175 }; one__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)




	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(lhs__4))) {
		tmp4 = lang.IFn_Cast(one__5).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(lhs__4)) } else {
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_A_const_142.GetRawRoot__O(); var tmp9 any = A_arbace_repr_go_convert_A_const_587; tmp4 = tmp7.Invoke_O_O_O__O(tmp8, tmp9, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(one__5, lhs__4)) }
//line :1650:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1114000850__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000850__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A_New() *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A{}; t.Ctor(); return t }
//line :1651:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A) Ctor() {}
//line :1651:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A) Invoke_O_O__O(self, p__1114000857__1 any) any { var vec__1114000859__2 any = p__1114000857__1; var nm__3 any = lang.RT_Nth_O_I_O__O(vec__1114000859__2, lang.RT_IntCast_J__I(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O(vec__1114000859__2, lang.RT_IntCast_J__I(1), nil); if
																						lang.Util_Equiv_O_O__Z(nm__3, Lit_28) { var vec__1114000862__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_586, p__4); var ___6 any = lang.RT_Nth_O_I_O__O(vec__1114000862__5, lang.RT_IntCast_J__I(0), nil); var file__7 any = lang.RT_Nth_O_I_O__O(vec__1114000862__5, lang.RT_IntCast_J__I(1), nil); var l__8 any = lang.RT_Nth_O_I_O__O(vec__1114000862__5, lang.RT_IntCast_J__I(2), nil); var c__9 any = lang.RT_Nth_O_I_O__O(vec__1114000862__5, lang.RT_IntCast_J__I(3), nil); _ = ___6; return lang.Tuple_Create_O_O_O__IPersistentVector(file__7, jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(l__8))).Ref(), jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(c__9))).Ref()) } else {


		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(nm__3) } }
//line :1651:1
func A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A_New() *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A{}; t.Ctor(); return t }
//line :1651:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A) Ctor() {}
//line :1651:1
func (t *A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A) Invoke_O_O__O(self, p__1114000869__1 any) any { var vec__1114000871__2 any = p__1114000869__1; var nm__3 any = lang.RT_Nth_O_I_O__O(vec__1114000871__2, lang.RT_IntCast_J__I(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O(vec__1114000871__2, lang.RT_IntCast_J__I(1), nil); if
																				lang.Util_Equiv_O_O__Z(nm__3, Lit_28) { var vec__1114000874__5 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_586, p__4); var ___6 any = lang.RT_Nth_O_I_O__O(vec__1114000874__5, lang.RT_IntCast_J__I(0), nil); var file__7 any = lang.RT_Nth_O_I_O__O(vec__1114000874__5, lang.RT_IntCast_J__I(1), nil); var l__8 any = lang.RT_Nth_O_I_O__O(vec__1114000874__5, lang.RT_IntCast_J__I(2), nil); var c__9 any = lang.RT_Nth_O_I_O__O(vec__1114000874__5, lang.RT_IntCast_J__I(3), nil); _ = ___6; return lang.Tuple_Create_O_O_O__IPersistentVector(file__7, jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(l__8))).Ref(), jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(c__9))).Ref()) } else {


		return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()).Invoke_O__O(nm__3) } }




func A_arbace_repr_go_convert_munge_name_A_New() *A_arbace_repr_go_convert_munge_name_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_munge_name_A{}; t.Ctor(); return t }
//line :1660:1
func (t *A_arbace_repr_go_convert_munge_name_A) Ctor() {}
//line :1660:1
func (t *A_arbace_repr_go_convert_munge_name_A) Invoke_O_O__O(self, s__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_581.GetRawRoot__O()).Invoke_O_O_O__O(s__0, A_arbace_repr_go_convert_A_const_589, Lit_28) }

func A_arbace_repr_go_convert_package_form_A_New() *A_arbace_repr_go_convert_package_form_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_package_form_A{}; t.Ctor(); return t }
//line :1662:1
func (t *A_arbace_repr_go_convert_package_form_A) Ctor() {}
//line :1662:1
func (t *A_arbace_repr_go_convert_package_form_A) Invoke_O_O_O__O(self, dump__0, p__1114000883__1 any) any { var map__1114000884__3 any = p__1114000883__1; var map__1114000884__4 any; if lang.ISeq_InstanceOf(map__1114000884__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_136.GetRawRoot__O()).Invoke_O__O(map__1114000884__3)) { map__1114000884__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_convert_A_const_215.GetRawRoot__O()).Invoke_O__O(map__1114000884__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(map__1114000884__3)) { map__1114000884__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1114000884__3) } else { lang.PersistentArrayMap_Init(); map__1114000884__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1114000884__4 = map__1114000884__3 }; var positions__5 any = lang.RT_Get_O_O__O(map__1114000884__4, A_arbace_repr_go_convert_A_const_590); var c__6 any = A_arbace_repr_go_convert_A_const_591.Invoke_O__O(dump__0); var files__7 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_592.Invoke_O__O(dump__0)); var others__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_534.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_237.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_convert_package_form_fn__1114000886_A_New_O(dump__0); var tmp5 *jrt.Class; var fncls__180 *jrt.Class = A_arbace_repr_go_convert_package_form_fn__1114000886_A_fn_class; if


	fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_179, false); A_arbace_repr_go_convert_package_form_fn__1114000886_A_fn_class = fncls__180d; tmp5 = fncls__180d } else { tmp5 = fncls__180 }; others__8 = tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), A_arbace_repr_go_convert_A_const_593))); var embeds__9 any = /*line :1662:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_594.Invoke_O__O(dump__0), A_arbace_repr_go_convert_A_const_595.Invoke_O__O(dump__0))); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_139.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_142.GetRawRoot__O(); var tmp8 any = A_arbace_repr_go_convert_A_const_596; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_192.GetRawRoot__O()); var tmp10 any; if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_161.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_49.Invoke_O__O(dump__0))) {
		tmp10 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_597.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_546.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_505.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_553.Invoke_O__O(dump__0), A_arbace_repr_go_convert_A_const_598))) } else {
			tmp10 = A_arbace_repr_go_convert_A_const_49.Invoke_O__O(dump__0) }; var tmp11 any = /*line :1668:1*/tmp9.Invoke_O__O(tmp10); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_convert_A_const_51; var tmp14 any = A_arbace_repr_go_convert_A_const_553.Invoke_O__O(dump__0); var tmp15 any = A_arbace_repr_go_convert_A_const_591; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_599.GetRawRoot__O()); var tmp17 any = A_arbace_repr_go_convert_A_const_601; var tmp18 any = A_arbace_repr_go_convert_A_const_601.Invoke_O__O(c__6); var tmp19 any = A_arbace_repr_go_convert_A_const_602; var tmp20 any = A_arbace_repr_go_convert_A_const_602.Invoke_O__O(c__6); var tmp21 *lang.Keyword; if





	lang.Util_Equiv_O_O__Z(Lit_180, A_arbace_repr_go_convert_A_const_602.Invoke_O__O(c__6)) { tmp21 = A_arbace_repr_go_convert_A_const_603 } else { tmp21 = A_arbace_repr_go_convert_A_const_604 }; var tmp22 any = /*line :1668:1*/tmp21.Ref(); var tmp23 any; var or__1927000174__auto____10 any = A_arbace_repr_go_convert_A_const_603.Invoke_O__O(c__6); if






	jrt.J2g_Truth(or__1927000174__auto____10) { tmp23 = or__1927000174__auto____10 } else { tmp23 = A_arbace_repr_go_convert_A_const_604.Invoke_O__O(c__6) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_repr_go_convert_A_const_605; var tmp26 any = /*line :1668:1*/A_arbace_repr_go_convert_A_const_605.Invoke_O__O(c__6); var tmp27 any = A_arbace_repr_go_convert_A_const_555; var tmp28 any = A_arbace_repr_go_convert_A_const_552.Invoke_O__O(c__6); var tmp29 any = A_arbace_repr_go_convert_A_const_606; var tmp30 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_606.Invoke_O__O(c__6)); var tmp31 any = A_arbace_repr_go_convert_A_const_607; var tmp32 any = A_arbace_repr_go_convert_A_const_607.Invoke_O__O(c__6); var tmp33 any = A_arbace_repr_go_convert_A_const_608; var tmp34 any = A_arbace_repr_go_convert_A_const_608.Invoke_O__O(c__6); var tmp35 any = A_arbace_repr_go_convert_A_const_609; var tmp36 any = lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp13, tmp14, tmp15, tmp16.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp17, tmp18, tmp19, tmp20, tmp22, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, A_arbace_repr_go_convert_A_const_609.Invoke_O__O(c__6)), A_arbace_repr_go_convert_A_const_600, files__7); var tmp37 lang.IPersistentVector; if










	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(others__8)) { tmp37 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_convert_A_const_610, others__8) } else { tmp37 = nil }; var tmp38 any = tmp37; var tmp39 lang.IPersistentVector; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(embeds__9)) { var tmp40 any = A_arbace_repr_go_convert_A_const_594; tmp39 = lang.Tuple_Create_O_O__IPersistentVector(tmp40, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_168.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O(), embeds__9))) } else { tmp39 = nil }; var tmp41 any = tmp39; var tmp42 lang.IPersistentVector; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_611.Invoke_O__O(dump__0))) { var tmp43 any = A_arbace_repr_go_convert_A_const_612; tmp42 = lang.Tuple_Create_O_O__IPersistentVector(tmp43, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_611.Invoke_O__O(dump__0))) } else { tmp42 = nil }; var tmp44 any = A_arbace_repr_go_convert_A_const_588; return /*line :1668:1*/ tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp11, tmp12.Invoke_O_O_O_O_O__O(tmp36, tmp38, tmp41, tmp42, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp44, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_613.GetRawRoot__O()).Invoke_O__O(dump__0), A_arbace_repr_go_convert_A_const_590, positions__5))) }
//line :1665:1
func A_arbace_repr_go_convert_package_form_fn__1114000886_A_New_O(p0 any) *A_arbace_repr_go_convert_package_form_fn__1114000886_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_package_form_fn__1114000886_A{}; t.Ctor_O(p0); return t }
//line :1665:1
func (t *A_arbace_repr_go_convert_package_form_fn__1114000886_A) Ctor_O(c__dump any) { t.F_dump = c__dump }
//line :1665:1
func (t *A_arbace_repr_go_convert_package_form_fn__1114000886_A) Invoke_O_O__O(self, p1__1114000882_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_dump, p1__1114000882_SHARP___1) }



















func A_arbace_repr_go_convert_file_stem_A_New() *A_arbace_repr_go_convert_file_stem_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_file_stem_A{}; t.Ctor(); return t }
//line :1685:1
func (t *A_arbace_repr_go_convert_file_stem_A) Ctor() {}
//line :1685:1
func (t *A_arbace_repr_go_convert_file_stem_A) Invoke_O_O_O__O(self, name__0, src_dir__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_37.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_convert_A_const_18; var stem__3 any = tmp1.Invoke_O_O_O__O(name__0, tmp2, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(name__0)), 3)).Ref()); var tmp3 any; var and__1927000168__auto____4 any = src_dir__1; if





	jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, src_dir__1, nil, stem__3))).IsDirectory__Z()).Ref() } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) {
		lang.IFn_Cast(A_arbace_repr_go_convert_A_const_195.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_614)
//line :1691:1
		return name__0 } else { return stem__3 } }



func A_arbace_repr_go_convert_convert_package_A_New() *A_arbace_repr_go_convert_convert_package_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_A{}; t.Ctor(); return t }
//line :1695:1
func (t *A_arbace_repr_go_convert_convert_package_A) Ctor() {}
//line :1695:1
func (t *A_arbace_repr_go_convert_convert_package_A) Invoke_O_O_O__O(self, dump__0, opts__1 any) any { var stats__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_347.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;




	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; stats__3 = tmp1.Invoke_O__O(tmp2.Ref()); var ns_sym__4 any; var or__1927000174__auto____4 any = /*line :1695:1*/A_arbace_repr_go_convert_A_const_615.Invoke_O__O(opts__1); if





	jrt.J2g_Truth(or__1927000174__auto____4) { ns_sym__4 = or__1927000174__auto____4 } else { ns_sym__4 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_616.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_553.Invoke_O__O(dump__0)) }; var underlying__5 any; var tmp3 lang.IFn = /*line :1695:1*/lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap;






	lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; var tmp5 any = tmp4.Ref(); var tmp6 any; var iter__1927001039__auto____5 any; var tmp7 any = A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A_New(); var tmp8 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A_fn_class; if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A_fn_class = fncls__183d; tmp8 = fncls__183d } else { tmp8 = fncls__183 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_repr_go_convert_A_const_620.Invoke_O__O(dump__0)); underlying__5 = tmp3.Invoke_O_O__O(tmp5, tmp6); var tmp9 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_convert_A_const_621; var tmp11 any = A_arbace_repr_go_convert_A_const_12; var tmp12 any = A_arbace_repr_go_convert_A_const_148; var tmp13 any = A_arbace_repr_go_convert_A_const_622; var tmp14 any = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp13, A_arbace_repr_go_convert_A_const_590.Invoke_O__O(opts__1))).Ref(); var tmp15 any = A_arbace_repr_go_convert_A_const_557; var tmp16 any = A_arbace_repr_go_convert_A_const_623.Invoke_O__O(opts__1); var tmp17 any = A_arbace_repr_go_convert_A_const_624; var tmp18 any = A_arbace_repr_go_convert_A_const_625.Invoke_O__O(dump__0); var tmp19 any = A_arbace_repr_go_convert_A_const_626; lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp10, dump__0, tmp11, stats__3, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, A_arbace_repr_go_convert_A_const_553.Invoke_O__O(dump__0), A_arbace_repr_go_convert_A_const_627, underlying__5)); var tmp20 any; tmp30 := /*line :1695:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var files__8 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_160.GetRawRoot__O()); var tmp22 any; var iter__1927001039__auto____8 any; var tmp23 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A_New_O_O_O(ns_sym__4, dump__0, opts__1); var tmp24 *jrt.Class
		var fncls__198 /*line :1695:1*/*jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A_fn_class














		if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A_fn_class = fncls__198d; tmp24 = fncls__198d } else { tmp24 = fncls__198 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(A_arbace_repr_go_convert_A_const_600.Invoke_O__O(dump__0)); files__8 = tmp21.Invoke_O__O(tmp22)
//line :1695:1
		var tmp25 any = A_arbace_repr_go_convert_A_const_615; var tmp26 any = A_arbace_repr_go_convert_A_const_553; var tmp27 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_617.GetRawRoot__O()).Invoke_O_O__O(dump__0, opts__1); var tmp28 any = A_arbace_repr_go_convert_A_const_600; var tmp29 any = A_arbace_repr_go_convert_A_const_618; tmp20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, ns_sym__4, tmp26, tmp27, tmp28, files__8, tmp29, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_8.GetRawRoot__O()).Invoke_O__O(stats__3))) }; return nil }();







	lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if /*line :1695:1*/ tmp30 != nil { panic(tmp30) }; return tmp20 }






func A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A_New() *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A{}; t.Ctor(); return t }
//line :1702:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A) Ctor() {}
//line :1702:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A) Invoke_O_O__O(self, s__1114000891__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A_New_O_O(s__1114000891__1, self); var tmp2 *jrt.Class; var fncls__182 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A_fn_class; if fncls__182 == nil { var fncls__182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A_fn_class = fncls__182d; tmp2 = fncls__182d } else { tmp2 = fncls__182 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1702:1
func A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1702:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A) Ctor_O_O(c__s__1114000891, c__iter__1114000890 any) { t.F_s__1114000891 = c__s__1114000891; t.F_iter__1114000890 = c__iter__1114000890 }
//line :1702:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A) Invoke_O__O(self any) any { { var s__1114000891__1 any; var t_ any = t.F_s__1114000891; t.F_s__1114000891 = nil; s__1114000891__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000891__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000891__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000891__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000891__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000893__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A_New_O_I_O(b__1114000893__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A_fn_class = fncls__181d; tmp2 = fncls__181d } else { tmp2 = fncls__181 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000890); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000893__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000891__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000893__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000891__3); if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_619.Invoke_O__O(t__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1114000890); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_convert_A_const_314.Invoke_O__O(t__4), A_arbace_repr_go_convert_A_const_619.Invoke_O__O(t__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000891__3))) } else { s__1114000891__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000891__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1702:1
func A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1702:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A) Ctor_O_I_O(c__b__1114000893 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000893 = c__b__1114000893; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1702:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A) Invoke_O__O(self any) any { { var i__1114000892__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000892__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000892__1)); if jrt.J2g_Truth(A_arbace_repr_go_convert_A_const_619.Invoke_O__O(t__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000893; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_convert_A_const_314.Invoke_O__O(t__2), A_arbace_repr_go_convert_A_const_619.Invoke_O__O(t__2))); i__1114000892__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000892__1); continue L1 } else { i__1114000892__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000892__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1710:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A) Ctor_O_O_O(c__ns_sym, c__dump, c__opts any) { t.F_ns_sym = c__ns_sym; t.F_dump = c__dump; t.F_opts = c__opts }
//line :1710:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A) Invoke_O_O__O(self, s__1114000901__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A_New_O_O_O_O_O(self, t.F_ns_sym, t.F_dump, t.F_opts, s__1114000901__1); var tmp2 *jrt.Class; var fncls__197 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A_fn_class; if fncls__197 == nil { var fncls__197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A_fn_class = fncls__197d; tmp2 = fncls__197d } else { tmp2 = fncls__197 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1710:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1710:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A) Ctor_O_O_O_O_O(c__iter__1114000900, c__ns_sym, c__dump, c__opts, c__s__1114000901 any) { t.F_iter__1114000900 = c__iter__1114000900; t.F_ns_sym = c__ns_sym; t.F_dump = c__dump; t.F_opts = c__opts; t.F_s__1114000901 = c__s__1114000901 }
//line :1710:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A) Invoke_O__O(self any) any { { var s__1114000901__1 any; var t_ any = t.F_s__1114000901; t.F_s__1114000901 = nil; s__1114000901__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000901__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000901__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000901__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000901__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000903__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A_New_O_O_O_I_O_O(t.F_ns_sym, b__1114000903__6, t.F_dump, size__1927001038__auto____5, t.F_opts, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__190 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A_fn_class; if fncls__190 == nil { var fncls__190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A_fn_class = fncls__190d; tmp2 = fncls__190d } else { tmp2 = fncls__190 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000900); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000903__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000901__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000903__6), nil) } } else { var fe__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000901__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()); var tmp5 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_convert_A_const_632; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()); var tmp10 *lang.PersistentArrayMap
																lang.PersistentArrayMap_Init(); tmp10 = lang.PersistentArrayMap_EMPTY; var tmp11 any = tmp10.Ref(); var tmp12 any; var iter__1927001039__auto____5 any; var tmp13 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A_New(); var tmp14 *jrt.Class; var fncls__196 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A_fn_class
																if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A_fn_class = fncls__196d; tmp14 = fncls__196d } else { tmp14 = fncls__196 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var tmp15 *lang.Keyword = A_arbace_repr_go_convert_A_const_544; tmp12 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_542.Invoke_O__O(fe__4))))
//line :1711:1
	tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(tmp11, tmp12))); var tmp16 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A_New_O_O_O_O(t.F_ns_sym, t.F_dump, fe__4, t.F_opts); var tmp17 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A_fn_class; if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A_fn_class = fncls__191d; tmp17 = fncls__191d } else { tmp17 = fncls__191 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O()
//line :1710:1
	var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__1114000900); return tmp4.Invoke_O_O__O(tmp5, tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000901__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1710:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1710:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A) Ctor_O_O_O_I_O_O(c__ns_sym, c__b__1114000903, c__dump any, c__size__1927001038__auto__ int32, c__opts, c__c__1927001037__auto__ any) { t.F_ns_sym = c__ns_sym; t.F_b__1114000903 = c__b__1114000903; t.F_dump = c__dump; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_opts = c__opts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1710:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A) Invoke_O__O(self any) any { { var i__1114000902__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000902__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fe__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000902__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp3 any = t.F_b__1114000903; var tmp4 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_308.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_309.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_convert_A_const_632; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_126.GetRawRoot__O()); var tmp9 *lang.PersistentArrayMap
																		lang.PersistentArrayMap_Init(); tmp9 = lang.PersistentArrayMap_EMPTY; var tmp10 any = tmp9.Ref(); var tmp11 any; var iter__1927001039__auto____3 any; var tmp12 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A_New(); var tmp13 *jrt.Class; var fncls__189 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A_fn_class
																		if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A_fn_class = fncls__189d; tmp13 = fncls__189d } else { tmp13 = fncls__189 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 *lang.Keyword = A_arbace_repr_go_convert_A_const_544; tmp11 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_convert_A_const_542.Invoke_O__O(fe__2))))
//line :1711:1
	tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp10, tmp11))); var tmp15 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A_New_O_O_O_O(t.F_ns_sym, t.F_dump, fe__2, t.F_opts); var tmp16 *jrt.Class; var fncls__184 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A_fn_class; if fncls__184 == nil { var fncls__184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A_fn_class = fncls__184d; tmp16 = fncls__184d } else { tmp16 = fncls__184 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :1710:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1114000902__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000902__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1711:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A) Ctor_O_O_O_O(c__ns_sym, c__dump, c__fe, c__opts any) { t.F_ns_sym = c__ns_sym; t.F_dump = c__dump; t.F_fe = c__fe; t.F_opts = c__opts }
//line :1711:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_628.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_dump; t.F_dump = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = t.F_fe; var tmp7 any; var t__2 any = t.F_ns_sym; t.F_ns_sym = nil; tmp7 = t__2; var tmp8 any = tmp3.Invoke_O_O_O__O(tmp5, tmp6, tmp7); var tmp9 any = A_arbace_repr_go_convert_A_const_629; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_630.GetRawRoot__O()); var tmp11 *lang.Keyword = A_arbace_repr_go_convert_A_const_543; var tmp12 any; var t__3 any = t.F_fe
		t.F_fe = nil; tmp12 = t__3
//line :1718:1
		var tmp13 any = tmp11.Invoke_O__O(tmp12); var tmp14 *lang.Keyword = A_arbace_repr_go_convert_A_const_631; var tmp15 any; var t__4 any = t.F_opts
		t.F_opts = nil; tmp15 = t__4
//line :1718:1
		tmp1 = tmp2.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O__O(tmp13, tmp14.Invoke_O__O(tmp15))) }
//line :1711:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp16 != nil { panic(tmp16) }; return tmp1 }
//line :1711:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1711:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A) Ctor_O_O_O_O(c__ns_sym, c__dump, c__fe, c__opts any) { t.F_ns_sym = c__ns_sym; t.F_dump = c__dump; t.F_fe = c__fe; t.F_opts = c__opts }
//line :1711:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_141.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_628.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_dump; t.F_dump = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = t.F_fe; var tmp7 any; var t__2 any = t.F_ns_sym; t.F_ns_sym = nil; tmp7 = t__2; var tmp8 any = tmp3.Invoke_O_O_O__O(tmp5, tmp6, tmp7); var tmp9 any = A_arbace_repr_go_convert_A_const_629; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_630.GetRawRoot__O()); var tmp11 *lang.Keyword = A_arbace_repr_go_convert_A_const_543; var tmp12 any; var t__3 any = t.F_fe
		t.F_fe = nil; tmp12 = t__3
//line :1718:1
		var tmp13 any = tmp11.Invoke_O__O(tmp12); var tmp14 *lang.Keyword = A_arbace_repr_go_convert_A_const_631; var tmp15 any; var t__4 any = t.F_opts
		t.F_opts = nil; tmp15 = t__4
//line :1718:1
		tmp1 = tmp2.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O__O(tmp13, tmp14.Invoke_O__O(tmp15))) }
//line :1711:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_convert_A_const_307.GetRawRoot__O()).Invoke__O(); if tmp16 != nil { panic(tmp16) }; return tmp1 }
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A_New() *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A{}; t.Ctor(); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A) Ctor() {}
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A) Invoke_O_O__O(self, s__1114000908__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A_New_O_O(s__1114000908__1, self); var tmp2 *jrt.Class; var fncls__188 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A_fn_class; if fncls__188 == nil { var fncls__188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A_fn_class = fncls__188d; tmp2 = fncls__188d } else { tmp2 = fncls__188 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A) Ctor_O_O(c__s__1114000908, c__iter__1114000907 any) { t.F_s__1114000908 = c__s__1114000908; t.F_iter__1114000907 = c__iter__1114000907 }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A) Invoke_O__O(self any) any { { var s__1114000908__1 any; var t_ any = t.F_s__1114000908; t.F_s__1114000908 = nil; s__1114000908__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000908__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp1 bool; var tmp2 any = A_arbace_repr_go_convert_A_const_90; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__4))
																							if and__1927000168__auto____5 { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; tmp1 = lang.Util_Equiv_O_O__Z(Lit_54, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__4))) } else { tmp1 = and__1927000168__auto____5 }
//line :1712:1
	if tmp1 { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A_New(); var tmp5 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A_fn_class; if fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A_fn_class = fncls__187d; tmp5 = fncls__187d } else { tmp5 = fncls__187 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_393; var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__4)))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1114000907); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000908__1))) } else { s__1114000908__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000908__1); continue L1 } } else { s__1114000908__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000908__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A_New() *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A{}; t.Ctor(); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A) Ctor() {}
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A) Invoke_O_O__O(self, s__1114000910__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A_New_O_O(self, s__1114000910__1); var tmp2 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A_fn_class = fncls__186d; tmp2 = fncls__186d } else { tmp2 = fncls__186 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A) Ctor_O_O(c__iter__1114000909, c__s__1114000910 any) { t.F_iter__1114000909 = c__iter__1114000909; t.F_s__1114000910 = c__s__1114000910 }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A) Invoke_O__O(self any) any { { var s__1114000910__1 any; var t_ any = t.F_s__1114000910; t.F_s__1114000910 = nil; s__1114000910__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000910__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000910__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000910__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000910__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000912__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A_New_O_I_O(b__1114000912__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A_fn_class; if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A_fn_class = fncls__185d; tmp2 = fncls__185d } else { tmp2 = fncls__185 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000909); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000912__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000910__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000912__6), nil) } } else { var sp__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000910__3); var nm__5 any; var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var temp__1927000408__auto____5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__4))


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5; nm__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(n__6) } else { var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_522; nm__5 = tmp5.Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(sp__4))) }
//line :1712:1
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_634).Invoke_O__O(nm__5))) { var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_51; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1114000909); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_247.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__4))), nm__5), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000910__3))) } else { s__1114000910__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000910__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A) Ctor_O_I_O(c__b__1114000912 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000912 = c__b__1114000912; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A) Invoke_O__O(self any) any { { var i__1114000911__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000911__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sp__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000911__1)); var nm__3 any; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__2))


	if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; nm__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(n__4) } else { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_522; nm__3 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(sp__2))) }
//line :1712:1
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_633).Invoke_O__O(nm__3))) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp6 any = t.F_b__1114000912; var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_51; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_247.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__2))), nm__3)); i__1114000911__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000911__1); continue L1 } else { i__1114000911__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000911__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A_New() *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A{}; t.Ctor(); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A) Ctor() {}
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A) Invoke_O_O__O(self, s__1114000927__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A_New_O_O(s__1114000927__1, self); var tmp2 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A_fn_class; if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A_fn_class = fncls__195d; tmp2 = fncls__195d } else { tmp2 = fncls__195 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A) Ctor_O_O(c__s__1114000927, c__iter__1114000926 any) { t.F_s__1114000927 = c__s__1114000927; t.F_iter__1114000926 = c__iter__1114000926 }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A) Invoke_O__O(self any) any { { var s__1114000927__1 any; var t_ any = t.F_s__1114000927; t.F_s__1114000927 = nil; s__1114000927__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000927__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp1 bool; var tmp2 any = A_arbace_repr_go_convert_A_const_90; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_convert_A_const_33.GetRawRoot__O()).Invoke_O__O(d__4))
																					if and__1927000168__auto____5 { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_392; tmp1 = lang.Util_Equiv_O_O__Z(Lit_54, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__4))) } else { tmp1 = and__1927000168__auto____5 }
//line :1712:1
	if tmp1 { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A_New(); var tmp5 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A_fn_class = fncls__194d; tmp5 = fncls__194d } else { tmp5 = fncls__194 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_393; var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(d__4)))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1114000926); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_243.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000927__1))) } else { s__1114000927__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000927__1); continue L1 } } else { s__1114000927__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000927__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A_New() *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A{}; t.Ctor(); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A) Ctor() {}
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A) Invoke_O_O__O(self, s__1114000929__1 any) any { var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A_New_O_O(s__1114000929__1, self); var tmp2 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A_fn_class = fncls__193d; tmp2 = fncls__193d } else { tmp2 = fncls__193 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A_New_O_O(p0, p1 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A) Ctor_O_O(c__s__1114000929, c__iter__1114000928 any) { t.F_s__1114000929 = c__s__1114000929; t.F_iter__1114000928 = c__iter__1114000928 }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A) Invoke_O__O(self any) any { { var s__1114000929__1 any; var t_ any = t.F_s__1114000929; t.F_s__1114000929 = nil; s__1114000929__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1114000929__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1114000929__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__1114000929__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(s__1114000929__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1114000931__6 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_251.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A_New_O_I_O(b__1114000931__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__192 *jrt.Class = A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A_fn_class; if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A_fn_class = fncls__192d; tmp2 = fncls__192d } else { tmp2 = fncls__192 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1114000928); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000931__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(s__1114000929__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_254.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_255.GetRawRoot__O()).Invoke_O__O(b__1114000931__6), nil) } } else { var sp__4 any = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1114000929__3); var nm__5 any; var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var temp__1927000408__auto____5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__4))


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5; nm__5 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(n__6) } else { var tmp5 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var tmp6 *lang.Keyword = A_arbace_repr_go_convert_A_const_522; nm__5 = tmp5.Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(sp__4))) }
//line :1712:1
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_636).Invoke_O__O(nm__5))) { var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_51; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1114000928); return lang.IFn_Cast(A_arbace_repr_go_convert_A_const_228.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_247.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__4))), nm__5), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000929__3))) } else { s__1114000929__1 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_214.GetRawRoot__O()).Invoke_O__O(s__1114000929__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1712:1
func A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A) Ctor_O_I_O(c__b__1114000931 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1114000931 = c__b__1114000931; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1712:1
func (t *A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A) Invoke_O__O(self any) any { { var i__1114000930__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1114000930__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sp__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1114000930__1)); var nm__3 any; var tmp2 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__2))


	if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; nm__3 = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_180.GetRawRoot__O()).Invoke_O__O(n__4) } else { var tmp3 *lang.Keyword = A_arbace_repr_go_convert_A_const_49; var tmp4 *lang.Keyword = A_arbace_repr_go_convert_A_const_522; nm__3 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_172.GetRawRoot__O()).Invoke_O__O(sp__2))) }
//line :1712:1
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_635).Invoke_O__O(nm__3))) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_convert_A_const_252.GetRawRoot__O()); var tmp6 any = t.F_b__1114000931; var tmp7 *lang.Keyword = A_arbace_repr_go_convert_A_const_51; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_247.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_convert_A_const_35.GetRawRoot__O()).Invoke_O__O(sp__2))), nm__3)); i__1114000930__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000930__1); continue L1 } else { i__1114000930__1 = lang.Numbers_Unchecked_inc_J__J(i__1114000930__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






































































































































































































































































































































































































type A_arbace_repr_go_convert_A struct{ jrt.Object }

var A_arbace_repr_go_convert_A_const_pool *jrt.RefArray

var A_arbace_repr_go_convert_A_const_0 *lang.Var

var A_arbace_repr_go_convert_A_const_1 *lang.Var

var A_arbace_repr_go_convert_A_const_2 any

var A_arbace_repr_go_convert_A_const_3 any

var A_arbace_repr_go_convert_A_const_4 any

var A_arbace_repr_go_convert_A_const_5 any

var A_arbace_repr_go_convert_A_const_6 any

var A_arbace_repr_go_convert_A_const_7 *lang.Var

var A_arbace_repr_go_convert_A_const_8 *lang.Var

var A_arbace_repr_go_convert_A_const_9 *lang.Var

var A_arbace_repr_go_convert_A_const_10 any

var A_arbace_repr_go_convert_A_const_11 *lang.Var

var A_arbace_repr_go_convert_A_const_12 *lang.Var

var A_arbace_repr_go_convert_A_const_13 *lang.Var

var A_arbace_repr_go_convert_A_const_14 *lang.Var

var A_arbace_repr_go_convert_A_const_15 *lang.Var

var A_arbace_repr_go_convert_A_const_16 *lang.Keyword

var A_arbace_repr_go_convert_A_const_17 *lang.Var

var A_arbace_repr_go_convert_A_const_18 any

var A_arbace_repr_go_convert_A_const_19 *lang.Keyword

var A_arbace_repr_go_convert_A_const_20 *lang.Var

var A_arbace_repr_go_convert_A_const_21 *lang.Var

var A_arbace_repr_go_convert_A_const_22 *lang.Var

var A_arbace_repr_go_convert_A_const_23 *lang.Var

var A_arbace_repr_go_convert_A_const_24 *lang.Var

var A_arbace_repr_go_convert_A_const_25 *lang.Var

var A_arbace_repr_go_convert_A_const_26 *lang.Var

var A_arbace_repr_go_convert_A_const_27 *lang.Keyword

var A_arbace_repr_go_convert_A_const_28 *lang.Var

var A_arbace_repr_go_convert_A_const_29 *lang.Var

var A_arbace_repr_go_convert_A_const_30 *lang.Var

var A_arbace_repr_go_convert_A_const_31 any

var A_arbace_repr_go_convert_A_const_32 *lang.Keyword

var A_arbace_repr_go_convert_A_const_33 *lang.Var

var A_arbace_repr_go_convert_A_const_34 *lang.Keyword

var A_arbace_repr_go_convert_A_const_35 *lang.Var

var A_arbace_repr_go_convert_A_const_36 any

var A_arbace_repr_go_convert_A_const_37 *lang.Var

var A_arbace_repr_go_convert_A_const_38 *lang.Var

var A_arbace_repr_go_convert_A_const_39 *lang.Keyword

var A_arbace_repr_go_convert_A_const_40 *lang.Var

var A_arbace_repr_go_convert_A_const_41 *lang.Keyword

var A_arbace_repr_go_convert_A_const_42 *lang.Keyword

var A_arbace_repr_go_convert_A_const_43 *lang.Keyword

var A_arbace_repr_go_convert_A_const_44 *lang.Keyword

var A_arbace_repr_go_convert_A_const_45 *lang.Keyword

var A_arbace_repr_go_convert_A_const_46 *lang.Var

var A_arbace_repr_go_convert_A_const_47 *lang.Keyword

var A_arbace_repr_go_convert_A_const_48 *lang.Keyword

var A_arbace_repr_go_convert_A_const_49 *lang.Keyword

var A_arbace_repr_go_convert_A_const_50 *lang.Keyword

var A_arbace_repr_go_convert_A_const_51 *lang.Keyword

var A_arbace_repr_go_convert_A_const_52 *lang.Keyword

var A_arbace_repr_go_convert_A_const_53 *lang.Keyword

var A_arbace_repr_go_convert_A_const_54 *lang.Keyword

var A_arbace_repr_go_convert_A_const_55 *lang.Keyword

var A_arbace_repr_go_convert_A_const_56 *lang.Keyword

var A_arbace_repr_go_convert_A_const_57 *lang.Keyword

var A_arbace_repr_go_convert_A_const_58 *lang.Keyword

var A_arbace_repr_go_convert_A_const_59 *lang.Keyword

var A_arbace_repr_go_convert_A_const_60 *lang.Keyword

var A_arbace_repr_go_convert_A_const_61 *lang.Keyword

var A_arbace_repr_go_convert_A_const_62 *lang.Keyword

var A_arbace_repr_go_convert_A_const_63 *lang.Keyword

var A_arbace_repr_go_convert_A_const_64 *lang.Keyword

var A_arbace_repr_go_convert_A_const_65 *lang.Var

var A_arbace_repr_go_convert_A_const_66 *lang.Keyword

var A_arbace_repr_go_convert_A_const_67 *lang.Keyword

var A_arbace_repr_go_convert_A_const_68 *lang.Keyword

var A_arbace_repr_go_convert_A_const_69 *lang.Keyword

var A_arbace_repr_go_convert_A_const_70 *lang.Keyword

var A_arbace_repr_go_convert_A_const_71 *lang.Keyword

var A_arbace_repr_go_convert_A_const_72 *lang.Keyword

var A_arbace_repr_go_convert_A_const_73 *lang.Keyword

var A_arbace_repr_go_convert_A_const_74 *lang.Keyword

var A_arbace_repr_go_convert_A_const_75 *lang.Keyword

var A_arbace_repr_go_convert_A_const_76 *lang.Keyword

var A_arbace_repr_go_convert_A_const_77 *lang.Keyword

var A_arbace_repr_go_convert_A_const_78 *lang.Keyword

var A_arbace_repr_go_convert_A_const_79 *lang.Keyword

var A_arbace_repr_go_convert_A_const_80 *lang.Keyword

var A_arbace_repr_go_convert_A_const_81 *lang.Keyword

var A_arbace_repr_go_convert_A_const_82 *lang.Keyword

var A_arbace_repr_go_convert_A_const_83 *lang.Keyword

var A_arbace_repr_go_convert_A_const_84 *lang.Keyword

var A_arbace_repr_go_convert_A_const_85 *lang.Keyword

var A_arbace_repr_go_convert_A_const_86 *lang.Keyword

var A_arbace_repr_go_convert_A_const_87 *lang.Keyword

var A_arbace_repr_go_convert_A_const_88 *lang.Keyword

var A_arbace_repr_go_convert_A_const_89 *lang.Keyword

var A_arbace_repr_go_convert_A_const_90 *lang.Keyword

var A_arbace_repr_go_convert_A_const_91 *lang.Keyword

var A_arbace_repr_go_convert_A_const_92 *lang.Keyword

var A_arbace_repr_go_convert_A_const_93 *lang.Keyword

var A_arbace_repr_go_convert_A_const_94 *lang.Keyword

var A_arbace_repr_go_convert_A_const_95 *lang.Keyword

var A_arbace_repr_go_convert_A_const_96 *lang.Keyword

var A_arbace_repr_go_convert_A_const_97 *lang.Keyword

var A_arbace_repr_go_convert_A_const_98 *lang.Keyword

var A_arbace_repr_go_convert_A_const_99 *lang.Keyword

var A_arbace_repr_go_convert_A_const_100 *lang.Keyword

var A_arbace_repr_go_convert_A_const_101 *lang.Keyword

var A_arbace_repr_go_convert_A_const_102 *lang.Keyword

var A_arbace_repr_go_convert_A_const_103 *lang.Keyword

var A_arbace_repr_go_convert_A_const_104 *lang.Keyword

var A_arbace_repr_go_convert_A_const_105 *lang.Keyword

var A_arbace_repr_go_convert_A_const_106 *lang.Keyword

var A_arbace_repr_go_convert_A_const_107 *lang.Keyword

var A_arbace_repr_go_convert_A_const_108 *lang.Keyword

var A_arbace_repr_go_convert_A_const_109 *lang.Keyword

var A_arbace_repr_go_convert_A_const_110 *lang.Keyword

var A_arbace_repr_go_convert_A_const_111 *lang.Keyword

var A_arbace_repr_go_convert_A_const_112 *lang.Keyword

var A_arbace_repr_go_convert_A_const_113 *lang.Keyword

var A_arbace_repr_go_convert_A_const_114 *lang.Keyword

var A_arbace_repr_go_convert_A_const_115 *lang.Keyword

var A_arbace_repr_go_convert_A_const_116 *lang.Keyword

var A_arbace_repr_go_convert_A_const_117 *lang.Keyword

var A_arbace_repr_go_convert_A_const_118 *lang.Keyword

var A_arbace_repr_go_convert_A_const_119 *lang.Keyword

var A_arbace_repr_go_convert_A_const_120 *lang.Keyword

var A_arbace_repr_go_convert_A_const_121 *lang.Keyword

var A_arbace_repr_go_convert_A_const_122 *lang.Keyword

var A_arbace_repr_go_convert_A_const_123 *lang.Keyword

var A_arbace_repr_go_convert_A_const_124 *lang.Keyword

var A_arbace_repr_go_convert_A_const_125 *lang.Var

var A_arbace_repr_go_convert_A_const_126 *lang.Var

var A_arbace_repr_go_convert_A_const_127 *lang.Var

var A_arbace_repr_go_convert_A_const_128 *lang.Var

var A_arbace_repr_go_convert_A_const_129 *lang.Var

var A_arbace_repr_go_convert_A_const_130 *lang.Var

var A_arbace_repr_go_convert_A_const_131 *lang.Var

var A_arbace_repr_go_convert_A_const_132 *lang.Var

var A_arbace_repr_go_convert_A_const_133 *lang.Var

var A_arbace_repr_go_convert_A_const_134 *lang.Var

var A_arbace_repr_go_convert_A_const_135 *lang.Var

var A_arbace_repr_go_convert_A_const_136 *lang.Var

var A_arbace_repr_go_convert_A_const_137 any

var A_arbace_repr_go_convert_A_const_138 *lang.Var

var A_arbace_repr_go_convert_A_const_139 *lang.Var

var A_arbace_repr_go_convert_A_const_140 *lang.Keyword

var A_arbace_repr_go_convert_A_const_141 *lang.Var

var A_arbace_repr_go_convert_A_const_142 *lang.Var

var A_arbace_repr_go_convert_A_const_143 *lang.Keyword

var A_arbace_repr_go_convert_A_const_144 *lang.Var

var A_arbace_repr_go_convert_A_const_145 *lang.Var

var A_arbace_repr_go_convert_A_const_146 *lang.Var

var A_arbace_repr_go_convert_A_const_147 *lang.Var

var A_arbace_repr_go_convert_A_const_148 *lang.Var

var A_arbace_repr_go_convert_A_const_149 *lang.Keyword

var A_arbace_repr_go_convert_A_const_150 *lang.Var

var A_arbace_repr_go_convert_A_const_151 *lang.Var

var A_arbace_repr_go_convert_A_const_152 *lang.Keyword

var A_arbace_repr_go_convert_A_const_153 *lang.Keyword

var A_arbace_repr_go_convert_A_const_154 *lang.Keyword

var A_arbace_repr_go_convert_A_const_155 any

var A_arbace_repr_go_convert_A_const_156 *lang.Var

var A_arbace_repr_go_convert_A_const_157 *lang.Var

var A_arbace_repr_go_convert_A_const_158 *lang.Keyword

var A_arbace_repr_go_convert_A_const_159 *lang.Var

var A_arbace_repr_go_convert_A_const_160 *lang.Var

var A_arbace_repr_go_convert_A_const_161 *lang.Var

var A_arbace_repr_go_convert_A_const_162 *lang.Keyword

var A_arbace_repr_go_convert_A_const_163 *lang.Keyword

var A_arbace_repr_go_convert_A_const_164 *lang.Var

var A_arbace_repr_go_convert_A_const_165 *lang.Keyword

var A_arbace_repr_go_convert_A_const_166 *lang.Keyword

var A_arbace_repr_go_convert_A_const_167 *lang.Var

var A_arbace_repr_go_convert_A_const_168 *lang.Var

var A_arbace_repr_go_convert_A_const_169 *lang.Var

var A_arbace_repr_go_convert_A_const_170 *lang.Var

var A_arbace_repr_go_convert_A_const_171 *lang.Keyword

var A_arbace_repr_go_convert_A_const_172 *lang.Var

var A_arbace_repr_go_convert_A_const_173 *lang.Keyword

var A_arbace_repr_go_convert_A_const_174 *lang.Var

var A_arbace_repr_go_convert_A_const_175 *lang.Keyword

var A_arbace_repr_go_convert_A_const_176 *lang.Keyword

var A_arbace_repr_go_convert_A_const_177 *lang.Var

var A_arbace_repr_go_convert_A_const_178 *lang.Keyword

var A_arbace_repr_go_convert_A_const_179 *lang.Var

var A_arbace_repr_go_convert_A_const_180 *lang.Var

var A_arbace_repr_go_convert_A_const_181 *lang.Var

var A_arbace_repr_go_convert_A_const_182 *lang.Var

var A_arbace_repr_go_convert_A_const_183 any

var A_arbace_repr_go_convert_A_const_184 *lang.Keyword

var A_arbace_repr_go_convert_A_const_185 *lang.Keyword

var A_arbace_repr_go_convert_A_const_186 *lang.Keyword

var A_arbace_repr_go_convert_A_const_187 *lang.Keyword

var A_arbace_repr_go_convert_A_const_188 *lang.Var

var A_arbace_repr_go_convert_A_const_189 *lang.Var

var A_arbace_repr_go_convert_A_const_190 *lang.Var

var A_arbace_repr_go_convert_A_const_191 *lang.Var

var A_arbace_repr_go_convert_A_const_192 *lang.Var

var A_arbace_repr_go_convert_A_const_193 *lang.Var

var A_arbace_repr_go_convert_A_const_194 any

var A_arbace_repr_go_convert_A_const_195 *lang.Var

var A_arbace_repr_go_convert_A_const_196 *lang.Keyword

var A_arbace_repr_go_convert_A_const_197 any

var A_arbace_repr_go_convert_A_const_198 *lang.Var

var A_arbace_repr_go_convert_A_const_199 *lang.Var

var A_arbace_repr_go_convert_A_const_200 *lang.Var

var A_arbace_repr_go_convert_A_const_201 *lang.Var

var A_arbace_repr_go_convert_A_const_202 *lang.Keyword

var A_arbace_repr_go_convert_A_const_203 *lang.Var

var A_arbace_repr_go_convert_A_const_204 *lang.Var

var A_arbace_repr_go_convert_A_const_205 *lang.Keyword

var A_arbace_repr_go_convert_A_const_206 *lang.Keyword

var A_arbace_repr_go_convert_A_const_207 *lang.Var

var A_arbace_repr_go_convert_A_const_208 *lang.Var

var A_arbace_repr_go_convert_A_const_209 *lang.Var

var A_arbace_repr_go_convert_A_const_210 *lang.Var

var A_arbace_repr_go_convert_A_const_211 *lang.Var

var A_arbace_repr_go_convert_A_const_212 *lang.Var

var A_arbace_repr_go_convert_A_const_213 *lang.Var

var A_arbace_repr_go_convert_A_const_214 *lang.Var

var A_arbace_repr_go_convert_A_const_215 *lang.Var

var A_arbace_repr_go_convert_A_const_216 *lang.Var

var A_arbace_repr_go_convert_A_const_217 *lang.Var

var A_arbace_repr_go_convert_A_const_218 *lang.Var

var A_arbace_repr_go_convert_A_const_219 *lang.Var

var A_arbace_repr_go_convert_A_const_220 *lang.Var

var A_arbace_repr_go_convert_A_const_221 any

var A_arbace_repr_go_convert_A_const_222 *lang.Var

var A_arbace_repr_go_convert_A_const_223 *lang.Var

var A_arbace_repr_go_convert_A_const_224 *lang.Var

var A_arbace_repr_go_convert_A_const_225 *lang.Var

var A_arbace_repr_go_convert_A_const_226 *lang.Keyword

var A_arbace_repr_go_convert_A_const_227 *lang.Var

var A_arbace_repr_go_convert_A_const_228 *lang.Var

var A_arbace_repr_go_convert_A_const_229 *lang.Keyword

var A_arbace_repr_go_convert_A_const_230 *lang.Var

var A_arbace_repr_go_convert_A_const_231 *lang.Var

var A_arbace_repr_go_convert_A_const_232 *lang.Keyword

var A_arbace_repr_go_convert_A_const_233 *lang.Var

var A_arbace_repr_go_convert_A_const_234 *lang.Var

var A_arbace_repr_go_convert_A_const_235 *lang.Keyword

var A_arbace_repr_go_convert_A_const_236 *lang.Var

var A_arbace_repr_go_convert_A_const_237 *lang.Var

var A_arbace_repr_go_convert_A_const_238 *lang.Keyword

var A_arbace_repr_go_convert_A_const_239 *lang.Var

var A_arbace_repr_go_convert_A_const_240 *lang.Var

var A_arbace_repr_go_convert_A_const_241 *lang.Keyword

var A_arbace_repr_go_convert_A_const_242 *lang.Keyword

var A_arbace_repr_go_convert_A_const_243 *lang.Var

var A_arbace_repr_go_convert_A_const_244 any

var A_arbace_repr_go_convert_A_const_245 *lang.Keyword

var A_arbace_repr_go_convert_A_const_246 *lang.Keyword

var A_arbace_repr_go_convert_A_const_247 *lang.Var

var A_arbace_repr_go_convert_A_const_248 *lang.Var

var A_arbace_repr_go_convert_A_const_249 any

var A_arbace_repr_go_convert_A_const_250 *lang.Var

var A_arbace_repr_go_convert_A_const_251 *lang.Var

var A_arbace_repr_go_convert_A_const_252 *lang.Var

var A_arbace_repr_go_convert_A_const_253 *lang.Var

var A_arbace_repr_go_convert_A_const_254 *lang.Var

var A_arbace_repr_go_convert_A_const_255 *lang.Var

var A_arbace_repr_go_convert_A_const_256 *lang.Var

var A_arbace_repr_go_convert_A_const_257 *lang.Keyword

var A_arbace_repr_go_convert_A_const_258 *lang.Keyword

var A_arbace_repr_go_convert_A_const_259 *lang.Keyword

var A_arbace_repr_go_convert_A_const_260 *lang.Keyword

var A_arbace_repr_go_convert_A_const_261 *lang.Var

var A_arbace_repr_go_convert_A_const_262 *lang.Var

var A_arbace_repr_go_convert_A_const_263 *lang.Var

var A_arbace_repr_go_convert_A_const_264 any

var A_arbace_repr_go_convert_A_const_265 any

var A_arbace_repr_go_convert_A_const_266 any

var A_arbace_repr_go_convert_A_const_267 any

var A_arbace_repr_go_convert_A_const_268 *lang.Keyword

var A_arbace_repr_go_convert_A_const_269 any

var A_arbace_repr_go_convert_A_const_270 *lang.Var

var A_arbace_repr_go_convert_A_const_271 *lang.Keyword

var A_arbace_repr_go_convert_A_const_272 *lang.Keyword

var A_arbace_repr_go_convert_A_const_273 *lang.Keyword

var A_arbace_repr_go_convert_A_const_274 any

var A_arbace_repr_go_convert_A_const_275 *lang.Keyword

var A_arbace_repr_go_convert_A_const_276 any

var A_arbace_repr_go_convert_A_const_277 *lang.Var

var A_arbace_repr_go_convert_A_const_278 *lang.Keyword

var A_arbace_repr_go_convert_A_const_279 any

var A_arbace_repr_go_convert_A_const_280 *lang.Keyword

var A_arbace_repr_go_convert_A_const_281 any

var A_arbace_repr_go_convert_A_const_282 any

var A_arbace_repr_go_convert_A_const_283 any

var A_arbace_repr_go_convert_A_const_284 any

var A_arbace_repr_go_convert_A_const_285 *lang.Var

var A_arbace_repr_go_convert_A_const_286 any

var A_arbace_repr_go_convert_A_const_287 *lang.Var

var A_arbace_repr_go_convert_A_const_288 any

var A_arbace_repr_go_convert_A_const_289 *lang.Keyword

var A_arbace_repr_go_convert_A_const_290 *lang.Keyword

var A_arbace_repr_go_convert_A_const_291 *lang.Keyword

var A_arbace_repr_go_convert_A_const_292 any

var A_arbace_repr_go_convert_A_const_293 *lang.Keyword

var A_arbace_repr_go_convert_A_const_294 *lang.Keyword

var A_arbace_repr_go_convert_A_const_295 *lang.Var

var A_arbace_repr_go_convert_A_const_296 any

var A_arbace_repr_go_convert_A_const_297 any

var A_arbace_repr_go_convert_A_const_298 any

var A_arbace_repr_go_convert_A_const_299 *lang.Var

var A_arbace_repr_go_convert_A_const_300 any

var A_arbace_repr_go_convert_A_const_301 any

var A_arbace_repr_go_convert_A_const_302 *lang.Keyword

var A_arbace_repr_go_convert_A_const_303 *lang.Keyword

var A_arbace_repr_go_convert_A_const_304 any

var A_arbace_repr_go_convert_A_const_305 *lang.Var

var A_arbace_repr_go_convert_A_const_306 any

var A_arbace_repr_go_convert_A_const_307 *lang.Var

var A_arbace_repr_go_convert_A_const_308 *lang.Var

var A_arbace_repr_go_convert_A_const_309 *lang.Var

var A_arbace_repr_go_convert_A_const_310 *lang.Var

var A_arbace_repr_go_convert_A_const_311 *lang.Keyword

var A_arbace_repr_go_convert_A_const_312 any

var A_arbace_repr_go_convert_A_const_313 *lang.Var

var A_arbace_repr_go_convert_A_const_314 *lang.Keyword

var A_arbace_repr_go_convert_A_const_315 *lang.Var

var A_arbace_repr_go_convert_A_const_316 any

var A_arbace_repr_go_convert_A_const_317 *lang.Keyword

var A_arbace_repr_go_convert_A_const_318 any

var A_arbace_repr_go_convert_A_const_319 any

var A_arbace_repr_go_convert_A_const_320 *lang.Keyword

var A_arbace_repr_go_convert_A_const_321 *lang.Keyword

var A_arbace_repr_go_convert_A_const_322 *lang.Keyword

var A_arbace_repr_go_convert_A_const_323 any

var A_arbace_repr_go_convert_A_const_324 any

var A_arbace_repr_go_convert_A_const_325 *lang.Var

var A_arbace_repr_go_convert_A_const_326 *lang.Var

var A_arbace_repr_go_convert_A_const_327 *lang.Var

var A_arbace_repr_go_convert_A_const_328 any

var A_arbace_repr_go_convert_A_const_329 *lang.Var

var A_arbace_repr_go_convert_A_const_330 *lang.Var

var A_arbace_repr_go_convert_A_const_331 any

var A_arbace_repr_go_convert_A_const_332 *lang.Keyword

var A_arbace_repr_go_convert_A_const_333 *lang.Var

var A_arbace_repr_go_convert_A_const_334 any

var A_arbace_repr_go_convert_A_const_335 any

var A_arbace_repr_go_convert_A_const_336 any

var A_arbace_repr_go_convert_A_const_337 *lang.Keyword

var A_arbace_repr_go_convert_A_const_338 *lang.Var

var A_arbace_repr_go_convert_A_const_339 *lang.Keyword

var A_arbace_repr_go_convert_A_const_340 any

var A_arbace_repr_go_convert_A_const_341 any

var A_arbace_repr_go_convert_A_const_342 any

var A_arbace_repr_go_convert_A_const_343 *lang.Keyword

var A_arbace_repr_go_convert_A_const_344 any

var A_arbace_repr_go_convert_A_const_345 *lang.Keyword

var A_arbace_repr_go_convert_A_const_346 *lang.Var

var A_arbace_repr_go_convert_A_const_347 *lang.Var

var A_arbace_repr_go_convert_A_const_348 *lang.Var

var A_arbace_repr_go_convert_A_const_349 *lang.Var

var A_arbace_repr_go_convert_A_const_350 *lang.Keyword

var A_arbace_repr_go_convert_A_const_351 *lang.Var

var A_arbace_repr_go_convert_A_const_352 *lang.Keyword

var A_arbace_repr_go_convert_A_const_353 any

var A_arbace_repr_go_convert_A_const_354 *lang.Var

var A_arbace_repr_go_convert_A_const_355 any

var A_arbace_repr_go_convert_A_const_356 *lang.Var

var A_arbace_repr_go_convert_A_const_357 *lang.Var

var A_arbace_repr_go_convert_A_const_358 *lang.Var

var A_arbace_repr_go_convert_A_const_359 *lang.Keyword

var A_arbace_repr_go_convert_A_const_360 *lang.Keyword

var A_arbace_repr_go_convert_A_const_361 *lang.Keyword

var A_arbace_repr_go_convert_A_const_362 any

var A_arbace_repr_go_convert_A_const_363 *lang.Keyword

var A_arbace_repr_go_convert_A_const_364 *lang.Var

var A_arbace_repr_go_convert_A_const_365 any

var A_arbace_repr_go_convert_A_const_366 *lang.Var

var A_arbace_repr_go_convert_A_const_367 *lang.Var

var A_arbace_repr_go_convert_A_const_368 *lang.Var

var A_arbace_repr_go_convert_A_const_369 any

var A_arbace_repr_go_convert_A_const_370 *lang.Keyword

var A_arbace_repr_go_convert_A_const_371 any

var A_arbace_repr_go_convert_A_const_372 any

var A_arbace_repr_go_convert_A_const_373 *lang.Var

var A_arbace_repr_go_convert_A_const_374 *lang.Keyword

var A_arbace_repr_go_convert_A_const_375 any

var A_arbace_repr_go_convert_A_const_376 *lang.Var

var A_arbace_repr_go_convert_A_const_377 any

var A_arbace_repr_go_convert_A_const_378 *lang.Var

var A_arbace_repr_go_convert_A_const_379 *lang.Keyword

var A_arbace_repr_go_convert_A_const_380 any

var A_arbace_repr_go_convert_A_const_381 any

var A_arbace_repr_go_convert_A_const_382 any

var A_arbace_repr_go_convert_A_const_383 any

var A_arbace_repr_go_convert_A_const_384 *lang.Keyword

var A_arbace_repr_go_convert_A_const_385 *lang.Keyword

var A_arbace_repr_go_convert_A_const_386 *lang.Var

var A_arbace_repr_go_convert_A_const_387 *lang.Var

var A_arbace_repr_go_convert_A_const_388 *lang.Var

var A_arbace_repr_go_convert_A_const_389 *lang.Var

var A_arbace_repr_go_convert_A_const_390 *lang.Keyword

var A_arbace_repr_go_convert_A_const_391 *lang.Var

var A_arbace_repr_go_convert_A_const_392 *lang.Keyword

var A_arbace_repr_go_convert_A_const_393 *lang.Keyword

var A_arbace_repr_go_convert_A_const_394 *lang.Keyword

var A_arbace_repr_go_convert_A_const_395 *lang.Keyword

var A_arbace_repr_go_convert_A_const_396 *lang.Var

var A_arbace_repr_go_convert_A_const_397 *lang.Keyword

var A_arbace_repr_go_convert_A_const_398 any

var A_arbace_repr_go_convert_A_const_399 *lang.Keyword

var A_arbace_repr_go_convert_A_const_400 *lang.Keyword

var A_arbace_repr_go_convert_A_const_401 *lang.Keyword

var A_arbace_repr_go_convert_A_const_402 any

var A_arbace_repr_go_convert_A_const_403 *lang.Keyword

var A_arbace_repr_go_convert_A_const_404 *lang.Keyword

var A_arbace_repr_go_convert_A_const_405 *lang.Keyword

var A_arbace_repr_go_convert_A_const_406 *lang.Var

var A_arbace_repr_go_convert_A_const_407 *lang.Var

var A_arbace_repr_go_convert_A_const_408 any

var A_arbace_repr_go_convert_A_const_409 *lang.Keyword

var A_arbace_repr_go_convert_A_const_410 *lang.Keyword

var A_arbace_repr_go_convert_A_const_411 *lang.Var

var A_arbace_repr_go_convert_A_const_412 *lang.Keyword

var A_arbace_repr_go_convert_A_const_413 *lang.Var

var A_arbace_repr_go_convert_A_const_414 *lang.Var

var A_arbace_repr_go_convert_A_const_415 *lang.Var

var A_arbace_repr_go_convert_A_const_416 *lang.Var

var A_arbace_repr_go_convert_A_const_417 *lang.Keyword

var A_arbace_repr_go_convert_A_const_418 any

var A_arbace_repr_go_convert_A_const_419 *lang.Var

var A_arbace_repr_go_convert_A_const_420 *lang.Var

var A_arbace_repr_go_convert_A_const_421 *lang.Var

var A_arbace_repr_go_convert_A_const_422 *lang.Var

var A_arbace_repr_go_convert_A_const_423 *lang.Var

var A_arbace_repr_go_convert_A_const_424 *lang.Var

var A_arbace_repr_go_convert_A_const_425 *lang.Var

var A_arbace_repr_go_convert_A_const_426 *lang.Var

var A_arbace_repr_go_convert_A_const_427 *lang.Var

var A_arbace_repr_go_convert_A_const_428 *lang.Keyword

var A_arbace_repr_go_convert_A_const_429 *lang.Keyword

var A_arbace_repr_go_convert_A_const_430 *lang.Keyword

var A_arbace_repr_go_convert_A_const_431 *lang.Var

var A_arbace_repr_go_convert_A_const_432 *lang.Keyword

var A_arbace_repr_go_convert_A_const_433 any

var A_arbace_repr_go_convert_A_const_434 any

var A_arbace_repr_go_convert_A_const_435 *lang.Var

var A_arbace_repr_go_convert_A_const_436 *lang.Var

var A_arbace_repr_go_convert_A_const_437 *lang.Var

var A_arbace_repr_go_convert_A_const_438 any

var A_arbace_repr_go_convert_A_const_439 any

var A_arbace_repr_go_convert_A_const_440 any

var A_arbace_repr_go_convert_A_const_441 any

var A_arbace_repr_go_convert_A_const_442 *lang.Var

var A_arbace_repr_go_convert_A_const_443 *lang.Keyword

var A_arbace_repr_go_convert_A_const_444 *lang.Keyword

var A_arbace_repr_go_convert_A_const_445 any

var A_arbace_repr_go_convert_A_const_446 *lang.Var

var A_arbace_repr_go_convert_A_const_447 *lang.Keyword

var A_arbace_repr_go_convert_A_const_448 any

var A_arbace_repr_go_convert_A_const_449 *lang.Var

var A_arbace_repr_go_convert_A_const_450 any

var A_arbace_repr_go_convert_A_const_451 *lang.Var

var A_arbace_repr_go_convert_A_const_452 *lang.Keyword

var A_arbace_repr_go_convert_A_const_453 *lang.Keyword

var A_arbace_repr_go_convert_A_const_454 any

var A_arbace_repr_go_convert_A_const_455 any

var A_arbace_repr_go_convert_A_const_456 *lang.Var

var A_arbace_repr_go_convert_A_const_457 *lang.Var

var A_arbace_repr_go_convert_A_const_458 *lang.Keyword

var A_arbace_repr_go_convert_A_const_459 any

var A_arbace_repr_go_convert_A_const_460 any

var A_arbace_repr_go_convert_A_const_461 *lang.Var

var A_arbace_repr_go_convert_A_const_462 *lang.Var

var A_arbace_repr_go_convert_A_const_463 *lang.Keyword

var A_arbace_repr_go_convert_A_const_464 any

var A_arbace_repr_go_convert_A_const_465 any

var A_arbace_repr_go_convert_A_const_466 any

var A_arbace_repr_go_convert_A_const_467 any

var A_arbace_repr_go_convert_A_const_468 *lang.Var

var A_arbace_repr_go_convert_A_const_469 any

var A_arbace_repr_go_convert_A_const_470 *lang.Var

var A_arbace_repr_go_convert_A_const_471 *lang.Keyword

var A_arbace_repr_go_convert_A_const_472 any

var A_arbace_repr_go_convert_A_const_473 any

var A_arbace_repr_go_convert_A_const_474 any

var A_arbace_repr_go_convert_A_const_475 *lang.Keyword

var A_arbace_repr_go_convert_A_const_476 any

var A_arbace_repr_go_convert_A_const_477 *lang.Var

var A_arbace_repr_go_convert_A_const_478 any

var A_arbace_repr_go_convert_A_const_479 any

var A_arbace_repr_go_convert_A_const_480 any

var A_arbace_repr_go_convert_A_const_481 any

var A_arbace_repr_go_convert_A_const_482 *lang.Var

var A_arbace_repr_go_convert_A_const_483 any

var A_arbace_repr_go_convert_A_const_484 *lang.Keyword

var A_arbace_repr_go_convert_A_const_485 any

var A_arbace_repr_go_convert_A_const_486 any

var A_arbace_repr_go_convert_A_const_487 *lang.Keyword

var A_arbace_repr_go_convert_A_const_488 *lang.Keyword

var A_arbace_repr_go_convert_A_const_489 *lang.Keyword

var A_arbace_repr_go_convert_A_const_490 *lang.Keyword

var A_arbace_repr_go_convert_A_const_491 any

var A_arbace_repr_go_convert_A_const_492 *lang.Var

var A_arbace_repr_go_convert_A_const_493 any

var A_arbace_repr_go_convert_A_const_494 any

var A_arbace_repr_go_convert_A_const_495 any

var A_arbace_repr_go_convert_A_const_496 any

var A_arbace_repr_go_convert_A_const_497 any

var A_arbace_repr_go_convert_A_const_498 *lang.Var

var A_arbace_repr_go_convert_A_const_499 *lang.Var

var A_arbace_repr_go_convert_A_const_500 *lang.Var

var A_arbace_repr_go_convert_A_const_501 any

var A_arbace_repr_go_convert_A_const_502 *lang.Var

var A_arbace_repr_go_convert_A_const_503 *lang.Var

var A_arbace_repr_go_convert_A_const_504 *lang.Var

var A_arbace_repr_go_convert_A_const_505 *lang.Var

var A_arbace_repr_go_convert_A_const_506 *lang.Var

var A_arbace_repr_go_convert_A_const_507 any

var A_arbace_repr_go_convert_A_const_508 *lang.Keyword

var A_arbace_repr_go_convert_A_const_509 any

var A_arbace_repr_go_convert_A_const_510 any

var A_arbace_repr_go_convert_A_const_511 any

var A_arbace_repr_go_convert_A_const_512 *lang.Keyword

var A_arbace_repr_go_convert_A_const_513 *lang.Keyword

var A_arbace_repr_go_convert_A_const_514 any

var A_arbace_repr_go_convert_A_const_515 any

var A_arbace_repr_go_convert_A_const_516 any

var A_arbace_repr_go_convert_A_const_517 any

var A_arbace_repr_go_convert_A_const_518 *lang.Var

var A_arbace_repr_go_convert_A_const_519 *lang.Keyword

var A_arbace_repr_go_convert_A_const_520 any

var A_arbace_repr_go_convert_A_const_521 any

var A_arbace_repr_go_convert_A_const_522 *lang.Keyword

var A_arbace_repr_go_convert_A_const_523 any

var A_arbace_repr_go_convert_A_const_524 any

var A_arbace_repr_go_convert_A_const_525 *lang.Var

var A_arbace_repr_go_convert_A_const_526 any

var A_arbace_repr_go_convert_A_const_527 *lang.Var

var A_arbace_repr_go_convert_A_const_528 *lang.Var

var A_arbace_repr_go_convert_A_const_529 *lang.Keyword

var A_arbace_repr_go_convert_A_const_530 *lang.Keyword

var A_arbace_repr_go_convert_A_const_531 *lang.Var

var A_arbace_repr_go_convert_A_const_532 *lang.Keyword

var A_arbace_repr_go_convert_A_const_533 *lang.Keyword

var A_arbace_repr_go_convert_A_const_534 *lang.Var

var A_arbace_repr_go_convert_A_const_535 any

var A_arbace_repr_go_convert_A_const_536 any

var A_arbace_repr_go_convert_A_const_537 any

var A_arbace_repr_go_convert_A_const_538 *lang.Var

var A_arbace_repr_go_convert_A_const_539 *lang.Keyword

var A_arbace_repr_go_convert_A_const_540 *lang.Var

var A_arbace_repr_go_convert_A_const_541 *lang.Var

var A_arbace_repr_go_convert_A_const_542 *lang.Keyword

var A_arbace_repr_go_convert_A_const_543 *lang.Keyword

var A_arbace_repr_go_convert_A_const_544 *lang.Keyword

var A_arbace_repr_go_convert_A_const_545 *lang.Var

var A_arbace_repr_go_convert_A_const_546 *lang.Var

var A_arbace_repr_go_convert_A_const_547 *lang.Var

var A_arbace_repr_go_convert_A_const_548 *lang.Var

var A_arbace_repr_go_convert_A_const_549 *lang.Keyword

var A_arbace_repr_go_convert_A_const_550 *lang.Keyword

var A_arbace_repr_go_convert_A_const_551 any

var A_arbace_repr_go_convert_A_const_552 *lang.Keyword

var A_arbace_repr_go_convert_A_const_553 *lang.Keyword

var A_arbace_repr_go_convert_A_const_554 *lang.Keyword

var A_arbace_repr_go_convert_A_const_555 *lang.Keyword

var A_arbace_repr_go_convert_A_const_556 *lang.Keyword

var A_arbace_repr_go_convert_A_const_557 *lang.Var

var A_arbace_repr_go_convert_A_const_558 *lang.Var

var A_arbace_repr_go_convert_A_const_559 *lang.Var

var A_arbace_repr_go_convert_A_const_560 *lang.Var

var A_arbace_repr_go_convert_A_const_561 any

var A_arbace_repr_go_convert_A_const_562 *lang.Keyword

var A_arbace_repr_go_convert_A_const_563 *lang.Var

var A_arbace_repr_go_convert_A_const_564 *lang.Var

var A_arbace_repr_go_convert_A_const_565 *lang.Var

var A_arbace_repr_go_convert_A_const_566 *lang.Keyword

var A_arbace_repr_go_convert_A_const_567 *lang.Keyword

var A_arbace_repr_go_convert_A_const_568 *lang.Var

var A_arbace_repr_go_convert_A_const_569 *lang.Var

var A_arbace_repr_go_convert_A_const_570 *lang.Keyword

var A_arbace_repr_go_convert_A_const_571 *lang.Keyword

var A_arbace_repr_go_convert_A_const_572 *lang.Var

var A_arbace_repr_go_convert_A_const_573 *lang.Var

var A_arbace_repr_go_convert_A_const_574 *lang.Var

var A_arbace_repr_go_convert_A_const_575 *lang.Keyword

var A_arbace_repr_go_convert_A_const_576 *lang.Keyword

var A_arbace_repr_go_convert_A_const_577 *lang.Keyword

var A_arbace_repr_go_convert_A_const_578 *lang.Keyword

var A_arbace_repr_go_convert_A_const_579 *lang.Keyword

var A_arbace_repr_go_convert_A_const_580 *lang.Var

var A_arbace_repr_go_convert_A_const_581 *lang.Var

var A_arbace_repr_go_convert_A_const_582 *lang.Keyword

var A_arbace_repr_go_convert_A_const_583 *lang.Keyword

var A_arbace_repr_go_convert_A_const_584 any

var A_arbace_repr_go_convert_A_const_585 any

var A_arbace_repr_go_convert_A_const_586 any

var A_arbace_repr_go_convert_A_const_587 any

var A_arbace_repr_go_convert_A_const_588 *lang.Keyword

var A_arbace_repr_go_convert_A_const_589 any

var A_arbace_repr_go_convert_A_const_590 *lang.Keyword

var A_arbace_repr_go_convert_A_const_591 *lang.Keyword

var A_arbace_repr_go_convert_A_const_592 *lang.Keyword

var A_arbace_repr_go_convert_A_const_593 any

var A_arbace_repr_go_convert_A_const_594 *lang.Keyword

var A_arbace_repr_go_convert_A_const_595 *lang.Keyword

var A_arbace_repr_go_convert_A_const_596 any

var A_arbace_repr_go_convert_A_const_597 *lang.Var

var A_arbace_repr_go_convert_A_const_598 any

var A_arbace_repr_go_convert_A_const_599 *lang.Var

var A_arbace_repr_go_convert_A_const_600 *lang.Keyword

var A_arbace_repr_go_convert_A_const_601 *lang.Keyword

var A_arbace_repr_go_convert_A_const_602 *lang.Keyword

var A_arbace_repr_go_convert_A_const_603 *lang.Keyword

var A_arbace_repr_go_convert_A_const_604 *lang.Keyword

var A_arbace_repr_go_convert_A_const_605 *lang.Keyword

var A_arbace_repr_go_convert_A_const_606 *lang.Keyword

var A_arbace_repr_go_convert_A_const_607 *lang.Keyword

var A_arbace_repr_go_convert_A_const_608 *lang.Keyword

var A_arbace_repr_go_convert_A_const_609 *lang.Keyword

var A_arbace_repr_go_convert_A_const_610 *lang.Keyword

var A_arbace_repr_go_convert_A_const_611 *lang.Keyword

var A_arbace_repr_go_convert_A_const_612 *lang.Keyword

var A_arbace_repr_go_convert_A_const_613 *lang.Var

var A_arbace_repr_go_convert_A_const_614 *lang.Keyword

var A_arbace_repr_go_convert_A_const_615 *lang.Keyword

var A_arbace_repr_go_convert_A_const_616 *lang.Var

var A_arbace_repr_go_convert_A_const_617 *lang.Var

var A_arbace_repr_go_convert_A_const_618 *lang.Keyword

var A_arbace_repr_go_convert_A_const_619 *lang.Keyword

var A_arbace_repr_go_convert_A_const_620 *lang.Keyword

var A_arbace_repr_go_convert_A_const_621 *lang.Var

var A_arbace_repr_go_convert_A_const_622 *lang.Keyword

var A_arbace_repr_go_convert_A_const_623 *lang.Keyword

var A_arbace_repr_go_convert_A_const_624 *lang.Var

var A_arbace_repr_go_convert_A_const_625 *lang.Keyword

var A_arbace_repr_go_convert_A_const_626 *lang.Var

var A_arbace_repr_go_convert_A_const_627 *lang.Var

var A_arbace_repr_go_convert_A_const_628 *lang.Var

var A_arbace_repr_go_convert_A_const_629 *lang.Keyword

var A_arbace_repr_go_convert_A_const_630 *lang.Var

var A_arbace_repr_go_convert_A_const_631 *lang.Keyword

var A_arbace_repr_go_convert_A_const_632 *lang.Var

var A_arbace_repr_go_convert_A_const_633 any

var A_arbace_repr_go_convert_A_const_634 any

var A_arbace_repr_go_convert_A_const_635 any

var A_arbace_repr_go_convert_A_const_636 any

var A_arbace_repr_go_convert_A_init jrt.ClassInit

func A_arbace_repr_go_convert_A_Init() { if !A_arbace_repr_go_convert_A_init.Done() { A_arbace_repr_go_convert_A_init.Run(A_arbace_repr_go_convert_A_clinit) } }

func A_arbace_repr_go_convert_A_clinit() { A_arbace_repr_go_convert_A_clinit_p0(); A_arbace_repr_go_convert_A_clinit_p1(); A_arbace_repr_go_convert_A_clinit_p2(); A_arbace_repr_go_convert_A_clinit_p3(); A_arbace_repr_go_convert_A_clinit_p4(); A_arbace_repr_go_convert_A_clinit_p5(); A_arbace_repr_go_convert_A_clinit_p6(); A_arbace_repr_go_convert_A_clinit_p7(); A_arbace_repr_go_convert_A_clinit_p8(); A_arbace_repr_go_convert_A_clinit_p9(); A_arbace_repr_go_convert_A_clinit_p10(); A_arbace_repr_go_convert_A_clinit_p11(); A_arbace_repr_go_convert_A_clinit_p12(); A_arbace_repr_go_convert_A_clinit_p13(); A_arbace_repr_go_convert_A_clinit_p14(); A_arbace_repr_go_convert_A_clinit_p15(); A_arbace_repr_go_convert_A_clinit_p16(); A_arbace_repr_go_convert_A_clinit_p17(); A_arbace_repr_go_convert_A_clinit_p18(); A_arbace_repr_go_convert_A_clinit_p19(); A_arbace_repr_go_convert_A_clinit_p20(); A_arbace_repr_go_convert_A_clinit_p21(); A_arbace_repr_go_convert_A_clinit_p22(); A_arbace_repr_go_convert_A_clinit_p23(); A_arbace_repr_go_convert_A_clinit_p24(); A_arbace_repr_go_convert_A_clinit_p25(); A_arbace_repr_go_convert_A_clinit_p26(); A_arbace_repr_go_convert_A_clinit_p27(); A_arbace_repr_go_convert_A_clinit_p28(); A_arbace_repr_go_convert_A_clinit_p29(); A_arbace_repr_go_convert_A_clinit_p30(); A_arbace_repr_go_convert_A_clinit_p31(); A_arbace_repr_go_convert_A_clinit_p32(); A_arbace_repr_go_convert_A_clinit_p33(); A_arbace_repr_go_convert_A_clinit_p34(); A_arbace_repr_go_convert_A_clinit_p35(); A_arbace_repr_go_convert_A_clinit_p36(); A_arbace_repr_go_convert_A_clinit_p37(); A_arbace_repr_go_convert_A_clinit_p38(); A_arbace_repr_go_convert_A_clinit_p39(); A_arbace_repr_go_convert_A_clinit_p40(); A_arbace_repr_go_convert_A_clinit_p41(); A_arbace_repr_go_convert_A_clinit_p42(); A_arbace_repr_go_convert_A_clinit_p43(); A_arbace_repr_go_convert_A_clinit_p44(); A_arbace_repr_go_convert_A_clinit_p45(); A_arbace_repr_go_convert_A_clinit_p46(); A_arbace_repr_go_convert_A_clinit_p47(); A_arbace_repr_go_convert_A_clinit_p48(); A_arbace_repr_go_convert_A_clinit_p49(); A_arbace_repr_go_convert_A_clinit_p50(); A_arbace_repr_go_convert_A_clinit_p51() }

func A_arbace_repr_go_convert_A_clinit_p0() { A_arbace_repr_go_convert_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 981); A_arbace_repr_go_convert_A_const_0 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[344]); A_arbace_repr_go_convert_A_const_1 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[345]); A_arbace_repr_go_convert_A_const_2 = A_arbace_repr_go_convert_A_const_pool.A[346]; A_arbace_repr_go_convert_A_const_3 = A_arbace_repr_go_convert_A_const_pool.A[347]; A_arbace_repr_go_convert_A_const_4 = A_arbace_repr_go_convert_A_const_pool.A[348]; A_arbace_repr_go_convert_A_const_5 = A_arbace_repr_go_convert_A_const_pool.A[349]; A_arbace_repr_go_convert_A_const_6 = A_arbace_repr_go_convert_A_const_pool.A[350]; A_arbace_repr_go_convert_A_const_7 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[351]); A_arbace_repr_go_convert_A_const_8 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[352]); A_arbace_repr_go_convert_A_const_9 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[353]); A_arbace_repr_go_convert_A_const_10 = A_arbace_repr_go_convert_A_const_pool.A[354]; A_arbace_repr_go_convert_A_const_11 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[355]); A_arbace_repr_go_convert_A_const_12 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[356]) }

func A_arbace_repr_go_convert_A_clinit_p1() { A_arbace_repr_go_convert_A_const_13 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[357]); A_arbace_repr_go_convert_A_const_14 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[358]); A_arbace_repr_go_convert_A_const_15 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[359]); A_arbace_repr_go_convert_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[360]); A_arbace_repr_go_convert_A_const_17 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[361]); A_arbace_repr_go_convert_A_const_18 = A_arbace_repr_go_convert_A_const_pool.A[362]; A_arbace_repr_go_convert_A_const_19 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[363]); A_arbace_repr_go_convert_A_const_20 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[364]); A_arbace_repr_go_convert_A_const_21 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[365]); A_arbace_repr_go_convert_A_const_22 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[366]); A_arbace_repr_go_convert_A_const_23 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[367]); A_arbace_repr_go_convert_A_const_24 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[368]) }

func A_arbace_repr_go_convert_A_clinit_p2() { A_arbace_repr_go_convert_A_const_25 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[369]); A_arbace_repr_go_convert_A_const_26 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[370]); A_arbace_repr_go_convert_A_const_27 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[371]); A_arbace_repr_go_convert_A_const_28 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[372]); A_arbace_repr_go_convert_A_const_29 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[373]); A_arbace_repr_go_convert_A_const_30 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[374]); A_arbace_repr_go_convert_A_const_31 = A_arbace_repr_go_convert_A_const_pool.A[375]; A_arbace_repr_go_convert_A_const_32 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[376]); A_arbace_repr_go_convert_A_const_33 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[377]); A_arbace_repr_go_convert_A_const_34 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[378]); A_arbace_repr_go_convert_A_const_35 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[379]); A_arbace_repr_go_convert_A_const_36 = A_arbace_repr_go_convert_A_const_pool.A[380] }

func A_arbace_repr_go_convert_A_clinit_p3() { A_arbace_repr_go_convert_A_const_37 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[381]); A_arbace_repr_go_convert_A_const_38 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[382]); A_arbace_repr_go_convert_A_const_39 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[383]); A_arbace_repr_go_convert_A_const_40 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[384]); A_arbace_repr_go_convert_A_const_41 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[385]); A_arbace_repr_go_convert_A_const_42 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[386]); A_arbace_repr_go_convert_A_const_43 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[387]); A_arbace_repr_go_convert_A_const_44 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[388]); A_arbace_repr_go_convert_A_const_45 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[389]); A_arbace_repr_go_convert_A_const_46 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[390]); A_arbace_repr_go_convert_A_const_47 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[391]); A_arbace_repr_go_convert_A_const_48 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[392]) }

func A_arbace_repr_go_convert_A_clinit_p4() { A_arbace_repr_go_convert_A_const_49 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[393]); A_arbace_repr_go_convert_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[394]); A_arbace_repr_go_convert_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[395]); A_arbace_repr_go_convert_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[396]); A_arbace_repr_go_convert_A_const_53 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[397]); A_arbace_repr_go_convert_A_const_54 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[398]); A_arbace_repr_go_convert_A_const_55 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[399]); A_arbace_repr_go_convert_A_const_56 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[400]); A_arbace_repr_go_convert_A_const_57 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[401]); A_arbace_repr_go_convert_A_const_58 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[402]); A_arbace_repr_go_convert_A_const_59 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[403]); A_arbace_repr_go_convert_A_const_60 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[404]) }

func A_arbace_repr_go_convert_A_clinit_p5() { A_arbace_repr_go_convert_A_const_61 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[405]); A_arbace_repr_go_convert_A_const_62 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[406]); A_arbace_repr_go_convert_A_const_63 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[407]); A_arbace_repr_go_convert_A_const_64 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[408]); A_arbace_repr_go_convert_A_const_65 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[409]); A_arbace_repr_go_convert_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[410]); A_arbace_repr_go_convert_A_const_67 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[411]); A_arbace_repr_go_convert_A_const_68 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[412]); A_arbace_repr_go_convert_A_const_69 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[413]); A_arbace_repr_go_convert_A_const_70 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[414]); A_arbace_repr_go_convert_A_const_71 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[415]); A_arbace_repr_go_convert_A_const_72 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[416]) }

func A_arbace_repr_go_convert_A_clinit_p6() { A_arbace_repr_go_convert_A_const_73 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[417]); A_arbace_repr_go_convert_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[418]); A_arbace_repr_go_convert_A_const_75 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[419]); A_arbace_repr_go_convert_A_const_76 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[420]); A_arbace_repr_go_convert_A_const_77 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[421]); A_arbace_repr_go_convert_A_const_78 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[422]); A_arbace_repr_go_convert_A_const_79 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[423]); A_arbace_repr_go_convert_A_const_80 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[424]); A_arbace_repr_go_convert_A_const_81 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[425]); A_arbace_repr_go_convert_A_const_82 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[426]); A_arbace_repr_go_convert_A_const_83 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[427]); A_arbace_repr_go_convert_A_const_84 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[428]) }

func A_arbace_repr_go_convert_A_clinit_p7() { A_arbace_repr_go_convert_A_const_85 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[429]); A_arbace_repr_go_convert_A_const_86 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[430]); A_arbace_repr_go_convert_A_const_87 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[431]); A_arbace_repr_go_convert_A_const_88 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[432]); A_arbace_repr_go_convert_A_const_89 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[433]); A_arbace_repr_go_convert_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[434]); A_arbace_repr_go_convert_A_const_91 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[435]); A_arbace_repr_go_convert_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[436]); A_arbace_repr_go_convert_A_const_93 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[437]); A_arbace_repr_go_convert_A_const_94 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[438]); A_arbace_repr_go_convert_A_const_95 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[439]); A_arbace_repr_go_convert_A_const_96 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[440]) }

func A_arbace_repr_go_convert_A_clinit_p8() { A_arbace_repr_go_convert_A_const_97 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[441]); A_arbace_repr_go_convert_A_const_98 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[442]); A_arbace_repr_go_convert_A_const_99 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[443]); A_arbace_repr_go_convert_A_const_100 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[444]); A_arbace_repr_go_convert_A_const_101 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[445]); A_arbace_repr_go_convert_A_const_102 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[446]); A_arbace_repr_go_convert_A_const_103 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[447]); A_arbace_repr_go_convert_A_const_104 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[448]); A_arbace_repr_go_convert_A_const_105 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[449]); A_arbace_repr_go_convert_A_const_106 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[450]); A_arbace_repr_go_convert_A_const_107 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[451]); A_arbace_repr_go_convert_A_const_108 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[452]) }

func A_arbace_repr_go_convert_A_clinit_p9() { A_arbace_repr_go_convert_A_const_109 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[453]); A_arbace_repr_go_convert_A_const_110 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[454]); A_arbace_repr_go_convert_A_const_111 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[455]); A_arbace_repr_go_convert_A_const_112 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[456]); A_arbace_repr_go_convert_A_const_113 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[457]); A_arbace_repr_go_convert_A_const_114 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[458]); A_arbace_repr_go_convert_A_const_115 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[459]); A_arbace_repr_go_convert_A_const_116 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[460]); A_arbace_repr_go_convert_A_const_117 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[461]); A_arbace_repr_go_convert_A_const_118 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[462]); A_arbace_repr_go_convert_A_const_119 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[463]); A_arbace_repr_go_convert_A_const_120 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[464]) }

func A_arbace_repr_go_convert_A_clinit_p10() { A_arbace_repr_go_convert_A_const_121 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[465]); A_arbace_repr_go_convert_A_const_122 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[466]); A_arbace_repr_go_convert_A_const_123 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[467]); A_arbace_repr_go_convert_A_const_124 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[468]); A_arbace_repr_go_convert_A_const_125 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[469]); A_arbace_repr_go_convert_A_const_126 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[470]); A_arbace_repr_go_convert_A_const_127 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[471]); A_arbace_repr_go_convert_A_const_128 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[472]); A_arbace_repr_go_convert_A_const_129 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[473]); A_arbace_repr_go_convert_A_const_130 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[474]); A_arbace_repr_go_convert_A_const_131 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[475]); A_arbace_repr_go_convert_A_const_132 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[476]) }

func A_arbace_repr_go_convert_A_clinit_p11() { A_arbace_repr_go_convert_A_const_133 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[477]); A_arbace_repr_go_convert_A_const_134 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[478]); A_arbace_repr_go_convert_A_const_135 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[479]); A_arbace_repr_go_convert_A_const_136 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[480]); A_arbace_repr_go_convert_A_const_137 = A_arbace_repr_go_convert_A_const_pool.A[481]; A_arbace_repr_go_convert_A_const_138 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[482]); A_arbace_repr_go_convert_A_const_139 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[483]); A_arbace_repr_go_convert_A_const_140 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[484]); A_arbace_repr_go_convert_A_const_141 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[485]); A_arbace_repr_go_convert_A_const_142 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[486]); A_arbace_repr_go_convert_A_const_143 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[487]); A_arbace_repr_go_convert_A_const_144 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[488]) }

func A_arbace_repr_go_convert_A_clinit_p12() { A_arbace_repr_go_convert_A_const_145 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[489]); A_arbace_repr_go_convert_A_const_146 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[490]); A_arbace_repr_go_convert_A_const_147 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[491]); A_arbace_repr_go_convert_A_const_148 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[492]); A_arbace_repr_go_convert_A_const_149 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[493]); A_arbace_repr_go_convert_A_const_150 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[494]); A_arbace_repr_go_convert_A_const_151 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[495]); A_arbace_repr_go_convert_A_const_152 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[496]); A_arbace_repr_go_convert_A_const_153 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[497]); A_arbace_repr_go_convert_A_const_154 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[498]); A_arbace_repr_go_convert_A_const_155 = A_arbace_repr_go_convert_A_const_pool.A[499]; A_arbace_repr_go_convert_A_const_156 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[500]) }

func A_arbace_repr_go_convert_A_clinit_p13() { A_arbace_repr_go_convert_A_const_157 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[501]); A_arbace_repr_go_convert_A_const_158 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[502]); A_arbace_repr_go_convert_A_const_159 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[503]); A_arbace_repr_go_convert_A_const_160 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[504]); A_arbace_repr_go_convert_A_const_161 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[505]); A_arbace_repr_go_convert_A_const_162 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[506]); A_arbace_repr_go_convert_A_const_163 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[507]); A_arbace_repr_go_convert_A_const_164 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[508]); A_arbace_repr_go_convert_A_const_165 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[509]); A_arbace_repr_go_convert_A_const_166 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[510]); A_arbace_repr_go_convert_A_const_167 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[511]); A_arbace_repr_go_convert_A_const_168 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[512]) }

func A_arbace_repr_go_convert_A_clinit_p14() { A_arbace_repr_go_convert_A_const_169 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[513]); A_arbace_repr_go_convert_A_const_170 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[514]); A_arbace_repr_go_convert_A_const_171 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[515]); A_arbace_repr_go_convert_A_const_172 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[516]); A_arbace_repr_go_convert_A_const_173 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[517]); A_arbace_repr_go_convert_A_const_174 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[518]); A_arbace_repr_go_convert_A_const_175 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[519]); A_arbace_repr_go_convert_A_const_176 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[520]); A_arbace_repr_go_convert_A_const_177 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[521]); A_arbace_repr_go_convert_A_const_178 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[522]); A_arbace_repr_go_convert_A_const_179 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[523]); A_arbace_repr_go_convert_A_const_180 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[524]) }

func A_arbace_repr_go_convert_A_clinit_p15() { A_arbace_repr_go_convert_A_const_181 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[525]); A_arbace_repr_go_convert_A_const_182 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[526]); A_arbace_repr_go_convert_A_const_183 = A_arbace_repr_go_convert_A_const_pool.A[527]; A_arbace_repr_go_convert_A_const_184 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[528]); A_arbace_repr_go_convert_A_const_185 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[529]); A_arbace_repr_go_convert_A_const_186 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[530]); A_arbace_repr_go_convert_A_const_187 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[531]); A_arbace_repr_go_convert_A_const_188 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[532]); A_arbace_repr_go_convert_A_const_189 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[533]); A_arbace_repr_go_convert_A_const_190 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[534]); A_arbace_repr_go_convert_A_const_191 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[535]); A_arbace_repr_go_convert_A_const_192 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[536]) }

func A_arbace_repr_go_convert_A_clinit_p16() { A_arbace_repr_go_convert_A_const_193 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[537]); A_arbace_repr_go_convert_A_const_194 = A_arbace_repr_go_convert_A_const_pool.A[538]; A_arbace_repr_go_convert_A_const_195 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[539]); A_arbace_repr_go_convert_A_const_196 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[540]); A_arbace_repr_go_convert_A_const_197 = A_arbace_repr_go_convert_A_const_pool.A[541]; A_arbace_repr_go_convert_A_const_198 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[542]); A_arbace_repr_go_convert_A_const_199 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[543]); A_arbace_repr_go_convert_A_const_200 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[544]); A_arbace_repr_go_convert_A_const_201 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[545]); A_arbace_repr_go_convert_A_const_202 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[546]); A_arbace_repr_go_convert_A_const_203 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[547]); A_arbace_repr_go_convert_A_const_204 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[548]) }

func A_arbace_repr_go_convert_A_clinit_p17() { A_arbace_repr_go_convert_A_const_205 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[549]); A_arbace_repr_go_convert_A_const_206 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[550]); A_arbace_repr_go_convert_A_const_207 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[551]); A_arbace_repr_go_convert_A_const_208 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[552]); A_arbace_repr_go_convert_A_const_209 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[553]); A_arbace_repr_go_convert_A_const_210 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[554]); A_arbace_repr_go_convert_A_const_211 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[555]); A_arbace_repr_go_convert_A_const_212 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[556]); A_arbace_repr_go_convert_A_const_213 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[557]); A_arbace_repr_go_convert_A_const_214 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[558]); A_arbace_repr_go_convert_A_const_215 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[559]); A_arbace_repr_go_convert_A_const_216 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[560]) }

func A_arbace_repr_go_convert_A_clinit_p18() { A_arbace_repr_go_convert_A_const_217 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[561]); A_arbace_repr_go_convert_A_const_218 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[562]); A_arbace_repr_go_convert_A_const_219 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[563]); A_arbace_repr_go_convert_A_const_220 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[564]); A_arbace_repr_go_convert_A_const_221 = A_arbace_repr_go_convert_A_const_pool.A[565]; A_arbace_repr_go_convert_A_const_222 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[566]); A_arbace_repr_go_convert_A_const_223 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[567]); A_arbace_repr_go_convert_A_const_224 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[568]); A_arbace_repr_go_convert_A_const_225 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[569]); A_arbace_repr_go_convert_A_const_226 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[570]); A_arbace_repr_go_convert_A_const_227 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[571]); A_arbace_repr_go_convert_A_const_228 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[572]) }

func A_arbace_repr_go_convert_A_clinit_p19() { A_arbace_repr_go_convert_A_const_229 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[573]); A_arbace_repr_go_convert_A_const_230 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[574]); A_arbace_repr_go_convert_A_const_231 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[575]); A_arbace_repr_go_convert_A_const_232 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[576]); A_arbace_repr_go_convert_A_const_233 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[577]); A_arbace_repr_go_convert_A_const_234 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[578]); A_arbace_repr_go_convert_A_const_235 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[579]); A_arbace_repr_go_convert_A_const_236 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[580]); A_arbace_repr_go_convert_A_const_237 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[581]); A_arbace_repr_go_convert_A_const_238 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[582]); A_arbace_repr_go_convert_A_const_239 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[583]); A_arbace_repr_go_convert_A_const_240 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[584]) }

func A_arbace_repr_go_convert_A_clinit_p20() { A_arbace_repr_go_convert_A_const_241 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[585]); A_arbace_repr_go_convert_A_const_242 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[586]); A_arbace_repr_go_convert_A_const_243 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[587]); A_arbace_repr_go_convert_A_const_244 = A_arbace_repr_go_convert_A_const_pool.A[588]; A_arbace_repr_go_convert_A_const_245 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[589]); A_arbace_repr_go_convert_A_const_246 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[590]); A_arbace_repr_go_convert_A_const_247 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[591]); A_arbace_repr_go_convert_A_const_248 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[592]); A_arbace_repr_go_convert_A_const_249 = A_arbace_repr_go_convert_A_const_pool.A[593]; A_arbace_repr_go_convert_A_const_250 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[594]); A_arbace_repr_go_convert_A_const_251 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[595]); A_arbace_repr_go_convert_A_const_252 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[596]) }

func A_arbace_repr_go_convert_A_clinit_p21() { A_arbace_repr_go_convert_A_const_253 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[597]); A_arbace_repr_go_convert_A_const_254 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[598]); A_arbace_repr_go_convert_A_const_255 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[599]); A_arbace_repr_go_convert_A_const_256 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[600]); A_arbace_repr_go_convert_A_const_257 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[601]); A_arbace_repr_go_convert_A_const_258 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[602]); A_arbace_repr_go_convert_A_const_259 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[603]); A_arbace_repr_go_convert_A_const_260 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[604]); A_arbace_repr_go_convert_A_const_261 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[605]); A_arbace_repr_go_convert_A_const_262 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[606]); A_arbace_repr_go_convert_A_const_263 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[607]); A_arbace_repr_go_convert_A_const_264 = A_arbace_repr_go_convert_A_const_pool.A[608] }

func A_arbace_repr_go_convert_A_clinit_p22() { A_arbace_repr_go_convert_A_const_265 = A_arbace_repr_go_convert_A_const_pool.A[609]; A_arbace_repr_go_convert_A_const_266 = A_arbace_repr_go_convert_A_const_pool.A[610]; A_arbace_repr_go_convert_A_const_267 = A_arbace_repr_go_convert_A_const_pool.A[611]; A_arbace_repr_go_convert_A_const_268 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[612]); A_arbace_repr_go_convert_A_const_269 = A_arbace_repr_go_convert_A_const_pool.A[613]; A_arbace_repr_go_convert_A_const_270 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[614]); A_arbace_repr_go_convert_A_const_271 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[615]); A_arbace_repr_go_convert_A_const_272 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[616]); A_arbace_repr_go_convert_A_const_273 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[617]); A_arbace_repr_go_convert_A_const_274 = A_arbace_repr_go_convert_A_const_pool.A[618]; A_arbace_repr_go_convert_A_const_275 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[619]); A_arbace_repr_go_convert_A_const_276 = A_arbace_repr_go_convert_A_const_pool.A[620]; A_arbace_repr_go_convert_A_const_277 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[621]) }

func A_arbace_repr_go_convert_A_clinit_p23() { A_arbace_repr_go_convert_A_const_278 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[622]); A_arbace_repr_go_convert_A_const_279 = A_arbace_repr_go_convert_A_const_pool.A[623]; A_arbace_repr_go_convert_A_const_280 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[624]); A_arbace_repr_go_convert_A_const_281 = A_arbace_repr_go_convert_A_const_pool.A[625]; A_arbace_repr_go_convert_A_const_282 = A_arbace_repr_go_convert_A_const_pool.A[626]; A_arbace_repr_go_convert_A_const_283 = A_arbace_repr_go_convert_A_const_pool.A[627]; A_arbace_repr_go_convert_A_const_284 = A_arbace_repr_go_convert_A_const_pool.A[628]; A_arbace_repr_go_convert_A_const_285 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[629]); A_arbace_repr_go_convert_A_const_286 = A_arbace_repr_go_convert_A_const_pool.A[630]; A_arbace_repr_go_convert_A_const_287 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[631]); A_arbace_repr_go_convert_A_const_288 = A_arbace_repr_go_convert_A_const_pool.A[632]; A_arbace_repr_go_convert_A_const_289 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[633]); A_arbace_repr_go_convert_A_const_290 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[634]) }

func A_arbace_repr_go_convert_A_clinit_p24() { A_arbace_repr_go_convert_A_const_291 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[635]); A_arbace_repr_go_convert_A_const_292 = A_arbace_repr_go_convert_A_const_pool.A[636]; A_arbace_repr_go_convert_A_const_293 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[637]); A_arbace_repr_go_convert_A_const_294 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[638]); A_arbace_repr_go_convert_A_const_295 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[639]); A_arbace_repr_go_convert_A_const_296 = A_arbace_repr_go_convert_A_const_pool.A[640]; A_arbace_repr_go_convert_A_const_297 = A_arbace_repr_go_convert_A_const_pool.A[641]; A_arbace_repr_go_convert_A_const_298 = A_arbace_repr_go_convert_A_const_pool.A[642]; A_arbace_repr_go_convert_A_const_299 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[643]); A_arbace_repr_go_convert_A_const_300 = A_arbace_repr_go_convert_A_const_pool.A[644]; A_arbace_repr_go_convert_A_const_301 = A_arbace_repr_go_convert_A_const_pool.A[645]; A_arbace_repr_go_convert_A_const_302 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[646]); A_arbace_repr_go_convert_A_const_303 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[647]) }

func A_arbace_repr_go_convert_A_clinit_p25() { A_arbace_repr_go_convert_A_const_304 = A_arbace_repr_go_convert_A_const_pool.A[648]; A_arbace_repr_go_convert_A_const_305 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[649]); A_arbace_repr_go_convert_A_const_306 = A_arbace_repr_go_convert_A_const_pool.A[650]; A_arbace_repr_go_convert_A_const_307 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[651]); A_arbace_repr_go_convert_A_const_308 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[652]); A_arbace_repr_go_convert_A_const_309 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[653]); A_arbace_repr_go_convert_A_const_310 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[654]); A_arbace_repr_go_convert_A_const_311 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[655]); A_arbace_repr_go_convert_A_const_312 = A_arbace_repr_go_convert_A_const_pool.A[656]; A_arbace_repr_go_convert_A_const_313 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[657]); A_arbace_repr_go_convert_A_const_314 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[658]); A_arbace_repr_go_convert_A_const_315 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[659]); A_arbace_repr_go_convert_A_const_316 = A_arbace_repr_go_convert_A_const_pool.A[660] }

func A_arbace_repr_go_convert_A_clinit_p26() { A_arbace_repr_go_convert_A_const_317 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[661]); A_arbace_repr_go_convert_A_const_318 = A_arbace_repr_go_convert_A_const_pool.A[662]; A_arbace_repr_go_convert_A_const_319 = A_arbace_repr_go_convert_A_const_pool.A[663]; A_arbace_repr_go_convert_A_const_320 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[664]); A_arbace_repr_go_convert_A_const_321 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[665]); A_arbace_repr_go_convert_A_const_322 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[666]); A_arbace_repr_go_convert_A_const_323 = A_arbace_repr_go_convert_A_const_pool.A[667]; A_arbace_repr_go_convert_A_const_324 = A_arbace_repr_go_convert_A_const_pool.A[668]; A_arbace_repr_go_convert_A_const_325 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[669]); A_arbace_repr_go_convert_A_const_326 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[670]); A_arbace_repr_go_convert_A_const_327 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[671]); A_arbace_repr_go_convert_A_const_328 = A_arbace_repr_go_convert_A_const_pool.A[672]; A_arbace_repr_go_convert_A_const_329 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[673]) }

func A_arbace_repr_go_convert_A_clinit_p27() { A_arbace_repr_go_convert_A_const_330 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[674]); A_arbace_repr_go_convert_A_const_331 = A_arbace_repr_go_convert_A_const_pool.A[675]; A_arbace_repr_go_convert_A_const_332 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[676]); A_arbace_repr_go_convert_A_const_333 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[677]); A_arbace_repr_go_convert_A_const_334 = A_arbace_repr_go_convert_A_const_pool.A[678]; A_arbace_repr_go_convert_A_const_335 = A_arbace_repr_go_convert_A_const_pool.A[679]; A_arbace_repr_go_convert_A_const_336 = A_arbace_repr_go_convert_A_const_pool.A[680]; A_arbace_repr_go_convert_A_const_337 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[681]); A_arbace_repr_go_convert_A_const_338 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[682]); A_arbace_repr_go_convert_A_const_339 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[683]); A_arbace_repr_go_convert_A_const_340 = A_arbace_repr_go_convert_A_const_pool.A[684]; A_arbace_repr_go_convert_A_const_341 = A_arbace_repr_go_convert_A_const_pool.A[685]; A_arbace_repr_go_convert_A_const_342 = A_arbace_repr_go_convert_A_const_pool.A[686] }

func A_arbace_repr_go_convert_A_clinit_p28() { A_arbace_repr_go_convert_A_const_343 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[687]); A_arbace_repr_go_convert_A_const_344 = A_arbace_repr_go_convert_A_const_pool.A[688]; A_arbace_repr_go_convert_A_const_345 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[689]); A_arbace_repr_go_convert_A_const_346 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[690]); A_arbace_repr_go_convert_A_const_347 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[691]); A_arbace_repr_go_convert_A_const_348 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[692]); A_arbace_repr_go_convert_A_const_349 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[693]); A_arbace_repr_go_convert_A_const_350 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[694]); A_arbace_repr_go_convert_A_const_351 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[695]); A_arbace_repr_go_convert_A_const_352 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[696]); A_arbace_repr_go_convert_A_const_353 = A_arbace_repr_go_convert_A_const_pool.A[697]; A_arbace_repr_go_convert_A_const_354 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[698]) }

func A_arbace_repr_go_convert_A_clinit_p29() { A_arbace_repr_go_convert_A_const_355 = A_arbace_repr_go_convert_A_const_pool.A[699]; A_arbace_repr_go_convert_A_const_356 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[700]); A_arbace_repr_go_convert_A_const_357 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[701]); A_arbace_repr_go_convert_A_const_358 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[702]); A_arbace_repr_go_convert_A_const_359 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[703]); A_arbace_repr_go_convert_A_const_360 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[704]); A_arbace_repr_go_convert_A_const_361 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[705]); A_arbace_repr_go_convert_A_const_362 = A_arbace_repr_go_convert_A_const_pool.A[706]; A_arbace_repr_go_convert_A_const_363 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[707]); A_arbace_repr_go_convert_A_const_364 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[708]); A_arbace_repr_go_convert_A_const_365 = A_arbace_repr_go_convert_A_const_pool.A[709]; A_arbace_repr_go_convert_A_const_366 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[710]) }

func A_arbace_repr_go_convert_A_clinit_p30() { A_arbace_repr_go_convert_A_const_367 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[711]); A_arbace_repr_go_convert_A_const_368 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[712]); A_arbace_repr_go_convert_A_const_369 = A_arbace_repr_go_convert_A_const_pool.A[713]; A_arbace_repr_go_convert_A_const_370 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[714]); A_arbace_repr_go_convert_A_const_371 = A_arbace_repr_go_convert_A_const_pool.A[715]; A_arbace_repr_go_convert_A_const_372 = A_arbace_repr_go_convert_A_const_pool.A[716]; A_arbace_repr_go_convert_A_const_373 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[717]); A_arbace_repr_go_convert_A_const_374 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[718]); A_arbace_repr_go_convert_A_const_375 = A_arbace_repr_go_convert_A_const_pool.A[719]; A_arbace_repr_go_convert_A_const_376 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[720]); A_arbace_repr_go_convert_A_const_377 = A_arbace_repr_go_convert_A_const_pool.A[721]; A_arbace_repr_go_convert_A_const_378 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[722]); A_arbace_repr_go_convert_A_const_379 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[723]) }

func A_arbace_repr_go_convert_A_clinit_p31() { A_arbace_repr_go_convert_A_const_380 = A_arbace_repr_go_convert_A_const_pool.A[724]; A_arbace_repr_go_convert_A_const_381 = A_arbace_repr_go_convert_A_const_pool.A[725]; A_arbace_repr_go_convert_A_const_382 = A_arbace_repr_go_convert_A_const_pool.A[726]; A_arbace_repr_go_convert_A_const_383 = A_arbace_repr_go_convert_A_const_pool.A[727]; A_arbace_repr_go_convert_A_const_384 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[728]); A_arbace_repr_go_convert_A_const_385 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[729]); A_arbace_repr_go_convert_A_const_386 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[730]); A_arbace_repr_go_convert_A_const_387 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[731]); A_arbace_repr_go_convert_A_const_388 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[732]); A_arbace_repr_go_convert_A_const_389 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[733]); A_arbace_repr_go_convert_A_const_390 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[734]); A_arbace_repr_go_convert_A_const_391 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[735]); A_arbace_repr_go_convert_A_const_392 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[736]) }

func A_arbace_repr_go_convert_A_clinit_p32() { A_arbace_repr_go_convert_A_const_393 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[737]); A_arbace_repr_go_convert_A_const_394 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[738]); A_arbace_repr_go_convert_A_const_395 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[739]); A_arbace_repr_go_convert_A_const_396 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[740]); A_arbace_repr_go_convert_A_const_397 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[741]); A_arbace_repr_go_convert_A_const_398 = A_arbace_repr_go_convert_A_const_pool.A[742]; A_arbace_repr_go_convert_A_const_399 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[743]); A_arbace_repr_go_convert_A_const_400 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[744]); A_arbace_repr_go_convert_A_const_401 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[745]); A_arbace_repr_go_convert_A_const_402 = A_arbace_repr_go_convert_A_const_pool.A[746]; A_arbace_repr_go_convert_A_const_403 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[747]); A_arbace_repr_go_convert_A_const_404 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[748]) }

func A_arbace_repr_go_convert_A_clinit_p33() { A_arbace_repr_go_convert_A_const_405 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[749]); A_arbace_repr_go_convert_A_const_406 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[750]); A_arbace_repr_go_convert_A_const_407 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[751]); A_arbace_repr_go_convert_A_const_408 = A_arbace_repr_go_convert_A_const_pool.A[752]; A_arbace_repr_go_convert_A_const_409 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[753]); A_arbace_repr_go_convert_A_const_410 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[754]); A_arbace_repr_go_convert_A_const_411 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[755]); A_arbace_repr_go_convert_A_const_412 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[756]); A_arbace_repr_go_convert_A_const_413 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[757]); A_arbace_repr_go_convert_A_const_414 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[758]); A_arbace_repr_go_convert_A_const_415 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[759]); A_arbace_repr_go_convert_A_const_416 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[760]) }

func A_arbace_repr_go_convert_A_clinit_p34() { A_arbace_repr_go_convert_A_const_417 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[761]); A_arbace_repr_go_convert_A_const_418 = A_arbace_repr_go_convert_A_const_pool.A[762]; A_arbace_repr_go_convert_A_const_419 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[763]); A_arbace_repr_go_convert_A_const_420 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[764]); A_arbace_repr_go_convert_A_const_421 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[765]); A_arbace_repr_go_convert_A_const_422 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[766]); A_arbace_repr_go_convert_A_const_423 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[767]); A_arbace_repr_go_convert_A_const_424 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[768]); A_arbace_repr_go_convert_A_const_425 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[769]); A_arbace_repr_go_convert_A_const_426 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[770]); A_arbace_repr_go_convert_A_const_427 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[771]); A_arbace_repr_go_convert_A_const_428 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[772]) }

func A_arbace_repr_go_convert_A_clinit_p35() { A_arbace_repr_go_convert_A_const_429 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[773]); A_arbace_repr_go_convert_A_const_430 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[774]); A_arbace_repr_go_convert_A_const_431 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[775]); A_arbace_repr_go_convert_A_const_432 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[776]); A_arbace_repr_go_convert_A_const_433 = A_arbace_repr_go_convert_A_const_pool.A[777]; A_arbace_repr_go_convert_A_const_434 = A_arbace_repr_go_convert_A_const_pool.A[778]; A_arbace_repr_go_convert_A_const_435 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[779]); A_arbace_repr_go_convert_A_const_436 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[780]); A_arbace_repr_go_convert_A_const_437 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[781]); A_arbace_repr_go_convert_A_const_438 = A_arbace_repr_go_convert_A_const_pool.A[782]; A_arbace_repr_go_convert_A_const_439 = A_arbace_repr_go_convert_A_const_pool.A[783]; A_arbace_repr_go_convert_A_const_440 = A_arbace_repr_go_convert_A_const_pool.A[784]; A_arbace_repr_go_convert_A_const_441 = A_arbace_repr_go_convert_A_const_pool.A[785] }

func A_arbace_repr_go_convert_A_clinit_p36() { A_arbace_repr_go_convert_A_const_442 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[786]); A_arbace_repr_go_convert_A_const_443 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[787]); A_arbace_repr_go_convert_A_const_444 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[788]); A_arbace_repr_go_convert_A_const_445 = A_arbace_repr_go_convert_A_const_pool.A[789]; A_arbace_repr_go_convert_A_const_446 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[790]); A_arbace_repr_go_convert_A_const_447 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[791]); A_arbace_repr_go_convert_A_const_448 = A_arbace_repr_go_convert_A_const_pool.A[792]; A_arbace_repr_go_convert_A_const_449 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[793]); A_arbace_repr_go_convert_A_const_450 = A_arbace_repr_go_convert_A_const_pool.A[794]; A_arbace_repr_go_convert_A_const_451 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[795]); A_arbace_repr_go_convert_A_const_452 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[796]); A_arbace_repr_go_convert_A_const_453 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[797]); A_arbace_repr_go_convert_A_const_454 = A_arbace_repr_go_convert_A_const_pool.A[798] }

func A_arbace_repr_go_convert_A_clinit_p37() { A_arbace_repr_go_convert_A_const_455 = A_arbace_repr_go_convert_A_const_pool.A[799]; A_arbace_repr_go_convert_A_const_456 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[800]); A_arbace_repr_go_convert_A_const_457 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[801]); A_arbace_repr_go_convert_A_const_458 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[802]); A_arbace_repr_go_convert_A_const_459 = A_arbace_repr_go_convert_A_const_pool.A[803]; A_arbace_repr_go_convert_A_const_460 = A_arbace_repr_go_convert_A_const_pool.A[804]; A_arbace_repr_go_convert_A_const_461 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[805]); A_arbace_repr_go_convert_A_const_462 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[806]); A_arbace_repr_go_convert_A_const_463 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[807]); A_arbace_repr_go_convert_A_const_464 = A_arbace_repr_go_convert_A_const_pool.A[808]; A_arbace_repr_go_convert_A_const_465 = A_arbace_repr_go_convert_A_const_pool.A[809]; A_arbace_repr_go_convert_A_const_466 = A_arbace_repr_go_convert_A_const_pool.A[810]; A_arbace_repr_go_convert_A_const_467 = A_arbace_repr_go_convert_A_const_pool.A[811] }

func A_arbace_repr_go_convert_A_clinit_p38() { A_arbace_repr_go_convert_A_const_468 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[812]); A_arbace_repr_go_convert_A_const_469 = A_arbace_repr_go_convert_A_const_pool.A[813]; A_arbace_repr_go_convert_A_const_470 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[814]); A_arbace_repr_go_convert_A_const_471 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[815]); A_arbace_repr_go_convert_A_const_472 = A_arbace_repr_go_convert_A_const_pool.A[816]; A_arbace_repr_go_convert_A_const_473 = A_arbace_repr_go_convert_A_const_pool.A[817]; A_arbace_repr_go_convert_A_const_474 = A_arbace_repr_go_convert_A_const_pool.A[818]; A_arbace_repr_go_convert_A_const_475 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[819]); A_arbace_repr_go_convert_A_const_476 = A_arbace_repr_go_convert_A_const_pool.A[820]; A_arbace_repr_go_convert_A_const_477 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[821]); A_arbace_repr_go_convert_A_const_478 = A_arbace_repr_go_convert_A_const_pool.A[822]; A_arbace_repr_go_convert_A_const_479 = A_arbace_repr_go_convert_A_const_pool.A[823]; A_arbace_repr_go_convert_A_const_480 = A_arbace_repr_go_convert_A_const_pool.A[824]; A_arbace_repr_go_convert_A_const_481 = A_arbace_repr_go_convert_A_const_pool.A[825] }

func A_arbace_repr_go_convert_A_clinit_p39() { A_arbace_repr_go_convert_A_const_482 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[826]); A_arbace_repr_go_convert_A_const_483 = A_arbace_repr_go_convert_A_const_pool.A[827]; A_arbace_repr_go_convert_A_const_484 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[828]); A_arbace_repr_go_convert_A_const_485 = A_arbace_repr_go_convert_A_const_pool.A[829]; A_arbace_repr_go_convert_A_const_486 = A_arbace_repr_go_convert_A_const_pool.A[830]; A_arbace_repr_go_convert_A_const_487 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[831]); A_arbace_repr_go_convert_A_const_488 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[832]); A_arbace_repr_go_convert_A_const_489 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[833]); A_arbace_repr_go_convert_A_const_490 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[834]); A_arbace_repr_go_convert_A_const_491 = A_arbace_repr_go_convert_A_const_pool.A[835]; A_arbace_repr_go_convert_A_const_492 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[836]); A_arbace_repr_go_convert_A_const_493 = A_arbace_repr_go_convert_A_const_pool.A[837]; A_arbace_repr_go_convert_A_const_494 = A_arbace_repr_go_convert_A_const_pool.A[838] }

func A_arbace_repr_go_convert_A_clinit_p40() { A_arbace_repr_go_convert_A_const_495 = A_arbace_repr_go_convert_A_const_pool.A[839]; A_arbace_repr_go_convert_A_const_496 = A_arbace_repr_go_convert_A_const_pool.A[840]; A_arbace_repr_go_convert_A_const_497 = A_arbace_repr_go_convert_A_const_pool.A[841]; A_arbace_repr_go_convert_A_const_498 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[842]); A_arbace_repr_go_convert_A_const_499 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[843]); A_arbace_repr_go_convert_A_const_500 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[844]); A_arbace_repr_go_convert_A_const_501 = A_arbace_repr_go_convert_A_const_pool.A[845]; A_arbace_repr_go_convert_A_const_502 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[846]); A_arbace_repr_go_convert_A_const_503 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[847]); A_arbace_repr_go_convert_A_const_504 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[848]); A_arbace_repr_go_convert_A_const_505 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[849]); A_arbace_repr_go_convert_A_const_506 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[850]); A_arbace_repr_go_convert_A_const_507 = A_arbace_repr_go_convert_A_const_pool.A[851] }

func A_arbace_repr_go_convert_A_clinit_p41() { A_arbace_repr_go_convert_A_const_508 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[852]); A_arbace_repr_go_convert_A_const_509 = A_arbace_repr_go_convert_A_const_pool.A[853]; A_arbace_repr_go_convert_A_const_510 = A_arbace_repr_go_convert_A_const_pool.A[854]; A_arbace_repr_go_convert_A_const_511 = A_arbace_repr_go_convert_A_const_pool.A[855]; A_arbace_repr_go_convert_A_const_512 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[856]); A_arbace_repr_go_convert_A_const_513 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[857]); A_arbace_repr_go_convert_A_const_514 = A_arbace_repr_go_convert_A_const_pool.A[858]; A_arbace_repr_go_convert_A_const_515 = A_arbace_repr_go_convert_A_const_pool.A[859]; A_arbace_repr_go_convert_A_const_516 = A_arbace_repr_go_convert_A_const_pool.A[860]; A_arbace_repr_go_convert_A_const_517 = A_arbace_repr_go_convert_A_const_pool.A[861]; A_arbace_repr_go_convert_A_const_518 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[862]); A_arbace_repr_go_convert_A_const_519 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[863]); A_arbace_repr_go_convert_A_const_520 = A_arbace_repr_go_convert_A_const_pool.A[864]; A_arbace_repr_go_convert_A_const_521 = A_arbace_repr_go_convert_A_const_pool.A[865] }

func A_arbace_repr_go_convert_A_clinit_p42() { A_arbace_repr_go_convert_A_const_522 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[866]); A_arbace_repr_go_convert_A_const_523 = A_arbace_repr_go_convert_A_const_pool.A[867]; A_arbace_repr_go_convert_A_const_524 = A_arbace_repr_go_convert_A_const_pool.A[868]; A_arbace_repr_go_convert_A_const_525 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[869]); A_arbace_repr_go_convert_A_const_526 = A_arbace_repr_go_convert_A_const_pool.A[870]; A_arbace_repr_go_convert_A_const_527 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[871]); A_arbace_repr_go_convert_A_const_528 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[872]); A_arbace_repr_go_convert_A_const_529 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[873]); A_arbace_repr_go_convert_A_const_530 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[874]); A_arbace_repr_go_convert_A_const_531 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[875]); A_arbace_repr_go_convert_A_const_532 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[876]); A_arbace_repr_go_convert_A_const_533 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[877]) }

func A_arbace_repr_go_convert_A_clinit_p43() { A_arbace_repr_go_convert_A_const_534 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[878]); A_arbace_repr_go_convert_A_const_535 = A_arbace_repr_go_convert_A_const_pool.A[879]; A_arbace_repr_go_convert_A_const_536 = A_arbace_repr_go_convert_A_const_pool.A[880]; A_arbace_repr_go_convert_A_const_537 = A_arbace_repr_go_convert_A_const_pool.A[881]; A_arbace_repr_go_convert_A_const_538 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[882]); A_arbace_repr_go_convert_A_const_539 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[883]); A_arbace_repr_go_convert_A_const_540 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[884]); A_arbace_repr_go_convert_A_const_541 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[885]); A_arbace_repr_go_convert_A_const_542 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[886]); A_arbace_repr_go_convert_A_const_543 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[887]); A_arbace_repr_go_convert_A_const_544 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[888]); A_arbace_repr_go_convert_A_const_545 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[889]) }

func A_arbace_repr_go_convert_A_clinit_p44() { A_arbace_repr_go_convert_A_const_546 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[890]); A_arbace_repr_go_convert_A_const_547 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[891]); A_arbace_repr_go_convert_A_const_548 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[892]); A_arbace_repr_go_convert_A_const_549 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[893]); A_arbace_repr_go_convert_A_const_550 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[894]); A_arbace_repr_go_convert_A_const_551 = A_arbace_repr_go_convert_A_const_pool.A[895]; A_arbace_repr_go_convert_A_const_552 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[896]); A_arbace_repr_go_convert_A_const_553 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[897]); A_arbace_repr_go_convert_A_const_554 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[898]); A_arbace_repr_go_convert_A_const_555 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[899]); A_arbace_repr_go_convert_A_const_556 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[900]); A_arbace_repr_go_convert_A_const_557 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[901]) }

func A_arbace_repr_go_convert_A_clinit_p45() { A_arbace_repr_go_convert_A_const_558 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[902]); A_arbace_repr_go_convert_A_const_559 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[903]); A_arbace_repr_go_convert_A_const_560 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[904]); A_arbace_repr_go_convert_A_const_561 = A_arbace_repr_go_convert_A_const_pool.A[905]; A_arbace_repr_go_convert_A_const_562 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[906]); A_arbace_repr_go_convert_A_const_563 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[907]); A_arbace_repr_go_convert_A_const_564 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[908]); A_arbace_repr_go_convert_A_const_565 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[909]); A_arbace_repr_go_convert_A_const_566 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[910]); A_arbace_repr_go_convert_A_const_567 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[911]); A_arbace_repr_go_convert_A_const_568 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[912]); A_arbace_repr_go_convert_A_const_569 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[913]) }

func A_arbace_repr_go_convert_A_clinit_p46() { A_arbace_repr_go_convert_A_const_570 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[914]); A_arbace_repr_go_convert_A_const_571 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[915]); A_arbace_repr_go_convert_A_const_572 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[916]); A_arbace_repr_go_convert_A_const_573 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[917]); A_arbace_repr_go_convert_A_const_574 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[918]); A_arbace_repr_go_convert_A_const_575 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[919]); A_arbace_repr_go_convert_A_const_576 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[920]); A_arbace_repr_go_convert_A_const_577 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[921]); A_arbace_repr_go_convert_A_const_578 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[922]); A_arbace_repr_go_convert_A_const_579 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[923]); A_arbace_repr_go_convert_A_const_580 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[924]); A_arbace_repr_go_convert_A_const_581 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[925]) }

func A_arbace_repr_go_convert_A_clinit_p47() { A_arbace_repr_go_convert_A_const_582 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[926]); A_arbace_repr_go_convert_A_const_583 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[927]); A_arbace_repr_go_convert_A_const_584 = A_arbace_repr_go_convert_A_const_pool.A[928]; A_arbace_repr_go_convert_A_const_585 = A_arbace_repr_go_convert_A_const_pool.A[929]; A_arbace_repr_go_convert_A_const_586 = A_arbace_repr_go_convert_A_const_pool.A[930]; A_arbace_repr_go_convert_A_const_587 = A_arbace_repr_go_convert_A_const_pool.A[931]; A_arbace_repr_go_convert_A_const_588 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[932]); A_arbace_repr_go_convert_A_const_589 = A_arbace_repr_go_convert_A_const_pool.A[933]; A_arbace_repr_go_convert_A_const_590 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[934]); A_arbace_repr_go_convert_A_const_591 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[935]); A_arbace_repr_go_convert_A_const_592 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[936]); A_arbace_repr_go_convert_A_const_593 = A_arbace_repr_go_convert_A_const_pool.A[937]; A_arbace_repr_go_convert_A_const_594 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[938]) }

func A_arbace_repr_go_convert_A_clinit_p48() { A_arbace_repr_go_convert_A_const_595 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[939]); A_arbace_repr_go_convert_A_const_596 = A_arbace_repr_go_convert_A_const_pool.A[940]; A_arbace_repr_go_convert_A_const_597 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[941]); A_arbace_repr_go_convert_A_const_598 = A_arbace_repr_go_convert_A_const_pool.A[942]; A_arbace_repr_go_convert_A_const_599 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[943]); A_arbace_repr_go_convert_A_const_600 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[944]); A_arbace_repr_go_convert_A_const_601 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[945]); A_arbace_repr_go_convert_A_const_602 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[946]); A_arbace_repr_go_convert_A_const_603 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[947]); A_arbace_repr_go_convert_A_const_604 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[948]); A_arbace_repr_go_convert_A_const_605 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[949]); A_arbace_repr_go_convert_A_const_606 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[950]) }

func A_arbace_repr_go_convert_A_clinit_p49() { A_arbace_repr_go_convert_A_const_607 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[951]); A_arbace_repr_go_convert_A_const_608 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[952]); A_arbace_repr_go_convert_A_const_609 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[953]); A_arbace_repr_go_convert_A_const_610 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[954]); A_arbace_repr_go_convert_A_const_611 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[955]); A_arbace_repr_go_convert_A_const_612 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[956]); A_arbace_repr_go_convert_A_const_613 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[957]); A_arbace_repr_go_convert_A_const_614 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[958]); A_arbace_repr_go_convert_A_const_615 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[959]); A_arbace_repr_go_convert_A_const_616 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[960]); A_arbace_repr_go_convert_A_const_617 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[961]); A_arbace_repr_go_convert_A_const_618 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[962]) }

func A_arbace_repr_go_convert_A_clinit_p50() { A_arbace_repr_go_convert_A_const_619 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[963]); A_arbace_repr_go_convert_A_const_620 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[964]); A_arbace_repr_go_convert_A_const_621 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[965]); A_arbace_repr_go_convert_A_const_622 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[966]); A_arbace_repr_go_convert_A_const_623 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[967]); A_arbace_repr_go_convert_A_const_624 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[968]); A_arbace_repr_go_convert_A_const_625 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[969]); A_arbace_repr_go_convert_A_const_626 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[970]); A_arbace_repr_go_convert_A_const_627 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[971]); A_arbace_repr_go_convert_A_const_628 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[972]); A_arbace_repr_go_convert_A_const_629 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[973]); A_arbace_repr_go_convert_A_const_630 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[974]) }

func A_arbace_repr_go_convert_A_clinit_p51() { A_arbace_repr_go_convert_A_const_631 = lang.Keyword_Cast(A_arbace_repr_go_convert_A_const_pool.A[975]); A_arbace_repr_go_convert_A_const_632 = lang.Var_Cast(A_arbace_repr_go_convert_A_const_pool.A[976]); A_arbace_repr_go_convert_A_const_633 = A_arbace_repr_go_convert_A_const_pool.A[977]; A_arbace_repr_go_convert_A_const_634 = A_arbace_repr_go_convert_A_const_pool.A[978]; A_arbace_repr_go_convert_A_const_635 = A_arbace_repr_go_convert_A_const_pool.A[979]; A_arbace_repr_go_convert_A_const_636 = A_arbace_repr_go_convert_A_const_pool.A[980] }

func A_arbace_repr_go_convert_A_New() *A_arbace_repr_go_convert_A { A_arbace_repr_go_convert_A_Init(); t := &A_arbace_repr_go_convert_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_convert_A) Ctor() {}

func (t *A_arbace_repr_go_convert_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_convert_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_convert_A_class }

func (t *A_arbace_repr_go_convert_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_convert_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_convert_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_convert_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_convert_A); return ok }

func A_arbace_repr_go_convert_A_Cast(x any) *A_arbace_repr_go_convert_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_convert_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_convert_A_class)) }; return v }



type A_arbace_repr_go_convert_add_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_add_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_add_parens_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_add_parens_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_add_parens_fn__1114000066_A struct{ j2g_header uint64; F_pr any }

var A_arbace_repr_go_convert_add_parens_fn__1114000066_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_add_parens_fn__1114000068_A struct{ j2g_header uint64; F_pr any }

var A_arbace_repr_go_convert_add_parens_fn__1114000068_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_an_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_an_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_as_inst_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_as_inst_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_assign_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_assign_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_at_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_at_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_at_fn__1114000046_A struct{ j2g_header uint64; F_l, F_n any }

var A_arbace_repr_go_convert_at_fn__1114000046_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A struct{ j2g_header uint64; F_n any }

var A_arbace_repr_go_convert_at_fn__1114000046_fn__1114000048_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_attachable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_attachable_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_basic_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_basic_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_basic_lit_extents_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_basic_lit_extents_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_basic_lit_extents_fn__1114000688_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A struct{ j2g_header uint64; F_s__1114000675, F_iter__1114000674 any }

var A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A struct{ j2g_header uint64; F_b__1114000677 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_basic_lit_extents_iter__1114000674__1114000678_fn__1114000679_fn__1114000680_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_bindings_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_bindings_of_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_block_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_block_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_block_pos_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_block_pos_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_branch_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_branch_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_builtin_name_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_builtin_name_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_call_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_call_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_call_fn__1114000192_A struct{ j2g_header uint64; F_fun any }

var A_arbace_repr_go_convert_call_fn__1114000192_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_call_args_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_call_args_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_case_clause_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_case_clause_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_case_clause_fn__1114000381_A struct{ j2g_header uint64; F_tswitch any }

var A_arbace_repr_go_convert_case_clause_fn__1114000381_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_clause_bound_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_clause_bound_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_clauses_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_clauses_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_clauses_fn__1114000384_A struct{ j2g_header uint64; F_body, F_tswitch any }

var A_arbace_repr_go_convert_clauses_fn__1114000384_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_comm_clause_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_comm_clause_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_composite_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_composite_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_composite_fn__1114000201_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_composite_fn__1114000201_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_composite_fn__1114000203_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_composite_fn__1114000203_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_const_val_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_const_val_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A struct{ j2g_header uint64; F_placed, F_plan any }

var A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000750_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_attach_meta__1114000748_fn__1114000755_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000706_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_fn__1114000706_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000709_A struct{ j2g_header uint64; F_pkg_pos any }

var A_arbace_repr_go_convert_convert_file_fn__1114000709_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000715_A struct{ j2g_header uint64; F_pkg_pos any }

var A_arbace_repr_go_convert_convert_file_fn__1114000715_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000720_A struct{ j2g_header uint64; F_ranges any }

var A_arbace_repr_go_convert_convert_file_fn__1114000720_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000735_A struct{ j2g_header uint64; F_inside_of, F_ranges, F_last_import, F_decls any }

var A_arbace_repr_go_convert_convert_file_fn__1114000735_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A struct{ j2g_header uint64; F_l, F_c any }

var A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000739_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A struct{ j2g_header uint64; F_l, F_c any }

var A_arbace_repr_go_convert_convert_file_fn__1114000735_fn__1114000742_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000758_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_fn__1114000758_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000760_A struct{ j2g_header uint64; F_placed any }

var A_arbace_repr_go_convert_convert_file_fn__1114000760_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000762_A struct{ j2g_header uint64; F_f, F_doc, F_name, F_dump, F_imports, F_fe, F_header, F_pkg_line any }

var A_arbace_repr_go_convert_convert_file_fn__1114000762_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000763_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000765_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000767_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_fn__1114000762_fn__1114000769_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000802_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_fn__1114000802_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000807_A struct{ j2g_header uint64; F_attach_meta, F_placed, F_plan, F_decls any }

var A_arbace_repr_go_convert_convert_file_fn__1114000807_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A struct{ j2g_header uint64; F_attach_meta, F_placed, F_plan any }

var A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A struct{ j2g_header uint64; F_placed any }

var A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000809_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A struct{ j2g_header uint64; F_k, F_attach_meta any }

var A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000808_fn__1114000812_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A struct{ j2g_header uint64; F_placed any }

var A_arbace_repr_go_convert_convert_file_fn__1114000807_fn__1114000815_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000819_A struct{ j2g_header uint64; F_placed any }

var A_arbace_repr_go_convert_convert_file_fn__1114000819_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000824_A struct{ j2g_header uint64; F_kept, F_dirs any }

var A_arbace_repr_go_convert_convert_file_fn__1114000824_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A struct{ j2g_header uint64; F_dirs any }

var A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A struct{ j2g_header uint64; F_l, F_c any }

var A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000834_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A struct{ j2g_header uint64; F_l any }

var A_arbace_repr_go_convert_convert_file_fn__1114000824_fn__1114000826_fn__1114000840_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A struct{ j2g_header uint64; F_ranges any }

var A_arbace_repr_go_convert_convert_file_inside_of__1114000723_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A struct{ j2g_header uint64; F_l, F_c any }

var A_arbace_repr_go_convert_convert_file_inside_of__1114000723_fn__1114000728_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A struct{ j2g_header uint64; F_s__1114000697, F_iter__1114000696 any }

var A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A struct{ j2g_header uint64; F_b__1114000699 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_convert_file_iter__1114000696__1114000700_fn__1114000701_fn__1114000702_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A struct{ j2g_header uint64; F_s__1114000773, F_iter__1114000772 any }

var A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A struct{ j2g_header uint64; F_s__1114000775, F_iter__1114000774 any }

var A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A struct{ j2g_header uint64; F_b__1114000777 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_convert_file_iter__1114000772__1114000778_fn__1114000779_iter__1114000774__1114000780_fn__1114000781_fn__1114000782_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_package_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A struct{ j2g_header uint64; F_s__1114000891, F_iter__1114000890 any }

var A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A struct{ j2g_header uint64; F_b__1114000893 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_convert_package_iter__1114000890__1114000894_fn__1114000895_fn__1114000896_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A struct{ j2g_header uint64; F_ns_sym, F_dump, F_opts any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A struct{ j2g_header uint64; F_iter__1114000900, F_ns_sym, F_dump, F_opts, F_s__1114000901 any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A struct{ j2g_header uint64; F_ns_sym, F_b__1114000903, F_dump any; F_size__1927001038__auto__ int32; F_opts, F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A struct{ j2g_header uint64; F_ns_sym, F_dump, F_fe, F_opts any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_fn__1114000923_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A struct{ j2g_header uint64; F_s__1114000908, F_iter__1114000907 any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A struct{ j2g_header uint64; F_iter__1114000909, F_s__1114000910 any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A struct{ j2g_header uint64; F_b__1114000912 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000906_iter__1114000907__1114000913_fn__1114000914_iter__1114000909__1114000915_fn__1114000916_fn__1114000917_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A struct{ j2g_header uint64; F_ns_sym, F_dump, F_fe, F_opts any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_fn__1114000942_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A struct{ j2g_header uint64; F_s__1114000927, F_iter__1114000926 any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A struct{ j2g_header uint64; F_s__1114000929, F_iter__1114000928 any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A struct{ j2g_header uint64; F_b__1114000931 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_convert_package_iter__1114000900__1114000904_fn__1114000905_iter__1114000926__1114000932_fn__1114000933_iter__1114000928__1114000934_fn__1114000935_fn__1114000936_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_count_node_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_count_node_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_bindings_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_decl_bindings_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A struct{ j2g_header uint64; F_specs, F_gd any }

var A_arbace_repr_go_convert_decl_bindings_fn__1114000244_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A struct{ j2g_header uint64; F_type, F_l any }

var A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000250_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A struct{ j2g_header uint64; F_values, F_l any }

var A_arbace_repr_go_convert_decl_bindings_fn__1114000244_fn__1114000255_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A struct{ j2g_header uint64; F_t any }

var A_arbace_repr_go_convert_decl_bindings_fn__1114000244_mk__1114000252_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A struct{ j2g_header uint64; F_specs, F_gd any }

var A_arbace_repr_go_convert_decl_bindings_fn__1114000258_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A struct{ j2g_header uint64; F_t any }

var A_arbace_repr_go_convert_decl_bindings_fn__1114000258_mk__1114000261_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A struct{ j2g_header uint64; F_specs, F_gd any }

var A_arbace_repr_go_convert_decl_bindings_fn__1114000264_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_name_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_decl_name_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_decl_stmt_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_decl_stmt_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_define_binding_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_define_binding_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_define_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_define_target_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_dir_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_dir_form_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_directive_args_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_directive_args_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_directive_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_directive_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_directive_meta_fn__1114000415_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_directive_meta_fn__1114000415_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A struct{ j2g_header uint64; F_v any }

var A_arbace_repr_go_convert_directive_meta_fn__1114000415_fn__1114000416_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_directive_name_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_directive_name_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_doc_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_doc_of_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_eval1114000004_A struct{ jrt.Object }

func A_arbace_repr_go_convert_eval1114000004_A_New() *A_arbace_repr_go_convert_eval1114000004_A { t := &A_arbace_repr_go_convert_eval1114000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_convert_eval1114000004_A) Ctor() {}

func (t *A_arbace_repr_go_convert_eval1114000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_convert_eval1114000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_convert_eval1114000004_A_class }

func (t *A_arbace_repr_go_convert_eval1114000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_convert_eval1114000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_convert_eval1114000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_convert_eval1114000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_convert_eval1114000004_A); return ok }

func A_arbace_repr_go_convert_eval1114000004_A_Cast(x any) *A_arbace_repr_go_convert_eval1114000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_convert_eval1114000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_convert_eval1114000004_A_class)) }; return v }



type A_arbace_repr_go_convert_eval1114000004_loading__1927001464__auto____1114000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_eval1114000004_loading__1927001464__auto____1114000005_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_eval1114000008_A struct{ jrt.Object }

func A_arbace_repr_go_convert_eval1114000008_A_New() *A_arbace_repr_go_convert_eval1114000008_A { t := &A_arbace_repr_go_convert_eval1114000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_convert_eval1114000008_A) Ctor() {}

func (t *A_arbace_repr_go_convert_eval1114000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_convert_eval1114000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_convert_eval1114000008_A_class }

func (t *A_arbace_repr_go_convert_eval1114000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_convert_eval1114000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_convert_eval1114000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_convert_eval1114000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_convert_eval1114000008_A); return ok }

func A_arbace_repr_go_convert_eval1114000008_A_Cast(x any) *A_arbace_repr_go_convert_eval1114000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_convert_eval1114000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_convert_eval1114000008_A_class)) }; return v }



type A_arbace_repr_go_convert_eval1114000008_fn__1114000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_eval1114000008_fn__1114000009_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_expr_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_expr_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_expr_fn__1114000216_A struct{ j2g_header uint64; F_x any }

var A_arbace_repr_go_convert_expr_fn__1114000216_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_expr_fn__1114000220_A struct{ j2g_header uint64; F_l any }

var A_arbace_repr_go_convert_expr_fn__1114000220_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_expr_fn__1114000227_A struct{ j2g_header uint64; F_operand, F_logical, F_f, F_n, F_op any }

var A_arbace_repr_go_convert_expr_fn__1114000227_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_expr_fn__1114000230_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_expr_fn__1114000230_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_expr_operand__1114000225_A struct{ j2g_header uint64; F_logical any }

var A_arbace_repr_go_convert_expr_operand__1114000225_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_fail_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_fail_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_fail_fn__1114000016_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_fail_fn__1114000016_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_fields_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_fields_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_fields_fn__1114000114_A struct{ j2g_header uint64; F_struct_QMARK_ any }

var A_arbace_repr_go_convert_fields_fn__1114000114_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A struct{ j2g_header uint64; F_extra, F_tag_full, F_t any }

var A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A struct{ j2g_header uint64; F_iter__1114000118, F_extra, F_tag_full, F_t, F_s__1114000119 any }

var A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A struct{ j2g_header uint64; F_extra, F_tag_full, F_t any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1114000121 any }

var A_arbace_repr_go_convert_fields_fn__1114000114_iter__1114000118__1114000122_fn__1114000123_fn__1114000124_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_file_directives_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_file_directives_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A struct{ j2g_header uint64; F_prefix any }

var A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A struct{ j2g_header uint64; F_prefix, F_s__1114000461, F_iter__1114000460 any }

var A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A struct{ j2g_header uint64; F_b__1114000463, F_prefix any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_file_directives_iter__1114000460__1114000464_fn__1114000465_fn__1114000466_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_file_stem_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_file_stem_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_fn_sig_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_fn_sig_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_form_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_free_directive_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_free_directive_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_full_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_full_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_func_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_func_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_func_decl_fn__1114000434_A struct{ j2g_header uint64; F_body, F_has_results any }

var A_arbace_repr_go_convert_func_decl_fn__1114000434_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_func_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_func_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_func_lit_fn__1114000210_A struct{ j2g_header uint64; F_has_results, F_body any }

var A_arbace_repr_go_convert_func_lit_fn__1114000210_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gap_directives_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_gap_directives_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gap_directives_fn__1114000280_A struct{ j2g_header uint64; F_from, F_to any }

var A_arbace_repr_go_convert_gap_directives_fn__1114000280_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gap_directives_fn__1114000285_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_gap_directives_fn__1114000285_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gap_directives_fn__1114000296_A struct{ j2g_header uint64; F_inside_QMARK_ any }

var A_arbace_repr_go_convert_gap_directives_fn__1114000296_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gap_directives_fn__1114000302_A struct{ j2g_header uint64; F_stmts, F_ranges any }

var A_arbace_repr_go_convert_gap_directives_fn__1114000302_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A struct{ j2g_header uint64; F_l, F_c any }

var A_arbace_repr_go_convert_gap_directives_fn__1114000302_fn__1114000307_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A struct{ j2g_header uint64; F_ranges any }

var A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A struct{ j2g_header uint64; F_p any }

var A_arbace_repr_go_convert_gap_directives_inside_QMARK___1114000287_fn__1114000289_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gen_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_gen_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gen_decl_fn__1114000448_A struct{ j2g_header uint64; F_spec any }

var A_arbace_repr_go_convert_gen_decl_fn__1114000448_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gen_decl_spec__1114000444_A struct{ j2g_header uint64; F_spec_meta any }

var A_arbace_repr_go_convert_gen_decl_spec__1114000444_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A struct{ j2g_header uint64; F_spec_meta, F_kind any }

var A_arbace_repr_go_convert_gen_decl_spec_vec__1114000453_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_generic_decl_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_generic_decl_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_group_marks_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_group_marks_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_group_marks_fn__1114000104_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_group_marks_fn__1114000104_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_ident_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_ident_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_ident_name_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_ident_name_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_if_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_if_form_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_if_form_fn__1114000353_A struct{ j2g_header uint64; F_test, F_else, F_body any }

var A_arbace_repr_go_convert_if_form_fn__1114000353_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_if_form_fn__1114000366_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_if_form_fn__1114000366_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_if_form_fn__1114000372_A struct{ j2g_header uint64; F_n any }

var A_arbace_repr_go_convert_if_form_fn__1114000372_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_imports_of_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A struct{ j2g_header uint64; F_iter__1114000489, F_s__1114000490 any }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A struct{ j2g_header uint64; F_d any }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A struct{ j2g_header uint64; F_d, F_s__1114000492, F_iter__1114000491 any }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A struct{ j2g_header uint64; F_d, F_i any }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_decl_pos__1114000519_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A struct{ j2g_header uint64; F_d any; F_size__1927001038__auto__ int32; F_b__1114000494, F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A struct{ j2g_header uint64; F_d, F_i any }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_decl_pos__1114000508_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_fn__1114000499_nm__1114000506_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_go_convert_imports_of_iter__1114000489__1114000495_fn__1114000496_iter__1114000491__1114000497_fn__1114000498_nm__1114000517_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_init_order_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_init_order_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A struct{ j2g_header uint64; F_s__1114000849, F_iter__1114000848 any }

var A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A struct{ j2g_header uint64; F_b__1114000851 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_fn__1114000854_one__1114000858_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_init_order_iter__1114000848__1114000852_fn__1114000853_one__1114000870_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_init_vec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_init_vec_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_inits_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_inits_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_inst_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_inst_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_instantiation_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_instantiation_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_interface_elems_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_interface_elems_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A struct{ j2g_header uint64; F_s__1114000131, F_iter__1114000130 any }

var A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A struct{ j2g_header uint64; F_b__1114000133 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_interface_elems_iter__1114000130__1114000134_fn__1114000135_fn__1114000136_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_label_kw_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_label_kw_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_line_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_line_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_line_of_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_lit_at_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_lit_at_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_lit_spelling_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_lit_spelling_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_mark_ungrouped_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_mark_ungrouped_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A struct{ j2g_header uint64; F_names_only, F_elems any }

var A_arbace_repr_go_convert_mark_ungrouped_fn__1114000107_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_max_pos_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_max_pos_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_max_pos_walk__1114000036_A struct{ j2g_header uint64; F_best any }

var A_arbace_repr_go_convert_max_pos_walk__1114000036_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_munge_name_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_munge_name_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_nf_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_nf_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_note_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_note_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_nt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_nt_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_obj_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_obj_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_package_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_package_form_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_package_form_fn__1114000886_A struct{ j2g_header uint64; F_dump any }

var A_arbace_repr_go_convert_package_form_fn__1114000886_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_parse_pos_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_parse_pos_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_pkg_ident_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_pkg_ident_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_pos_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_pos_line_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_positions_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_positions_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_positions_fn__1114000030_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_positions_fn__1114000030_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_relined_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_relined_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_relined_fn__1114000080_A struct{ j2g_header uint64; F_l any }

var A_arbace_repr_go_convert_relined_fn__1114000080_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_relined_fn__1114000082_A struct{ j2g_header uint64; F_l any }

var A_arbace_repr_go_convert_relined_fn__1114000082_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_relined_fn__1114000084_A struct{ j2g_header uint64; F_l any }

var A_arbace_repr_go_convert_relined_fn__1114000084_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_reparen_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_reparen_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_selection_via_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_selection_via_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_selector_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_selector_form_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_signature_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_signature_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_simple_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_simple_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_source_text_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_fn__1114000529_A struct{ j2g_header uint64; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_fn__1114000529_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_fn__1114000607_A struct{ j2g_header uint64; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_fn__1114000607_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_fn__1114000629_A struct{ j2g_header uint64; F_bs, F_i any; F_ob int64 }

var A_arbace_repr_go_convert_source_text_fn__1114000629_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_fn__1114000631_A struct{ j2g_header uint64; F_bs, F_lim, F_i any }

var A_arbace_repr_go_convert_source_text_fn__1114000631_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_fn__1114000633_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_source_text_fn__1114000633_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_fn__1114000635_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_source_text_fn__1114000635_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A struct{ j2g_header uint64; F_text, F_off any; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A struct{ j2g_header uint64; F_text, F_iter__1114000539, F_off any; F_n int32; F_bs, F_s__1114000540 any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A struct{ j2g_header uint64; F_text, F_off any; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A struct{ j2g_header uint64; F_text, F_off any; F_n int32; F_bs, F_s__1114000542, F_iter__1114000541 any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A struct{ j2g_header uint64; F_b__1114000544, F_text, F_off any; F_n int32; F_bs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A struct{ j2g_header uint64; F_o any; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000556_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A struct{ j2g_header uint64; F_o any; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000549_fn__1114000558_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A struct{ j2g_header uint64; F_o any; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000567_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A struct{ j2g_header uint64; F_o any; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000539__1114000545_fn__1114000546_iter__1114000541__1114000547_fn__1114000548_fn__1114000569_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A struct{ j2g_header uint64; F_off any }

var A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A struct{ j2g_header uint64; F_off, F_s__1114000576, F_iter__1114000575 any }

var A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A struct{ j2g_header uint64; F_b__1114000578, F_off any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_source_text_iter__1114000575__1114000579_fn__1114000580_fn__1114000581_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A struct{ j2g_header uint64; F_off any }

var A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A struct{ j2g_header uint64; F_off, F_s__1114000592, F_iter__1114000591 any }

var A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A struct{ j2g_header uint64; F_off any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1114000594 any }

var A_arbace_repr_go_convert_source_text_iter__1114000591__1114000595_fn__1114000596_fn__1114000597_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A struct{ j2g_header uint64; F_off any }

var A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A struct{ j2g_header uint64; F_s__1114000638, F_iter__1114000637, F_off any }

var A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A struct{ j2g_header uint64; F_b__1114000640, F_off any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_source_text_iter__1114000637__1114000641_fn__1114000642_fn__1114000643_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A struct{ j2g_header uint64; F_cstarts any; F_n int32; F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A struct{ j2g_header uint64; F_cstarts any; F_n int32; F_bs, F_s__1114000654, F_iter__1114000653 any }

var A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A struct{ j2g_header uint64; F_cstarts, F_b__1114000656 any; F_n int32; F_bs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A struct{ j2g_header uint64; F_cstarts any; F_n int32; F_o, F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000659_fn__1114000663_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A struct{ j2g_header uint64; F_cstarts any; F_n int32; F_o, F_bs any }

var A_arbace_repr_go_convert_source_text_iter__1114000653__1114000657_fn__1114000658_fn__1114000669_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_off__1114000532_A struct{ j2g_header uint64; F_starts any }

var A_arbace_repr_go_convert_source_text_off__1114000532_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_source_text_text__1114000537_A struct{ j2g_header uint64; F_bs any }

var A_arbace_repr_go_convert_source_text_text__1114000537_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_spelled_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_spelled_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_start_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_start_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmt_STAR__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_stmt_STAR__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_convert_stmt_STAR__fn__1114000397_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A struct{ j2g_header uint64; F_define bool }

var A_arbace_repr_go_convert_stmt_STAR__tgt__1114000407_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmt_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_stmt_list_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmts_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_stmts_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmts_forms_build__1114000327_A struct{ j2g_header uint64; F_n int32; F_stmts, F_tail, F_gaps any }

var A_arbace_repr_go_convert_stmts_forms_build__1114000327_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A struct{ j2g_header uint64; F_s, F_ll, F_dl any }

var A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000336_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A struct{ j2g_header uint64; F_n int32; F_stmts, F_i, F_bs, F_kind, F_gaps, F_kind_of any }

var A_arbace_repr_go_convert_stmts_forms_build__1114000327_fn__1114000338_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_stmts_forms_build__1114000327_kind_of__1114000334_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_stmts_forms_fn__1114000319_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A struct{ j2g_header uint64; F_list any }

var A_arbace_repr_go_convert_stmts_forms_fn__1114000325_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_string_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_string_value_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_tagged_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_tagged_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_targets_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_targets_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_targs_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_targs_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_type_form_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_type_form_fl_pos__1114000159_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_form_fn__1114000156_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_convert_type_form_fn__1114000156_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_params_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_type_params_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_params_STAR__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_type_params_STAR__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A struct{ j2g_header uint64; F_c any }

var A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A struct{ j2g_header uint64; F_s__1114000168, F_c, F_iter__1114000167 any }

var A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A struct{ j2g_header uint64; F_b__1114000170 any; F_size__1927001038__auto__ int32; F_c, F_c__1927001037__auto__ any }

var A_arbace_repr_go_convert_type_params_STAR__fn__1114000164_iter__1114000167__1114000171_fn__1114000172_fn__1114000173_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_unparen_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_unparen_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_untyped_const_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_untyped_const_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_value_spec_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_value_spec_target_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A struct{ j2g_header uint64; F_t, F_extra, F_kind any }

var A_arbace_repr_go_convert_value_spec_target_mk__1114000439_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_vec_at_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_vec_at_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_whitespace_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_whitespace_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_convert_with_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_with_line_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_with_pos_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_with_pos_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_with_pos_fn__1114000055_A struct{ j2g_header uint64 }

var A_arbace_repr_go_convert_with_pos_fn__1114000055_A_fn_class *jrt.Class



type A_arbace_repr_go_convert_with_pos_fn__1114000060_A struct{ j2g_header uint64; F_ps any }

var A_arbace_repr_go_convert_with_pos_fn__1114000060_A_fn_class *jrt.Class
