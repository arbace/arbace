//line j2g_strings.ae:1
package aot_arbace_repr_go_convert

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn18,arbace.repr.go.litkn2,asyn3,lityn25,arbace.repr.go.print-textyn5,ptextyn20,arbace.repr.go.typesyn2,tyyn13,arbace.stringyn3,stryn11,arbace.corekn3,dockn5,noteskn5,nodeskn4,nodekn10,paren-exprkn1,xkn4,elsekn9,send-stmtkn4,chankn10,array-typekn6,lbrackkn8,ellipsiskn7,if-stmtkn2,ifkn11,import-speckn4,namekn4,pathkn10,value-speckn5,nameskn10,unary-exprkn6,op-poskn5,identkn8,name-poskn11,return-stmtkn6,returnkn13,composite-litkn4,typekn6,lbracekn9,chan-typekn5,beginkn5,fieldkn8,map-typekn3,mapkn11,case-clausekn4,casekn10,field-listkn7,openingkn4,listkn10,index-exprkn9,decl-stmtkn4,declkn9,expr-stmtkn11,assign-stmtkn3,lhskn10,slice-exprkn9,call-exprkn3,funkn14,interface-typekn9,interfacekn14,key-value-exprkn3,keykn13,selector-exprkn10,empty-stmtkn9,semicolonkn9,type-speckn8,gen-declkn7,tok-poskn12,inc-dec-stmtkn8,for-stmtkn3,forkn12,labeled-stmtkn5,labelkn8,func-litkn9,star-exprkn4,starkn9,func-typekn4,funckn6,paramskn15,index-list-exprkn11,binary-exprkn11,switch-stmtkn6,switchkn10,defer-stmtkn5,deferkn9,basic-litkn9,value-poskn16,type-switch-stmtkn11,struct-typekn6,structkn10,range-stmtkn6,lparenkn16,type-assert-exprkn11,select-stmtkn6,selectkn11,branch-stmtkn7,go-stmtkn2,gokn11,comm-clausekn9,func-declkn10,block-stmtks22,arbace.repr.go.convert1,lks22,arbace.repr.go.convert3,posks22,arbace.repr.go.convert4,openks22,arbace.repr.go.convert4,fullkn6,parensks2,go6,parenskn6,rparenkn6,rbracekn4,linekn3,poskn5,spellkn5,colonkn3,usekn3,defkn5,targskn4,instkn4,kindys2,go2,idkn2,idkn8,universekn3,nilkn4,modekn5,constkn5,go-idkn3,pkgks2,go4,textkn5,valueyn9,imaginaryys2,go7,literalkn7,literalkn3,tagks2,go7,groupedkn4,textkn7,struct?yn5,slicekn3,eltks2,go3,tagks2,go7,tag-posks2,go8,tag-textyn1,&kn3,dirkn4,recvyn4,chankn5,arrowkn4,bothkn4,sendyn9,interfacekn7,methodskn7,closingkn7,indiceskn5,indexyn4,instyn6,structkn6,fieldskn3,lenyn5,arrayyn3,...kn2,opyn5,tildeyn3,mapkn3,selkn5,x-poskn1,yyn1,|ks2,go3,opsyn1,*kn7,resultsyn4,funckn15,results-openingkn15,results-closingkn3,anykn7,builtinkn4,argskn1,tkn3,viaks2,go3,viakn11,method-expryn11,method-exprkn6,methodys2,go6,selectyn6,spreadys2,go4,callkn4,callyn4,convyn3,newkn3,dotkn7,go-callkn4,eltsks2,go3,keykn4,bodykn4,tailyn2,fnks2,go3,endkn3,lowkn4,highkn3,maxyn8,subslicekn16,negative-literalyn2,oryn3,andks2,go5,parenkn13,logical-parenyn2,>>yn2,<<kn5,shiftkn9,shift-tagyn6,assertys2,go10,type-guardkn10,type-guardys2,go5,indexyn4,agetys2,go4,staryn5,derefks22,arbace.repr.go.convert5,derefyn6,valuesyn1,_ks2,go6,definekn6,definekn6,assignkn3,rhskn3,valkn3,tokkn5,specskn3,letkn6,valueskn20,local-const-repeatedks2,go8,implicitkn17,local-const-groupkn23,local-const-group-splityn4,zerokn3,varkn8,let-typekn11,type-paramskn5,aliaskn18,local-generic-typekn4,stmtys2,go9,directivekn19,directive-statementks2,go5,labelks2,go10,label-linekn11,label-colonyn3,letyn8,let-typekn19,labeled-declarationyn2,doyn4,whenyn2,ifyn4,condkn4,initkn4,condks2,go4,condkn11,else-lbracekn11,else-rbraceyn7,defaultyn4,casekn4,commyn4,asetkn6,rbrackyn4,set!ys2,go6,definekn11,define-stmtyn6,returnyn5,labelyn6,selectkn15,implicit-returnkn4,postyn5,whileyn3,foryn5,breakyn8,continueyn4,gotoyn11,fallthroughyn5,deferyn4,inc!yn4,dec!yn11,type-switchkn9,guard-tokkn9,guard-dotkn12,guard-lparenkn12,guard-rparenyn5,rangeyn6,switchyn2,>!yn2,gokn14,directive-freekn6,externkn12,recv-openingkn12,recv-closingys2,go6,methodys2,go4,funckn10,directiveskn6,importkn8,implicitkn8,commentskn5,semiskn6,trailskn5,spacekn9,value-endkn3,astkn4,filekn7,packagekn5,declskn6,attachkn5,innerkn10,in-importskn4,freekn18,directive-attachedys2,go4,filekn5,buildkn10,go-versionkn4,langkn7,importsks2,go8,commentsks2,go5,semisks2,go6,trailsks2,go5,spaceks2,go4,tailkn5,formsyn5,in-nsyn5,quoteks22,arbace.repr.go.convert3,rawkn8,unplacedkn18,directive-unplacedkn10,init-orderkn9,positionskn6,configkn8,go-fileskn7,s-fileskn7,h-fileskn10,syso-fileskn7,c-fileskn9,cxx-fileskn7,m-fileskn7,f-fileskn10,swig-fileskn14,swig-cxx-fileskn11,embed-fileskn16,test-embed-filesys2,go7,packagekn4,gooskn6,goarchkn7,goamd64kn7,goarm64kn9,toolchainkn4,tagskn12,goexperimentkn3,cgokn8,compilerkn5,fileskn11,other-fileskn13,test-go-fileskn10,test-fileskn13,local-importskn19,file-name-collisionkn2,nskn10,underlyingkn5,typeskn4,stemkn7,src-dirkn5,statskn3,rawkn4,fullkn8,text-dirkn10,type-tablekn10,namespacesv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,v11,arbace.core5,referR9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn22,arbace.repr.go.convertm2,R10,s878,repr/go's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.repr.go.lit/Lit (text and value). arbace.repr.go.layout writes them as text.\n\n  Raw mode (*raw*, doc/go/GO-PARSER-SURVEY.md GP3, doc/go/CONVERTER-NOTES.md \"Raw forms\"): the\n  forms of an un-annotated tree, every decision that needs types left open and marked (::open\n  in memory, a head or a public key in the text); no annotation is read.v22,arbace.repr.go.convert7,*stats*v11,arbace.core5,swap!v11,arbace.core9,update-inR11,v11,arbace.core4,fnilv11,arbace.core3,incl0,R12,v11,arbace.core5,firstv11,arbace.core7,ex-infov11,arbace.core6,pr-strv11,arbace.core4,seq?v11,arbace.core4,map?v11,arbace.core6,secondv11,arbace.core4,valsv11,arbace.core6,filterv11,arbace.core7,string?v11,arbace.core10,re-matchesp7,\\d+:\\d+R13,v22,arbace.repr.go.convert5,*raw*R14,v22,arbace.repr.go.convert2,ntR15,v22,arbace.repr.go.convert2,nfp7,\\d+:\\d+v11,arbace.core4,subsv22,arbace.repr.go.convert9,parse-posv22,arbace.repr.go.convert5,*src*R16,S3,l32,l13,l9,l1,R17,v22,arbace.repr.go.convert5,startR18,R19,R20,R21,R22,R23,v22,arbace.repr.go.convert4,failR24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,v11,arbace.core3,seqR41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,R73,R74,R75,R76,R77,R78,R79,R80,R81,R82,R83,R84,R85,R86,R87,R88,R89,R90,R91,R92,R93,R94,R95,R96,R97,R98,R99,v22,arbace.repr.go.convert8,pos-linev11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core4,keepv11,arbace.core9,volatile!V2,l0,l0,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core7,vector?v11,arbace.core4,run!v11,arbace.core7,vreset!v11,arbace.core10,chunk-restv11,arbace.core4,nextv11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core4,listR100,v11,arbace.core5,assocR101,v22,arbace.repr.go.convert9,positionsv11,arbace.core9,vary-metav11,arbace.core6,updatev11,arbace.core5,mergeR102,v22,arbace.repr.go.convert6,*full*R103,v11,arbace.core3,notv18,arbace.repr.go.lit4,lit?R104,V2,R103,R105,R106,v22,arbace.repr.go.convert10,add-parensv22,arbace.repr.go.convert7,reparenR107,v22,arbace.repr.go.convert4,linev11,arbace.core3,vecv11,arbace.core6,empty?R108,R109,R110,R111,v11,arbace.core3,mapv22,arbace.repr.go.convert7,relinedv11,arbace.core6,dissocv11,arbace.core4,mapvv11,arbace.core7,symbol?R112,v22,arbace.repr.go.convert2,anR113,v20,arbace.repr.go.types9,type-formR114,R115,v22,arbace.repr.go.convert3,objR116,v22,arbace.repr.go.convert5,targsv22,arbace.repr.go.convert10,ident-namev22,arbace.repr.go.convert7,line-ofv22,arbace.repr.go.convert2,atv11,arbace.core6,symbolS3,s5,falses4,trues3,nilv22,arbace.repr.go.convert4,openv22,arbace.repr.go.convert4,formR117,v18,arbace.repr.go.lit3,litv18,arbace.repr.go.lit11,string-textR118,S3,s5,falses4,trues3,nilR119,R120,R121,R122,v22,arbace.repr.go.convert6,lit-atm6,s4,trueTs5,falseFs3,nilnR117,v22,arbace.repr.go.convert8,add-metav22,arbace.repr.go.convert9,inst-metav22,arbace.repr.go.convert11,count-node!v22,arbace.repr.go.convert5,note!R123,v22,arbace.repr.go.convert5,identv11,arbace.core7,keywordR124,v22,arbace.repr.go.convert7,unparenv11,arbace.core4,not=v22,arbace.repr.go.convert4,exprv22,arbace.repr.go.convert9,full-metaR125,R126,v25,arbace.repr.go.print-text9,go-stringv11,arbace.core5,char?v25,arbace.repr.go.print-text7,go-runev11,arbace.core7,number?v25,arbace.repr.go.print-text9,go-numberv11,arbace.core3,strv25,arbace.repr.go.print-text14,go-byte-stringv11,arbace.core4,restv11,arbace.core8,to-arrayv22,arbace.repr.go.convert7,spelledv18,arbace.repr.go.lit10,bytes-formv18,arbace.repr.go.lit12,string-bytesR127,v18,arbace.repr.go.lit10,imag-innerv18,arbace.repr.go.lit14,float-text-litv18,arbace.repr.go.lit9,rune-formv18,arbace.repr.go.lit10,rune-valuev18,arbace.repr.go.lit7,int-litv22,arbace.repr.go.convert12,lit-spellingR128,R129,R130,v22,arbace.repr.go.convert9,*generic*v11,arbace.core4,consR131,v11,arbace.core11,map-indexedv11,arbace.core9,contains?R132,v22,arbace.repr.go.convert11,*kept-docs*R133,v22,arbace.repr.go.convert14,mark-ungroupedv11,arbace.core6,mapcatR10,R134,v22,arbace.repr.go.convert9,type-formR135,R136,v22,arbace.repr.go.convert12,string-valuev22,arbace.repr.go.convert6,doc-ofv22,arbace.repr.go.convert8,*groups*R137,R138,v11,arbace.core6,concatV1,R139,v22,arbace.repr.go.convert11,group-marksv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv22,arbace.repr.go.convert6,taggedv11,arbace.core10,chunk-consv11,arbace.core5,chunkv22,arbace.repr.go.convert9,signatureR134,R140,R141,v22,arbace.repr.go.convert8,with-posR142,v22,arbace.repr.go.convert13,recv-chan-posR143,R144,R142,R145,R142,R146,v22,arbace.repr.go.convert15,interface-elemsR147,R148,R149,R150,v11,arbace.core9,namespacev20,arbace.repr.go.types19,reserved-type-headsR151,R152,v22,arbace.repr.go.convert6,fieldsR153,m2,R133,TR154,R134,R155,R156,R155,R157,R158,R159,v22,arbace.repr.go.convert10,pkg-ident?R160,R161,R162,R163,R164,R165,R166,v11,arbace.core11,select-keysV2,R46,R148,R167,v22,arbace.repr.go.convert6,vec-atR167,V2,R46,R148,R168,R169,V2,R46,R148,v22,arbace.repr.go.convert12,type-params*V2,R46,R148,R170,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv22,arbace.repr.go.convert14,untyped-const?R171,S3,s4,imags4,reals7,complexv11,arbace.core6,every?R172,R173,v20,arbace.repr.go.types8,untyped?S2,s2,>>s2,<<S1,R151,R151,R174,R175,v20,arbace.repr.go.types9,name-formR176,R177,v22,arbace.repr.go.convert7,as-instS2,R178,R40,v22,arbace.repr.go.convert13,selection-viaR179,S3,s5,falses4,trues3,nilR117,R180,v11,arbace.core3,popv22,arbace.repr.go.convert6,spreadv11,arbace.core4,peekv22,arbace.repr.go.convert18,raw-reserved-headsR181,v22,arbace.repr.go.convert9,call-argsR182,R183,v22,arbace.repr.go.convert12,builtin-nameR184,R178,R185,v22,arbace.repr.go.convert14,reserved-headsR181,R186,R177,R151,R187,R188,R2,R189,v22,arbace.repr.go.convert12,fn-sig-formsv11,arbace.core4,atomv11,arbace.core5,doallv22,arbace.repr.go.convert9,stmt-listR190,R191,R192,v22,arbace.repr.go.convert9,block-posv22,arbace.repr.go.convert12,*return-pos*S2,s3,INTs5,FLOATv22,arbace.repr.go.convert9,basic-litv22,arbace.repr.go.convert9,unary-opsv22,arbace.repr.go.convert9,compositeR193,R194,R195,R196,S6,R19,R75,R38,R87,R41,R57,R197,v22,arbace.repr.go.convert8,raw-callv22,arbace.repr.go.convert4,callv22,arbace.repr.go.convert10,raw-selectv22,arbace.repr.go.convert13,selector-formv22,arbace.repr.go.convert10,binary-opsv22,arbace.repr.go.convert8,nary-opsS2,R198,R199,m2,R200,TR201,v11,arbace.core4,rseqS2,R202,R203,R204,S2,R202,R203,R205,R206,R207,R208,R209,v22,arbace.repr.go.convert13,instantiationR210,v22,arbace.repr.go.convert8,func-litR211,R212,R213,R214,R214,v22,arbace.repr.go.convert8,raw-nameR215,R216,R217,R215,R218,R219,v22,arbace.repr.go.convert7,targetsv22,arbace.repr.go.convert13,define-targetv22,arbace.repr.go.convert5,initsR220,v18,arbace.repr.go.lit10,const-formv20,arbace.repr.go.types10,const-kindR221,R222,R223,R224,R225,v22,arbace.repr.go.convert9,const-valV3,R66,R90,R106,R226,R227,R228,R229,R230,R231,R232,v22,arbace.repr.go.convert11,type-paramsV3,R66,R90,R106,R233,R234,v22,arbace.repr.go.convert13,generic-decl?v22,arbace.repr.go.convert10,decl-stmt?R235,v22,arbace.repr.go.convert11,bindings-ofv22,arbace.repr.go.convert13,decl-bindingsv22,arbace.repr.go.convert14,define-bindingR236,v22,arbace.repr.go.convert8,*placed*R237,v22,arbace.repr.go.convert9,*fn-dirs*v11,arbace.core6,repeatv22,arbace.repr.go.convert7,max-posv11,arbace.core4,somev11,arbace.core6,removev11,arbace.core6,reducev11,arbace.core12,keep-indexedv22,arbace.repr.go.convert14,gap-directivesv22,arbace.repr.go.convert8,dir-formR238,v22,arbace.repr.go.convert8,label-kwR239,R240,R241,R242,R243,v11,arbace.core8,identityv22,arbace.repr.go.convert4,stmtv22,arbace.repr.go.convert11,stmts-formsR244,R244,S3,R245,R246,R247,R244,v22,arbace.repr.go.convert11,simple-stmtR248,R249,R245,v22,arbace.repr.go.convert8,init-vecR247,v22,arbace.repr.go.convert6,branchR250,R246,v22,arbace.repr.go.convert7,if-formR251,R252,R253,R254,v22,arbace.repr.go.convert12,type-syntax?v22,arbace.repr.go.convert11,case-clausev22,arbace.repr.go.convert12,clause-boundR255,R253,R254,v11,arbace.core1,=R256,R257,R258,R258,v22,arbace.repr.go.convert10,assign-opsR258,R259,R260,v22,arbace.repr.go.convert5,stmt*S5,R86,R68,R92,R80,R89,R261,R262,R262,R263,v22,arbace.repr.go.convert11,comm-clauseR264,v11,arbace.core6,reset!R265,R266,R266,R267,m8,s5,breakR268,s8,continueR269,s4,gotoR270,s11,fallthroughR271,v22,arbace.repr.go.convert6,assignR272,R273,R274,R275,v22,arbace.repr.go.convert7,clausesR276,R277,R278,R279,R280,m2,R218,TR281,R282,R283,v22,arbace.repr.go.convert11,block-formsv13,arbace.string12,starts-with?l5,v13,arbace.string8,index-ofv13,arbace.string5,trimlv22,arbace.repr.go.convert14,directive-namev22,arbace.repr.go.convert19,free-standing-namesv13,arbace.string5,splitv22,arbace.repr.go.convert14,directive-argsp3,\\s+R236,R284,S2,R78,R48,m2,R285,TR286,R287,R288,R289,R214,m2,R233,Tv22,arbace.repr.go.convert17,value-spec-targetR290,V3,R66,R90,R106,R291,R292,S2,s1,_s1,.V3,R66,R90,R106,S2,s1,_s1,.v11,arbace.core6,vectorV1,l0,v11,arbace.core4,sortl10,v22,arbace.repr.go.convert11,whitespace?v11,arbace.core9,transientR293,R294,v11,arbace.core11,persistent!R295,R296,c9,c32,v11,arbace.core5,conj!R297,v11,arbace.core8,tree-seqv11,arbace.core5,coll?R298,R299,R300,R301,v22,arbace.repr.go.convert15,file-directivesv11,arbace.core4,lastv22,arbace.repr.go.convert11,attachable?v22,arbace.repr.go.convert9,decl-nameR302,R303,R304,R305,v11,arbace.core6,get-inv22,arbace.repr.go.convert14,directive-metaR306,v11,arbace.core7,sort-byv22,arbace.repr.go.convert10,imports-ofv22,arbace.repr.go.convert14,free-directivev11,arbace.core4,takel2,R307,R308,R309,R310,R311,v22,arbace.repr.go.convert10,*text-dir*v22,arbace.repr.go.convert11,source-textv22,arbace.repr.go.convert17,basic-lit-extentsR312,R313,R314,R315,R316,v22,arbace.repr.go.convert8,gen-declv22,arbace.repr.go.convert9,func-declv11,arbace.core5,rangev13,arbace.string11,split-linesv13,arbace.string7,replaceR317,R318,R319,R320,R321,R322,p16,(.*):(\\d+):(\\d+)R214,R323,p4,[.-]R324,R325,R326,V9,R327,R328,R329,R330,R331,R332,R333,R334,R335,R336,R337,R338,v22,arbace.repr.go.convert10,munge-namep1,/v11,arbace.core9,array-mapR339,R340,R341,R342,R343,R344,R345,R346,R347,R348,R349,R350,R351,R352,v22,arbace.repr.go.convert10,init-orderR353,R354,v20,arbace.repr.go.types10,ns-name-ofR355,R356,v22,arbace.repr.go.convert12,convert-fileR357,v22,arbace.repr.go.convert9,file-stemR358,v20,arbace.repr.go.types9,*imports*S2,s1,_s1,.S2,s1,_s1,.S2,s1,_s1,.S2,s1,_s1,.v22,arbace.repr.go.convert12,package-formR359,v22,arbace.repr.go.convert6,*dump*R360,R361,R362,v20,arbace.repr.go.types7,*table*R363,v20,arbace.repr.go.types5,*pkg*v20,arbace.repr.go.types12,*namespaces*R364,v20,arbace.repr.go.types12,*underlying*")

var Lit_1 *jrt.String = jrt.Intern("arbace.repr.go.convert$add_parens$fn__1114000073")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.go.convert$add_parens$fn__1114000075")

var Lit_3 *jrt.String = jrt.Intern("=")

var Lit_4 *jrt.String = jrt.Intern(":=")

var Lit_5 *jrt.String = jrt.Intern("assignment ")

var Lit_6 *jrt.String = jrt.Intern("arbace.repr.go.convert$at$fn__1114000052")

var Lit_7 *jrt.String = jrt.Intern("arbace.repr.go.convert$at$fn__1114000052$fn__1114000054")

var Lit_8 *jrt.String = jrt.Intern("cgo_")

var Lit_9 *jrt.String = jrt.Intern("linkname")

var Lit_10 *jrt.String = jrt.Intern("")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit$lit_form__1114000107")

var Lit_12 *jrt.String = jrt.Intern("STRING")

var Lit_13 *jrt.String = jrt.Intern("IMAG")

var Lit_14 *jrt.String = jrt.Intern("FLOAT")

var Lit_15 *jrt.String = jrt.Intern("CHAR")

var Lit_16 *jrt.String = jrt.Intern("INT")

var Lit_17 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents$iter__1114000698__1114000702")

var Lit_19 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents$fn__1114000712")

var Lit_20 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents$iter__1114000698__1114000702$fn__1114000703")

var Lit_21 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents$iter__1114000698__1114000702$fn__1114000703$fn__1114000704")

var Lit_22 *jrt.String = jrt.Intern("builtin")

var Lit_23 *jrt.String = jrt.Intern("conversion arity")

var Lit_24 *jrt.String = jrt.Intern("arbace.repr.go.convert$call$fn__1114000209")

var Lit_25 *jrt.String = jrt.Intern(".")

var Lit_26 *jrt.String = jrt.Intern("arbace.repr.go.convert$case_clause$fn__1114000404")

var Lit_27 *jrt.String = jrt.Intern("arbace.repr.go.convert$clauses$fn__1114000407")

var Lit_28 *jrt.String = jrt.Intern("select case")

var Lit_29 *jrt.String = jrt.Intern("_")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.go.convert$composite$fn__1114000220")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.go.convert$composite$fn__1114000222")

var Lit_32 *jrt.String = jrt.Intern("struct literal key")

var Lit_33 *jrt.String = jrt.Intern(":")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000720__1114000724")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000730")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000733")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000739")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000744")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$inside_of__1114000747")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000759")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$attach_meta__1114000772")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000782")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000784")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000786")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000796__1114000802")

var Lit_46 *jrt.String = jrt.Intern("\n")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000826")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000831")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000843")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000848")

var Lit_51 *jrt.String = jrt.Intern("(in-ns '")

var Lit_52 *jrt.String = jrt.Intern(")")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$attach_meta__1114000772$fn__1114000774")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$attach_meta__1114000772$fn__1114000779")

var Lit_55 *jrt.String = jrt.Intern("import")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000759$fn__1114000763")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000759$fn__1114000766")

var Lit_58 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000786$fn__1114000787")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000786$fn__1114000789")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000786$fn__1114000791")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000786$fn__1114000793")

var Lit_62 *jrt.String = jrt.Intern("//go:build")

var Lit_63 *jrt.String = jrt.Intern("// +build")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000831$fn__1114000832")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000831$fn__1114000839")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000831$fn__1114000832$fn__1114000833")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000831$fn__1114000832$fn__1114000836")

var Lit_68 *jrt.String = jrt.Intern("declaration")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000848$fn__1114000850")

var Lit_70 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000848$fn__1114000850$fn__1114000858")

var Lit_71 *jrt.String = jrt.Intern("\r")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000848$fn__1114000850$fn__1114000864")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$inside_of__1114000747$fn__1114000752")

var Lit_74 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000720__1114000724$fn__1114000725")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000720__1114000724$fn__1114000725$fn__1114000726")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000796__1114000802$fn__1114000803")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000796__1114000802$fn__1114000803$iter__1114000798__1114000804")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000796__1114000802$fn__1114000803$iter__1114000798__1114000804$fn__1114000805")

var Lit_79 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000796__1114000802$fn__1114000803$iter__1114000798__1114000804$fn__1114000805$fn__1114000806")

var Lit_80 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000927__1114000931")

var Lit_81 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941")

var Lit_82 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000927__1114000931$fn__1114000932")

var Lit_83 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000927__1114000931$fn__1114000932$fn__1114000933")

var Lit_84 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942")

var Lit_85 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$fn__1114000943")

var Lit_86 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$iter__1114000963__1114000969")

var Lit_87 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$fn__1114000979")

var Lit_88 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$fn__1114000943$iter__1114000944__1114000950")

var Lit_89 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$fn__1114000943$fn__1114000960")

var Lit_90 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$fn__1114000943$iter__1114000944__1114000950$fn__1114000951")

var Lit_91 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$fn__1114000943$iter__1114000944__1114000950$fn__1114000951$iter__1114000946__1114000952")

var Lit_92 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$fn__1114000943$iter__1114000944__1114000950$fn__1114000951$iter__1114000946__1114000952$fn__1114000953")

var Lit_93 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$fn__1114000943$iter__1114000944__1114000950$fn__1114000951$iter__1114000946__1114000952$fn__1114000953$fn__1114000954")

var Lit_94 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$iter__1114000963__1114000969$fn__1114000970")

var Lit_95 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$iter__1114000963__1114000969$fn__1114000970$iter__1114000965__1114000971")

var Lit_96 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$iter__1114000963__1114000969$fn__1114000970$iter__1114000965__1114000971$fn__1114000972")

var Lit_97 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000937__1114000941$fn__1114000942$iter__1114000963__1114000969$fn__1114000970$iter__1114000965__1114000971$fn__1114000972$fn__1114000973")

var Lit_98 *jrt.String = jrt.Intern("const")

var Lit_99 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000264")

var Lit_100 *jrt.String = jrt.Intern("var")

var Lit_101 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000279")

var Lit_102 *jrt.String = jrt.Intern("type")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000285")

var Lit_104 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000264$fn__1114000270")

var Lit_105 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000264$mk__1114000272")

var Lit_106 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000264$fn__1114000276")

var Lit_107 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000279$mk__1114000282")

var Lit_108 *jrt.String = jrt.Intern("var without type")

var Lit_109 *jrt.String = jrt.Intern(" ")

var Lit_110 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_meta$fn__1114000438")

var Lit_111 *jrt.String = jrt.Intern("go")

var Lit_112 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_meta$fn__1114000438$fn__1114000439")

var Lit_113 *jrt.String = jrt.Intern("//go:")

var Lit_114 *jrt.String = jrt.Intern("ellipsis outside a parameter list")

var Lit_115 *jrt.String = jrt.Intern("-")

var Lit_116 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$fn__1114000235")

var Lit_117 *jrt.String = jrt.Intern("~")

var Lit_118 *jrt.String = jrt.Intern("unary operator")

var Lit_119 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$fn__1114000239")

var Lit_120 *jrt.String = jrt.Intern("binary operator")

var Lit_121 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$operand__1114000244")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$fn__1114000246")

var Lit_123 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$fn__1114000249")

var Lit_124 *jrt.String = jrt.Intern("x.(type) outside a type switch")

var Lit_125 *jrt.String = jrt.Intern("key-value outside a literal")

var Lit_126 *jrt.String = jrt.Intern("expression")

var Lit_127 *jrt.String = jrt.Intern(": ")

var Lit_128 *jrt.String = jrt.Intern(" at ")

var Lit_129 *jrt.String = jrt.Intern("arbace.repr.go.convert$fail$fn__1114000016")

var Lit_130 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields$fn__1114000124")

var Lit_131 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields$fn__1114000124$iter__1114000128__1114000132")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields$fn__1114000124$iter__1114000128__1114000132$fn__1114000133")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields$fn__1114000124$iter__1114000128__1114000132$fn__1114000133$fn__1114000134")

var Lit_134 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_directives$iter__1114000484__1114000488")

var Lit_135 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_directives$iter__1114000484__1114000488$fn__1114000489")

var Lit_136 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_directives$iter__1114000484__1114000488$fn__1114000489$fn__1114000490")

var Lit_137 *jrt.String = jrt.Intern("//line ")

var Lit_138 *jrt.String = jrt.Intern("/")

var Lit_139 *jrt.String = jrt.Intern("arbace.repr.go.convert$func_decl$fn__1114000457")

var Lit_140 *jrt.String = jrt.Intern("arbace.repr.go.convert$func_lit$fn__1114000229")

var Lit_141 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000301")

var Lit_142 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000306")

var Lit_143 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$inside_QMARK___1114000308")

var Lit_144 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000317")

var Lit_145 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000323")

var Lit_146 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000323$fn__1114000328")

var Lit_147 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$inside_QMARK___1114000308$fn__1114000310")

var Lit_148 *jrt.String = jrt.Intern("arbace.repr.go.convert$gen_decl$spec__1114000468")

var Lit_149 *jrt.String = jrt.Intern("arbace.repr.go.convert$gen_decl$fn__1114000472")

var Lit_150 *jrt.String = jrt.Intern("arbace.repr.go.convert$gen_decl$spec_vec__1114000477")

var Lit_151 *jrt.String = jrt.Intern("arbace.repr.go.convert$group_marks$fn__1114000114")

var Lit_152 *jrt.String = jrt.Intern("arbace.repr.go.convert$if_form$fn__1114000374")

var Lit_153 *jrt.String = jrt.Intern("arbace.repr.go.convert$if_form$fn__1114000387")

var Lit_154 *jrt.String = jrt.Intern(":else")

var Lit_155 *jrt.String = jrt.Intern("arbace.repr.go.convert$if_form$fn__1114000393")

var Lit_156 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519")

var Lit_157 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519$fn__1114000520")

var Lit_158 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519$fn__1114000520$iter__1114000515__1114000521")

var Lit_159 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519$fn__1114000520$iter__1114000515__1114000521$fn__1114000522")

var Lit_160 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519$fn__1114000520$iter__1114000515__1114000521$fn__1114000522$fn__1114000523")

var Lit_161 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519$fn__1114000520$iter__1114000515__1114000521$fn__1114000522$nm__1114000541")

var Lit_162 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519$fn__1114000520$iter__1114000515__1114000521$fn__1114000522$decl_pos__1114000543")

var Lit_163 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519$fn__1114000520$iter__1114000515__1114000521$fn__1114000522$fn__1114000523$nm__1114000530")

var Lit_164 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000513__1114000519$fn__1114000520$iter__1114000515__1114000521$fn__1114000522$fn__1114000523$decl_pos__1114000532")

var Lit_165 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000885__1114000889")

var Lit_166 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000885__1114000889$fn__1114000890")

var Lit_167 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000885__1114000889$fn__1114000890$fn__1114000891")

var Lit_168 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000885__1114000889$fn__1114000890$one__1114000907")

var Lit_169 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000885__1114000889$fn__1114000890$fn__1114000891$one__1114000895")

var Lit_170 *jrt.String = jrt.Intern("arbace.repr.go.convert$instantiation$fn__1114000214")

var Lit_171 *jrt.String = jrt.Intern(".-")

var Lit_172 *jrt.String = jrt.Intern("arbace.repr.go.convert$interface_elems$iter__1114000140__1114000144")

var Lit_173 *jrt.String = jrt.Intern("arbace.repr.go.convert$interface_elems$iter__1114000140__1114000144$fn__1114000145")

var Lit_174 *jrt.String = jrt.Intern("arbace.repr.go.convert$interface_elems$iter__1114000140__1114000144$fn__1114000145$fn__1114000146")

var Lit_175 *jrt.String = jrt.Intern("imaginary")

var Lit_176 *jrt.String = jrt.Intern("i")

var Lit_177 *jrt.String = jrt.Intern("rune")

var Lit_178 *jrt.String = jrt.Intern("byte-string")

var Lit_179 *jrt.String = jrt.Intern("arbace.repr.go.convert$mark_ungrouped$fn__1114000117")

var Lit_180 *jrt.String = jrt.Intern("arbace.repr.go.convert$max_pos$walk__1114000042")

var Lit_181 *jrt.String = jrt.Intern("arbace.repr.go.convert$open_counts$walk__1114000872")

var Lit_182 *jrt.String = jrt.Intern("arbace.repr.go.convert")

var Lit_183 *jrt.String = jrt.Intern("arbace.repr.go.convert$package_form$fn__1114000923")

var Lit_184 *jrt.String = jrt.Intern("amd64")

var Lit_185 *jrt.String = jrt.Intern("arbace.repr.go.convert$positions$fn__1114000036")

var Lit_186 *jrt.String = jrt.Intern("arbace.repr.go.convert$recv_chan_pos$fn__1114000028")

var Lit_187 *jrt.String = jrt.Intern("chan")

var Lit_188 *jrt.String = jrt.Intern("arbace.repr.go.convert$relined$fn__1114000087")

var Lit_189 *jrt.String = jrt.Intern("arbace.repr.go.convert$relined$fn__1114000089")

var Lit_190 *jrt.String = jrt.Intern("arbace.repr.go.convert$relined$fn__1114000091")

var Lit_191 *jrt.String = jrt.Intern("selector-form in raw mode")

var Lit_192 *jrt.String = jrt.Intern("selector")

var Lit_193 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000553")

var Lit_194 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$off__1114000556")

var Lit_195 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$text__1114000561")

var Lit_196 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569")

var Lit_197 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000599__1114000603")

var Lit_198 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000615__1114000619")

var Lit_199 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000631")

var Lit_200 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000653")

var Lit_201 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000655")

var Lit_202 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000657")

var Lit_203 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000659")

var Lit_204 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000661__1114000665")

var Lit_205 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000677__1114000681")

var Lit_206 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569$fn__1114000570")

var Lit_207 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569$fn__1114000570$iter__1114000565__1114000571")

var Lit_208 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569$fn__1114000570$iter__1114000565__1114000571$fn__1114000572")

var Lit_209 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569$fn__1114000570$iter__1114000565__1114000571$fn__1114000572$fn__1114000573")

var Lit_210 *jrt.String = jrt.Intern("//")

var Lit_211 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569$fn__1114000570$iter__1114000565__1114000571$fn__1114000572$fn__1114000591")

var Lit_212 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569$fn__1114000570$iter__1114000565__1114000571$fn__1114000572$fn__1114000593")

var Lit_213 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569$fn__1114000570$iter__1114000565__1114000571$fn__1114000572$fn__1114000573$fn__1114000580")

var Lit_214 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000563__1114000569$fn__1114000570$iter__1114000565__1114000571$fn__1114000572$fn__1114000573$fn__1114000582")

var Lit_215 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000599__1114000603$fn__1114000604")

var Lit_216 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000599__1114000603$fn__1114000604$fn__1114000605")

var Lit_217 *jrt.String = jrt.Intern("UTF-8")

var Lit_218 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000615__1114000619$fn__1114000620")

var Lit_219 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000615__1114000619$fn__1114000620$fn__1114000621")

var Lit_220 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000661__1114000665$fn__1114000666")

var Lit_221 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000661__1114000665$fn__1114000666$fn__1114000667")

var Lit_222 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000677__1114000681$fn__1114000682")

var Lit_223 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000677__1114000681$fn__1114000682$fn__1114000683")

var Lit_224 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000677__1114000681$fn__1114000682$fn__1114000693")

var Lit_225 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000677__1114000681$fn__1114000682$fn__1114000683$fn__1114000687")

var Lit_226 *jrt.String = jrt.Intern("no start for")

var Lit_227 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt_STAR_$fn__1114000420")

var Lit_228 *jrt.String = jrt.Intern("true")

var Lit_229 *jrt.String = jrt.Intern("++")

var Lit_230 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt_STAR_$tgt__1114000430")

var Lit_231 *jrt.String = jrt.Intern("declaration outside a statement list")

var Lit_232 *jrt.String = jrt.Intern("statement")

var Lit_233 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$fn__1114000340")

var Lit_234 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$fn__1114000346")

var Lit_235 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$build__1114000348")

var Lit_236 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$build__1114000348$kind_of__1114000355")

var Lit_237 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$build__1114000348$fn__1114000357")

var Lit_238 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$build__1114000348$fn__1114000359")

var Lit_239 *jrt.String = jrt.Intern("unary type")

var Lit_240 *jrt.String = jrt.Intern("type selector")

var Lit_241 *jrt.String = jrt.Intern("|")

var Lit_242 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_form$fn__1114000166")

var Lit_243 *jrt.String = jrt.Intern("binary type")

var Lit_244 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_form$fl_pos__1114000169")

var Lit_245 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_$fn__1114000174")

var Lit_246 *jrt.String = jrt.Intern("any")

var Lit_247 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_$fn__1114000174$iter__1114000177__1114000181")

var Lit_248 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_$fn__1114000174$iter__1114000177__1114000181$fn__1114000182")

var Lit_249 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_$fn__1114000174$iter__1114000177__1114000181$fn__1114000182$fn__1114000183")

var Lit_250 *jrt.String = jrt.Intern("arbace.repr.go.convert$value_spec_target$mk__1114000462")

var Lit_251 *jrt.String = jrt.Intern("arbace.repr.go.convert$with_pos$fn__1114000062")

var Lit_252 *jrt.String = jrt.Intern("arbace.repr.go.convert$with_pos$fn__1114000067")

var Lit_253 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn1,kyn1,nyn3,msgkn3,tagyn6,Stringyn1,syn5,arrowyn1,lyn1,&yn2,xsyn1,xyn1,myn1,pyn1,byn22,arbace.repr.go.lit.Lityn3,posyn4,instyn8,explicitkn8,declaredkn7,privateyn3,rawyn7,printedyn3,symyn1,tyn4,symsyn5,elemsyn10,names-onlyyn7,pos-stryn6,groupsyn10,field-listkn4,keysyn7,struct?yn2,ftyn2,>>yn3,andyn2,!=yn1,*yn1,%yn2,<=yn6,bit-oryn1,/yn1,-yn2,>=yn7,bit-andyn1,<yn2,<<yn11,bit-and-notyn2,oryn2,==yn7,bit-xoryn1,+yn1,>yn7,bit-notyn3,notyn4,addryn2,<!yn1,ayn4,argsyn8,ellipsisyn3,funyn3,lhsyn2,mkyn3,rhsyn2,stv11,arbace.core5,in-nsMyn22,arbace.repr.go.convertm2,R0,s878,repr/go's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.repr.go.lit/Lit (text and value). arbace.repr.go.layout writes them as text.\n\n  Raw mode (*raw*, doc/go/GO-PARSER-SURVEY.md GP3, doc/go/CONVERTER-NOTES.md \"Raw forms\"): the\n  forms of an un-annotated tree, every decision that needs types left open and marked (::open\n  in memory, a head or a public key in the text); no annotation is read.m2,R0,s878,repr/go's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.repr.go.lit/Lit (text and value). arbace.repr.go.layout writes them as text.\n\n  Raw mode (*raw*, doc/go/GO-PARSER-SURVEY.md GP3, doc/go/CONVERTER-NOTES.md \"Raw forms\"): the\n  forms of an un-annotated tree, every decision that needs types left open and marked (::open\n  in memory, a head or a public key in the text); no annotation is read.R1,v22,arbace.repr.go.convert6,*dump*m8,R2,TR3,i21,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,*stats*m8,R2,TR3,i22,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,*generic*m8,R2,TR3,i23,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,*kept-docs*m8,R2,TR3,i24,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,*fn-dirs*m8,R2,TR3,i25,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,*placed*m8,R2,TR3,i26,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,*full*m8,R2,TR3,i27,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,*return-pos*m8,R2,TR3,i28,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,*text-dir*m8,R2,TR3,i29,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,*src*m8,R2,TR3,i30,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,*raw*m8,R2,TR3,i31,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,note!m8,R6,L1,V1,R7,R3,i33,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,count-node!m8,R6,L1,V1,R8,R3,i34,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,failm8,R6,L1,V2,R9,R8,R3,i36,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert2,ntm8,R6,L1,V1,R8,R3,i44,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert2,nfm8,R6,L1,V1,R8,R3,i45,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert2,anm10,R6,L1,V1,R8,R0,s71,A node's annotations (go/types', as reader metadata); none in raw mode.R3,i46,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,unparenm8,R6,L1,V1,R8,R3,i51,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,parse-posm8,R6,L1,V1,Myn1,sm2,R10,R11,R3,i53,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,pos-linem8,R6,L1,V1,R12,R3,i58,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,recv-chan-posm10,R6,L1,V1,R13,R0,s310,Mode :full: the position \"L:C\" of the keyword chan of a receive-only channel type whose\n  arrow is at arrow, when white space separates them (`<- chan T`): go/ast keeps the arrow's\n  position only, and the printer writes chan right after it otherwise. nil when they are\n  adjacent or the source is not at hand.R3,i60,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,startm10,R6,L1,V1,R8,R0,s54,The position string of a node's start, go/ast's Pos().R3,i84,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,line-ofm8,R6,L1,V1,R8,R3,i133,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,positionsm10,R6,L1,V1,R8,R0,s51,The position fields of a node: {:field [line col]}.R3,i135,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,max-posm10,R6,L1,V1,R8,R0,s53,The greatest position [line col] in a node's subtree.R3,i142,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,formm10,R6,L1,V4,R8,R14,R15,R16,R0,s88,A list form beginning on line l, built from node n (whose positions it keeps for :full).R3,i158,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert2,atm10,R6,L1,V3,R17,R8,R14,R0,s64,x (a symbol, list or vector) with line l and node n's positions.R3,i163,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,linem8,R6,L1,V1,R17,R3,i171,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,openm10,R6,L1,V2,R17,R7,R0,s168,Raw mode: x (a form or symbol) marked as the open decision of kind k (private ::open, which\n  open-counts counts and arbace.repr.go.raw checks against the final forms).R3,i173,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,with-posm10,R6,L1,V2,R17,R18,R0,s89,x with more positions for mode :full: m maps keys to position strings (nil ones skipped).R3,i179,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,full-metam10,R6,L1,V2,R17,R18,R0,s86,x with the public metadata m that only mode :full writes (layout writes ::full there).R3,i187,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,add-parensm10,R6,L1,V2,R17,R19,R0,s153,x (a form or a Lit) inside the parentheses of the ParenExpr node p (mode :full): the pair\n  [lparen rparen] before those x already has (outermost first).R3,i194,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,reparenm10,R6,L1,V2,R17,R8,R0,s63,x, built from (unparen n), inside n's parentheses (mode :full).R3,i206,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,block-posm8,R6,L1,V1,R20,R3,i213,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,with-linem8,R6,L1,V2,R14,R17,R3,i215,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,vec-atm8,R6,L1,V2,R14,R16,R3,i218,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,add-metam10,R6,L1,V2,R17,R18,R0,s39,x with the public metadata m merged in.R3,i220,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,lit-atm10,R6,L1,V3,R14,Myn1,xm2,R10,R21,R22,R0,s57,A Lit placed on line l (layout records it in its parent).R3,i225,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,relinedm10,R6,L1,V2,R14,R17,R0,s82,x with every form inside on line l and no positions (an implicitly repeated init).R3,i230,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,builtin-headsv11,arbace.core4,intov11,arbace.core3,mapv11,arbace.core6,symbolV18,s6,appends3,caps5,clears5,closes7,complexs4,copys6,deletes4,imags3,lens4,makes3,maxs3,mins3,news5,panics5,prints7,printlns4,reals7,recoverm8,R3,i243,R4,i1,R5,s25,arbace/repr/go/convert.aeR0,s58,The heads of builtin calls (§7.4): Go's builtin functions.v22,arbace.repr.go.convert14,reserved-headsv11,arbace.core6,concatV27,s3,lets8,let-types4,set!s4,asets4,inc!s4,dec!s2,>!s2,gos5,defers6,returns5,breaks8,continues4,gotos11,fallthroughs5,labels2,dos2,ifs4,whens4,conds6,switchs11,type-switchs6,selects4,cases7,defaults3,fors5,whiles5,rangeV38,s1,+s1,-s1,*s1,/s1,%s2,<<s2,>>s2,==s2,!=s1,<s2,<=s1,>s2,>=s3,ands2,ors3,nots7,bit-ands6,bit-ors7,bit-xors7,bit-nots11,bit-and-nots4,addrs2,<!s3,lits4,convs6,asserts4,agets8,subslices6,spreads6,valuess4,insts11,method-exprs2,fns4,zeros4,runes9,imaginarys11,byte-strings5,derefV9,s5,slices5,arrays3,maps4,chans4,funcs6,structs9,interfaces1,|s5,tildem8,R3,i250,R4,i1,R5,s25,arbace/repr/go/convert.aeR0,s83,Unqualified heads of Go context (§13.5): a call of a Go name among them is go/call.v22,arbace.repr.go.convert18,raw-reserved-headsv11,arbace.core6,reducev11,arbace.core4,disjm8,R3,i264,R4,i1,R5,s25,arbace/repr/go/convert.aeR0,s212,Raw mode: the reserved heads but the builtins' names. A raw call is never classified, so\n  (len x) is a call of the identifier len; only a Go name that is a head of the forms' syntax\n  is written (go/call h ...).v22,arbace.repr.go.convert10,ident-namem8,R6,L1,V1,R8,R3,i270,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert3,objm8,R6,L1,V1,R8,R3,i272,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,targsm10,R6,L1,V1,R23,R0,s63,The type forms of the type arguments of an instance annotation.R3,i274,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,inst-metam10,R6,L1,V2,R8,R24,R0,s132,{:inst [...]} for the use of a generic function or method whose type arguments are not\n  all in the source (explicit: how many are).R3,i279,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,identm10,R6,L2,V1,R8,V2,R8,R24,R0,s86,An identifier as a symbol, a literal (the universe's true, false, nil) or (go/id \"x\").R3,i288,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,label-kwm8,R6,L1,V1,R8,R3,i307,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,pkg-ident?m8,R6,L1,V1,R8,R3,i309,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,exprm8,R25,TR3,i311,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,raw-namem10,R6,L1,V1,R8,R0,s177,Raw mode: a name the syntax requires (a := target, a type switch's variable) as ident, any\n  other expression an invalid program puts there as its form (the checker reports it).R3,i313,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,spelledm12,R26,TR6,L1,V3,R17,R27,R28,R0,s183,x (a Lit or a literal list) with the source's spelling raw of a basic literal when the\n  printer would spell it otherwise (printed, a function of x giving its spelling; mode\n  :full).R3,i321,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,lit-spellingm12,R26,TR6,L1,V1,R17,R0,s84,The printer's spelling of a literal of the forms (a Lit's value, or a literal list).R3,i334,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,basic-litm8,R6,L1,V1,R8,R3,i349,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,string-valuem10,R6,L1,V1,R8,R0,s74,The Go string value of a STRING basic literal (import paths, struct tags).R3,i374,R4,i1,R5,s25,arbace/repr/go/convert.aem8,R25,TR3,i381,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,type-formm8,R25,TR3,i381,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,signaturem8,R25,TR3,i381,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,field-list-vecm8,R25,TR3,i381,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,taggedm10,R6,L1,V2,R29,R30,R0,s44,The symbol sym with the type form t as :tag.R3,i383,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,group-marksm12,R26,TR6,L1,V1,R31,R0,s143,Names of one field after the first get :go/group inside generic declarations (proposed\n  amendment: gc's output depends on field groups there).R3,i388,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,mark-ungroupedm10,R6,L1,V2,R32,R33,R0,s172,Inside generic declarations, a name declared apart from the name before it although of an\n  equal type gets :go/grouped false, so that the printer does not group them (A1).R3,i396,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,doc-ofm10,R6,L1,V2,R34,R35,R0,s84,The kept doc text of a comment group position, recording it as kept; nil when empty.R3,i412,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,*groups*m8,R2,TR3,i421,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,fieldsm10,R6,L1,V2,R36,m2,R37,V1,R38,R0,s246,The elements of a struct type's fields, or of a parameter/result vector: a tagged name per\n  name, a type form for an unnamed field (embedded or unnamed parameter). opts: :struct (tags,\n  docs), :variadic (an Ellipsis type is the last parameter).R3,i423,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert15,interface-elemsm8,R6,L1,V1,R36,R3,i457,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R6,L1,V1,R8,R0,s40,The type form of a type expression node.R3,i471,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R6,L1,V1,R39,R0,s154,[params-vector results...] of a func-type: the parameter vector (tagged with a single\n  unnamed result) and, for named or several results, :results [...].R3,i534,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,type-params*m8,R25,TR3,i553,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,type-paramsm10,R6,L1,V1,R36,R0,s88,The type parameter vector of a field list (nil when none), with its brackets' positions.R3,i555,R4,i1,R5,s25,arbace/repr/go/convert.aem8,R6,L1,V1,R36,R3,i561,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,binary-opsm38,s2,>>R40,s2,&&R41,s2,!=R42,s1,*R43,s1,%R44,s2,<=R45,s1,|R46,s1,/R47,s1,-R48,s2,>=R49,s1,&R50,s1,<R51,s2,<<R52,s2,&^R53,s2,||R54,s2,==R55,s1,^R56,s1,+R57,s1,>R58,m6,R3,i584,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,nary-opsS10,R56,R43,R53,R48,R54,R50,R47,R46,R57,R41,m6,R3,i588,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,unary-opsm12,s1,-R48,s1,+R57,s1,^R59,s1,!R60,s1,&R61,s2,<-R62,m6,R3,i590,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,assign-opsm22,s2,-=R48,s2,/=R47,s2,%=R44,s2,*=R43,s2,|=R46,s3,<<=R52,s3,>>=R40,s3,&^=R53,s2,^=R56,s2,&=R50,s2,+=R57,m6,R3,i592,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,untyped-const?m10,R6,L1,V1,R8,R0,s61,Whether a constant expression is untyped (for §8.3's shifts).R3,i596,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,as-instm10,R6,L1,V1,R30,R0,s139,A generic type instance (G T...) as (inst G T...): in operands the printer reads as\n  expressions too (new, method-expr; PRINTER-NOTES A5).R3,i617,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,selection-viam8,R6,L1,V1,R63,R3,i626,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,selector-formm10,R6,L1,V1,R8,R0,s45,A selector expression not in callee position.R3,i630,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,raw-selectm10,R6,L1,V1,R8,R0,s118,Raw mode: x.f as (go/select x f), of unknown kind: a package member, a field, a method value\n  or a method expression.R3,i654,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,spreadm10,R6,L1,V1,R17,R0,s91,x... as (spread x), on x's line: a literal's too (f(nil...), append(b, \"s\"...); GPS25 (b)).R3,i671,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,call-argsm8,R6,L1,V2,R64,R65,R3,i676,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,builtin-namem10,R6,L1,V1,R66,R0,s84,The head of a builtin call: len, append, ..., or unsafe/Sizeof with the file's name.R3,i682,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,raw-callm10,R6,L1,V1,R8,R0,s186,Raw mode: a call of unknown kind, (F args...): a conversion, a builtin call, a method call or\n  a function call; F the callee's form, (go/call h args...) when it is a head of the syntax.R3,i691,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,callm8,R6,L1,V1,R8,R3,i707,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,instantiationm10,R6,L1,V1,R8,R0,s310,F[T...] in an expression: (inst F T...), F carrying :inst when the arguments are partial. F is\n  written as the expression it is elsewhere: inside its parentheses (mode :full), a field's or\n  method value's selector with its name's position, a method expression's name with its line and\n  position (GPS25 (b)).R3,i757,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,compositem8,R6,L1,V1,R8,R3,i790,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,stmt-listm8,R25,TR3,i827,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,fn-sig-formsm8,R25,TR3,i827,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,generic-decl?m8,R25,TR3,i827,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,func-litm8,R6,L1,V1,R8,R3,i829,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R6,L1,V1,R8,R0,s31,The form of an expression node.R3,i842,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,targetsm10,R6,L1,V3,R67,R14,R68,R0,s57,Binding or assignment targets: one form, or (values ...).R3,i944,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,initsm8,R6,L1,V2,R69,R14,R3,i951,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,define-targetm10,R6,L1,V1,R8,R0,s126,A := target: a new name, or a reused one marked ^:assign. Raw mode: every name but _ marked\n  ^:go/define, new or reused open.R3,i956,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,define-bindingm10,R6,L1,V1,R70,R0,s29,[target init] of x, y := e...R3,i970,R4,i1,R5,s25,arbace/repr/go/convert.ae")

var Lit_254 *jrt.String = jrt.Intern("arbace.repr.go.convert$eval1114000004$loading__1927001464__auto____1114000005")

var Lit_255 *jrt.String = jrt.Intern("arbace.repr.go.convert$eval1114000008$fn__1114000009")

var Lit_256 *jrt.String = jrt.Intern("arbace.repr.go.convert$note_BANG_")

var Lit_257 *jrt.String = jrt.Intern("arbace.repr.go.convert$count_node_BANG_")

var Lit_258 *jrt.String = jrt.Intern("arbace.repr.go.convert$fail")

var Lit_259 *jrt.String = jrt.Intern("arbace.repr.go.convert$nt")

var Lit_260 *jrt.String = jrt.Intern("arbace.repr.go.convert$nf")

var Lit_261 *jrt.String = jrt.Intern("arbace.repr.go.convert$an")

var Lit_262 *jrt.String = jrt.Intern("arbace.repr.go.convert$unparen")

var Lit_263 *jrt.String = jrt.Intern("arbace.repr.go.convert$parse_pos")

var Lit_264 *jrt.String = jrt.Intern("arbace.repr.go.convert$pos_line")

var Lit_265 *jrt.String = jrt.Intern("arbace.repr.go.convert$recv_chan_pos")

var Lit_266 *jrt.String = jrt.Intern("arbace.repr.go.convert$start")

var Lit_267 *jrt.String = jrt.Intern("arbace.repr.go.convert$line_of")

var Lit_268 *jrt.String = jrt.Intern("arbace.repr.go.convert$positions")

var Lit_269 *jrt.String = jrt.Intern("arbace.repr.go.convert$max_pos")

var Lit_270 *jrt.String = jrt.Intern("arbace.repr.go.convert$form")

var Lit_271 *jrt.String = jrt.Intern("arbace.repr.go.convert$at")

var Lit_272 *jrt.String = jrt.Intern("arbace.repr.go.convert$line")

var Lit_273 *jrt.String = jrt.Intern("arbace.repr.go.convert$open")

var Lit_274 *jrt.String = jrt.Intern("arbace.repr.go.convert$with_pos")

var Lit_275 *jrt.String = jrt.Intern("arbace.repr.go.convert$full_meta")

var Lit_276 *jrt.String = jrt.Intern("arbace.repr.go.convert$add_parens")

var Lit_277 *jrt.String = jrt.Intern("arbace.repr.go.convert$reparen")

var Lit_278 *jrt.String = jrt.Intern("arbace.repr.go.convert$block_pos")

var Lit_279 *jrt.String = jrt.Intern("arbace.repr.go.convert$with_line")

var Lit_280 *jrt.String = jrt.Intern("arbace.repr.go.convert$vec_at")

var Lit_281 *jrt.String = jrt.Intern("arbace.repr.go.convert$add_meta")

var Lit_282 *jrt.String = jrt.Intern("arbace.repr.go.convert$lit_at")

var Lit_283 *jrt.String = jrt.Intern("arbace.repr.go.convert$relined")

var Lit_284 *jrt.String = jrt.Intern("arbace.repr.go.convert$ident_name")

var Lit_285 *jrt.String = jrt.Intern("arbace.repr.go.convert$obj")

var Lit_286 *jrt.String = jrt.Intern("arbace.repr.go.convert$targs")

var Lit_287 *jrt.String = jrt.Intern("arbace.repr.go.convert$inst_meta")

var Lit_288 *jrt.String = jrt.Intern("arbace.repr.go.convert$ident")

var Lit_289 *jrt.String = jrt.Intern("arbace.repr.go.convert$label_kw")

var Lit_290 *jrt.String = jrt.Intern("arbace.repr.go.convert$pkg_ident_QMARK_")

var Lit_291 *jrt.String = jrt.Intern("arbace.repr.go.convert$raw_name")

var Lit_292 *jrt.String = jrt.Intern("arbace.repr.go.convert$spelled")

var Lit_293 *jrt.String = jrt.Intern("arbace.repr.go.convert$lit_spelling")

var Lit_294 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit")

var Lit_295 *jrt.String = jrt.Intern("arbace.repr.go.convert$string_value")

var Lit_296 *jrt.String = jrt.Intern("arbace.repr.go.convert$tagged")

var Lit_297 *jrt.String = jrt.Intern("arbace.repr.go.convert$group_marks")

var Lit_298 *jrt.String = jrt.Intern("arbace.repr.go.convert$mark_ungrouped")

var Lit_299 *jrt.String = jrt.Intern("arbace.repr.go.convert$doc_of")

var Lit_300 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields")

var Lit_301 *jrt.String = jrt.Intern("arbace.repr.go.convert$interface_elems")

var Lit_302 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_form")

var Lit_303 *jrt.String = jrt.Intern("arbace.repr.go.convert$signature")

var Lit_304 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params")

var Lit_305 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_")

var Lit_306 *jrt.String = jrt.Intern("arbace.repr.go.convert$untyped_const_QMARK_")

var Lit_307 *jrt.String = jrt.Intern("arbace.repr.go.convert$as_inst")

var Lit_308 *jrt.String = jrt.Intern("arbace.repr.go.convert$selection_via")

var Lit_309 *jrt.String = jrt.Intern("arbace.repr.go.convert$selector_form")

var Lit_310 *jrt.String = jrt.Intern("arbace.repr.go.convert$raw_select")

var Lit_311 *jrt.String = jrt.Intern("arbace.repr.go.convert$spread")

var Lit_312 *jrt.String = jrt.Intern("arbace.repr.go.convert$call_args")

var Lit_313 *jrt.String = jrt.Intern("arbace.repr.go.convert$builtin_name")

var Lit_314 *jrt.String = jrt.Intern("arbace.repr.go.convert$raw_call")

var Lit_315 *jrt.String = jrt.Intern("arbace.repr.go.convert$call")

var Lit_316 *jrt.String = jrt.Intern("arbace.repr.go.convert$instantiation")

var Lit_317 *jrt.String = jrt.Intern("arbace.repr.go.convert$composite")

var Lit_318 *jrt.String = jrt.Intern("arbace.repr.go.convert$func_lit")

var Lit_319 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr")

var Lit_320 *jrt.String = jrt.Intern("arbace.repr.go.convert$targets")

var Lit_321 *jrt.String = jrt.Intern("arbace.repr.go.convert$inits")

var Lit_322 *jrt.String = jrt.Intern("arbace.repr.go.convert$define_target")

var Lit_323 *jrt.String = jrt.Intern("arbace.repr.go.convert$define_binding")

var Lit_324 *jrt.String = jrt.Intern("kn8,arglistsyn2,nmkn3,dockn4,linekn6,columnkn4,fileyn2,stkn8,declaredyn1,lyn1,cyn4,textkn7,privateyn5,stmtsyn4,fromyn2,toyn4,listkn4,keysyn4,tailyn5,blockyn4,optsyn1,byn5,else?yn4,inityn1,nyn4,bodyyn1,iyn7,tswitchyn1,syn2,ftkn3,tagyn6,Stringyn9,decl-nameyn5,textsyn1,_yn1,dyn5,dmetayn2,spyn4,kindyn5,extrayn9,spec-metayn4,dumpyn4,nameyn5,declsyn5,bytesyn6,groupsyn4,litsyn3,astyn2,feyn6,ns-symyn2,xsyn9,positionsyn7,src-dirv22,arbace.repr.go.convert9,const-valm10,R0,L1,V1,R1,R2,s41,{:val v} of a constant name's definition.R3,i978,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,decl-bindingsm10,R0,L1,V1,R6,R2,s86,The let bindings of a local declaration (a decl-stmt), and the kind :let or :let-type.R3,i986,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,decl-stmt?m10,R0,L1,V1,R6,R2,s60,Whether a statement declares (it becomes a let or let-type).R3,i1055,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,bindings-ofm8,R0,L1,V1,R6,R3,i1064,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,stmtm8,R7,TR3,i1070,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,simple-stmtm8,R7,TR3,i1070,R4,i1,R5,s25,arbace/repr/go/convert.aem8,R7,TR3,i1070,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,dir-formm8,R0,L1,V1,V3,R8,R9,R10,R3,i1072,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,gap-directivesm12,R11,TR0,L1,V3,R12,R13,R14,R2,s164,For statements stmts in a block spanning [from to] (positions), the directives in the gaps:\n  a vector of n+1 lists, gap k before statement k, gap n after the last.R3,i1077,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,stmts-formsm10,R0,L1,V4,R15,R13,R14,m2,R16,V1,R17,R2,s271,The forms of a statement list stmts spanning the positions (from, to). Declarations become\n  a let (or let-type) whose body is the rest of the list (§7.3). opts :tail: the list ends a\n  function with results, so a final return of one expression is that expression (§6.4).R3,i1094,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R0,L1,V2,R18,R19,R2,s48,The forms of a block's statements (stmts-forms).R3,i1145,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,block-formsm10,R0,L1,V1,R20,R2,s30,A nested Go block as (do ...).R3,i1152,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,branchm10,R0,L1,V2,R20,R21,R2,s171,A branch of if/cond (§7.2): one statement, or (do ...) for a statement list; else? (an else\n  branch): a single if, when or cond is wrapped in do, which an else if is not.R3,i1157,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,init-vecm10,R0,L1,V2,R22,R8,R2,s88,The init vector of if, switch, type-switch and for: [target expr] for a :=, [stmt] else.R3,i1170,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,if-formm8,R0,L1,V1,R23,R3,i1179,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,clause-boundm10,R0,L1,V2,R24,R25,R2,s80,The end bound of clause i of a switch or select body: the next clause, or the }.R3,i1218,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,type-syntax?m10,R0,L1,V1,R23,R2,s57,Whether node n is written as a type (type-form takes it).R3,i1226,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,case-clausem8,R0,L1,V3,R9,R14,R26,R3,i1237,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,clausesm8,R0,L1,V2,R24,R26,R3,i1256,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,comm-clausem8,R0,L1,V2,R9,R14,R3,i1260,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,assignm8,R0,L1,V1,R23,R3,i1276,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R0,L1,V1,R27,R2,s47,A simple statement in an init or post position.R3,i1297,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,stmt*m8,R7,TR3,i1302,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R0,L1,V2,R23,R17,R2,s94,The form of a statement (not a declaration). tail: the last of a function body with\n  results.R3,i1304,R4,i1,R5,s25,arbace/repr/go/convert.aem8,R0,L1,V2,R23,R17,R3,i1313,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R0,L1,V1,R28,R2,s42,The signature part of fn: params, results.R3,i1401,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,directive-namem10,R0,L1,V1,Myn4,textm2,R29,R30,R2,s52,The name of a //go: directive (\"nosplit\"), else nil.R3,i1408,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,directive-argsm8,R0,L1,V1,Myn4,textm2,R29,R30,R3,i1416,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert19,free-standing-namesS3,s11,linknamestds8,generates5,buildm8,R3,i1421,R4,i1,R5,s25,arbace/repr/go/convert.aeR2,s87,//go: directives that gc applies by name or to the file, never to the next declaration.v22,arbace.repr.go.convert11,attachable?m10,R0,L1,V2,R10,R31,R2,s187,Whether the directive attaches to a declaration named decl-name that follows it: gc's\n  pragmas (noder.go) other than linkname naming another declaration, cgo's and the\n  file-level ones.R3,i1425,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,directive-metam10,R0,L1,V1,R32,R2,s83,The metadata of attached directives (texts in order): {:go/name true|\"args\"|[...]}.R3,i1436,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,free-directivem8,R0,L1,V1,V3,R8,R33,R10,R3,i1447,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R0,L1,V1,R34,R2,s89,A func-decl with type parameters or a receiver of a generic type, or a generic type spec.R3,i1453,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,func-declm8,R0,L1,V2,R34,R35,R3,i1466,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert17,value-spec-targetm10,R0,L1,V3,R36,R37,R38,R2,s114,The target of a package-level value spec: a name or (values ...); docs and directive\n  metadata on the first name.R3,i1491,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,gen-declm8,R0,L1,V2,R34,R39,R3,i1506,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert15,file-directivesm10,R0,L1,V2,R40,R41,R2,s58,The dump's directives of file name: [[line col text] ...].R3,i1547,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,decl-namem10,R0,L1,V1,R34,R2,s68,The name a directive before declaration d (or spec) would attach to.R3,i1559,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,imports-ofm8,R0,L1,V1,R42,R3,i1568,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,whitespace?m10,R11,TR0,L1,V1,R20,R3,i1594,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,source-textm10,R0,L1,V3,Myn2,bsm2,R29,R43,R44,R45,R2,s632,What mode :full keeps of a Go file's text beyond the syntax tree, from the file's bytes bs:\n  {:comments [[line col text] ...] (every comment, as the source spells it), :space [[line col\n  ws] ...] (the white space runs other than gofmt's: indentation of tabs, single or aligning\n  spaces between tokens, nothing at the end of a line), :semis [[line col] ...] (the\n  semicolons the source writes: the syntax tree keeps none), :tail (the white space after the\n  last token or comment)}. groups are the dump's comment groups, lits the [start end] positions of\n  its basic literals (white space inside literals and comments is theirs).R3,i1596,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert17,basic-lit-extentsm10,R11,TR0,L1,V1,R46,R3,i1673,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,convert-filem10,R0,L1,V3,R40,R47,R48,R2,s179,The forms of one Go file of the dump: {:name :forms [...] :comments {line [text]}\n  :unplaced [...]} (forms in order: in-ns, go/file, declarations and free-standing\n  directives).R3,i1681,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,open-countsm10,R0,L1,V1,R49,R2,s182,The open decisions of raw forms xs by kind ({kind n}): every form, symbol and vector marked\n  ::open, in the forms and in their public metadata (a local type's :type-params, a :tag).R3,i1826,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,init-orderm8,R0,L1,V1,R40,R3,i1844,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,munge-namem10,R11,TR0,L1,V1,R27,R3,i1856,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,package-formm8,R0,L1,V2,R40,m2,R16,V1,R50,R3,i1858,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,file-stemm10,R0,L1,V2,R41,R51,R2,s198,The .ae path stem of Go file name in package directory dir (a Go source directory): x for\n  x.go, or x.go when dir has a subdirectory x (a package of that name would own x.ae:\n  proposed amendment).R3,i1883,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert15,convert-packagem10,R0,L1,V2,R40,R19,R2,s446,Converts a dump. opts: :positions (:lines or :full), :ns (the namespace symbol, default from\n  the import path), :namespaces ({path ns-sym} of other packages whose namespace is not their\n  path's: a directory test's), :src-dir (the package's source directory, for file-name\n  collisions), :raw (raw mode: the typed decisions open; with :positions :full).\n  Returns {:ns sym :package form :files [{:name :stem :forms :comments :unplaced}] :stats}.R3,i1893,R4,i1,R5,s25,arbace/repr/go/convert.ae")

var Lit_325 *jrt.String = jrt.Intern("arbace.repr.go.convert$const_val")

var Lit_326 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings")

var Lit_327 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_stmt_QMARK_")

var Lit_328 *jrt.String = jrt.Intern("arbace.repr.go.convert$bindings_of")

var Lit_329 *jrt.String = jrt.Intern("arbace.repr.go.convert$dir_form")

var Lit_330 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives")

var Lit_331 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms")

var Lit_332 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt_list")

var Lit_333 *jrt.String = jrt.Intern("arbace.repr.go.convert$block_forms")

var Lit_334 *jrt.String = jrt.Intern("arbace.repr.go.convert$branch")

var Lit_335 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_vec")

var Lit_336 *jrt.String = jrt.Intern("arbace.repr.go.convert$if_form")

var Lit_337 *jrt.String = jrt.Intern("arbace.repr.go.convert$clause_bound")

var Lit_338 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_syntax_QMARK_")

var Lit_339 *jrt.String = jrt.Intern("arbace.repr.go.convert$case_clause")

var Lit_340 *jrt.String = jrt.Intern("arbace.repr.go.convert$clauses")

var Lit_341 *jrt.String = jrt.Intern("arbace.repr.go.convert$comm_clause")

var Lit_342 *jrt.String = jrt.Intern("arbace.repr.go.convert$assign")

var Lit_343 *jrt.String = jrt.Intern("arbace.repr.go.convert$simple_stmt")

var Lit_344 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt")

var Lit_345 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt_STAR_")

var Lit_346 *jrt.String = jrt.Intern("arbace.repr.go.convert$fn_sig_forms")

var Lit_347 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_name")

var Lit_348 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_args")

var Lit_349 *jrt.String = jrt.Intern("arbace.repr.go.convert$attachable_QMARK_")

var Lit_350 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_meta")

var Lit_351 *jrt.String = jrt.Intern("arbace.repr.go.convert$free_directive")

var Lit_352 *jrt.String = jrt.Intern("arbace.repr.go.convert$generic_decl_QMARK_")

var Lit_353 *jrt.String = jrt.Intern("arbace.repr.go.convert$func_decl")

var Lit_354 *jrt.String = jrt.Intern("arbace.repr.go.convert$value_spec_target")

var Lit_355 *jrt.String = jrt.Intern("arbace.repr.go.convert$gen_decl")

var Lit_356 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_directives")

var Lit_357 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_name")

var Lit_358 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of")

var Lit_359 *jrt.String = jrt.Intern("arbace.repr.go.convert$whitespace_QMARK_")

var Lit_360 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text")

var Lit_361 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents")

var Lit_362 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file")

var Lit_363 *jrt.String = jrt.Intern("arbace.repr.go.convert$open_counts")

var Lit_364 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order")

var Lit_365 *jrt.String = jrt.Intern("arbace.repr.go.convert$munge_name")

var Lit_366 *jrt.String = jrt.Intern("arbace.repr.go.convert$package_form")

var Lit_367 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_stem")

var Lit_368 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package")
