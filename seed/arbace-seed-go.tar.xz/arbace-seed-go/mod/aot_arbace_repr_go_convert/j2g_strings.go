//line j2g_strings.ae:1
package aot_arbace_repr_go_convert

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn18,arbace.repr.go.litkn2,asyn3,lityn25,arbace.repr.go.print-textyn5,ptextyn20,arbace.repr.go.typesyn2,tyyn13,arbace.stringyn3,strkn3,dockn5,noteskn5,nodeskn4,nodekn10,paren-exprkn1,xkn4,elsekn9,send-stmtkn10,array-typekn6,lbrackkn8,ellipsiskn7,if-stmtkn2,ifkn4,chankn11,import-speckn4,namekn10,value-speckn4,pathkn10,unary-exprkn6,op-poskn5,nameskn5,identkn8,name-poskn11,return-stmtkn6,returnkn13,composite-litkn4,typekn6,lbracekn9,chan-typekn5,beginkn5,fieldkn8,map-typekn3,mapkn11,case-clausekn4,casekn10,field-listkn7,openingkn4,listkn10,index-exprkn9,decl-stmtkn9,expr-stmtkn4,declkn11,assign-stmtkn10,slice-exprkn3,lhskn9,call-exprkn14,interface-typekn9,interfacekn3,funkn14,key-value-exprkn13,selector-exprkn3,keykn10,empty-stmtkn9,semicolonkn9,type-speckn8,gen-declkn7,tok-poskn12,inc-dec-stmtkn8,for-stmtkn3,forkn12,labeled-stmtkn8,func-litkn5,labelkn9,star-exprkn4,starkn9,func-typekn4,funckn15,index-list-exprkn6,paramskn11,binary-exprkn11,switch-stmtkn6,switchkn10,defer-stmtkn5,deferkn9,basic-litkn9,value-poskn16,type-switch-stmtkn11,struct-typekn6,structkn10,range-stmtkn6,lparenkn16,type-assert-exprkn11,select-stmtkn6,selectkn11,branch-stmtkn7,go-stmtkn2,gokn11,comm-clausekn9,func-declkn10,block-stmtks22,arbace.repr.go.convert1,lks22,arbace.repr.go.convert3,posks22,arbace.repr.go.convert4,fullkn6,rparenkn6,parensks2,go6,parenskn6,rbracekn4,linekn3,poskn5,spellkn5,colonkn3,usekn3,defkn5,targskn4,instkn4,kindkn8,universekn3,nilkn4,modekn5,constkn5,go-idys2,go2,idkn3,pkgks2,go4,textkn5,valueyn9,imaginarykn3,tagks2,go7,groupedkn4,textkn7,struct?ks2,go7,tag-posks2,go8,tag-textyn5,slicekn3,eltks2,go3,tagyn1,&kn3,dirkn4,recvkn4,bothkn4,sendyn4,chankn5,arrowkn7,closingyn9,interfacekn7,methodskn7,indiceskn5,indexyn4,instkn3,lenyn6,structkn6,fieldskn2,opyn5,arrayyn3,...yn5,tildeyn3,mapkn1,ykn3,selkn5,x-posyn1,|ks2,go3,opskn7,resultsyn1,*yn4,funckn15,results-openingkn15,results-closingkn7,builtinkn1,tkn4,argskn3,viaks2,go3,viakn11,method-exprkn6,methodyn11,method-expryn6,spreadyn3,newyn4,convkn3,dotkn7,go-callys2,go4,callkn4,eltskn4,bodykn4,tailks2,go3,endyn2,fnkn3,lowkn4,highkn3,maxkn16,negative-literalyn8,subsliceyn2,oryn3,andkn13,logical-parenks2,go5,parenyn2,>>yn2,<<kn9,shift-tagyn6,assertyn4,agetks22,arbace.repr.go.convert5,derefyn5,derefyn6,valuesyn1,_kn6,assignkn3,rhskn3,valkn3,tokkn5,specskn3,letkn6,valueskn20,local-const-repeatedks2,go8,implicitkn17,local-const-groupkn23,local-const-group-splityn4,zerokn3,varkn8,let-typekn11,type-paramskn5,aliaskn18,local-generic-typekn4,stmtkn19,directive-statementys2,go9,directivekn19,labeled-declarationkn11,label-colonks2,go5,labelks2,go10,label-lineyn3,letyn8,let-typeyn2,doyn4,whenyn2,ifyn4,condkn4,initkn4,condks2,go4,condkn11,else-lbracekn11,else-rbraceyn7,defaultyn4,casekn4,commkn6,rbrackyn4,asetyn4,set!kn15,implicit-returnyn6,returnyn5,labelkn4,postyn6,selectyn5,breakyn8,continueyn4,gotoyn11,fallthroughyn5,whileyn3,foryn5,deferkn4,callyn4,inc!yn4,dec!kn9,guard-tokkn9,guard-dotkn12,guard-lparenkn12,guard-rparenyn11,type-switchyn5,rangeyn6,switchyn2,>!yn2,gokn14,directive-freekn6,externkn12,recv-openingkn12,recv-closingys2,go6,methodys2,go4,funckn10,directiveskn8,implicitkn8,commentskn5,semiskn6,trailskn5,spacekn9,value-endkn3,astkn4,filekn5,declskn6,attachkn18,directive-attachedys2,go4,filekn10,go-versionkn7,packagekn5,buildkn4,langkn7,importskn4,freekn5,formskn8,unplacedkn5,innerkn10,in-importsks2,go8,commentsks2,go5,semisks2,go6,trailsks2,go5,spaceks2,go4,tailkn18,directive-unplacedks22,arbace.repr.go.convert3,rawyn5,in-nsyn5,quotekn10,init-orderkn9,positionskn6,configkn8,go-fileskn7,s-fileskn7,h-fileskn10,syso-fileskn7,c-fileskn9,cxx-fileskn7,m-fileskn7,f-fileskn10,swig-fileskn14,swig-cxx-fileskn11,embed-fileskn16,test-embed-filesys2,go7,packagekn5,fileskn4,gooskn6,goarchkn7,goamd64kn7,goarm64kn9,toolchainkn4,tagskn12,goexperimentkn3,cgokn8,compilerkn11,other-fileskn13,test-go-fileskn10,test-fileskn13,local-importskn19,file-name-collisionkn2,nskn5,statskn10,underlyingkn5,typeskn4,fullkn8,text-dirkn10,type-tablekn10,namespaceskn4,stemkn7,src-dirv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn22,arbace.repr.go.convertm2,R10,s615,repr/go's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.repr.go.lit/Lit (text and value). arbace.repr.go.layout writes them as text.v11,arbace.core13,*loaded-libs*v22,arbace.repr.go.convert7,*stats*v11,arbace.core5,swap!v11,arbace.core9,update-inv11,arbace.core4,fnilR11,v11,arbace.core3,incl0,R12,v11,arbace.core5,firstv11,arbace.core7,ex-infov11,arbace.core6,pr-strv11,arbace.core4,seq?v11,arbace.core4,map?v11,arbace.core6,secondv11,arbace.core4,valsR13,v11,arbace.core6,filterv11,arbace.core7,string?v11,arbace.core10,re-matchesp7,\\d+:\\d+R14,v22,arbace.repr.go.convert2,ntR15,v22,arbace.repr.go.convert2,nfp7,\\d+:\\d+v11,arbace.core4,subsv22,arbace.repr.go.convert9,parse-posv22,arbace.repr.go.convert5,*src*R16,S3,l32,l13,l9,l1,R17,v22,arbace.repr.go.convert5,startR18,R19,R20,R21,R22,v22,arbace.repr.go.convert4,failR23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,v11,arbace.core3,seqR41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,R73,R74,R75,R76,R77,R78,R79,R80,R81,R82,R83,R84,R85,R86,R87,R88,R89,R90,R91,R92,R93,R94,R95,R96,R97,R98,R99,v22,arbace.repr.go.convert8,pos-linev11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core4,keepv11,arbace.core9,volatile!v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core7,vector?v11,arbace.core4,run!v11,arbace.core7,vreset!v11,arbace.core10,chunk-restv11,arbace.core4,nextV2,l0,l0,v11,arbace.core9,with-metav11,arbace.core5,applyR100,v11,arbace.core5,assocv11,arbace.core4,listR101,v22,arbace.repr.go.convert9,positionsv11,arbace.core9,vary-metav11,arbace.core6,updatev11,arbace.core5,mergev22,arbace.repr.go.convert6,*full*R102,v11,arbace.core3,notv18,arbace.repr.go.lit4,lit?R103,R104,V2,R102,R105,v22,arbace.repr.go.convert10,add-parensv22,arbace.repr.go.convert7,reparenR106,v22,arbace.repr.go.convert4,linev11,arbace.core3,vecv11,arbace.core6,empty?R107,R108,v11,arbace.core7,symbol?R109,R110,v11,arbace.core6,dissocv11,arbace.core3,mapv22,arbace.repr.go.convert7,relinedv11,arbace.core4,mapvR111,v22,arbace.repr.go.convert2,anR112,v20,arbace.repr.go.types9,type-formR113,R114,v22,arbace.repr.go.convert3,objR115,v22,arbace.repr.go.convert5,targsv22,arbace.repr.go.convert10,ident-namev22,arbace.repr.go.convert7,line-ofv22,arbace.repr.go.convert2,atS3,s5,falses4,trues3,nilR116,R117,R118,R119,v22,arbace.repr.go.convert6,lit-atv22,arbace.repr.go.convert4,formv22,arbace.repr.go.convert8,add-metav22,arbace.repr.go.convert11,count-node!v11,arbace.core6,symbolv18,arbace.repr.go.lit3,litm6,s4,trueTs5,falseFs3,nilnv22,arbace.repr.go.convert5,note!R120,R121,v18,arbace.repr.go.lit11,string-textv22,arbace.repr.go.convert9,inst-metav22,arbace.repr.go.convert5,identv11,arbace.core7,keywordR122,v22,arbace.repr.go.convert7,unparenv22,arbace.repr.go.convert9,full-metaR123,R124,v25,arbace.repr.go.print-text9,go-stringv11,arbace.core5,char?v25,arbace.repr.go.print-text7,go-runev11,arbace.core7,number?v25,arbace.repr.go.print-text9,go-numberv11,arbace.core3,strv25,arbace.repr.go.print-text14,go-byte-stringv11,arbace.core4,restv11,arbace.core8,to-arrayv22,arbace.repr.go.convert7,spelledv18,arbace.repr.go.lit10,bytes-formv18,arbace.repr.go.lit9,rune-formv22,arbace.repr.go.convert12,lit-spellingv18,arbace.repr.go.lit12,string-bytesR125,v18,arbace.repr.go.lit10,imag-innerv18,arbace.repr.go.lit14,float-text-litv18,arbace.repr.go.lit10,rune-valuev18,arbace.repr.go.lit7,int-litR126,v22,arbace.repr.go.convert9,*generic*v11,arbace.core4,consR127,v11,arbace.core11,map-indexedv11,arbace.core9,contains?R128,v11,arbace.core4,not=v22,arbace.repr.go.convert11,*kept-docs*R129,v22,arbace.repr.go.convert14,mark-ungroupedv11,arbace.core6,mapcatR10,v22,arbace.repr.go.convert9,type-formv22,arbace.repr.go.convert6,doc-ofR130,R131,v11,arbace.core6,concatR132,R133,R134,v22,arbace.repr.go.convert12,string-valuev22,arbace.repr.go.convert8,*groups*V1,R135,v22,arbace.repr.go.convert11,group-marksv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv22,arbace.repr.go.convert6,taggedv11,arbace.core10,chunk-consv11,arbace.core5,chunkv22,arbace.repr.go.convert9,signatureR136,R137,v22,arbace.repr.go.convert8,with-posR138,R139,v11,arbace.core9,namespacev20,arbace.repr.go.types19,reserved-type-headsR132,v22,arbace.repr.go.convert13,recv-chan-posR140,R141,R140,R140,R142,R143,v22,arbace.repr.go.convert15,interface-elemsR144,R145,R146,R147,R148,R149,v22,arbace.repr.go.convert6,fieldsR150,m2,R129,TR151,R132,R152,R153,R152,v22,arbace.repr.go.convert4,exprR154,v22,arbace.repr.go.convert10,pkg-ident?R155,R156,R157,R158,R159,R160,R161,v11,arbace.core11,select-keysV2,R46,R142,R162,R163,v22,arbace.repr.go.convert6,vec-atR163,V2,R46,R142,R164,R165,V2,R46,R142,v22,arbace.repr.go.convert12,type-params*V2,R46,R142,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv22,arbace.repr.go.convert14,untyped-const?R166,S3,s4,imags4,reals7,complexv11,arbace.core6,every?R167,v20,arbace.repr.go.types8,untyped?S2,s2,>>s2,<<R168,S1,R147,R147,R169,R170,R171,S2,R172,R40,R173,v22,arbace.repr.go.convert7,as-instv22,arbace.repr.go.convert13,selection-viav11,arbace.core3,popR174,v11,arbace.core4,peekv22,arbace.repr.go.convert12,builtin-nameR175,R172,v22,arbace.repr.go.convert14,reserved-headsR176,R174,R177,v22,arbace.repr.go.convert9,call-argsR178,R179,R173,R147,R180,R3,R181,v22,arbace.repr.go.convert12,fn-sig-formsv11,arbace.core4,atomv11,arbace.core5,doallv22,arbace.repr.go.convert9,stmt-listR182,v22,arbace.repr.go.convert12,*return-pos*R183,R184,v22,arbace.repr.go.convert9,block-posS2,s3,INTs5,FLOATv22,arbace.repr.go.convert9,basic-litv22,arbace.repr.go.convert9,unary-opsv22,arbace.repr.go.convert9,compositeR185,R186,R187,S6,R18,R75,R38,R87,R41,R56,R188,v22,arbace.repr.go.convert4,callR189,v22,arbace.repr.go.convert13,selector-formv22,arbace.repr.go.convert10,binary-opsv22,arbace.repr.go.convert8,nary-opsS2,R190,R191,R192,m2,R193,TS2,R194,R195,v11,arbace.core4,rseqR196,R197,v22,arbace.repr.go.convert13,instantiationR198,v22,arbace.repr.go.convert8,func-litR199,R200,R201,R201,R202,R203,R204,v22,arbace.repr.go.convert7,targetsv22,arbace.repr.go.convert13,define-targetv22,arbace.repr.go.convert5,initsv18,arbace.repr.go.lit10,const-formR205,v20,arbace.repr.go.types10,const-kindR206,R207,R208,R209,v22,arbace.repr.go.convert9,const-valR210,V3,R66,R90,R103,R211,R212,R213,R214,R215,R216,R217,v22,arbace.repr.go.convert11,type-paramsv22,arbace.repr.go.convert13,generic-decl?V3,R66,R90,R103,R218,R219,v22,arbace.repr.go.convert10,decl-stmt?R220,v22,arbace.repr.go.convert11,bindings-ofv22,arbace.repr.go.convert13,decl-bindingsv22,arbace.repr.go.convert14,define-bindingv22,arbace.repr.go.convert8,*placed*R221,R222,v11,arbace.core4,somev11,arbace.core6,removev11,arbace.core6,reducev22,arbace.repr.go.convert9,*fn-dirs*v11,arbace.core6,repeatv22,arbace.repr.go.convert7,max-posv11,arbace.core12,keep-indexedv22,arbace.repr.go.convert14,gap-directivesv22,arbace.repr.go.convert8,dir-formR223,R224,R225,v22,arbace.repr.go.convert8,label-kwR226,R227,R228,v11,arbace.core8,identityv22,arbace.repr.go.convert4,stmtv22,arbace.repr.go.convert11,stmts-formsR229,R229,S3,R230,R231,R232,R229,v22,arbace.repr.go.convert11,simple-stmtR233,R234,R230,v22,arbace.repr.go.convert8,init-vecR235,R232,v22,arbace.repr.go.convert6,branchR231,v22,arbace.repr.go.convert7,if-formR236,R237,R238,R239,v22,arbace.repr.go.convert11,case-clausev22,arbace.repr.go.convert12,clause-boundR240,R238,R239,v11,arbace.core1,=v22,arbace.repr.go.convert10,assign-opsR241,R242,R243,R243,R243,v22,arbace.repr.go.convert5,stmt*S5,R86,R68,R92,R80,R89,v11,arbace.core6,reset!R244,R245,R246,R246,R247,R248,v22,arbace.repr.go.convert11,comm-clausem8,s5,breakR249,s8,continueR250,s4,gotoR251,s11,fallthroughR252,R253,R253,R254,v22,arbace.repr.go.convert6,assignR255,R256,R257,R258,R259,R260,R261,R262,R263,v22,arbace.repr.go.convert7,clausesR264,m2,R203,TR265,R266,R267,v22,arbace.repr.go.convert11,block-formsv13,arbace.string12,starts-with?v13,arbace.string8,index-ofl5,v13,arbace.string5,trimlv22,arbace.repr.go.convert14,directive-namev22,arbace.repr.go.convert19,free-standing-namesv13,arbace.string5,splitv22,arbace.repr.go.convert14,directive-argsp3,\\s+R268,R222,S2,R77,R48,m2,R269,TR270,R271,R272,R273,R201,m2,R218,Tv22,arbace.repr.go.convert17,value-spec-targetR274,V3,R66,R90,R103,S2,s1,_s1,.R275,V3,R66,R90,R103,S2,s1,_s1,.v11,arbace.core6,vectorV1,l0,v22,arbace.repr.go.convert11,whitespace?v11,arbace.core9,transientR276,R277,v11,arbace.core11,persistent!R278,R279,v11,arbace.core4,sortl10,c9,c32,v11,arbace.core5,conj!R280,v11,arbace.core8,tree-seqv11,arbace.core5,coll?R281,R282,R283,v22,arbace.repr.go.convert15,file-directivesv11,arbace.core4,lastv11,arbace.core6,get-inv22,arbace.repr.go.convert14,directive-metaR284,R285,R286,R287,R288,R289,R290,R291,v22,arbace.repr.go.convert10,*text-dir*v22,arbace.repr.go.convert11,source-textv22,arbace.repr.go.convert14,free-directivev11,arbace.core4,takel2,R292,v22,arbace.repr.go.convert8,gen-declv22,arbace.repr.go.convert9,func-declv11,arbace.core5,rangeR293,R294,v22,arbace.repr.go.convert11,attachable?v22,arbace.repr.go.convert9,decl-nameR295,R296,v11,arbace.core7,sort-byv22,arbace.repr.go.convert10,imports-ofv22,arbace.repr.go.convert17,basic-lit-extentsR297,R298,R299,R300,R301,v13,arbace.string11,split-linesv13,arbace.string7,replaceR302,R303,R304,R305,p16,(.*):(\\d+):(\\d+)R201,R306,p4,[.-]R307,R308,R309,V9,R310,R311,R312,R313,R314,R315,R316,R317,R318,R319,R320,R321,v22,arbace.repr.go.convert10,munge-namep1,/v11,arbace.core9,array-mapR322,R323,R324,R325,R326,R327,R328,R329,R330,R331,R332,R333,R334,R335,v22,arbace.repr.go.convert10,init-orderR336,R337,v20,arbace.repr.go.types10,ns-name-ofv22,arbace.repr.go.convert12,package-formR338,R339,R340,v22,arbace.repr.go.convert6,*dump*R341,R342,v20,arbace.repr.go.types7,*table*R343,v20,arbace.repr.go.types5,*pkg*v20,arbace.repr.go.types12,*namespaces*R344,v20,arbace.repr.go.types12,*underlying*v22,arbace.repr.go.convert12,convert-fileR345,v22,arbace.repr.go.convert9,file-stemR346,v20,arbace.repr.go.types9,*imports*S2,s1,_s1,.S2,s1,_s1,.S2,s1,_s1,.S2,s1,_s1,.")

var Lit_1 *jrt.String = jrt.Intern("arbace.repr.go.convert$add_parens$fn__1114000072")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.go.convert$add_parens$fn__1114000074")

var Lit_3 *jrt.String = jrt.Intern("=")

var Lit_4 *jrt.String = jrt.Intern("assignment ")

var Lit_5 *jrt.String = jrt.Intern("arbace.repr.go.convert$at$fn__1114000052")

var Lit_6 *jrt.String = jrt.Intern("arbace.repr.go.convert$at$fn__1114000052$fn__1114000054")

var Lit_7 *jrt.String = jrt.Intern("cgo_")

var Lit_8 *jrt.String = jrt.Intern("linkname")

var Lit_9 *jrt.String = jrt.Intern("")

var Lit_10 *jrt.String = jrt.Intern("STRING")

var Lit_11 *jrt.String = jrt.Intern("IMAG")

var Lit_12 *jrt.String = jrt.Intern("FLOAT")

var Lit_13 *jrt.String = jrt.Intern("CHAR")

var Lit_14 *jrt.String = jrt.Intern("INT")

var Lit_15 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents$iter__1114000680__1114000684")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents$fn__1114000694")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents$iter__1114000680__1114000684$fn__1114000685")

var Lit_19 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents$iter__1114000680__1114000684$fn__1114000685$fn__1114000686")

var Lit_20 *jrt.String = jrt.Intern("builtin")

var Lit_21 *jrt.String = jrt.Intern("conversion arity")

var Lit_22 *jrt.String = jrt.Intern("arbace.repr.go.convert$call$fn__1114000198")

var Lit_23 *jrt.String = jrt.Intern(".")

var Lit_24 *jrt.String = jrt.Intern("arbace.repr.go.convert$case_clause$fn__1114000387")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.go.convert$clauses$fn__1114000390")

var Lit_26 *jrt.String = jrt.Intern(":=")

var Lit_27 *jrt.String = jrt.Intern("select case")

var Lit_28 *jrt.String = jrt.Intern("_")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.go.convert$composite$fn__1114000207")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.go.convert$composite$fn__1114000209")

var Lit_31 *jrt.String = jrt.Intern("struct literal key")

var Lit_32 *jrt.String = jrt.Intern(":")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000702__1114000706")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000712")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000715")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000721")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000726")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$inside_of__1114000729")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000741")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$attach_meta__1114000754")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000764")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000766")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000768")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000778__1114000784")

var Lit_45 *jrt.String = jrt.Intern("\n")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000808")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000813")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000825")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000830")

var Lit_50 *jrt.String = jrt.Intern("(in-ns '")

var Lit_51 *jrt.String = jrt.Intern(")")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$attach_meta__1114000754$fn__1114000756")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$attach_meta__1114000754$fn__1114000761")

var Lit_54 *jrt.String = jrt.Intern("import")

var Lit_55 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000741$fn__1114000745")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000741$fn__1114000748")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000768$fn__1114000769")

var Lit_58 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000768$fn__1114000771")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000768$fn__1114000773")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000768$fn__1114000775")

var Lit_61 *jrt.String = jrt.Intern("//go:build")

var Lit_62 *jrt.String = jrt.Intern("// +build")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000813$fn__1114000814")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000813$fn__1114000821")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000813$fn__1114000814$fn__1114000815")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000813$fn__1114000814$fn__1114000818")

var Lit_67 *jrt.String = jrt.Intern("declaration")

var Lit_68 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000830$fn__1114000832")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000830$fn__1114000832$fn__1114000840")

var Lit_70 *jrt.String = jrt.Intern("\r")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$fn__1114000830$fn__1114000832$fn__1114000846")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$inside_of__1114000729$fn__1114000734")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000702__1114000706$fn__1114000707")

var Lit_74 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000702__1114000706$fn__1114000707$fn__1114000708")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000778__1114000784$fn__1114000785")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000778__1114000784$fn__1114000785$iter__1114000780__1114000786")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000778__1114000784$fn__1114000785$iter__1114000780__1114000786$fn__1114000787")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file$iter__1114000778__1114000784$fn__1114000785$iter__1114000780__1114000786$fn__1114000787$fn__1114000788")

var Lit_79 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000896__1114000900")

var Lit_80 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910")

var Lit_81 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000896__1114000900$fn__1114000901")

var Lit_82 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000896__1114000900$fn__1114000901$fn__1114000902")

var Lit_83 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911")

var Lit_84 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$fn__1114000912")

var Lit_85 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$iter__1114000932__1114000938")

var Lit_86 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$fn__1114000948")

var Lit_87 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$fn__1114000912$iter__1114000913__1114000919")

var Lit_88 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$fn__1114000912$fn__1114000929")

var Lit_89 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$fn__1114000912$iter__1114000913__1114000919$fn__1114000920")

var Lit_90 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$fn__1114000912$iter__1114000913__1114000919$fn__1114000920$iter__1114000915__1114000921")

var Lit_91 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$fn__1114000912$iter__1114000913__1114000919$fn__1114000920$iter__1114000915__1114000921$fn__1114000922")

var Lit_92 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$fn__1114000912$iter__1114000913__1114000919$fn__1114000920$iter__1114000915__1114000921$fn__1114000922$fn__1114000923")

var Lit_93 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$iter__1114000932__1114000938$fn__1114000939")

var Lit_94 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$iter__1114000932__1114000938$fn__1114000939$iter__1114000934__1114000940")

var Lit_95 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$iter__1114000932__1114000938$fn__1114000939$iter__1114000934__1114000940$fn__1114000941")

var Lit_96 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package$iter__1114000906__1114000910$fn__1114000911$iter__1114000932__1114000938$fn__1114000939$iter__1114000934__1114000940$fn__1114000941$fn__1114000942")

var Lit_97 *jrt.String = jrt.Intern("const")

var Lit_98 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000250")

var Lit_99 *jrt.String = jrt.Intern("var")

var Lit_100 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000264")

var Lit_101 *jrt.String = jrt.Intern("type")

var Lit_102 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000270")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000250$fn__1114000256")

var Lit_104 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000250$mk__1114000258")

var Lit_105 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000250$fn__1114000261")

var Lit_106 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings$fn__1114000264$mk__1114000267")

var Lit_107 *jrt.String = jrt.Intern("var without type")

var Lit_108 *jrt.String = jrt.Intern(" ")

var Lit_109 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_meta$fn__1114000421")

var Lit_110 *jrt.String = jrt.Intern("go")

var Lit_111 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_meta$fn__1114000421$fn__1114000422")

var Lit_112 *jrt.String = jrt.Intern("//go:")

var Lit_113 *jrt.String = jrt.Intern("ellipsis outside a parameter list")

var Lit_114 *jrt.String = jrt.Intern("-")

var Lit_115 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$fn__1114000222")

var Lit_116 *jrt.String = jrt.Intern("~")

var Lit_117 *jrt.String = jrt.Intern("unary operator")

var Lit_118 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$fn__1114000226")

var Lit_119 *jrt.String = jrt.Intern("binary operator")

var Lit_120 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$operand__1114000231")

var Lit_121 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$fn__1114000233")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr$fn__1114000236")

var Lit_123 *jrt.String = jrt.Intern("x.(type) outside a type switch")

var Lit_124 *jrt.String = jrt.Intern("key-value outside a literal")

var Lit_125 *jrt.String = jrt.Intern("expression")

var Lit_126 *jrt.String = jrt.Intern(": ")

var Lit_127 *jrt.String = jrt.Intern(" at ")

var Lit_128 *jrt.String = jrt.Intern("arbace.repr.go.convert$fail$fn__1114000016")

var Lit_129 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields$fn__1114000120")

var Lit_130 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields$fn__1114000120$iter__1114000124__1114000128")

var Lit_131 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields$fn__1114000120$iter__1114000124__1114000128$fn__1114000129")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields$fn__1114000120$iter__1114000124__1114000128$fn__1114000129$fn__1114000130")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_directives$iter__1114000466__1114000470")

var Lit_134 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_directives$iter__1114000466__1114000470$fn__1114000471")

var Lit_135 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_directives$iter__1114000466__1114000470$fn__1114000471$fn__1114000472")

var Lit_136 *jrt.String = jrt.Intern("//line ")

var Lit_137 *jrt.String = jrt.Intern("/")

var Lit_138 *jrt.String = jrt.Intern("arbace.repr.go.convert$func_decl$fn__1114000440")

var Lit_139 *jrt.String = jrt.Intern("arbace.repr.go.convert$func_lit$fn__1114000216")

var Lit_140 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000286")

var Lit_141 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000291")

var Lit_142 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$inside_QMARK___1114000293")

var Lit_143 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000302")

var Lit_144 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000308")

var Lit_145 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$fn__1114000308$fn__1114000313")

var Lit_146 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives$inside_QMARK___1114000293$fn__1114000295")

var Lit_147 *jrt.String = jrt.Intern("arbace.repr.go.convert$gen_decl$spec__1114000450")

var Lit_148 *jrt.String = jrt.Intern("arbace.repr.go.convert$gen_decl$fn__1114000454")

var Lit_149 *jrt.String = jrt.Intern("arbace.repr.go.convert$gen_decl$spec_vec__1114000459")

var Lit_150 *jrt.String = jrt.Intern("arbace.repr.go.convert$group_marks$fn__1114000110")

var Lit_151 *jrt.String = jrt.Intern("arbace.repr.go.convert$if_form$fn__1114000359")

var Lit_152 *jrt.String = jrt.Intern("arbace.repr.go.convert$if_form$fn__1114000372")

var Lit_153 *jrt.String = jrt.Intern(":else")

var Lit_154 *jrt.String = jrt.Intern("arbace.repr.go.convert$if_form$fn__1114000378")

var Lit_155 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501")

var Lit_156 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501$fn__1114000502")

var Lit_157 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501$fn__1114000502$iter__1114000497__1114000503")

var Lit_158 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501$fn__1114000502$iter__1114000497__1114000503$fn__1114000504")

var Lit_159 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501$fn__1114000502$iter__1114000497__1114000503$fn__1114000504$fn__1114000505")

var Lit_160 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501$fn__1114000502$iter__1114000497__1114000503$fn__1114000504$nm__1114000523")

var Lit_161 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501$fn__1114000502$iter__1114000497__1114000503$fn__1114000504$decl_pos__1114000525")

var Lit_162 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501$fn__1114000502$iter__1114000497__1114000503$fn__1114000504$fn__1114000505$nm__1114000512")

var Lit_163 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of$iter__1114000495__1114000501$fn__1114000502$iter__1114000497__1114000503$fn__1114000504$fn__1114000505$decl_pos__1114000514")

var Lit_164 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000854__1114000858")

var Lit_165 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000854__1114000858$fn__1114000859")

var Lit_166 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000854__1114000858$fn__1114000859$fn__1114000860")

var Lit_167 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000854__1114000858$fn__1114000859$one__1114000876")

var Lit_168 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order$iter__1114000854__1114000858$fn__1114000859$fn__1114000860$one__1114000864")

var Lit_169 *jrt.String = jrt.Intern(".-")

var Lit_170 *jrt.String = jrt.Intern("arbace.repr.go.convert$interface_elems$iter__1114000136__1114000140")

var Lit_171 *jrt.String = jrt.Intern("arbace.repr.go.convert$interface_elems$iter__1114000136__1114000140$fn__1114000141")

var Lit_172 *jrt.String = jrt.Intern("arbace.repr.go.convert$interface_elems$iter__1114000136__1114000140$fn__1114000141$fn__1114000142")

var Lit_173 *jrt.String = jrt.Intern("imaginary")

var Lit_174 *jrt.String = jrt.Intern("i")

var Lit_175 *jrt.String = jrt.Intern("rune")

var Lit_176 *jrt.String = jrt.Intern("byte-string")

var Lit_177 *jrt.String = jrt.Intern("arbace.repr.go.convert$mark_ungrouped$fn__1114000113")

var Lit_178 *jrt.String = jrt.Intern("arbace.repr.go.convert$max_pos$walk__1114000042")

var Lit_179 *jrt.String = jrt.Intern("arbace.repr.go.convert$package_form$fn__1114000892")

var Lit_180 *jrt.String = jrt.Intern("amd64")

var Lit_181 *jrt.String = jrt.Intern("arbace.repr.go.convert$positions$fn__1114000036")

var Lit_182 *jrt.String = jrt.Intern("arbace.repr.go.convert$recv_chan_pos$fn__1114000028")

var Lit_183 *jrt.String = jrt.Intern("chan")

var Lit_184 *jrt.String = jrt.Intern("arbace.repr.go.convert$relined$fn__1114000086")

var Lit_185 *jrt.String = jrt.Intern("arbace.repr.go.convert$relined$fn__1114000088")

var Lit_186 *jrt.String = jrt.Intern("arbace.repr.go.convert$relined$fn__1114000090")

var Lit_187 *jrt.String = jrt.Intern("selector")

var Lit_188 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000535")

var Lit_189 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$off__1114000538")

var Lit_190 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$text__1114000543")

var Lit_191 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551")

var Lit_192 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000581__1114000585")

var Lit_193 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000597__1114000601")

var Lit_194 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000613")

var Lit_195 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000635")

var Lit_196 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000637")

var Lit_197 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000639")

var Lit_198 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$fn__1114000641")

var Lit_199 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000643__1114000647")

var Lit_200 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000659__1114000663")

var Lit_201 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551$fn__1114000552")

var Lit_202 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551$fn__1114000552$iter__1114000547__1114000553")

var Lit_203 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551$fn__1114000552$iter__1114000547__1114000553$fn__1114000554")

var Lit_204 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551$fn__1114000552$iter__1114000547__1114000553$fn__1114000554$fn__1114000555")

var Lit_205 *jrt.String = jrt.Intern("//")

var Lit_206 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551$fn__1114000552$iter__1114000547__1114000553$fn__1114000554$fn__1114000573")

var Lit_207 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551$fn__1114000552$iter__1114000547__1114000553$fn__1114000554$fn__1114000575")

var Lit_208 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551$fn__1114000552$iter__1114000547__1114000553$fn__1114000554$fn__1114000555$fn__1114000562")

var Lit_209 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000545__1114000551$fn__1114000552$iter__1114000547__1114000553$fn__1114000554$fn__1114000555$fn__1114000564")

var Lit_210 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000581__1114000585$fn__1114000586")

var Lit_211 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000581__1114000585$fn__1114000586$fn__1114000587")

var Lit_212 *jrt.String = jrt.Intern("UTF-8")

var Lit_213 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000597__1114000601$fn__1114000602")

var Lit_214 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000597__1114000601$fn__1114000602$fn__1114000603")

var Lit_215 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000643__1114000647$fn__1114000648")

var Lit_216 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000643__1114000647$fn__1114000648$fn__1114000649")

var Lit_217 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000659__1114000663$fn__1114000664")

var Lit_218 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000659__1114000663$fn__1114000664$fn__1114000665")

var Lit_219 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000659__1114000663$fn__1114000664$fn__1114000675")

var Lit_220 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text$iter__1114000659__1114000663$fn__1114000664$fn__1114000665$fn__1114000669")

var Lit_221 *jrt.String = jrt.Intern("no start for")

var Lit_222 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt_STAR_$fn__1114000403")

var Lit_223 *jrt.String = jrt.Intern("true")

var Lit_224 *jrt.String = jrt.Intern("++")

var Lit_225 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt_STAR_$tgt__1114000413")

var Lit_226 *jrt.String = jrt.Intern("declaration outside a statement list")

var Lit_227 *jrt.String = jrt.Intern("statement")

var Lit_228 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$fn__1114000325")

var Lit_229 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$fn__1114000331")

var Lit_230 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$build__1114000333")

var Lit_231 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$build__1114000333$kind_of__1114000340")

var Lit_232 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$build__1114000333$fn__1114000342")

var Lit_233 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms$build__1114000333$fn__1114000344")

var Lit_234 *jrt.String = jrt.Intern("unary type")

var Lit_235 *jrt.String = jrt.Intern("type selector")

var Lit_236 *jrt.String = jrt.Intern("|")

var Lit_237 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_form$fn__1114000162")

var Lit_238 *jrt.String = jrt.Intern("binary type")

var Lit_239 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_form$fl_pos__1114000165")

var Lit_240 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_$fn__1114000170")

var Lit_241 *jrt.String = jrt.Intern("any")

var Lit_242 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_$fn__1114000170$iter__1114000173__1114000177")

var Lit_243 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_$fn__1114000170$iter__1114000173__1114000177$fn__1114000178")

var Lit_244 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_$fn__1114000170$iter__1114000173__1114000177$fn__1114000178$fn__1114000179")

var Lit_245 *jrt.String = jrt.Intern("arbace.repr.go.convert$value_spec_target$mk__1114000445")

var Lit_246 *jrt.String = jrt.Intern("arbace.repr.go.convert$with_pos$fn__1114000061")

var Lit_247 *jrt.String = jrt.Intern("arbace.repr.go.convert$with_pos$fn__1114000066")

var Lit_248 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn1,kyn1,nyn3,msgkn3,tagyn6,Stringyn1,syn5,arrowyn1,lyn1,&yn2,xsyn1,xyn1,myn1,pyn1,byn22,arbace.repr.go.lit.Lityn3,posyn4,instyn8,explicitkn7,privateyn3,rawyn7,printedkn8,declaredyn3,symyn1,tyn4,symsyn5,elemsyn10,names-onlyyn7,pos-stryn6,groupsyn10,field-listkn4,keysyn7,struct?yn2,ftyn2,>>yn3,andyn2,!=yn1,*yn1,%yn2,<=yn6,bit-oryn1,/yn1,-yn2,>=yn7,bit-andyn1,<yn2,<<yn11,bit-and-notyn2,oryn2,==yn7,bit-xoryn1,+yn1,>yn7,bit-notyn3,notyn4,addryn2,<!yn1,ayn4,argsyn8,ellipsisyn3,funyn3,lhsyn2,mkyn3,rhsyn2,styn2,nmyn1,cyn4,textyn5,stmtsyn4,fromyn2,tov11,arbace.core5,in-nsMyn22,arbace.repr.go.convertm2,R0,s615,repr/go's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.repr.go.lit/Lit (text and value). arbace.repr.go.layout writes them as text.m2,R0,s615,repr/go's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.repr.go.lit/Lit (text and value). arbace.repr.go.layout writes them as text.R1,v22,arbace.repr.go.convert6,*dump*m8,R2,TR3,i17,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,*stats*m8,R2,TR3,i18,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,*generic*m8,R2,TR3,i19,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,*kept-docs*m8,R2,TR3,i20,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,*fn-dirs*m8,R2,TR3,i21,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,*placed*m8,R2,TR3,i22,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,*full*m8,R2,TR3,i23,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,*return-pos*m8,R2,TR3,i24,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,*text-dir*m8,R2,TR3,i25,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,*src*m8,R2,TR3,i26,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,note!m8,R6,L1,V1,R7,R3,i28,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,count-node!m8,R6,L1,V1,R8,R3,i29,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,failm8,R6,L1,V2,R9,R8,R3,i31,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert2,ntm8,R6,L1,V1,R8,R3,i39,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert2,nfm8,R6,L1,V1,R8,R3,i40,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert2,anm8,R6,L1,V1,R8,R3,i41,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,unparenm8,R6,L1,V1,R8,R3,i43,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,parse-posm8,R6,L1,V1,Myn1,sm2,R10,R11,R3,i45,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,pos-linem8,R6,L1,V1,R12,R3,i50,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,recv-chan-posm10,R6,L1,V1,R13,R0,s310,Mode :full: the position \"L:C\" of the keyword chan of a receive-only channel type whose\n  arrow is at arrow, when white space separates them (`<- chan T`): go/ast keeps the arrow's\n  position only, and the printer writes chan right after it otherwise. nil when they are\n  adjacent or the source is not at hand.R3,i52,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,startm10,R6,L1,V1,R8,R0,s54,The position string of a node's start, go/ast's Pos().R3,i76,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,line-ofm8,R6,L1,V1,R8,R3,i125,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,positionsm10,R6,L1,V1,R8,R0,s51,The position fields of a node: {:field [line col]}.R3,i127,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,max-posm10,R6,L1,V1,R8,R0,s53,The greatest position [line col] in a node's subtree.R3,i134,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,formm10,R6,L1,V4,R8,R14,R15,R16,R0,s88,A list form beginning on line l, built from node n (whose positions it keeps for :full).R3,i150,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert2,atm10,R6,L1,V3,R17,R8,R14,R0,s64,x (a symbol, list or vector) with line l and node n's positions.R3,i155,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,linem8,R6,L1,V1,R17,R3,i163,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,with-posm10,R6,L1,V2,R17,R18,R0,s89,x with more positions for mode :full: m maps keys to position strings (nil ones skipped).R3,i165,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,full-metam10,R6,L1,V2,R17,R18,R0,s86,x with the public metadata m that only mode :full writes (layout writes ::full there).R3,i173,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,add-parensm10,R6,L1,V2,R17,R19,R0,s153,x (a form or a Lit) inside the parentheses of the ParenExpr node p (mode :full): the pair\n  [lparen rparen] before those x already has (outermost first).R3,i180,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,reparenm10,R6,L1,V2,R17,R8,R0,s63,x, built from (unparen n), inside n's parentheses (mode :full).R3,i192,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,block-posm8,R6,L1,V1,R20,R3,i199,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,with-linem8,R6,L1,V2,R14,R17,R3,i201,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,vec-atm8,R6,L1,V2,R14,R16,R3,i204,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,add-metam10,R6,L1,V2,R17,R18,R0,s39,x with the public metadata m merged in.R3,i206,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,lit-atm10,R6,L1,V3,R14,Myn1,xm2,R10,R21,R22,R0,s57,A Lit placed on line l (layout records it in its parent).R3,i211,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,relinedm10,R6,L1,V2,R14,R17,R0,s82,x with every form inside on line l and no positions (an implicitly repeated init).R3,i216,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,reserved-headsv11,arbace.core4,intom8,R3,i229,R4,i1,R5,s25,arbace/repr/go/convert.aeR0,s83,Unqualified heads of Go context (§13.5): a call of a Go name among them is go/call.v11,arbace.core3,mapv11,arbace.core6,concatv11,arbace.core6,symbolV27,s3,lets8,let-types4,set!s4,asets4,inc!s4,dec!s2,>!s2,gos5,defers6,returns5,breaks8,continues4,gotos11,fallthroughs5,labels2,dos2,ifs4,whens4,conds6,switchs11,type-switchs6,selects4,cases7,defaults3,fors5,whiles5,rangeV38,s1,+s1,-s1,*s1,/s1,%s2,<<s2,>>s2,==s2,!=s1,<s2,<=s1,>s2,>=s3,ands2,ors3,nots7,bit-ands6,bit-ors7,bit-xors7,bit-nots11,bit-and-nots4,addrs2,<!s3,lits4,convs6,asserts4,agets8,subslices6,spreads6,valuess4,insts11,method-exprs2,fns4,zeros4,runes9,imaginarys11,byte-strings5,derefV18,s6,appends3,caps5,clears5,closes7,complexs4,copys6,deletes4,imags3,lens4,makes3,maxs3,mins3,news5,panics5,prints7,printlns4,reals7,recoverV9,s5,slices5,arrays3,maps4,chans4,funcs6,structs9,interfaces1,|s5,tildev22,arbace.repr.go.convert10,ident-namem8,R6,L1,V1,R8,R3,i245,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert3,objm8,R6,L1,V1,R8,R3,i247,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,targsm10,R6,L1,V1,R23,R0,s63,The type forms of the type arguments of an instance annotation.R3,i249,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,inst-metam10,R6,L1,V2,R8,R24,R0,s132,{:inst [...]} for the use of a generic function or method whose type arguments are not\n  all in the source (explicit: how many are).R3,i254,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,identm10,R6,L2,V1,R8,V2,R8,R24,R0,s86,An identifier as a symbol, a literal (the universe's true, false, nil) or (go/id \"x\").R3,i263,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,label-kwm8,R6,L1,V1,R8,R3,i279,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,pkg-ident?m8,R6,L1,V1,R8,R3,i281,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,spelledm12,R25,TR6,L1,V3,R17,R26,R27,R0,s183,x (a Lit or a literal list) with the source's spelling raw of a basic literal when the\n  printer would spell it otherwise (printed, a function of x giving its spelling; mode\n  :full).R3,i285,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,lit-spellingm12,R25,TR6,L1,V1,R17,R0,s84,The printer's spelling of a literal of the forms (a Lit's value, or a literal list).R3,i298,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,basic-litm8,R6,L1,V1,R8,R3,i313,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,string-valuem10,R6,L1,V1,R8,R0,s74,The Go string value of a STRING basic literal (import paths, struct tags).R3,i328,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,exprm8,R28,TR3,i335,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,type-formm8,R28,TR3,i335,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,signaturem8,R28,TR3,i335,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,field-list-vecm8,R28,TR3,i335,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,taggedm10,R6,L1,V2,R29,R30,R0,s44,The symbol sym with the type form t as :tag.R3,i337,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,group-marksm12,R25,TR6,L1,V1,R31,R0,s143,Names of one field after the first get :go/group inside generic declarations (proposed\n  amendment: gc's output depends on field groups there).R3,i342,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,mark-ungroupedm10,R6,L1,V2,R32,R33,R0,s172,Inside generic declarations, a name declared apart from the name before it although of an\n  equal type gets :go/grouped false, so that the printer does not group them (A1).R3,i350,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,doc-ofm10,R6,L1,V2,R34,R35,R0,s84,The kept doc text of a comment group position, recording it as kept; nil when empty.R3,i366,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,*groups*m8,R2,TR3,i375,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,fieldsm10,R6,L1,V2,R36,m2,R37,V1,R38,R0,s246,The elements of a struct type's fields, or of a parameter/result vector: a tagged name per\n  name, a type form for an unnamed field (embedded or unnamed parameter). opts: :struct (tags,\n  docs), :variadic (an Ellipsis type is the last parameter).R3,i377,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert15,interface-elemsm8,R6,L1,V1,R36,R3,i411,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R6,L1,V1,R8,R0,s40,The type form of a type expression node.R3,i425,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R6,L1,V1,R39,R0,s154,[params-vector results...] of a func-type: the parameter vector (tagged with a single\n  unnamed result) and, for named or several results, :results [...].R3,i487,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,type-params*m8,R28,TR3,i506,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,type-paramsm10,R6,L1,V1,R36,R0,s88,The type parameter vector of a field list (nil when none), with its brackets' positions.R3,i508,R4,i1,R5,s25,arbace/repr/go/convert.aem8,R6,L1,V1,R36,R3,i514,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,binary-opsm38,s2,>>R40,s2,&&R41,s2,!=R42,s1,*R43,s1,%R44,s2,<=R45,s1,|R46,s1,/R47,s1,-R48,s2,>=R49,s1,&R50,s1,<R51,s2,<<R52,s2,&^R53,s2,||R54,s2,==R55,s1,^R56,s1,+R57,s1,>R58,m6,R3,i535,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,nary-opsS10,R56,R43,R53,R48,R54,R50,R47,R46,R57,R41,m6,R3,i539,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,unary-opsm12,s1,-R48,s1,+R57,s1,^R59,s1,!R60,s1,&R61,s2,<-R62,m6,R3,i541,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,assign-opsm22,s2,-=R48,s2,/=R47,s2,%=R44,s2,*=R43,s2,|=R46,s3,<<=R52,s3,>>=R40,s3,&^=R53,s2,^=R56,s2,&=R50,s2,+=R57,m6,R3,i543,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,untyped-const?m10,R6,L1,V1,R8,R0,s61,Whether a constant expression is untyped (for §8.3's shifts).R3,i547,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,as-instm10,R6,L1,V1,R30,R0,s139,A generic type instance (G T...) as (inst G T...): in operands the printer reads as\n  expressions too (new, method-expr; PRINTER-NOTES A5).R3,i568,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,selection-viam8,R6,L1,V1,R63,R3,i577,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,selector-formm10,R6,L1,V1,R8,R0,s45,A selector expression not in callee position.R3,i581,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,call-argsm8,R6,L1,V2,R64,R65,R3,i604,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,builtin-namem10,R6,L1,V1,R66,R0,s84,The head of a builtin call: len, append, ..., or unsafe/Sizeof with the file's name.R3,i610,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,callm8,R6,L1,V1,R8,R3,i619,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,instantiationm10,R6,L1,V1,R8,R0,s89,F[T...] in an expression: (inst F T...), F carrying :inst when the arguments are partial.R3,i668,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,compositem8,R6,L1,V1,R8,R3,i696,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,stmt-listm8,R28,TR3,i724,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,fn-sig-formsm8,R28,TR3,i724,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,generic-decl?m8,R28,TR3,i724,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,func-litm8,R6,L1,V1,R8,R3,i726,R4,i1,R5,s25,arbace/repr/go/convert.aem10,R6,L1,V1,R8,R0,s31,The form of an expression node.R3,i739,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,targetsm10,R6,L1,V3,R67,R14,R68,R0,s57,Binding or assignment targets: one form, or (values ...).R3,i825,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,initsm8,R6,L1,V2,R69,R14,R3,i832,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,define-targetm10,R6,L1,V1,R8,R0,s57,A := target: a new name, or a reused one marked ^:assign.R3,i837,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,define-bindingm10,R6,L1,V1,R70,R0,s29,[target init] of x, y := e...R3,i845,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,const-valm10,R6,L1,V1,R71,R0,s41,{:val v} of a constant name's definition.R3,i853,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert13,decl-bindingsm10,R6,L1,V1,R70,R0,s86,The let bindings of a local declaration (a decl-stmt), and the kind :let or :let-type.R3,i861,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,decl-stmt?m10,R6,L1,V1,R70,R0,s60,Whether a statement declares (it becomes a let or let-type).R3,i929,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,bindings-ofm8,R6,L1,V1,R70,R3,i938,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert4,stmtm8,R28,TR3,i944,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,simple-stmtm8,R28,TR3,i944,R4,i1,R5,s25,arbace/repr/go/convert.aem8,R28,TR3,i944,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,dir-formm8,R6,L1,V1,V3,R14,R72,R73,R3,i946,R4,i1,R5,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,gap-directivesm12,R25,TR6,L1,V3,R74,R75,R76,R0,s164,For statements stmts in a block spanning [from to] (positions), the directives in the gaps:\n  a vector of n+1 lists, gap k before statement k, gap n after the last.R3,i951,R4,i1,R5,s25,arbace/repr/go/convert.ae")

var Lit_249 *jrt.String = jrt.Intern("arbace.repr.go.convert$eval1114000004$loading__1927001464__auto____1114000005")

var Lit_250 *jrt.String = jrt.Intern("arbace.repr.go.convert$eval1114000008$fn__1114000009")

var Lit_251 *jrt.String = jrt.Intern("arbace.repr.go.convert$note_BANG_")

var Lit_252 *jrt.String = jrt.Intern("arbace.repr.go.convert$count_node_BANG_")

var Lit_253 *jrt.String = jrt.Intern("arbace.repr.go.convert$fail")

var Lit_254 *jrt.String = jrt.Intern("arbace.repr.go.convert$nt")

var Lit_255 *jrt.String = jrt.Intern("arbace.repr.go.convert$nf")

var Lit_256 *jrt.String = jrt.Intern("arbace.repr.go.convert$an")

var Lit_257 *jrt.String = jrt.Intern("arbace.repr.go.convert$unparen")

var Lit_258 *jrt.String = jrt.Intern("arbace.repr.go.convert$parse_pos")

var Lit_259 *jrt.String = jrt.Intern("arbace.repr.go.convert$pos_line")

var Lit_260 *jrt.String = jrt.Intern("arbace.repr.go.convert$recv_chan_pos")

var Lit_261 *jrt.String = jrt.Intern("arbace.repr.go.convert$start")

var Lit_262 *jrt.String = jrt.Intern("arbace.repr.go.convert$line_of")

var Lit_263 *jrt.String = jrt.Intern("arbace.repr.go.convert$positions")

var Lit_264 *jrt.String = jrt.Intern("arbace.repr.go.convert$max_pos")

var Lit_265 *jrt.String = jrt.Intern("arbace.repr.go.convert$form")

var Lit_266 *jrt.String = jrt.Intern("arbace.repr.go.convert$at")

var Lit_267 *jrt.String = jrt.Intern("arbace.repr.go.convert$line")

var Lit_268 *jrt.String = jrt.Intern("arbace.repr.go.convert$with_pos")

var Lit_269 *jrt.String = jrt.Intern("arbace.repr.go.convert$full_meta")

var Lit_270 *jrt.String = jrt.Intern("arbace.repr.go.convert$add_parens")

var Lit_271 *jrt.String = jrt.Intern("arbace.repr.go.convert$reparen")

var Lit_272 *jrt.String = jrt.Intern("arbace.repr.go.convert$block_pos")

var Lit_273 *jrt.String = jrt.Intern("arbace.repr.go.convert$with_line")

var Lit_274 *jrt.String = jrt.Intern("arbace.repr.go.convert$vec_at")

var Lit_275 *jrt.String = jrt.Intern("arbace.repr.go.convert$add_meta")

var Lit_276 *jrt.String = jrt.Intern("arbace.repr.go.convert$lit_at")

var Lit_277 *jrt.String = jrt.Intern("arbace.repr.go.convert$relined")

var Lit_278 *jrt.String = jrt.Intern("arbace.repr.go.convert$ident_name")

var Lit_279 *jrt.String = jrt.Intern("arbace.repr.go.convert$obj")

var Lit_280 *jrt.String = jrt.Intern("arbace.repr.go.convert$targs")

var Lit_281 *jrt.String = jrt.Intern("arbace.repr.go.convert$inst_meta")

var Lit_282 *jrt.String = jrt.Intern("arbace.repr.go.convert$ident")

var Lit_283 *jrt.String = jrt.Intern("arbace.repr.go.convert$label_kw")

var Lit_284 *jrt.String = jrt.Intern("arbace.repr.go.convert$pkg_ident_QMARK_")

var Lit_285 *jrt.String = jrt.Intern("arbace.repr.go.convert$spelled")

var Lit_286 *jrt.String = jrt.Intern("arbace.repr.go.convert$lit_spelling")

var Lit_287 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit")

var Lit_288 *jrt.String = jrt.Intern("arbace.repr.go.convert$string_value")

var Lit_289 *jrt.String = jrt.Intern("arbace.repr.go.convert$tagged")

var Lit_290 *jrt.String = jrt.Intern("arbace.repr.go.convert$group_marks")

var Lit_291 *jrt.String = jrt.Intern("arbace.repr.go.convert$mark_ungrouped")

var Lit_292 *jrt.String = jrt.Intern("arbace.repr.go.convert$doc_of")

var Lit_293 *jrt.String = jrt.Intern("arbace.repr.go.convert$fields")

var Lit_294 *jrt.String = jrt.Intern("arbace.repr.go.convert$interface_elems")

var Lit_295 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_form")

var Lit_296 *jrt.String = jrt.Intern("arbace.repr.go.convert$signature")

var Lit_297 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params")

var Lit_298 *jrt.String = jrt.Intern("arbace.repr.go.convert$type_params_STAR_")

var Lit_299 *jrt.String = jrt.Intern("arbace.repr.go.convert$untyped_const_QMARK_")

var Lit_300 *jrt.String = jrt.Intern("arbace.repr.go.convert$as_inst")

var Lit_301 *jrt.String = jrt.Intern("arbace.repr.go.convert$selection_via")

var Lit_302 *jrt.String = jrt.Intern("arbace.repr.go.convert$selector_form")

var Lit_303 *jrt.String = jrt.Intern("arbace.repr.go.convert$call_args")

var Lit_304 *jrt.String = jrt.Intern("arbace.repr.go.convert$builtin_name")

var Lit_305 *jrt.String = jrt.Intern("arbace.repr.go.convert$call")

var Lit_306 *jrt.String = jrt.Intern("arbace.repr.go.convert$instantiation")

var Lit_307 *jrt.String = jrt.Intern("arbace.repr.go.convert$composite")

var Lit_308 *jrt.String = jrt.Intern("arbace.repr.go.convert$func_lit")

var Lit_309 *jrt.String = jrt.Intern("arbace.repr.go.convert$expr")

var Lit_310 *jrt.String = jrt.Intern("arbace.repr.go.convert$targets")

var Lit_311 *jrt.String = jrt.Intern("arbace.repr.go.convert$inits")

var Lit_312 *jrt.String = jrt.Intern("arbace.repr.go.convert$define_target")

var Lit_313 *jrt.String = jrt.Intern("arbace.repr.go.convert$define_binding")

var Lit_314 *jrt.String = jrt.Intern("arbace.repr.go.convert$const_val")

var Lit_315 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_bindings")

var Lit_316 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_stmt_QMARK_")

var Lit_317 *jrt.String = jrt.Intern("arbace.repr.go.convert$bindings_of")

var Lit_318 *jrt.String = jrt.Intern("arbace.repr.go.convert$dir_form")

var Lit_319 *jrt.String = jrt.Intern("arbace.repr.go.convert$gap_directives")

var Lit_320 *jrt.String = jrt.Intern("kn8,arglistsyn4,listyn4,fromyn2,tokn4,keysyn4,tailkn3,dockn4,linekn6,columnkn4,fileyn5,blockyn4,optsyn1,byn5,else?yn4,inityn1,lyn1,nyn4,bodyyn1,iyn1,cyn7,tswitchyn1,skn8,declaredyn2,ftkn3,tagyn6,Stringyn4,textyn9,decl-nameyn5,textsyn1,_yn1,dyn5,dmetayn2,spyn4,kindyn5,extrayn9,spec-metayn4,dumpyn4,nameyn5,declskn7,privateyn5,bytesyn6,groupsyn4,litsyn3,astyn2,feyn6,ns-symyn9,positionsyn7,src-dirv22,arbace.repr.go.convert11,stmts-formsm10,R0,L1,V4,R1,R2,R3,m2,R4,V1,R5,R6,s271,The forms of a statement list stmts spanning the positions (from, to). Declarations become\n  a let (or let-type) whose body is the rest of the list (§7.3). opts :tail: the list ends a\n  function with results, so a final return of one expression is that expression (§6.4).R7,i968,R8,i1,R9,s25,arbace/repr/go/convert.aem10,R0,L1,V2,R10,R11,R6,s48,The forms of a block's statements (stmts-forms).R7,i1018,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,block-formsm10,R0,L1,V1,R12,R6,s30,A nested Go block as (do ...).R7,i1025,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,branchm10,R0,L1,V2,R12,R13,R6,s171,A branch of if/cond (§7.2): one statement, or (do ...) for a statement list; else? (an else\n  branch): a single if, when or cond is wrapped in do, which an else if is not.R7,i1030,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,init-vecm10,R0,L1,V2,R14,R15,R6,s88,The init vector of if, switch, type-switch and for: [target expr] for a :=, [stmt] else.R7,i1043,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,if-formm8,R0,L1,V1,R16,R7,i1052,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,clause-boundm10,R0,L1,V2,R17,R18,R6,s80,The end bound of clause i of a switch or select body: the next clause, or the }.R7,i1091,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,case-clausem8,R0,L1,V3,R19,R3,R20,R7,i1099,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert7,clausesm8,R0,L1,V2,R17,R20,R7,i1114,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,comm-clausem8,R0,L1,V2,R19,R3,R7,i1118,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert6,assignm8,R0,L1,V1,R16,R7,i1134,R8,i1,R9,s25,arbace/repr/go/convert.aem10,R0,L1,V1,R21,R6,s47,A simple statement in an init or post position.R7,i1152,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert5,stmt*m8,R22,TR7,i1157,R8,i1,R9,s25,arbace/repr/go/convert.aem10,R0,L1,V2,R16,R5,R6,s94,The form of a statement (not a declaration). tail: the last of a function body with\n  results.R7,i1159,R8,i1,R9,s25,arbace/repr/go/convert.aem8,R0,L1,V2,R16,R5,R7,i1168,R8,i1,R9,s25,arbace/repr/go/convert.aem10,R0,L1,V1,R23,R6,s42,The signature part of fn: params, results.R7,i1256,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,directive-namem10,R0,L1,V1,Myn4,textm2,R24,R25,R6,s52,The name of a //go: directive (\"nosplit\"), else nil.R7,i1263,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,directive-argsm8,R0,L1,V1,Myn4,textm2,R24,R25,R7,i1271,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert19,free-standing-namesS3,s11,linknamestds8,generates5,buildm8,R7,i1276,R8,i1,R9,s25,arbace/repr/go/convert.aeR6,s87,//go: directives that gc applies by name or to the file, never to the next declaration.v22,arbace.repr.go.convert11,attachable?m10,R0,L1,V2,R26,R27,R6,s187,Whether the directive attaches to a declaration named decl-name that follows it: gc's\n  pragmas (noder.go) other than linkname naming another declaration, cgo's and the\n  file-level ones.R7,i1280,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,directive-metam10,R0,L1,V1,R28,R6,s83,The metadata of attached directives (texts in order): {:go/name true|\"args\"|[...]}.R7,i1291,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert14,free-directivem8,R0,L1,V1,V3,R15,R29,R26,R7,i1302,R8,i1,R9,s25,arbace/repr/go/convert.aem10,R0,L1,V1,R30,R6,s89,A func-decl with type parameters or a receiver of a generic type, or a generic type spec.R7,i1308,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,func-declm8,R0,L1,V2,R30,R31,R7,i1321,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert17,value-spec-targetm10,R0,L1,V3,R32,R33,R34,R6,s114,The target of a package-level value spec: a name or (values ...); docs and directive\n  metadata on the first name.R7,i1346,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert8,gen-declm8,R0,L1,V2,R30,R35,R7,i1360,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert15,file-directivesm10,R0,L1,V2,R36,R37,R6,s58,The dump's directives of file name: [[line col text] ...].R7,i1401,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,decl-namem10,R0,L1,V1,R30,R6,s68,The name a directive before declaration d (or spec) would attach to.R7,i1413,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,imports-ofm8,R0,L1,V1,R38,R7,i1422,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,whitespace?m10,R39,TR0,L1,V1,R12,R7,i1446,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert11,source-textm10,R0,L1,V3,Myn2,bsm2,R24,R40,R41,R42,R6,s632,What mode :full keeps of a Go file's text beyond the syntax tree, from the file's bytes bs:\n  {:comments [[line col text] ...] (every comment, as the source spells it), :space [[line col\n  ws] ...] (the white space runs other than gofmt's: indentation of tabs, single or aligning\n  spaces between tokens, nothing at the end of a line), :semis [[line col] ...] (the\n  semicolons the source writes: the syntax tree keeps none), :tail (the white space after the\n  last token or comment)}. groups are the dump's comment groups, lits the [start end] positions of\n  its basic literals (white space inside literals and comments is theirs).R7,i1448,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert17,basic-lit-extentsm10,R39,TR0,L1,V1,R43,R7,i1525,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,convert-filem10,R0,L1,V3,R36,R44,R45,R6,s179,The forms of one Go file of the dump: {:name :forms [...] :comments {line [text]}\n  :unplaced [...]} (forms in order: in-ns, go/file, declarations and free-standing\n  directives).R7,i1533,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,init-orderm8,R0,L1,V1,R36,R7,i1678,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert10,munge-namem10,R39,TR0,L1,V1,R21,R7,i1690,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert12,package-formm8,R0,L1,V2,R36,m2,R4,V1,R46,R7,i1692,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert9,file-stemm10,R0,L1,V2,R37,R47,R6,s198,The .ae path stem of Go file name in package directory dir (a Go source directory): x for\n  x.go, or x.go when dir has a subdirectory x (a package of that name would own x.ae:\n  proposed amendment).R7,i1716,R8,i1,R9,s25,arbace/repr/go/convert.aev22,arbace.repr.go.convert15,convert-packagem10,R0,L1,V2,R36,R11,R6,s380,Converts a dump. opts: :positions (:lines or :full), :ns (the namespace symbol, default from\n  the import path), :namespaces ({path ns-sym} of other packages whose namespace is not their\n  path's: a directory test's), :src-dir (the package's source directory, for file-name\n  collisions).\n  Returns {:ns sym :package form :files [{:name :stem :forms :comments :unplaced}] :stats}.R7,i1726,R8,i1,R9,s25,arbace/repr/go/convert.ae")

var Lit_321 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmts_forms")

var Lit_322 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt_list")

var Lit_323 *jrt.String = jrt.Intern("arbace.repr.go.convert$block_forms")

var Lit_324 *jrt.String = jrt.Intern("arbace.repr.go.convert$branch")

var Lit_325 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_vec")

var Lit_326 *jrt.String = jrt.Intern("arbace.repr.go.convert$if_form")

var Lit_327 *jrt.String = jrt.Intern("arbace.repr.go.convert$clause_bound")

var Lit_328 *jrt.String = jrt.Intern("arbace.repr.go.convert$case_clause")

var Lit_329 *jrt.String = jrt.Intern("arbace.repr.go.convert$clauses")

var Lit_330 *jrt.String = jrt.Intern("arbace.repr.go.convert$comm_clause")

var Lit_331 *jrt.String = jrt.Intern("arbace.repr.go.convert$assign")

var Lit_332 *jrt.String = jrt.Intern("arbace.repr.go.convert$simple_stmt")

var Lit_333 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt")

var Lit_334 *jrt.String = jrt.Intern("arbace.repr.go.convert$stmt_STAR_")

var Lit_335 *jrt.String = jrt.Intern("arbace.repr.go.convert$fn_sig_forms")

var Lit_336 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_name")

var Lit_337 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_args")

var Lit_338 *jrt.String = jrt.Intern("arbace.repr.go.convert$attachable_QMARK_")

var Lit_339 *jrt.String = jrt.Intern("arbace.repr.go.convert$directive_meta")

var Lit_340 *jrt.String = jrt.Intern("arbace.repr.go.convert$free_directive")

var Lit_341 *jrt.String = jrt.Intern("arbace.repr.go.convert$generic_decl_QMARK_")

var Lit_342 *jrt.String = jrt.Intern("arbace.repr.go.convert$func_decl")

var Lit_343 *jrt.String = jrt.Intern("arbace.repr.go.convert$value_spec_target")

var Lit_344 *jrt.String = jrt.Intern("arbace.repr.go.convert$gen_decl")

var Lit_345 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_directives")

var Lit_346 *jrt.String = jrt.Intern("arbace.repr.go.convert$decl_name")

var Lit_347 *jrt.String = jrt.Intern("arbace.repr.go.convert$imports_of")

var Lit_348 *jrt.String = jrt.Intern("arbace.repr.go.convert$whitespace_QMARK_")

var Lit_349 *jrt.String = jrt.Intern("arbace.repr.go.convert$source_text")

var Lit_350 *jrt.String = jrt.Intern("arbace.repr.go.convert$basic_lit_extents")

var Lit_351 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_file")

var Lit_352 *jrt.String = jrt.Intern("arbace.repr.go.convert$init_order")

var Lit_353 *jrt.String = jrt.Intern("arbace.repr.go.convert$munge_name")

var Lit_354 *jrt.String = jrt.Intern("arbace.repr.go.convert$package_form")

var Lit_355 *jrt.String = jrt.Intern("arbace.repr.go.convert$file_stem")

var Lit_356 *jrt.String = jrt.Intern("arbace.repr.go.convert$convert_package")
