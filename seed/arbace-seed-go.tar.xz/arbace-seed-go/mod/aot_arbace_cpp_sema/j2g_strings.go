//line j2g_strings.ae:1
package aot_arbace_cpp_sema

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn14,arbace.cpp.abikn2,asyn3,abiyn21,arbace.repr.cpp.scopeyn21,arbace.repr.cpp.typesyn2,ctyn13,arbace.stringyn3,stryn11,arbace.corekn3,docks3,cpp7,timeoutkn4,kindkn5,nameskn6,parentkn6,usingskn4,pathkn2,nskn3,poskn5,classkn3,clskn1,ekn5,scopekn9,dependentkn5,baseskn1,kkn2,idkn6,opaquekn4,namekn6,fieldskn5,outerkn7,va-listkn4,uintkn8,completekn2,tykn6,accesskn6,publickn1,ikn1,tkn4,elabkn1,skn11,header-typekn1,pkn2,ofkn1,bkn1,wkn1,nkn3,entkn6,targetkn3,tagkn4,elsekn1,ckn1,vkn2,kwkn3,varkn5,clinkkn4,tmplkn2,fnkn2,qtkn7,linkagekn11,param-nameskn8,defaultskn6,headerkn8,noexceptkn8,noreturnkn4,typekn3,retkn2,pskn2,vakn7,storagekn6,globalkn7,definedkn6,externkn3,ovlkn15,header-overloadkn7,builtinkn4,tdepkn8,pack-expkn8,tparam-vkn5,texprkn5,tspeckn6,tparamkn3,ttpkn3,tidkn1,xkn4,failkn4,whatkn3,valkn3,intkn4,nttpkn8,qualTypekn13,valueCategorykn5,innerkn20,explicitTemplateArgskn9,qualifierkn8,implicitkn3,memkn5,targskn5,arrowkn7,isArrowkn4,basekn6,memberkn14,referencedDeclkn2,opkn4,codekn4,argskn3,rawkn5,valuekn4,castkn9,constructkn4,listkn6,opcodekn7,argTypekn4,tyopkn3,litkn4,callkn1,fkn5,_thiskn15,globalQualifierkn1,qkn3,fpikn2,fpkn3,tpvkn2,szkn7,staticsks7,codegen7,refusedkn18,dependent-decltypekn7,fn-typekn2,dtkn5,fnsetkn3,objkn5,tmplskn3,fnskn2,lvkn3,catkn2,xvkn8,decltypeyn4,autokn4,autoyn13,decltype-autoyn17,__builtin_va_listkn14,dependent-nameyn2,fnkn8,is-traitkn10,trait-typeyn1,&yn4,voidyn11,pack-expandkn11,pack-expandkn4,packyn2,&&yn7,complexkn7,complexyn1,*yn8,decltypeys3,cpp4,textys3,cpp6,globalyn5,arraykn11,const-boundys3,cpp10,attributedyn8,typenameyn10,member-ptrkn5,constkn2,cqkn8,volatilekn2,vqks3,cpp3,refkn4,refqkn2,&&kn4,mptrkn2,toyn5,constys3,cpp10,elaboratedyn2,<>kn11,template-idkn8,templateys3,cpp5,scopeyn8,templateyn8,volatilekn2,inyn8,restrictkn4,ctadkn5,aliaskn2,tkkn3,depkn10,ctad-errorks2,cx4,nodekn6,offsetkn12,expansionLockn4,filekn5,rangekn5,beginkn3,endkn6,tokLenkn3,lockn3,_wnkn6,lookupkn4,_argkn4,_gnukn5,scharkn5,ucharkn5,shortkn6,ushortkn4,longkn5,ulongkn4,enumkn4,i128kn4,u128kn8,extern-ckn4,anonkn8,internalkn4,ctorkn4,dtorkn10,trait-textkn8,finishedkn14,trailing-deferkn5,blockkn5,paramkn22,trailingRequiresClausekn4,convkn6,methodkn25,isExplicitObjectParameterkn4,rrefkn6,statickn12,storageClasskn7,virtualkn4,purekn9,constexprkn10,_constevalkn9,constevalkn13,always-inlinekn4,usedkn9,ctor-attrkn14,noexcept-falsekn3,cppkn10,internal-lkn6,inlinekn19,explicitlyDefaultedkn8,explicitkn9,defaultedkn7,deletedkn17,explicitlyDeletedkn2,_bkn3,srckn4,xobjkn8,abi-tagskn12,deleted-surekn19,out-of-line-defaultkn4,bodykn4,nodekn9,def-scopekn5,initskn4,lazykn5,ctorskn8,virtualskn7,methodskn5,_ctadkn9,cx-globalkn13,member-statickn4,initkn10,init-stylekn9,ctad-initkn13,init-prioritykn3,tlskn8,tls-kindkn9,constinitkn10,_constinitkn12,cx-constexprkn8,cx-rangekn12,cx-type-textkn7,cx-declkn11,pending-defkn8,linkoncekn13,scopedEnumTagkn19,fixedUnderlyingTypekn5,underkn6,scopedkn6,nonnegkn10,enumeratorkn18,completeDefinitionkn7,tparamskn5,mnamekn5,unionkn7,tagUsedkn8,definingkn15,isPackExpansionkn11,pack-scopeskn9,isVirtualkn13,writtenAccesskn9,dep-baseskn10,align-attrkn7,privatekn10,incompletekn8,cx-errorkn10,isBitfieldkn21,hasInClassInitializerkn5,fieldkn4,bitskn4,_stdkn3,nuakn8,indirectkn5,chainkn11,has-friendskn10,friend-fnskn14,friend-classeskn18,friend-class-nameskn14,friend-unknownkn15,class-completedks7,codegen12,not-constantkn12,not-constantkn10,isImplicitkn15,isParameterPackkn3,_tckn7,_tcargskn7,_tctextkn12,_abbreviatedkn2,_ekn7,declarekn7,sassertkn4,declkn4,uclskn7,uaccesskn5,_textkn14,inherits-ctorskn7,typedefkn12,pack-elementkn8,languagekn8,isInlinekn3,refkn7,trivialkn11,deleted-whykn7,cx-movekn9,user-ctorkn9,user-dtorkn16,user-copy-assignkn6,vtablekn3,ptrkn6,layoutkn4,cintkn4,landkn1,lkn1,rkn3,icekn3,lorkn4,loadkn4,unopkn1,okn3,cmpkn2,ctkn3,notkn5,binopkn4,condkn4,thenks2,cx4,sureks2,cx2,atkn5,cx-atks15,arbace.cpp.sema4,baseks15,arbace.cpp.sema1,iks15,arbace.cpp.sema4,cellks15,arbace.cpp.sema4,pathkn4,boolkn5,floatkn6,assignkn8,temp-objkn8,ptr->intkn8,int->ptrkn2,ckkn7,int->fpkn7,fp->intkn5,commakn4,noopkn7,to-boolkn4,thisks15,arbace.cpp.sema4,thiskn7,ptrdiffks15,arbace.cpp.sema3,retkn5,tbodykn5,derefkn6,ptraddkn5,decaykn4,tempkn7,base-lvkn9,init-nodekn5,tinstkn6,lambdakn12,static-localkn5,localkn3,strkn7,cassignkn6,incdeckn4,postkn4,addrkn8,zero-valkn4,zeroks15,arbace.cpp.sema6,ce-altkn7,refusedkn6,normalkn2,dokn5,breakkn8,continuekn2,ifkn4,nullkn4,flatkn5,itemskn4,nonekn4,exprks15,arbace.cpp.sema5,emptykn4,fillkn6,returnkn6,void-ekn5,whilekn3,forkn3,incks15,arbace.cpp.sema3,clskn6,paramskn6,tinitskn8,delegatekn9,zero-thenkn9,bind-tempkn11,fields-usedkn8,agg-thiskn4,copykn4,bindkn2,prkn5,foldskn12,fnaddr-specskn7,mptr-fnkn6,fnaddrkn10,mptr-fnsetkn5,char8kn4,charkn6,char16kn8,float128kn7,ldoublekn6,doublekn7,float16kn7,nullptrkn10,conversionkn4,voidkn8,mptr-adjkn3,offkn7,derivedkn10,conv-tmplskn15,conv-candidateskn9,glam-convkn6,base-fkn10,glam-convskn9,glam-speckn6,invokekn4,tsigkn10,mangle-retkn3,fidkn9,ambiguousks15,arbace.cpp.sema4,nonekn15,ctor-candidateskn9,list-ctorkn9,init-listkn4,rankkn3,subkn3,cvqkn8,tiebreakkn10,sure-dropskn12,unsure-dropskn8,overloadys19,arbace.cpp.template7,sym-sigys19,arbace.cpp.template4,tmplkn6,noconvkn5,va-tykn7,varargskn13,std-init-listkn4,elemkn5,fn-idkn7,recordskn9,protectedkn6,directkn10,inheritingkn8,inh-fromkn8,inh-basekn8,inh-nameks15,arbace.cpp.sema9,inheritedkn12,default-initkn10,value-initkn6,char32kn5,wcharkn6,stringkn9,this-typekn5,llongkn6,ullongkn5,unitskn7,mutablekn9,declconstkn7,bindingkn7,conceptkn10,concept-idkn12,var-templatekn13,implicit-thiskn7,cx-qclskn13,member-accesskn5,cx-nckn6,cx-objkn8,cx-usingkn8,capfieldkn10,targs-textkn11,targs-scopekn8,operatorkn4,cmp3kn6,mboundkn1,mkn3,ftykn6,mfieldkn10,derived-lvkn14,reinterpret-lvkn9,qualifiedkn9,analyzingkn8,analyzedkn12,cx-imm-errorkn3,arrkn10,friend-clskn7,nomatchkn3,adlkn6,undeclkn3,rmwkn5,fencekn6,sfencekn6,atomickn5,whichkn2,ockn3,taskn5,clearkn2,epkn2,vpkn2,fokn2,rpkn2,vtkn3,fockn2,wckn7,cmpxchgkn4,xchgkn15,call-candidateskn5,mcallkn5,icallkn6,calleekn4,sizekn5,alignkn3,symkn3,newkn6,placeskn8,void-ptrkn5,placekn5,allockn7,deallockn8,reservedkn7,isArraykn9,initStylekn11,isPlacementkn8,isGlobalkn7,defaultkn9,placementkn6,cookiekn2,etkn11,expand-packkn4,capskn4,enclkn6,sealedkn7,capturekn5,_glamkn14,generic-lambdakn10,dollar-keykn4,nrvokn6,dollarkn5,_foldkn4,_invkn8,_invpackkn4,glamkn11,glam-cutoffkn11,list-directkn6,xvaluekn16,isArrayAsWrittenkn6,deletekn5,arraykn7,dyncastkn4,fromkn4,hintkn4,rttikn7,typeArgkn6,typeidkn7,_atomickn5,_argskn4,foldkn5,rightkn4,leftkn4,_retkn15,type-constraintkn9,_noexceptkn9,_offsetofkn6,_vaargkn7,_vatypekn6,va-argkn5,elemskn3,idskn7,varpackkn5,throwkn3,etykn9,stmt-exprkn5,bswapkn5,bitopkn2,fbkn8,isfinitekn7,signbitkn6,expectkn6,va-endkn7,va-copykn10,constant-pkn8,va-startkn13,clear-paddingkn12,sub-overflowkn12,add-overflowkn12,mul-overflowkn9,addressofkn6,allocakn9,lock-freekn21,is-constant-evaluatedkn9,ccompoundkn4,_udlkn6,suffixkn3,chrkn11,bind-opaquekn5,traitkn9,mptr-datakn9,isPostfixkn5,cpartkn4,partkn9,list-copykn3,errkn6,decompkn4,disckn5,sinitkn12,constexpr-ifkn5,labelkn9,range-forkn17,instantiate-classkn4,casekn4,stmtkn4,_asmkn7,outputskn6,labelskn4,gotokn6,inputskn8,clobberskn3,asmkn3,inskn6,hasVarkn3,trykn8,handlerskn7,exn-objkn7,exn-ptrkn7,hasInitkn6,switchkn8,nrvo-varkn11,isConstevalkn18,isNegatedConstevalkn11,isConstexprkn7,hasElsekn8,baseInitkn14,delegatingInitkn7,anyInitkn3,idxkn9,pre-initskn6,vbaseskn14,keep-def-scopekn11,param-packskn3,ordkn7,tassignkn10,copy-byteskn3,dstkn2,_tkn4,_entkn17,explicit-inst-defkn5,nodesys22,arbace.repr.cpp.native10,parse-filekn4,varskn5,orderkn7,classeskn5,enumskn4,rootkn4,wrapkn5,ginitkn8,cx-sinitkn7,pendingv11,arbace.core7,requireV3,R0,R1,R2,V1,R3,V3,R4,R1,R5,V3,R6,R1,R7,v11,arbace.core5,referR8,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.cpp.semam2,R9,s1344,The code generator's semantic analysis (doc/cpp/CODEGEN.md §3): the native parser's tree (clang's AST as data,\n  arbace.repr.cpp.native) analyzed as clang's Sema analyzes it for the slice of C++ CODEGEN.md §6 names -- the\n  declarations entered into scopes (namespaces, classes, blocks), every expression typed with its value category and\n  its implicit conversions written out (lvalue-to-rvalue, promotions, the usual arithmetic conversions, decay, the\n  pointer conversions, derived-to-base), names looked up as [basic.lookup] says (unqualified, qualified, class members\n  through the bases, the operators' ADL in the classes' namespaces), overload resolution by the implicit conversion\n  sequences' ranks ([over.match.best], [over.ics.rank]: exact, promotion, conversion, user-defined, ellipsis, with the\n  reference bindings' qualification tie-break), initialization ([dcl.init]: default, value, copy, direct, list and\n  aggregate initialization, reference binding with temporaries materialized), the implicit special members\n  ([class.default.ctor], [class.copy.ctor], [class.dtor]: declared, trivial or defined), virtual functions and their\n  overriders. The result is a program of typed functions and variables that arbace.cpp.codegen writes as LLVM forms.\n  Anything outside the slice is refused: (ex-info ... {:codegen/refused class}).v11,arbace.core5,some?v15,arbace.cpp.sema12,*on-refusal*v15,arbace.cpp.sema10,*deadline*v11,arbace.core7,ex-infom2,R10,Tv11,arbace.core7,re-findp23,\\+\\+(\\d\\d|[0-9a-z]{2})$v11,arbace.core3,strv11,arbace.core10,re-matchesp4,\\d\\dv11,arbace.core5,swap!v15,arbace.cpp.sema5,*ids*v11,arbace.core3,incv15,arbace.cpp.sema5,*fns*v15,arbace.cpp.sema6,*vars*v11,arbace.core5,applyv11,arbace.core6,updatev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core5,mergeR11,R12,R13,R14,R15,v13,arbace.string7,replacep39,\\\\u([0-9A-Fa-f]{4})|\\\\U([0-9A-Fa-f]{8})v15,arbace.cpp.sema8,ucn-nameR16,v11,arbace.core7,filtervR17,l-1,v15,arbace.cpp.sema8,*cutoff*v11,arbace.core6,concatv11,arbace.core5,doallv11,arbace.core6,mapcatv15,arbace.cpp.sema9,own-namesR18,v11,arbace.core3,mapv11,arbace.core6,secondv15,arbace.cpp.sema12,class-lookupR19,v15,arbace.cpp.sema9,find-herev15,arbace.cpp.sema15,header-entitiesv15,arbace.cpp.sema16,builtin-entitiesv11,arbace.core19,pop-thread-bindingsv11,arbace.core7,printlnv11,arbace.core6,pr-strv11,arbace.core11,select-keysV2,R20,R17,V2,R20,R17,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v14,arbace.cpp.abi3,clsR21,v11,arbace.core4,mapvv11,arbace.core4,keepv11,arbace.core6,removeR22,R23,v11,arbace.core8,not-any?v14,arbace.cpp.abi13,derived-from?v11,arbace.core6,ffirstv11,arbace.core6,filterv15,arbace.cpp.sema14,*header-cache*v15,arbace.cpp.sema7,next-idR24,R25,R26,v14,arbace.cpp.abi9,*classes*v11,arbace.core5,assocR27,v15,arbace.cpp.sema9,new-scopev15,arbace.cpp.sema6,*root*R28,R29,V1,R30,v14,arbace.cpp.abi1,bR31,v14,arbace.cpp.abi3,ptrv14,arbace.cpp.abi4,voidR32,v11,arbace.core3,vecv11,arbace.core11,map-indexedR33,R34,R35,R36,v15,arbace.cpp.sema13,finish-class!V1,R30,R37,R38,S3,s5,classs5,unions6,structv15,arbace.cpp.sema12,opaque-classR39,v15,arbace.cpp.sema4,failR40,R41,v15,arbace.cpp.sema11,ptype->typeR42,R43,v15,arbace.cpp.sema17,resolve-type-formv21,arbace.repr.cpp.types14,builtin-symbolR44,R45,R46,R47,R48,S3,s5,classs5,unions6,structR49,v11,arbace.core6,dissocR50,R51,R52,V1,s15,__builtin_abortv15,arbace.cpp.sema7,*proot*v21,arbace.repr.cpp.scope6,lookupv21,arbace.repr.cpp.scope7,find-inv11,arbace.core6,empty?R53,R54,v11,arbace.core3,notR55,R56,R57,v15,arbace.cpp.sema12,resolve-typeR58,R59,R60,R61,R62,v15,arbace.cpp.sema12,nothrow-libcR63,v11,arbace.core9,contains?S4,s10,quick_exits5,_Exits4,exits5,abortR64,R65,R66,R67,R20,R68,R69,R70,R71,R72,R73,v11,arbace.core4,lastv15,arbace.cpp.sema11,builtin-fnsR74,v11,arbace.core4,not=S2,s4,exits5,abortv11,arbace.core9,namespacev13,arbace.string5,splitp1,/v11,arbace.core4,namev11,arbace.core4,map?S6,R75,R76,R77,R78,R79,R80,v11,arbace.core4,somev15,arbace.cpp.sema13,dt-dependent?v11,arbace.core4,valsv11,arbace.core11,sequential?S3,R77,R81,R80,R82,v11,arbace.core4,intov15,arbace.cpp.sema8,dt-stripv11,arbace.core7,vector?R83,R84,R85,v13,arbace.string4,trimp3,\\d+R86,R87,p12,[A-Za-z_]\\w*v15,arbace.cpp.sema6,lookupR88,R77,v15,arbace.cpp.sema7,dt-typev11,arbace.core6,get-inV2,R64,R89,R90,v15,arbace.cpp.sema5,dt-irR91,R92,v15,arbace.cpp.sema7,dt-targv13,arbace.string12,starts-with?R93,m4,R83,R84,R85,s18,a qualified memberR94,R95,R96,R97,R98,R99,R100,V2,R101,R27,R102,R103,R104,R105,R106,v15,arbace.cpp.sema8,dt-castsR107,v15,arbace.cpp.sema15,dt-written-typeR108,R109,v15,arbace.cpp.sema9,dt-binopsR110,v15,arbace.cpp.sema8,dt-unopsm4,R83,R105,R39,s4,LDnEm4,R83,R105,R39,s3,fpTm8,s6,sizeofV2,s2,sts2,szs7,alignofV2,s2,ats2,azs8,_AlignofV2,s2,ats2,azs9,__alignofV2,s2,ats2,azR111,R112,V2,R111,R89,p3,\\d+R113,V2,R64,R89,R114,R115,v11,arbace.core4,restV2,R101,R27,R116,R117,m4,R83,R84,R85,s19,a ::-qualified namev15,arbace.cpp.sema11,type-entityv14,arbace.cpp.abi3,unqR80,p18,\\s*[A-Za-z_]\\w*\\s*R118,v15,arbace.cpp.sema4,var*R119,R120,R121,m4,R83,R84,R85,s11,a subscriptR122,m4,R83,R84,R85,s9,sizeof...V2,R101,R27,m4,R83,R84,R85,s19,a ::-qualified namev15,arbace.cpp.sema11,*decltypes*p3,\\s+v15,arbace.cpp.sema17,*decltype-failed*v15,arbace.cpp.sema7,analyzeR123,v11,arbace.core4,atomR124,v11,arbace.core7,ex-dataR125,v11,arbace.core6,reset!R126,S2,s20,UnresolvedLookupExprs11,DeclRefExprV2,R101,R27,v11,arbace.core8,tree-seqR75,m8,R24,R80,R36,l-1,R82,l-1,R27,s8,decltypeR127,R128,R129,R130,v11,arbace.core8,distinctR131,v15,arbace.cpp.sema3,fndS2,s11,DeclRefExprs10,MemberExprR132,R133,v14,arbace.cpp.abi4,lrefR134,v14,arbace.cpp.abi4,rrefR135,v11,arbace.core7,symbol?v15,arbace.cpp.sema12,builtin-symsR136,m2,R24,R137,R138,m4,R24,R137,R135,TR139,v14,arbace.cpp.abi3,arrl1,v15,arbace.cpp.sema11,va-list-tagv15,arbace.cpp.sema10,name-partsR140,v15,arbace.cpp.sema5,hooksv15,arbace.cpp.sema16,lookup-qualifiedv11,arbace.core4,seq?R141,R142,R143,S1,R144,S1,R144,V1,R145,v14,arbace.cpp.abi4,arr?v14,arbace.cpp.abi3,fn?R146,R147,R148,R149,v14,arbace.cpp.abi4,ref?R150,R151,R152,R153,R154,v14,arbace.cpp.abi9,nullptr-tp19,^(sizeof|alignof)\\bv14,arbace.cpp.abi6,ulong*v15,arbace.cpp.sema11,decltype-ofR155,R156,v11,arbace.core7,number?R157,R158,R159,R160,R161,R162,v15,arbace.cpp.sema9,checking?R163,R164,R165,R166,R167,R168,R169,R170,R144,R171,R172,R173,R174,R175,R176,R175,v11,arbace.core5,nnextS3,R75,R79,R80,R172,v11,arbace.core4,consv14,arbace.cpp.abi6,class?R172,v14,arbace.cpp.abi6,cls-ofR177,v11,arbace.core4,listR172,R178,R179,v13,arbace.string9,includes?c40,c41,v11,arbace.core4,subsl0,v15,arbace.cpp.sema16,strip-type-attrsp51,\\((unnamed|anonymous) (union|struct|class|enum) at v15,arbace.cpp.sema11,*last-anon*p7,^const v21,arbace.repr.cpp.types10,parse-typep18,vector_size__\\s*\\(v11,arbace.core7,string?R180,S2,R177,R170,R175,v11,arbace.core7,butlastS2,R181,R18,R182,R136,S2,R181,R18,R172,S3,R177,R172,R170,v15,arbace.cpp.sema13,ctad-templatev15,arbace.cpp.sema14,ctad-compound!m4,R24,R183,R27,s18,<deduction failed>R184,R185,p18,\\)\\s*const(\\s|$|&)p34,\\)\\s*(?:const\\s*)?volatile(\\s|$|&)p48,\\)\\s*(?:const\\s*)?(?:volatile\\s*)?(&&|&)(?:\\s|$)R186,R187,c34,c39,c47,c42,c92,c10,c32,v15,arbace.cpp.sema10,*main-dir*v15,arbace.cpp.sema11,*main-name*v13,arbace.string10,ends-with?v15,arbace.cpp.sema5,*src*v15,arbace.cpp.sema12,located-filev15,arbace.cpp.sema10,file-textsv15,arbace.cpp.sema14,blank-commentsR188,v15,arbace.cpp.sema6,loc-ofV2,R189,R190,V2,R189,R190,V2,R189,R191,R192,v15,arbace.cpp.sema7,text-ofV2,R189,R191,p41,(?m)^[ \\t]*#(?:[^\\n]*\\\\\\n)*[^\\n]*(?:\\n|$)V2,R189,R190,R193,v15,arbace.cpp.sema16,strip-directivesV2,R189,R190,p45,((?:[A-Za-z_][A-Za-z_0-9]*\\s*::\\s*)+)(~\\s*)?$v13,arbace.string6,blank?p2,::v15,arbace.cpp.sema16,text-before-namep5,~\\s*$c62,c60,p28,([A-Za-z_][A-Za-z_0-9]*)\\s*$p28,([A-Za-z_][A-Za-z_0-9]*)\\s*$p3,\\s+S2,c40,c60,S2,c41,c62,c58,R194,v15,arbace.cpp.sema9,node-textv15,arbace.cpp.sema11,split-scopev13,arbace.string4,joinp27,(?s)\\s*decltype\\s*\\(.*\\)\\s*v14,arbace.cpp.abi7,non-refp29,(?s)\\s*decltype\\s*\\((.*)\\)\\s*S2,R16,R64,v14,arbace.cpp.abi5,enum?v14,arbace.cpp.abi3,enmR195,S2,s10,CXXTryStmts12,CompoundStmtv15,arbace.cpp.sema4,kidsR196,v11,arbace.core10,parse-longR197,S2,s4,modes8,__mode__p7,^__|__$v15,arbace.cpp.sema9,mode-bitsv14,arbace.cpp.abi7,signed?R198,R199,R200,R201,R202,R203,V2,R50,R51,v14,arbace.cpp.abi9,integral?R204,R205,R206,R207,V1,R208,R209,v15,arbace.cpp.sema6,enter!l8,v15,arbace.cpp.sema9,same-sig?R210,R211,v11,arbace.core10,re-matcherp12,\\bnoexcept\\bp17,\\bthrow\\s*\\(\\s*\\)p3,\\s+p3,\\s+v15,arbace.cpp.sema6,ce-tryv15,arbace.cpp.sema2,rvR212,v15,arbace.cpp.sema18,*constraint-doubt*v15,arbace.cpp.sema4,*at*v15,arbace.cpp.sema9,const-intv15,arbace.cpp.sema18,*constraint-depth*v15,arbace.cpp.sema18,*constraint-stack*v15,arbace.cpp.sema6,doubt!S2,s13,always_inlines17,__always_inline__S2,s8,noreturns12,__noreturn__p37,^\\s*\\[\\[\\s*(?:std\\s*::\\s*)?noreturn\\bp70,(?s)^\\s*(?:inline\\s+|constexpr\\s+)*explicit(?![A-Za-z0-9_$])\\s*(\\(.*)?v11,arbace.core3,decR213,v11,arbace.core5,coll?R214,v15,arbace.cpp.sema21,constraint-satisfied?V2,R64,R89,R215,v11,arbace.core6,vectorv15,arbace.cpp.sema11,param-nodesv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstV2,R64,R89,R216,v11,arbace.core10,chunk-restV2,R64,R89,R217,v15,arbace.cpp.sema17,unfinished-targs?S5,s12,FunctionDecls17,CXXDestructorDecls13,CXXMethodDecls18,CXXConstructorDecls17,CXXConversionDeclv15,arbace.cpp.sema16,qualifier-beforev15,arbace.cpp.sema20,qualifier-tid-beforeS2,R16,R64,R218,R219,V2,R64,R89,v15,arbace.cpp.sema13,fn-type-scopev15,arbace.cpp.sema13,method-const?v15,arbace.cpp.sema7,body-ofR220,v11,arbace.core4,compR221,v15,arbace.cpp.sema11,method-refqv15,arbace.cpp.sema5,fn-opR222,R223,S4,s17,operator delete[]s15,operator deletes14,operator new[]s12,operator newR224,R225,R226,R227,R228,R229,v15,arbace.cpp.sema19,always-inline-node?v15,arbace.cpp.sema14,noreturn-node?R230,v15,arbace.cpp.sema12,gnu-attr-argR231,l65535,v15,arbace.cpp.sema11,noexcept-ofv15,arbace.cpp.sema10,linkage-c?S4,s10,quick_exits5,_Exits4,exits5,abortR232,p23,\\bnoexcept\\s*\\(\\s*falseR233,R234,R235,R236,R237,v15,arbace.cpp.sema13,explicit-specR238,R239,R240,R241,R242,v11,arbace.core9,not-emptyv11,arbace.core4,sortS2,s11,__abi_tag__s7,abi_tagv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core6,re-seqp12,\\\"([^\\\"]*)\\\"R243,R244,R245,v15,arbace.cpp.sema16,method-volatile?v15,arbace.cpp.sema15,*member-access*v15,arbace.cpp.sema11,find-redeclV2,R64,R89,V2,R64,R89,v15,arbace.cpp.sema7,upd-fn!V1,R59,v15,arbace.cpp.sema12,header-node?R246,R247,R248,R249,R250,R251,v15,arbace.cpp.sema11,declare-fn!R89,p10,^\\s*auto\\bm2,R251,Tv14,arbace.cpp.abi11,update-cls!R252,v11,arbace.core4,fnilR253,R254,v15,arbace.cpp.sema7,*order*V2,R64,R89,R255,v15,arbace.cpp.sema8,ctad-varR256,v15,arbace.cpp.sema17,ctad-compound-varv15,arbace.cpp.sema8,init-kidv14,arbace.cpp.abi7,scalar?S2,R16,R64,R257,R258,R259,R260,R261,R262,R263,R264,R265,R266,R267,R189,R268,V2,R64,R89,R269,v15,arbace.cpp.sema8,upd-var!R270,R271,v15,arbace.cpp.sema10,*cxx-year*R272,V2,R273,R89,v14,arbace.cpp.abi4,int*v14,arbace.cpp.abi7,*enums*R274,R275,V2,R273,R89,v11,arbace.core8,assoc-inR276,R277,R278,R279,S2,R16,R64,S2,s11,__abi_tag__s7,abi_tagp12,\\\"([^\\\"]*)\\\"R280,v14,arbace.cpp.abi11,source-nameR281,R282,R283,V2,R64,R89,R284,R285,R286,v11,arbace.core7,keywordS3,s7,privates9,protecteds6,publicR287,R288,S3,s7,privates9,protecteds6,publicp22,[A-Za-z_][A-Za-z_0-9]*S2,s11,__aligned__s7,alignedS2,s11,__aligned__s7,alignedR289,v11,arbace.core3,maxv14,arbace.cpp.abi8,align-ofR290,p46,\\((unnamed|anonymous) (union|struct|class) at V2,R64,R89,V2,R64,R89,R291,R292,V2,R64,R89,R293,R294,R295,v15,arbace.cpp.sema13,declare-node!v15,arbace.cpp.sema10,drop-countR296,R208,R297,R298,S2,R295,R299,S2,R295,R299,R299,R300,S2,R295,R299,S2,R295,R299,S4,s12,FunctionDecls20,FunctionTemplateDecls13,CXXMethodDecls18,CXXConstructorDeclR301,R302,V2,R64,R89,R303,R304,V2,R64,R89,p4,<.*$p29,^\\s*(?:class|struct|union)\\s+p2,::V2,R64,R89,R305,V2,R64,R89,V2,R64,R89,V2,R64,R89,S2,R295,R299,S2,R295,R299,S2,R295,R299,S2,R295,R299,S4,s12,FunctionDecls20,FunctionTemplateDecls13,CXXMethodDecls18,CXXConstructorDeclV2,R64,R89,V2,R64,R89,V2,R64,R89,R306,V2,R189,R190,v15,arbace.cpp.sema14,declare-node*!v15,arbace.cpp.sema12,*main-retry*S2,s11,TypedefDecls13,TypeAliasDeclv15,arbace.cpp.sema14,*header-drops*v15,arbace.cpp.sema8,drop-keyR307,R308,v15,arbace.cpp.sema7,*retry*p53,an incomplete class template|unknown type|header typeV3,R189,R190,R186,V2,R189,R190,p28,an incomplete class templatep8,\\bauto\\bp17,decltype\\s*\\(\\s*$c95,p18,(?:const|volatile)S4,s12,FunctionDecls13,CXXMethodDecls18,CXXConstructorDecls17,CXXConversionDeclV2,nnv15,arbace.cpp.sema17,placeholder-splitV2,R64,R89,V2,R64,R89,v13,arbace.string8,index-ofV2,R64,R89,V2,R64,R89,R309,p10,\\.\\.\\.\\s*$R310,R311,p7,\\s*<.*$p8,\\s*::\\s*R312,R313,V2,R64,R89,v11,arbace.core12,keep-indexedS3,s20,TemplateTypeParmDecls23,NonTypeTemplateParmDecls24,TemplateTemplateParmDeclv11,arbace.core4,takev11,arbace.core4,dropR314,R315,v15,arbace.cpp.sema20,abbreviated-templateR316,v15,arbace.cpp.sema13,declare-enum!p32,using\\s+enum\\s+([^;]+?)\\s*;?\\s*$R317,v15,arbace.cpp.sema14,declare-class!R318,R319,R320,R321,p37,using\\s+(?:typename\\s+)?([^;]+);?\\s*$p10,^\\s*\\.\\.\\.v15,arbace.cpp.sema10,text-afterl16,p2,::p22,[A-Za-z_][A-Za-z_0-9]*v15,arbace.cpp.sema10,cx-access!p4,<.*$R322,S2,R64,R277,S2,R64,R277,S2,R64,R277,S2,R64,R277,p25,namespace\\s+([^;]+);?\\s*$p2,::V2,R64,R89,R323,p22,^(struct|class|union) p76,^\\s*typedef\\s+(?:struct|class|union)\\s*(?:__attribute__\\s*\\(\\(.*?\\)\\)\\s*)?\\{p33,(?:enum|struct|union|class) (\\S+)v15,arbace.cpp.sema9,mode-typeR324,R325,p17,=\\s*([^;]+);?\\s*$p2,::S2,R64,R277,S2,R64,R277,S2,R64,R277,S2,R64,R277,V2,R64,R89,v15,arbace.cpp.sema9,ns-scope!R326,v15,arbace.cpp.sema12,declare-var!S2,R64,R277,S2,R64,R277,S2,R64,R277,S2,R64,R277,R327,R328,v14,arbace.cpp.abi8,dynamic?v11,arbace.core6,every?v15,arbace.cpp.sema10,copy-ctor?v15,arbace.cpp.sema13,trivial-copy?v15,arbace.cpp.sema18,class-like-membersv15,arbace.cpp.sema12,copy-assign?v15,arbace.cpp.sema12,move-assign?v15,arbace.cpp.sema15,trivial-assign?m2,R251,Tv15,arbace.cpp.sema13,trivial-dtor?v15,arbace.cpp.sema12,implicit-fn!v15,arbace.cpp.sema12,has-ctor-of?v15,arbace.cpp.sema10,move-ctor?m6,R239,TR245,TR329,s60,a user-declared move constructor or move assignment operatorR330,R331,R332,R333,v14,arbace.cpp.abi12,primary-baseR334,S3,R327,R221,R335,v14,arbace.cpp.abi9,base-pathv11,arbace.core6,reduceR336,v14,arbace.cpp.abi6,layoutS2,R219,R211,S2,R219,R211,v11,arbace.core8,integer?v11,arbace.core6,bigintr40,170141183460469231731687303715884105728Nr40,340282366920938463463374607431768211456Nv14,arbace.cpp.abi10,underlyingv15,arbace.cpp.sema5,wide?r21,18446744073709551616Nv15,arbace.cpp.sema11,wide-value?v15,arbace.cpp.sema12,not-constantv14,arbace.cpp.abi7,size-ofv11,arbace.core10,bigintegerv15,arbace.cpp.sema6,ce-numv11,arbace.core2,<=l127,R337,v15,arbace.cpp.sema9,*ce-wide*v15,arbace.cpp.sema10,narrow-outR338,R339,R340,R341,v15,arbace.cpp.sema7,ce-wrapv15,arbace.cpp.sema8,from-srcR342,v15,arbace.cpp.sema7,ce-evalR343,v15,arbace.cpp.sema13,var-const-intR344,S2,s1,~s1,-R345,R346,R347,R348,R349,S2,s1,%s1,/v15,arbace.cpp.sema3,ub!v15,arbace.cpp.sema10,wide-binopR350,R351,v15,arbace.cpp.sema13,*ce-manifest*v15,arbace.cpp.sema5,tick!R352,R353,R354,m2,R307,TR355,R356,v15,arbace.cpp.sema8,ce-elemsR357,R358,v15,arbace.cpp.sema7,ce-ptr?v14,arbace.cpp.abi4,ptr?R359,v14,arbace.cpp.abi2,bnv15,arbace.cpp.sema7,ce-loc?v14,arbace.cpp.abi9,floating?R360,v11,arbace.core6,float?v15,arbace.cpp.sema12,*ce-in-call*v15,arbace.cpp.sema9,*ce-fold*m4,R307,TR352,TR361,v15,arbace.cpp.sema5,ce-lvv15,arbace.cpp.sema10,ce-glvaluev15,arbace.cpp.sema7,ce-put!R362,v15,arbace.cpp.sema7,ce-initS2,R363,R364,v15,arbace.cpp.sema12,ce-top-sure!R365,R366,R367,R368,v15,arbace.cpp.sema10,*ce-steps*R369,R370,R371,R372,R373,v15,arbace.cpp.sema13,ce-same-base?v14,arbace.cpp.abi12,empty-class?v15,arbace.cpp.sema11,ce-args-envR374,v15,arbace.cpp.sema7,ce-execR375,v14,arbace.cpp.abi5,void?v15,arbace.cpp.sema8,ce-storeR376,R377,R378,v11,arbace.core1,<v15,arbace.cpp.sema6,ce-getS5,R379,R114,R295,R350,R380,R381,R382,R383,v15,arbace.cpp.sema11,analyze-fn!S4,R257,R69,R384,R385,R386,v15,arbace.cpp.sema9,str-unitsv11,arbace.core6,repeatv15,arbace.cpp.sema10,ce-ptr-addS2,s2,!=s2,==V2,l0,l0,V2,l0,l1,S2,s2,!=s2,==V2,l0,l1,S2,s2,!=s2,==V2,l0,l1,S2,s2,!=s2,==V2,l0,l1,R387,R388,v11,arbace.core1,+v11,arbace.core1,-R389,S2,s1,-s1,+R390,R391,m2,R36,R392,S7,s2,>>s1,*s1,%s1,/s1,-s2,<<s1,+v11,arbace.core1,*r2,1Nr2,2NR393,R394,V1,R395,R396,R397,V1,R395,V1,R395,R398,V1,R398,R399,V1,R395,R400,V1,R395,V1,R397,R401,R402,V1,R395,R392,R403,R404,R405,R406,S3,R392,R404,R403,R395,V1,R395,R407,R408,V2,R65,l0,V2,R65,l0,R409,V1,R395,V1,R395,R410,V1,R395,V1,R395,R411,v15,arbace.cpp.sema12,ce-base-pathR379,v15,arbace.cpp.sema11,ce-cell-locR380,S2,R134,R132,R412,v15,arbace.cpp.sema10,ce-zero-ofR413,R414,v14,arbace.cpp.abi11,vbases-initR415,R416,v15,arbace.cpp.sema12,ce-constructR417,R418,R419,R420,R421,R422,v15,arbace.cpp.sema12,wide-literalR423,S2,R134,R132,R424,R425,v15,arbace.cpp.sema11,fn-matchingR426,R427,v15,arbace.cpp.sema12,mptr-fn-nodeR385,v15,arbace.cpp.sema3,lv?v15,arbace.cpp.sema12,promote-typeS8,R200,R201,R428,R199,R359,R429,R198,R430,R431,R432,R433,v14,arbace.cpp.abi7,double*v14,arbace.cpp.abi6,float*R434,v14,arbace.cpp.abi9,int-ranksv14,arbace.cpp.abi11,unsigned-nsv15,arbace.cpp.sema11,unsigned-ofv14,arbace.cpp.abi6,arith?V3,R24,R45,R25,V3,R24,R45,R25,R435,R436,v14,arbace.cpp.abi5,mptr?v15,arbace.cpp.sema9,cast-nodeR437,v14,arbace.cpp.abi9,llvm-typev15,arbace.cpp.sema14,null-constant?R438,R439,v15,arbace.cpp.sema8,class-idR440,R364,R363,V3,R166,R162,R164,V3,R166,R162,R164,l2,v15,arbace.cpp.sema7,arr-unqv15,arbace.cpp.sema6,arr-cvv11,arbace.core3,setv15,arbace.cpp.sema8,conv-fnsR441,v15,arbace.cpp.sema10,conv-tmplsR442,R443,R444,R445,R446,v15,arbace.cpp.sema8,deduced!R137,R447,v15,arbace.cpp.sema11,method-callv15,arbace.cpp.sema8,var-nodev15,arbace.cpp.sema8,init-form2,R36,R403,R448,R449,v15,arbace.cpp.sema8,std-rankv11,arbace.core7,sort-byv15,arbace.cpp.sema10,glam-conv!v15,arbace.cpp.sema10,conv-specsR450,v11,arbace.core1,=R451,v15,arbace.cpp.sema17,*conv-tmpl-cache*R452,v15,arbace.cpp.sema14,init-list-elemv15,arbace.cpp.sema15,ctor-candidatesR453,v15,arbace.cpp.sema16,resolve-overloadp28,^codegen: no viable functionv11,arbace.core10,ex-messageR454,v11,arbace.core4,juxtR455,v15,arbace.cpp.sema3,icsR456,v15,arbace.cpp.sema10,aggregate?m2,R456,l3,v15,arbace.cpp.sema17,list-ctor-viable?m2,R456,l3,l9,R457,R458,v15,arbace.cpp.sema9,*no-user*v15,arbace.cpp.sema12,ref-conv-form2,R456,l3,m2,R456,l0,m2,R456,l2,v15,arbace.cpp.sema8,conv-form2,R456,l3,m2,R456,l3,m2,R456,l3,m2,R456,l0,v15,arbace.cpp.sema17,resolve-overload*v11,arbace.core9,take-lastv15,arbace.cpp.sema12,trailing-ok?m2,R456,l4,m4,R456,l0,R457,l-1,m4,R456,l0,R457,l1,m4,R456,l0,R457,l0,m4,R456,l0,R457,l0,m2,R456,l4,m4,R456,l0,R457,l-1,m4,R456,l0,R457,l1,m4,R456,l0,R457,l0,m4,R456,l0,R457,l0,R459,v11,arbace.core10,constantlyv11,arbace.core5,true?v15,arbace.cpp.sema11,better-ics?v15,arbace.cpp.sema7,*drops*R460,R461,R462,R76,v11,arbace.core17,requiring-resolveR463,R464,V2,R189,R190,R465,V2,R24,R45,v15,arbace.cpp.sema11,materializeR466,v15,arbace.cpp.sema14,convert-scalarR467,v11,arbace.core5,rangeV1,V2,R16,s3,stdR468,R469,R470,v15,arbace.cpp.sema20,cx-enclosing-classesR471,v15,arbace.cpp.sema13,cx-friend-of?R472,v15,arbace.cpp.sema8,cx-pathsv15,arbace.cpp.sema13,cx-member-ok?m6,R35,l0,R472,l1,R290,l2,S2,R290,R403,v15,arbace.cpp.sema10,cx-contextv11,arbace.core6,false?v15,arbace.cpp.sema13,cx-access-ok?S2,R290,R472,v15,arbace.cpp.sema15,cx-ctor-access!R473,v15,arbace.cpp.sema17,default-ctor-initv15,arbace.cpp.sema15,init-list-ctorsv15,arbace.cpp.sema13,std-init-listv15,arbace.cpp.sema9,call-argsv15,arbace.cpp.sema9,ctor-initv15,arbace.cpp.sema9,user-convp9,no viablev15,arbace.cpp.sema9,aggr-subsR474,R475,R476,R477,V3,R237,R62,R226,v15,arbace.cpp.sema16,inheriting-ctor!v15,arbace.cpp.sema16,inherit-through!p19,no viable|ambiguousR478,m2,R36,R403,m2,R36,R403,m2,R36,R403,m2,R36,R392,m2,R36,R403,S3,R479,R480,R455,v15,arbace.cpp.sema9,elide-aggv15,arbace.cpp.sema9,elide-subR480,v15,arbace.cpp.sema10,class-initm2,R36,R392,S2,R392,R403,m2,R36,R392,m2,R36,R403,v15,arbace.cpp.sema11,brace-elideS7,R428,R199,R481,R482,R429,R198,R430,R483,m2,R36,R392,R479,R484,m2,R36,R392,R485,v14,arbace.cpp.abi5,uint*R486,v14,arbace.cpp.abi5,char*v14,arbace.cpp.abi5,bool*v14,arbace.cpp.abi5,long*c120,p11,[0-9a-fA-F]c48,c97,c98,c102,c110,c114,c13,c116,c9,c118,p11,[0-9a-fA-F]S2,c85,c117,c117,R487,v15,arbace.cpp.sema13,capture-fieldv15,arbace.cpp.sema15,base-subobjectsv15,arbace.cpp.sema10,to-base-lvR488,R489,S2,R216,R385,v15,arbace.cpp.sema13,*unevaluated*v15,arbace.cpp.sema10,field-nodev15,arbace.cpp.sema6,cx-viav15,arbace.cpp.sema10,deref-nodev15,arbace.cpp.sema9,this-exprv15,arbace.cpp.sema15,cx-naming-classR101,V2,R101,R27,R490,v15,arbace.cpp.sema13,check-access!V2,R101,R27,R491,R492,R493,V2,R101,R27,m2,R24,R462,R494,R495,R496,R497,R498,R499,v15,arbace.cpp.sema12,cx-using-mapV2,R101,R27,m2,R24,R462,R500,v15,arbace.cpp.sema18,implicit-alloc-fnsV2,R101,R27,v15,arbace.cpp.sema13,ref-qualifierv15,arbace.cpp.sema11,entity-exprv15,arbace.cpp.sema13,written-targsR501,R502,v15,arbace.cpp.sema15,implicit-alloc!v15,arbace.cpp.sema12,arith-commonR503,R504,v15,arbace.cpp.sema13,ordering-typev15,arbace.cpp.sema11,arith-binopR505,R506,R507,m2,R24,R462,R508,v15,arbace.cpp.sema9,fold-markv15,arbace.cpp.sema7,to-boolm2,R24,R462,v15,arbace.cpp.sema9,three-wayv15,arbace.cpp.sema13,operator-callR335,S2,s2,>>s2,<<S2,s2,>>s2,<<R509,R510,v15,arbace.cpp.sema9,cast-exprp55,((?:[A-Za-z_][A-Za-z_0-9]*::)+)([A-Za-z_][A-Za-z_0-9]*)p2,::S2,R290,R472,v15,arbace.cpp.sema15,cx-type-friend?S2,R290,R472,p63,(?:const\\s+)?([A-Za-z_][\\w:]*<[^<>]*>)\\s*::\\s*([A-Za-z_]\\w*)\\s*S2,R290,R472,S2,R290,R472,v15,arbace.cpp.sema17,friend-may-grant?p104,(?:\\.|->)\\s*((?:[A-Za-z_][A-Za-z_0-9]*\\s*(?:<[^.]*>)?\\s*::\\s*)+)~?[A-Za-z_][A-Za-z_0-9]*\\s*(?:<.*>)?\\s*$v15,arbace.cpp.sema13,method-set-ofS2,R56,R55,m2,R24,R462,R511,p31,<[^<>]*(?:<[^<>]*>[^<>]*)*>\\s*$p33,(?:\\.|->)\\s*(?:template\\s+)?(.*)$p14,(?:\\.|->)\\s*::v15,arbace.cpp.sema9,has-auto?v15,arbace.cpp.sema21,defaulted-comparison!R512,R513,v15,arbace.cpp.sema18,cx-immediate-call!R514,v15,arbace.cpp.sema7,adl-nssv15,arbace.cpp.sema10,enum-assocS4,R327,R515,R221,R335,S4,R327,R515,R221,R335,R516,v15,arbace.cpp.sema11,adl-classesv15,arbace.cpp.sema15,friend-visible?v15,arbace.cpp.sema13,adl-class-nssS2,R56,R55,S5,s1,=s2,[]s2,->s1,,s2,()S2,R56,R55,v15,arbace.cpp.sema14,sure-assoc-nssv15,arbace.cpp.sema12,declared-in?R517,V3,R24,R45,R25,S2,R56,R55,R518,R519,R520,V2,R51,R345,V2,R51,R345,V8,s3,adds3,subs3,ands2,ors3,xors4,nands3,mins3,maxv15,arbace.cpp.sema12,atomic-formsS2,R521,R522,R523,R524,R525,S2,R526,R527,S1,R51,S2,l4,l8,S2,R526,R527,S4,l1,l4,l2,l8,R528,R529,R530,R531,R532,R533,R534,R535,R536,R526,R537,v15,arbace.cpp.sema7,adl-fnsV1,V2,R16,s3,stdv15,arbace.cpp.sema12,std-builtinsV1,V2,R16,s3,stdv15,arbace.cpp.sema7,fn-callR538,R539,R540,v15,arbace.cpp.sema14,adl-not-found!v15,arbace.cpp.sema16,undeclared-call!S4,s2,<=s2,>=s1,<s1,>v15,arbace.cpp.sema20,rewritten-relationalp26,ambiguous|deleted functionS4,s2,<=s2,>=s1,<s1,>v15,arbace.cpp.sema14,class-operand?v15,arbace.cpp.sema9,new-alignV2,s3,stds11,align_val_tv15,arbace.cpp.sema6,fn-idsv15,arbace.cpp.sema9,void-ptr?v15,arbace.cpp.sema7,size-t?v15,arbace.cpp.sema8,align-t?R541,R542,v15,arbace.cpp.sema18,usual-dealloc-infoV3,R56,R541,R542,R543,v15,arbace.cpp.sema12,alloc-lookupv15,arbace.cpp.sema15,resolve-deallocv15,arbace.cpp.sema16,implicit-deallocv15,arbace.cpp.sema12,overaligned?v15,arbace.cpp.sema14,global-deallocv15,arbace.cpp.sema11,align-val-tR544,R545,v11,arbace.core6,subvecV1,R546,R547,R548,R549,R550,v15,arbace.cpp.sema24,array-delete-wants-size?V2,R64,R89,R551,R552,R553,v15,arbace.cpp.sema12,analyze-argsv15,arbace.cpp.sema15,find-allocationR554,R555,R556,R557,v15,arbace.cpp.sema14,delete-deallocR558,S2,s13,ParenListExprs21,ImplicitValueInitExprR559,S4,c40,c91,c123,c60,S4,c41,c93,c125,c62,c44,c91,c93,R560,R561,R562,R563,v15,arbace.cpp.sema11,deduce-autom2,R24,R137,R564,v15,arbace.cpp.sema19,generic-lambda-exprv15,arbace.cpp.sema13,capture-introV3,R189,R190,R186,V3,R189,R190,R186,p14,\\)\\s*mutable\\bp8,\\bauto\\bV2,R64,R89,R565,V2,R64,R89,V2,R64,R89,p10,^auto\\s*\\(p14,->\\s*(.+?)\\s*$m2,R24,R137,v15,arbace.cpp.sema15,*lambda-counts*v14,arbace.cpp.abi13,mangle-paramsR566,v15,arbace.cpp.sema9,split-topS2,s1,=s1,&p2,^&V2,R371,R420,S2,s1,=s1,&V2,R371,R420,S2,s1,=s1,&S2,s1,=s1,&p46,(?s)(&?)\\s*([A-Za-z_][A-Za-z_0-9]*)\\s*=\\s*(.+)v15,arbace.cpp.sema13,init-capture!p2,^&v15,arbace.cpp.sema4,stmtV2,R33,R65,R567,v15,arbace.cpp.sema8,nrvo-varv15,arbace.cpp.sema17,analyze-implicit!R568,m2,R36,R403,R569,V2,R339,R340,S4,s24,UnaryExprOrTypeTraitExprs12,RequiresExprs14,SizeOfPackExprs15,CXXNoexceptExprv15,arbace.cpp.sema13,node-childrenV2,R101,R27,S4,s11,BindingDecls17,DecompositionDecls11,ParmVarDecls7,VarDeclS4,s11,BindingDecls17,DecompositionDecls11,ParmVarDecls7,VarDeclV3,R189,R190,R186,V3,R189,R190,R186,p14,\\)\\s*mutable\\bV2,R64,R89,p8,\\bauto\\bR570,R571,p10,\\.\\.\\.\\s*$V2,R64,R89,v13,arbace.string13,replace-firstp8,\\bauto\\bp22,\\bdecltype\\s*\\(\\s*autoV2,R64,R89,p14,->\\s*(.+?)\\s*$V2,R64,R89,R463,S2,s1,=s1,&p2,^&V2,R371,R420,S2,s1,=s1,&V2,R371,R420,S2,s1,=s1,&S2,s1,=s1,&p46,(?s)(&?)\\s*([A-Za-z_][A-Za-z_0-9]*)\\s*=\\s*(.+)p2,^&v15,arbace.cpp.sema13,glam-declaredv11,arbace.core4,keysv15,arbace.cpp.sema10,glam-namesS2,R216,R385,S2,R216,R385,R572,R573,R464,v15,arbace.cpp.sema9,cond-nodeR574,v15,arbace.cpp.sema12,analyze-nodeV2,R64,R89,v15,arbace.cpp.sema9,ctad-exprV2,R64,R89,S2,R575,s6,xvalueV2,R64,R89,v15,arbace.cpp.sema16,scalar-list-castV2,R64,R89,V2,R64,R89,S2,R575,s6,xvalueV2,R64,R89,V2,R189,R190,R576,R577,R578,V2,R64,R89,S2,R575,s6,xvalueR579,R580,R581,l-2,V2,s3,stds9,type_infoR582,V2,R583,R89,R584,R585,v15,arbace.cpp.sema11,atomic-exprR586,m6,R102,R480,R33,m2,R24,R480,R133,R422,V2,R64,R89,V2,R64,R89,v15,arbace.cpp.sema18,check-type-access!V2,R64,R89,p14,without a packS10,s2,-=s2,/=s2,%=s2,*=s2,|=s3,<<=s3,>>=s2,^=s2,&=s2,+=R587,R588,v11,arbace.core4,peekv11,arbace.core4,rseqv11,arbace.core3,popv15,arbace.cpp.sema8,new-exprR589,v15,arbace.cpp.sema11,member-exprV2,R101,R27,v15,arbace.cpp.sema9,name-exprv15,arbace.cpp.sema9,block-ctxV2,R64,R89,V2,R64,R89,p66,(?:typename\\s+)?(.+?)\\s*::\\s*(?:template\\s+)?[A-Za-z_]\\w*(?:<.*>)?V2,R64,R89,p53,^codegen: (\\* of a non-pointer|member of a non-class)R590,R591,R592,V2,R64,R89,p25,^\\s*__(is|has|reference)_V2,R64,R89,V2,R64,R89,S2,R575,s6,xvalueV2,R64,R89,R593,R594,R595,R596,R597,R598,V2,R64,R89,V2,R64,R89,V2,R64,R89,S2,R148,R599,m2,R24,R455,R600,R601,S7,R13,R33,R21,R248,R249,R14,R12,S7,R13,R33,R21,R248,R249,R14,R12,R602,v15,arbace.cpp.sema11,int-type-ofV2,R64,R89,V2,R64,R89,V2,R64,R89,V2,R64,R89,S2,R575,s6,xvalueV2,R64,R89,m4,s22,__builtin_operator_news12,operator news25,__builtin_operator_deletes15,operator deletev15,arbace.cpp.sema15,atomic-builtin?V2,R101,R27,V2,R101,R27,v15,arbace.cpp.sema14,value-builtinsS4,l1,l4,l2,l8,R603,R604,R605,R606,R607,R608,R609,R610,v15,arbace.cpp.sema12,analyze-callv15,arbace.cpp.sema11,assign-nodeS2,s2,.*s3,->*v15,arbace.cpp.sema12,no-operator!v15,arbace.cpp.sema13,builtin-binopv15,arbace.cpp.sema13,class->scalarV2,R101,R27,V2,R101,R27,R611,R612,R613,R614,m6,R615,s1,+R614,s1,-R616,s1,*R617,R616,m6,R615,s1,+R614,s1,-R616,s1,*R615,m6,R615,s1,+R614,s1,-R616,s1,*R618,R619,S4,l1,l4,l2,l8,R620,V2,R64,R89,S4,R428,R199,R429,R198,v15,arbace.cpp.sema13,decode-stringS3,R481,R482,R430,v15,arbace.cpp.sema10,wide-unitsv15,arbace.cpp.sema11,lambda-exprR621,v15,arbace.cpp.sema13,compound-nodem6,R102,R479,R33,m2,R24,R479,R133,R422,S4,s2,-=s2,/=s2,*=s2,+=R622,R623,R624,v15,arbace.cpp.sema10,opaque-idsR625,m2,R89,s11,long doublem2,R89,s13,unsigned longm2,R89,s18,unsigned long longV2,R111,R89,R626,V2,R64,R89,V2,R64,R89,S2,R575,s6,xvalueV2,R64,R89,V2,R101,R27,m2,R24,R462,R627,v14,arbace.cpp.abi12,field-offsetS2,s2,++s2,--R628,R629,R630,d0,V2,R64,R89,V2,R64,R89,r21,18446744073709551616NV2,R64,R89,V2,R64,R89,V2,R64,R89,V2,R20,R102,V3,R20,R20,R102,V3,R20,R20,R105,V3,R20,R20,R25,S2,R216,R385,R631,v15,arbace.cpp.sema9,ctad-initR632,p12,[A-Za-z_]\\w*m4,R24,R183,R27,s18,<deduction failed>R170,R177,V2,R64,R89,p12,[A-Za-z_]\\w*R384,S3,R327,R221,R335,S2,s4,lists4,callV2,R64,R89,S2,R384,R385,v15,arbace.cpp.sema10,local-var!R633,m2,R27,s5,valuem2,R27,s3,getm2,R27,s3,getm2,R89,s13,unsigned longm2,R89,s13,unsigned longV2,s3,stds10,tuple_sizeS2,R290,R472,S2,R290,R472,m2,R39,R400,m2,R39,R400,m2,R39,R400,v15,arbace.cpp.sema14,decomposition!m2,R39,R400,v15,arbace.cpp.sema17,cx-decomposition!m2,R39,R400,m2,R39,R400,v15,arbace.cpp.sema20,check-static-assert!m2,R39,R400,V2,R64,R89,v15,arbace.cpp.sema9,decl-initv15,arbace.cpp.sema18,cx-check-constant!S3,R87,R360,R400,m2,R39,R400,R634,R635,m2,R39,R400,m2,R39,R400,m2,R39,R400,m2,R39,R400,m2,R39,R400,m2,R39,R400,m2,R39,R400,m2,R39,R400,m2,R39,R400,V2,R64,R89,S3,R87,R360,R400,m2,R39,R400,m2,R39,R400,m2,R39,R400,v15,arbace.cpp.sema7,cond-ofV2,R189,R190,R636,m2,R39,R400,R637,R638,V2,s3,stds16,initializer_listR639,R640,v15,arbace.cpp.sema4,fullR641,v15,arbace.cpp.sema15,range-for-classR642,R643,R644,R645,p2,r+R646,S2,s6,memorys2,ccR647,R648,R649,R650,m2,R39,R400,m2,R39,R400,R651,R652,R653,R654,m2,R39,R398,R655,R656,m2,R39,R400,v15,arbace.cpp.sema9,decl-stmtp31,goto\\s+([A-Za-z_][A-Za-z_0-9]*)v15,arbace.cpp.sema12,p2266-xvalueS2,s11,DeclRefExprs10,MemberExprm2,R39,R407,S2,R216,R385,R657,p19,ambiguous|no viablem2,R39,R397,V2,R33,R65,R658,m2,R39,R400,R659,v11,arbace.core9,vary-metaV2,R101,R27,R660,v15,arbace.cpp.sema18,constexpr-if-valuep17,^not a constant: R661,m2,R39,R400,R662,R663,V2,R664,R27,V2,R664,R27,R665,R666,R667,m2,R36,R403,m2,R36,R403,V5,R402,R351,R49,R247,R652,S2,s9,ParenExprs16,ImplicitCastExprV2,R101,R27,S2,s2,++s2,--R668,V14,R25,R27,R11,R19,R33,R162,R102,R222,R58,R234,R209,R15,R382,R235,R669,R599,V2,R189,R190,v15,arbace.cpp.sema27,consteval-ctor-body-stores?S2,R210,R211,V2,R33,R65,v15,arbace.cpp.sema10,ctor-initsR670,v11,arbace.core7,reverseV2,R33,R65,S2,s3,<=>s2,==S5,s2,!=s2,<=s2,>=s1,<s1,>R671,R672,R673,v15,arbace.cpp.sema17,immediate-addressV2,R258,R36,V2,R258,R20,V6,R402,R351,R49,R247,R258,R39,v15,arbace.cpp.sema18,returned-immediateS4,s24,UnaryExprOrTypeTraitExprs15,CXXNoexceptExprs12,OffsetOfExprs13,TypeTraitExprR674,R675,v15,arbace.cpp.sema20,sassert-unsure-node?R676,S3,R87,R360,R400,v15,arbace.cpp.sema15,strip-positionsR677,R678,v11,arbace.core4,spitv15,arbace.cpp.sema16,prelude-typeinfoR679,R680,R681,R682,R683,R684,R685,v15,arbace.cpp.sema11,global-initp37,^codegen: no default constructor for p26,call to a deleted functionR686,v15,arbace.cpp.sema22,cx-static-member-init?m2,R36,R403,R687,p24,\\btypeid\\b|\\btype_info\\bv15,arbace.cpp.sema13,prelude-nodesv11,arbace.core10,split-withv15,arbace.cpp.sema15,*incomplete-ok*")

var Lit_1 *jrt.String = jrt.Intern("FunctionTemplateDecl")

var Lit_2 *jrt.String = jrt.Intern("arbace.cpp.sema$abbreviated_template$fn__916000659")

var Lit_3 *jrt.String = jrt.Intern("arbace.cpp.sema$abbreviated_template$fn__916000661")

var Lit_4 *jrt.String = jrt.Intern("(")

var Lit_5 *jrt.String = jrt.Intern("arbace.cpp.sema$abbreviated_template$fn__916000663")

var Lit_6 *jrt.String = jrt.Intern("arbace.cpp.sema$abbreviated_template$fn__916000669")

var Lit_7 *jrt.String = jrt.Intern("arbace.cpp.sema$abbreviated_template$fn__916000671")

var Lit_8 *jrt.String = jrt.Intern("arbace.cpp.sema$abbreviated_template$fn__916000673")

var Lit_9 *jrt.String = jrt.Intern("__auto_")

var Lit_10 *jrt.String = jrt.Intern("TemplateTypeParmDecl")

var Lit_11 *jrt.String = jrt.Intern("")

var Lit_12 *jrt.String = jrt.Intern("<")

var Lit_13 *jrt.String = jrt.Intern("ParmVarDecl")

var Lit_14 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_class_nss$ty_BANG___916001751")

var Lit_15 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_class_nss$cls_BANG___916001767")

var Lit_16 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_class_nss$cls_BANG___916001767$fn__916001772")

var Lit_17 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_classes$ty_BANG___916001784")

var Lit_18 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_classes$cls_BANG___916001800")

var Lit_19 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824")

var Lit_20 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824$fn__916001825")

var Lit_21 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824$fn__916001825$fn__916001826")

var Lit_22 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824$fn__916001825$iter__916001818__916001828")

var Lit_23 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824$fn__916001825$iter__916001818__916001828$fn__916001829")

var Lit_24 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824$fn__916001825$iter__916001818__916001828$fn__916001829$iter__916001820__916001830")

var Lit_25 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824$fn__916001825$iter__916001818__916001828$fn__916001829$fn__916001836")

var Lit_26 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824$fn__916001825$iter__916001818__916001828$fn__916001829$iter__916001820__916001830$fn__916001831")

var Lit_27 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns$iter__916001816__916001824$fn__916001825$iter__916001818__916001828$fn__916001829$iter__916001820__916001830$fn__916001831$fn__916001832")

var Lit_28 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_not_found_BANG_$fn__916001888")

var Lit_29 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_not_found_BANG_$fn__916001890")

var Lit_30 *jrt.String = jrt.Intern("call to function '")

var Lit_31 *jrt.String = jrt.Intern("' that is neither visible in the template definition nor found by argument-dependent lookup")

var Lit_32 *jrt.String = jrt.Intern(" inline")

var Lit_33 *jrt.String = jrt.Intern("arbace.cpp.sema$aggr_subs$fn__916001463")

var Lit_34 *jrt.String = jrt.Intern("arbace.cpp.sema$aggr_subs$fn__916001465")

var Lit_35 *jrt.String = jrt.Intern("arbace.cpp.sema$aggregate_QMARK_$fn__916000968")

var Lit_36 *jrt.String = jrt.Intern("arbace.cpp.sema$aggregate_QMARK_$fn__916000970")

var Lit_37 *jrt.String = jrt.Intern("align_val_t")

var Lit_38 *jrt.String = jrt.Intern("arbace.cpp.sema$align_val_t$fn__916002006")

var Lit_39 *jrt.String = jrt.Intern("arbace.cpp.sema$always_inline_node_QMARK_$fn__916000332")

var Lit_40 *jrt.String = jrt.Intern("NativeAttr")

var Lit_41 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_args$fn__916002071")

var Lit_42 *jrt.String = jrt.Intern("PackExpansionExpr")

var Lit_43 *jrt.String = jrt.Intern("a pack expansion")

var Lit_44 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_call$fn__916001934")

var Lit_45 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_call$fn__916001936")

var Lit_46 *jrt.String = jrt.Intern("CPP_TMPL_TRACE")

var Lit_47 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_call$fn__916001938")

var Lit_48 *jrt.String = jrt.Intern("unknown name ")

var Lit_49 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_call$fn__916001940")

var Lit_50 *jrt.String = jrt.Intern("__is_constant_evaluated")

var Lit_51 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_call$fn__916001945")

var Lit_52 *jrt.String = jrt.Intern("call of a non-function")

var Lit_53 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_call$fn__916001948")

var Lit_54 *jrt.String = jrt.Intern("call of")

var Lit_55 *jrt.String = jrt.Intern("no candidates:")

var Lit_56 *jrt.String = jrt.Intern("fns")

var Lit_57 *jrt.String = jrt.Intern("templates")

var Lit_58 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002859")

var Lit_59 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002865")

var Lit_60 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002878")

var Lit_61 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002892")

var Lit_62 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$trace__916002901")

var Lit_63 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002905")

var Lit_64 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002907")

var Lit_65 *jrt.String = jrt.Intern("CXXTryStmt")

var Lit_66 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002909")

var Lit_67 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002865$fn__916002869")

var Lit_68 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002865$fn__916002874")

var Lit_69 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002909$fn__916002910")

var Lit_70 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$fn__916002909$fn__916002910$fn__916002911")

var Lit_71 *jrt.String = jrt.Intern("CPP_HDR_TRACE")

var Lit_72 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_$trace__916002901$fn__916002902")

var Lit_73 *jrt.String = jrt.Intern("in the body of")

var Lit_74 *jrt.String = jrt.Intern(":")

var Lit_75 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002982")

var Lit_76 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002984")

var Lit_77 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002986")

var Lit_78 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002988")

var Lit_79 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990")

var Lit_80 *jrt.String = jrt.Intern("=")

var Lit_81 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916003028")

var Lit_82 *jrt.String = jrt.Intern("__p")

var Lit_83 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916002991__916002995")

var Lit_84 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916003007__916003011")

var Lit_85 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916003017__916003021")

var Lit_86 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916002991__916002995$fn__916002996")

var Lit_87 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916002991__916002995$fn__916002996$fn__916002997")

var Lit_88 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916003007__916003011$fn__916003012")

var Lit_89 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916003007__916003011$fn__916003012$fn__916003013")

var Lit_90 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916003017__916003021$fn__916003022")

var Lit_91 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916002990$iter__916003017__916003021$fn__916003022$fn__916003023")

var Lit_92 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916003028$iter__916003029__916003033")

var Lit_93 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916003028$iter__916003039__916003043")

var Lit_94 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916003028$iter__916003029__916003033$fn__916003034")

var Lit_95 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916003028$iter__916003029__916003033$fn__916003034$fn__916003035")

var Lit_96 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916003028$iter__916003039__916003043$fn__916003044")

var Lit_97 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_$fn__916003028$iter__916003039__916003043$fn__916003044$fn__916003045")

var Lit_98 *jrt.String = jrt.Intern("ExprWithCleanups")

var Lit_99 *jrt.String = jrt.Intern("CXXStaticCastExpr")

var Lit_100 *jrt.String = jrt.Intern("CXXFunctionalCastExpr")

var Lit_101 *jrt.String = jrt.Intern("lvalue")

var Lit_102 *jrt.String = jrt.Intern("a functional cast of a scalar type with ")

var Lit_103 *jrt.String = jrt.Intern(" arguments: ")

var Lit_104 *jrt.String = jrt.Intern(" from ")

var Lit_105 *jrt.String = jrt.Intern("InitListExpr")

var Lit_106 *jrt.String = jrt.Intern("CXXBoolLiteralExpr")

var Lit_107 *jrt.String = jrt.Intern("CXXDeleteExpr")

var Lit_108 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002297")

var Lit_109 *jrt.String = jrt.Intern("CXXNullPtrLiteralExpr")

var Lit_110 *jrt.String = jrt.Intern("CXXDynamicCastExpr")

var Lit_111 *jrt.String = jrt.Intern("CXXTypeidExpr")

var Lit_112 *jrt.String = jrt.Intern("typeid without std::type_info")

var Lit_113 *jrt.String = jrt.Intern("AtomicExpr")

var Lit_114 *jrt.String = jrt.Intern("ImplicitValueInitExpr")

var Lit_115 *jrt.String = jrt.Intern("CXXTemporaryObjectExpr")

var Lit_116 *jrt.String = jrt.Intern("CXXConstructExpr")

var Lit_117 *jrt.String = jrt.Intern("CXXFoldExpr")

var Lit_118 *jrt.String = jrt.Intern("a fold expression")

var Lit_119 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$expand__916002307")

var Lit_120 *jrt.String = jrt.Intern("a fold over no pack")

var Lit_121 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$typed__916002309")

var Lit_122 *jrt.String = jrt.Intern("CompoundAssignOperator")

var Lit_123 *jrt.String = jrt.Intern("BinaryOperator")

var Lit_124 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$combine__916002311")

var Lit_125 *jrt.String = jrt.Intern(",")

var Lit_126 *jrt.String = jrt.Intern("&&")

var Lit_127 *jrt.String = jrt.Intern("||")

var Lit_128 *jrt.String = jrt.Intern("a unary fold expression with an empty expansion for operator '")

var Lit_129 *jrt.String = jrt.Intern("'")

var Lit_130 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002314")

var Lit_131 *jrt.String = jrt.Intern("a fold expression the parser kept as its text: ")

var Lit_132 *jrt.String = jrt.Intern("CXXNewExpr")

var Lit_133 *jrt.String = jrt.Intern("ParenExpr")

var Lit_134 *jrt.String = jrt.Intern("UnresolvedMemberExpr")

var Lit_135 *jrt.String = jrt.Intern("RequiresExpr")

var Lit_136 *jrt.String = jrt.Intern("a requires-expression the parser kept as its text")

var Lit_137 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002320")

var Lit_138 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$type_sure_false_QMARK___916002322")

var Lit_139 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$sure_expr_failure_QMARK___916002329")

var Lit_140 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$ok_QMARK___916002331")

var Lit_141 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002340")

var Lit_142 *jrt.String = jrt.Intern("TypeTraitExpr")

var Lit_143 *jrt.String = jrt.Intern("a type trait")

var Lit_144 *jrt.String = jrt.Intern("a dependent type trait ")

var Lit_145 *jrt.String = jrt.Intern("__Typed")

var Lit_146 *jrt.String = jrt.Intern("DeclRefExpr")

var Lit_147 *jrt.String = jrt.Intern("CStyleCastExpr")

var Lit_148 *jrt.String = jrt.Intern("BuiltinExpr")

var Lit_149 *jrt.String = jrt.Intern("offsetof in a non-class ")

var Lit_150 *jrt.String = jrt.Intern("offsetof through a virtual base")

var Lit_151 *jrt.String = jrt.Intern("offsetof of a non-field ")

var Lit_152 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002371")

var Lit_153 *jrt.String = jrt.Intern("offsetof of a bit-field")

var Lit_154 *jrt.String = jrt.Intern("offsetof's [] of a non-array")

var Lit_155 *jrt.String = jrt.Intern("offsetof's index not a constant")

var Lit_156 *jrt.String = jrt.Intern("a builtin expression ")

var Lit_157 *jrt.String = jrt.Intern("PredefinedExpr")

var Lit_158 *jrt.String = jrt.Intern("SizeOfPackExpr")

var Lit_159 *jrt.String = jrt.Intern("sizeof... of a non-pack ")

var Lit_160 *jrt.String = jrt.Intern("CXXUnresolvedConstructExpr")

var Lit_161 *jrt.String = jrt.Intern("CXXThrowExpr")

var Lit_162 *jrt.String = jrt.Intern("CXXNoexceptExpr")

var Lit_163 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002376")

var Lit_164 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$walk__916002378")

var Lit_165 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002394")

var Lit_166 *jrt.String = jrt.Intern("StmtExpr")

var Lit_167 *jrt.String = jrt.Intern("Stmt")

var Lit_168 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002396")

var Lit_169 *jrt.String = jrt.Intern("a statement expression of class type")

var Lit_170 *jrt.String = jrt.Intern("CharacterLiteral")

var Lit_171 *jrt.String = jrt.Intern("char")

var Lit_172 *jrt.String = jrt.Intern("FloatingLiteral")

var Lit_173 *jrt.String = jrt.Intern("long double")

var Lit_174 *jrt.String = jrt.Intern("float")

var Lit_175 *jrt.String = jrt.Intern("_Float16")

var Lit_176 *jrt.String = jrt.Intern("__float128")

var Lit_177 *jrt.String = jrt.Intern("CXXConstCastExpr")

var Lit_178 *jrt.String = jrt.Intern("CallExpr")

var Lit_179 *jrt.String = jrt.Intern(" of ")

var Lit_180 *jrt.String = jrt.Intern("double")

var Lit_181 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$lit__916002407")

var Lit_182 *jrt.String = jrt.Intern("__builtin_copysign")

var Lit_183 *jrt.String = jrt.Intern("f")

var Lit_184 *jrt.String = jrt.Intern("l")

var Lit_185 *jrt.String = jrt.Intern("1.0")

var Lit_186 *jrt.String = jrt.Intern("0.0")

var Lit_187 *jrt.String = jrt.Intern("-")

var Lit_188 *jrt.String = jrt.Intern("==")

var Lit_189 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002410")

var Lit_190 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002412")

var Lit_191 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$lit__916002415")

var Lit_192 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002418")

var Lit_193 *jrt.String = jrt.Intern("__builtin_clear_padding of ")

var Lit_194 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002423")

var Lit_195 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002428")

var Lit_196 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002433")

var Lit_197 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002438")

var Lit_198 *jrt.String = jrt.Intern("a lock-free query not folded")

var Lit_199 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_200 *jrt.String = jrt.Intern("CXXDependentScopeMemberExpr")

var Lit_201 *jrt.String = jrt.Intern("MemberExpr")

var Lit_202 *jrt.String = jrt.Intern("~")

var Lit_203 *jrt.String = jrt.Intern("()")

var Lit_204 *jrt.String = jrt.Intern("no operator()")

var Lit_205 *jrt.String = jrt.Intern(" ")

var Lit_206 *jrt.String = jrt.Intern("::")

var Lit_207 *jrt.String = jrt.Intern("->*")

var Lit_208 *jrt.String = jrt.Intern("GNUNullExpr")

var Lit_209 *jrt.String = jrt.Intern("StringLiteral")

var Lit_210 *jrt.String = jrt.Intern("a string literal of ")

var Lit_211 *jrt.String = jrt.Intern("LambdaExpr")

var Lit_212 *jrt.String = jrt.Intern("a complex compound assignment ")

var Lit_213 *jrt.String = jrt.Intern("CXXDefaultInitExpr")

var Lit_214 *jrt.String = jrt.Intern("CXXThisExpr")

var Lit_215 *jrt.String = jrt.Intern("UserDefinedLiteral")

var Lit_216 *jrt.String = jrt.Intern("operator\"\"")

var Lit_217 *jrt.String = jrt.Intern("prvalue")

var Lit_218 *jrt.String = jrt.Intern("const ")

var Lit_219 *jrt.String = jrt.Intern("[")

var Lit_220 *jrt.String = jrt.Intern("]")

var Lit_221 *jrt.String = jrt.Intern("IntegerLiteral")

var Lit_222 *jrt.String = jrt.Intern("a user-defined literal")

var Lit_223 *jrt.String = jrt.Intern("BinaryConditionalOperator")

var Lit_224 *jrt.String = jrt.Intern("UnaryExprOrTypeTraitExpr")

var Lit_225 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002454")

var Lit_226 *jrt.String = jrt.Intern("sizeof")

var Lit_227 *jrt.String = jrt.Intern("alignof")

var Lit_228 *jrt.String = jrt.Intern("__alignof")

var Lit_229 *jrt.String = jrt.Intern("CXXReinterpretCastExpr")

var Lit_230 *jrt.String = jrt.Intern("ConditionalOperator")

var Lit_231 *jrt.String = jrt.Intern("UnaryOperator")

var Lit_232 *jrt.String = jrt.Intern("&")

var Lit_233 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002467")

var Lit_234 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002469")

var Lit_235 *jrt.String = jrt.Intern("!")

var Lit_236 *jrt.String = jrt.Intern("& of an rvalue")

var Lit_237 *jrt.String = jrt.Intern("*")

var Lit_238 *jrt.String = jrt.Intern("+")

var Lit_239 *jrt.String = jrt.Intern("__imag")

var Lit_240 *jrt.String = jrt.Intern("__real__ of a complex prvalue")

var Lit_241 *jrt.String = jrt.Intern("__real")

var Lit_242 *jrt.String = jrt.Intern("unary ")

var Lit_243 *jrt.String = jrt.Intern("__extension__")

var Lit_244 *jrt.String = jrt.Intern("++")

var Lit_245 *jrt.String = jrt.Intern("++ of an rvalue")

var Lit_246 *jrt.String = jrt.Intern("--")

var Lit_247 *jrt.String = jrt.Intern("ArraySubscriptExpr")

var Lit_248 *jrt.String = jrt.Intern("[]")

var Lit_249 *jrt.String = jrt.Intern("a subscript of ")

var Lit_250 *jrt.String = jrt.Intern(" expressions")

var Lit_251 *jrt.String = jrt.Intern("CXXScalarValueInitExpr")

var Lit_252 *jrt.String = jrt.Intern("expression ")

var Lit_253 *jrt.String = jrt.Intern(" at ")

var Lit_254 *jrt.String = jrt.Intern("CPP_CONCEPT_TRACE")

var Lit_255 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$fn__916002340$fn__916002341")

var Lit_256 *jrt.String = jrt.Intern("requirement")

var Lit_257 *jrt.String = jrt.Intern("false:")

var Lit_258 *jrt.String = jrt.Intern("NestedRequirement")

var Lit_259 *jrt.String = jrt.Intern("TypeRequirement")

var Lit_260 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$ok_QMARK___916002331$fn__916002334")

var Lit_261 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$ok_QMARK___916002331$fn__916002336")

var Lit_262 *jrt.String = jrt.Intern("fails:")

var Lit_263 *jrt.String = jrt.Intern("|")

var Lit_264 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node$type_sure_false_QMARK___916002322$fn__916002326")

var Lit_265 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003103")

var Lit_266 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105")

var Lit_267 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$fn__916003106")

var Lit_268 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$fn__916003112")

var Lit_269 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$entry_BANG___916003157")

var Lit_270 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$entry_BANG___916003157$fn__916003163")

var Lit_271 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$entry_BANG___916003157$fn__916003167")

var Lit_272 *jrt.String = jrt.Intern("implicit member failed:")

var Lit_273 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$fn__916003112$retry_BANG___916003116")

var Lit_274 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$fn__916003112$rounds_BANG___916003132")

var Lit_275 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$fn__916003112$fn__916003134")

var Lit_276 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program$fn__916003105$fn__916003112$again_BANG___916003136")

var Lit_277 *jrt.String = jrt.Intern("arithmetic on ")

var Lit_278 *jrt.String = jrt.Intern(" and ")

var Lit_279 *jrt.String = jrt.Intern("arbace.cpp.sema$array_delete_wants_size_QMARK_$fn__916002034")

var Lit_280 *jrt.String = jrt.Intern("operator delete[]")

var Lit_281 *jrt.String = jrt.Intern("assignment to an rvalue")

var Lit_282 *jrt.String = jrt.Intern("a list of several values assigned to a scalar")

var Lit_283 *jrt.String = jrt.Intern(" with ")

var Lit_284 *jrt.String = jrt.Intern(" arguments")

var Lit_285 *jrt.String = jrt.Intern("the atomic builtin ")

var Lit_286 *jrt.String = jrt.Intern(" of a non-pointer")

var Lit_287 *jrt.String = jrt.Intern(" of a ")

var Lit_288 *jrt.String = jrt.Intern("-byte type")

var Lit_289 *jrt.String = jrt.Intern("arbace.cpp.sema$atomic_expr$fn__916001924")

var Lit_290 *jrt.String = jrt.Intern("arbace.cpp.sema$atomic_expr$const__916001927")

var Lit_291 *jrt.String = jrt.Intern("arbace.cpp.sema$base_subobjects$paths__916001533")

var Lit_292 *jrt.String = jrt.Intern("arbace.cpp.sema$base_subobjects$paths__916001533$fn__916001535")

var Lit_293 *jrt.String = jrt.Intern("arbace.cpp.sema$base_subobjects$paths__916001533$fn__916001535$iter__916001539__916001543")

var Lit_294 *jrt.String = jrt.Intern("arbace.cpp.sema$base_subobjects$paths__916001533$fn__916001535$iter__916001539__916001543$fn__916001544")

var Lit_295 *jrt.String = jrt.Intern("arbace.cpp.sema$base_subobjects$paths__916001533$fn__916001535$iter__916001539__916001543$fn__916001544$fn__916001545")

var Lit_296 *jrt.String = jrt.Intern("arbace.cpp.sema$blank_comments$fn__916000228")

var Lit_297 *jrt.String = jrt.Intern("arbace.cpp.sema$blank_comments$fn__916000230")

var Lit_298 *jrt.String = jrt.Intern("arbace.cpp.sema$blank_comments$fn__916000232")

var Lit_299 *jrt.String = jrt.Intern("arbace.cpp.sema$body_of$fn__916000281")

var Lit_300 *jrt.String = jrt.Intern("%")

var Lit_301 *jrt.String = jrt.Intern("/")

var Lit_302 *jrt.String = jrt.Intern(">")

var Lit_303 *jrt.String = jrt.Intern("^")

var Lit_304 *jrt.String = jrt.Intern("pointer-to-member function type requires an ")

var Lit_305 *jrt.String = jrt.Intern("rvalue")

var Lit_306 *jrt.String = jrt.Intern("!=")

var Lit_307 *jrt.String = jrt.Intern(".*")

var Lit_308 *jrt.String = jrt.Intern("<<")

var Lit_309 *jrt.String = jrt.Intern("<=")

var Lit_310 *jrt.String = jrt.Intern(">=")

var Lit_311 *jrt.String = jrt.Intern(">>")

var Lit_312 *jrt.String = jrt.Intern("<=>")

var Lit_313 *jrt.String = jrt.Intern("binary ")

var Lit_314 *jrt.String = jrt.Intern("abort")

var Lit_315 *jrt.String = jrt.Intern("arbace.cpp.sema$call_args$fn__916001336")

var Lit_316 *jrt.String = jrt.Intern("arbace.cpp.sema$call_args$iter__916001338__916001342")

var Lit_317 *jrt.String = jrt.Intern("a non-trivial class through ...")

var Lit_318 *jrt.String = jrt.Intern("arbace.cpp.sema$call_args$iter__916001338__916001342$fn__916001343")

var Lit_319 *jrt.String = jrt.Intern("arbace.cpp.sema$call_args$iter__916001338__916001342$fn__916001343$fn__916001344")

var Lit_320 *jrt.String = jrt.Intern("missing argument")

var Lit_321 *jrt.String = jrt.Intern("arbace.cpp.sema$call_args$iter__916001338__916001342$fn__916001343$fn__916001348")

var Lit_322 *jrt.String = jrt.Intern("arbace.cpp.sema$call_args$iter__916001338__916001342$fn__916001343$fn__916001344$fn__916001345")

var Lit_323 *jrt.String = jrt.Intern("a capture of a generic lambda its definition did not name: ")

var Lit_324 *jrt.String = jrt.Intern("this")

var Lit_325 *jrt.String = jrt.Intern("arbace.cpp.sema$capture_field$fn__916002077")

var Lit_326 *jrt.String = jrt.Intern("a variable the lambda does not capture: ")

var Lit_327 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_args_env$fn__916001082")

var Lit_328 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_base_path$fn__916001069")

var Lit_329 *jrt.String = jrt.Intern("a call of ")

var Lit_330 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_call_fn$fn__916001115")

var Lit_331 *jrt.String = jrt.Intern("no return")

var Lit_332 *jrt.String = jrt.Intern("a call of the constructor ")

var Lit_333 *jrt.String = jrt.Intern("a class with virtual bases")

var Lit_334 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_construct$fn__916001085")

var Lit_335 *jrt.String = jrt.Intern("a copy of a value")

var Lit_336 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_construct$fn__916001087")

var Lit_337 *jrt.String = jrt.Intern("too many steps")

var Lit_338 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$ev__916001014")

var Lit_339 *jrt.String = jrt.Intern("reinterpret_cast: conversion from pointer type")

var Lit_340 *jrt.String = jrt.Intern("cast ")

var Lit_341 *jrt.String = jrt.Intern("this outside a member's evaluation")

var Lit_342 *jrt.String = jrt.Intern("a pointer difference")

var Lit_343 *jrt.String = jrt.Intern("__")

var Lit_344 *jrt.String = jrt.Intern("call to non-constexpr function '")

var Lit_345 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$fn__916001018")

var Lit_346 *jrt.String = jrt.Intern("a member call without its object")

var Lit_347 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$fn__916001021")

var Lit_348 *jrt.String = jrt.Intern("an element out of its array")

var Lit_349 *jrt.String = jrt.Intern("a load through a pointer")

var Lit_350 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$fn__916001023")

var Lit_351 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$fn__916001025")

var Lit_352 *jrt.String = jrt.Intern("the value of '")

var Lit_353 *jrt.String = jrt.Intern("' is not usable in a constant expression")

var Lit_354 *jrt.String = jrt.Intern("a load")

var Lit_355 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$fn__916001027")

var Lit_356 *jrt.String = jrt.Intern("the decay of ")

var Lit_357 *jrt.String = jrt.Intern("pointer arithmetic")

var Lit_358 *jrt.String = jrt.Intern("a pointer to an object compared")

var Lit_359 *jrt.String = jrt.Intern("pointers into different arrays compared")

var Lit_360 *jrt.String = jrt.Intern("a pointer compared")

var Lit_361 *jrt.String = jrt.Intern("a pointer's compound assignment")

var Lit_362 *jrt.String = jrt.Intern("op ")

var Lit_363 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$big__916001035")

var Lit_364 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$out_QMARK___916001037")

var Lit_365 *jrt.String = jrt.Intern("value ")

var Lit_366 *jrt.String = jrt.Intern(" is outside the range of representable values")

var Lit_367 *jrt.String = jrt.Intern("negative shift count ")

var Lit_368 *jrt.String = jrt.Intern("shift count ")

var Lit_369 *jrt.String = jrt.Intern(" >= width of type (")

var Lit_370 *jrt.String = jrt.Intern(" bits)")

var Lit_371 *jrt.String = jrt.Intern("left shift of negative value ")

var Lit_372 *jrt.String = jrt.Intern("signed left shift discards bits")

var Lit_373 *jrt.String = jrt.Intern("division by zero")

var Lit_374 *jrt.String = jrt.Intern("the expression ")

var Lit_375 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval$fn__916001012")

var Lit_376 *jrt.String = jrt.Intern("a pointer's value")

var Lit_377 *jrt.String = jrt.Intern("an object's value")

var Lit_378 *jrt.String = jrt.Intern("an if consteval's branch not analyzed")

var Lit_379 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_exec$fn__916001055")

var Lit_380 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_exec$el__916001060")

var Lit_381 *jrt.String = jrt.Intern("a local with a destructor (")

var Lit_382 *jrt.String = jrt.Intern(")")

var Lit_383 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_exec$fn__916001064")

var Lit_384 *jrt.String = jrt.Intern("a local's initializer (")

var Lit_385 *jrt.String = jrt.Intern("the statement ")

var Lit_386 *jrt.String = jrt.Intern("an element's initializer")

var Lit_387 *jrt.String = jrt.Intern(" (in a local's initializer (")

var Lit_388 *jrt.String = jrt.Intern("))")

var Lit_389 *jrt.String = jrt.Intern("CPP_CE_TRACE")

var Lit_390 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_get$fn__916001003")

var Lit_391 *jrt.String = jrt.Intern("a read of an uninitialized object")

var Lit_392 *jrt.String = jrt.Intern("ce-get")

var Lit_393 *jrt.String = jrt.Intern("an initializer :zero-then")

var Lit_394 *jrt.String = jrt.Intern("a base subobject")

var Lit_395 *jrt.String = jrt.Intern("a default member initializer's this")

var Lit_396 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_init$fn__916001101")

var Lit_397 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_init$fn__916001107")

var Lit_398 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_init$fn__916001112")

var Lit_399 *jrt.String = jrt.Intern("a list's initializer")

var Lit_400 *jrt.String = jrt.Intern("a constructor's call for ")

var Lit_401 *jrt.String = jrt.Intern("an initializer ")

var Lit_402 *jrt.String = jrt.Intern("an object through a pointer")

var Lit_403 *jrt.String = jrt.Intern("a variable's object")

var Lit_404 *jrt.String = jrt.Intern("the object of ")

var Lit_405 *jrt.String = jrt.Intern("a pointer out of its array")

var Lit_406 *jrt.String = jrt.Intern("a reference to a value")

var Lit_407 *jrt.String = jrt.Intern("not a constant: ")

var Lit_408 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_try$fn__916001118")

var Lit_409 *jrt.String = jrt.Intern("a pointer as ")

var Lit_410 *jrt.String = jrt.Intern("a value of ")

var Lit_411 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_zero_of$fn__916001077")

var Lit_412 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_zero_of$fn__916001079")

var Lit_413 *jrt.String = jrt.Intern("' is a ")

var Lit_414 *jrt.String = jrt.Intern(" member of '")

var Lit_415 *jrt.String = jrt.Intern("arbace.cpp.sema$check_static_assert_BANG_$fn__916003075")

var Lit_416 *jrt.String = jrt.Intern("arbace.cpp.sema$check_static_assert_BANG_$fn__916003077")

var Lit_417 *jrt.String = jrt.Intern("codegen: static assertion failed")

var Lit_418 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_$fn__916001682")

var Lit_419 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_$fn__916001684")

var Lit_420 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_$fn__916001693")

var Lit_421 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_$fn__916001697")

var Lit_422 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_$fn__916001702")

var Lit_423 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_$fn__916001706")

var Lit_424 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_$fn__916001693$fn__916001694")

var Lit_425 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_$fn__916001702$fn__916001703")

var Lit_426 *jrt.String = jrt.Intern("arbace.cpp.sema$class__GT_scalar$fn__916001639")

var Lit_427 *jrt.String = jrt.Intern("a class operand with ")

var Lit_428 *jrt.String = jrt.Intern(" conversion functions")

var Lit_429 *jrt.String = jrt.Intern("arbace.cpp.sema$class_init$fn__916001410")

var Lit_430 *jrt.String = jrt.Intern("arbace.cpp.sema$class_init$fn__916001412")

var Lit_431 *jrt.String = jrt.Intern("arbace.cpp.sema$class_init$fn__916001414")

var Lit_432 *jrt.String = jrt.Intern("arbace.cpp.sema$class_init$fn__916001416")

var Lit_433 *jrt.String = jrt.Intern("arbace.cpp.sema$class_init$fn__916001418")

var Lit_434 *jrt.String = jrt.Intern("arbace.cpp.sema$class_like_members$fn__916000835")

var Lit_435 *jrt.String = jrt.Intern("arbace.cpp.sema$class_like_members$fn__916000835$fn__916000836")

var Lit_436 *jrt.String = jrt.Intern("arbace.cpp.sema$class_lookup$fn__916000060")

var Lit_437 *jrt.String = jrt.Intern("arbace.cpp.sema$class_lookup$fn__916000062")

var Lit_438 *jrt.String = jrt.Intern("arbace.cpp.sema$class_lookup$keep_QMARK___916000064")

var Lit_439 *jrt.String = jrt.Intern("arbace.cpp.sema$class_lookup$keep_QMARK___916000064$fn__916000065")

var Lit_440 *jrt.String = jrt.Intern("arbace.cpp.sema$const_int$fn__916000984")

var Lit_441 *jrt.String = jrt.Intern("arbace.cpp.sema$const_int$ev__916000986")

var Lit_442 *jrt.String = jrt.Intern("arbace.cpp.sema$const_int$fn__916000993")

var Lit_443 *jrt.String = jrt.Intern("constant cast")

var Lit_444 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$member_QMARK___916002833")

var Lit_445 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$strip__916002843")

var Lit_446 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$this_QMARK___916002845")

var Lit_447 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$of_this_QMARK___916002847")

var Lit_448 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$store_QMARK___916002850")

var Lit_449 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$fn__916002853")

var Lit_450 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$fn__916002855")

var Lit_451 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$member_QMARK___916002833$fn__916002835")

var Lit_452 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_$member_QMARK___916002833$fn__916002840")

var Lit_453 *jrt.String = jrt.Intern("ParenListExpr")

var Lit_454 *jrt.String = jrt.Intern("CXXMemberCallExpr")

var Lit_455 *jrt.String = jrt.Intern("arbace.cpp.sema$constexpr_if_value$fn__916002651")

var Lit_456 *jrt.String = jrt.Intern("CPP_CONSTEXPR_IF_TRACE")

var Lit_457 *jrt.String = jrt.Intern("arbace.cpp.sema$constexpr_if_value$fn__916002653")

var Lit_458 *jrt.String = jrt.Intern("arbace.cpp.sema$constexpr_if_value$fn__916002656")

var Lit_459 *jrt.String = jrt.Intern("an if constexpr's condition not evaluated (")

var Lit_460 *jrt.String = jrt.Intern("if constexpr")

var Lit_461 *jrt.String = jrt.Intern("arbace.cpp.sema$constraint_satisfied_QMARK_$fn__916000325")

var Lit_462 *jrt.String = jrt.Intern("a constraint's satisfaction depends on itself")

var Lit_463 *jrt.String = jrt.Intern("arbace.cpp.sema$constraint_satisfied_QMARK_$fn__916000328")

var Lit_464 *jrt.String = jrt.Intern("constraint depth")

var Lit_465 *jrt.String = jrt.Intern("constraint not satisfied:")

var Lit_466 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_fns$fn__916001151")

var Lit_467 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_fns$fn__916001153")

var Lit_468 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_fns$fn__916001155")

var Lit_469 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_fns$fn__916001157")

var Lit_470 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_for$iter__916001189__916001193")

var Lit_471 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_for$iter__916001189__916001193$fn__916001194")

var Lit_472 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_for$iter__916001189__916001193$fn__916001194$fn__916001195")

var Lit_473 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_tmpls$fn__916001161")

var Lit_474 *jrt.String = jrt.Intern("no function of the set matches")

var Lit_475 *jrt.String = jrt.Intern("arbace.cpp.sema$convert_scalar$fn__916001141")

var Lit_476 *jrt.String = jrt.Intern("incompatible member function pointer types (qualifiers)")

var Lit_477 *jrt.String = jrt.Intern("conversion from ")

var Lit_478 *jrt.String = jrt.Intern(" to ")

var Lit_479 *jrt.String = jrt.Intern("operator=")

var Lit_480 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_compound_BANG_$fn__916000208")

var Lit_481 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_compound_BANG_$syms__916000210")

var Lit_482 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_compound_BANG_$fn__916000212")

var Lit_483 *jrt.String = jrt.Intern("cannot form a compound type of a deduced class template specialization type (")

var Lit_484 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_compound_var$fn__916000215")

var Lit_485 *jrt.String = jrt.Intern("call")

var Lit_486 *jrt.String = jrt.Intern("list")

var Lit_487 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_template$fn__916000192")

var Lit_488 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_template$fn__916000194")

var Lit_489 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_template$fn__916000196")

var Lit_490 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_template$fn__916000198")

var Lit_491 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_template$fn__916000200")

var Lit_492 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_template$fn__916000202")

var Lit_493 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_template$fn__916000204")

var Lit_494 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_var$fn__916002489")

var Lit_495 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_var$fallback__916002491")

var Lit_496 *jrt.String = jrt.Intern("<>")

var Lit_497 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_candidates$fn__916001331")

var Lit_498 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_candidates$fn__916001333")

var Lit_499 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$fn__916001432")

var Lit_500 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$inh_of__916001434")

var Lit_501 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$fn__916001452")

var Lit_502 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$fn__916001454")

var Lit_503 *jrt.String = jrt.Intern(" (constructing ")

var Lit_504 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$inh_of__916001434$iter__916001435__916001441")

var Lit_505 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$inh_of__916001434$iter__916001435__916001441$fn__916001442")

var Lit_506 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$inh_of__916001434$iter__916001435__916001441$fn__916001442$iter__916001437__916001443")

var Lit_507 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$inh_of__916001434$iter__916001435__916001441$fn__916001442$iter__916001437__916001443$fn__916001444")

var Lit_508 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init$inh_of__916001434$iter__916001435__916001441$fn__916001442$iter__916001437__916001443$fn__916001444$fn__916001445")

var Lit_509 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002747__916002751")

var Lit_510 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$init_of__916002763")

var Lit_511 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002767__916002771")

var Lit_512 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002783__916002787")

var Lit_513 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797")

var Lit_514 *jrt.String = jrt.Intern("CXXParenListInitExpr")

var Lit_515 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$init_of__916002763$fn__916002764")

var Lit_516 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002747__916002751$fn__916002752")

var Lit_517 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002747__916002751$fn__916002752$fn__916002753")

var Lit_518 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002767__916002771$fn__916002772")

var Lit_519 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002767__916002771$fn__916002772$fn__916002773")

var Lit_520 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002783__916002787$fn__916002788")

var Lit_521 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002783__916002787$fn__916002788$fn__916002789")

var Lit_522 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797$fn__916002798")

var Lit_523 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797$fn__916002798$fn__916002799")

var Lit_524 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797$fn__916002798$fn__916002807")

var Lit_525 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797$fn__916002798$fn__916002809")

var Lit_526 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797$fn__916002798$fn__916002811")

var Lit_527 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797$fn__916002798$fn__916002799$fn__916002800")

var Lit_528 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797$fn__916002798$fn__916002799$fn__916002802")

var Lit_529 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits$iter__916002793__916002797$fn__916002798$fn__916002799$fn__916002804")

var Lit_530 *jrt.String = jrt.Intern("' is a member of '")

var Lit_531 *jrt.String = jrt.Intern("', an inaccessible base of '")

var Lit_532 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_ok_QMARK_$fn__916001390")

var Lit_533 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_ok_QMARK_$acc__916001392")

var Lit_534 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_ok_QMARK_$direct__916001394")

var Lit_535 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_ok_QMARK_$base_ok_QMARK___916001396")

var Lit_536 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_ok_QMARK_$ok_QMARK___916001400")

var Lit_537 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_ok_QMARK_$base_ok_QMARK___916001396$fn__916001397")

var Lit_538 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_ok_QMARK_$ok_QMARK___916001400$fn__916001401")

var Lit_539 *jrt.String = jrt.Intern("constant")

var Lit_540 *jrt.String = jrt.Intern("immediate")

var Lit_541 *jrt.String = jrt.Intern("codegen: constexpr variable '")

var Lit_542 *jrt.String = jrt.Intern("' must be initialized by a constant expression (")

var Lit_543 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_$fn__916002597")

var Lit_544 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_$fn__916002599")

var Lit_545 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_$fn__916002601")

var Lit_546 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_$err__916002603")

var Lit_547 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_$data__916002605")

var Lit_548 *jrt.String = jrt.Intern("type decomposes into ")

var Lit_549 *jrt.String = jrt.Intern(" elements, but ")

var Lit_550 *jrt.String = jrt.Intern(" names were provided")

var Lit_551 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_$holder__916002609")

var Lit_552 *jrt.String = jrt.Intern("cannot decompose lambda closure type '")

var Lit_553 *jrt.String = jrt.Intern("cannot decompose class type '")

var Lit_554 *jrt.String = jrt.Intern("' because it has an anonymous ")

var Lit_555 *jrt.String = jrt.Intern("union")

var Lit_556 *jrt.String = jrt.Intern("struct")

var Lit_557 *jrt.String = jrt.Intern(" member")

var Lit_558 *jrt.String = jrt.Intern("cannot decompose inaccessible member '")

var Lit_559 *jrt.String = jrt.Intern("' of '")

var Lit_560 *jrt.String = jrt.Intern("type '")

var Lit_561 *jrt.String = jrt.Intern("' decomposes into ")

var Lit_562 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_$data__916002605$fn__916002606")

var Lit_563 *jrt.String = jrt.Intern("codegen: ")

var Lit_564 *jrt.String = jrt.Intern("BindingDecl")

var Lit_565 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_$holder__916002609$fn__916002610")

var Lit_566 *jrt.String = jrt.Intern("': both it and its base class '")

var Lit_567 *jrt.String = jrt.Intern("' have non-static data members")

var Lit_568 *jrt.String = jrt.Intern("': its base classes '")

var Lit_569 *jrt.String = jrt.Intern("' and '")

var Lit_570 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_enclosing_classes$fn__916001365")

var Lit_571 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_friend_of_QMARK_$fn__916001371")

var Lit_572 *jrt.String = jrt.Intern("call to consteval function '")

var Lit_573 *jrt.String = jrt.Intern("' is not a constant expression")

var Lit_574 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_member_ok_QMARK_$fn__916001374")

var Lit_575 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_member_ok_QMARK_$fn__916001377")

var Lit_576 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_naming_class$fn__916001559")

var Lit_577 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_paths$fn__916001384")

var Lit_578 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_paths$fn__916001384$fn__916001385")

var Lit_579 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_type_friend_QMARK_$fn__916001673")

var Lit_580 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_using_map$iter__916001658__916001662")

var Lit_581 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_using_map$iter__916001658__916001662$fn__916001663")

var Lit_582 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_using_map$iter__916001658__916001662$fn__916001663$fn__916001664")

var Lit_583 *jrt.String = jrt.Intern("03")

var Lit_584 *jrt.String = jrt.Intern("0x")

var Lit_585 *jrt.String = jrt.Intern("1y")

var Lit_586 *jrt.String = jrt.Intern("1z")

var Lit_587 *jrt.String = jrt.Intern("2a")

var Lit_588 *jrt.String = jrt.Intern("2b")

var Lit_589 *jrt.String = jrt.Intern("2c")

var Lit_590 *jrt.String = jrt.Intern("98")

var Lit_591 *jrt.String = jrt.Intern("arbace.cpp.sema$decl_stmt$fn__916002620")

var Lit_592 *jrt.String = jrt.Intern("arbace.cpp.sema$decl_stmt$iter__916002622__916002626")

var Lit_593 *jrt.String = jrt.Intern("arbace.cpp.sema$decl_stmt$iter__916002622__916002626$fn__916002627")

var Lit_594 *jrt.String = jrt.Intern("arbace.cpp.sema$decl_stmt$iter__916002622__916002626$fn__916002627$fn__916002628")

var Lit_595 *jrt.String = jrt.Intern("UsingDirectiveDecl")

var Lit_596 *jrt.String = jrt.Intern("NamespaceAliasDecl")

var Lit_597 *jrt.String = jrt.Intern("UsingDecl")

var Lit_598 *jrt.String = jrt.Intern("DecompositionDecl")

var Lit_599 *jrt.String = jrt.Intern("TypedefDecl")

var Lit_600 *jrt.String = jrt.Intern("StaticAssertDecl")

var Lit_601 *jrt.String = jrt.Intern("FunctionDecl")

var Lit_602 *jrt.String = jrt.Intern("UsingEnumDecl")

var Lit_603 *jrt.String = jrt.Intern("VarDecl")

var Lit_604 *jrt.String = jrt.Intern("arbace.cpp.sema$decl_stmt$iter__916002622__916002626$fn__916002627$fn__916002636")

var Lit_605 *jrt.String = jrt.Intern("TypeAliasDecl")

var Lit_606 *jrt.String = jrt.Intern("EnumDecl")

var Lit_607 *jrt.String = jrt.Intern("CXXRecordDecl")

var Lit_608 *jrt.String = jrt.Intern("local declaration ")

var Lit_609 *jrt.String = jrt.Intern("arbace.cpp.sema$decl_stmt$iter__916002622__916002626$fn__916002627$fn__916002628$fn__916002631")

var Lit_610 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000473")

var Lit_611 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000475")

var Lit_612 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000477")

var Lit_613 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000479__916000485")

var Lit_614 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000501")

var Lit_615 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000503__916000509")

var Lit_616 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000526")

var Lit_617 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000528__916000532")

var Lit_618 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000540__916000544")

var Lit_619 *jrt.String = jrt.Intern("class")

var Lit_620 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554")

var Lit_621 *jrt.String = jrt.Intern("B")

var Lit_622 *jrt.String = jrt.Intern("AlignedAttr")

var Lit_623 *jrt.String = jrt.Intern("FieldDecl")

var Lit_624 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000560")

var Lit_625 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000562")

var Lit_626 *jrt.String = jrt.Intern("codegen: field has incomplete type '")

var Lit_627 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000565")

var Lit_628 *jrt.String = jrt.Intern("AccessSpecDecl")

var Lit_629 *jrt.String = jrt.Intern("FriendDecl")

var Lit_630 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000585")

var Lit_631 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000587")

var Lit_632 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000597")

var Lit_633 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000600")

var Lit_634 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000602")

var Lit_635 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000605")

var Lit_636 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000625")

var Lit_637 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000627")

var Lit_638 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000637")

var Lit_639 *jrt.String = jrt.Intern("header drop: an anonymous member of")

var Lit_640 *jrt.String = jrt.Intern("(its class dropped)")

var Lit_641 *jrt.String = jrt.Intern("no_unique_address")

var Lit_642 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000587$fn__916000589")

var Lit_643 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000587$fn__916000591")

var Lit_644 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000587$fn__916000594")

var Lit_645 *jrt.String = jrt.Intern("ClassTemplateDecl")

var Lit_646 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000627$fn__916000629")

var Lit_647 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000627$fn__916000631")

var Lit_648 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$fn__916000554$fn__916000627$fn__916000634")

var Lit_649 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000479__916000485$fn__916000486")

var Lit_650 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000479__916000485$fn__916000486$iter__916000481__916000487")

var Lit_651 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000479__916000485$fn__916000486$iter__916000481__916000487$fn__916000488")

var Lit_652 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000479__916000485$fn__916000486$iter__916000481__916000487$fn__916000488$fn__916000489")

var Lit_653 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000503__916000509$fn__916000510")

var Lit_654 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000503__916000509$fn__916000510$iter__916000505__916000514")

var Lit_655 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000503__916000509$fn__916000510$fn__916000522")

var Lit_656 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000503__916000509$fn__916000510$iter__916000505__916000514$fn__916000515")

var Lit_657 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000503__916000509$fn__916000510$iter__916000505__916000514$fn__916000515$fn__916000516")

var Lit_658 *jrt.String = jrt.Intern("private")

var Lit_659 *jrt.String = jrt.Intern("public")

var Lit_660 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000528__916000532$fn__916000533")

var Lit_661 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000528__916000532$fn__916000533$fn__916000534")

var Lit_662 *jrt.String = jrt.Intern("16")

var Lit_663 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000540__916000544$fn__916000545")

var Lit_664 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000540__916000544$fn__916000545$fn__916000546")

var Lit_665 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000540__916000544$fn__916000545$fn__916000550")

var Lit_666 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_$iter__916000540__916000544$fn__916000545$fn__916000546$fn__916000547")

var Lit_667 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_enum_BANG_$fn__916000457")

var Lit_668 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_enum_BANG_$fn__916000462")

var Lit_669 *jrt.String = jrt.Intern("EnumConstantDecl")

var Lit_670 *jrt.String = jrt.Intern("Attr")

var Lit_671 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000379")

var Lit_672 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000381")

var Lit_673 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000383")

var Lit_674 *jrt.String = jrt.Intern("qualifier ")

var Lit_675 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000385")

var Lit_676 *jrt.String = jrt.Intern("CXXConstructorDecl")

var Lit_677 *jrt.String = jrt.Intern("CXXDestructorDecl")

var Lit_678 *jrt.String = jrt.Intern("CXXConversionDecl")

var Lit_679 *jrt.String = jrt.Intern("an explicit object parameter not a reference to its class")

var Lit_680 *jrt.String = jrt.Intern("an explicit object parameter named in a body")

var Lit_681 *jrt.String = jrt.Intern("static")

var Lit_682 *jrt.String = jrt.Intern("used")

var Lit_683 *jrt.String = jrt.Intern("constructor")

var Lit_684 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$iter__916000388__916000394")

var Lit_685 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000412")

var Lit_686 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000416")

var Lit_687 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000421")

var Lit_688 *jrt.String = jrt.Intern(" ctor")

var Lit_689 *jrt.String = jrt.Intern(" dtor")

var Lit_690 *jrt.String = jrt.Intern("operator<=>")

var Lit_691 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000423")

var Lit_692 *jrt.String = jrt.Intern("operator==")

var Lit_693 *jrt.String = jrt.Intern("bool")

var Lit_694 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000412$fn__916000413")

var Lit_695 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$fn__916000416$fn__916000418")

var Lit_696 *jrt.String = jrt.Intern("CXXCtorInitializer")

var Lit_697 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$iter__916000388__916000394$fn__916000395")

var Lit_698 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$iter__916000388__916000394$fn__916000395$iter__916000390__916000396")

var Lit_699 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$iter__916000388__916000394$fn__916000395$iter__916000390__916000396$fn__916000397")

var Lit_700 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_$iter__916000388__916000394$fn__916000395$iter__916000390__916000396$fn__916000397$fn__916000398")

var Lit_701 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_BANG_$fn__916000642")

var Lit_702 *jrt.String = jrt.Intern("header drop:")

var Lit_703 *jrt.String = jrt.Intern("using enum of a non-enumeration ")

var Lit_704 *jrt.String = jrt.Intern("...")

var Lit_705 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000712")

var Lit_706 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000718")

var Lit_707 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000720")

var Lit_708 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000722")

var Lit_709 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000724")

var Lit_710 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000735")

var Lit_711 *jrt.String = jrt.Intern("CPP_LOOKUP_TRACE")

var Lit_712 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000737")

var Lit_713 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000741")

var Lit_714 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000743")

var Lit_715 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000748")

var Lit_716 *jrt.String = jrt.Intern("EmptyDecl")

var Lit_717 *jrt.String = jrt.Intern("LinkageSpecDecl")

var Lit_718 *jrt.String = jrt.Intern("C")

var Lit_719 *jrt.String = jrt.Intern("UnresolvedUsingValueDecl")

var Lit_720 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000759")

var Lit_721 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000765")

var Lit_722 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000767")

var Lit_723 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000769")

var Lit_724 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000771")

var Lit_725 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000782")

var Lit_726 *jrt.String = jrt.Intern("CXXMethodDecl")

var Lit_727 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000786")

var Lit_728 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000788")

var Lit_729 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000793")

var Lit_730 *jrt.String = jrt.Intern("NamespaceDecl")

var Lit_731 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000797")

var Lit_732 *jrt.String = jrt.Intern("UnresolvedUsingTypenameDecl")

var Lit_733 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000806")

var Lit_734 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000812")

var Lit_735 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000814")

var Lit_736 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000816")

var Lit_737 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000818")

var Lit_738 *jrt.String = jrt.Intern("declaration ")

var Lit_739 *jrt.String = jrt.Intern("using")

var Lit_740 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000748$fn__916000749")

var Lit_741 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_$fn__916000793$fn__916000794")

var Lit_742 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_var_BANG_$fn__916000430")

var Lit_743 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_var_BANG_$fn__916000433")

var Lit_744 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_var_BANG_$fn__916000435")

var Lit_745 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_var_BANG_$fn__916000437")

var Lit_746 *jrt.String = jrt.Intern("extern")

var Lit_747 *jrt.String = jrt.Intern("init_priority")

var Lit_748 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_var_BANG_$fn__916000440")

var Lit_749 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_var_BANG_$fn__916000445")

var Lit_750 *jrt.String = jrt.Intern("ConstInitAttr")

var Lit_751 *jrt.String = jrt.Intern("declare")

var Lit_752 *jrt.String = jrt.Intern("arbace.cpp.sema$declared_in_QMARK_$fn__916001864")

var Lit_753 *jrt.String = jrt.Intern("arbace.cpp.sema$declared_in_QMARK_$fn__916001864$fn__916001865")

var Lit_754 *jrt.String = jrt.Intern("arbace.cpp.sema$declared_in_QMARK_$fn__916001864$fn__916001867")

var Lit_755 *jrt.String = jrt.Intern("arbace.cpp.sema$decltype_of$fn__916000136")

var Lit_756 *jrt.String = jrt.Intern("decltype(")

var Lit_757 *jrt.String = jrt.Intern("arbace.cpp.sema$decltype_of$fn__916000138")

var Lit_758 *jrt.String = jrt.Intern("arbace.cpp.sema$decltype_of$fn__916000142")

var Lit_759 *jrt.String = jrt.Intern("arbace.cpp.sema$decltype_of$fn__916000144")

var Lit_760 *jrt.String = jrt.Intern("arbace.cpp.sema$decltype_of$fn__916000146")

var Lit_761 *jrt.String = jrt.Intern(") not kept by the parser")

var Lit_762 *jrt.String = jrt.Intern("arbace.cpp.sema$decltype_of$fn__916000138$fn__916000139")

var Lit_763 *jrt.String = jrt.Intern(") dependent:")

var Lit_764 *jrt.String = jrt.Intern("\"")

var Lit_765 *jrt.String = jrt.Intern("arbace.cpp.sema$decode_string$fn__916001507")

var Lit_766 *jrt.String = jrt.Intern("arbace.cpp.sema$decode_string$fn__916001509")

var Lit_767 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002518")

var Lit_768 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002520")

var Lit_769 *jrt.String = jrt.Intern("a static or thread-local structured binding")

var Lit_770 *jrt.String = jrt.Intern("a structured binding from several values")

var Lit_771 *jrt.String = jrt.Intern("a structured binding without an initializer")

var Lit_772 *jrt.String = jrt.Intern("codegen: cannot decompose an array of unknown bound: its type is incomplete")

var Lit_773 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$iter__916002523__916002527")

var Lit_774 *jrt.String = jrt.Intern("__binding")

var Lit_775 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$bind_BANG___916002533")

var Lit_776 *jrt.String = jrt.Intern("__bindingE")

var Lit_777 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002535")

var Lit_778 *jrt.String = jrt.Intern("a structured binding of ")

var Lit_779 *jrt.String = jrt.Intern(" names for ")

var Lit_780 *jrt.String = jrt.Intern(" elements")

var Lit_781 *jrt.String = jrt.Intern(" names for a tuple-like size ")

var Lit_782 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002548")

var Lit_783 *jrt.String = jrt.Intern("get")

var Lit_784 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$iter__916002553__916002557")

var Lit_785 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002569")

var Lit_786 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002577")

var Lit_787 *jrt.String = jrt.Intern(" members")

var Lit_788 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002579")

var Lit_789 *jrt.String = jrt.Intern("a structured binding of an anonymous member")

var Lit_790 *jrt.String = jrt.Intern("std")

var Lit_791 *jrt.String = jrt.Intern("tuple_size<")

var Lit_792 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002569$fn__916002570")

var Lit_793 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002569$fn__916002572")

var Lit_794 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$fn__916002569$fn__916002572$fn__916002573")

var Lit_795 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$iter__916002523__916002527$fn__916002528")

var Lit_796 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$iter__916002523__916002527$fn__916002528$fn__916002529")

var Lit_797 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$iter__916002553__916002557$fn__916002558")

var Lit_798 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_$iter__916002553__916002557$fn__916002558$fn__916002559")

var Lit_799 *jrt.String = jrt.Intern("arbace.cpp.sema$default_ctor_init$zero_QMARK___916001458")

var Lit_800 *jrt.String = jrt.Intern("no default constructor for ")

var Lit_801 *jrt.String = jrt.Intern("call to a deleted function ")

var Lit_802 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002919")

var Lit_803 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$iter__916002922__916002926")

var Lit_804 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$iter__916002932__916002936")

var Lit_805 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$bin__916002942")

var Lit_806 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944")

var Lit_807 *jrt.String = jrt.Intern("a defaulted operator")

var Lit_808 *jrt.String = jrt.Intern(" with no usable rewritten candidate")

var Lit_809 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$iter__916002946__916002950")

var Lit_810 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$nm__916002962")

var Lit_811 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$fn__916002964")

var Lit_812 *jrt.String = jrt.Intern("partial_ordering")

var Lit_813 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$fn__916002966")

var Lit_814 *jrt.String = jrt.Intern("weak_ordering")

var Lit_815 *jrt.String = jrt.Intern("strong_ordering")

var Lit_816 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$as_rt__916002968")

var Lit_817 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$fn__916002970")

var Lit_818 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$fn__916002972")

var Lit_819 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$fn__916002975")

var Lit_820 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$iter__916002946__916002950$fn__916002951")

var Lit_821 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$fn__916002944$iter__916002946__916002950$fn__916002951$fn__916002952")

var Lit_822 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$iter__916002922__916002926$fn__916002927")

var Lit_823 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$iter__916002922__916002926$fn__916002927$fn__916002928")

var Lit_824 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$iter__916002932__916002936$fn__916002937")

var Lit_825 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_$iter__916002932__916002936$fn__916002937$fn__916002938")

var Lit_826 *jrt.String = jrt.Intern("arbace.cpp.sema$delete_dealloc$fn__916002056")

var Lit_827 *jrt.String = jrt.Intern("operator delete")

var Lit_828 *jrt.String = jrt.Intern("* of a non-pointer")

var Lit_829 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_ir$ir__916000118")

var Lit_830 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_ir$targs__916000120")

var Lit_831 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_ir$simple__916000124")

var Lit_832 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_ir$member__916000126")

var Lit_833 *jrt.String = jrt.Intern("sp")

var Lit_834 *jrt.String = jrt.Intern("Lb1E")

var Lit_835 *jrt.String = jrt.Intern("Lb0E")

var Lit_836 *jrt.String = jrt.Intern("ImplicitCastExpr")

var Lit_837 *jrt.String = jrt.Intern("operator ")

var Lit_838 *jrt.String = jrt.Intern("qu")

var Lit_839 *jrt.String = jrt.Intern("int")

var Lit_840 *jrt.String = jrt.Intern("literal ")

var Lit_841 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_ir$fn__916000129")

var Lit_842 *jrt.String = jrt.Intern("a qualifier ")

var Lit_843 *jrt.String = jrt.Intern("variable ")

var Lit_844 *jrt.String = jrt.Intern("ix")

var Lit_845 *jrt.String = jrt.Intern("sZ")

var Lit_846 *jrt.String = jrt.Intern("nx")

var Lit_847 *jrt.String = jrt.Intern("UnresolvedLookupExpr")

var Lit_848 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_ir$fn__916000131")

var Lit_849 *jrt.String = jrt.Intern("a ")

var Lit_850 *jrt.String = jrt.Intern("operator")

var Lit_851 *jrt.String = jrt.Intern("name ")

var Lit_852 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_ir$targs__916000120$fn__916000121")

var Lit_853 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_strip$fn__916000105")

var Lit_854 *jrt.String = jrt.Intern("type ")

var Lit_855 *jrt.String = jrt.Intern("xvalue")

var Lit_856 *jrt.String = jrt.Intern(" &&")

var Lit_857 *jrt.String = jrt.Intern(" &")

var Lit_858 *jrt.String = jrt.Intern("a reference to a function as an argument")

var Lit_859 *jrt.String = jrt.Intern("a structured binding captured by a lambda")

var Lit_860 *jrt.String = jrt.Intern("a variable template")

var Lit_861 *jrt.String = jrt.Intern("arbace.cpp.sema$entity_expr$fn__916001576")

var Lit_862 *jrt.String = jrt.Intern("arbace.cpp.sema$entity_expr$fn__916001578")

var Lit_863 *jrt.String = jrt.Intern("arbace.cpp.sema$entity_expr$fn__916001584")

var Lit_864 *jrt.String = jrt.Intern("arbace.cpp.sema$entity_expr$fn__916001586")

var Lit_865 *jrt.String = jrt.Intern("arbace.cpp.sema$entity_expr$fn__916001592")

var Lit_866 *jrt.String = jrt.Intern(" of kind ")

var Lit_867 *jrt.String = jrt.Intern("arbace.cpp.sema$enum_assoc$fn__916001746")

var Lit_868 *jrt.String = jrt.Intern("arbace.cpp.sema$enum_assoc$fn__916001748")

var Lit_869 *jrt.String = jrt.Intern("arbace.cpp.sema$explicit_spec$fn__916000342")

var Lit_870 *jrt.String = jrt.Intern("arbace.cpp.sema$explicit_spec$fn__916000344")

var Lit_871 *jrt.String = jrt.Intern("arbace.cpp.sema$find_allocation$fn__916002049")

var Lit_872 *jrt.String = jrt.Intern("operator new[]")

var Lit_873 *jrt.String = jrt.Intern("operator new")

var Lit_874 *jrt.String = jrt.Intern("arbace.cpp.sema$find_allocation$try_res__916002051")

var Lit_875 *jrt.String = jrt.Intern("no viable ")

var Lit_876 *jrt.String = jrt.Intern(" for ")

var Lit_877 *jrt.String = jrt.Intern(" placement arguments")

var Lit_878 *jrt.String = jrt.Intern("a placement new without a declared operator new")

var Lit_879 *jrt.String = jrt.Intern("m")

var Lit_880 *jrt.String = jrt.Intern("_Zna")

var Lit_881 *jrt.String = jrt.Intern("_Znw")

var Lit_882 *jrt.String = jrt.Intern("St11align_val_t")

var Lit_883 *jrt.String = jrt.Intern("arbace.cpp.sema$find_allocation$fn__916002053")

var Lit_884 *jrt.String = jrt.Intern("arbace.cpp.sema$find_redecl$fn__916000309")

var Lit_885 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$self__916000880")

var Lit_886 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000884")

var Lit_887 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000890")

var Lit_888 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000892")

var Lit_889 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000894")

var Lit_890 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000896")

var Lit_891 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000898")

var Lit_892 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000906")

var Lit_893 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000910")

var Lit_894 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000914")

var Lit_895 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$non_const_QMARK___916000916")

var Lit_896 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000928")

var Lit_897 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000930")

var Lit_898 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000932")

var Lit_899 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000938")

var Lit_900 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000940")

var Lit_901 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$overrides_QMARK___916000942")

var Lit_902 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$ret_class__916000944")

var Lit_903 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$ret_adj_QMARK___916000946")

var Lit_904 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000951")

var Lit_905 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000957")

var Lit_906 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000961")

var Lit_907 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000963")

var Lit_908 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000898$fn__916000899")

var Lit_909 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000906$fn__916000907")

var Lit_910 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000910$fn__916000911")

var Lit_911 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000951$fn__916000952")

var Lit_912 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000951$fn__916000954")

var Lit_913 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$fn__916000957$fn__916000958")

var Lit_914 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$non_const_QMARK___916000916$fn__916000917")

var Lit_915 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$non_const_QMARK___916000916$fn__916000917$fn__916000918")

var Lit_916 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$non_const_QMARK___916000916$fn__916000917$fn__916000920")

var Lit_917 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_$self__916000880$fn__916000881")

var Lit_918 *jrt.String = jrt.Intern("arbace.cpp.sema$fn__916001902$iter__916001896__916001903")

var Lit_919 *jrt.String = jrt.Intern("arbace.cpp.sema$fn__916001902$iter__916001896__916001903$fn__916001904")

var Lit_920 *jrt.String = jrt.Intern("arbace.cpp.sema$fn__916001902$iter__916001896__916001903$fn__916001904$iter__916001898__916001905")

var Lit_921 *jrt.String = jrt.Intern("__atomic_fetch_")

var Lit_922 *jrt.String = jrt.Intern("__atomic_")

var Lit_923 *jrt.String = jrt.Intern("_fetch")

var Lit_924 *jrt.String = jrt.Intern("arbace.cpp.sema$fn__916001902$iter__916001896__916001903$fn__916001904$iter__916001898__916001905$fn__916001906")

var Lit_925 *jrt.String = jrt.Intern("arbace.cpp.sema$fn__916001902$iter__916001896__916001903$fn__916001904$iter__916001898__916001905$fn__916001906$fn__916001907")

var Lit_926 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_ids$fn__916002013")

var Lit_927 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_matching$same_QMARK___916001125")

var Lit_928 *jrt.String = jrt.Intern("decltype")

var Lit_929 *jrt.String = jrt.Intern("noexcept(")

var Lit_930 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_type_scope$fn__916000362")

var Lit_931 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_type_scope$fn__916000367")

var Lit_932 *jrt.String = jrt.Intern("arbace.cpp.sema$friend_may_grant_QMARK_$fn__916001709")

var Lit_933 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002195")

var Lit_934 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002197")

var Lit_935 *jrt.String = jrt.Intern("a decltype(auto) parameter")

var Lit_936 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$iter__916002199__916002203")

var Lit_937 *jrt.String = jrt.Intern(" (")

var Lit_938 *jrt.String = jrt.Intern("auto")

var Lit_939 *jrt.String = jrt.Intern(", ")

var Lit_940 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002214")

var Lit_941 *jrt.String = jrt.Intern(" const")

var Lit_942 *jrt.String = jrt.Intern("operator()")

var Lit_943 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002216")

var Lit_944 *jrt.String = jrt.Intern("a generic lambda without templates")

var Lit_945 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002218")

var Lit_946 *jrt.String = jrt.Intern("the call operator template not declared")

var Lit_947 *jrt.String = jrt.Intern("Ul")

var Lit_948 *jrt.String = jrt.Intern("E")

var Lit_949 *jrt.String = jrt.Intern("_")

var Lit_950 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002220")

var Lit_951 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$iter__916002224__916002228")

var Lit_952 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002242")

var Lit_953 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002258")

var Lit_954 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002264")

var Lit_955 *jrt.String = jrt.Intern("__lambda_auto_")

var Lit_956 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002242$fn__916002246")

var Lit_957 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002242$fn__916002251")

var Lit_958 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002264$fn__916002265")

var Lit_959 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$fn__916002264$fn__916002267")

var Lit_960 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$iter__916002199__916002203$fn__916002204")

var Lit_961 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$iter__916002199__916002203$fn__916002204$fn__916002205")

var Lit_962 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$iter__916002224__916002228$fn__916002229")

var Lit_963 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$iter__916002224__916002228$fn__916002229$fn__916002230")

var Lit_964 *jrt.String = jrt.Intern("*this")

var Lit_965 *jrt.String = jrt.Intern("a capture of *this")

var Lit_966 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$iter__916002224__916002228$fn__916002229$fn__916002234")

var Lit_967 *jrt.String = jrt.Intern("capture of ")

var Lit_968 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr$iter__916002224__916002228$fn__916002229$fn__916002230$fn__916002231")

var Lit_969 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_conv_BANG_$fn__916001169")

var Lit_970 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_conv_BANG_$iter__916001172__916001176")

var Lit_971 *jrt.String = jrt.Intern("__invoke")

var Lit_972 *jrt.String = jrt.Intern("operator function")

var Lit_973 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_conv_BANG_$fn__916001182")

var Lit_974 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_conv_BANG_$iter__916001172__916001176$fn__916001177")

var Lit_975 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_conv_BANG_$iter__916001172__916001176$fn__916001177$fn__916001178")

var Lit_976 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_declared$iter__916002173__916002177")

var Lit_977 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_declared$fn__916002183")

var Lit_978 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_declared$fn__916002185")

var Lit_979 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_declared$iter__916002173__916002177$fn__916002178")

var Lit_980 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_declared$iter__916002173__916002177$fn__916002178$fn__916002179")

var Lit_981 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_names$walk__916002162")

var Lit_982 *jrt.String = jrt.Intern("arbace.cpp.sema$global_init$fn__916003082")

var Lit_983 *jrt.String = jrt.Intern("arbace.cpp.sema$gnu_attr_arg$fn__916000285")

var Lit_984 *jrt.String = jrt.Intern("arbace.cpp.sema$has_ctor_of_QMARK_$fn__916000858")

var Lit_985 *jrt.String = jrt.Intern("arbace.cpp.sema$header_entities$fn__916000087")

var Lit_986 *jrt.String = jrt.Intern("an overloaded header function ")

var Lit_987 *jrt.String = jrt.Intern("arbace.cpp.sema$ics$fn__916001230")

var Lit_988 *jrt.String = jrt.Intern("arbace.cpp.sema$ics$fn__916001232")

var Lit_989 *jrt.String = jrt.Intern("arbace.cpp.sema$ics$converts_QMARK___916001236")

var Lit_990 *jrt.String = jrt.Intern("arbace.cpp.sema$ics$fn__916001240")

var Lit_991 *jrt.String = jrt.Intern("arbace.cpp.sema$ics$converts_QMARK___916001236$fn__916001237")

var Lit_992 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_$iter__916001599__916001603")

var Lit_993 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_$fn__916001609")

var Lit_994 *jrt.String = jrt.Intern(" implicit ")

var Lit_995 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_$fn__916001618")

var Lit_996 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_$fn__916001620")

var Lit_997 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_$fn__916001625")

var Lit_998 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_$fn__916001627")

var Lit_999 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_$iter__916001599__916001603$fn__916001604")

var Lit_1000 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_$iter__916001599__916001603$fn__916001604$fn__916001605")

var Lit_1001 *jrt.String = jrt.Intern("_ZdaPv")

var Lit_1002 *jrt.String = jrt.Intern("_ZdlPv")

var Lit_1003 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_fn_BANG_$fn__916000852")

var Lit_1004 *jrt.String = jrt.Intern("arbace.cpp.sema$inherit_through_BANG_$below_QMARK___916001425")

var Lit_1005 *jrt.String = jrt.Intern("an inherited constructor's base")

var Lit_1006 *jrt.String = jrt.Intern("arbace.cpp.sema$inherit_through_BANG_$below_QMARK___916001425$fn__916001426")

var Lit_1007 *jrt.String = jrt.Intern("arbace.cpp.sema$inheriting_ctor_BANG_$fn__916001421")

var Lit_1008 *jrt.String = jrt.Intern("a list's element does not convert to the initializer_list's")

var Lit_1009 *jrt.String = jrt.Intern("a non-const reference to a list's temporary")

var Lit_1010 *jrt.String = jrt.Intern("a list for a reference")

var Lit_1011 *jrt.String = jrt.Intern("a reference from arguments")

var Lit_1012 *jrt.String = jrt.Intern("no function of the set matches the reference")

var Lit_1013 *jrt.String = jrt.Intern("reference initialization is ambiguous (two conversion functions bind it, neither better)")

var Lit_1014 *jrt.String = jrt.Intern("a non-const reference to a temporary")

var Lit_1015 *jrt.String = jrt.Intern("several values for a scalar")

var Lit_1016 *jrt.String = jrt.Intern("too many initializers for a complex")

var Lit_1017 *jrt.String = jrt.Intern("arbace.cpp.sema$init_for$fn__916001483")

var Lit_1018 *jrt.String = jrt.Intern("arbace.cpp.sema$init_for$fn__916001485")

var Lit_1019 *jrt.String = jrt.Intern("arbace.cpp.sema$init_for$fn__916001487")

var Lit_1020 *jrt.String = jrt.Intern("arbace.cpp.sema$init_for$fn__916001489")

var Lit_1021 *jrt.String = jrt.Intern("arbace.cpp.sema$init_for$fn__916001491")

var Lit_1022 *jrt.String = jrt.Intern("too many initializers")

var Lit_1023 *jrt.String = jrt.Intern("arbace.cpp.sema$init_for$fn__916001493")

var Lit_1024 *jrt.String = jrt.Intern("an array from an expression")

var Lit_1025 *jrt.String = jrt.Intern("cannot initialize a variable of type '")

var Lit_1026 *jrt.String = jrt.Intern("' with a value of another type")

var Lit_1027 *jrt.String = jrt.Intern("arbace.cpp.sema$init_for$fn__916001493$fn__916001495")

var Lit_1028 *jrt.String = jrt.Intern("arbace.cpp.sema$init_kid$fn__916000295")

var Lit_1029 *jrt.String = jrt.Intern("arbace.cpp.sema$init_list_ctors$fn__916001362")

var Lit_1030 *jrt.String = jrt.Intern("initializer_list")

var Lit_1031 *jrt.String = jrt.Intern("long long")

var Lit_1032 *jrt.String = jrt.Intern("unsigned int")

var Lit_1033 *jrt.String = jrt.Intern("unsigned long long")

var Lit_1034 *jrt.String = jrt.Intern("unsigned long")

var Lit_1035 *jrt.String = jrt.Intern("long")

var Lit_1036 *jrt.String = jrt.Intern("arbace.cpp.sema$kids$fn__916000277")

var Lit_1037 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002088")

var Lit_1038 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002090")

var Lit_1039 *jrt.String = jrt.Intern("a generic lambda")

var Lit_1040 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002092")

var Lit_1041 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002097")

var Lit_1042 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002100")

var Lit_1043 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$iter__916002103__916002107")

var Lit_1044 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002121")

var Lit_1045 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002133")

var Lit_1046 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002135")

var Lit_1047 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002141")

var Lit_1048 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$iter__916002147__916002151")

var Lit_1049 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002121$fn__916002125")

var Lit_1050 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002121$fn__916002130")

var Lit_1051 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002141$fn__916002142")

var Lit_1052 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$fn__916002141$fn__916002144")

var Lit_1053 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$iter__916002103__916002107$fn__916002108")

var Lit_1054 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$iter__916002103__916002107$fn__916002108$fn__916002109")

var Lit_1055 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$iter__916002103__916002107$fn__916002108$fn__916002113")

var Lit_1056 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$iter__916002103__916002107$fn__916002108$fn__916002109$fn__916002110")

var Lit_1057 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$iter__916002147__916002151$fn__916002152")

var Lit_1058 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr$iter__916002147__916002151$fn__916002152$fn__916002153")

var Lit_1059 *jrt.String = jrt.Intern("arbace.cpp.sema$list_ctor_viable_QMARK_$fn__916001223")

var Lit_1060 *jrt.String = jrt.Intern("arbace.cpp.sema$list_ctor_viable_QMARK_$fn__916001225")

var Lit_1061 *jrt.String = jrt.Intern("arbace.cpp.sema$local_var_BANG_$fn__916002495")

var Lit_1062 *jrt.String = jrt.Intern("arbace.cpp.sema$local_var_BANG_$fn__916002495$fn__916002496")

var Lit_1063 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup$fn__916000048")

var Lit_1064 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup$fn__916000056")

var Lit_1065 *jrt.String = jrt.Intern("lookup")

var Lit_1066 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup$fn__916000048$fn__916000049")

var Lit_1067 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup$fn__916000048$fn__916000051")

var Lit_1068 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup$fn__916000048$fn__916000051$fn__916000052")

var Lit_1069 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup_qualified$fn__916000259")

var Lit_1070 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup_qualified$tid_type__916000271")

var Lit_1071 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup_qualified$fn__916000273")

var Lit_1072 *jrt.String = jrt.Intern("no scope ")

var Lit_1073 *jrt.String = jrt.Intern("arbace.cpp.sema$member_expr$fn__916001717")

var Lit_1074 *jrt.String = jrt.Intern("arbace.cpp.sema$member_expr$fn__916001719")

var Lit_1075 *jrt.String = jrt.Intern("member of a non-class")

var Lit_1076 *jrt.String = jrt.Intern("no member ")

var Lit_1077 *jrt.String = jrt.Intern("arbace.cpp.sema$member_expr$fn__916001725")

var Lit_1078 *jrt.String = jrt.Intern("arbace.cpp.sema$member_expr$fn__916001731")

var Lit_1079 *jrt.String = jrt.Intern("member ")

var Lit_1080 *jrt.String = jrt.Intern("->")

var Lit_1081 *jrt.String = jrt.Intern("no operator-> of ")

var Lit_1082 *jrt.String = jrt.Intern("arbace.cpp.sema$method_set_of$fn__916001670")

var Lit_1083 *jrt.String = jrt.Intern("arbace.cpp.sema$mode_type$fn__916000290")

var Lit_1084 *jrt.String = jrt.Intern("the mode ")

var Lit_1085 *jrt.String = jrt.Intern("arbace.cpp.sema$name_expr$lk__916001633")

var Lit_1086 *jrt.String = jrt.Intern("a 128-bit value outside 64 bits")

var Lit_1087 *jrt.String = jrt.Intern("arbace.cpp.sema$new_expr$fn__916002065")

var Lit_1088 *jrt.String = jrt.Intern("arbace.cpp.sema$new_expr$fn__916002067")

var Lit_1089 *jrt.String = jrt.Intern("arbace.cpp.sema$no_operator_BANG_$fn__916001876")

var Lit_1090 *jrt.String = jrt.Intern("arbace.cpp.sema$no_operator_BANG_$fn__916001878")

var Lit_1091 *jrt.String = jrt.Intern("arbace.cpp.sema$no_operator_BANG_$fn__916001880")

var Lit_1092 *jrt.String = jrt.Intern("arbace.cpp.sema$no_operator_BANG_$fn__916001882")

var Lit_1093 *jrt.String = jrt.Intern("no match for '")

var Lit_1094 *jrt.String = jrt.Intern("' (operand types ")

var Lit_1095 *jrt.String = jrt.Intern("arbace.cpp.sema$no_operator_BANG_$fn__916001884")

var Lit_1096 *jrt.String = jrt.Intern("arbace.cpp.sema$node_children$fn__916002159")

var Lit_1097 *jrt.String = jrt.Intern("arbace.cpp.sema$noexcept_of$fn__916000313")

var Lit_1098 *jrt.String = jrt.Intern("arbace.cpp.sema$noexcept_of$fn__916000315")

var Lit_1099 *jrt.String = jrt.Intern("true")

var Lit_1100 *jrt.String = jrt.Intern("false")

var Lit_1101 *jrt.String = jrt.Intern("noexcept:")

var Lit_1102 *jrt.String = jrt.Intern("arbace.cpp.sema$noexcept_of$fn__916000317")

var Lit_1103 *jrt.String = jrt.Intern("arbace.cpp.sema$noexcept_of$fn__916000321")

var Lit_1104 *jrt.String = jrt.Intern("arbace.cpp.sema$noexcept_of$fn__916000317$fn__916000318")

var Lit_1105 *jrt.String = jrt.Intern("arbace.cpp.sema$noreturn_node_QMARK_$fn__916000336")

var Lit_1106 *jrt.String = jrt.Intern("CPP_NC_STACK")

var Lit_1107 *jrt.String = jrt.Intern("arbace.cpp.sema$nrvo_var$walk__916002816")

var Lit_1108 *jrt.String = jrt.Intern("arbace.cpp.sema$ns_scope_BANG_$fn__916000300")

var Lit_1109 *jrt.String = jrt.Intern(" ns ")

var Lit_1110 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001961")

var Lit_1111 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001966")

var Lit_1112 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001968")

var Lit_1113 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001970")

var Lit_1114 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001974")

var Lit_1115 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001976")

var Lit_1116 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001978")

var Lit_1117 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001980")

var Lit_1118 *jrt.String = jrt.Intern("CPP_OP_TRACE")

var Lit_1119 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001982")

var Lit_1120 *jrt.String = jrt.Intern("no operator=")

var Lit_1121 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001987")

var Lit_1122 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001970$fn__916001971")

var Lit_1123 *jrt.String = jrt.Intern("no candidates for")

var Lit_1124 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001982$fn__916001983")

var Lit_1125 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001987$fn__916001988")

var Lit_1126 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001987$fn__916001990")

var Lit_1127 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call$fn__916001987$fn__916001992")

var Lit_1128 *jrt.String = jrt.Intern("arbace.cpp.sema$ordering_type$fn__916001644")

var Lit_1129 *jrt.String = jrt.Intern("<=> without <compare>")

var Lit_1130 *jrt.String = jrt.Intern("arbace.cpp.sema$own_names$fn__916000040")

var Lit_1131 *jrt.String = jrt.Intern("arbace.cpp.sema$own_names$fn__916000042")

var Lit_1132 *jrt.String = jrt.Intern("arbace.cpp.sema$param_nodes$fn__916000305")

var Lit_1133 *jrt.String = jrt.Intern("arbace.cpp.sema$placeholder_split$fn__916000645")

var Lit_1134 *jrt.String = jrt.Intern("arbace.cpp.sema$placeholder_split$fn__916000647")

var Lit_1135 *jrt.String = jrt.Intern("arbace.cpp.sema$placeholder_split$fn__916000649")

var Lit_1136 *jrt.String = jrt.Intern("cg-prelude")

var Lit_1137 *jrt.String = jrt.Intern(".cpp")

var Lit_1138 *jrt.String = jrt.Intern("c++23")

var Lit_1139 *jrt.String = jrt.Intern("header type ")

var Lit_1140 *jrt.String = jrt.Intern("arbace.cpp.sema$qualifier_tid_before$fn__916000245")

var Lit_1141 *jrt.String = jrt.Intern("arbace.cpp.sema$qualifier_tid_before$fn__916000247")

var Lit_1142 *jrt.String = jrt.Intern("arbace.cpp.sema$qualifier_tid_before$fn__916000252")

var Lit_1143 *jrt.String = jrt.Intern("arbace.cpp.sema$range_for_class$ref__916002644")

var Lit_1144 *jrt.String = jrt.Intern("arbace.cpp.sema$range_for_class$local_BANG___916002646")

var Lit_1145 *jrt.String = jrt.Intern("__range1")

var Lit_1146 *jrt.String = jrt.Intern("arbace.cpp.sema$range_for_class$call__916002648")

var Lit_1147 *jrt.String = jrt.Intern("begin")

var Lit_1148 *jrt.String = jrt.Intern("end")

var Lit_1149 *jrt.String = jrt.Intern("__begin1")

var Lit_1150 *jrt.String = jrt.Intern("__end1")

var Lit_1151 *jrt.String = jrt.Intern("arbace.cpp.sema$ref_conv_for$iter__916001205__916001209")

var Lit_1152 *jrt.String = jrt.Intern("arbace.cpp.sema$ref_conv_for$better_QMARK___916001215")

var Lit_1153 *jrt.String = jrt.Intern("arbace.cpp.sema$ref_conv_for$fn__916001217")

var Lit_1154 *jrt.String = jrt.Intern("arbace.cpp.sema$ref_conv_for$fn__916001217$fn__916001218")

var Lit_1155 *jrt.String = jrt.Intern("arbace.cpp.sema$ref_conv_for$iter__916001205__916001209$fn__916001210")

var Lit_1156 *jrt.String = jrt.Intern("arbace.cpp.sema$ref_conv_for$iter__916001205__916001209$fn__916001210$fn__916001211")

var Lit_1157 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_dealloc$fn__916002018")

var Lit_1158 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_dealloc$score__916002020")

var Lit_1159 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_dealloc$fn__916002022")

var Lit_1160 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload$fn__916001244")

var Lit_1161 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$iter__916001251__916001255")

var Lit_1162 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$better__916001273")

var Lit_1163 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$fn__916001283")

var Lit_1164 *jrt.String = jrt.Intern(" (implicitly deleted)")

var Lit_1165 *jrt.String = jrt.Intern("no viable function (a template's deduction unsure) among ")

var Lit_1166 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$fn__916001290")

var Lit_1167 *jrt.String = jrt.Intern("no viable function (a generic lambda's conversion not modeled) among ")

var Lit_1168 *jrt.String = jrt.Intern("no viable function among ")

var Lit_1169 *jrt.String = jrt.Intern("ambiguous call (")

var Lit_1170 *jrt.String = jrt.Intern(" viable)")

var Lit_1171 *jrt.String = jrt.Intern(": ")

var Lit_1172 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$fn__916001302")

var Lit_1173 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$better__916001273$fn__916001280")

var Lit_1174 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$fn__916001283$fn__916001284")

var Lit_1175 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$fn__916001290$fn__916001294")

var Lit_1176 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$fn__916001290$fn__916001294$fn__916001297")

var Lit_1177 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$iter__916001251__916001255$fn__916001256")

var Lit_1178 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$iter__916001251__916001255$fn__916001256$fn__916001257")

var Lit_1179 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$iter__916001251__916001255$fn__916001256$fn__916001267")

var Lit_1180 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_$iter__916001251__916001255$fn__916001256$fn__916001257$fn__916001261")

var Lit_1181 *jrt.String = jrt.Intern("a GNU vector type (")

var Lit_1182 *jrt.String = jrt.Intern("unknown type ")

var Lit_1183 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form$fn__916000155")

var Lit_1184 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form$fn__916000157")

var Lit_1185 *jrt.String = jrt.Intern("nullptr")

var Lit_1186 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form$fn__916000159")

var Lit_1187 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form$cv__916000161")

var Lit_1188 *jrt.String = jrt.Intern("template-id ")

var Lit_1189 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form$fn__916000170")

var Lit_1190 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form$fn__916000175")

var Lit_1191 *jrt.String = jrt.Intern("a scope of a non-class ")

var Lit_1192 *jrt.String = jrt.Intern("type form ")

var Lit_1193 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form$cv__916000179")

var Lit_1194 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form$fn__916000175$fn__916000176")

var Lit_1195 *jrt.String = jrt.Intern("arbace.cpp.sema$returned_immediate$fn__916003057")

var Lit_1196 *jrt.String = jrt.Intern("arbace.cpp.sema$returned_immediate$fn__916003059")

var Lit_1197 *jrt.String = jrt.Intern("arbace.cpp.sema$returned_immediate$fn__916003061")

var Lit_1198 *jrt.String = jrt.Intern("arbace.cpp.sema$rewritten_relational$three__916001999")

var Lit_1199 *jrt.String = jrt.Intern("arbace.cpp.sema$rewritten_relational$three__916001999$fn__916002000")

var Lit_1200 *jrt.String = jrt.Intern("arbace.cpp.sema$rv$fn__916001130")

var Lit_1201 *jrt.String = jrt.Intern("arbace.cpp.sema$sassert_unsure_node_QMARK_$fn__916003068")

var Lit_1202 *jrt.String = jrt.Intern("arbace.cpp.sema$sassert_unsure_node_QMARK_$fn__916003070")

var Lit_1203 *jrt.String = jrt.Intern("arbace.cpp.sema$sassert_unsure_node_QMARK_$fn__916003072")

var Lit_1204 *jrt.String = jrt.Intern("a braced functional cast of a scalar type with ")

var Lit_1205 *jrt.String = jrt.Intern("arbace.cpp.sema$std_init_list$fn__916001356")

var Lit_1206 *jrt.String = jrt.Intern("arbace.cpp.sema$std_init_list$fn__916001358")

var Lit_1207 *jrt.String = jrt.Intern("LabelStmt")

var Lit_1208 *jrt.String = jrt.Intern("CXXForRangeStmt")

var Lit_1209 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002666")

var Lit_1210 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002668")

var Lit_1211 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002670")

var Lit_1212 *jrt.String = jrt.Intern("a braced range of elements of different types")

var Lit_1213 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002672")

var Lit_1214 *jrt.String = jrt.Intern("a braced range without <initializer_list>")

var Lit_1215 *jrt.String = jrt.Intern("a braced range")

var Lit_1216 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002674")

var Lit_1217 *jrt.String = jrt.Intern("a range for over a non-array")

var Lit_1218 *jrt.String = jrt.Intern("__begin")

var Lit_1219 *jrt.String = jrt.Intern("__end")

var Lit_1220 *jrt.String = jrt.Intern("CaseStmt")

var Lit_1221 *jrt.String = jrt.Intern("GCCAsmStmt")

var Lit_1222 *jrt.String = jrt.Intern("statement GCCAsmStmt")

var Lit_1223 *jrt.String = jrt.Intern("an asm statement with outputs or labels")

var Lit_1224 *jrt.String = jrt.Intern("\"\"")

var Lit_1225 *jrt.String = jrt.Intern("an asm statement's template ")

var Lit_1226 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002680")

var Lit_1227 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002685")

var Lit_1228 *jrt.String = jrt.Intern("WhileStmt")

var Lit_1229 *jrt.String = jrt.Intern("a while condition's declaration (destroyed each iteration)")

var Lit_1230 *jrt.String = jrt.Intern("NullStmt")

var Lit_1231 *jrt.String = jrt.Intern("CompoundStmt")

var Lit_1232 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002690")

var Lit_1233 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002693")

var Lit_1234 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002695")

var Lit_1235 *jrt.String = jrt.Intern("AttributedStmt")

var Lit_1236 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$iter__916002700__916002704")

var Lit_1237 *jrt.String = jrt.Intern("ContinueStmt")

var Lit_1238 *jrt.String = jrt.Intern("DefaultStmt")

var Lit_1239 *jrt.String = jrt.Intern("ForStmt")

var Lit_1240 *jrt.String = jrt.Intern("a for condition's declaration")

var Lit_1241 *jrt.String = jrt.Intern("SwitchStmt")

var Lit_1242 *jrt.String = jrt.Intern("a switch condition's declaration")

var Lit_1243 *jrt.String = jrt.Intern("DoStmt")

var Lit_1244 *jrt.String = jrt.Intern("DeclStmt")

var Lit_1245 *jrt.String = jrt.Intern("GotoStmt")

var Lit_1246 *jrt.String = jrt.Intern("ReturnStmt")

var Lit_1247 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002725")

var Lit_1248 *jrt.String = jrt.Intern("BreakStmt")

var Lit_1249 *jrt.String = jrt.Intern("IfStmt")

var Lit_1250 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$br__916002730")

var Lit_1251 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002732")

var Lit_1252 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$fn__916002740")

var Lit_1253 *jrt.String = jrt.Intern("Expr")

var Lit_1254 *jrt.String = jrt.Intern("Operator")

var Lit_1255 *jrt.String = jrt.Intern("Literal")

var Lit_1256 *jrt.String = jrt.Intern("statement ")

var Lit_1257 *jrt.String = jrt.Intern("an asm operand's constraint ")

var Lit_1258 *jrt.String = jrt.Intern("an asm operand of ")

var Lit_1259 *jrt.String = jrt.Intern("an asm clobber ")

var Lit_1260 *jrt.String = jrt.Intern("codegen: constexpr if condition is not a constant expression (")

var Lit_1261 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$iter__916002700__916002704$fn__916002705")

var Lit_1262 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt$iter__916002700__916002704$fn__916002705$fn__916002706")

var Lit_1263 *jrt.String = jrt.Intern("arbace.cpp.sema$str_units$fn__916001528")

var Lit_1264 *jrt.String = jrt.Intern("#")

var Lit_1265 *jrt.String = jrt.Intern("arbace.cpp.sema$strip_positions$iter__916003085__916003089")

var Lit_1266 *jrt.String = jrt.Intern("arbace.cpp.sema$strip_positions$iter__916003085__916003089$fn__916003090")

var Lit_1267 *jrt.String = jrt.Intern("arbace.cpp.sema$strip_positions$iter__916003085__916003089$fn__916003090$fn__916003091")

var Lit_1268 *jrt.String = jrt.Intern("__attribute__")

var Lit_1269 *jrt.String = jrt.Intern("((")

var Lit_1270 *jrt.String = jrt.Intern("arbace.cpp.sema$strip_type_attrs$fn__916000182")

var Lit_1271 *jrt.String = jrt.Intern("arbace.cpp.sema$sure_assoc_nss$ns_of__916001844")

var Lit_1272 *jrt.String = jrt.Intern("arbace.cpp.sema$sure_assoc_nss$cls_BANG___916001846")

var Lit_1273 *jrt.String = jrt.Intern("arbace.cpp.sema$sure_assoc_nss$fn__916001856")

var Lit_1274 *jrt.String = jrt.Intern("arbace.cpp.sema$sure_assoc_nss$fn__916001858")

var Lit_1275 *jrt.String = jrt.Intern("arbace.cpp.sema$sure_assoc_nss$fn__916001860")

var Lit_1276 *jrt.String = jrt.Intern("ISO-8859-1")

var Lit_1277 *jrt.String = jrt.Intern("this outside a method")

var Lit_1278 *jrt.String = jrt.Intern("<=> of ")

var Lit_1279 *jrt.String = jrt.Intern("codegen: the read's time cap passed")

var Lit_1280 *jrt.String = jrt.Intern("ambiguous conversion from derived class '")

var Lit_1281 *jrt.String = jrt.Intern("' to base class '")

var Lit_1282 *jrt.String = jrt.Intern("arbace.cpp.sema$trivial_assign_QMARK_$fn__916000846")

var Lit_1283 *jrt.String = jrt.Intern("arbace.cpp.sema$trivial_copy_QMARK_$fn__916000842")

var Lit_1284 *jrt.String = jrt.Intern("arbace.cpp.sema$type_entity$fn__916000100")

var Lit_1285 *jrt.String = jrt.Intern("\\")

var Lit_1286 *jrt.String = jrt.Intern("arbace.cpp.sema$ucn_name$fn__916000031")

var Lit_1287 *jrt.String = jrt.Intern("arbace.cpp.sema$undeclared_call_BANG_$fn__916001893")

var Lit_1288 *jrt.String = jrt.Intern("use of undeclared identifier '")

var Lit_1289 *jrt.String = jrt.Intern("arbace.cpp.sema$unfinished_targs_QMARK_$fn__916000348")

var Lit_1290 *jrt.String = jrt.Intern("arbace.cpp.sema$user_conv$fn__916001312")

var Lit_1291 *jrt.String = jrt.Intern("arbace.cpp.sema$user_conv$fn__916001314")

var Lit_1292 *jrt.String = jrt.Intern("arbace.cpp.sema$user_conv$tm_QMARK___916001316")

var Lit_1293 *jrt.String = jrt.Intern("no viable conversion from '")

var Lit_1294 *jrt.String = jrt.Intern("' to ")

var Lit_1295 *jrt.String = jrt.Intern("no conversion function of ")

var Lit_1296 *jrt.String = jrt.Intern("arbace.cpp.sema$user_conv$tm_QMARK___916001316$fn__916001318")

var Lit_1297 *jrt.String = jrt.Intern("arbace.cpp.sema$user_conv$tm_QMARK___916001316$fn__916001325")

var Lit_1298 *jrt.String = jrt.Intern("arbace.cpp.sema$user_conv$tm_QMARK___916001316$fn__916001318$fn__916001322")

var Lit_1299 *jrt.String = jrt.Intern("arbace.cpp.sema$user_ctors$fn__916000828")

var Lit_1300 *jrt.String = jrt.Intern("__va_list_tag")

var Lit_1301 *jrt.String = jrt.Intern("arbace.cpp.sema$va_list_tag$fn__916000071")

var Lit_1302 *jrt.String = jrt.Intern("gp_offset")

var Lit_1303 *jrt.String = jrt.Intern("fp_offset")

var Lit_1304 *jrt.String = jrt.Intern("overflow_arg_area")

var Lit_1305 *jrt.String = jrt.Intern("reg_save_area")

var Lit_1306 *jrt.String = jrt.Intern("arbace.cpp.sema$var_const_int$fn__916000981")

var Lit_1307 *jrt.String = jrt.Intern("a shift by ")

var Lit_1308 *jrt.String = jrt.Intern("arbace.cpp.sema$wide_units$hex_QMARK___916001514")

var Lit_1309 *jrt.String = jrt.Intern("arbace.cpp.sema$wide_units$fn__916001521")

var Lit_1310 *jrt.String = jrt.Intern("arbace.cpp.sema$wide_units$fn__916001523")

var Lit_1311 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,dynamickn8,arglistsyn3,stdkn3,tagyn4,longkn7,privateyn2,idyn1,fyn1,&yn4,argsyn4,kindyn6,parentkn2,asyn4,moreyn6,Stringyn16,java.lang.Stringyn5,scopeyn1,ekn8,declaredyn25,java.util.IdentityHashMapyn12,unqualified?yn1,tyn5,partsyn4,boolkn4,boolyn7,char8_tkn5,char8yn11,long-doublekn7,ldoubleyn8,unsignedkn4,uintyn8,char16_tkn6,char16yn8,char32_tkn6,char32yn13,unsigned-charkn5,ucharyn4,charkn4,charyn13,unsigned-longkn5,ulongyn10,__float128kn8,float128ys8,decltype7,nullptrkn7,nullptryn8,_Float16kn7,float16kn4,longyn6,doublekn6,doubleyn5,shortkn5,shortyn3,intkn3,intyn18,unsigned-long-longkn6,ullongyn5,floatkn5,floatyn11,__uint128_tkn4,u128yn9,long-longkn5,llongyn7,wchar_tkn5,wcharyn10,__int128_tkn4,i128yn9,nullptr_tyn4,voidkn4,voidyn11,signed-charkn5,scharyn8,__int128ys3,std9,nullptr_tyn14,unsigned-shortkn6,ushortyn17,unsigned-__int128yn3,symyn2,esyn1,xyn1,nyn1,syn2,qtyn1,lyn12,java.io.Fileyn4,fileyn1,kyn7,global?v11,arbace.core5,in-nsMyn15,arbace.cpp.semam2,R0,s1344,The code generator's semantic analysis (doc/cpp/CODEGEN.md §3): the native parser's tree (clang's AST as data,\n  arbace.repr.cpp.native) analyzed as clang's Sema analyzes it for the slice of C++ CODEGEN.md §6 names -- the\n  declarations entered into scopes (namespaces, classes, blocks), every expression typed with its value category and\n  its implicit conversions written out (lvalue-to-rvalue, promotions, the usual arithmetic conversions, decay, the\n  pointer conversions, derived-to-base), names looked up as [basic.lookup] says (unqualified, qualified, class members\n  through the bases, the operators' ADL in the classes' namespaces), overload resolution by the implicit conversion\n  sequences' ranks ([over.match.best], [over.ics.rank]: exact, promotion, conversion, user-defined, ellipsis, with the\n  reference bindings' qualification tie-break), initialization ([dcl.init]: default, value, copy, direct, list and\n  aggregate initialization, reference binding with temporaries materialized), the implicit special members\n  ([class.default.ctor], [class.copy.ctor], [class.dtor]: declared, trivial or defined), virtual functions and their\n  overriders. The result is a program of typed functions and variables that arbace.cpp.codegen writes as LLVM forms.\n  Anything outside the slice is refused: (ex-info ... {:codegen/refused class}).m2,R0,s1344,The code generator's semantic analysis (doc/cpp/CODEGEN.md §3): the native parser's tree (clang's AST as data,\n  arbace.repr.cpp.native) analyzed as clang's Sema analyzes it for the slice of C++ CODEGEN.md §6 names -- the\n  declarations entered into scopes (namespaces, classes, blocks), every expression typed with its value category and\n  its implicit conversions written out (lvalue-to-rvalue, promotions, the usual arithmetic conversions, decay, the\n  pointer conversions, derived-to-base), names looked up as [basic.lookup] says (unqualified, qualified, class members\n  through the bases, the operators' ADL in the classes' namespaces), overload resolution by the implicit conversion\n  sequences' ranks ([over.match.best], [over.ics.rank]: exact, promotion, conversion, user-defined, ellipsis, with the\n  reference bindings' qualification tie-break), initialization ([dcl.init]: default, value, copy, direct, list and\n  aggregate initialization, reference binding with temporaries materialized), the implicit special members\n  ([class.default.ctor], [class.copy.ctor], [class.dtor]: declared, trivial or defined), virtual functions and their\n  overriders. The result is a program of typed functions and variables that arbace.cpp.codegen writes as LLVM forms.\n  Anything outside the slice is refused: (ex-info ... {:codegen/refused class}).R1,v11,arbace.core20,*warn-on-reflection*v15,arbace.cpp.sema4,failv14,arbace.cpp.abi4,failm6,R2,i21,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,hooksv11,arbace.core4,atomm6,R2,i28,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,*src*m8,R5,TR2,i33,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema4,*at*m8,R5,TR2,i36,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,*on-refusal*m8,R5,TR2,i37,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,*pedantic-errors*m8,R5,TR2,i38,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,checking?m8,R6,L1,V0,R2,i41,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,*deadline*l0,m8,R5,TR2,i45,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,tick!m8,R6,L1,V0,R2,i46,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,*drops*m8,R5,TR2,i51,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,*member-access*m8,R5,TR2,i53,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,*cxx-year*l17,m8,R5,TR2,i56,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,cxx-yearm10,R6,L1,MV1,R7,m2,R8,R9,R0,s95,The year of the standard `std` names (c++98 and c++03 as 3, gnu++NN as c++NN; 17 when unknown).R2,i58,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,*fns*m8,R5,TR2,i64,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,*vars*m8,R5,TR2,i65,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,*ids*m8,R5,TR2,i66,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,*order*m8,R5,TR2,i67,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,next-idm10,R10,TR6,L1,V0,R2,i69,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema3,fndm8,R6,L1,V1,R11,R2,i70,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema4,var*m8,R6,L1,V1,R11,R2,i71,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,upd-fn!m10,R10,TR6,L1,V4,R11,R12,R13,R14,R2,i72,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,upd-var!m10,R10,TR6,L1,V4,R11,R12,R13,R14,R2,i73,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,new-scopem10,R10,TR6,L1,V4,R15,R16,R13,m2,R17,R18,R2,i77,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,ucn-namem10,R6,L1,MV1,Myn2,nmm2,R8,R19,m2,R8,R20,R0,s257,A name with its universal character names as their characters ([lex.charset]/2, [lex.name]: `\\u00C1`, `\\u00c1` and\n  `\\U000000C1` one identifier, as clang's IdentifierInfo holds it); a name without a backslash itself (cpp-route: g++.dg's\n  other/ucnid-1.C).R2,i82,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,enter!m10,R10,TR6,L1,V3,R21,Myn2,nmm2,R8,R19,R22,R2,i92,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,*cutoff*m8,R5,TR2,i98,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,drop-countm8,R2,i99,R3,i1,R4,s18,arbace/cpp/sema.aeR0,s224,cpp-s8: the header declarations dropped so far (each drop counted, a later round's success not subtracted): a\n  provisional instance's test of whether a member of its definition was dropped (template.ae's declare-instance!).v15,arbace.cpp.sema11,*last-anon*m8,R5,TR2,i104,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,class-lookupm8,R23,TR2,i106,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,own-namesm12,R10,TR6,L2,V2,R21,Myn2,nmm2,R8,R19,V3,R21,Myn2,nmm2,R8,R19,Myn4,seenm2,R8,R24,R0,s334,The entities `nm` names in `scope` and, transitively, in the namespaces its using-directives nominate, each namespace\n  once ([namespace.udir]/2-3, [basic.lookup.unqual]/2: the nominated sets' union; a cycle of directives -- libsupc++'s\n  tinfo.h nominating __cxxabiv1 from inside a namespace __cxxabiv1 nominates -- is the same set).R2,i108,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,find-herem12,R10,TR6,L2,V2,R21,Myn2,nmm2,R8,R19,V3,R21,Myn2,nmm2,R8,R19,R25,R0,s92,The entities `nm` names in `scope` itself (a class: with its bases', [class.member.lookup]).R2,i120,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,header-entitiesm8,R23,TR2,i128,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,builtin-entitiesm8,R23,TR2,i130,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,lookupm10,R6,L1,V2,R21,Myn2,nmm2,R8,R19,R0,s137,Unqualified lookup: the entities of the first scope outward that declares `nm` (the headers' last, through the\n  native parser's scopes).R2,i132,R3,i1,R4,s18,arbace/cpp/sema.aem10,R6,L2,V2,R11,Myn2,nmm2,R8,R19,V3,R11,Myn2,nmm2,R8,R19,R25,R0,s466,[[class-id entity] ...]: the members named `nm` in class `id` or, if none, in its bases ([class.member.lookup]: the\n  bases' sets merged, a set found in a base of another found one's class dropped -- dominance through virtual bases;\n  of the rest the first). `unqualified?`: an unqualified name in a template's specialization does not look into a base\n  that was dependent in the pattern ([temp.dep]/4: two-phase lookup's first phase; this-> and qualified names do).R2,i147,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,resolve-type-formm8,R23,TR2,i165,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,resolve-typem8,R23,TR2,i165,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,lookup-qualifiedm8,R23,TR2,i165,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,const-intm8,R23,TR2,i165,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,*proot*m8,R5,TR2,i171,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,*root*m8,R5,TR2,i172,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,*header-cache*m8,R5,TR2,i173,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,opaque-classm12,R10,TR6,L1,V1,Myn2,nmm2,R8,R19,R0,s108,A class the headers declare and the program uses only through pointers (FILE's struct _IO_FILE): incomplete.R2,i175,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,finish-class!m8,R23,TR2,i184,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,va-list-tagm12,R10,TR6,L1,V0,R0,s211,x86-64's struct __va_list_tag {unsigned gp_offset, fp_offset; void *overflow_arg_area, *reg_save_area;} (the SysV\n  psABI §3.5.7), a complete trivial class (a va_list local is default-initialized: nothing runs).R2,i186,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,ptype->typem12,R10,TR6,L1,V1,R26,R0,s105,Our type of the native parser's type map (a builtin's words, a pointer, a named type through its entity).R2,i201,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,nothrow-libcS48,s5,floors6,mallocs4,ceils6,strcmps4,frees6,strcpys6,strspns6,strchrs7,isalphas4,labss7,isalnums6,memchrs6,strlens7,strrchrs5,llabss7,isdigits10,quick_exits7,strcspns6,memsets7,strncats6,memcpys3,pows7,strncmps4,fmods7,isspaces3,logs3,sins4,fabss3,exps6,callocs7,tolowers6,strstrs4,sqrts3,tans3,coss7,isuppers5,_Exits6,memcmps3,abss7,strpbrks7,strncpys4,exits5,aborts7,touppers7,reallocs7,memmoves6,strcats7,islowerm8,R10,TR2,i216,R3,i1,R4,s18,arbace/cpp/sema.aem10,R6,L1,V1,R27,R0,s94,Our entities for the header declaration the parts name ([\"printf\"], [\"std\" \"printf\"]), or nil.R2,i223,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,builtin-fnsm68,s16,__builtin_frexplV2,s6,frexpls32,long double (long double, int *)s18,__builtin_snprintfV2,s8,snprintfs46,int (char *, unsigned long, const char *, ...)s13,__builtin_absV2,s3,abss9,int (int)s16,__builtin_strcpyV2,s6,strcpys28,char *(char *, const char *)s16,__builtin_memcmpV2,s6,memcmps47,int (const void *, const void *, unsigned long)s21,__builtin_unreachableV2,s5,aborts7,void ()s18,__builtin_vsprintfV2,s8,vsprintfs45,int (char *, const char *, __builtin_va_list)s17,__builtin_strncmpV2,s7,strncmps47,int (const char *, const char *, unsigned long)s16,__builtin_printfV2,s6,printfs23,int (const char *, ...)s16,__builtin_strcatV2,s6,strcats28,char *(char *, const char *)s17,__builtin_memmoveV2,s7,memmoves43,void *(void *, const void *, unsigned long)s14,__builtin_freeV2,s4,frees13,void (void *)s19,__builtin_vsnprintfV2,s9,vsnprintfs60,int (char *, unsigned long, const char *, __builtin_va_list)s16,__builtin_mallocV2,s6,mallocs21,void *(unsigned long)s14,__builtin_putsV2,s4,putss18,int (const char *)s15,__builtin_frexpV2,s5,frexps22,double (double, int *)s16,__builtin_memsetV2,s6,memsets34,void *(void *, int, unsigned long)s16,__builtin_frexpfV2,s6,frexpfs20,float (float, int *)s17,__builtin_strncpyV2,s7,strncpys43,char *(char *, const char *, unsigned long)s19,__builtin_copysignlV2,s9,copysignls38,long double (long double, long double)s17,__builtin_toupperV2,s7,touppers9,int (int)s19,__builtin_copysignfV2,s9,copysignfs20,float (float, float)s16,__builtin_memchrV2,s6,memchrs40,void *(const void *, int, unsigned long)s15,__builtin_abortV2,s5,aborts7,void ()s17,__builtin_strrchrV2,s7,strrchrs25,char *(const char *, int)s14,__builtin_labsV2,s4,labss11,long (long)s16,__builtin_strlenV2,s6,strlens28,unsigned long (const char *)s16,__builtin_memcpyV2,s6,memcpys43,void *(void *, const void *, unsigned long)s17,__builtin_sprintfV2,s7,sprintfs31,int (char *, const char *, ...)s16,__builtin_strchrV2,s6,strchrs25,char *(const char *, int)s14,__builtin_exitV2,s4,exits10,void (int)s18,__builtin_copysignV2,s8,copysigns23,double (double, double)s16,__builtin_strcmpV2,s6,strcmps32,int (const char *, const char *)s17,__builtin_putcharV2,s7,putchars9,int (int)m8,R10,TR2,i263,R3,i1,R4,s18,arbace/cpp/sema.aem10,R10,TR6,L1,V1,Myn2,nmm2,R8,R19,R2,i303,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,builtin-symsm58,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R9,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R49,R72,R73,R74,R75,R76,R70,R77,R49,R78,R79,R80,R64,m8,R10,TR2,i314,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,name-partsm10,R10,TR6,L1,V1,R81,R2,i324,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,type-entitym10,R10,TR6,L1,V1,R82,R2,i326,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,*decltypes*m8,R5,TR2,i328,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,analyzem8,R23,TR2,i330,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,*decltype-failed*m8,R5,TR2,i335,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,dt-dependent?m12,R10,TR6,L1,V1,R83,R0,s98,Whether a type names a template's parameter (template.ae's dependent?, which sema does not reach).R2,i343,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,dt-stripm10,R10,TR6,L1,V1,R26,R2,i350,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,dt-typem10,R10,TR6,L1,V2,R21,Myn1,sm2,R8,R19,R2,i356,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,dt-targm12,R10,TR6,L1,V2,R21,Myn1,sm2,R8,R19,R0,s96,An explicit template argument as written: an integer literal, a non-type parameter, else a type.R2,i360,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,dt-unopsm12,s1,*s2,des1,&s2,ads1,-s2,ngs1,+s2,pss1,!s2,nts1,~s2,com8,R10,TR2,i370,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,dt-binopsm66,s2,>>s2,rss2,&&s2,aas2,!=s2,nes2,.*s2,dss1,=s2,aSs1,*s2,mls1,%s2,rms2,<=s2,les2,-=s2,mIs1,|s2,ors1,/s2,dvs1,-s2,mis2,/=s2,dVs2,%=s2,rMs2,*=s2,mLs2,|=s2,oRs3,<<=s2,lSs3,<=>s2,sss3,>>=s2,rSs2,>=s2,ges2,^=s2,eOs1,&s2,ans1,<s2,lts2,<<s2,lss1,,s2,cms2,&=s2,aNs2,+=s2,pLs2,||s2,oos2,==s2,eqs1,^s2,eos3,->*s2,pms1,+s2,pls1,>s2,gtm8,R10,TR2,i371,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,dt-castsm10,s17,CXXStaticCastExprs2,scs14,CStyleCastExprs2,cvs22,CXXReinterpretCastExprs2,rcs16,CXXConstCastExprs2,ccs18,CXXDynamicCastExprs2,dcm8,R10,TR2,i375,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,dt-written-typem12,R10,TR6,L1,MV1,R84,m2,R8,R20,R0,s103,A cast's or construction's type as written: the node's type with the reference its value category says.R2,i378,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,dt-irm12,R10,TR6,L1,V2,R21,R84,R0,s120,The operand `n` (the native parser's node) of a dependent decltype as the mangler's data, its names resolved in `scope`.R2,i383,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,decltype-ofm12,R10,TR6,L1,V2,R21,Myn1,tm2,R8,R19,R0,s289,decltype(e) ([dcl.type.decltype]/1): the operand the native parser kept for the text `t`, analyzed in `scope`\n  (unevaluated: its result is not kept); an unparenthesized id-expression or member access its entity's declared type,\n  else T& for an lvalue, T&& for an xvalue, T for a prvalue.R2,i458,R3,i1,R4,s18,arbace/cpp/sema.aem8,R6,L1,V2,R21,R12,R2,i505,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,strip-type-attrsm12,R10,TR6,L1,MV1,Myn1,sm2,R8,R19,m2,R8,R20,R0,s169,A spelling without its GNU attributes (`void () noexcept __attribute__((noreturn))`): none of them changes the type\n  the analysis needs (G4: the headers' declarations).R2,i606,R3,i1,R4,s18,arbace/cpp/sema.aem10,R6,L1,V2,R21,Myn2,s0m2,R8,R19,R0,s53,The semantic type of clang's spelling `s` in `scope`.R2,i621,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,ctad-templatem10,R6,L1,V2,R21,R85,R0,s254,The class or alias template the placeholder `s` (a type's spelling: a template-name, maybe qualified and\n  cv-qualified, no argument list) names in `scope` where no type of that name is found (the injected-class-name is a\n  type), as [tid #{cv}], or nil.R2,i635,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,ctad-compound!m10,R6,L1,V2,R21,R85,R0,s345,CP311 (a), the checker: a variable's type `s` that does not resolve and holds a placeholder for a deduced class type\n  inside a compound type (a pointer, a reference, an array, a function's parameter or return: [dcl.type.class.deduct]/2\n  allows the placeholder only as the whole declared type; clang's err_deduced_class_template_compound_type).R2,i663,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,ctad-compound-varm10,R6,L1,V3,R21,R84,R86,R0,s209,CP311 (a), the checker: {:ty :ctad-error} for a variable whose type `qt` is ctad-compound!'s error (the variable\n  declared with a dependent placeholder type, the error raised at its initialization), else nil.R2,i678,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,method-const?m10,R10,TR6,L1,V1,Myn2,qtm2,R8,R19,R2,i689,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,method-volatile?m10,R10,TR6,L1,V1,Myn2,qtm2,R8,R19,R2,i690,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,method-refqm12,R10,TR6,L1,V1,Myn2,qtm2,R8,R19,R0,s91,A member function's ref-qualifier from its type's spelling: \"&\", \"&&\" or nil ([dcl.fct]/4).R2,i692,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,*main-name*m8,R5,TR2,i700,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,*main-dir*m8,R5,TR2,i703,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,file-textsm8,R10,TR2,i704,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,loc-ofm12,R10,TR6,L1,V1,R87,R0,s75,A location's file position: its own, or a macro token's expansion location.R2,i706,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,blank-commentsm12,R10,TR6,L1,MV1,Myn1,tm2,R8,R19,m2,R8,R20,R0,s242,A header's text with its comments blanked (spaces, its newlines kept: the offsets unchanged), so that the analysis's\n  readings of a node's text (a partial specialization's arguments) see no comment (G4); string and character literals\n  kept.R2,i711,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,located-filem12,R10,TR6,L1,MV1,Myn4,filem2,R8,R19,m2,R8,R88,R0,s336,The file a location's relative name `file` is: as named, else under the main file's directory, else (CP368 (a)) under\n  the root the main file's own name is relative to (the dg read names the main file `coroutines/x.C` and its quoted header\n  `coroutines/coro.h`, both relative to g++.dg, while *main-dir* is the main file's directory).R2,i731,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,text-ofm10,R6,L1,MV1,R89,m2,R8,R20,R0,s178,The text of the file `file` names in the tree's locations: the main file's *src*, a header's read once (G4: header\n  bodies are parsed, so their nodes' text is their own file's).R2,i747,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,header-node?m10,R6,L1,V1,R84,R0,s92,Whether a node is a header's (G4: its location's file a header's path, not the main file's).R2,i764,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,node-textm10,R10,TR6,L1,MV1,R84,m2,R8,R20,R2,i770,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,text-afterm12,R10,TR6,L1,MV2,R84,R90,m2,R8,R20,R0,s77,At most `k` characters of a node's file after its range's last token, or nil.R2,i778,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,strip-directivesm12,R10,TR6,L1,MV1,Myn1,tm2,R8,R19,m2,R8,R20,R0,s516,The text with its preprocessing directives' lines left out (a `#` first on a line, with its continuations): a\n  declaration's text before its name is the source's, and a conditional may stand between the qualifier and the name\n  (CP377 (a): libstdc++ 15's basic_string.tcc writes `basic_string<_CharT, _Traits, _Alloc>::` then `#ifdef\n  __glibcxx_string_resize_and_overwrite` before `resize_and_overwrite(`, so the definition had been taken for a namespace's\n  function template and the member template had no body).R2,i786,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,text-before-namem10,R6,L1,MV1,R84,m2,R8,R20,R0,s139,The text a declaration's node has before its name (its location), in its own file, or nil (its preprocessing\n  directives' lines left out).R2,i795,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,qualifier-beforem12,R10,TR6,L1,V1,R84,R0,s108,The parts of the nested-name-specifier written before a declaration's name (`int ns::P::get()`: [\"ns\" \"P\"]).R2,i804,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema20,qualifier-tid-beforem12,R10,TR6,L1,V1,R84,R0,s311,cpp-s13: qualifier-before's parts when the nested-name-specifier names a template-id (`bool ctype<char>::is(...)`, a member\n  of an explicit specialization defined outside it, [temp.expl.spec]/5: no template<> before it): each part a name or a\n  template-id as written (lookup-qualified resolves those), or nil.R2,i815,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,split-scopem12,R10,TR6,L1,V1,Myn1,tm2,R8,R19,R0,s99,A qualified name's parts: the text split at the :: outside template argument lists and parentheses.R2,i841,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,ref-qualifierm12,R10,TR6,L1,V1,R84,R0,s107,A DeclRefExpr's written qualifier's parts and whether it starts with :: (the tree's, P13; else its text's).R2,i854,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,written-targsm10,R6,L1,V2,R84,Myn2,nmm2,R8,R19,R0,s163,The text `name<args>` of a name expression's explicit template arguments (the tree's, P13 (b)), or nil; a node of\n  no written name (the parser's own) by its text.R2,i865,R3,i1,R4,s18,arbace/cpp/sema.aem10,R6,L2,V2,R21,R27,V3,R21,R27,R91,R0,s108,The entities of a qualified name's last part, its qualifiers looked up from `scope` (the first unqualified).R2,i873,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema4,kidsm10,R10,TR6,L1,V1,R84,R2,i908,R3,i1,R4,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,body-ofm10,R6,L1,V1,R84,R0,s191,A function declaration's body: its compound statement, or its function-try-block ([dcl.fct.def.general]/1, [except.pre]/3: the\n  native parser's CXXTryStmt, as clang's FunctionDecl holds it).R2,i910,R3,i1,R4,s18,arbace/cpp/sema.ae")

var Lit_1312 *jrt.String = jrt.Intern("arbace.cpp.sema$eval916000004$loading__1927001464__auto____916000005")

var Lit_1313 *jrt.String = jrt.Intern("arbace.cpp.sema$eval916000008$fn__916000009")

var Lit_1314 *jrt.String = jrt.Intern("arbace.cpp.sema$checking_QMARK_")

var Lit_1315 *jrt.String = jrt.Intern("arbace.cpp.sema$tick_BANG_")

var Lit_1316 *jrt.String = jrt.Intern("arbace.cpp.sema$cxx_year")

var Lit_1317 *jrt.String = jrt.Intern("arbace.cpp.sema$next_id")

var Lit_1318 *jrt.String = jrt.Intern("arbace.cpp.sema$fnd")

var Lit_1319 *jrt.String = jrt.Intern("arbace.cpp.sema$var_STAR_")

var Lit_1320 *jrt.String = jrt.Intern("arbace.cpp.sema$upd_fn_BANG_")

var Lit_1321 *jrt.String = jrt.Intern("arbace.cpp.sema$upd_var_BANG_")

var Lit_1322 *jrt.String = jrt.Intern("arbace.cpp.sema$new_scope")

var Lit_1323 *jrt.String = jrt.Intern("arbace.cpp.sema$ucn_name")

var Lit_1324 *jrt.String = jrt.Intern("arbace.cpp.sema$enter_BANG_")

var Lit_1325 *jrt.String = jrt.Intern("arbace.cpp.sema$own_names")

var Lit_1326 *jrt.String = jrt.Intern("arbace.cpp.sema$find_here")

var Lit_1327 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup")

var Lit_1328 *jrt.String = jrt.Intern("arbace.cpp.sema$class_lookup")

var Lit_1329 *jrt.String = jrt.Intern("arbace.cpp.sema$opaque_class")

var Lit_1330 *jrt.String = jrt.Intern("arbace.cpp.sema$va_list_tag")

var Lit_1331 *jrt.String = jrt.Intern("arbace.cpp.sema$ptype__GT_type")

var Lit_1332 *jrt.String = jrt.Intern("arbace.cpp.sema$header_entities")

var Lit_1333 *jrt.String = jrt.Intern("arbace.cpp.sema$builtin_entities")

var Lit_1334 *jrt.String = jrt.Intern("arbace.cpp.sema$name_parts")

var Lit_1335 *jrt.String = jrt.Intern("arbace.cpp.sema$type_entity")

var Lit_1336 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_dependent_QMARK_")

var Lit_1337 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_strip")

var Lit_1338 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_type")

var Lit_1339 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_targ")

var Lit_1340 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_written_type")

var Lit_1341 *jrt.String = jrt.Intern("arbace.cpp.sema$dt_ir")

var Lit_1342 *jrt.String = jrt.Intern("arbace.cpp.sema$decltype_of")

var Lit_1343 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type_form")

var Lit_1344 *jrt.String = jrt.Intern("arbace.cpp.sema$strip_type_attrs")

var Lit_1345 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_type")

var Lit_1346 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_template")

var Lit_1347 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_compound_BANG_")

var Lit_1348 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_compound_var")

var Lit_1349 *jrt.String = jrt.Intern("arbace.cpp.sema$method_const_QMARK_")

var Lit_1350 *jrt.String = jrt.Intern("arbace.cpp.sema$method_volatile_QMARK_")

var Lit_1351 *jrt.String = jrt.Intern("arbace.cpp.sema$method_refq")

var Lit_1352 *jrt.String = jrt.Intern("arbace.cpp.sema$loc_of")

var Lit_1353 *jrt.String = jrt.Intern("arbace.cpp.sema$blank_comments")

var Lit_1354 *jrt.String = jrt.Intern("arbace.cpp.sema$located_file")

var Lit_1355 *jrt.String = jrt.Intern("arbace.cpp.sema$text_of")

var Lit_1356 *jrt.String = jrt.Intern("arbace.cpp.sema$header_node_QMARK_")

var Lit_1357 *jrt.String = jrt.Intern("arbace.cpp.sema$node_text")

var Lit_1358 *jrt.String = jrt.Intern("arbace.cpp.sema$text_after")

var Lit_1359 *jrt.String = jrt.Intern("arbace.cpp.sema$strip_directives")

var Lit_1360 *jrt.String = jrt.Intern("arbace.cpp.sema$text_before_name")

var Lit_1361 *jrt.String = jrt.Intern("arbace.cpp.sema$qualifier_before")

var Lit_1362 *jrt.String = jrt.Intern("arbace.cpp.sema$qualifier_tid_before")

var Lit_1363 *jrt.String = jrt.Intern("arbace.cpp.sema$split_scope")

var Lit_1364 *jrt.String = jrt.Intern("arbace.cpp.sema$ref_qualifier")

var Lit_1365 *jrt.String = jrt.Intern("arbace.cpp.sema$written_targs")

var Lit_1366 *jrt.String = jrt.Intern("arbace.cpp.sema$lookup_qualified")

var Lit_1367 *jrt.String = jrt.Intern("arbace.cpp.sema$kids")

var Lit_1368 *jrt.String = jrt.Intern("arbace.cpp.sema$body_of")

var Lit_1369 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,nyn2,nmkn3,dockn4,linekn6,columnkn4,fileyn1,tyn5,scopeyn6,parentyn4,anonkn8,declaredkn3,tagyn6,Stringyn1,fyn1,gkn7,dynamicyn2,rcyn2,rsyn7,storageyn6,scope0yn2,idyn1,kyn2,tyyn1,&kn2,asyn4,moreyn4,predyn1,vyn3,srcyn1,ayn1,byn1,eyn3,msgyn1,pyn4,longyn1,lyn1,xv15,arbace.cpp.sema12,gnu-attr-argm12,R0,TR1,L1,V2,R2,R3,R4,s159,The argument of a GNU attribute `nm` among a declaration's attribute nodes (init_priority(200)): a number, or true\n  when written without one; nil when absent.R5,i916,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,mode-bitsm22,s18,libgcc_shift_countl64,s2,SIl32,s4,wordl64,s2,QIl8,s7,pointerl64,s17,libgcc_cmp_returnl64,s11,unwind_wordl64,s2,TIl128,s2,DIl64,s2,HIl16,s4,bytel8,m8,R0,TR5,i924,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,mode-typem12,R0,TR1,L1,V2,R2,R8,R4,s354,The type `t` of a declaration `n` under GNU's mode attribute (G5c: cxxabi.h's `typedef int __guard\n  __attribute__((mode (__DI__)))`, unwind.h's _Unwind_Word): an integer type of the mode's width and `t`'s signedness,\n  the first of char, short, int, long, long long, __int128 of that width (clang's ASTContext::getIntTypeForBitwidth);\n  `t` without one.R5,i929,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,init-kidm12,R0,TR1,L1,V1,R2,R4,s150,A variable declaration's initializer node: its first child that is not an attribute (__attribute__((init_priority(N)))\n  comes first in the tree; G5).R5,i947,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,linkage-c?m10,R0,TR1,L1,V1,R9,R5,i953,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,ns-scope!m10,R0,TR1,L1,V3,R10,R3,R11,R5,i955,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,declare-node!m8,R12,TR5,i968,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,special-members!m8,R12,TR5,i968,R6,i1,R7,s18,arbace/cpp/sema.aem8,R12,TR5,i968,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,fn-opm10,R0,TR1,L1,V1,Myn2,nmm2,R13,R14,R5,i970,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,param-nodesm10,R0,TR1,L1,V1,R2,R5,i972,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,same-sig?m10,R0,TR1,L1,V2,R15,R16,R5,i974,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,find-redeclm10,R0,TR1,L1,V2,R9,R15,R5,i978,R6,i1,R7,s18,arbace/cpp/sema.aem8,R12,TR5,i982,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema2,rvm8,R12,TR5,i982,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,ce-trym8,R12,TR5,i982,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,noexcept-ofm12,R0,TR1,L1,V2,R9,Myn2,qtm2,R13,R14,R4,s239,Whether a function type's spelling says noexcept: `noexcept`, `noexcept(true)`, or noexcept(e) of a constant e\n  true ([except.spec]/2; G4: the headers' noexcept(__and_<...>::value), evaluated in `scope`, not noexcept when it\n  cannot be).R5,i984,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,*constraint-depth*m8,R17,TR5,i1014,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,*constraint-stack*m8,R17,TR5,i1015,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,*constraint-doubt*m8,R17,TR5,i1019,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,doubt!m8,R1,L1,V0,R5,i1020,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema21,constraint-satisfied?m10,R1,L1,V2,R9,R18,R4,s204,A constraint expression's satisfaction in `scope` ([temp.constr.constr]: the atomic constraints constant expressions\n  of type bool; a substitution failure or an expression not constant is not satisfied).R5,i1022,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema19,always-inline-node?m12,R0,TR1,L1,V1,R2,R4,s126,Whether a function declaration's attributes hold GNU's always_inline ([[gnu::always_inline]], __attribute__((always_inline))).R5,i1041,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,noreturn-node?m12,R0,TR1,L1,V1,R2,R4,s118,Whether a function declaration says it does not return ([[noreturn]], __attribute__((noreturn)); [dcl.attr.noreturn]).R5,i1046,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,explicit-specm12,R0,TR1,L1,V2,R9,Myn4,textm2,R13,R14,R4,s241,A function declaration's explicit-specifier ([dcl.fct.spec]/3): `explicit`, or `explicit(constant-expression)` true\n  when the expression converts to true (C++20; CP280 (a)); a value the slice cannot evaluate counts as explicit, as\n  before.R5,i1055,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,unfinished-targs?m12,R0,TR1,L1,V1,R9,R4,s153,cpp-s11: whether `scope` is a class template specialization's (or within one) whose template arguments name a class\n  not finished yet (abi's :finished).R5,i1076,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,trailing-ok?m10,R1,L1,V1,R15,R4,s139,cpp-s11: a function declared with its trailing requires-clause deferred (declare-fn!'s :trailing-defer) satisfies it\n  now; any other true.R5,i1087,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,fn-type-scopem10,R1,L1,V2,R19,R2,R4,s367,The scope a function declaration's type is resolved in: `rs`, or when its spelling has a decltype or a noexcept(e), a\n  block scope over it with the parameters ([basic.scope.param]: a trailing return type's decltype names them, `->\n  decltype(make_move_iterator(__it.base()))`, G4), each with its index (:fpi, a dependent decltype's fp_ in the mangling,\n  CP391 (a)).R5,i1095,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,declare-fn!m12,R0,TR1,L1,V2,R9,R2,R4,s223,A function, method, constructor or destructor declaration (or definition) in `scope`; out-of-line definitions join\n  their declaration. One whose trailing requires-clause is not satisfied is not declared (nil; P14 (b), G4).R5,i1112,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,ctad-varm8,R12,TR5,i1247,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,declare-var!m10,R0,TR1,L1,V3,R9,R2,R20,R5,i1249,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,declare-enum!m10,R0,TR1,L1,V2,R9,R2,R5,i1333,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,declare-class!m10,R0,TR1,L1,V2,R21,R2,R5,i1364,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,declare-node*!m8,R12,TR5,i1492,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,cx-access!m8,R12,TR5,i1492,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,cx-using-mapm8,R12,TR5,i1492,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,*retry*m8,R17,TR5,i1494,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,*main-retry*m8,R17,TR5,i1495,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,*incomplete-ok*m8,R17,TR5,i1496,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,*header-drops*m8,R17,TR5,i1498,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,drop-keym12,R0,TR1,L1,V1,R2,R4,s108,A header declaration's key in *header-drops*: the node itself (a retry declares the same node), by identity.R5,i1501,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V2,R9,R2,R4,s195,Enters a declaration node of namespace or class scope. A header's declaration that the analysis refuses is dropped\n  (G4: a use of it fails later as an unknown name; CPP_HDR_TRACE=1 prints each).R5,i1506,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,placeholder-splitm12,R0,TR1,L1,V1,Myn2,qtm2,R13,R14,R4,s334,cpp-s11: a parameter's type as written with a placeholder ([dcl.spec.auto]: `auto`, `C auto`, `C<A...> auto`, cv and\n  declarator operators around it, `auto...`): [before the type-constraint, the type-constraint's text or nil, after\n  `auto`], or nil when it has none (decltype(auto) is none: a parameter may not be declared with it).R5,i1543,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema20,abbreviated-templatem12,R0,TR1,L1,V1,R2,R4,s786,cpp-s11: an abbreviated function template ([dcl.fct]/22): a function declaration with a placeholder in a parameter's\n  type is a function template with an invented type template parameter for each, after the declared ones (a pack for\n  `auto...`), the placeholder's type-constraint the invented parameter's ([temp.param]/4: `C<A...> auto` the immediately-\n  declared constraint C<P, A...>). The node `n` (a function declaration, or a FunctionTemplateDecl whose function has\n  such parameters) as the FunctionTemplateDecl it declares, or nil when it has none. <bits/ranges_util.h>'s\n  subrange(__convertible_to_non_slicing<_It> auto __i, _Sent __s) had been dropped (\"type form (constrained ...)\"), so\n  <format>'s _Utf32_view<subrange<iterator>>({__first, __last}) found no constructor.R5,i1567,R6,i1,R7,s18,arbace/cpp/sema.aem10,R0,TR1,L1,V2,R9,R2,R5,i1615,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,user-ctorsm10,R0,TR1,L1,V1,R22,R5,i1763,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,copy-ctor?m10,R0,TR1,L1,V2,R15,R22,R5,i1764,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,move-ctor?m10,R0,TR1,L1,V2,R15,R22,R5,i1766,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,copy-assign?m10,R0,TR1,L1,V2,R15,R22,R5,i1768,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,move-assign?m10,R0,TR1,L1,V2,R15,R22,R5,i1770,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,class-like-membersm10,R0,TR1,L1,V1,R22,R5,i1772,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,trivial-dtor?m8,R1,L1,V1,R22,R5,i1776,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,trivial-copy?m8,R1,L1,V1,R22,R5,i1781,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,trivial-assign?m12,R0,TR1,L1,V1,R22,R4,s342,cpp-s3: the class's copy and move assignments trivial ([class.copy.assign]/9) as far as trivial-copy? does not tell:\n  no user-provided one, its bases' and members' trivial too. (An implicit or defaulted assignment over a member whose\n  operator= is user-provided is a call of it, not a copy of the bytes: explicit-obj-default2.C's S over A.)R5,i1787,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,implicit-fn!m10,R0,TR1,L1,V6,R22,R23,R3,R24,R25,m2,R26,R27,R5,i1797,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,has-ctor-of?m10,R0,TR1,L1,V2,R22,R28,R5,i1815,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V1,R22,R4,s107,A complete class: its virtual functions (declared or overriding), its implicit special members, its vtable.R5,i1817,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,aggregate?m10,R1,L1,V1,R8,R4,s206,[dcl.init.aggr]/1 (C++20): an array, or a class with no user-declared constructors, no private or protected direct\n  non-static data members, no virtual functions and no virtual, private or protected bases.R5,i1926,R6,i1,R7,s18,arbace/cpp/sema.aem8,R12,TR5,i1940,R6,i1,R7,s18,arbace/cpp/sema.aem8,R12,TR5,i1940,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,init-list-elemm8,R12,TR5,i1940,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,ce-evalm8,R12,TR5,i1942,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,ce-wrapm8,R12,TR5,i1942,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema3,ub!m8,R12,TR5,i1942,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,not-constantm8,R12,TR5,i1942,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,*ce-wide*m10,R17,TR5,i1944,R6,i1,R7,s18,arbace/cpp/sema.aeR4,s309,cpp-s13: true inside an evaluation (const-int's, ce-eval's), where a 128-bit value outside 64 bits is a value (a BigInt);\n  its result outside 64 bits is not a constant (narrow-out), as before: only evaluations' own steps see them (an if\n  constexpr's comparison of __numeric_traits_integer<__int128>::__max).v15,arbace.cpp.sema6,ce-numm10,R1,L1,V1,R29,R4,s114,An evaluation's integral value as a number to compute with: a long, or a BigInt outside 64 bits (a 128-bit value).R5,i1950,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,wide-value?m10,R0,TR1,L1,V1,R29,R5,i1955,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,wide-literalm12,R0,TR1,L1,V1,R29,R4,s140,cpp-s13: a 128-bit value as an :int node's :v (its LLVM constant): the signed representation, as a 64-bit unsigned one is a\n  negative long.R5,i1957,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,wide?m8,R12,TR5,i1963,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,from-srcm12,R0,TR1,L1,V3,R30,R8,R29,R4,s204,cpp-s13: an integral value of the type `src` as the value it stands for when converted to a 128-bit type: a 64-bit unsigned\n  one held as a negative long is 2^64 more ([conv.integral]/2's zero extension).R5,i1965,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,narrow-outm12,R0,TR1,L1,V1,R29,R4,s119,An evaluation's result `v` where it leaves the evaluator: a 128-bit value outside 64 bits not a constant (CP5b's rule).R5,i1974,R6,i1,R7,s18,arbace/cpp/sema.aem12,R0,TR1,L1,V1,R8,R4,s116,cpp-s5b (pending review 1111 #2): whether the integral type `t` is wider than 64 bits (__int128, unsigned __int128).R5,i1979,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,wide-binopm12,R0,TR1,L1,V3,Myn1,om2,R13,R14,R31,R32,R4,s401,cpp-s5b (pending review 1111 #2): a 128-bit type's arithmetic on the operands' values computed exactly (cpp-s13: the operands\n  themselves may be outside 64 bits, ce-wrap holding a 128-bit value as a BigInt then), for ce-wrap to reduce to the type's\n  width, never computed modulo 2^64 (`(unsigned __int128)1 << 64` was 0); a shift by a count outside 0..127 and a division by\n  zero are not constants.R5,i1985,R6,i1,R7,s18,arbace/cpp/sema.aem8,R12,TR5,i2000,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,*ce-manifest*m8,R17,TR5,i2007,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,var-const-intm12,R0,TR1,L1,V1,R22,R4,s467,A const integral variable's value, its initializer's constant (const-int in its definition's scope), kept on the variable\n  once found: a variable's initializer is the same expression at every use, and a class template's static member whose\n  initializer names its other specializations' (cpp0x/overflow1's Fib<i-1>::value + Fib<i-2>::value) is otherwise evaluated\n  again for each path, exponentially (the dg read's one file that never ended). A failure is not kept.R5,i2009,R6,i1,R7,s18,arbace/cpp/sema.aem8,R1,L1,V2,R9,R2,R5,i2022,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,analyze-fn!m8,R12,TR5,i2079,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema4,stmtm8,R12,TR5,i2079,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,ce-execm8,R12,TR5,i2079,R6,i1,R7,s18,arbace/cpp/sema.aem12,R0,TR1,L1,V3,R33,R25,R34,R4,s218,CX12 (the checker): an evaluation [expr.const]/5 makes not a core constant expression by the program's own operation\n  (undefined behaviour, [expr.shift]/1-3, [expr.mul]/4, [expr.pre]/4), sure: at the operation's node.R5,i2081,R6,i1,R7,s18,arbace/cpp/sema.aem10,R0,TR1,L1,V2,R25,R34,R5,i2087,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,ce-ptr?m12,R0,TR1,L1,V1,R29,R4,s223,CP374 (a): whether the evaluator's value is a pointer: {::base B ::i I}, B the elements' values (a string literal's, a\n  vector) or a local array's atom holding them, I the index (0 to the count, one past the last element).R5,i2089,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,ce-elemsm10,R0,TR1,L1,V1,R35,R5,i2095,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,ce-ptr-addm12,R0,TR1,L1,V2,R35,Myn1,nm2,R13,R36,R4,s107,The pointer `p` moved by `n` elements ([expr.add]/4: within its array or one past it, else not a constant).R5,i2097,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,ce-same-base?m10,R0,TR1,L1,V2,R31,R32,R5,i2103,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,ce-loc?m10,R0,TR1,L1,V1,R29,R5,i2111,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,ce-getm12,R0,TR1,L1,V1,R37,R4,s103,The value at location `l` (an uninitialized subobject, nil there, is not a constant: [expr.const]/5.9).R5,i2113,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,ce-put!m10,R0,TR1,L1,V2,R37,R38,R5,i2120,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,ce-cell-locm10,R0,TR1,L1,V1,R29,R5,i2123,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,str-unitsm8,R12,TR5,i2125,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V2,R8,R29,R4,s100,The value `v` as the type `t` holds it (integers wrapped to its width, bool 0/1, floats as doubles).R5,i2127,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,*ce-steps*m8,R17,TR5,i2154,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,*ce-in-call*m8,R17,TR5,i2157,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,*ce-fold*m8,R17,TR5,i2162,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,ce-top-sure!m12,R0,TR1,L1,V2,R25,R34,R4,s182,CX12 (the checker): an operation of the constexpr variable's initializer itself that [expr.const]/5 makes not a core\n  constant expression whatever the values: sure, at the variable.R5,i2164,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema5,ce-lvm8,R12,TR5,i2171,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,ce-initm8,R12,TR5,i2171,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,ce-glvaluem8,R12,TR5,i2171,R6,i1,R7,s18,arbace/cpp/sema.ae")

var Lit_1370 *jrt.String = jrt.Intern("arbace.cpp.sema$gnu_attr_arg")

var Lit_1371 *jrt.String = jrt.Intern("arbace.cpp.sema$mode_type")

var Lit_1372 *jrt.String = jrt.Intern("arbace.cpp.sema$init_kid")

var Lit_1373 *jrt.String = jrt.Intern("arbace.cpp.sema$linkage_c_QMARK_")

var Lit_1374 *jrt.String = jrt.Intern("arbace.cpp.sema$ns_scope_BANG_")

var Lit_1375 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_op")

var Lit_1376 *jrt.String = jrt.Intern("arbace.cpp.sema$param_nodes")

var Lit_1377 *jrt.String = jrt.Intern("arbace.cpp.sema$same_sig_QMARK_")

var Lit_1378 *jrt.String = jrt.Intern("arbace.cpp.sema$find_redecl")

var Lit_1379 *jrt.String = jrt.Intern("arbace.cpp.sema$noexcept_of")

var Lit_1380 *jrt.String = jrt.Intern("arbace.cpp.sema$doubt_BANG_")

var Lit_1381 *jrt.String = jrt.Intern("arbace.cpp.sema$constraint_satisfied_QMARK_")

var Lit_1382 *jrt.String = jrt.Intern("arbace.cpp.sema$always_inline_node_QMARK_")

var Lit_1383 *jrt.String = jrt.Intern("arbace.cpp.sema$noreturn_node_QMARK_")

var Lit_1384 *jrt.String = jrt.Intern("arbace.cpp.sema$explicit_spec")

var Lit_1385 *jrt.String = jrt.Intern("arbace.cpp.sema$unfinished_targs_QMARK_")

var Lit_1386 *jrt.String = jrt.Intern("arbace.cpp.sema$trailing_ok_QMARK_")

var Lit_1387 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_type_scope")

var Lit_1388 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_fn_BANG_")

var Lit_1389 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_var_BANG_")

var Lit_1390 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_enum_BANG_")

var Lit_1391 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_class_BANG_")

var Lit_1392 *jrt.String = jrt.Intern("arbace.cpp.sema$drop_key")

var Lit_1393 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_BANG_")

var Lit_1394 *jrt.String = jrt.Intern("arbace.cpp.sema$placeholder_split")

var Lit_1395 *jrt.String = jrt.Intern("arbace.cpp.sema$abbreviated_template")

var Lit_1396 *jrt.String = jrt.Intern("arbace.cpp.sema$declare_node_STAR__BANG_")

var Lit_1397 *jrt.String = jrt.Intern("arbace.cpp.sema$user_ctors")

var Lit_1398 *jrt.String = jrt.Intern("arbace.cpp.sema$copy_ctor_QMARK_")

var Lit_1399 *jrt.String = jrt.Intern("arbace.cpp.sema$move_ctor_QMARK_")

var Lit_1400 *jrt.String = jrt.Intern("arbace.cpp.sema$copy_assign_QMARK_")

var Lit_1401 *jrt.String = jrt.Intern("arbace.cpp.sema$move_assign_QMARK_")

var Lit_1402 *jrt.String = jrt.Intern("arbace.cpp.sema$class_like_members")

var Lit_1403 *jrt.String = jrt.Intern("arbace.cpp.sema$trivial_dtor_QMARK_")

var Lit_1404 *jrt.String = jrt.Intern("arbace.cpp.sema$trivial_copy_QMARK_")

var Lit_1405 *jrt.String = jrt.Intern("arbace.cpp.sema$trivial_assign_QMARK_")

var Lit_1406 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_fn_BANG_")

var Lit_1407 *jrt.String = jrt.Intern("arbace.cpp.sema$has_ctor_of_QMARK_")

var Lit_1408 *jrt.String = jrt.Intern("arbace.cpp.sema$finish_class_BANG_")

var Lit_1409 *jrt.String = jrt.Intern("arbace.cpp.sema$aggregate_QMARK_")

var Lit_1410 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_num")

var Lit_1411 *jrt.String = jrt.Intern("arbace.cpp.sema$wide_value_QMARK_")

var Lit_1412 *jrt.String = jrt.Intern("arbace.cpp.sema$wide_literal")

var Lit_1413 *jrt.String = jrt.Intern("arbace.cpp.sema$from_src")

var Lit_1414 *jrt.String = jrt.Intern("arbace.cpp.sema$narrow_out")

var Lit_1415 *jrt.String = jrt.Intern("arbace.cpp.sema$wide_QMARK_")

var Lit_1416 *jrt.String = jrt.Intern("arbace.cpp.sema$wide_binop")

var Lit_1417 *jrt.String = jrt.Intern("arbace.cpp.sema$var_const_int")

var Lit_1418 *jrt.String = jrt.Intern("arbace.cpp.sema$const_int")

var Lit_1419 *jrt.String = jrt.Intern("arbace.cpp.sema$ub_BANG_")

var Lit_1420 *jrt.String = jrt.Intern("arbace.cpp.sema$not_constant")

var Lit_1421 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_ptr_QMARK_")

var Lit_1422 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_elems")

var Lit_1423 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_ptr_add")

var Lit_1424 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_same_base_QMARK_")

var Lit_1425 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_loc_QMARK_")

var Lit_1426 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_get")

var Lit_1427 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_put_BANG_")

var Lit_1428 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_cell_loc")

var Lit_1429 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_wrap")

var Lit_1430 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_top_sure_BANG_")

var Lit_1431 *jrt.String = jrt.Intern("kn8,declaredkn4,linekn6,columnkn4,filekn8,arglistsyn1,eyn3,envkn3,dockn7,privateyn1,syn4,fromyn2,toyn1,tyn1,vyn1,fyn5,initsyn3,cidyn3,fidyn4,argsyn5,startyn1,iyn8,manifestyn1,cyn2,ckyn2,ftkn3,intkn4,uintkn4,longkn5,ulongkn5,llongkn6,ullongkn4,i128kn4,u128yn1,ayn1,byn9,explicit?yn2,idyn1,Fyn1,&yn5,obj-ckn7,dynamicyn5,itemsyn1,pyn5,candsyn3,objyn2,cskn3,tagyn4,longyn3,ctxyn1,lyn2,cxyn2,ncyn2,dcyn2,nmyn1,ryn5,styleyn4,bfidyn1,gyn6,nestedyn6,value?yn1,uyn1,nyn2,styn3,srcyn6,Stringyn16,java.lang.Stringyn3,bidyn2,qcyn2,esv15,arbace.cpp.sema8,ce-storem8,R0,TR1,i2171,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,ce-constructm8,R0,TR1,i2171,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,ce-args-envm8,R0,TR1,i2171,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L2,V1,R5,V2,R5,R6,R7,s181,The constant value of the typed expression `e` (`env` {var-id atom} the locals of the evaluated calls; ::this the\n  location of a member's object, ::ret the function's return type).R1,i2173,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V2,R9,R6,R7,s94,Executes a constexpr function's typed statement: [:normal], [:ret v], [:break] or [:continue].R1,i2365,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,ce-base-pathm12,R8,TR4,L1,V2,R10,R11,R7,s117,The keys from an object of class `from` down to its base subobject of class `to` ([:b B] each), the first path found.R1,i2424,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V2,R5,R6,R7,s140,CP378 (a): the location of the glvalue `e` (a local, a member, a base subobject, an object through a pointer or a\n  reference, a temporary).R1,i2430,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V2,R5,R6,R7,s97,The value of the object the expression `e` names (a glvalue's object, read) or makes (a prvalue).R1,i2453,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V2,R12,R13,R7,s76,The value `v` as an object, a reference or a parameter of type `t` holds it.R1,i2458,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,ce-zero-ofm10,R8,TR4,L1,V1,R12,R1,i2468,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V3,R14,R15,R6,R7,s165,The parameters of `f` bound to its call's initializers `inits`, each in a cell (an argument of an empty class, a tag\n  such as true_type, a value nothing reads; G4).R1,i2478,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V5,R16,R17,R18,R6,R19,R7,s299,The value of an object of class `cid` its constexpr constructor `fid` makes from the initializers `args`: its\n  mem-initializers (the bases', then the members', [class.base.init]/13), then its body with `this`; `start` the object\n  before (a zero-initialized one for :zero-then), else uninitialized.R1,i2491,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V3,R12,R20,R6,R7,s154,CP378 (a): the value an initializer (init-for's) gives an object, a reference or a parameter of type `t` (nil: the\n  initializer's own expression's type).R1,i2522,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,ce-call-fnm10,R4,L1,V2,R17,R18,R7,s184,The value of the call of the constexpr function `fid` with the integral constants `args` ([expr.const]; an array\n  bound written as a call), or an ex-info {:codegen/not-constant true}.R1,i2554,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L2,V1,R5,V2,R5,R21,R7,s274,The constant `e` folds to (a typed literal of its type), or nil. A fold of code that runs (fold-mark's): not manifestly\n  constant-evaluated, `__builtin_is_constant_evaluated()` false; `manifest` true for a variable usable in constant\n  expressions' initializer (CP378 (a)).R1,i2567,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,fold-markm10,R4,L1,V1,R22,R7,s286,The condition `c` with :folds true or false when it constant-folds to an integer as clang's CodeGen asks\n  (ConstantFoldsToSimpleInteger: EvaluateAsInt, not a constant-evaluated context; the code generator then writes only the\n  live branch of an if, a conditional operator, && and ||).R1,i2581,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema3,lv?m10,R8,TR4,L1,V1,R5,R1,i2593,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,cast-nodem10,R8,TR4,L1,V3,R5,R23,R12,R1,i2595,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,fn-matchingm12,R8,TR4,L1,V2,R5,R24,R7,s163,The function of the overload set `e` whose type is the function type `ft` (the address of an overloaded function,\n  [over.over]), or its only one when `ft` is nil.R1,i2597,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,mptr-fn-nodem8,R4,L1,V1,R17,R1,i2610,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V1,R5,R7,s94,The prvalue of a glvalue of non-class type (lvalue-to-rvalue), an array's decay, a function's.R1,i2615,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,promote-typem10,R8,TR4,L1,V1,R12,R1,i2636,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,unsigned-ofm8,R25,R26,R27,R28,R29,R30,R31,R32,m8,R8,TR1,i2643,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,arith-commonm10,R4,L1,V2,R33,R34,R7,s59,The usual arithmetic conversions' type ([expr.arith.conv]).R1,i2645,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,null-constant?m12,R8,TR4,L1,V1,R5,R7,s205,A null pointer constant ([conv.ptr]/1): a prvalue of type std::nullptr_t, or an integral zero; (CX12, the checker) from\n  C++11 an integer literal ([conv.ptr]/1 since CWG 903), so `false`, a bool, is none.R1,i2668,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,class-idm10,R8,TR4,L1,V1,R12,R1,i2676,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,convert-scalarm10,R4,L1,V3,R5,R12,R35,R7,s108,The standard conversion of the prvalue `e` to the scalar type `t` (implicit or, with `explicit?`, a cast's).R1,i2678,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,ctor-candidatesm8,R0,TR1,i2721,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,resolve-overloadm8,R0,TR1,i2721,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,std-rankm12,R8,TR4,L1,V3,R5,R10,R11,R7,s119,The rank of the standard conversion from the prvalue type `from` (expression e) to the non-reference type `to`, or nil.R1,i2723,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,arr-unqm12,R8,TR4,L1,V1,R12,R7,s88,A type without its cv-qualifiers, an array's at its elements ([basic.type.qualifier]/3).R1,i2747,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,arr-cvm12,R8,TR4,L1,V1,R12,R7,s64,The type whose qualifiers are the type's (an array's elements').R1,i2749,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,conv-fnsm10,R4,L1,V1,R36,R7,s126,The conversion functions of class `id` and its bases ([class.conv.fct]), a derived class's hiding a base's of the same\n  name.R1,i2751,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,deduced!m8,R0,TR1,i2760,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,method-callm8,R0,TR1,i2760,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,init-form8,R0,TR1,i2760,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,var-nodem8,R0,TR1,i2760,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,conv-tmplsm10,R4,L1,V1,R36,R7,s118,cpp-s14 (CP389 (a)): the conversion function templates of class `id` and its bases ([class.conv.fct]/1, [temp.mem]/5).R1,i2762,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,conv-specsm12,R8,TR4,L1,V2,R36,R12,R7,s221,cpp-s14 (CP389 (a)): the conversion function templates' specializations of class `id` for the target type `t`\n  ([temp.deduct.conv]; [over.match.conv]/1: a template's specialization deduced for the target is a candidate).R1,i2767,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,glam-conv!m12,R8,TR4,L1,V2,R16,R37,R7,s641,CP301 (a): the conversion of a captureless generic lambda's closure (class `cid`) to a pointer to the function type\n  `F` ([expr.prim.lambda.closure]/9-10): the specialization of its conversion function template for F, made once per F,\n  returning the address of a static invoker (`__invoke`, a specialization of the invoker template as clang's, its\n  arguments the call operator's) that calls the call operator's specialization deduced from F's parameter types on a\n  closure object; nil when none is deduced or its type is not F (the result type is a pointer to the specialization's\n  type, which converts to no other pointer to function).R1,i2774,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,conv-form12,R8,TR4,L1,V5,R36,R12,R35,R38,V1,R39,R7,s126,The conversion function of class `id` that converts best to the non-class type `t` (explicit ones when\n  `explicit?`), or nil.R1,i2815,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,ref-conv-form12,R8,TR4,L1,V4,R36,R12,R38,V1,R39,R7,s691,cpp-s14: the conversion function of class `id` whose result the reference type `t` binds to directly ([dcl.init.ref]\n  /5.1.2 for an lvalue reference: an lvalue of a type `t` is reference-compatible with; /5.3.2 for an rvalue reference:\n  an xvalue of one; [over.match.ref]), a conversion function template's specialization deduced for the reference\n  ([temp.deduct.conv]/4) among them; an exact type before a base's; or nil; :ambiguous when no candidate is better\n  than every other ([over.match.best], [over.ics.rank]/4.4.4: two results of unrelated classes derived from the\n  reference's, PR c++/57948's g++.dg/conversion/ambig2.C). (A prvalue result binds through a temporary as before.)R1,i2840,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,*no-user*m8,R40,TR1,i2876,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,*conv-tmpl-cache*m8,R40,TR1,i2877,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,list-ctor-viable?m12,R8,TR4,L1,V2,R36,R41,R7,s544,cpp-s11 ([over.match.list], for [over.ics.list]/7): whether a constructor of the non-aggregate class `id` is viable\n  for the braced list's elements `items`: an initializer-list constructor taken as viable (its own conversion is the\n  element's, as before), an empty list as viable (value-initialization), else the constructors (the templates' deduced\n  specializations among them) for the elements as arguments; a refusal other than \"no viable function\" leaves it\n  viable, as before. Memoized per class and the elements' types and categories.R1,i2879,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema3,icsm10,R4,L1,V2,R5,R42,R7,s120,The implicit conversion sequence of the argument `e` (a typed expression or {:op :init-list}) to the parameter type `p`.R1,i2902,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,better-ics?m10,R8,TR4,L1,V2,R33,R34,R1,i2988,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,resolve-overload*m8,R0,TR1,i2995,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V3,R43,R18,R44,R7,s167,The best viable function of `cands` (fn ids) for the arguments `args` (typed expressions; `obj` the implicit object\n  argument of a method call, or nil), or a refusal.R1,i2997,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V2,R45,Myn2,n0m2,R46,R47,R7,s197,The best viable of the candidates `cs` ([fn-id args obj] each: a member operator's with its object, a non-member's\n  with every operand, [over.match.oper]/3), `n` the operands' count, or a refusal.R1,i3003,R2,i1,R3,s18,arbace/cpp/sema.aem8,R0,TR1,i3071,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,args-form8,R0,TR1,i3071,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,default-ctor-initm8,R0,TR1,i3071,R2,i1,R3,s18,arbace/cpp/sema.aem8,R0,TR1,i3071,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,materializem8,R0,TR1,i3071,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,ctor-initm8,R0,TR1,i3071,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,user-convm10,R4,L1,V4,R48,R5,R12,R35,R7,s100,The class object `e` converted to the non-class type `t` by a conversion function: the call's value.R1,i3073,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V1,R36,R7,s232,The constructors of class `id` overload resolution considers: the deleted ones too for the checker ([over.match.funcs]:\n  a deleted function is a candidate, and choosing it is the error, [dcl.fct.def.delete]/2), those it is sure of.R1,i3096,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,call-argsm12,R8,TR4,L1,V3,R14,R18,R48,R7,s134,The parameters' initializers for a call of `f` with the typed arguments `args` (default arguments analyzed in the\n  function's scope).R1,i3104,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V1,R12,R7,s95,E when the type `t` (cv-qualified, or a reference to it) is std::initializer_list<E>, else nil.R1,i3131,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,std-init-listm12,R8,TR4,L1,V3,R12,R49,R48,R7,s297,The prvalue std::initializer_list<E> a braced list `l` initializes ([dcl.init.list]/5-6, clang's\n  CXXStdInitializerListExpr): a backing array const E[N] whose elements are copy-initialized from the list's, the\n  object its first element's address and N; nil when an element does not convert to E.R1,i3140,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,init-list-ctorsm12,R8,TR4,L1,V1,R36,R7,s173,The initializer-list constructors of class `id` ([dcl.init.list]/2): a first parameter std::initializer_list<E> or a\n  reference to one, every other with a default argument.R1,i3150,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,aggr-subsm8,R0,TR1,i3159,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema20,cx-enclosing-classesm12,R8,TR4,L1,V1,R16,R7,s188,The class `cid` and the classes it is nested in ([class.access.nest]: a nested class is a member, with its enclosing\n  classes' access), or nil for a closure or a local class (not judged).R1,i3168,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,cx-contextm10,R4,L1,V1,R48,R7,s263,EffectiveContext of the analysis context `ctx`: {:records :fn}, the classes the use is a member of (the function's\n  class, or the class a member's initializer is analyzed in, with their enclosing classes) and the function; nil when\n  the slice does not judge it.R1,i3181,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,cx-friend-of?m12,R8,TR4,L1,V2,R22,R50,R7,s189,GetFriendKind: whether class `c` may befriend the context `cx`: a friend function of its function's name, a friend\n  class among its classes by name, or a friend the slice did not classify.R1,i3193,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,cx-member-ok?m12,R8,TR4,L1,V4,R50,R51,R33,R44,R7,s356,HasAccess ([class.access]/2, [class.protected]): a member of class `nc` with access `a` (as a member of nc) named in\n  the context `cx`; `obj` the object expression's class for a non-static member, else nil: a protected member through a\n  class D derived from nc that the context is a member or friend of needs an object of D or of a class derived from it.R1,i3204,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,cx-pathsm10,R8,TR4,L1,V2,R10,R11,R1,i3218,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,cx-access-ok?m10,R4,L1,V5,R50,R52,R33,R51,R44,R7,s230,Whether a member of class `dc` with access `a` named through the class `nc` (dc or a class derived from it) is\n  accessible in the context `cx` ([class.access.base]/5): true, false, or nil when the slice does not know (two paths).R1,i3221,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V6,R48,R52,R53,R33,R51,R44,R7,s224,The checker: a member `nm` of class `dc` with access `a`, named through class `nc` (nil: dc) with the object of class\n  `obj` (nil for a static member, a type, a constructor), inaccessible in the context of `ctx`: the error.R1,i3247,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,cx-ctor-access!m12,R8,TR4,L1,V2,R48,R54,R7,s404,CX12 (the checker): the constructor an initialization `r` calls, private or protected, inaccessible in its context\n  ([class.access]/1-2; [class.protected]: a protected one through a derived class's member or friend; the rest of CP313\n  (a): every context cx-context judges, a constructor template's specialization with its template's access; before it,\n  a namespace-scope variable's initializer alone).R1,i3260,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,class-initm12,R8,TR4,L1,V4,R12,R18,R48,R55,R7,s110,The initialization of an object of class type `t` by the arguments `args` (typed expressions or an init-list).R1,i3275,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,inheriting-ctor!m12,R8,TR4,L1,V2,R36,R56,R7,s682,CP330 (a): the constructor of class `id` that inherits the base constructor `bfid` ([namespace.udecl]/3,\n  [class.inhctor.init]), made once: the base constructor's parameters (and default arguments), its definition the base\n  subobject initialized by `bfid` with the parameters forwarded and the other subobjects default-initialized (as an\n  implicit default constructor's, their default member initializers), analyze-implicit!'s :inh-from. Mangled as Itanium\n  §5.1.4.3's inheriting constructor (CI1/CI2 and the base's name, abi/unqualified-name), as clang emits it at -O0. It is no\n  member of the class's :ctors: the base constructor stays the candidate overload resolution sees.R1,i3329,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,inherit-through!m12,R8,TR4,L1,V2,R36,R57,R7,s255,cpp-s4: the inheriting constructor of class `id` for the base constructor `g`, `g`'s class a direct base of `id` or\n  an indirect one whose constructors the bases between inherit ([class.inhctor.init]/1, each base's inheriting\n  constructor made in turn).R1,i3355,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L2,V3,R36,R18,R48,V4,R36,R18,R48,R58,R7,s347,A constructor of class `id` chosen for the arguments `args` by overload resolution, its call's initializer. `nested`:\n  the second phase of [over.match.list] with one element itself a list, where a conversion to X by a user-defined\n  conversion is not considered for a constructor's first parameter of type X or reference to X ([over.best.ics]/4).R1,i3368,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V2,R36,R59,R7,s68,Default- (or with `value?` value-) initialization of a class object.R1,i3429,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V1,R5,R7,s58,A prvalue of class type as a temporary object (an xvalue).R1,i3450,R2,i1,R3,s18,arbace/cpp/sema.aem8,R0,TR1,i3455,R2,i1,R3,s18,arbace/cpp/sema.aem12,R8,TR4,L1,V2,R60,R61,R7,s93,The types an aggregate's elements have, in order (an array of unknown bound: as many as `n`).R1,i3457,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,elide-aggm8,R0,TR1,i3467,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,elide-subm12,R8,TR4,L1,V2,R62,R41,R7,s208,One element of type `st` initialized from the flat items `items` ([dcl.init.aggr]/16, brace elision): a braced\n  item, an item that initializes it whole, or as many items as a subaggregate takes. [item rest].R1,i3469,R2,i1,R3,s18,arbace/cpp/sema.aem10,R8,TR4,L1,V2,R60,R41,R1,i3482,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,brace-elidem12,R8,TR4,L1,V2,R60,R63,R7,s113,The braced list `src` for the aggregate `u` with its elided braces restored (fully braced), when some are elided.R1,i3488,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V4,R12,R63,R48,R55,R7,s244,The initializer of an object of type `t` from `src`: nil (none), a typed expression, an init-list node\n  {:op :init-list :items [...]}, or a vector of constructor arguments (direct-initialization); `style` :copy :direct\n  :list :value :default.R1,i3504,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,int-type-ofm10,R8,TR4,L1,V1,Myn2,qtm2,R46,R64,R1,i3641,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,decode-stringm10,R4,L1,MV1,Myn1,sm2,R46,R64,m2,R46,R65,R7,s94,The bytes of a string literal as clang prints it (\"...\" with C escapes, octal for the others).R1,i3644,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,wide-unitsm12,R8,TR4,L1,V1,Myn1,sm2,R46,R64,R7,s190,The code units of a wide or Unicode string literal as clang prints it (L\"...\", u\"...\", U\"...\": each unit a\n  printable character or an escape, \\Uxxxxxxxx for the others, cpp-s12, CP382 (a)).R1,i3664,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V1,R33,R7,s65,A string literal node's code units, without the terminating zero.R1,i3685,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,capture-fieldm8,R0,TR1,i3690,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,this-exprm10,R8,TR4,L1,V1,R48,R1,i3692,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,deref-nodem10,R8,TR4,L1,V1,R5,R1,i3698,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,base-subobjectsm12,R8,TR4,L1,V2,R10,R11,R7,s178,The distinct base class subobjects of type `to` in class `from` ([class.mi]/4-6: the paths to it, those through a\n  virtual base the same subobject past it), as their identities.R1,i3703,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,cx-naming-classm12,R8,TR4,L1,V2,R48,R61,R7,s97,CX12 (the checker): the class a qualified name's nested-name-specifier names (B of B::f), or nil.R1,i3716,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,to-base-lvm12,R8,TR4,L1,V2,R44,R66,R7,s60,The glvalue `obj` of a derived class seen as its base `bid`.R1,i3723,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,cx-viam12,R8,TR4,L1,V2,R44,R67,R7,s296,CX12 (the checker): the object glvalue seen first as the naming class `qc` of a qualified member when that is a proper\n  base of its class ([class.access.base]/6, [class.member.lookup]: the member's subobject is the naming class's), so the\n  conversion to the member's class is judged from there.R1,i3733,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,field-nodem10,R8,TR4,L1,V3,R44,R16,R20,R1,i3743,R2,i1,R3,s18,arbace/cpp/sema.aem10,R8,TR4,L1,V1,R36,R1,i3751,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,*unevaluated*m10,R40,TR1,i3757,R2,i1,R3,s18,arbace/cpp/sema.aeR7,s246,CP304 (a): true while an unevaluated operand is analyzed (sizeof's, alignof's, noexcept's): an enclosing function's\n  variable named there is not odr-used, so a lambda does not capture it ([expr.prim.lambda.capture]/7-8); only its type is\n  read.v15,arbace.cpp.sema13,check-access!m8,R0,TR1,i3763,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,entity-exprm10,R8,TR4,L1,V3,R48,R68,R61,R1,i3765,R2,i1,R3,s18,arbace/cpp/sema.ae")

var Lit_1432 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_eval")

var Lit_1433 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_exec")

var Lit_1434 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_base_path")

var Lit_1435 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_lv")

var Lit_1436 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_glvalue")

var Lit_1437 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_store")

var Lit_1438 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_zero_of")

var Lit_1439 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_args_env")

var Lit_1440 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_construct")

var Lit_1441 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_init")

var Lit_1442 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_call_fn")

var Lit_1443 *jrt.String = jrt.Intern("arbace.cpp.sema$ce_try")

var Lit_1444 *jrt.String = jrt.Intern("arbace.cpp.sema$fold_mark")

var Lit_1445 *jrt.String = jrt.Intern("arbace.cpp.sema$lv_QMARK_")

var Lit_1446 *jrt.String = jrt.Intern("arbace.cpp.sema$cast_node")

var Lit_1447 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_matching")

var Lit_1448 *jrt.String = jrt.Intern("arbace.cpp.sema$mptr_fn_node")

var Lit_1449 *jrt.String = jrt.Intern("arbace.cpp.sema$rv")

var Lit_1450 *jrt.String = jrt.Intern("arbace.cpp.sema$promote_type")

var Lit_1451 *jrt.String = jrt.Intern("arbace.cpp.sema$arith_common")

var Lit_1452 *jrt.String = jrt.Intern("arbace.cpp.sema$null_constant_QMARK_")

var Lit_1453 *jrt.String = jrt.Intern("arbace.cpp.sema$class_id")

var Lit_1454 *jrt.String = jrt.Intern("arbace.cpp.sema$convert_scalar")

var Lit_1455 *jrt.String = jrt.Intern("arbace.cpp.sema$std_rank")

var Lit_1456 *jrt.String = jrt.Intern("arbace.cpp.sema$arr_unq")

var Lit_1457 *jrt.String = jrt.Intern("arbace.cpp.sema$arr_cv")

var Lit_1458 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_fns")

var Lit_1459 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_tmpls")

var Lit_1460 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_specs")

var Lit_1461 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_conv_BANG_")

var Lit_1462 *jrt.String = jrt.Intern("arbace.cpp.sema$conv_for")

var Lit_1463 *jrt.String = jrt.Intern("arbace.cpp.sema$ref_conv_for")

var Lit_1464 *jrt.String = jrt.Intern("arbace.cpp.sema$list_ctor_viable_QMARK_")

var Lit_1465 *jrt.String = jrt.Intern("arbace.cpp.sema$ics")

var Lit_1466 *jrt.String = jrt.Intern("arbace.cpp.sema$better_ics_QMARK_")

var Lit_1467 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload")

var Lit_1468 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_overload_STAR_")

var Lit_1469 *jrt.String = jrt.Intern("arbace.cpp.sema$user_conv")

var Lit_1470 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_candidates")

var Lit_1471 *jrt.String = jrt.Intern("arbace.cpp.sema$call_args")

var Lit_1472 *jrt.String = jrt.Intern("arbace.cpp.sema$init_list_elem")

var Lit_1473 *jrt.String = jrt.Intern("arbace.cpp.sema$std_init_list")

var Lit_1474 *jrt.String = jrt.Intern("arbace.cpp.sema$init_list_ctors")

var Lit_1475 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_enclosing_classes")

var Lit_1476 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_context")

var Lit_1477 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_friend_of_QMARK_")

var Lit_1478 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_member_ok_QMARK_")

var Lit_1479 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_paths")

var Lit_1480 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_ok_QMARK_")

var Lit_1481 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_access_BANG_")

var Lit_1482 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_ctor_access_BANG_")

var Lit_1483 *jrt.String = jrt.Intern("arbace.cpp.sema$class_init")

var Lit_1484 *jrt.String = jrt.Intern("arbace.cpp.sema$inheriting_ctor_BANG_")

var Lit_1485 *jrt.String = jrt.Intern("arbace.cpp.sema$inherit_through_BANG_")

var Lit_1486 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_init")

var Lit_1487 *jrt.String = jrt.Intern("arbace.cpp.sema$default_ctor_init")

var Lit_1488 *jrt.String = jrt.Intern("arbace.cpp.sema$materialize")

var Lit_1489 *jrt.String = jrt.Intern("arbace.cpp.sema$aggr_subs")

var Lit_1490 *jrt.String = jrt.Intern("arbace.cpp.sema$elide_sub")

var Lit_1491 *jrt.String = jrt.Intern("arbace.cpp.sema$elide_agg")

var Lit_1492 *jrt.String = jrt.Intern("arbace.cpp.sema$brace_elide")

var Lit_1493 *jrt.String = jrt.Intern("arbace.cpp.sema$init_for")

var Lit_1494 *jrt.String = jrt.Intern("arbace.cpp.sema$int_type_of")

var Lit_1495 *jrt.String = jrt.Intern("arbace.cpp.sema$decode_string")

var Lit_1496 *jrt.String = jrt.Intern("arbace.cpp.sema$wide_units")

var Lit_1497 *jrt.String = jrt.Intern("arbace.cpp.sema$str_units")

var Lit_1498 *jrt.String = jrt.Intern("arbace.cpp.sema$this_expr")

var Lit_1499 *jrt.String = jrt.Intern("arbace.cpp.sema$deref_node")

var Lit_1500 *jrt.String = jrt.Intern("arbace.cpp.sema$base_subobjects")

var Lit_1501 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_naming_class")

var Lit_1502 *jrt.String = jrt.Intern("arbace.cpp.sema$to_base_lv")

var Lit_1503 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_via")

var Lit_1504 *jrt.String = jrt.Intern("arbace.cpp.sema$field_node")

var Lit_1505 *jrt.String = jrt.Intern("arbace.cpp.sema$var_node")

var Lit_1506 *jrt.String = jrt.Intern("arbace.cpp.sema$entity_expr")

var Lit_1507 *jrt.String = jrt.Intern("kn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn2,nmkn3,docyn3,ctxyn1,nyn1,oyn1,lyn1,ryn1,ekn8,declaredkn3,tagyn6,Stringyn1,tyn8,explicityn5,itemsyn2,esyn3,cidyn3,accyn5,scopeyn4,nodeyn1,fyn6,accessyn2,ncyn3,objyn3,fidyn4,argsyn10,virtual-okyn2,nsyn3,eidyn4,aclsyn3,nssyn6,calleekn4,loadkn1,okn5,fencekn3,taskn6,sfencekn5,storekn1,vkn5,clearkn4,xchgkn7,cmpxchgkn2,epkn1,wkn2,fokn2,rpkn2,vpkn5,ctpopkn6,expectkn5,bswapkn6,ushortkn8,va-startkn4,uintkn4,cttzkn9,lock-freekn12,sub-overflowkn6,ullongkn10,constant-pkn7,signbitkn5,ulongkn4,ctlzkn6,allocakn7,va-copykn9,addressofkn12,add-overflowkn21,is-constant-evaluatedkn13,clear-paddingkn12,mul-overflowkn8,isfinitekn6,va-endkn4,castkn4,addryn7,global?yn3,idsyn6,targetyn6,array?kn4,keysyn4,sizeyn5,alignyn2,etyn5,placekn7,dynamicyn1,kyn4,lctxyn2,fsyn3,ampyn1,xyn4,bodyyn1,cyn1,ayn1,byn2,ctyn2,qtv15,arbace.cpp.sema18,implicit-alloc-fnsm8,s12,operator newV2,s21,void *(unsigned long)V1,s13,unsigned longs14,operator new[]V2,s21,void *(unsigned long)V1,s13,unsigned longs15,operator deleteV2,V2,s22,void (void *) noexceptV1,s6,void *V2,s37,void (void *, unsigned long) noexceptV2,s6,void *s13,unsigned longs17,operator delete[]V2,V2,s22,void (void *) noexceptV1,s6,void *V2,s37,void (void *, unsigned long) noexceptV2,s6,void *s13,unsigned longm8,R0,TR1,i3812,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,implicit-alloc!m12,R0,TR4,L1,V1,R5,R6,s275,The implicit global declarations of the allocation or deallocation function `nm` entered in the root scope, the first\n  time a name expression names one that no declaration (<new>'s) has declared (cpp-route: g++.dg's cpp0x/defaulted19a.C,\n  ::operator new (t) without <new>).R1,i3820,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,name-exprm10,R0,TR4,L1,V2,R7,R8,R1,i3836,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,arith-binopm10,R0,TR4,L1,V3,R9,R10,R11,R1,i3856,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,to-boolm10,R0,TR4,L1,V1,R12,R1,i3860,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,operator-callm8,R13,TR1,i3865,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,analyze-callm8,R13,TR1,i3865,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,analyze-argsm8,R13,TR1,i3865,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema20,rewritten-relationalm8,R13,TR1,i3865,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,class->scalarm12,R0,TR4,L1,V2,R7,R12,R6,s160,A class operand of a built-in operator by its conversion function (the one non-explicit, [over.built]'s candidates\n  narrowed to it); another operand unchanged.R1,i3867,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,class-operand?m10,R0,TR4,L1,V1,R12,R1,i3879,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,ordering-typem12,R0,TR4,L1,V1,Myn2,nmm2,R14,R15,R6,s92,std::strong_ordering, weak_ordering or partial_ordering (<compare>'s classes), or a refusal.R1,i3881,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,three-waym12,R0,TR4,L1,V2,R10,R11,R6,s191,The built-in three-way comparison ([expr.spaceship]): the operands' common type, its category's class prvalue\n  ({:op :cmp3}, the code generator's -1, 0, 1 or partial_ordering's unordered 2).R1,i3887,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,builtin-binopm10,R0,TR4,L1,V3,R9,R10,R11,R1,i3900,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,assign-nodem10,R0,TR4,L1,V3,R7,R10,R11,R1,i3944,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,compound-nodem10,R0,TR4,L1,V3,R9,R10,R11,R1,i3959,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,cast-exprm10,R0,TR4,L1,V4,R7,R16,R12,R17,R1,i3966,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,scalar-list-castm12,R0,TR4,L1,V3,R7,R16,R18,R6,s208,T{items...} of a non-class type `t` ([expr.type.conv]/2, [dcl.init.list]/3.10-3.11): no item, the value-initialized\n  prvalue; one, it converted to `t` (a narrowing conversion not diagnosed); more, a refusal.R1,i3980,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L1,V1,R19,R6,s115,CP324 (a): {fn-id [class access]} for the functions among the entities `es` that a class's using-declaration named.R1,i3989,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,method-set-ofm12,R0,TR4,L1,V2,R20,R5,R6,s73,[class-id fn-ids] of the members named `nm` of the class of object `obj`.R1,i3994,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,cx-type-friend?m12,R0,TR4,L1,V2,R20,R21,R6,s274,The rest of CP313 (a): whether a friend declaration may grant a member type of class `cid` with access `acc` (the\n  class declares a friend, or for a protected one a class derived from it does), in place of the third slice's gate (no\n  class of the unit declaring a friend).R1,i4000,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,check-type-access!m12,R0,TR4,L1,V3,R22,Myn4,textm2,R14,R15,R23,R6,s581,CX12 (the checker): [class.access]/1-2 for the member types a declaration's type names by a qualified name (A::X with\n  X a private or protected typedef of the class A), in a declaration that is no class member's (a variable at namespace\n  scope with an unqualified name, or a local of a function that is no class's member nor a template's specialization),\n  where no class of the unit declares a friend: inaccessible ([class.access]/6's deferred check of a member's own\n  declaration, A::X A::v, is not judged: only unqualified declarators). `node` the declaration (its position).R1,i4008,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,friend-may-grant?m12,R0,TR4,L1,V3,R20,R24,R25,R6,s616,CP313 (a), clang's SemaAccess.cpp (llvmorg-23.1.5) EffectiveContext and GetFriendKind for a non-member function `f`\n  naming a member of class `cid`: whether a friend declaration could make it accessible -- `cid` declares a friend function\n  or function template of f's name (by name: an overload or a qualified friend counts, missed never wrong), or a friend it\n  could not classify; for a protected member ([class.protected]: a friend of a derived class may name it through the\n  derived class) any class derived from `cid` that declares a friend; a class's friend classes grant nothing to a\n  non-member function.R1,i4036,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L2,V4,R7,R20,R5,R25,V6,R7,R20,R5,R25,R26,R27,R6,s435,CX12 (the checker): [class.access]/1-2 for a member named in an expression: a private or protected member of class\n  `cid` named in a function that is no class's member (nor in a class's scope): inaccessible unless a friend declaration\n  may grant it (CP313 (a), friend-may-grant?; before it, judged only where no class of the unit declared a friend).\n  Everything else (members, templates' patterns, using-declarations) is not judged.R1,i4051,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,member-exprm10,R0,TR4,L1,V2,R7,R8,R1,i4066,R2,i1,R3,s18,arbace/cpp/sema.aem8,R13,TR1,i4115,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,has-auto?m8,R13,TR1,i4115,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema21,defaulted-comparison!m8,R13,TR1,i4117,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L1,V1,R28,R6,s175,The function `fid` with its deduced return type deduced ([dcl.spec.auto.general]/11: a use needs its definition\n  analyzed first; G4: <bits/ptr_traits.h>'s auto __to_address).R1,i4119,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,cx-immediate-call!m8,R13,TR1,i4134,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L1,V5,R7,R28,R27,R29,R30,R6,s80,A call of the method `fid` on the object glvalue `obj` with the typed arguments.R1,i4136,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L1,V2,R7,R24,R6,s254,CP310 (b), the checker: an immediate invocation ([expr.const]/16: a call of an immediate function outside one) is a\n  constant expression, so one of a function whose own body the checker found not constant (a constexpr error in it) is\n  not, at the call.R1,i4145,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,fn-callm10,R0,TR4,L1,V3,R7,R28,R29,R1,i4154,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,adl-nssm10,R4,L1,V1,R31,R6,s295,CP338 (a): the namespace `ns` with, when it is an inline namespace, the namespaces enclosing it as far as the first that is\n  not ([basic.lookup.argdep]/3: an inline namespace's enclosing namespace is associated too; std::__cxx11's std, where\n  operator+(const _CharT*, const basic_string&) is).R1,i4160,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,enum-assocm12,R0,TR4,L1,V1,R32,R6,s215,cpp-s11: an enumeration's associated entities ([basic.lookup.argdep]/3.3): its innermost enclosing namespace (with\n  adl-nss's inline enclosers), and when it is a class member that class, as [:ns NS] and [:cls CID].R1,i4171,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,adl-class-nssm10,R4,L1,V1,R20,R6,s425,cpp-s3: the namespaces associated with the class `cid` ([basic.lookup.argdep]/3): its innermost enclosing namespace's\n  (adl-nss), its bases', and for a class template's specialization its template type arguments' (classes, and the classes\n  pointers, references and arrays name), each class once; pr77550.C's distance(begin, end), std::distance found through an\n  iterator adaptor's argument std::F<...>. Scopes by identity.R1,i4181,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,adl-classesm12,R0,TR4,L1,V1,R29,R6,s233,cpp-s8: the classes associated with the arguments `args` ([basic.lookup.argdep]/3: each class argument's class, its\n  bases, a specialization's template type arguments' classes; a pointer's or reference's pointee's), as a set of ids.R1,i4210,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,friend-visible?m12,R0,TR4,L1,V2,R33,R12,R6,s645,cpp-s8: whether the entity `e` (a lookup's entry) is visible to a call with arguments of the associated classes `acls`:\n  a friend function (template) defined in a class and not declared in its namespace (a hidden friend, [class.friend]/7,\n  [namespace.memdef]/3) is found by argument-dependent lookup alone, when its class is associated ([basic.lookup.argdep]/4.3);\n  <bits/unreachable_sentinel.h>'s `template<weakly_incrementable _It> friend bool operator==(unreachable_sentinel_t,\n  const _It&)` had been a candidate for every `a == b`, and its constraint's satisfaction for a __normal_iterator recursed\n  through iterator_traits into itself.R1,i4232,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,adl-fnsm12,R0,TR4,L1,V2,R29,R5,R6,s112,The functions named `nm` in the namespaces of the class arguments' classes ([basic.lookup.argdep], for classes).R1,i4242,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,sure-assoc-nssm12,R0,TR4,L1,V1,R29,R6,s404,CX12 (the checker): the associated namespaces of the arguments `args` ([basic.lookup.argdep]/3) when the slice knows\n  them all -- each argument of a fundamental type, an enumeration, a pointer or reference to one, or a class that is no\n  template's specialization, with its bases' classes the same -- and no class of the unit declares a friend (a hidden\n  friend is found by ADL alone); nil when unsure.R1,i4259,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,declared-in?m10,R0,TR4,L1,V2,R34,Myn2,nmm2,R14,R15,R1,i4285,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,no-operator!m12,R0,TR4,L1,V3,R7,Myn1,om2,R14,R15,R29,R6,s639,CX12 (the checker): an operator expression with a class operand that no overloaded operator was found for\n  ([over.match.oper]/3: no member candidate, no non-member found by unqualified lookup -- at a template's definition,\n  [temp.res]/[temp.dep.candidate] -- or by ADL, and no operator template among them) and that has no conversion function, so\n  no built-in candidate applies ([over.built]): ill-formed (clang's err_ovl_no_viable_oper, \"invalid operands to binary\n  expression\"; gcc's \"no match for 'operator@'\"). Only where the slice is sure: the associated namespaces known\n  (sure-assoc-nss) and none declaring the operator's name.R1,i4288,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,adl-not-found!m12,R0,TR4,L1,V3,R7,R35,R29,R6,s557,CX12 (the checker): an unqualified call in a function template's specialization that nothing names: not unqualified\n  lookup at the template's definition ([temp.dep.candidate]: the declarations visible there), not ADL at its\n  instantiation, though a later declaration at namespace scope declares the name ([temp.res]/[temp.point]; clang's\n  err_not_found_by_two_phase_lookup, gcc's \"... not declared in this scope, and no declarations were found by\n  argument-dependent lookup at the point of instantiation\"). Only where the associated namespaces are sure.R1,i4308,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,undeclared-call!m12,R0,TR4,L1,V3,R7,R35,R29,R6,s328,CX12 (the checker): an unqualified call outside any template's specialization that unqualified lookup finds nothing\n  for and whose associated namespaces (sure-assoc-nss) declare no function of the name: no ADL candidate either\n  ([basic.lookup.argdep]/4; clang's err_undeclared_var_use, gcc's \"was not declared in this scope\").R1,i4323,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,block-ctxm8,R13,TR1,i4340,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,atomic-formsv11,arbace.core5,mergem24,s15,__atomic_load_nV2,R36,V1,R37,s21,__atomic_thread_fenceV2,R38,V1,R37,s21,__atomic_test_and_setV2,R39,V1,R37,s21,__atomic_signal_fenceV2,R40,V1,R37,s16,__atomic_store_nV2,R41,V2,R42,R37,s14,__atomic_clearV2,R43,V1,R37,s19,__atomic_exchange_nV2,R44,V2,R42,R37,s27,__atomic_compare_exchange_nV2,R45,V5,R46,R42,R47,R37,R48,s13,__atomic_loadV2,R36,V2,R49,R37,s25,__atomic_compare_exchangeV2,R45,V5,R46,R50,R47,R37,R48,s14,__atomic_storeV2,R41,V2,R50,R37,s17,__atomic_exchangeV2,R44,V3,R50,R49,R37,v11,arbace.core4,intom8,R0,TR1,i4347,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,atomic-builtin?m8,R4,L1,V1,Myn2,nmm2,R14,R15,R1,i4362,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,atomic-exprm12,R0,TR4,L1,V3,R7,Myn2,nmm2,R14,R15,R29,R6,s77,The node of a GNU __atomic builtin `nm` applied to the argument nodes `args`.R1,i4364,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,value-builtinsm66,s19,__builtin_popcountgV2,R51,ns33,__builtin_expect_with_probabilityR52,s17,__builtin_bswap16V2,R53,R54,s22,__builtin_c23_va_startR55,s17,__builtin_bswap32V2,R53,R56,s14,__builtin_ctzgV2,R57,ns21,__atomic_is_lock_freeR58,s13,__builtin_ctzV2,R57,R56,s18,__builtin_popcountV2,R51,R56,s22,__builtin_sub_overflowR59,s15,__builtin_ctzllV2,R57,R60,s20,__builtin_constant_pR61,s16,__builtin_expectR52,s17,__builtin_signbitR62,s20,__builtin_popcountllV2,R51,R60,s14,__builtin_ctzlV2,R57,R63,s19,__builtin_popcountlV2,R51,R63,s15,__builtin_clzllV2,R64,R60,s16,__builtin_allocaR65,s13,__builtin_clzV2,R64,R56,s17,__builtin_va_copyR66,s14,__builtin_clzgV2,R64,ns19,__builtin_addressofR67,s14,__builtin_clzlV2,R64,R63,s17,__builtin_bswap64V2,R53,R63,s22,__builtin_add_overflowR68,s31,__builtin_is_constant_evaluatedR69,s23,__builtin_clear_paddingR70,s22,__builtin_mul_overflowR71,s25,__atomic_always_lock_freeR58,s18,__builtin_isfiniteR72,s16,__builtin_va_endR73,s18,__builtin_va_startR55,m8,R0,TR1,i4397,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,std-builtinsm14,s4,moveR74,s7,forwardR74,s16,move_if_noexceptR74,s8,as_constR74,s12,forward_likeR74,s9,addressofR75,s11,__addressofR75,m8,R0,TR1,i4416,R2,i1,R3,s18,arbace/cpp/sema.aem8,R13,TR1,i4419,R2,i1,R3,s18,arbace/cpp/sema.aem8,R4,L1,V3,R7,R35,R29,R1,i4421,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V3,R7,R9,R29,R6,s204,An overloaded operator's call ([over.match.oper]): the members of the first operand's class and the non-members found\n  by unqualified lookup and ADL; nil when none is viable (the built-in operator then).R1,i4471,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L1,V3,R7,R9,R29,R6,s114,x @ y for a relational @ by a three-way comparison ([over.match.oper]/3.4, /8): (x <=> y) @ 0, else 0 @ (y <=> x).R1,i4519,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,new-alignl16,m8,R0,TR1,i4537,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,overaligned?m8,R4,L1,V1,R16,R1,i4539,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,align-val-tm10,R0,TR4,L1,V0,R1,i4541,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,size-t?m10,R0,TR4,L1,V1,R16,R1,i4543,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,align-t?m10,R0,TR4,L1,V1,R16,R1,i4544,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,void-ptr?m10,R0,TR4,L1,V1,R16,R1,i4545,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema6,fn-idsm10,R0,TR4,L1,V1,R19,R1,i4547,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,alloc-lookupm12,R0,TR4,L1,V3,R20,Myn2,nmm2,R14,R15,R76,R6,s167,[:class ids] when the class `cid` (not ::-qualified) declares or inherits `nm`, else [:global ids] (ids empty when no\n  header declares it: the implicit declarations).R1,i4549,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,usual-dealloc-infom12,R0,TR4,L1,V1,R28,R6,s111,UsualDeallocFnInfo of a deallocation function: {:size :align} when it is a usual (non-placement) one, else nil.R1,i4556,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,resolve-deallocm12,R0,TR4,L1,V2,R77,R78,R6,s170,The usual deallocation function of `ids` preferred for the target {:size :align} (Compare: the alignment parameter as\n  the target asks, then the size parameter), or nil.R1,i4565,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,implicit-deallocm12,R0,TR4,L1,V2,R79,m2,R80,V2,R81,R82,R6,s96,The implicitly declared global deallocation function for {:size :align} ([basic.stc.dynamic]/2).R1,i4575,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,global-deallocm10,R4,L1,V2,R79,R78,R6,s89,FindUsualDeallocationFunction: the global usual deallocation function for {:size :align}.R1,i4580,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,dtor-deallocm10,R4,L1,V1,R20,R6,s108,FindDeallocationFunctionForDestructor: the deallocation function a deleting destructor of class `cid` calls.R1,i4587,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema24,array-delete-wants-size?m12,R0,TR4,L1,V1,R83,R6,s83,doesUsualArrayDeleteWantSize: the class's own usual operator delete[] takes a size.R1,i4595,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,find-allocationm12,R0,TR4,L1,V5,R7,R83,R79,R76,R84,R6,s256,FindAllocationFunctions for `new T` (`array?`, `global?` for ::new, `place` the placement arguments): {:alloc choice\n  :dealloc choice-or-nil :reserved bool} (:reserved: the reserved placement form operator new(size_t, void*), which clang\n  calls not; G4).R1,i4602,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,delete-deallocm12,R0,TR4,L1,V3,R83,R79,R76,R6,s102,The deallocation function of `delete p` / `delete[] p` (ActOnCXXDelete), with the array's cookie need.R1,i4648,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,new-exprm10,R0,TR4,L1,V2,R7,R8,R1,i4660,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,dtor-ofm10,R0,TR4,L1,V1,R20,R1,i4696,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L1,V2,R7,R31,R6,s114,The typed expressions of argument nodes, a pack expansion (args...) analyzed once for each of its packs' elements.R1,i4698,R2,i1,R3,s18,arbace/cpp/sema.aem8,R13,TR1,i4712,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema8,nrvo-varm8,R13,TR1,i4712,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,analyze-implicit!m8,R13,TR1,i4712,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,deduce-autom8,R13,TR1,i4712,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,cx-check-constant!m8,R13,TR1,i4712,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,*lambda-counts*m8,R85,TR1,i4714,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,split-topm12,R0,TR4,L1,V1,Myn1,sm2,R14,R15,R6,s52,The comma-separated parts of `s` at bracket depth 0.R1,i4716,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,capture-introm10,R0,TR4,L1,V1,Myn4,textm2,R14,R15,R1,i4729,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V2,R7,R86,R6,s195,The expression of a captured entity (a variable's id or :this) inside the lambda of `ctx`: the closure's field,\n  added (with its initializer, analyzed in the enclosing context) on the first use.R1,i4737,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,init-capture!m12,R0,TR4,L1,V5,R87,R88,R89,R5,R23,R6,s185,An init-capture ([expr.prim.lambda.capture]/6): a field of the deduced type initialized by the expression analyzed in\n  the enclosing context, its name the field's in the lambda's body.R1,i4776,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema19,generic-lambda-exprm8,R13,TR1,i4789,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,lambda-exprm10,R0,TR4,L1,V2,R7,R8,R1,i4791,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,node-childrenm12,R0,TR4,L1,V1,R90,R6,s172,A node's children for the generic lambda's scans: its :inner, a fold expression's operands (CP291 (a)) and a nested\n  generic lambda's parameters (CP290 (a)), kept as data.R1,i4880,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,glam-namesm12,R0,TR4,L1,V1,R91,R6,s151,CP290 (a): the names a generic lambda's body refers to by an unqualified id, and whether it uses `this`, in the\n  order written ([{:name s} or :this]).R1,i4886,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,glam-declaredm12,R0,TR4,L1,V1,R91,R6,s149,The names a generic lambda's body declares (its variables, bindings, functions' parameters): a reference to one of\n  them is not taken for a capture.R1,i4907,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L1,V2,R7,R8,R6,s930,CP290 (a): a generic lambda ([expr.prim.lambda.closure]/3-4: a parameter declared `auto` or a template-parameter-list):\n  its closure's function call operator is a member function template, one invented type template parameter for each\n  parameter's `auto` (a pack for `auto...`) after the explicit ones, its specializations deduced from a call and\n  instantiated on use as a function template's are (arbace.cpp.template), their bodies analyzed in the lambda's context\n  (the captures, `this`). The closure object is made here, so its captures are found here: the explicit ones, and for a\n  capture-default the variables and `this` the body names ([expr.prim.lambda.capture]/7: in a generic lambda an entity\n  named in a dependent full-expression is captured), in the order written; a specialization that needs another is\n  refused. No conversion to a pointer to function (a conversion function template): a use of one is refused.R1,i4915,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,opaque-idsm8,R0,TR1,i5019,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,cond-nodem12,R0,TR4,L1,V4,R7,R92,R93,R94,R6,s118,The conditional operator's node of the analyzed condition `c` (contextually bool) and operands `a`, `b` ([expr.cond]).R1,i5021,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,analyze-nodem8,R13,TR1,i5051,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,ctad-exprm12,R0,TR4,L1,V3,R7,R8,R95,R6,s212,CP311 (a): T(args) or T{...} with T the placeholder `ct` ([tid #{cv}]) for a deduced class type ([expr.type.conv]/1:\n  the type deduced as for a variable direct-initialized by the initializer), a temporary of it.R1,i5053,R2,i1,R3,s18,arbace/cpp/sema.aem10,R4,L1,V2,R7,R8,R6,s93,The typed expression of the tree node `n` in the context `ctx` ({:scope :fn :this-type ...}).R1,i5064,R2,i1,R3,s18,arbace/cpp/sema.aem10,R0,TR4,L1,V2,R7,R8,R1,i5071,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema12,p2266-xvaluem12,R0,TR4,L1,V1,R93,R6,s406,C++23's P2266 ([expr.prim.id.unqual]/3 with [basic.lval]/4): in a return statement an id-expression naming an implicitly\n  movable entity -- an automatic variable or parameter of object type, or of rvalue reference type to an object type, not\n  volatile -- is an xvalue, whatever the return type (found with CP305's explicit instantiations, cpp23/elision7); the typed\n  expression `a` as one, or as it was.R1,i5559,R2,i1,R3,s18,arbace/cpp/sema.aem8,R13,TR1,i5580,R2,i1,R3,s18,arbace/cpp/sema.aem8,R13,TR1,i5582,R2,i1,R3,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,ctad-initm12,R0,TR4,L1,V2,R7,R8,R6,s256,CP311 (a): a variable's initializer analyzed for class template argument deduction, [kind init]: kind :direct,\n  :copy, :list-direct or :list-copy ([dcl.init.general]/15-16, [dcl.init.list]/1), init the arguments' vector, the\n  expression or the init-list.R1,i5584,R2,i1,R3,s18,arbace/cpp/sema.aem12,R0,TR4,L1,V4,R7,R8,R95,R96,R6,s458,CP311 (a): {:ty :ctad-init} for a variable declared with the placeholder `ct` ([tid #{cv}]) for a deduced class type\n  ([dcl.type.class.deduct]/1): the type the :ctad hook deduces from the analyzed initializer (kept for the variable's\n  initialization, analyzed once), else -- the slice not sure, or for the code generator also a program it finds\n  ill-formed -- the parser's own deduction when it made one (`qt` spelled with the arguments, the tree's type).R1,i5597,R2,i1,R3,s18,arbace/cpp/sema.ae")

var Lit_1508 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_alloc_BANG_")

var Lit_1509 *jrt.String = jrt.Intern("arbace.cpp.sema$name_expr")

var Lit_1510 *jrt.String = jrt.Intern("arbace.cpp.sema$arith_binop")

var Lit_1511 *jrt.String = jrt.Intern("arbace.cpp.sema$to_bool")

var Lit_1512 *jrt.String = jrt.Intern("arbace.cpp.sema$class__GT_scalar")

var Lit_1513 *jrt.String = jrt.Intern("arbace.cpp.sema$class_operand_QMARK_")

var Lit_1514 *jrt.String = jrt.Intern("arbace.cpp.sema$ordering_type")

var Lit_1515 *jrt.String = jrt.Intern("arbace.cpp.sema$three_way")

var Lit_1516 *jrt.String = jrt.Intern("arbace.cpp.sema$builtin_binop")

var Lit_1517 *jrt.String = jrt.Intern("arbace.cpp.sema$assign_node")

var Lit_1518 *jrt.String = jrt.Intern("arbace.cpp.sema$compound_node")

var Lit_1519 *jrt.String = jrt.Intern("arbace.cpp.sema$cast_expr")

var Lit_1520 *jrt.String = jrt.Intern("arbace.cpp.sema$scalar_list_cast")

var Lit_1521 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_using_map")

var Lit_1522 *jrt.String = jrt.Intern("arbace.cpp.sema$method_set_of")

var Lit_1523 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_type_friend_QMARK_")

var Lit_1524 *jrt.String = jrt.Intern("arbace.cpp.sema$check_type_access_BANG_")

var Lit_1525 *jrt.String = jrt.Intern("arbace.cpp.sema$friend_may_grant_QMARK_")

var Lit_1526 *jrt.String = jrt.Intern("arbace.cpp.sema$check_access_BANG_")

var Lit_1527 *jrt.String = jrt.Intern("arbace.cpp.sema$member_expr")

var Lit_1528 *jrt.String = jrt.Intern("arbace.cpp.sema$deduced_BANG_")

var Lit_1529 *jrt.String = jrt.Intern("arbace.cpp.sema$method_call")

var Lit_1530 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_immediate_call_BANG_")

var Lit_1531 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_call")

var Lit_1532 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_nss")

var Lit_1533 *jrt.String = jrt.Intern("arbace.cpp.sema$enum_assoc")

var Lit_1534 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_class_nss")

var Lit_1535 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_classes")

var Lit_1536 *jrt.String = jrt.Intern("arbace.cpp.sema$friend_visible_QMARK_")

var Lit_1537 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_fns")

var Lit_1538 *jrt.String = jrt.Intern("arbace.cpp.sema$sure_assoc_nss")

var Lit_1539 *jrt.String = jrt.Intern("arbace.cpp.sema$declared_in_QMARK_")

var Lit_1540 *jrt.String = jrt.Intern("arbace.cpp.sema$no_operator_BANG_")

var Lit_1541 *jrt.String = jrt.Intern("arbace.cpp.sema$adl_not_found_BANG_")

var Lit_1542 *jrt.String = jrt.Intern("arbace.cpp.sema$undeclared_call_BANG_")

var Lit_1543 *jrt.String = jrt.Intern("arbace.cpp.sema$fn__916001902")

var Lit_1544 *jrt.String = jrt.Intern("arbace.cpp.sema$atomic_builtin_QMARK_")

var Lit_1545 *jrt.String = jrt.Intern("arbace.cpp.sema$atomic_expr")

var Lit_1546 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_call")

var Lit_1547 *jrt.String = jrt.Intern("arbace.cpp.sema$operator_call")

var Lit_1548 *jrt.String = jrt.Intern("arbace.cpp.sema$rewritten_relational")

var Lit_1549 *jrt.String = jrt.Intern("arbace.cpp.sema$overaligned_QMARK_")

var Lit_1550 *jrt.String = jrt.Intern("arbace.cpp.sema$align_val_t")

var Lit_1551 *jrt.String = jrt.Intern("arbace.cpp.sema$size_t_QMARK_")

var Lit_1552 *jrt.String = jrt.Intern("arbace.cpp.sema$align_t_QMARK_")

var Lit_1553 *jrt.String = jrt.Intern("arbace.cpp.sema$void_ptr_QMARK_")

var Lit_1554 *jrt.String = jrt.Intern("arbace.cpp.sema$fn_ids")

var Lit_1555 *jrt.String = jrt.Intern("arbace.cpp.sema$alloc_lookup")

var Lit_1556 *jrt.String = jrt.Intern("arbace.cpp.sema$usual_dealloc_info")

var Lit_1557 *jrt.String = jrt.Intern("arbace.cpp.sema$resolve_dealloc")

var Lit_1558 *jrt.String = jrt.Intern("arbace.cpp.sema$implicit_dealloc")

var Lit_1559 *jrt.String = jrt.Intern("arbace.cpp.sema$global_dealloc")

var Lit_1560 *jrt.String = jrt.Intern("arbace.cpp.sema$dtor_dealloc")

var Lit_1561 *jrt.String = jrt.Intern("arbace.cpp.sema$array_delete_wants_size_QMARK_")

var Lit_1562 *jrt.String = jrt.Intern("arbace.cpp.sema$find_allocation")

var Lit_1563 *jrt.String = jrt.Intern("arbace.cpp.sema$delete_dealloc")

var Lit_1564 *jrt.String = jrt.Intern("arbace.cpp.sema$new_expr")

var Lit_1565 *jrt.String = jrt.Intern("arbace.cpp.sema$dtor_of")

var Lit_1566 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_args")

var Lit_1567 *jrt.String = jrt.Intern("arbace.cpp.sema$split_top")

var Lit_1568 *jrt.String = jrt.Intern("arbace.cpp.sema$capture_intro")

var Lit_1569 *jrt.String = jrt.Intern("arbace.cpp.sema$capture_field")

var Lit_1570 *jrt.String = jrt.Intern("arbace.cpp.sema$init_capture_BANG_")

var Lit_1571 *jrt.String = jrt.Intern("arbace.cpp.sema$lambda_expr")

var Lit_1572 *jrt.String = jrt.Intern("arbace.cpp.sema$node_children")

var Lit_1573 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_names")

var Lit_1574 *jrt.String = jrt.Intern("arbace.cpp.sema$glam_declared")

var Lit_1575 *jrt.String = jrt.Intern("arbace.cpp.sema$generic_lambda_expr")

var Lit_1576 *jrt.String = jrt.Intern("arbace.cpp.sema$cond_node")

var Lit_1577 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_expr")

var Lit_1578 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze")

var Lit_1579 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_node")

var Lit_1580 *jrt.String = jrt.Intern("arbace.cpp.sema$p2266_xvalue")

var Lit_1581 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_init")

var Lit_1582 *jrt.String = jrt.Intern("arbace.cpp.sema$ctad_var")

var Lit_1583 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn3,ctxyn1,nyn7,storagekn4,linekn6,columnkn4,fileyn1,tyn1,ekn3,docyn2,idyn1,dyn3,srckn8,declaredyn1,cyn7,range-eyn5,loopdyn4,bodyyn5,scopeyn2,cnyn1,fyn6,body-syn3,clsyn3,fidyn1,vyn1,iyn3,vidyn1,xyn5,nodesyn5,prootkn3,tagyn6,Stringv15,arbace.cpp.sema10,local-var!m10,R0,TR1,L1,V3,R2,R3,R4,R5,i5618,R6,i1,R7,s18,arbace/cpp/sema.aem10,R0,TR1,L1,V1,R8,R5,i5641,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V2,R8,R9,R10,s222,The type `t` with its auto deduced from the initializer `e` ([dcl.type.auto.deduct]: a plain auto drops references,\n  top-level cv-qualifiers and decays; auto& keeps the initializer's cv; auto&& is a forwarding reference).R5,i5643,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,decl-initm12,R0,TR1,L1,V3,R2,R11,R3,R10,s74,A local declaration's initializer from its node (`:init` c, call or list).R5,i5654,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema14,decomposition!m12,R0,TR1,L1,V3,R2,R12,R13,R10,s993,A structured binding declaration ([dcl.struct.bind]): the DecompositionDecl `d`, its initializer the typed `src`\n  (a range-for's *__begin) or its own. The unnamed variable e of the declared (auto) type, deduced from the\n  initializer (an array's copy element by element when the declaration has no ref-qualifier, /1); then its bindings:\n  of an array e's elements (/2); of a tuple-like type (std::tuple_size<E>::value a constant, /4) variables of type\n  Ti& or Ti&& (as the initializer is an lvalue) initialized by get<i>(e) (argument-dependent lookup; e an lvalue when\n  its type is an lvalue reference, else an xvalue; a member get<i>() when E has a member template get), Ti the call's\n  result type; else of e's non-static data members in declaration order, all of one class (/5). The bindings of /2\n  and /5 are names of e's subobjects (no variable: clang's BindingDecl's holding expression), entered as :binding.\n  The statements: e's declaration and the tuple-like bindings' variables'.R5,i5693,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema20,check-static-assert!m8,R14,TR5,i5773,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,cx-decomposition!m12,R0,TR1,L1,V2,R2,R12,R10,s577,The rest of CP313 (a), the checker: [dcl.struct.bind]/4 for a structured binding declaration `d` whose initializer is\n  of a class type E that is not tuple-like (no std::tuple_size in the unit; clang's checkMemberDecomposition with\n  findDecomposableBaseClass): E's non-static data members all direct members of E or of one base class of E (else\n  \"both it and its base class\" or \"its base classes\" have them), no anonymous union or struct member among them,\n  each accessible as a member of E in the context, and as many as the names; an array's elements as many as the names.R5,i5775,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema9,decl-stmtm10,R0,TR1,L1,V2,R2,R3,R5,i5821,R6,i1,R7,s18,arbace/cpp/sema.aem10,R0,TR1,L1,V1,R2,R5,i5865,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema4,fullm10,R0,TR1,L1,V1,R9,R5,i5867,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema7,cond-ofm10,R0,TR1,L1,V2,R2,R3,R5,i5869,R6,i1,R7,s18,arbace/cpp/sema.aem8,R14,TR5,i5872,R6,i1,R7,s18,arbace/cpp/sema.aem8,R14,TR5,i5872,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,range-for-classm12,R0,TR1,L1,V4,R15,R16,R17,R18,R10,s287,A range-based for over a class ([stmt.ranged]/1: auto&& __range = e; auto __begin = __range.begin(), __end =\n  __range.end(); for (; __begin != __end; ++__begin) { T x = *__begin; body }), the members begin and end (G4: the\n  headers' containers), their operators by overload resolution.R5,i5874,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,constexpr-if-valuem12,R0,TR1,L1,V2,R19,R20,R10,s372,An if constexpr's condition's value ([stmt.if]/2: a contextually converted constant expression of type bool): an\n  integral constant (const-int), or an object of class type converted to bool as a condition is (to-bool: its conversion\n  function, explicit ones too, [conv]/4) and evaluated (`if constexpr (__is_invocable<...>{})`, std::map's\n  _Rb_tree::_S_key; CP332 (a)).R5,i5909,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V2,R2,R3,R10,s35,The typed statement of a tree node.R5,i5931,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema10,ctor-initsm12,R0,TR1,L1,V2,R2,R21,R10,s111,A constructor's mem-initializers as [{:base bid :init} ...] and [{:field i :init} ...] in initialization order.R5,i6151,R6,i1,R7,s18,arbace/cpp/sema.aem12,R0,TR1,L1,V1,R22,R10,s153,The local every return statement of the body returns, when there is one ([class.copy.elision]/1.1, as clang's\n  computeNRVO decides it for one variable).R5,i6209,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema27,consteval-ctor-body-stores?m12,R0,TR1,L1,V2,R23,R18,R10,s635,cpp-s5b (pending review 1111 #1, CP362 (a)'s scope): whether the body (its node) of class `cls`'s consteval constructor\n  may store to the object it constructs beyond its mem-initializers: an assignment, a compound assignment or ++/-- whose\n  operand is a member of *this (a member named alone, this->m, a member of one, an element of one, *this), a call of a\n  member function of the class named alone or through this, a call on a member, or `this`/`*this` passed. The scan is\n  syntactic and conservative (a member passed by reference is not counted: basic_format_string's\n  `_Checking_scanner<...> __scanner(_M_str)` only reads it).R5,i6222,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V1,R24,R10,s78,Analyzes a function's body (and a constructor's mem-initializers) into :tbody.R5,i6257,R6,i1,R7,s18,arbace/cpp/sema.aem12,R0,TR1,L1,V1,R24,R10,s263,A defaulted == or <=> ([class.compare.default], [class.eq], [class.spaceship]): the bases' and members' comparisons\n  in order -- == their conjunction, <=> the first that is not equal (the common comparison category's, deduced for an\n  auto return type) or equal.R5,i6316,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V1,R24,R10,s123,An implicit (or defaulted) special member's definition: params and, for a default constructor, the members'\n  initializers.R5,i6362,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema17,immediate-addressm12,R0,TR1,L1,V1,R9,R10,s167,CP310 (b): the immediate function whose address the typed expression `e` is (a pointer to it, a pointer to member\n  function of it, through no-op conversions), or nil.R5,i6420,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema18,returned-immediatem12,R0,TR1,L1,V1,R24,R10,s127,CP310 (b): an immediate function the function `fid`'s return statements return the address of, or nil (its body as\n  analyzed).R5,i6429,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V2,R25,R26,R10,s761,CX12 (the checker): a constexpr variable's scalar initializer `i` evaluated ([dcl.constexpr]/10: a constant\n  expression); an evaluation the program's own operation makes not constant (ub!) diagnosed at that operation, clang's\n  err_constexpr_var_requires_const_init. An evaluation the slice cannot do judges nothing.\n  CP310 (b), [expr.const]/16-18: the result of a manifestly constant-evaluated initializer is no pointer to an immediate\n  function (a permitted result's constituent values do not refer to one): the initializer the address itself (g++'s\n  \"constant evaluation returns address of immediate function\") or an immediate invocation that returns one (\"immediate\n  evaluation returns ...\", its callee's return statement the address), at the variable.R5,i6437,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema20,sassert-unsure-node?m12,R0,TR1,L1,V1,R3,R10,s192,Whether a static_assert's condition holds a node whose value the slice approximates: a type trait, sizeof or alignof\n  (the layouts of the slice's types), a call through the trait hook's text.R5,i6462,R6,i1,R7,s18,arbace/cpp/sema.aem10,R1,L1,V2,R2,R3,R10,s378,CX12 (the checker): a static_assert-declaration ([dcl.pre]/10): its condition analyzed (a refusal of the analysis\n  is reported as its own error) and, when it evaluates with no doubt to false, \"static assertion failed\" at the\n  declaration (clang's err_static_assert_failed). A condition with a type trait, sizeof or alignof, or a constraint\n  the slice doubted, judges nothing.R5,i6469,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema22,cx-static-member-init?m12,R0,TR1,L1,V1,R25,R10,s258,CP321 (a): whether the checker analyzes the static data member `v`'s in-class initializer: a member of a class of the\n  main file that is no closure, no local class, and no class template's specialization but one an explicit instantiation\n  definition names.R5,i6486,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema11,global-initm10,R1,L1,V1,R27,R10,s41,A namespace-scope variable's initializer.R5,i6497,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema16,prelude-typeinfom6,R5,i6517,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,strip-positionsm10,R0,TR1,L1,V1,R28,R5,i6536,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema13,prelude-nodesm10,R0,TR1,L1,V0,R5,i6541,R6,i1,R7,s18,arbace/cpp/sema.aev15,arbace.cpp.sema15,analyze-programm10,R1,L1,V3,R29,R30,Myn3,srcm2,R31,R32,R10,s171,The program of the native parse's nodes (its global scope `proot`) of the source text `src`: {:fns {id fn} :vars\n  {id var} :order [...] :classes {id class} :enums {...}}.R5,i6548,R6,i1,R7,s18,arbace/cpp/sema.ae")

var Lit_1584 *jrt.String = jrt.Intern("arbace.cpp.sema$local_var_BANG_")

var Lit_1585 *jrt.String = jrt.Intern("arbace.cpp.sema$has_auto_QMARK_")

var Lit_1586 *jrt.String = jrt.Intern("arbace.cpp.sema$deduce_auto")

var Lit_1587 *jrt.String = jrt.Intern("arbace.cpp.sema$decl_init")

var Lit_1588 *jrt.String = jrt.Intern("arbace.cpp.sema$decomposition_BANG_")

var Lit_1589 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_decomposition_BANG_")

var Lit_1590 *jrt.String = jrt.Intern("arbace.cpp.sema$decl_stmt")

var Lit_1591 *jrt.String = jrt.Intern("arbace.cpp.sema$block_ctx")

var Lit_1592 *jrt.String = jrt.Intern("arbace.cpp.sema$full")

var Lit_1593 *jrt.String = jrt.Intern("arbace.cpp.sema$cond_of")

var Lit_1594 *jrt.String = jrt.Intern("arbace.cpp.sema$range_for_class")

var Lit_1595 *jrt.String = jrt.Intern("arbace.cpp.sema$constexpr_if_value")

var Lit_1596 *jrt.String = jrt.Intern("arbace.cpp.sema$stmt")

var Lit_1597 *jrt.String = jrt.Intern("arbace.cpp.sema$ctor_inits")

var Lit_1598 *jrt.String = jrt.Intern("arbace.cpp.sema$nrvo_var")

var Lit_1599 *jrt.String = jrt.Intern("arbace.cpp.sema$consteval_ctor_body_stores_QMARK_")

var Lit_1600 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_fn_BANG_")

var Lit_1601 *jrt.String = jrt.Intern("arbace.cpp.sema$defaulted_comparison_BANG_")

var Lit_1602 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_implicit_BANG_")

var Lit_1603 *jrt.String = jrt.Intern("arbace.cpp.sema$immediate_address")

var Lit_1604 *jrt.String = jrt.Intern("arbace.cpp.sema$returned_immediate")

var Lit_1605 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_check_constant_BANG_")

var Lit_1606 *jrt.String = jrt.Intern("arbace.cpp.sema$sassert_unsure_node_QMARK_")

var Lit_1607 *jrt.String = jrt.Intern("arbace.cpp.sema$check_static_assert_BANG_")

var Lit_1608 *jrt.String = jrt.Intern("arbace.cpp.sema$cx_static_member_init_QMARK_")

var Lit_1609 *jrt.String = jrt.Intern("arbace.cpp.sema$global_init")

var Lit_1610 *jrt.String = jrt.Intern("namespace std {\nclass type_info {\npublic:\n  virtual ~type_info();\n  const char* name() const noexcept { return __name[0] == '*' ? __name + 1 : __name; }\n  bool before(const type_info& __arg) const noexcept { return __builtin_strcmp(name(), __arg.name()) < 0; }\n  bool operator==(const type_info& __arg) const noexcept {\n    return __name == __arg.__name || (__name[0] != '*' && __builtin_strcmp(__name, __arg.__name) == 0);\n  }\nprotected:\n  const char* __name;\n};\n}\n")

var Lit_1611 *jrt.String = jrt.Intern("arbace.cpp.sema$strip_positions")

var Lit_1612 *jrt.String = jrt.Intern("arbace.cpp.sema$prelude_nodes")

var Lit_1613 *jrt.String = jrt.Intern("arbace.cpp.sema$analyze_program")
