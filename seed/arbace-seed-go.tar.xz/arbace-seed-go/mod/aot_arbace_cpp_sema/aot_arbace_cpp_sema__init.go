//line aot_arbace_cpp_sema__init.ae:1
package aot_arbace_cpp_sema

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_cpp_sema__init_part0_A_Unit0__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_cpp_sema__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_sema__init_part0_A_const_1) }
//line :1:1
func A_arbace_cpp_sema__init_part0_A_Unit1__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_cpp_sema__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_2)) }
//line :1:1
func A_arbace_cpp_sema__init_part0_A_Unit2__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_sema_eval916000004_loading__1927001464__auto____916000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_sema_eval916000004_loading__1927001464__auto____916000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1312, false, nil); A_arbace_cpp_sema_eval916000004_loading__1927001464__auto____916000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_cpp_sema__init_part0_A_Unit3__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_cpp_sema__init_part0_A_const_1)).Equals_O__Z(A_arbace_cpp_sema__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_sema_eval916000008_fn__916000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_sema_eval916000008_fn__916000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1313, false, nil); A_arbace_cpp_sema_eval916000008_fn__916000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_cpp_sema__init_part0_A_Init__O() any { A_arbace_cpp_sema__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_cpp_sema__init_part0_A_Load__O() any { A_arbace_cpp_sema__init_part0_A_Init(); A_arbace_cpp_sema__init_part0_A_Unit0__O(); A_arbace_cpp_sema__init_part0_A_Unit1__O(); A_arbace_cpp_sema__init_part0_A_Unit2__O(); A_arbace_cpp_sema__init_part0_A_Unit3__O(); A_arbace_cpp_sema__init_part0_A_Unit4__O(); A_arbace_cpp_sema__init_part0_A_Unit5__O(); A_arbace_cpp_sema__init_part0_A_Unit6__O(); A_arbace_cpp_sema__init_part0_A_Unit7__O(); A_arbace_cpp_sema__init_part0_A_Unit8__O(); A_arbace_cpp_sema__init_part0_A_Unit9__O(); A_arbace_cpp_sema__init_part0_A_Unit10__O(); A_arbace_cpp_sema__init_part0_A_Unit11__O(); A_arbace_cpp_sema__init_part0_A_Unit12__O(); A_arbace_cpp_sema__init_part0_A_Unit13__O(); A_arbace_cpp_sema__init_part0_A_Unit14__O(); A_arbace_cpp_sema__init_part0_A_Unit15__O(); A_arbace_cpp_sema__init_part0_A_Unit16__O(); A_arbace_cpp_sema__init_part0_A_Unit17__O(); A_arbace_cpp_sema__init_part0_A_Unit18__O(); A_arbace_cpp_sema__init_part0_A_Unit19__O(); A_arbace_cpp_sema__init_part0_A_Unit20__O(); A_arbace_cpp_sema__init_part0_A_Unit21__O(); A_arbace_cpp_sema__init_part0_A_Unit22__O(); A_arbace_cpp_sema__init_part0_A_Unit23__O(); A_arbace_cpp_sema__init_part0_A_Unit24__O(); A_arbace_cpp_sema__init_part0_A_Unit25__O(); A_arbace_cpp_sema__init_part0_A_Unit26__O(); A_arbace_cpp_sema__init_part0_A_Unit27__O(); A_arbace_cpp_sema__init_part0_A_Unit28__O(); A_arbace_cpp_sema__init_part0_A_Unit29__O(); A_arbace_cpp_sema__init_part0_A_Unit30__O(); A_arbace_cpp_sema__init_part0_A_Unit31__O(); A_arbace_cpp_sema__init_part0_A_Unit32__O(); A_arbace_cpp_sema__init_part0_A_Unit33__O(); A_arbace_cpp_sema__init_part0_A_Unit34__O(); A_arbace_cpp_sema__init_part0_A_Unit35__O(); A_arbace_cpp_sema__init_part0_A_Unit36__O(); A_arbace_cpp_sema__init_part0_A_Unit37__O(); A_arbace_cpp_sema__init_part0_A_Unit38__O(); A_arbace_cpp_sema__init_part0_A_Unit39__O(); A_arbace_cpp_sema__init_part0_A_Unit40__O(); A_arbace_cpp_sema__init_part0_A_Unit41__O(); A_arbace_cpp_sema__init_part0_A_Unit42__O(); A_arbace_cpp_sema__init_part0_A_Unit43__O(); A_arbace_cpp_sema__init_part0_A_Unit44__O(); A_arbace_cpp_sema__init_part0_A_Unit45__O(); A_arbace_cpp_sema__init_part0_A_Unit46__O(); A_arbace_cpp_sema__init_part0_A_Unit47__O(); A_arbace_cpp_sema__init_part0_A_Unit48__O(); A_arbace_cpp_sema__init_part0_A_Unit49__O(); A_arbace_cpp_sema__init_part0_A_Unit50__O(); A_arbace_cpp_sema__init_part0_A_Unit51__O(); A_arbace_cpp_sema__init_part0_A_Unit52__O(); A_arbace_cpp_sema__init_part0_A_Unit53__O(); A_arbace_cpp_sema__init_part0_A_Unit54__O(); A_arbace_cpp_sema__init_part0_A_Unit55__O(); A_arbace_cpp_sema__init_part0_A_Unit56__O(); A_arbace_cpp_sema__init_part0_A_Unit57__O(); A_arbace_cpp_sema__init_part0_A_Unit58__O(); A_arbace_cpp_sema__init_part0_A_Unit59__O(); A_arbace_cpp_sema__init_part0_A_Unit60__O(); A_arbace_cpp_sema__init_part0_A_Unit61__O(); A_arbace_cpp_sema__init_part0_A_Unit62__O(); A_arbace_cpp_sema__init_part0_A_Unit63__O(); A_arbace_cpp_sema__init_part0_A_Unit64__O(); A_arbace_cpp_sema__init_part0_A_Unit65__O(); A_arbace_cpp_sema__init_part0_A_Unit66__O(); A_arbace_cpp_sema__init_part0_A_Unit67__O(); A_arbace_cpp_sema__init_part0_A_Unit68__O(); A_arbace_cpp_sema__init_part0_A_Unit69__O(); A_arbace_cpp_sema__init_part0_A_Unit70__O(); A_arbace_cpp_sema__init_part0_A_Unit71__O(); A_arbace_cpp_sema__init_part0_A_Unit72__O(); A_arbace_cpp_sema__init_part0_A_Unit73__O(); A_arbace_cpp_sema__init_part0_A_Unit74__O(); A_arbace_cpp_sema__init_part0_A_Unit75__O(); A_arbace_cpp_sema__init_part0_A_Unit76__O(); A_arbace_cpp_sema__init_part0_A_Unit77__O(); A_arbace_cpp_sema__init_part0_A_Unit78__O(); A_arbace_cpp_sema__init_part0_A_Unit79__O(); A_arbace_cpp_sema__init_part0_A_Unit80__O(); A_arbace_cpp_sema__init_part0_A_Unit81__O(); A_arbace_cpp_sema__init_part0_A_Unit82__O(); A_arbace_cpp_sema__init_part0_A_Unit83__O(); A_arbace_cpp_sema__init_part0_A_Unit84__O(); A_arbace_cpp_sema__init_part0_A_Unit85__O(); A_arbace_cpp_sema__init_part0_A_Unit86__O(); A_arbace_cpp_sema__init_part0_A_Unit87__O(); A_arbace_cpp_sema__init_part0_A_Unit88__O(); A_arbace_cpp_sema__init_part0_A_Unit89__O(); A_arbace_cpp_sema__init_part0_A_Unit90__O(); A_arbace_cpp_sema__init_part0_A_Unit91__O(); A_arbace_cpp_sema__init_part0_A_Unit92__O(); A_arbace_cpp_sema__init_part0_A_Unit93__O(); A_arbace_cpp_sema__init_part0_A_Unit94__O(); A_arbace_cpp_sema__init_part0_A_Unit95__O(); A_arbace_cpp_sema__init_part0_A_Unit96__O(); A_arbace_cpp_sema__init_part0_A_Unit97__O(); A_arbace_cpp_sema__init_part0_A_Unit98__O(); A_arbace_cpp_sema__init_part0_A_Unit99__O(); return nil }



func A_arbace_cpp_sema__init_A_Load__O() any { jrt.StartCheck(); A_arbace_cpp_sema__init_part0_A_Init__O(); A_arbace_cpp_sema__init_part1_A_Init__O(); A_arbace_cpp_sema__init_part2_A_Init__O(); A_arbace_cpp_sema__init_part3_A_Init__O(); A_arbace_cpp_sema__init_part4_A_Init__O(); A_arbace_cpp_sema__init_part0_A_Load__O(); A_arbace_cpp_sema__init_part1_A_Load__O(); A_arbace_cpp_sema__init_part2_A_Load__O(); A_arbace_cpp_sema__init_part3_A_Load__O(); A_arbace_cpp_sema__init_part4_A_Load__O(); return nil }













func A_arbace_cpp_sema__init_part0_A_Unit4__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); return A_arbace_cpp_sema__init_part0_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_cpp_sema__init_part0_A_Unit5__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_5; tmp1.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_6.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_5; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_7)); return A_arbace_cpp_sema__init_part0_A_const_5 }






func A_arbace_cpp_sema__init_part0_A_Unit6__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_8; var tmp2 any; var root_5 any = A_arbace_cpp_sema__init_part0_A_const_9.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_5, arg_8) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_8; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_10)); return A_arbace_cpp_sema__init_part0_A_const_8 }




func A_arbace_cpp_sema__init_part0_A_Unit7__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); A_arbace_cpp_sema__init_part0_A_const_11.BindRoot_O__V(Lit_11); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_12)); return A_arbace_cpp_sema__init_part0_A_const_11.SetDynamic_Z__Var(true).Ref() }


func A_arbace_cpp_sema__init_part0_A_Unit8__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); A_arbace_cpp_sema__init_part0_A_const_13.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_13; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_14)); return A_arbace_cpp_sema__init_part0_A_const_13.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit9__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); A_arbace_cpp_sema__init_part0_A_const_15.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_15; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_16)); return A_arbace_cpp_sema__init_part0_A_const_15.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit10__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_cpp_sema__init_part0_A_const_17.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_18)); return A_arbace_cpp_sema__init_part0_A_const_17.SetDynamic_Z__Var(true).Ref() }


func A_arbace_cpp_sema__init_part0_A_Unit11__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_sema_checking_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_sema_checking_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1314, false, nil); A_arbace_cpp_sema_checking_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_20)); return A_arbace_cpp_sema__init_part0_A_const_19 }



func A_arbace_cpp_sema__init_part0_A_Unit12__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); A_arbace_cpp_sema__init_part0_A_const_21.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_22); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_23)); return A_arbace_cpp_sema__init_part0_A_const_21.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit13__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_sema_tick_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_sema_tick_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1315, false, nil); A_arbace_cpp_sema_tick_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_25)); return A_arbace_cpp_sema__init_part0_A_const_24 }




func A_arbace_cpp_sema__init_part0_A_Unit14__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); A_arbace_cpp_sema__init_part0_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_27)); return A_arbace_cpp_sema__init_part0_A_const_26.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part0_A_Unit15__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); A_arbace_cpp_sema__init_part0_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_29)); return A_arbace_cpp_sema__init_part0_A_const_28.SetDynamic_Z__Var(true).Ref() }


func A_arbace_cpp_sema__init_part0_A_Unit16__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_cpp_sema__init_part0_A_const_30.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_31); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_32)); return A_arbace_cpp_sema__init_part0_A_const_30.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part0_A_Unit17__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_sema_cxx_year_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_sema_cxx_year_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1316, false, nil); A_arbace_cpp_sema_cxx_year_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_34)); return A_arbace_cpp_sema__init_part0_A_const_33 }





func A_arbace_cpp_sema__init_part0_A_Unit18__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); A_arbace_cpp_sema__init_part0_A_const_35.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_35; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_36)); return A_arbace_cpp_sema__init_part0_A_const_35.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit19__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); A_arbace_cpp_sema__init_part0_A_const_37.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_37; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_38)); return A_arbace_cpp_sema__init_part0_A_const_37.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit20__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); A_arbace_cpp_sema__init_part0_A_const_39.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_39; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_40)); return A_arbace_cpp_sema__init_part0_A_const_39.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit21__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); A_arbace_cpp_sema__init_part0_A_const_41.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_42)); return A_arbace_cpp_sema__init_part0_A_const_41.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part0_A_Unit22__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_sema_next_id_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_sema_next_id_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1317, false, nil); A_arbace_cpp_sema_next_id_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_44)); return A_arbace_cpp_sema__init_part0_A_const_43 }
func A_arbace_cpp_sema__init_part0_A_Unit23__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_sema_fnd_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_sema_fnd_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1318, false, nil); A_arbace_cpp_sema_fnd_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_46)); return A_arbace_cpp_sema__init_part0_A_const_45 }
func A_arbace_cpp_sema__init_part0_A_Unit24__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_sema_var_STAR__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_sema_var_STAR__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1319, false, nil); A_arbace_cpp_sema_var_STAR__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_48)); return A_arbace_cpp_sema__init_part0_A_const_47 }
func A_arbace_cpp_sema__init_part0_A_Unit25__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_49; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__22 any = A_arbace_cpp_sema_upd_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_sema_upd_fn_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1320, true, nil); A_arbace_cpp_sema_upd_fn_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__22, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_50)); return A_arbace_cpp_sema__init_part0_A_const_49 }
func A_arbace_cpp_sema__init_part0_A_Unit26__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_51; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__24 any = A_arbace_cpp_sema_upd_var_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_sema_upd_var_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1321, true, nil); A_arbace_cpp_sema_upd_var_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__24, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_52)); return A_arbace_cpp_sema__init_part0_A_const_51 }



func A_arbace_cpp_sema__init_part0_A_Unit27__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_53; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__26 any = A_arbace_cpp_sema_new_scope_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_sema_new_scope_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1322, true, nil); A_arbace_cpp_sema_new_scope_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__26, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_54)); return A_arbace_cpp_sema__init_part0_A_const_53 }




func A_arbace_cpp_sema__init_part0_A_Unit28__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_sema_ucn_name_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_sema_ucn_name_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1323, false, nil); A_arbace_cpp_sema_ucn_name_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_56)); return A_arbace_cpp_sema__init_part0_A_const_55 }









func A_arbace_cpp_sema__init_part0_A_Unit29__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_sema_enter_BANG__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_sema_enter_BANG__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1324, false, nil); A_arbace_cpp_sema_enter_BANG__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_58)); return A_arbace_cpp_sema__init_part0_A_const_57 }





func A_arbace_cpp_sema__init_part0_A_Unit30__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(98, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_59; tmp1.BindRoot_O__V(jrt.Long_ValueOf_J__Long_NoInit(9223372036854775807).Ref()); var tmp2 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_59; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_60)); return A_arbace_cpp_sema__init_part0_A_const_59.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit31__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_61; tmp1.BindRoot_O__V(jrt.AtomicLong_New()); var tmp2 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_61; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_62)); return A_arbace_cpp_sema__init_part0_A_const_61 }




func A_arbace_cpp_sema__init_part0_A_Unit32__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); A_arbace_cpp_sema__init_part0_A_const_63.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_63; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_64)); return A_arbace_cpp_sema__init_part0_A_const_63.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part0_A_Unit33__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_65; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_66)); return A_arbace_cpp_sema__init_part0_A_const_65 }

func A_arbace_cpp_sema__init_part0_A_Unit34__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(108, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_sema_own_names_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_sema_own_names_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1325, false, nil); A_arbace_cpp_sema_own_names_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_68)); return A_arbace_cpp_sema__init_part0_A_const_67 }











func A_arbace_cpp_sema__init_part0_A_Unit35__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_sema_find_here_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_sema_find_here_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1326, false, nil); A_arbace_cpp_sema_find_here_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_70)); return A_arbace_cpp_sema__init_part0_A_const_69 }







func A_arbace_cpp_sema__init_part0_A_Unit36__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_72)); return A_arbace_cpp_sema__init_part0_A_const_71 }

func A_arbace_cpp_sema__init_part0_A_Unit37__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_74)); return A_arbace_cpp_sema__init_part0_A_const_73 }

func A_arbace_cpp_sema__init_part0_A_Unit38__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_sema_lookup_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_sema_lookup_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1327, false, nil); A_arbace_cpp_sema_lookup_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_76)); return A_arbace_cpp_sema__init_part0_A_const_75 }














func A_arbace_cpp_sema__init_part0_A_Unit39__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_sema_class_lookup_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_sema_class_lookup_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1328, false, nil); A_arbace_cpp_sema_class_lookup_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_77)); return A_arbace_cpp_sema__init_part0_A_const_65 }

















func A_arbace_cpp_sema__init_part0_A_Unit40__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_79)); return A_arbace_cpp_sema__init_part0_A_const_78 }
//line :165:1
func A_arbace_cpp_sema__init_part0_A_Unit41__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_81)); return A_arbace_cpp_sema__init_part0_A_const_80 }
//line :165:1
func A_arbace_cpp_sema__init_part0_A_Unit42__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_83)); return A_arbace_cpp_sema__init_part0_A_const_82 }
//line :165:1
func A_arbace_cpp_sema__init_part0_A_Unit43__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_85)); return A_arbace_cpp_sema__init_part0_A_const_84 }





func A_arbace_cpp_sema__init_part0_A_Unit44__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); A_arbace_cpp_sema__init_part0_A_const_86.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_87)); return A_arbace_cpp_sema__init_part0_A_const_86.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit45__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); A_arbace_cpp_sema__init_part0_A_const_88.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_89)); return A_arbace_cpp_sema__init_part0_A_const_88.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit46__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); A_arbace_cpp_sema__init_part0_A_const_90.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_91)); return A_arbace_cpp_sema__init_part0_A_const_90.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part0_A_Unit47__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_sema_opaque_class_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_sema_opaque_class_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1329, false, nil); A_arbace_cpp_sema_opaque_class_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_93)); return A_arbace_cpp_sema__init_part0_A_const_92 }








func A_arbace_cpp_sema__init_part0_A_Unit48__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_94; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_95)); return A_arbace_cpp_sema__init_part0_A_const_94 }

func A_arbace_cpp_sema__init_part0_A_Unit49__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(186, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_sema_va_list_tag_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_sema_va_list_tag_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1330, false, nil); A_arbace_cpp_sema_va_list_tag_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_97)); return A_arbace_cpp_sema__init_part0_A_const_96 }














func A_arbace_cpp_sema__init_part0_A_Unit50__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_sema_ptype__GT_type_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_sema_ptype__GT_type_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1331, false, nil); A_arbace_cpp_sema_ptype__GT_type_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_99)); return A_arbace_cpp_sema__init_part0_A_const_98 }














func A_arbace_cpp_sema__init_part0_A_Unit51__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); A_arbace_cpp_sema__init_part0_A_const_100.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_101); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_102)); return A_arbace_cpp_sema__init_part0_A_const_100 }






func A_arbace_cpp_sema__init_part0_A_Unit52__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_sema_header_entities_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_sema_header_entities_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1332, false, nil); A_arbace_cpp_sema_header_entities_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_103)); return A_arbace_cpp_sema__init_part0_A_const_71 }







































func A_arbace_cpp_sema__init_part0_A_Unit53__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); A_arbace_cpp_sema__init_part0_A_const_104.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_105); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_106)); return A_arbace_cpp_sema__init_part0_A_const_104 }







































func A_arbace_cpp_sema__init_part0_A_Unit54__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_sema_builtin_entities_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_sema_builtin_entities_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1333, false, nil); A_arbace_cpp_sema_builtin_entities_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_107)); return A_arbace_cpp_sema__init_part0_A_const_73 }










func A_arbace_cpp_sema__init_part0_A_Unit55__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); A_arbace_cpp_sema__init_part0_A_const_108.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_109); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_110)); return A_arbace_cpp_sema__init_part0_A_const_108 }









func A_arbace_cpp_sema__init_part0_A_Unit56__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(324, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_sema_name_parts_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_sema_name_parts_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1334, false, nil); A_arbace_cpp_sema_name_parts_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_112)); return A_arbace_cpp_sema__init_part0_A_const_111 }

func A_arbace_cpp_sema__init_part0_A_Unit57__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_sema_type_entity_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_sema_type_entity_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1335, false, nil); A_arbace_cpp_sema_type_entity_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_114)); return A_arbace_cpp_sema__init_part0_A_const_113 }

func A_arbace_cpp_sema__init_part0_A_Unit58__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); A_arbace_cpp_sema__init_part0_A_const_115.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_115; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_116)); return A_arbace_cpp_sema__init_part0_A_const_115.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part0_A_Unit59__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_117; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_118)); return A_arbace_cpp_sema__init_part0_A_const_117 }




func A_arbace_cpp_sema__init_part0_A_Unit60__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); A_arbace_cpp_sema__init_part0_A_const_119.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_119; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_120)); return A_arbace_cpp_sema__init_part0_A_const_119.SetDynamic_Z__Var(true).Ref() }







func A_arbace_cpp_sema__init_part0_A_Unit61__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(343, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_sema_dt_dependent_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_sema_dt_dependent_QMARK__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1336, false, nil); A_arbace_cpp_sema_dt_dependent_QMARK__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_122)); return A_arbace_cpp_sema__init_part0_A_const_121 }






func A_arbace_cpp_sema__init_part0_A_Unit62__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_sema_dt_strip_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_sema_dt_strip_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1337, false, nil); A_arbace_cpp_sema_dt_strip_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_124)); return A_arbace_cpp_sema__init_part0_A_const_123 }





func A_arbace_cpp_sema__init_part0_A_Unit63__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_sema_dt_type_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_sema_dt_type_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1338, false, nil); A_arbace_cpp_sema_dt_type_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_126)); return A_arbace_cpp_sema__init_part0_A_const_125 }



func A_arbace_cpp_sema__init_part0_A_Unit64__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(360, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_sema_dt_targ_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_sema_dt_targ_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1339, false, nil); A_arbace_cpp_sema_dt_targ_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_128)); return A_arbace_cpp_sema__init_part0_A_const_127 }









func A_arbace_cpp_sema__init_part0_A_Unit65__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); A_arbace_cpp_sema__init_part0_A_const_129.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_130); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_129; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_131)); return A_arbace_cpp_sema__init_part0_A_const_129 }
func A_arbace_cpp_sema__init_part0_A_Unit66__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(371, 1); A_arbace_cpp_sema__init_part0_A_const_132.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_133); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_132; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_134)); return A_arbace_cpp_sema__init_part0_A_const_132 }



func A_arbace_cpp_sema__init_part0_A_Unit67__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); A_arbace_cpp_sema__init_part0_A_const_135.BindRoot_O__V(A_arbace_cpp_sema__init_part0_A_const_136); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_135; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_137)); return A_arbace_cpp_sema__init_part0_A_const_135 }


func A_arbace_cpp_sema__init_part0_A_Unit68__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_sema_dt_written_type_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_sema_dt_written_type_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1340, false, nil); A_arbace_cpp_sema_dt_written_type_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_139)); return A_arbace_cpp_sema__init_part0_A_const_138 }




func A_arbace_cpp_sema__init_part0_A_Unit69__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(383, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_sema_dt_ir_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_sema_dt_ir_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1341, false, nil); A_arbace_cpp_sema_dt_ir_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_141)); return A_arbace_cpp_sema__init_part0_A_const_140 }










































































func A_arbace_cpp_sema__init_part0_A_Unit70__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(458, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_sema_decltype_of_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_sema_decltype_of_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1342, false, nil); A_arbace_cpp_sema_decltype_of_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_143)); return A_arbace_cpp_sema__init_part0_A_const_142 }














































func A_arbace_cpp_sema__init_part0_A_Unit71__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(505, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_sema_resolve_type_form_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_sema_resolve_type_form_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1343, false, nil); A_arbace_cpp_sema_resolve_type_form_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_144)); return A_arbace_cpp_sema__init_part0_A_const_78 }




































































































func A_arbace_cpp_sema__init_part0_A_Unit72__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(606, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_sema_strip_type_attrs_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_sema_strip_type_attrs_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1344, false, nil); A_arbace_cpp_sema_strip_type_attrs_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_146)); return A_arbace_cpp_sema__init_part0_A_const_145 }














func A_arbace_cpp_sema__init_part0_A_Unit73__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(621, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_sema_resolve_type_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_sema_resolve_type_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1345, false, nil); A_arbace_cpp_sema_resolve_type_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_147)); return A_arbace_cpp_sema__init_part0_A_const_80 }













func A_arbace_cpp_sema__init_part0_A_Unit74__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(635, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_cpp_sema_ctad_template_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_sema_ctad_template_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1346, false, nil); A_arbace_cpp_sema_ctad_template_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_149)); return A_arbace_cpp_sema__init_part0_A_const_148 }



























func A_arbace_cpp_sema__init_part0_A_Unit75__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(663, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_150; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_sema_ctad_compound_BANG__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_sema_ctad_compound_BANG__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1347, false, nil); A_arbace_cpp_sema_ctad_compound_BANG__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_151)); return A_arbace_cpp_sema__init_part0_A_const_150 }














func A_arbace_cpp_sema__init_part0_A_Unit76__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(678, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_cpp_sema_ctad_compound_var_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_cpp_sema_ctad_compound_var_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1348, false, nil); A_arbace_cpp_sema_ctad_compound_var_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_153)); return A_arbace_cpp_sema__init_part0_A_const_152 }










func A_arbace_cpp_sema__init_part0_A_Unit77__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(689, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_cpp_sema_method_const_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_cpp_sema_method_const_QMARK__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1349, false, nil); A_arbace_cpp_sema_method_const_QMARK__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_155)); return A_arbace_cpp_sema__init_part0_A_const_154 }
func A_arbace_cpp_sema__init_part0_A_Unit78__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(690, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_sema_method_volatile_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_sema_method_volatile_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1350, false, nil); A_arbace_cpp_sema_method_volatile_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_157)); return A_arbace_cpp_sema__init_part0_A_const_156 }

func A_arbace_cpp_sema__init_part0_A_Unit79__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(692, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_sema_method_refq_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_sema_method_refq_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1351, false, nil); A_arbace_cpp_sema_method_refq_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_159)); return A_arbace_cpp_sema__init_part0_A_const_158 }







func A_arbace_cpp_sema__init_part0_A_Unit80__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(700, 1); A_arbace_cpp_sema__init_part0_A_const_160.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_160; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_161)); return A_arbace_cpp_sema__init_part0_A_const_160.SetDynamic_Z__Var(true).Ref() }


func A_arbace_cpp_sema__init_part0_A_Unit81__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(703, 1); A_arbace_cpp_sema__init_part0_A_const_162.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_162; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_163)); return A_arbace_cpp_sema__init_part0_A_const_162.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part0_A_Unit82__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(704, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_164; var tmp2 any; var root_85 any = A_arbace_cpp_sema__init_part0_A_const_9.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_86 == nil { tmp2 = ifn_87.Invoke_O__O(arg_88) } else { tmp2 = linked_86.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_85, arg_88) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_164; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_165)); return A_arbace_cpp_sema__init_part0_A_const_164 }

func A_arbace_cpp_sema__init_part0_A_Unit83__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(706, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_sema_loc_of_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_sema_loc_of_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1352, false, nil); A_arbace_cpp_sema_loc_of_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_167)); return A_arbace_cpp_sema__init_part0_A_const_166 }




func A_arbace_cpp_sema__init_part0_A_Unit84__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(711, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_168; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_sema_blank_comments_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_sema_blank_comments_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1353, false, nil); A_arbace_cpp_sema_blank_comments_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_169)); return A_arbace_cpp_sema__init_part0_A_const_168 }



















func A_arbace_cpp_sema__init_part0_A_Unit85__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(731, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_sema_located_file_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_sema_located_file_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1354, false, nil); A_arbace_cpp_sema_located_file_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_171)); return A_arbace_cpp_sema__init_part0_A_const_170 }















func A_arbace_cpp_sema__init_part0_A_Unit86__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(747, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_cpp_sema_text_of_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_sema_text_of_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1355, false, nil); A_arbace_cpp_sema_text_of_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_173)); return A_arbace_cpp_sema__init_part0_A_const_172 }
















func A_arbace_cpp_sema__init_part0_A_Unit87__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(764, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_174; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_sema_header_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_sema_header_node_QMARK__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1356, false, nil); A_arbace_cpp_sema_header_node_QMARK__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_175)); return A_arbace_cpp_sema__init_part0_A_const_174 }





func A_arbace_cpp_sema__init_part0_A_Unit88__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(770, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_176; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_cpp_sema_node_text_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_sema_node_text_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1357, false, nil); A_arbace_cpp_sema_node_text_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_177)); return A_arbace_cpp_sema__init_part0_A_const_176 }







func A_arbace_cpp_sema__init_part0_A_Unit89__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(778, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_178; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_cpp_sema_text_after_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_sema_text_after_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1358, false, nil); A_arbace_cpp_sema_text_after_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_179)); return A_arbace_cpp_sema__init_part0_A_const_178 }







func A_arbace_cpp_sema__init_part0_A_Unit90__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(786, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_180; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_cpp_sema_strip_directives_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_cpp_sema_strip_directives_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1359, false, nil); A_arbace_cpp_sema_strip_directives_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_181)); return A_arbace_cpp_sema__init_part0_A_const_180 }








func A_arbace_cpp_sema__init_part0_A_Unit91__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(795, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_cpp_sema_text_before_name_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_cpp_sema_text_before_name_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1360, false, nil); A_arbace_cpp_sema_text_before_name_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_183)); return A_arbace_cpp_sema__init_part0_A_const_182 }








func A_arbace_cpp_sema__init_part0_A_Unit92__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(804, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_cpp_sema_qualifier_before_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_cpp_sema_qualifier_before_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1361, false, nil); A_arbace_cpp_sema_qualifier_before_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_185)); return A_arbace_cpp_sema__init_part0_A_const_184 }










func A_arbace_cpp_sema__init_part0_A_Unit93__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(815, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_186; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_cpp_sema_qualifier_tid_before_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_cpp_sema_qualifier_tid_before_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1362, false, nil); A_arbace_cpp_sema_qualifier_tid_before_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_187)); return A_arbace_cpp_sema__init_part0_A_const_186 }

























func A_arbace_cpp_sema__init_part0_A_Unit94__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(841, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_188; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_cpp_sema_split_scope_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_cpp_sema_split_scope_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1363, false, nil); A_arbace_cpp_sema_split_scope_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_189)); return A_arbace_cpp_sema__init_part0_A_const_188 }












func A_arbace_cpp_sema__init_part0_A_Unit95__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(854, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_190; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_cpp_sema_ref_qualifier_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_cpp_sema_ref_qualifier_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1364, false, nil); A_arbace_cpp_sema_ref_qualifier_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_190; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_191)); return A_arbace_cpp_sema__init_part0_A_const_190 }










func A_arbace_cpp_sema__init_part0_A_Unit96__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(865, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_192; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_cpp_sema_written_targs_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_cpp_sema_written_targs_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1365, false, nil); A_arbace_cpp_sema_written_targs_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_192; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_193)); return A_arbace_cpp_sema__init_part0_A_const_192 }







func A_arbace_cpp_sema__init_part0_A_Unit97__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(873, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_cpp_sema_lookup_qualified_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_cpp_sema_lookup_qualified_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1366, false, nil); A_arbace_cpp_sema_lookup_qualified_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_194)); return A_arbace_cpp_sema__init_part0_A_const_82 }


































func A_arbace_cpp_sema__init_part0_A_Unit98__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(908, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_195; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_cpp_sema_kids_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_cpp_sema_kids_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1367, false, nil); A_arbace_cpp_sema_kids_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_195; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_196)); return A_arbace_cpp_sema__init_part0_A_const_195 }

func A_arbace_cpp_sema__init_part0_A_Unit99__O() any { A_arbace_cpp_sema__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(910, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_197; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_cpp_sema_body_of_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_cpp_sema_body_of_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1368, false, nil); A_arbace_cpp_sema_body_of_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part0_A_const_197; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part0_A_const_198)); return A_arbace_cpp_sema__init_part0_A_const_197 }





func A_arbace_cpp_sema__init_part1_A_Unit100__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(916, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_sema_gnu_attr_arg_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_sema_gnu_attr_arg_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1370, false, nil); A_arbace_cpp_sema_gnu_attr_arg_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_1)); return A_arbace_cpp_sema__init_part1_A_const_0 }
//line :916:1
func A_arbace_cpp_sema__init_part1_A_Init__O() any { A_arbace_cpp_sema__init_part1_A_Init(); return nil }
//line :916:1
func A_arbace_cpp_sema__init_part1_A_Load__O() any { A_arbace_cpp_sema__init_part1_A_Init(); A_arbace_cpp_sema__init_part1_A_Unit100__O(); A_arbace_cpp_sema__init_part1_A_Unit101__O(); A_arbace_cpp_sema__init_part1_A_Unit102__O(); A_arbace_cpp_sema__init_part1_A_Unit103__O(); A_arbace_cpp_sema__init_part1_A_Unit104__O(); A_arbace_cpp_sema__init_part1_A_Unit105__O(); A_arbace_cpp_sema__init_part1_A_Unit106__O(); A_arbace_cpp_sema__init_part1_A_Unit107__O(); A_arbace_cpp_sema__init_part1_A_Unit108__O(); A_arbace_cpp_sema__init_part1_A_Unit109__O(); A_arbace_cpp_sema__init_part1_A_Unit110__O(); A_arbace_cpp_sema__init_part1_A_Unit111__O(); A_arbace_cpp_sema__init_part1_A_Unit112__O(); A_arbace_cpp_sema__init_part1_A_Unit113__O(); A_arbace_cpp_sema__init_part1_A_Unit114__O(); A_arbace_cpp_sema__init_part1_A_Unit115__O(); A_arbace_cpp_sema__init_part1_A_Unit116__O(); A_arbace_cpp_sema__init_part1_A_Unit117__O(); A_arbace_cpp_sema__init_part1_A_Unit118__O(); A_arbace_cpp_sema__init_part1_A_Unit119__O(); A_arbace_cpp_sema__init_part1_A_Unit120__O(); A_arbace_cpp_sema__init_part1_A_Unit121__O(); A_arbace_cpp_sema__init_part1_A_Unit122__O(); A_arbace_cpp_sema__init_part1_A_Unit123__O(); A_arbace_cpp_sema__init_part1_A_Unit124__O(); A_arbace_cpp_sema__init_part1_A_Unit125__O(); A_arbace_cpp_sema__init_part1_A_Unit126__O(); A_arbace_cpp_sema__init_part1_A_Unit127__O(); A_arbace_cpp_sema__init_part1_A_Unit128__O(); A_arbace_cpp_sema__init_part1_A_Unit129__O(); A_arbace_cpp_sema__init_part1_A_Unit130__O(); A_arbace_cpp_sema__init_part1_A_Unit131__O(); A_arbace_cpp_sema__init_part1_A_Unit132__O(); A_arbace_cpp_sema__init_part1_A_Unit133__O(); A_arbace_cpp_sema__init_part1_A_Unit134__O(); A_arbace_cpp_sema__init_part1_A_Unit135__O(); A_arbace_cpp_sema__init_part1_A_Unit136__O(); A_arbace_cpp_sema__init_part1_A_Unit137__O(); A_arbace_cpp_sema__init_part1_A_Unit138__O(); A_arbace_cpp_sema__init_part1_A_Unit139__O(); A_arbace_cpp_sema__init_part1_A_Unit140__O(); A_arbace_cpp_sema__init_part1_A_Unit141__O(); A_arbace_cpp_sema__init_part1_A_Unit142__O(); A_arbace_cpp_sema__init_part1_A_Unit143__O(); A_arbace_cpp_sema__init_part1_A_Unit144__O(); A_arbace_cpp_sema__init_part1_A_Unit145__O(); A_arbace_cpp_sema__init_part1_A_Unit146__O(); A_arbace_cpp_sema__init_part1_A_Unit147__O(); A_arbace_cpp_sema__init_part1_A_Unit148__O(); A_arbace_cpp_sema__init_part1_A_Unit149__O(); A_arbace_cpp_sema__init_part1_A_Unit150__O(); A_arbace_cpp_sema__init_part1_A_Unit151__O(); A_arbace_cpp_sema__init_part1_A_Unit152__O(); A_arbace_cpp_sema__init_part1_A_Unit153__O(); A_arbace_cpp_sema__init_part1_A_Unit154__O(); A_arbace_cpp_sema__init_part1_A_Unit155__O(); A_arbace_cpp_sema__init_part1_A_Unit156__O(); A_arbace_cpp_sema__init_part1_A_Unit157__O(); A_arbace_cpp_sema__init_part1_A_Unit158__O(); A_arbace_cpp_sema__init_part1_A_Unit159__O(); A_arbace_cpp_sema__init_part1_A_Unit160__O(); A_arbace_cpp_sema__init_part1_A_Unit161__O(); A_arbace_cpp_sema__init_part1_A_Unit162__O(); A_arbace_cpp_sema__init_part1_A_Unit163__O(); A_arbace_cpp_sema__init_part1_A_Unit164__O(); A_arbace_cpp_sema__init_part1_A_Unit165__O(); A_arbace_cpp_sema__init_part1_A_Unit166__O(); A_arbace_cpp_sema__init_part1_A_Unit167__O(); A_arbace_cpp_sema__init_part1_A_Unit168__O(); A_arbace_cpp_sema__init_part1_A_Unit169__O(); A_arbace_cpp_sema__init_part1_A_Unit170__O(); A_arbace_cpp_sema__init_part1_A_Unit171__O(); A_arbace_cpp_sema__init_part1_A_Unit172__O(); A_arbace_cpp_sema__init_part1_A_Unit173__O(); A_arbace_cpp_sema__init_part1_A_Unit174__O(); A_arbace_cpp_sema__init_part1_A_Unit175__O(); A_arbace_cpp_sema__init_part1_A_Unit176__O(); A_arbace_cpp_sema__init_part1_A_Unit177__O(); A_arbace_cpp_sema__init_part1_A_Unit178__O(); A_arbace_cpp_sema__init_part1_A_Unit179__O(); A_arbace_cpp_sema__init_part1_A_Unit180__O(); A_arbace_cpp_sema__init_part1_A_Unit181__O(); A_arbace_cpp_sema__init_part1_A_Unit182__O(); A_arbace_cpp_sema__init_part1_A_Unit183__O(); A_arbace_cpp_sema__init_part1_A_Unit184__O(); A_arbace_cpp_sema__init_part1_A_Unit185__O(); A_arbace_cpp_sema__init_part1_A_Unit186__O(); A_arbace_cpp_sema__init_part1_A_Unit187__O(); A_arbace_cpp_sema__init_part1_A_Unit188__O(); A_arbace_cpp_sema__init_part1_A_Unit189__O(); A_arbace_cpp_sema__init_part1_A_Unit190__O(); A_arbace_cpp_sema__init_part1_A_Unit191__O(); A_arbace_cpp_sema__init_part1_A_Unit192__O(); A_arbace_cpp_sema__init_part1_A_Unit193__O(); A_arbace_cpp_sema__init_part1_A_Unit194__O(); A_arbace_cpp_sema__init_part1_A_Unit195__O(); A_arbace_cpp_sema__init_part1_A_Unit196__O(); A_arbace_cpp_sema__init_part1_A_Unit197__O(); A_arbace_cpp_sema__init_part1_A_Unit198__O(); A_arbace_cpp_sema__init_part1_A_Unit199__O(); return nil }







func A_arbace_cpp_sema__init_part1_A_Unit101__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(924, 1); A_arbace_cpp_sema__init_part1_A_const_2.BindRoot_O__V(A_arbace_cpp_sema__init_part1_A_const_3); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_4)); return A_arbace_cpp_sema__init_part1_A_const_2 }




func A_arbace_cpp_sema__init_part1_A_Unit102__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(929, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_5; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_sema_mode_type_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_sema_mode_type_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1371, false, nil); A_arbace_cpp_sema_mode_type_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_6)); return A_arbace_cpp_sema__init_part1_A_const_5 }

















func A_arbace_cpp_sema__init_part1_A_Unit103__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(947, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_sema_init_kid_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_sema_init_kid_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1372, false, nil); A_arbace_cpp_sema_init_kid_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_8)); return A_arbace_cpp_sema__init_part1_A_const_7 }





func A_arbace_cpp_sema__init_part1_A_Unit104__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(953, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_sema_linkage_c_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_sema_linkage_c_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1373, false, nil); A_arbace_cpp_sema_linkage_c_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_10)); return A_arbace_cpp_sema__init_part1_A_const_9 }

func A_arbace_cpp_sema__init_part1_A_Unit105__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(955, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_sema_ns_scope_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_sema_ns_scope_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1374, false, nil); A_arbace_cpp_sema_ns_scope_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_12)); return A_arbace_cpp_sema__init_part1_A_const_11 }












func A_arbace_cpp_sema__init_part1_A_Unit106__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(968, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_13; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_14)); return A_arbace_cpp_sema__init_part1_A_const_13 }
//line :968:1
func A_arbace_cpp_sema__init_part1_A_Unit107__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(968, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_15; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_16)); return A_arbace_cpp_sema__init_part1_A_const_15 }
//line :968:1
func A_arbace_cpp_sema__init_part1_A_Unit108__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(968, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_18)); return A_arbace_cpp_sema__init_part1_A_const_17 }

func A_arbace_cpp_sema__init_part1_A_Unit109__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(970, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_sema_fn_op_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_sema_fn_op_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1375, false, nil); A_arbace_cpp_sema_fn_op_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_20)); return A_arbace_cpp_sema__init_part1_A_const_19 }

func A_arbace_cpp_sema__init_part1_A_Unit110__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(972, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_sema_param_nodes_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_sema_param_nodes_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1376, false, nil); A_arbace_cpp_sema_param_nodes_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_22)); return A_arbace_cpp_sema__init_part1_A_const_21 }

func A_arbace_cpp_sema__init_part1_A_Unit111__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(974, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_sema_same_sig_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_sema_same_sig_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1377, false, nil); A_arbace_cpp_sema_same_sig_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_24)); return A_arbace_cpp_sema__init_part1_A_const_23 }



func A_arbace_cpp_sema__init_part1_A_Unit112__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(978, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_sema_find_redecl_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_sema_find_redecl_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1378, false, nil); A_arbace_cpp_sema_find_redecl_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_26)); return A_arbace_cpp_sema__init_part1_A_const_25 }



func A_arbace_cpp_sema__init_part1_A_Unit113__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(982, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_28)); return A_arbace_cpp_sema__init_part1_A_const_27 }
//line :982:1
func A_arbace_cpp_sema__init_part1_A_Unit114__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(982, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_29; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_30)); return A_arbace_cpp_sema__init_part1_A_const_29 }
//line :982:1
func A_arbace_cpp_sema__init_part1_A_Unit115__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(982, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_31; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_32)); return A_arbace_cpp_sema__init_part1_A_const_31 }

func A_arbace_cpp_sema__init_part1_A_Unit116__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(984, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_sema_noexcept_of_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_sema_noexcept_of_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1379, false, nil); A_arbace_cpp_sema_noexcept_of_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_34)); return A_arbace_cpp_sema__init_part1_A_const_33 }





























func A_arbace_cpp_sema__init_part1_A_Unit117__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1014, 1); A_arbace_cpp_sema__init_part1_A_const_35.BindRoot_O__V(A_arbace_cpp_sema__init_part1_A_const_36); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_35; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_37)); return A_arbace_cpp_sema__init_part1_A_const_35.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part1_A_Unit118__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1015, 1); A_arbace_cpp_sema__init_part1_A_const_38.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_39)); return A_arbace_cpp_sema__init_part1_A_const_38.SetDynamic_Z__Var(true).Ref() }



func A_arbace_cpp_sema__init_part1_A_Unit119__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1019, 1); A_arbace_cpp_sema__init_part1_A_const_40.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_41)); return A_arbace_cpp_sema__init_part1_A_const_40.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part1_A_Unit120__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1020, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_sema_doubt_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_sema_doubt_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1380, false, nil); A_arbace_cpp_sema_doubt_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_43)); return A_arbace_cpp_sema__init_part1_A_const_42 }

func A_arbace_cpp_sema__init_part1_A_Unit121__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1022, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_sema_constraint_satisfied_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_sema_constraint_satisfied_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1381, false, nil); A_arbace_cpp_sema_constraint_satisfied_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_45)); return A_arbace_cpp_sema__init_part1_A_const_44 }


















func A_arbace_cpp_sema__init_part1_A_Unit122__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1041, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_sema_always_inline_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_sema_always_inline_node_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1382, false, nil); A_arbace_cpp_sema_always_inline_node_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_47)); return A_arbace_cpp_sema__init_part1_A_const_46 }




func A_arbace_cpp_sema__init_part1_A_Unit123__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1046, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_sema_noreturn_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_sema_noreturn_node_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1383, false, nil); A_arbace_cpp_sema_noreturn_node_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_49)); return A_arbace_cpp_sema__init_part1_A_const_48 }








func A_arbace_cpp_sema__init_part1_A_Unit124__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1055, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_sema_explicit_spec_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_sema_explicit_spec_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1384, false, nil); A_arbace_cpp_sema_explicit_spec_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_51)); return A_arbace_cpp_sema__init_part1_A_const_50 }




















func A_arbace_cpp_sema__init_part1_A_Unit125__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1076, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_sema_unfinished_targs_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_sema_unfinished_targs_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1385, false, nil); A_arbace_cpp_sema_unfinished_targs_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_53)); return A_arbace_cpp_sema__init_part1_A_const_52 }










func A_arbace_cpp_sema__init_part1_A_Unit126__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1087, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_sema_trailing_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_sema_trailing_ok_QMARK__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1386, false, nil); A_arbace_cpp_sema_trailing_ok_QMARK__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_55)); return A_arbace_cpp_sema__init_part1_A_const_54 }







func A_arbace_cpp_sema__init_part1_A_Unit127__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1095, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_sema_fn_type_scope_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_sema_fn_type_scope_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1387, false, nil); A_arbace_cpp_sema_fn_type_scope_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_57)); return A_arbace_cpp_sema__init_part1_A_const_56 }
















func A_arbace_cpp_sema__init_part1_A_Unit128__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1112, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_sema_declare_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_sema_declare_fn_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1388, false, nil); A_arbace_cpp_sema_declare_fn_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_59)); return A_arbace_cpp_sema__init_part1_A_const_58 }






































































































































func A_arbace_cpp_sema__init_part1_A_Unit129__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1247, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_61)); return A_arbace_cpp_sema__init_part1_A_const_60 }

func A_arbace_cpp_sema__init_part1_A_Unit130__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1249, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_sema_declare_var_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_sema_declare_var_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1389, false, nil); A_arbace_cpp_sema_declare_var_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_63)); return A_arbace_cpp_sema__init_part1_A_const_62 }



















































































func A_arbace_cpp_sema__init_part1_A_Unit131__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1333, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_sema_declare_enum_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_sema_declare_enum_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1390, false, nil); A_arbace_cpp_sema_declare_enum_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_65)); return A_arbace_cpp_sema__init_part1_A_const_64 }






























func A_arbace_cpp_sema__init_part1_A_Unit132__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1364, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_sema_declare_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_sema_declare_class_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1391, false, nil); A_arbace_cpp_sema_declare_class_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_67)); return A_arbace_cpp_sema__init_part1_A_const_66 }































































































































func A_arbace_cpp_sema__init_part1_A_Unit133__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1492, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_69)); return A_arbace_cpp_sema__init_part1_A_const_68 }
//line :1492:1
func A_arbace_cpp_sema__init_part1_A_Unit134__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1492, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_71)); return A_arbace_cpp_sema__init_part1_A_const_70 }
//line :1492:1
func A_arbace_cpp_sema__init_part1_A_Unit135__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1492, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_73)); return A_arbace_cpp_sema__init_part1_A_const_72 }

func A_arbace_cpp_sema__init_part1_A_Unit136__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1494, 1); A_arbace_cpp_sema__init_part1_A_const_74.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_75)); return A_arbace_cpp_sema__init_part1_A_const_74.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part1_A_Unit137__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1495, 1); A_arbace_cpp_sema__init_part1_A_const_76.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_77)); return A_arbace_cpp_sema__init_part1_A_const_76.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part1_A_Unit138__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1496, 1); A_arbace_cpp_sema__init_part1_A_const_78.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_79)); return A_arbace_cpp_sema__init_part1_A_const_78.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part1_A_Unit139__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1498, 1); A_arbace_cpp_sema__init_part1_A_const_80.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_81)); return A_arbace_cpp_sema__init_part1_A_const_80.SetDynamic_Z__Var(true).Ref() }


func A_arbace_cpp_sema__init_part1_A_Unit140__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1501, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_sema_drop_key_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_sema_drop_key_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1392, false, nil); A_arbace_cpp_sema_drop_key_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_83)); return A_arbace_cpp_sema__init_part1_A_const_82 }




func A_arbace_cpp_sema__init_part1_A_Unit141__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1506, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_sema_declare_node_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_sema_declare_node_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1393, false, nil); A_arbace_cpp_sema_declare_node_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_84)); return A_arbace_cpp_sema__init_part1_A_const_13 }




































func A_arbace_cpp_sema__init_part1_A_Unit142__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1543, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_sema_placeholder_split_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_sema_placeholder_split_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1394, false, nil); A_arbace_cpp_sema_placeholder_split_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_86)); return A_arbace_cpp_sema__init_part1_A_const_85 }























func A_arbace_cpp_sema__init_part1_A_Unit143__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1567, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_sema_abbreviated_template_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_sema_abbreviated_template_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1395, false, nil); A_arbace_cpp_sema_abbreviated_template_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_88)); return A_arbace_cpp_sema__init_part1_A_const_87 }















































func A_arbace_cpp_sema__init_part1_A_Unit144__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1615, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_sema_declare_node_STAR__BANG__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_sema_declare_node_STAR__BANG__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1396, false, nil); A_arbace_cpp_sema_declare_node_STAR__BANG__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_89)); return A_arbace_cpp_sema__init_part1_A_const_68 }



















































































































































func A_arbace_cpp_sema__init_part1_A_Unit145__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1763, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_sema_user_ctors_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_sema_user_ctors_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1397, false, nil); A_arbace_cpp_sema_user_ctors_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_91)); return A_arbace_cpp_sema__init_part1_A_const_90 }
func A_arbace_cpp_sema__init_part1_A_Unit146__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1764, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_sema_copy_ctor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_sema_copy_ctor_QMARK__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1398, false, nil); A_arbace_cpp_sema_copy_ctor_QMARK__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_93)); return A_arbace_cpp_sema__init_part1_A_const_92 }

func A_arbace_cpp_sema__init_part1_A_Unit147__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1766, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_sema_move_ctor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_sema_move_ctor_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1399, false, nil); A_arbace_cpp_sema_move_ctor_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_95)); return A_arbace_cpp_sema__init_part1_A_const_94 }

func A_arbace_cpp_sema__init_part1_A_Unit148__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1768, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_sema_copy_assign_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_sema_copy_assign_QMARK__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1400, false, nil); A_arbace_cpp_sema_copy_assign_QMARK__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_97)); return A_arbace_cpp_sema__init_part1_A_const_96 }

func A_arbace_cpp_sema__init_part1_A_Unit149__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1770, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_sema_move_assign_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_sema_move_assign_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1401, false, nil); A_arbace_cpp_sema_move_assign_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_99)); return A_arbace_cpp_sema__init_part1_A_const_98 }

func A_arbace_cpp_sema__init_part1_A_Unit150__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1772, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_sema_class_like_members_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_sema_class_like_members_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1402, false, nil); A_arbace_cpp_sema_class_like_members_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_101)); return A_arbace_cpp_sema__init_part1_A_const_100 }



func A_arbace_cpp_sema__init_part1_A_Unit151__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1776, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_sema_trivial_dtor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_sema_trivial_dtor_QMARK__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1403, false, nil); A_arbace_cpp_sema_trivial_dtor_QMARK__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_103)); return A_arbace_cpp_sema__init_part1_A_const_102 }




func A_arbace_cpp_sema__init_part1_A_Unit152__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1781, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_sema_trivial_copy_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_sema_trivial_copy_QMARK__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1404, false, nil); A_arbace_cpp_sema_trivial_copy_QMARK__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_105)); return A_arbace_cpp_sema__init_part1_A_const_104 }





func A_arbace_cpp_sema__init_part1_A_Unit153__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1787, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_sema_trivial_assign_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_sema_trivial_assign_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1405, false, nil); A_arbace_cpp_sema_trivial_assign_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_107)); return A_arbace_cpp_sema__init_part1_A_const_106 }









func A_arbace_cpp_sema__init_part1_A_Unit154__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1797, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_108; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__74 any = A_arbace_cpp_sema_implicit_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_sema_implicit_fn_BANG__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1406, true, nil); A_arbace_cpp_sema_implicit_fn_BANG__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__74, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_109)); return A_arbace_cpp_sema__init_part1_A_const_108 }

















func A_arbace_cpp_sema__init_part1_A_Unit155__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1815, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_sema_has_ctor_of_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_sema_has_ctor_of_QMARK__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1407, false, nil); A_arbace_cpp_sema_has_ctor_of_QMARK__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_111)); return A_arbace_cpp_sema__init_part1_A_const_110 }

func A_arbace_cpp_sema__init_part1_A_Unit156__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1817, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_cpp_sema_finish_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_cpp_sema_finish_class_BANG__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1408, false, nil); A_arbace_cpp_sema_finish_class_BANG__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_112)); return A_arbace_cpp_sema__init_part1_A_const_17 }












































































































func A_arbace_cpp_sema__init_part1_A_Unit157__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1926, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_cpp_sema_aggregate_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_cpp_sema_aggregate_QMARK__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1409, false, nil); A_arbace_cpp_sema_aggregate_QMARK__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_114)); return A_arbace_cpp_sema__init_part1_A_const_113 }













func A_arbace_cpp_sema__init_part1_A_Unit158__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1940, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_115)); return A_arbace_cpp_sema__init_part1_A_const_27 }
//line :1940:1
func A_arbace_cpp_sema__init_part1_A_Unit159__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1940, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_29; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_116)); return A_arbace_cpp_sema__init_part1_A_const_29 }
//line :1940:1
func A_arbace_cpp_sema__init_part1_A_Unit160__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1940, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_117; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_118)); return A_arbace_cpp_sema__init_part1_A_const_117 }

func A_arbace_cpp_sema__init_part1_A_Unit161__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1942, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_119; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_120)); return A_arbace_cpp_sema__init_part1_A_const_119 }
//line :1942:1
func A_arbace_cpp_sema__init_part1_A_Unit162__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1942, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_121; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_122)); return A_arbace_cpp_sema__init_part1_A_const_121 }
//line :1942:1
func A_arbace_cpp_sema__init_part1_A_Unit163__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1942, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_123; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_124)); return A_arbace_cpp_sema__init_part1_A_const_123 }
//line :1942:1
func A_arbace_cpp_sema__init_part1_A_Unit164__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1942, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_125; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_126)); return A_arbace_cpp_sema__init_part1_A_const_125 }

func A_arbace_cpp_sema__init_part1_A_Unit165__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1944, 1); A_arbace_cpp_sema__init_part1_A_const_127.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_127; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_128)); return A_arbace_cpp_sema__init_part1_A_const_127.SetDynamic_Z__Var(true).Ref() }





func A_arbace_cpp_sema__init_part1_A_Unit166__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1950, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_sema_ce_num_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_sema_ce_num_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1410, false, nil); A_arbace_cpp_sema_ce_num_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_130)); return A_arbace_cpp_sema__init_part1_A_const_129 }




func A_arbace_cpp_sema__init_part1_A_Unit167__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1955, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_sema_wide_value_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_sema_wide_value_QMARK__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1411, false, nil); A_arbace_cpp_sema_wide_value_QMARK__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_132)); return A_arbace_cpp_sema__init_part1_A_const_131 }

func A_arbace_cpp_sema__init_part1_A_Unit168__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1957, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_cpp_sema_wide_literal_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_cpp_sema_wide_literal_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1412, false, nil); A_arbace_cpp_sema_wide_literal_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_134)); return A_arbace_cpp_sema__init_part1_A_const_133 }





func A_arbace_cpp_sema__init_part1_A_Unit169__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1963, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_135; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_136)); return A_arbace_cpp_sema__init_part1_A_const_135 }

func A_arbace_cpp_sema__init_part1_A_Unit170__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1965, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_cpp_sema_from_src_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_cpp_sema_from_src_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1413, false, nil); A_arbace_cpp_sema_from_src_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_138)); return A_arbace_cpp_sema__init_part1_A_const_137 }








func A_arbace_cpp_sema__init_part1_A_Unit171__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1974, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_sema_narrow_out_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_sema_narrow_out_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1414, false, nil); A_arbace_cpp_sema_narrow_out_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_140)); return A_arbace_cpp_sema__init_part1_A_const_139 }




func A_arbace_cpp_sema__init_part1_A_Unit172__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1979, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_sema_wide_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_sema_wide_QMARK__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1415, false, nil); A_arbace_cpp_sema_wide_QMARK__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_141)); return A_arbace_cpp_sema__init_part1_A_const_135 }





func A_arbace_cpp_sema__init_part1_A_Unit173__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1985, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_sema_wide_binop_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_sema_wide_binop_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1416, false, nil); A_arbace_cpp_sema_wide_binop_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_143)); return A_arbace_cpp_sema__init_part1_A_const_142 }














func A_arbace_cpp_sema__init_part1_A_Unit174__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2000, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_144; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_145)); return A_arbace_cpp_sema__init_part1_A_const_144 }






func A_arbace_cpp_sema__init_part1_A_Unit175__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2007, 1); A_arbace_cpp_sema__init_part1_A_const_146.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_146; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_147)); return A_arbace_cpp_sema__init_part1_A_const_146.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part1_A_Unit176__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2009, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_cpp_sema_var_const_int_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_sema_var_const_int_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1417, false, nil); A_arbace_cpp_sema_var_const_int_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_149)); return A_arbace_cpp_sema__init_part1_A_const_148 }












func A_arbace_cpp_sema__init_part1_A_Unit177__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2022, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_sema_const_int_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_sema_const_int_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1418, false, nil); A_arbace_cpp_sema_const_int_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_150)); return A_arbace_cpp_sema__init_part1_A_const_144 }
























































func A_arbace_cpp_sema__init_part1_A_Unit178__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2079, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_151; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_152)); return A_arbace_cpp_sema__init_part1_A_const_151 }
//line :2079:1
func A_arbace_cpp_sema__init_part1_A_Unit179__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2079, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_153; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_154)); return A_arbace_cpp_sema__init_part1_A_const_153 }
//line :2079:1
func A_arbace_cpp_sema__init_part1_A_Unit180__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2079, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_155; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_156)); return A_arbace_cpp_sema__init_part1_A_const_155 }

func A_arbace_cpp_sema__init_part1_A_Unit181__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2081, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_123; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__100 any = A_arbace_cpp_sema_ub_BANG__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_sema_ub_BANG__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1419, true, nil); A_arbace_cpp_sema_ub_BANG__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__100, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_157)); return A_arbace_cpp_sema__init_part1_A_const_123 }





func A_arbace_cpp_sema__init_part1_A_Unit182__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2087, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_125; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__102 any = A_arbace_cpp_sema_not_constant_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_sema_not_constant_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1420, true, nil); A_arbace_cpp_sema_not_constant_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__102, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_158)); return A_arbace_cpp_sema__init_part1_A_const_125 }

func A_arbace_cpp_sema__init_part1_A_Unit183__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2089, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_cpp_sema_ce_ptr_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_cpp_sema_ce_ptr_QMARK__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1421, false, nil); A_arbace_cpp_sema_ce_ptr_QMARK__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_160)); return A_arbace_cpp_sema__init_part1_A_const_159 }





func A_arbace_cpp_sema__init_part1_A_Unit184__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2095, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_cpp_sema_ce_elems_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_cpp_sema_ce_elems_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1422, false, nil); A_arbace_cpp_sema_ce_elems_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_162)); return A_arbace_cpp_sema__init_part1_A_const_161 }

func A_arbace_cpp_sema__init_part1_A_Unit185__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2097, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_cpp_sema_ce_ptr_add_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_cpp_sema_ce_ptr_add_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1423, false, nil); A_arbace_cpp_sema_ce_ptr_add_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_164)); return A_arbace_cpp_sema__init_part1_A_const_163 }





func A_arbace_cpp_sema__init_part1_A_Unit186__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2103, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_cpp_sema_ce_same_base_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_cpp_sema_ce_same_base_QMARK__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1424, false, nil); A_arbace_cpp_sema_ce_same_base_QMARK__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_166)); return A_arbace_cpp_sema__init_part1_A_const_165 }







func A_arbace_cpp_sema__init_part1_A_Unit187__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2111, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_cpp_sema_ce_loc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_cpp_sema_ce_loc_QMARK__A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1425, false, nil); A_arbace_cpp_sema_ce_loc_QMARK__A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_168)); return A_arbace_cpp_sema__init_part1_A_const_167 }

func A_arbace_cpp_sema__init_part1_A_Unit188__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2113, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_cpp_sema_ce_get_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_cpp_sema_ce_get_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1426, false, nil); A_arbace_cpp_sema_ce_get_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_170)); return A_arbace_cpp_sema__init_part1_A_const_169 }






func A_arbace_cpp_sema__init_part1_A_Unit189__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2120, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_cpp_sema_ce_put_BANG__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_cpp_sema_ce_put_BANG__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1427, false, nil); A_arbace_cpp_sema_ce_put_BANG__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_172)); return A_arbace_cpp_sema__init_part1_A_const_171 }


func A_arbace_cpp_sema__init_part1_A_Unit190__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2123, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_cpp_sema_ce_cell_loc_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_cpp_sema_ce_cell_loc_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1428, false, nil); A_arbace_cpp_sema_ce_cell_loc_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_174)); return A_arbace_cpp_sema__init_part1_A_const_173 }

func A_arbace_cpp_sema__init_part1_A_Unit191__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2125, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_175; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_176)); return A_arbace_cpp_sema__init_part1_A_const_175 }

func A_arbace_cpp_sema__init_part1_A_Unit192__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2127, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_cpp_sema_ce_wrap_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_cpp_sema_ce_wrap_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1429, false, nil); A_arbace_cpp_sema_ce_wrap_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_177)); return A_arbace_cpp_sema__init_part1_A_const_121 }


























func A_arbace_cpp_sema__init_part1_A_Unit193__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2154, 1); A_arbace_cpp_sema__init_part1_A_const_178.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_178; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_179)); return A_arbace_cpp_sema__init_part1_A_const_178.SetDynamic_Z__Var(true).Ref() }


func A_arbace_cpp_sema__init_part1_A_Unit194__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2157, 1); A_arbace_cpp_sema__init_part1_A_const_180.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_180; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_181)); return A_arbace_cpp_sema__init_part1_A_const_180.SetDynamic_Z__Var(true).Ref() }




func A_arbace_cpp_sema__init_part1_A_Unit195__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2162, 1); A_arbace_cpp_sema__init_part1_A_const_182.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_182; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_183)); return A_arbace_cpp_sema__init_part1_A_const_182.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part1_A_Unit196__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2164, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_184; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__122 any = A_arbace_cpp_sema_ce_top_sure_BANG__A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_cpp_sema_ce_top_sure_BANG__A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1430, true, nil); A_arbace_cpp_sema_ce_top_sure_BANG__A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__122, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_185)); return A_arbace_cpp_sema__init_part1_A_const_184 }






func A_arbace_cpp_sema__init_part1_A_Unit197__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2171, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_186; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_187)); return A_arbace_cpp_sema__init_part1_A_const_186 }
//line :2171:1
func A_arbace_cpp_sema__init_part1_A_Unit198__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2171, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_188; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_189)); return A_arbace_cpp_sema__init_part1_A_const_188 }
//line :2171:1
func A_arbace_cpp_sema__init_part1_A_Unit199__O() any { A_arbace_cpp_sema__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2171, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part1_A_const_190; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part1_A_const_191)); return A_arbace_cpp_sema__init_part1_A_const_190 }
//line :2171:1
func A_arbace_cpp_sema__init_part2_A_Unit200__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2171, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_1)); return A_arbace_cpp_sema__init_part2_A_const_0 }
//line :2171:1
func A_arbace_cpp_sema__init_part2_A_Unit201__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2171, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_3)); return A_arbace_cpp_sema__init_part2_A_const_2 }
//line :2171:1
func A_arbace_cpp_sema__init_part2_A_Unit202__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2171, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_5)); return A_arbace_cpp_sema__init_part2_A_const_4 }
//line :2171:1
func A_arbace_cpp_sema__init_part2_A_Init__O() any { A_arbace_cpp_sema__init_part2_A_Init(); return nil }
//line :2171:1
func A_arbace_cpp_sema__init_part2_A_Load__O() any { A_arbace_cpp_sema__init_part2_A_Init(); A_arbace_cpp_sema__init_part2_A_Unit200__O(); A_arbace_cpp_sema__init_part2_A_Unit201__O(); A_arbace_cpp_sema__init_part2_A_Unit202__O(); A_arbace_cpp_sema__init_part2_A_Unit203__O(); A_arbace_cpp_sema__init_part2_A_Unit204__O(); A_arbace_cpp_sema__init_part2_A_Unit205__O(); A_arbace_cpp_sema__init_part2_A_Unit206__O(); A_arbace_cpp_sema__init_part2_A_Unit207__O(); A_arbace_cpp_sema__init_part2_A_Unit208__O(); A_arbace_cpp_sema__init_part2_A_Unit209__O(); A_arbace_cpp_sema__init_part2_A_Unit210__O(); A_arbace_cpp_sema__init_part2_A_Unit211__O(); A_arbace_cpp_sema__init_part2_A_Unit212__O(); A_arbace_cpp_sema__init_part2_A_Unit213__O(); A_arbace_cpp_sema__init_part2_A_Unit214__O(); A_arbace_cpp_sema__init_part2_A_Unit215__O(); A_arbace_cpp_sema__init_part2_A_Unit216__O(); A_arbace_cpp_sema__init_part2_A_Unit217__O(); A_arbace_cpp_sema__init_part2_A_Unit218__O(); A_arbace_cpp_sema__init_part2_A_Unit219__O(); A_arbace_cpp_sema__init_part2_A_Unit220__O(); A_arbace_cpp_sema__init_part2_A_Unit221__O(); A_arbace_cpp_sema__init_part2_A_Unit222__O(); A_arbace_cpp_sema__init_part2_A_Unit223__O(); A_arbace_cpp_sema__init_part2_A_Unit224__O(); A_arbace_cpp_sema__init_part2_A_Unit225__O(); A_arbace_cpp_sema__init_part2_A_Unit226__O(); A_arbace_cpp_sema__init_part2_A_Unit227__O(); A_arbace_cpp_sema__init_part2_A_Unit228__O(); A_arbace_cpp_sema__init_part2_A_Unit229__O(); A_arbace_cpp_sema__init_part2_A_Unit230__O(); A_arbace_cpp_sema__init_part2_A_Unit231__O(); A_arbace_cpp_sema__init_part2_A_Unit232__O(); A_arbace_cpp_sema__init_part2_A_Unit233__O(); A_arbace_cpp_sema__init_part2_A_Unit234__O(); A_arbace_cpp_sema__init_part2_A_Unit235__O(); A_arbace_cpp_sema__init_part2_A_Unit236__O(); A_arbace_cpp_sema__init_part2_A_Unit237__O(); A_arbace_cpp_sema__init_part2_A_Unit238__O(); A_arbace_cpp_sema__init_part2_A_Unit239__O(); A_arbace_cpp_sema__init_part2_A_Unit240__O(); A_arbace_cpp_sema__init_part2_A_Unit241__O(); A_arbace_cpp_sema__init_part2_A_Unit242__O(); A_arbace_cpp_sema__init_part2_A_Unit243__O(); A_arbace_cpp_sema__init_part2_A_Unit244__O(); A_arbace_cpp_sema__init_part2_A_Unit245__O(); A_arbace_cpp_sema__init_part2_A_Unit246__O(); A_arbace_cpp_sema__init_part2_A_Unit247__O(); A_arbace_cpp_sema__init_part2_A_Unit248__O(); A_arbace_cpp_sema__init_part2_A_Unit249__O(); A_arbace_cpp_sema__init_part2_A_Unit250__O(); A_arbace_cpp_sema__init_part2_A_Unit251__O(); A_arbace_cpp_sema__init_part2_A_Unit252__O(); A_arbace_cpp_sema__init_part2_A_Unit253__O(); A_arbace_cpp_sema__init_part2_A_Unit254__O(); A_arbace_cpp_sema__init_part2_A_Unit255__O(); A_arbace_cpp_sema__init_part2_A_Unit256__O(); A_arbace_cpp_sema__init_part2_A_Unit257__O(); A_arbace_cpp_sema__init_part2_A_Unit258__O(); A_arbace_cpp_sema__init_part2_A_Unit259__O(); A_arbace_cpp_sema__init_part2_A_Unit260__O(); A_arbace_cpp_sema__init_part2_A_Unit261__O(); A_arbace_cpp_sema__init_part2_A_Unit262__O(); A_arbace_cpp_sema__init_part2_A_Unit263__O(); A_arbace_cpp_sema__init_part2_A_Unit264__O(); A_arbace_cpp_sema__init_part2_A_Unit265__O(); A_arbace_cpp_sema__init_part2_A_Unit266__O(); A_arbace_cpp_sema__init_part2_A_Unit267__O(); A_arbace_cpp_sema__init_part2_A_Unit268__O(); A_arbace_cpp_sema__init_part2_A_Unit269__O(); A_arbace_cpp_sema__init_part2_A_Unit270__O(); A_arbace_cpp_sema__init_part2_A_Unit271__O(); A_arbace_cpp_sema__init_part2_A_Unit272__O(); A_arbace_cpp_sema__init_part2_A_Unit273__O(); A_arbace_cpp_sema__init_part2_A_Unit274__O(); A_arbace_cpp_sema__init_part2_A_Unit275__O(); A_arbace_cpp_sema__init_part2_A_Unit276__O(); A_arbace_cpp_sema__init_part2_A_Unit277__O(); A_arbace_cpp_sema__init_part2_A_Unit278__O(); A_arbace_cpp_sema__init_part2_A_Unit279__O(); A_arbace_cpp_sema__init_part2_A_Unit280__O(); A_arbace_cpp_sema__init_part2_A_Unit281__O(); A_arbace_cpp_sema__init_part2_A_Unit282__O(); A_arbace_cpp_sema__init_part2_A_Unit283__O(); A_arbace_cpp_sema__init_part2_A_Unit284__O(); A_arbace_cpp_sema__init_part2_A_Unit285__O(); A_arbace_cpp_sema__init_part2_A_Unit286__O(); A_arbace_cpp_sema__init_part2_A_Unit287__O(); A_arbace_cpp_sema__init_part2_A_Unit288__O(); A_arbace_cpp_sema__init_part2_A_Unit289__O(); A_arbace_cpp_sema__init_part2_A_Unit290__O(); A_arbace_cpp_sema__init_part2_A_Unit291__O(); A_arbace_cpp_sema__init_part2_A_Unit292__O(); A_arbace_cpp_sema__init_part2_A_Unit293__O(); A_arbace_cpp_sema__init_part2_A_Unit294__O(); A_arbace_cpp_sema__init_part2_A_Unit295__O(); A_arbace_cpp_sema__init_part2_A_Unit296__O(); A_arbace_cpp_sema__init_part2_A_Unit297__O(); A_arbace_cpp_sema__init_part2_A_Unit298__O(); A_arbace_cpp_sema__init_part2_A_Unit299__O(); return nil }

func A_arbace_cpp_sema__init_part2_A_Unit203__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2173, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_sema_ce_eval_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_sema_ce_eval_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1432, false, nil); A_arbace_cpp_sema_ce_eval_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_7)); return A_arbace_cpp_sema__init_part2_A_const_6 }































































































































































































func A_arbace_cpp_sema__init_part2_A_Unit204__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2365, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_sema_ce_exec_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_sema_ce_exec_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1433, false, nil); A_arbace_cpp_sema_ce_exec_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_9)); return A_arbace_cpp_sema__init_part2_A_const_8 }


























































func A_arbace_cpp_sema__init_part2_A_Unit205__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2424, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_sema_ce_base_path_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_sema_ce_base_path_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1434, false, nil); A_arbace_cpp_sema_ce_base_path_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_11)); return A_arbace_cpp_sema__init_part2_A_const_10 }





func A_arbace_cpp_sema__init_part2_A_Unit206__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2430, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_sema_ce_lv_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_sema_ce_lv_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1435, false, nil); A_arbace_cpp_sema_ce_lv_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_13)); return A_arbace_cpp_sema__init_part2_A_const_12 }






















func A_arbace_cpp_sema__init_part2_A_Unit207__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2453, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_sema_ce_glvalue_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_sema_ce_glvalue_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1436, false, nil); A_arbace_cpp_sema_ce_glvalue_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_15)); return A_arbace_cpp_sema__init_part2_A_const_14 }




func A_arbace_cpp_sema__init_part2_A_Unit208__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2458, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_sema_ce_store_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_sema_ce_store_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1437, false, nil); A_arbace_cpp_sema_ce_store_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_16)); return A_arbace_cpp_sema__init_part2_A_const_0 }









func A_arbace_cpp_sema__init_part2_A_Unit209__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2468, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_sema_ce_zero_of_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_sema_ce_zero_of_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1438, false, nil); A_arbace_cpp_sema_ce_zero_of_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_18)); return A_arbace_cpp_sema__init_part2_A_const_17 }









func A_arbace_cpp_sema__init_part2_A_Unit210__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2478, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_sema_ce_args_env_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_sema_ce_args_env_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1439, false, nil); A_arbace_cpp_sema_ce_args_env_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_19)); return A_arbace_cpp_sema__init_part2_A_const_4 }












func A_arbace_cpp_sema__init_part2_A_Unit211__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2491, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_sema_ce_construct_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_sema_ce_construct_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1440, false, nil); A_arbace_cpp_sema_ce_construct_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_20)); return A_arbace_cpp_sema__init_part2_A_const_2 }






























func A_arbace_cpp_sema__init_part2_A_Unit212__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2522, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_sema_ce_init_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_sema_ce_init_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1441, false, nil); A_arbace_cpp_sema_ce_init_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_22)); return A_arbace_cpp_sema__init_part2_A_const_21 }































func A_arbace_cpp_sema__init_part2_A_Unit213__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2554, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_sema_ce_call_fn_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_sema_ce_call_fn_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1442, false, nil); A_arbace_cpp_sema_ce_call_fn_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_24)); return A_arbace_cpp_sema__init_part2_A_const_23 }












func A_arbace_cpp_sema__init_part2_A_Unit214__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2567, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_sema_ce_try_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_sema_ce_try_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1443, false, nil); A_arbace_cpp_sema_ce_try_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_26)); return A_arbace_cpp_sema__init_part2_A_const_25 }













func A_arbace_cpp_sema__init_part2_A_Unit215__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2581, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_sema_fold_mark_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_sema_fold_mark_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1444, false, nil); A_arbace_cpp_sema_fold_mark_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_28)); return A_arbace_cpp_sema__init_part2_A_const_27 }











func A_arbace_cpp_sema__init_part2_A_Unit216__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2593, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_sema_lv_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_sema_lv_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1445, false, nil); A_arbace_cpp_sema_lv_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_30)); return A_arbace_cpp_sema__init_part2_A_const_29 }

func A_arbace_cpp_sema__init_part2_A_Unit217__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2595, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_sema_cast_node_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_sema_cast_node_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1446, false, nil); A_arbace_cpp_sema_cast_node_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_32)); return A_arbace_cpp_sema__init_part2_A_const_31 }

func A_arbace_cpp_sema__init_part2_A_Unit218__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2597, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_sema_fn_matching_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_sema_fn_matching_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1447, false, nil); A_arbace_cpp_sema_fn_matching_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_34)); return A_arbace_cpp_sema__init_part2_A_const_33 }












func A_arbace_cpp_sema__init_part2_A_Unit219__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2610, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_sema_mptr_fn_node_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_sema_mptr_fn_node_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1448, false, nil); A_arbace_cpp_sema_mptr_fn_node_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_36)); return A_arbace_cpp_sema__init_part2_A_const_35 }




func A_arbace_cpp_sema__init_part2_A_Unit220__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2615, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_sema_rv_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_sema_rv_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1449, false, nil); A_arbace_cpp_sema_rv_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_38)); return A_arbace_cpp_sema__init_part2_A_const_37 }




















func A_arbace_cpp_sema__init_part2_A_Unit221__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2636, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_sema_promote_type_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_sema_promote_type_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1450, false, nil); A_arbace_cpp_sema_promote_type_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_40)); return A_arbace_cpp_sema__init_part2_A_const_39 }






func A_arbace_cpp_sema__init_part2_A_Unit222__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2643, 1); A_arbace_cpp_sema__init_part2_A_const_41.BindRoot_O__V(A_arbace_cpp_sema__init_part2_A_const_42); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_43)); return A_arbace_cpp_sema__init_part2_A_const_41 }

func A_arbace_cpp_sema__init_part2_A_Unit223__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2645, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_sema_arith_common_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_sema_arith_common_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1451, false, nil); A_arbace_cpp_sema_arith_common_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_45)); return A_arbace_cpp_sema__init_part2_A_const_44 }






















func A_arbace_cpp_sema__init_part2_A_Unit224__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2668, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_sema_null_constant_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_sema_null_constant_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1452, false, nil); A_arbace_cpp_sema_null_constant_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_47)); return A_arbace_cpp_sema__init_part2_A_const_46 }







func A_arbace_cpp_sema__init_part2_A_Unit225__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2676, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_sema_class_id_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_sema_class_id_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1453, false, nil); A_arbace_cpp_sema_class_id_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_49)); return A_arbace_cpp_sema__init_part2_A_const_48 }

func A_arbace_cpp_sema__init_part2_A_Unit226__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2678, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_sema_convert_scalar_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_sema_convert_scalar_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1454, false, nil); A_arbace_cpp_sema_convert_scalar_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_51)); return A_arbace_cpp_sema__init_part2_A_const_50 }










































func A_arbace_cpp_sema__init_part2_A_Unit227__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2721, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_53)); return A_arbace_cpp_sema__init_part2_A_const_52 }
//line :2721:1
func A_arbace_cpp_sema__init_part2_A_Unit228__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2721, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_55)); return A_arbace_cpp_sema__init_part2_A_const_54 }

func A_arbace_cpp_sema__init_part2_A_Unit229__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2723, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_sema_std_rank_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_sema_std_rank_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1455, false, nil); A_arbace_cpp_sema_std_rank_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_57)); return A_arbace_cpp_sema__init_part2_A_const_56 }























func A_arbace_cpp_sema__init_part2_A_Unit230__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2747, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_sema_arr_unq_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_sema_arr_unq_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1456, false, nil); A_arbace_cpp_sema_arr_unq_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_59)); return A_arbace_cpp_sema__init_part2_A_const_58 }

func A_arbace_cpp_sema__init_part2_A_Unit231__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2749, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_sema_arr_cv_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_sema_arr_cv_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1457, false, nil); A_arbace_cpp_sema_arr_cv_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_61)); return A_arbace_cpp_sema__init_part2_A_const_60 }

func A_arbace_cpp_sema__init_part2_A_Unit232__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2751, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_sema_conv_fns_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_sema_conv_fns_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1458, false, nil); A_arbace_cpp_sema_conv_fns_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_63)); return A_arbace_cpp_sema__init_part2_A_const_62 }








func A_arbace_cpp_sema__init_part2_A_Unit233__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2760, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_65)); return A_arbace_cpp_sema__init_part2_A_const_64 }
//line :2760:1
func A_arbace_cpp_sema__init_part2_A_Unit234__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2760, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_67)); return A_arbace_cpp_sema__init_part2_A_const_66 }
//line :2760:1
func A_arbace_cpp_sema__init_part2_A_Unit235__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2760, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_69)); return A_arbace_cpp_sema__init_part2_A_const_68 }
//line :2760:1
func A_arbace_cpp_sema__init_part2_A_Unit236__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2760, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_71)); return A_arbace_cpp_sema__init_part2_A_const_70 }

func A_arbace_cpp_sema__init_part2_A_Unit237__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2762, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_sema_conv_tmpls_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_sema_conv_tmpls_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1459, false, nil); A_arbace_cpp_sema_conv_tmpls_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_73)); return A_arbace_cpp_sema__init_part2_A_const_72 }




func A_arbace_cpp_sema__init_part2_A_Unit238__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2767, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_sema_conv_specs_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_sema_conv_specs_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1460, false, nil); A_arbace_cpp_sema_conv_specs_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_75)); return A_arbace_cpp_sema__init_part2_A_const_74 }






func A_arbace_cpp_sema__init_part2_A_Unit239__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2774, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_sema_glam_conv_BANG__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_sema_glam_conv_BANG__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1461, false, nil); A_arbace_cpp_sema_glam_conv_BANG__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_77)); return A_arbace_cpp_sema__init_part2_A_const_76 }








































func A_arbace_cpp_sema__init_part2_A_Unit240__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2815, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_78; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__62 any = A_arbace_cpp_sema_conv_for_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_sema_conv_for_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1462, true, nil); A_arbace_cpp_sema_conv_for_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__62, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_79)); return A_arbace_cpp_sema__init_part2_A_const_78 }
























func A_arbace_cpp_sema__init_part2_A_Unit241__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2840, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_80; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__64 any = A_arbace_cpp_sema_ref_conv_for_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_sema_ref_conv_for_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1463, true, nil); A_arbace_cpp_sema_ref_conv_for_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__64, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_81)); return A_arbace_cpp_sema__init_part2_A_const_80 }



































func A_arbace_cpp_sema__init_part2_A_Unit242__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2876, 1); A_arbace_cpp_sema__init_part2_A_const_82.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_83)); return A_arbace_cpp_sema__init_part2_A_const_82.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_sema__init_part2_A_Unit243__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2877, 1); A_arbace_cpp_sema__init_part2_A_const_84.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_85)); return A_arbace_cpp_sema__init_part2_A_const_84.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part2_A_Unit244__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2879, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_sema_list_ctor_viable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_sema_list_ctor_viable_QMARK__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1464, false, nil); A_arbace_cpp_sema_list_ctor_viable_QMARK__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_87)); return A_arbace_cpp_sema__init_part2_A_const_86 }






















func A_arbace_cpp_sema__init_part2_A_Unit245__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2902, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_sema_ics_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_sema_ics_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1465, false, nil); A_arbace_cpp_sema_ics_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_89)); return A_arbace_cpp_sema__init_part2_A_const_88 }





















































































func A_arbace_cpp_sema__init_part2_A_Unit246__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2988, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_sema_better_ics_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_sema_better_ics_QMARK__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1466, false, nil); A_arbace_cpp_sema_better_ics_QMARK__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_91)); return A_arbace_cpp_sema__init_part2_A_const_90 }






func A_arbace_cpp_sema__init_part2_A_Unit247__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2995, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_92; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_93)); return A_arbace_cpp_sema__init_part2_A_const_92 }

func A_arbace_cpp_sema__init_part2_A_Unit248__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2997, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_sema_resolve_overload_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_sema_resolve_overload_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1467, false, nil); A_arbace_cpp_sema_resolve_overload_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_94)); return A_arbace_cpp_sema__init_part2_A_const_54 }





func A_arbace_cpp_sema__init_part2_A_Unit249__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3003, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_cpp_sema_resolve_overload_STAR__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_sema_resolve_overload_STAR__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1468, false, nil); A_arbace_cpp_sema_resolve_overload_STAR__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_95)); return A_arbace_cpp_sema__init_part2_A_const_92 }



































































func A_arbace_cpp_sema__init_part2_A_Unit250__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3071, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_96)); return A_arbace_cpp_sema__init_part2_A_const_68 }
//line :3071:1
func A_arbace_cpp_sema__init_part2_A_Unit251__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3071, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_97; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_98)); return A_arbace_cpp_sema__init_part2_A_const_97 }
//line :3071:1
func A_arbace_cpp_sema__init_part2_A_Unit252__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3071, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_99; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_100)); return A_arbace_cpp_sema__init_part2_A_const_99 }
//line :3071:1
func A_arbace_cpp_sema__init_part2_A_Unit253__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3071, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_101)); return A_arbace_cpp_sema__init_part2_A_const_66 }
//line :3071:1
func A_arbace_cpp_sema__init_part2_A_Unit254__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3071, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_103)); return A_arbace_cpp_sema__init_part2_A_const_102 }
//line :3071:1
func A_arbace_cpp_sema__init_part2_A_Unit255__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3071, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_105)); return A_arbace_cpp_sema__init_part2_A_const_104 }

func A_arbace_cpp_sema__init_part2_A_Unit256__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3073, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_sema_user_conv_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_sema_user_conv_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1469, false, nil); A_arbace_cpp_sema_user_conv_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_107)); return A_arbace_cpp_sema__init_part2_A_const_106 }






















func A_arbace_cpp_sema__init_part2_A_Unit257__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3096, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_cpp_sema_ctor_candidates_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_cpp_sema_ctor_candidates_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1470, false, nil); A_arbace_cpp_sema_ctor_candidates_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_108)); return A_arbace_cpp_sema__init_part2_A_const_52 }







func A_arbace_cpp_sema__init_part2_A_Unit258__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3104, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_cpp_sema_call_args_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_cpp_sema_call_args_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1471, false, nil); A_arbace_cpp_sema_call_args_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_110)); return A_arbace_cpp_sema__init_part2_A_const_109 }


























func A_arbace_cpp_sema__init_part2_A_Unit259__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3131, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_sema_init_list_elem_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_sema_init_list_elem_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1472, false, nil); A_arbace_cpp_sema_init_list_elem_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_112)); return A_arbace_cpp_sema__init_part2_A_const_111 }








func A_arbace_cpp_sema__init_part2_A_Unit260__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3140, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_sema_std_init_list_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_sema_std_init_list_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1473, false, nil); A_arbace_cpp_sema_std_init_list_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_114)); return A_arbace_cpp_sema__init_part2_A_const_113 }









func A_arbace_cpp_sema__init_part2_A_Unit261__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3150, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_cpp_sema_init_list_ctors_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_cpp_sema_init_list_ctors_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1474, false, nil); A_arbace_cpp_sema_init_list_ctors_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_116)); return A_arbace_cpp_sema__init_part2_A_const_115 }








func A_arbace_cpp_sema__init_part2_A_Unit262__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3159, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_117; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_118)); return A_arbace_cpp_sema__init_part2_A_const_117 }








func A_arbace_cpp_sema__init_part2_A_Unit263__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3168, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_cpp_sema_cx_enclosing_classes_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_cpp_sema_cx_enclosing_classes_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1475, false, nil); A_arbace_cpp_sema_cx_enclosing_classes_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_120)); return A_arbace_cpp_sema__init_part2_A_const_119 }












func A_arbace_cpp_sema__init_part2_A_Unit264__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3181, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_sema_cx_context_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_sema_cx_context_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1476, false, nil); A_arbace_cpp_sema_cx_context_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_122)); return A_arbace_cpp_sema__init_part2_A_const_121 }











func A_arbace_cpp_sema__init_part2_A_Unit265__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3193, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_sema_cx_friend_of_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_sema_cx_friend_of_QMARK__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1477, false, nil); A_arbace_cpp_sema_cx_friend_of_QMARK__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_124)); return A_arbace_cpp_sema__init_part2_A_const_123 }










func A_arbace_cpp_sema__init_part2_A_Unit266__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3204, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_sema_cx_member_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_sema_cx_member_ok_QMARK__A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1478, false, nil); A_arbace_cpp_sema_cx_member_ok_QMARK__A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_126)); return A_arbace_cpp_sema__init_part2_A_const_125 }













func A_arbace_cpp_sema__init_part2_A_Unit267__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3218, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_cpp_sema_cx_paths_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_sema_cx_paths_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1479, false, nil); A_arbace_cpp_sema_cx_paths_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_128)); return A_arbace_cpp_sema__init_part2_A_const_127 }


func A_arbace_cpp_sema__init_part2_A_Unit268__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3221, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_sema_cx_access_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_sema_cx_access_ok_QMARK__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1480, false, nil); A_arbace_cpp_sema_cx_access_ok_QMARK__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_130)); return A_arbace_cpp_sema__init_part2_A_const_129 }

























func A_arbace_cpp_sema__init_part2_A_Unit269__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3247, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_cpp_sema_cx_access_BANG__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_sema_cx_access_BANG__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1481, false, nil); A_arbace_cpp_sema_cx_access_BANG__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_132)); return A_arbace_cpp_sema__init_part2_A_const_131 }












func A_arbace_cpp_sema__init_part2_A_Unit270__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3260, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_cpp_sema_cx_ctor_access_BANG__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_sema_cx_ctor_access_BANG__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1482, false, nil); A_arbace_cpp_sema_cx_ctor_access_BANG__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_134)); return A_arbace_cpp_sema__init_part2_A_const_133 }














func A_arbace_cpp_sema__init_part2_A_Unit271__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3275, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_cpp_sema_class_init_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_cpp_sema_class_init_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1483, false, nil); A_arbace_cpp_sema_class_init_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_136)); return A_arbace_cpp_sema__init_part2_A_const_135 }





















































func A_arbace_cpp_sema__init_part2_A_Unit272__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3329, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_cpp_sema_inheriting_ctor_BANG__A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_cpp_sema_inheriting_ctor_BANG__A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1484, false, nil); A_arbace_cpp_sema_inheriting_ctor_BANG__A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_138)); return A_arbace_cpp_sema__init_part2_A_const_137 }

























func A_arbace_cpp_sema__init_part2_A_Unit273__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3355, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_cpp_sema_inherit_through_BANG__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_cpp_sema_inherit_through_BANG__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1485, false, nil); A_arbace_cpp_sema_inherit_through_BANG__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_140)); return A_arbace_cpp_sema__init_part2_A_const_139 }












func A_arbace_cpp_sema__init_part2_A_Unit274__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3368, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_cpp_sema_ctor_init_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_cpp_sema_ctor_init_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1486, false, nil); A_arbace_cpp_sema_ctor_init_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_141)); return A_arbace_cpp_sema__init_part2_A_const_104 }




























































func A_arbace_cpp_sema__init_part2_A_Unit275__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3429, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_cpp_sema_default_ctor_init_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_cpp_sema_default_ctor_init_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1487, false, nil); A_arbace_cpp_sema_default_ctor_init_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_142)); return A_arbace_cpp_sema__init_part2_A_const_99 }




















func A_arbace_cpp_sema__init_part2_A_Unit276__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3450, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_cpp_sema_materialize_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_cpp_sema_materialize_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1488, false, nil); A_arbace_cpp_sema_materialize_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_143)); return A_arbace_cpp_sema__init_part2_A_const_102 }




func A_arbace_cpp_sema__init_part2_A_Unit277__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3455, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_144; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_145)); return A_arbace_cpp_sema__init_part2_A_const_144 }

func A_arbace_cpp_sema__init_part2_A_Unit278__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3457, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_cpp_sema_aggr_subs_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_cpp_sema_aggr_subs_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1489, false, nil); A_arbace_cpp_sema_aggr_subs_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_146)); return A_arbace_cpp_sema__init_part2_A_const_117 }









func A_arbace_cpp_sema__init_part2_A_Unit279__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3467, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_147; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_148)); return A_arbace_cpp_sema__init_part2_A_const_147 }

func A_arbace_cpp_sema__init_part2_A_Unit280__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3469, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_cpp_sema_elide_sub_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_cpp_sema_elide_sub_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1490, false, nil); A_arbace_cpp_sema_elide_sub_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_150)); return A_arbace_cpp_sema__init_part2_A_const_149 }












func A_arbace_cpp_sema__init_part2_A_Unit281__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3482, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_cpp_sema_elide_agg_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_cpp_sema_elide_agg_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1491, false, nil); A_arbace_cpp_sema_elide_agg_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_151)); return A_arbace_cpp_sema__init_part2_A_const_147 }





func A_arbace_cpp_sema__init_part2_A_Unit282__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3488, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_cpp_sema_brace_elide_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_cpp_sema_brace_elide_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1492, false, nil); A_arbace_cpp_sema_brace_elide_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_153)); return A_arbace_cpp_sema__init_part2_A_const_152 }















func A_arbace_cpp_sema__init_part2_A_Unit283__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3504, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_cpp_sema_init_for_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_cpp_sema_init_for_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1493, false, nil); A_arbace_cpp_sema_init_for_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_154)); return A_arbace_cpp_sema__init_part2_A_const_68 }








































































































































func A_arbace_cpp_sema__init_part2_A_Unit284__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3641, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_155; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_cpp_sema_int_type_of_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_cpp_sema_int_type_of_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1494, false, nil); A_arbace_cpp_sema_int_type_of_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_156)); return A_arbace_cpp_sema__init_part2_A_const_155 }


func A_arbace_cpp_sema__init_part2_A_Unit285__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3644, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_157; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_cpp_sema_decode_string_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_cpp_sema_decode_string_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1495, false, nil); A_arbace_cpp_sema_decode_string_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_158)); return A_arbace_cpp_sema__init_part2_A_const_157 }



















func A_arbace_cpp_sema__init_part2_A_Unit286__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3664, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_cpp_sema_wide_units_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_cpp_sema_wide_units_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1496, false, nil); A_arbace_cpp_sema_wide_units_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_160)); return A_arbace_cpp_sema__init_part2_A_const_159 }




















func A_arbace_cpp_sema__init_part2_A_Unit287__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3685, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_cpp_sema_str_units_A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_cpp_sema_str_units_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1497, false, nil); A_arbace_cpp_sema_str_units_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_162)); return A_arbace_cpp_sema__init_part2_A_const_161 }




func A_arbace_cpp_sema__init_part2_A_Unit288__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3690, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_163; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_164)); return A_arbace_cpp_sema__init_part2_A_const_163 }

func A_arbace_cpp_sema__init_part2_A_Unit289__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3692, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_cpp_sema_this_expr_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_cpp_sema_this_expr_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1498, false, nil); A_arbace_cpp_sema_this_expr_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_166)); return A_arbace_cpp_sema__init_part2_A_const_165 }





func A_arbace_cpp_sema__init_part2_A_Unit290__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3698, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_cpp_sema_deref_node_A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_cpp_sema_deref_node_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1499, false, nil); A_arbace_cpp_sema_deref_node_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_168)); return A_arbace_cpp_sema__init_part2_A_const_167 }




func A_arbace_cpp_sema__init_part2_A_Unit291__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3703, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_cpp_sema_base_subobjects_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_cpp_sema_base_subobjects_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1500, false, nil); A_arbace_cpp_sema_base_subobjects_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_170)); return A_arbace_cpp_sema__init_part2_A_const_169 }












func A_arbace_cpp_sema__init_part2_A_Unit292__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3716, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_cpp_sema_cx_naming_class_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_cpp_sema_cx_naming_class_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1501, false, nil); A_arbace_cpp_sema_cx_naming_class_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_172)); return A_arbace_cpp_sema__init_part2_A_const_171 }






func A_arbace_cpp_sema__init_part2_A_Unit293__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3723, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_cpp_sema_to_base_lv_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_cpp_sema_to_base_lv_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1502, false, nil); A_arbace_cpp_sema_to_base_lv_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_174)); return A_arbace_cpp_sema__init_part2_A_const_173 }









func A_arbace_cpp_sema__init_part2_A_Unit294__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3733, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_cpp_sema_cx_via_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_cpp_sema_cx_via_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1503, false, nil); A_arbace_cpp_sema_cx_via_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_176)); return A_arbace_cpp_sema__init_part2_A_const_175 }









func A_arbace_cpp_sema__init_part2_A_Unit295__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3743, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_177; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_cpp_sema_field_node_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_cpp_sema_field_node_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1504, false, nil); A_arbace_cpp_sema_field_node_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_178)); return A_arbace_cpp_sema__init_part2_A_const_177 }







func A_arbace_cpp_sema__init_part2_A_Unit296__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3751, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_cpp_sema_var_node_A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_cpp_sema_var_node_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1505, false, nil); A_arbace_cpp_sema_var_node_A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_179)); return A_arbace_cpp_sema__init_part2_A_const_70 }





func A_arbace_cpp_sema__init_part2_A_Unit297__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3757, 1); A_arbace_cpp_sema__init_part2_A_const_180.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_180; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_181)); return A_arbace_cpp_sema__init_part2_A_const_180.SetDynamic_Z__Var(true).Ref() }





func A_arbace_cpp_sema__init_part2_A_Unit298__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3763, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_182; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_183)); return A_arbace_cpp_sema__init_part2_A_const_182 }

func A_arbace_cpp_sema__init_part2_A_Unit299__O() any { A_arbace_cpp_sema__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3765, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_cpp_sema_entity_expr_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_cpp_sema_entity_expr_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1506, false, nil); A_arbace_cpp_sema_entity_expr_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part2_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part2_A_const_185)); return A_arbace_cpp_sema__init_part2_A_const_184 }














































func A_arbace_cpp_sema__init_part3_A_Unit300__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3812, 1); A_arbace_cpp_sema__init_part3_A_const_0.BindRoot_O__V(A_arbace_cpp_sema__init_part3_A_const_1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_2)); return A_arbace_cpp_sema__init_part3_A_const_0 }
//line :3812:1
func A_arbace_cpp_sema__init_part3_A_Init__O() any { A_arbace_cpp_sema__init_part3_A_Init(); return nil }
//line :3812:1
func A_arbace_cpp_sema__init_part3_A_Load__O() any { A_arbace_cpp_sema__init_part3_A_Init(); A_arbace_cpp_sema__init_part3_A_Unit300__O(); A_arbace_cpp_sema__init_part3_A_Unit301__O(); A_arbace_cpp_sema__init_part3_A_Unit302__O(); A_arbace_cpp_sema__init_part3_A_Unit303__O(); A_arbace_cpp_sema__init_part3_A_Unit304__O(); A_arbace_cpp_sema__init_part3_A_Unit305__O(); A_arbace_cpp_sema__init_part3_A_Unit306__O(); A_arbace_cpp_sema__init_part3_A_Unit307__O(); A_arbace_cpp_sema__init_part3_A_Unit308__O(); A_arbace_cpp_sema__init_part3_A_Unit309__O(); A_arbace_cpp_sema__init_part3_A_Unit310__O(); A_arbace_cpp_sema__init_part3_A_Unit311__O(); A_arbace_cpp_sema__init_part3_A_Unit312__O(); A_arbace_cpp_sema__init_part3_A_Unit313__O(); A_arbace_cpp_sema__init_part3_A_Unit314__O(); A_arbace_cpp_sema__init_part3_A_Unit315__O(); A_arbace_cpp_sema__init_part3_A_Unit316__O(); A_arbace_cpp_sema__init_part3_A_Unit317__O(); A_arbace_cpp_sema__init_part3_A_Unit318__O(); A_arbace_cpp_sema__init_part3_A_Unit319__O(); A_arbace_cpp_sema__init_part3_A_Unit320__O(); A_arbace_cpp_sema__init_part3_A_Unit321__O(); A_arbace_cpp_sema__init_part3_A_Unit322__O(); A_arbace_cpp_sema__init_part3_A_Unit323__O(); A_arbace_cpp_sema__init_part3_A_Unit324__O(); A_arbace_cpp_sema__init_part3_A_Unit325__O(); A_arbace_cpp_sema__init_part3_A_Unit326__O(); A_arbace_cpp_sema__init_part3_A_Unit327__O(); A_arbace_cpp_sema__init_part3_A_Unit328__O(); A_arbace_cpp_sema__init_part3_A_Unit329__O(); A_arbace_cpp_sema__init_part3_A_Unit330__O(); A_arbace_cpp_sema__init_part3_A_Unit331__O(); A_arbace_cpp_sema__init_part3_A_Unit332__O(); A_arbace_cpp_sema__init_part3_A_Unit333__O(); A_arbace_cpp_sema__init_part3_A_Unit334__O(); A_arbace_cpp_sema__init_part3_A_Unit335__O(); A_arbace_cpp_sema__init_part3_A_Unit336__O(); A_arbace_cpp_sema__init_part3_A_Unit337__O(); A_arbace_cpp_sema__init_part3_A_Unit338__O(); A_arbace_cpp_sema__init_part3_A_Unit339__O(); A_arbace_cpp_sema__init_part3_A_Unit340__O(); A_arbace_cpp_sema__init_part3_A_Unit341__O(); A_arbace_cpp_sema__init_part3_A_Unit342__O(); A_arbace_cpp_sema__init_part3_A_Unit343__O(); A_arbace_cpp_sema__init_part3_A_Unit344__O(); A_arbace_cpp_sema__init_part3_A_Unit345__O(); A_arbace_cpp_sema__init_part3_A_Unit346__O(); A_arbace_cpp_sema__init_part3_A_Unit347__O(); A_arbace_cpp_sema__init_part3_A_Unit348__O(); A_arbace_cpp_sema__init_part3_A_Unit349__O(); A_arbace_cpp_sema__init_part3_A_Unit350__O(); A_arbace_cpp_sema__init_part3_A_Unit351__O(); A_arbace_cpp_sema__init_part3_A_Unit352__O(); A_arbace_cpp_sema__init_part3_A_Unit353__O(); A_arbace_cpp_sema__init_part3_A_Unit354__O(); A_arbace_cpp_sema__init_part3_A_Unit355__O(); A_arbace_cpp_sema__init_part3_A_Unit356__O(); A_arbace_cpp_sema__init_part3_A_Unit357__O(); A_arbace_cpp_sema__init_part3_A_Unit358__O(); A_arbace_cpp_sema__init_part3_A_Unit359__O(); A_arbace_cpp_sema__init_part3_A_Unit360__O(); A_arbace_cpp_sema__init_part3_A_Unit361__O(); A_arbace_cpp_sema__init_part3_A_Unit362__O(); A_arbace_cpp_sema__init_part3_A_Unit363__O(); A_arbace_cpp_sema__init_part3_A_Unit364__O(); A_arbace_cpp_sema__init_part3_A_Unit365__O(); A_arbace_cpp_sema__init_part3_A_Unit366__O(); A_arbace_cpp_sema__init_part3_A_Unit367__O(); A_arbace_cpp_sema__init_part3_A_Unit368__O(); A_arbace_cpp_sema__init_part3_A_Unit369__O(); A_arbace_cpp_sema__init_part3_A_Unit370__O(); A_arbace_cpp_sema__init_part3_A_Unit371__O(); A_arbace_cpp_sema__init_part3_A_Unit372__O(); A_arbace_cpp_sema__init_part3_A_Unit373__O(); A_arbace_cpp_sema__init_part3_A_Unit374__O(); A_arbace_cpp_sema__init_part3_A_Unit375__O(); A_arbace_cpp_sema__init_part3_A_Unit376__O(); A_arbace_cpp_sema__init_part3_A_Unit377__O(); A_arbace_cpp_sema__init_part3_A_Unit378__O(); A_arbace_cpp_sema__init_part3_A_Unit379__O(); A_arbace_cpp_sema__init_part3_A_Unit380__O(); A_arbace_cpp_sema__init_part3_A_Unit381__O(); A_arbace_cpp_sema__init_part3_A_Unit382__O(); A_arbace_cpp_sema__init_part3_A_Unit383__O(); A_arbace_cpp_sema__init_part3_A_Unit384__O(); A_arbace_cpp_sema__init_part3_A_Unit385__O(); A_arbace_cpp_sema__init_part3_A_Unit386__O(); A_arbace_cpp_sema__init_part3_A_Unit387__O(); A_arbace_cpp_sema__init_part3_A_Unit388__O(); A_arbace_cpp_sema__init_part3_A_Unit389__O(); A_arbace_cpp_sema__init_part3_A_Unit390__O(); A_arbace_cpp_sema__init_part3_A_Unit391__O(); A_arbace_cpp_sema__init_part3_A_Unit392__O(); A_arbace_cpp_sema__init_part3_A_Unit393__O(); A_arbace_cpp_sema__init_part3_A_Unit394__O(); A_arbace_cpp_sema__init_part3_A_Unit395__O(); A_arbace_cpp_sema__init_part3_A_Unit396__O(); A_arbace_cpp_sema__init_part3_A_Unit397__O(); A_arbace_cpp_sema__init_part3_A_Unit398__O(); A_arbace_cpp_sema__init_part3_A_Unit399__O(); return nil }







func A_arbace_cpp_sema__init_part3_A_Unit301__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3820, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_3; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_sema_implicit_alloc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_sema_implicit_alloc_BANG__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1508, false, nil); A_arbace_cpp_sema_implicit_alloc_BANG__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_3; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_4)); return A_arbace_cpp_sema__init_part3_A_const_3 }















func A_arbace_cpp_sema__init_part3_A_Unit302__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3836, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_5; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_sema_name_expr_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_sema_name_expr_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1509, false, nil); A_arbace_cpp_sema_name_expr_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_6)); return A_arbace_cpp_sema__init_part3_A_const_5 }



















func A_arbace_cpp_sema__init_part3_A_Unit303__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3856, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_sema_arith_binop_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_sema_arith_binop_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1510, false, nil); A_arbace_cpp_sema_arith_binop_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_8)); return A_arbace_cpp_sema__init_part3_A_const_7 }



func A_arbace_cpp_sema__init_part3_A_Unit304__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3860, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_sema_to_bool_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_sema_to_bool_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1511, false, nil); A_arbace_cpp_sema_to_bool_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_10)); return A_arbace_cpp_sema__init_part3_A_const_9 }




func A_arbace_cpp_sema__init_part3_A_Unit305__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3865, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_12)); return A_arbace_cpp_sema__init_part3_A_const_11 }
//line :3865:1
func A_arbace_cpp_sema__init_part3_A_Unit306__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3865, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_13; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_14)); return A_arbace_cpp_sema__init_part3_A_const_13 }
//line :3865:1
func A_arbace_cpp_sema__init_part3_A_Unit307__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3865, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_15; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_16)); return A_arbace_cpp_sema__init_part3_A_const_15 }
//line :3865:1
func A_arbace_cpp_sema__init_part3_A_Unit308__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3865, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_18)); return A_arbace_cpp_sema__init_part3_A_const_17 }

func A_arbace_cpp_sema__init_part3_A_Unit309__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3867, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_sema_class__GT_scalar_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_sema_class__GT_scalar_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1512, false, nil); A_arbace_cpp_sema_class__GT_scalar_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_20)); return A_arbace_cpp_sema__init_part3_A_const_19 }











func A_arbace_cpp_sema__init_part3_A_Unit310__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3879, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_sema_class_operand_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_sema_class_operand_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1513, false, nil); A_arbace_cpp_sema_class_operand_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_22)); return A_arbace_cpp_sema__init_part3_A_const_21 }

func A_arbace_cpp_sema__init_part3_A_Unit311__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3881, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_sema_ordering_type_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_sema_ordering_type_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1514, false, nil); A_arbace_cpp_sema_ordering_type_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_24)); return A_arbace_cpp_sema__init_part3_A_const_23 }





func A_arbace_cpp_sema__init_part3_A_Unit312__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3887, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_sema_three_way_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_sema_three_way_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1515, false, nil); A_arbace_cpp_sema_three_way_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_26)); return A_arbace_cpp_sema__init_part3_A_const_25 }












func A_arbace_cpp_sema__init_part3_A_Unit313__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3900, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_sema_builtin_binop_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_sema_builtin_binop_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1516, false, nil); A_arbace_cpp_sema_builtin_binop_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_28)); return A_arbace_cpp_sema__init_part3_A_const_27 }











































func A_arbace_cpp_sema__init_part3_A_Unit314__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3944, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_sema_assign_node_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_sema_assign_node_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1517, false, nil); A_arbace_cpp_sema_assign_node_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_30)); return A_arbace_cpp_sema__init_part3_A_const_29 }














func A_arbace_cpp_sema__init_part3_A_Unit315__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3959, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_sema_compound_node_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_sema_compound_node_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1518, false, nil); A_arbace_cpp_sema_compound_node_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_32)); return A_arbace_cpp_sema__init_part3_A_const_31 }






func A_arbace_cpp_sema__init_part3_A_Unit316__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3966, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_sema_cast_expr_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_sema_cast_expr_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1519, false, nil); A_arbace_cpp_sema_cast_expr_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_34)); return A_arbace_cpp_sema__init_part3_A_const_33 }













func A_arbace_cpp_sema__init_part3_A_Unit317__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3980, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_sema_scalar_list_cast_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_sema_scalar_list_cast_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1520, false, nil); A_arbace_cpp_sema_scalar_list_cast_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_36)); return A_arbace_cpp_sema__init_part3_A_const_35 }








func A_arbace_cpp_sema__init_part3_A_Unit318__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3989, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_sema_cx_using_map_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_sema_cx_using_map_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1521, false, nil); A_arbace_cpp_sema_cx_using_map_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_38)); return A_arbace_cpp_sema__init_part3_A_const_37 }




func A_arbace_cpp_sema__init_part3_A_Unit319__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3994, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_sema_method_set_of_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_sema_method_set_of_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1522, false, nil); A_arbace_cpp_sema_method_set_of_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_40)); return A_arbace_cpp_sema__init_part3_A_const_39 }





func A_arbace_cpp_sema__init_part3_A_Unit320__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4000, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_sema_cx_type_friend_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_sema_cx_type_friend_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1523, false, nil); A_arbace_cpp_sema_cx_type_friend_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_42)); return A_arbace_cpp_sema__init_part3_A_const_41 }







func A_arbace_cpp_sema__init_part3_A_Unit321__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4008, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_sema_check_type_access_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_sema_check_type_access_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1524, false, nil); A_arbace_cpp_sema_check_type_access_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_44)); return A_arbace_cpp_sema__init_part3_A_const_43 }



























func A_arbace_cpp_sema__init_part3_A_Unit322__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4036, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_sema_friend_may_grant_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_sema_friend_may_grant_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1525, false, nil); A_arbace_cpp_sema_friend_may_grant_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_46)); return A_arbace_cpp_sema__init_part3_A_const_45 }














func A_arbace_cpp_sema__init_part3_A_Unit323__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4051, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_sema_check_access_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_sema_check_access_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1526, false, nil); A_arbace_cpp_sema_check_access_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_48)); return A_arbace_cpp_sema__init_part3_A_const_47 }














func A_arbace_cpp_sema__init_part3_A_Unit324__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4066, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_sema_member_expr_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_sema_member_expr_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1527, false, nil); A_arbace_cpp_sema_member_expr_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_50)); return A_arbace_cpp_sema__init_part3_A_const_49 }
















































func A_arbace_cpp_sema__init_part3_A_Unit325__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4115, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_51; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_52)); return A_arbace_cpp_sema__init_part3_A_const_51 }
//line :4115:1
func A_arbace_cpp_sema__init_part3_A_Unit326__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4115, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_54)); return A_arbace_cpp_sema__init_part3_A_const_53 }

func A_arbace_cpp_sema__init_part3_A_Unit327__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4117, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_55; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_56)); return A_arbace_cpp_sema__init_part3_A_const_55 }

func A_arbace_cpp_sema__init_part3_A_Unit328__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4119, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_sema_deduced_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_sema_deduced_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1528, false, nil); A_arbace_cpp_sema_deduced_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_58)); return A_arbace_cpp_sema__init_part3_A_const_57 }














func A_arbace_cpp_sema__init_part3_A_Unit329__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4134, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_59; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_60)); return A_arbace_cpp_sema__init_part3_A_const_59 }

func A_arbace_cpp_sema__init_part3_A_Unit330__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4136, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_sema_method_call_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_sema_method_call_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1529, false, nil); A_arbace_cpp_sema_method_call_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_62)); return A_arbace_cpp_sema__init_part3_A_const_61 }








func A_arbace_cpp_sema__init_part3_A_Unit331__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4145, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_sema_cx_immediate_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_sema_cx_immediate_call_BANG__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1530, false, nil); A_arbace_cpp_sema_cx_immediate_call_BANG__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_63)); return A_arbace_cpp_sema__init_part3_A_const_59 }








func A_arbace_cpp_sema__init_part3_A_Unit332__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4154, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_sema_fn_call_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_sema_fn_call_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1531, false, nil); A_arbace_cpp_sema_fn_call_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_65)); return A_arbace_cpp_sema__init_part3_A_const_64 }





func A_arbace_cpp_sema__init_part3_A_Unit333__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4160, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_sema_adl_nss_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_sema_adl_nss_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1532, false, nil); A_arbace_cpp_sema_adl_nss_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_67)); return A_arbace_cpp_sema__init_part3_A_const_66 }










func A_arbace_cpp_sema__init_part3_A_Unit334__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4171, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_sema_enum_assoc_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_sema_enum_assoc_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1533, false, nil); A_arbace_cpp_sema_enum_assoc_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_69)); return A_arbace_cpp_sema__init_part3_A_const_68 }









func A_arbace_cpp_sema__init_part3_A_Unit335__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4181, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_sema_adl_class_nss_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_sema_adl_class_nss_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1534, false, nil); A_arbace_cpp_sema_adl_class_nss_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_71)); return A_arbace_cpp_sema__init_part3_A_const_70 }




























func A_arbace_cpp_sema__init_part3_A_Unit336__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4210, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_sema_adl_classes_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_sema_adl_classes_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1535, false, nil); A_arbace_cpp_sema_adl_classes_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_73)); return A_arbace_cpp_sema__init_part3_A_const_72 }





















func A_arbace_cpp_sema__init_part3_A_Unit337__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4232, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_sema_friend_visible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_sema_friend_visible_QMARK__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1536, false, nil); A_arbace_cpp_sema_friend_visible_QMARK__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_75)); return A_arbace_cpp_sema__init_part3_A_const_74 }









func A_arbace_cpp_sema__init_part3_A_Unit338__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4242, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_sema_adl_fns_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_sema_adl_fns_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1537, false, nil); A_arbace_cpp_sema_adl_fns_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_77)); return A_arbace_cpp_sema__init_part3_A_const_76 }
















func A_arbace_cpp_sema__init_part3_A_Unit339__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4259, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_sema_sure_assoc_nss_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_sema_sure_assoc_nss_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1538, false, nil); A_arbace_cpp_sema_sure_assoc_nss_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_79)); return A_arbace_cpp_sema__init_part3_A_const_78 }

























func A_arbace_cpp_sema__init_part3_A_Unit340__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4285, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_sema_declared_in_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_sema_declared_in_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1539, false, nil); A_arbace_cpp_sema_declared_in_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_81)); return A_arbace_cpp_sema__init_part3_A_const_80 }


func A_arbace_cpp_sema__init_part3_A_Unit341__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4288, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_sema_no_operator_BANG__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_sema_no_operator_BANG__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1540, false, nil); A_arbace_cpp_sema_no_operator_BANG__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_83)); return A_arbace_cpp_sema__init_part3_A_const_82 }



















func A_arbace_cpp_sema__init_part3_A_Unit342__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4308, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_sema_adl_not_found_BANG__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_sema_adl_not_found_BANG__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1541, false, nil); A_arbace_cpp_sema_adl_not_found_BANG__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_85)); return A_arbace_cpp_sema__init_part3_A_const_84 }














func A_arbace_cpp_sema__init_part3_A_Unit343__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4323, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_sema_undeclared_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_sema_undeclared_call_BANG__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1542, false, nil); A_arbace_cpp_sema_undeclared_call_BANG__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_87)); return A_arbace_cpp_sema__init_part3_A_const_86 }
















func A_arbace_cpp_sema__init_part3_A_Unit344__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4340, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_89)); return A_arbace_cpp_sema__init_part3_A_const_88 }






func A_arbace_cpp_sema__init_part3_A_Unit345__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4347, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_90; var tmp2 any; var root_71 any = A_arbace_cpp_sema__init_part3_A_const_91.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_73 lang.IFn; if


	linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_cpp_sema__init_part3_A_const_92; var arg_75 any; var root_76 any = A_arbace_cpp_sema__init_part3_A_const_93.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_78 lang.IFn; if







	linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_80 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_sema_fn__916001902_A_New(); var tmp4 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_sema_fn__916001902_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1543, false, nil); A_arbace_cpp_sema_fn__916001902_A_fn_class = fncls__81d; tmp4 = fncls__81d } else { tmp4 = fncls__81 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp4, nil); arg_80 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); if linked_77 == nil { arg_75 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { arg_75 = linked_77.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_76, arg_79, arg_80) }; if /*line :4350:1*/ linked_72 == nil { tmp2 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { tmp2 = linked_72.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }; /*line :4347:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_90; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_94)); return A_arbace_cpp_sema__init_part3_A_const_90 }














func A_arbace_cpp_sema__init_part3_A_Unit346__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4362, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_sema_atomic_builtin_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_sema_atomic_builtin_QMARK__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1544, false, nil); A_arbace_cpp_sema_atomic_builtin_QMARK__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_96)); return A_arbace_cpp_sema__init_part3_A_const_95 }

func A_arbace_cpp_sema__init_part3_A_Unit347__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4364, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_cpp_sema_atomic_expr_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_cpp_sema_atomic_expr_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1545, false, nil); A_arbace_cpp_sema_atomic_expr_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_98)); return A_arbace_cpp_sema__init_part3_A_const_97 }
































func A_arbace_cpp_sema__init_part3_A_Unit348__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4397, 1); A_arbace_cpp_sema__init_part3_A_const_99.BindRoot_O__V(A_arbace_cpp_sema__init_part3_A_const_100); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_99; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_101)); return A_arbace_cpp_sema__init_part3_A_const_99 }


















func A_arbace_cpp_sema__init_part3_A_Unit349__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4416, 1); A_arbace_cpp_sema__init_part3_A_const_102.BindRoot_O__V(A_arbace_cpp_sema__init_part3_A_const_103); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_104)); return A_arbace_cpp_sema__init_part3_A_const_102 }


func A_arbace_cpp_sema__init_part3_A_Unit350__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4419, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_105)); return A_arbace_cpp_sema__init_part3_A_const_33 }

func A_arbace_cpp_sema__init_part3_A_Unit351__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4421, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_cpp_sema_analyze_call_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_cpp_sema_analyze_call_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1546, false, nil); A_arbace_cpp_sema_analyze_call_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_106)); return A_arbace_cpp_sema__init_part3_A_const_13 }

















































func A_arbace_cpp_sema__init_part3_A_Unit352__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4471, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_sema_operator_call_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_sema_operator_call_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1547, false, nil); A_arbace_cpp_sema_operator_call_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_107)); return A_arbace_cpp_sema__init_part3_A_const_11 }















































func A_arbace_cpp_sema__init_part3_A_Unit353__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4519, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_sema_rewritten_relational_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_sema_rewritten_relational_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1548, false, nil); A_arbace_cpp_sema_rewritten_relational_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_108)); return A_arbace_cpp_sema__init_part3_A_const_17 }

















func A_arbace_cpp_sema__init_part3_A_Unit354__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4537, 1); A_arbace_cpp_sema__init_part3_A_const_109.BindRoot_O__V(A_arbace_cpp_sema__init_part3_A_const_110); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_109; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_111)); return A_arbace_cpp_sema__init_part3_A_const_109 }

func A_arbace_cpp_sema__init_part3_A_Unit355__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4539, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_sema_overaligned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_sema_overaligned_QMARK__A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1549, false, nil); A_arbace_cpp_sema_overaligned_QMARK__A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_113)); return A_arbace_cpp_sema__init_part3_A_const_112 }

func A_arbace_cpp_sema__init_part3_A_Unit356__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4541, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_cpp_sema_align_val_t_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_sema_align_val_t_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1550, false, nil); A_arbace_cpp_sema_align_val_t_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_115)); return A_arbace_cpp_sema__init_part3_A_const_114 }

func A_arbace_cpp_sema__init_part3_A_Unit357__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4543, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_sema_size_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_sema_size_t_QMARK__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1551, false, nil); A_arbace_cpp_sema_size_t_QMARK__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_117)); return A_arbace_cpp_sema__init_part3_A_const_116 }
func A_arbace_cpp_sema__init_part3_A_Unit358__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4544, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_cpp_sema_align_t_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_sema_align_t_QMARK__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1552, false, nil); A_arbace_cpp_sema_align_t_QMARK__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_119)); return A_arbace_cpp_sema__init_part3_A_const_118 }
func A_arbace_cpp_sema__init_part3_A_Unit359__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4545, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_cpp_sema_void_ptr_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_sema_void_ptr_QMARK__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1553, false, nil); A_arbace_cpp_sema_void_ptr_QMARK__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_121)); return A_arbace_cpp_sema__init_part3_A_const_120 }

func A_arbace_cpp_sema__init_part3_A_Unit360__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4547, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_cpp_sema_fn_ids_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_cpp_sema_fn_ids_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1554, false, nil); A_arbace_cpp_sema_fn_ids_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_123)); return A_arbace_cpp_sema__init_part3_A_const_122 }

func A_arbace_cpp_sema__init_part3_A_Unit361__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4549, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_cpp_sema_alloc_lookup_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_cpp_sema_alloc_lookup_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1555, false, nil); A_arbace_cpp_sema_alloc_lookup_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_125)); return A_arbace_cpp_sema__init_part3_A_const_124 }






func A_arbace_cpp_sema__init_part3_A_Unit362__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4556, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_cpp_sema_usual_dealloc_info_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_cpp_sema_usual_dealloc_info_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1556, false, nil); A_arbace_cpp_sema_usual_dealloc_info_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_127)); return A_arbace_cpp_sema__init_part3_A_const_126 }








func A_arbace_cpp_sema__init_part3_A_Unit363__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4565, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_cpp_sema_resolve_dealloc_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_cpp_sema_resolve_dealloc_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1557, false, nil); A_arbace_cpp_sema_resolve_dealloc_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_129)); return A_arbace_cpp_sema__init_part3_A_const_128 }









func A_arbace_cpp_sema__init_part3_A_Unit364__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4575, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_cpp_sema_implicit_dealloc_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_cpp_sema_implicit_dealloc_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1558, false, nil); A_arbace_cpp_sema_implicit_dealloc_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_131)); return A_arbace_cpp_sema__init_part3_A_const_130 }




func A_arbace_cpp_sema__init_part3_A_Unit365__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4580, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_132; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_cpp_sema_global_dealloc_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_cpp_sema_global_dealloc_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1559, false, nil); A_arbace_cpp_sema_global_dealloc_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_133)); return A_arbace_cpp_sema__init_part3_A_const_132 }






func A_arbace_cpp_sema__init_part3_A_Unit366__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4587, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_cpp_sema_dtor_dealloc_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_cpp_sema_dtor_dealloc_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1560, false, nil); A_arbace_cpp_sema_dtor_dealloc_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_135)); return A_arbace_cpp_sema__init_part3_A_const_134 }







func A_arbace_cpp_sema__init_part3_A_Unit367__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4595, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_cpp_sema_array_delete_wants_size_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_cpp_sema_array_delete_wants_size_QMARK__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1561, false, nil); A_arbace_cpp_sema_array_delete_wants_size_QMARK__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_137)); return A_arbace_cpp_sema__init_part3_A_const_136 }






func A_arbace_cpp_sema__init_part3_A_Unit368__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4602, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_cpp_sema_find_allocation_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_cpp_sema_find_allocation_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1562, false, nil); A_arbace_cpp_sema_find_allocation_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_139)); return A_arbace_cpp_sema__init_part3_A_const_138 }













































func A_arbace_cpp_sema__init_part3_A_Unit369__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4648, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_cpp_sema_delete_dealloc_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_cpp_sema_delete_dealloc_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1563, false, nil); A_arbace_cpp_sema_delete_dealloc_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_141)); return A_arbace_cpp_sema__init_part3_A_const_140 }











func A_arbace_cpp_sema__init_part3_A_Unit370__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4660, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_cpp_sema_new_expr_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_cpp_sema_new_expr_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1564, false, nil); A_arbace_cpp_sema_new_expr_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_143)); return A_arbace_cpp_sema__init_part3_A_const_142 }



































func A_arbace_cpp_sema__init_part3_A_Unit371__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4696, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_cpp_sema_dtor_of_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_cpp_sema_dtor_of_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1565, false, nil); A_arbace_cpp_sema_dtor_of_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_145)); return A_arbace_cpp_sema__init_part3_A_const_144 }

func A_arbace_cpp_sema__init_part3_A_Unit372__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4698, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_cpp_sema_analyze_args_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_cpp_sema_analyze_args_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1566, false, nil); A_arbace_cpp_sema_analyze_args_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_146)); return A_arbace_cpp_sema__init_part3_A_const_15 }













func A_arbace_cpp_sema__init_part3_A_Unit373__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4712, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_147; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_148)); return A_arbace_cpp_sema__init_part3_A_const_147 }
//line :4712:1
func A_arbace_cpp_sema__init_part3_A_Unit374__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4712, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_149; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_150)); return A_arbace_cpp_sema__init_part3_A_const_149 }
//line :4712:1
func A_arbace_cpp_sema__init_part3_A_Unit375__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4712, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_151; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_152)); return A_arbace_cpp_sema__init_part3_A_const_151 }
//line :4712:1
func A_arbace_cpp_sema__init_part3_A_Unit376__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4712, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_153; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_154)); return A_arbace_cpp_sema__init_part3_A_const_153 }
//line :4712:1
func A_arbace_cpp_sema__init_part3_A_Unit377__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4712, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_155; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_156)); return A_arbace_cpp_sema__init_part3_A_const_155 }

func A_arbace_cpp_sema__init_part3_A_Unit378__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4714, 1); A_arbace_cpp_sema__init_part3_A_const_157.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_157; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_158)); return A_arbace_cpp_sema__init_part3_A_const_157.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_sema__init_part3_A_Unit379__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4716, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_cpp_sema_split_top_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_cpp_sema_split_top_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1567, false, nil); A_arbace_cpp_sema_split_top_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_160)); return A_arbace_cpp_sema__init_part3_A_const_159 }












func A_arbace_cpp_sema__init_part3_A_Unit380__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4729, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_cpp_sema_capture_intro_A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_cpp_sema_capture_intro_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1568, false, nil); A_arbace_cpp_sema_capture_intro_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_162)); return A_arbace_cpp_sema__init_part3_A_const_161 }







func A_arbace_cpp_sema__init_part3_A_Unit381__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4737, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_cpp_sema_capture_field_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_cpp_sema_capture_field_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1569, false, nil); A_arbace_cpp_sema_capture_field_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_164)); return A_arbace_cpp_sema__init_part3_A_const_163 }






































func A_arbace_cpp_sema__init_part3_A_Unit382__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4776, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_cpp_sema_init_capture_BANG__A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_cpp_sema_init_capture_BANG__A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1570, false, nil); A_arbace_cpp_sema_init_capture_BANG__A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_166)); return A_arbace_cpp_sema__init_part3_A_const_165 }












func A_arbace_cpp_sema__init_part3_A_Unit383__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4789, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_167; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_168)); return A_arbace_cpp_sema__init_part3_A_const_167 }

func A_arbace_cpp_sema__init_part3_A_Unit384__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4791, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_cpp_sema_lambda_expr_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_cpp_sema_lambda_expr_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1571, false, nil); A_arbace_cpp_sema_lambda_expr_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_170)); return A_arbace_cpp_sema__init_part3_A_const_169 }
























































































func A_arbace_cpp_sema__init_part3_A_Unit385__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4880, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_cpp_sema_node_children_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_cpp_sema_node_children_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1572, false, nil); A_arbace_cpp_sema_node_children_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_172)); return A_arbace_cpp_sema__init_part3_A_const_171 }





func A_arbace_cpp_sema__init_part3_A_Unit386__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4886, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_cpp_sema_glam_names_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_cpp_sema_glam_names_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1573, false, nil); A_arbace_cpp_sema_glam_names_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_174)); return A_arbace_cpp_sema__init_part3_A_const_173 }




















func A_arbace_cpp_sema__init_part3_A_Unit387__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4907, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_cpp_sema_glam_declared_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_cpp_sema_glam_declared_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1574, false, nil); A_arbace_cpp_sema_glam_declared_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_176)); return A_arbace_cpp_sema__init_part3_A_const_175 }







func A_arbace_cpp_sema__init_part3_A_Unit388__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4915, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_cpp_sema_generic_lambda_expr_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_cpp_sema_generic_lambda_expr_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1575, false, nil); A_arbace_cpp_sema_generic_lambda_expr_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_177)); return A_arbace_cpp_sema__init_part3_A_const_167 }







































































































func A_arbace_cpp_sema__init_part3_A_Unit389__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5019, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_178; var tmp2 any; var root_147 any = A_arbace_cpp_sema__init_part3_A_const_179.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = A_arbace_cpp_sema__init_part3_A_const_180; if linked_148 == nil { tmp2 = ifn_149.Invoke_O__O(arg_150) } else { tmp2 = linked_148.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_147, arg_150) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_178; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_181)); return A_arbace_cpp_sema__init_part3_A_const_178 }

func A_arbace_cpp_sema__init_part3_A_Unit390__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5021, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_cpp_sema_cond_node_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_cpp_sema_cond_node_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1576, false, nil); A_arbace_cpp_sema_cond_node_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_183)); return A_arbace_cpp_sema__init_part3_A_const_182 }





























func A_arbace_cpp_sema__init_part3_A_Unit391__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5051, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_184; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_185)); return A_arbace_cpp_sema__init_part3_A_const_184 }

func A_arbace_cpp_sema__init_part3_A_Unit392__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5053, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_186; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_cpp_sema_ctad_expr_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_cpp_sema_ctad_expr_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1577, false, nil); A_arbace_cpp_sema_ctad_expr_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_187)); return A_arbace_cpp_sema__init_part3_A_const_186 }










func A_arbace_cpp_sema__init_part3_A_Unit393__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5064, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_188; var tmp2 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_cpp_sema_analyze_A_New(); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_cpp_sema_analyze_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1578, false, nil); A_arbace_cpp_sema_analyze_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_189)); return A_arbace_cpp_sema__init_part3_A_const_188 }






func A_arbace_cpp_sema__init_part3_A_Unit394__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5071, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__158 any = A_arbace_cpp_sema_analyze_node_A_New(); var tmp3 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_cpp_sema_analyze_node_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1579, false, nil); A_arbace_cpp_sema_analyze_node_A_fn_class = fncls__157d; tmp3 = fncls__157d } else { tmp3 = fncls__157 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__158, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_190)); return A_arbace_cpp_sema__init_part3_A_const_184 }







































































































































































































































































































































































































































































































func A_arbace_cpp_sema__init_part3_A_Unit395__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5559, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_191; var tmp2 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_cpp_sema_p2266_xvalue_A_New(); var tmp3 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_cpp_sema_p2266_xvalue_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1580, false, nil); A_arbace_cpp_sema_p2266_xvalue_A_fn_class = fncls__159d; tmp3 = fncls__159d } else { tmp3 = fncls__159 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_191; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_192)); return A_arbace_cpp_sema__init_part3_A_const_191 }




















func A_arbace_cpp_sema__init_part3_A_Unit396__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5580, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_147; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_193)); return A_arbace_cpp_sema__init_part3_A_const_147 }

func A_arbace_cpp_sema__init_part3_A_Unit397__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5582, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_15; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_194)); return A_arbace_cpp_sema__init_part3_A_const_15 }

func A_arbace_cpp_sema__init_part3_A_Unit398__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5584, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_195; var tmp2 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_cpp_sema_ctad_init_A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_cpp_sema_ctad_init_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1581, false, nil); A_arbace_cpp_sema_ctad_init_A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_195; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_196)); return A_arbace_cpp_sema__init_part3_A_const_195 }












func A_arbace_cpp_sema__init_part3_A_Unit399__O() any { A_arbace_cpp_sema__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5597, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_197; var tmp2 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_cpp_sema_ctad_var_A_New(); var tmp3 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_cpp_sema_ctad_var_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1582, false, nil); A_arbace_cpp_sema_ctad_var_A_fn_class = fncls__163d; tmp3 = fncls__163d } else { tmp3 = fncls__163 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part3_A_const_197; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part3_A_const_198)); return A_arbace_cpp_sema__init_part3_A_const_197 }




















func A_arbace_cpp_sema__init_part4_A_Unit400__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5618, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_sema_local_var_BANG__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_sema_local_var_BANG__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1584, false, nil); A_arbace_cpp_sema_local_var_BANG__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_1)); return A_arbace_cpp_sema__init_part4_A_const_0 }
//line :5618:1
func A_arbace_cpp_sema__init_part4_A_Init__O() any { A_arbace_cpp_sema__init_part4_A_Init(); return nil }
//line :5618:1
func A_arbace_cpp_sema__init_part4_A_Load__O() any { A_arbace_cpp_sema__init_part4_A_Init(); A_arbace_cpp_sema__init_part4_A_Unit400__O(); A_arbace_cpp_sema__init_part4_A_Unit401__O(); A_arbace_cpp_sema__init_part4_A_Unit402__O(); A_arbace_cpp_sema__init_part4_A_Unit403__O(); A_arbace_cpp_sema__init_part4_A_Unit404__O(); A_arbace_cpp_sema__init_part4_A_Unit405__O(); A_arbace_cpp_sema__init_part4_A_Unit406__O(); A_arbace_cpp_sema__init_part4_A_Unit407__O(); A_arbace_cpp_sema__init_part4_A_Unit408__O(); A_arbace_cpp_sema__init_part4_A_Unit409__O(); A_arbace_cpp_sema__init_part4_A_Unit410__O(); A_arbace_cpp_sema__init_part4_A_Unit411__O(); A_arbace_cpp_sema__init_part4_A_Unit412__O(); A_arbace_cpp_sema__init_part4_A_Unit413__O(); A_arbace_cpp_sema__init_part4_A_Unit414__O(); A_arbace_cpp_sema__init_part4_A_Unit415__O(); A_arbace_cpp_sema__init_part4_A_Unit416__O(); A_arbace_cpp_sema__init_part4_A_Unit417__O(); A_arbace_cpp_sema__init_part4_A_Unit418__O(); A_arbace_cpp_sema__init_part4_A_Unit419__O(); A_arbace_cpp_sema__init_part4_A_Unit420__O(); A_arbace_cpp_sema__init_part4_A_Unit421__O(); A_arbace_cpp_sema__init_part4_A_Unit422__O(); A_arbace_cpp_sema__init_part4_A_Unit423__O(); A_arbace_cpp_sema__init_part4_A_Unit424__O(); A_arbace_cpp_sema__init_part4_A_Unit425__O(); A_arbace_cpp_sema__init_part4_A_Unit426__O(); A_arbace_cpp_sema__init_part4_A_Unit427__O(); A_arbace_cpp_sema__init_part4_A_Unit428__O(); A_arbace_cpp_sema__init_part4_A_Unit429__O(); A_arbace_cpp_sema__init_part4_A_Unit430__O(); A_arbace_cpp_sema__init_part4_A_Unit431__O(); A_arbace_cpp_sema__init_part4_A_Unit432__O(); return nil }






















func A_arbace_cpp_sema__init_part4_A_Unit401__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5641, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_sema_has_auto_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_sema_has_auto_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1585, false, nil); A_arbace_cpp_sema_has_auto_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_3)); return A_arbace_cpp_sema__init_part4_A_const_2 }

func A_arbace_cpp_sema__init_part4_A_Unit402__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5643, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_sema_deduce_auto_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_sema_deduce_auto_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1586, false, nil); A_arbace_cpp_sema_deduce_auto_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_5)); return A_arbace_cpp_sema__init_part4_A_const_4 }










func A_arbace_cpp_sema__init_part4_A_Unit403__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5654, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_sema_decl_init_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_sema_decl_init_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1587, false, nil); A_arbace_cpp_sema_decl_init_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_7)); return A_arbace_cpp_sema__init_part4_A_const_6 }






































func A_arbace_cpp_sema__init_part4_A_Unit404__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5693, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_sema_decomposition_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_sema_decomposition_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1588, false, nil); A_arbace_cpp_sema_decomposition_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_9)); return A_arbace_cpp_sema__init_part4_A_const_8 }















































































func A_arbace_cpp_sema__init_part4_A_Unit405__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5773, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_11)); return A_arbace_cpp_sema__init_part4_A_const_10 }

func A_arbace_cpp_sema__init_part4_A_Unit406__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5775, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_sema_cx_decomposition_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_sema_cx_decomposition_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1589, false, nil); A_arbace_cpp_sema_cx_decomposition_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_13)); return A_arbace_cpp_sema__init_part4_A_const_12 }













































func A_arbace_cpp_sema__init_part4_A_Unit407__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5821, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_sema_decl_stmt_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_sema_decl_stmt_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1590, false, nil); A_arbace_cpp_sema_decl_stmt_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_15)); return A_arbace_cpp_sema__init_part4_A_const_14 }











































func A_arbace_cpp_sema__init_part4_A_Unit408__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5865, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_sema_block_ctx_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_sema_block_ctx_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1591, false, nil); A_arbace_cpp_sema_block_ctx_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_17)); return A_arbace_cpp_sema__init_part4_A_const_16 }

func A_arbace_cpp_sema__init_part4_A_Unit409__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5867, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_sema_full_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_sema_full_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1592, false, nil); A_arbace_cpp_sema_full_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_19)); return A_arbace_cpp_sema__init_part4_A_const_18 }

func A_arbace_cpp_sema__init_part4_A_Unit410__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5869, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_sema_cond_of_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_sema_cond_of_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1593, false, nil); A_arbace_cpp_sema_cond_of_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_21)); return A_arbace_cpp_sema__init_part4_A_const_20 }


func A_arbace_cpp_sema__init_part4_A_Unit411__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5872, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_22)); return A_arbace_cpp_sema__init_part4_A_const_0 }
//line :5872:1
func A_arbace_cpp_sema__init_part4_A_Unit412__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5872, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_24)); return A_arbace_cpp_sema__init_part4_A_const_23 }

func A_arbace_cpp_sema__init_part4_A_Unit413__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5874, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_sema_range_for_class_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_sema_range_for_class_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1594, false, nil); A_arbace_cpp_sema_range_for_class_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_26)); return A_arbace_cpp_sema__init_part4_A_const_25 }


































func A_arbace_cpp_sema__init_part4_A_Unit414__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5909, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_sema_constexpr_if_value_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_sema_constexpr_if_value_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1595, false, nil); A_arbace_cpp_sema_constexpr_if_value_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_28)); return A_arbace_cpp_sema__init_part4_A_const_27 }





















func A_arbace_cpp_sema__init_part4_A_Unit415__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5931, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_sema_stmt_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_sema_stmt_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1596, false, nil); A_arbace_cpp_sema_stmt_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_29)); return A_arbace_cpp_sema__init_part4_A_const_23 }



























































































































































































































func A_arbace_cpp_sema__init_part4_A_Unit416__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6151, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_sema_ctor_inits_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_sema_ctor_inits_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1597, false, nil); A_arbace_cpp_sema_ctor_inits_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_31)); return A_arbace_cpp_sema__init_part4_A_const_30 }

























































func A_arbace_cpp_sema__init_part4_A_Unit417__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6209, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_sema_nrvo_var_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_sema_nrvo_var_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1598, false, nil); A_arbace_cpp_sema_nrvo_var_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_33)); return A_arbace_cpp_sema__init_part4_A_const_32 }












func A_arbace_cpp_sema__init_part4_A_Unit418__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6222, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_sema_consteval_ctor_body_stores_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_sema_consteval_ctor_body_stores_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1599, false, nil); A_arbace_cpp_sema_consteval_ctor_body_stores_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_35)); return A_arbace_cpp_sema__init_part4_A_const_34 }


































func A_arbace_cpp_sema__init_part4_A_Unit419__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6257, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_sema_analyze_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_sema_analyze_fn_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1600, false, nil); A_arbace_cpp_sema_analyze_fn_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_37)); return A_arbace_cpp_sema__init_part4_A_const_36 }


























































func A_arbace_cpp_sema__init_part4_A_Unit420__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6316, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_sema_defaulted_comparison_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_sema_defaulted_comparison_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1601, false, nil); A_arbace_cpp_sema_defaulted_comparison_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_39)); return A_arbace_cpp_sema__init_part4_A_const_38 }













































func A_arbace_cpp_sema__init_part4_A_Unit421__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6362, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_sema_analyze_implicit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_sema_analyze_implicit_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1602, false, nil); A_arbace_cpp_sema_analyze_implicit_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_41)); return A_arbace_cpp_sema__init_part4_A_const_40 }

























































func A_arbace_cpp_sema__init_part4_A_Unit422__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6420, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_sema_immediate_address_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_sema_immediate_address_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1603, false, nil); A_arbace_cpp_sema_immediate_address_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_43)); return A_arbace_cpp_sema__init_part4_A_const_42 }








func A_arbace_cpp_sema__init_part4_A_Unit423__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6429, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_sema_returned_immediate_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_sema_returned_immediate_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1604, false, nil); A_arbace_cpp_sema_returned_immediate_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_45)); return A_arbace_cpp_sema__init_part4_A_const_44 }







func A_arbace_cpp_sema__init_part4_A_Unit424__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6437, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_sema_cx_check_constant_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_sema_cx_check_constant_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1605, false, nil); A_arbace_cpp_sema_cx_check_constant_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_47)); return A_arbace_cpp_sema__init_part4_A_const_46 }
























func A_arbace_cpp_sema__init_part4_A_Unit425__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6462, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_sema_sassert_unsure_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_sema_sassert_unsure_node_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1606, false, nil); A_arbace_cpp_sema_sassert_unsure_node_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_49)); return A_arbace_cpp_sema__init_part4_A_const_48 }






func A_arbace_cpp_sema__init_part4_A_Unit426__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6469, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_sema_check_static_assert_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_sema_check_static_assert_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1607, false, nil); A_arbace_cpp_sema_check_static_assert_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_50)); return A_arbace_cpp_sema__init_part4_A_const_10 }
















func A_arbace_cpp_sema__init_part4_A_Unit427__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6486, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_sema_cx_static_member_init_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_sema_cx_static_member_init_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1608, false, nil); A_arbace_cpp_sema_cx_static_member_init_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_52)); return A_arbace_cpp_sema__init_part4_A_const_51 }










func A_arbace_cpp_sema__init_part4_A_Unit428__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6497, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_sema_global_init_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_sema_global_init_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1609, false, nil); A_arbace_cpp_sema_global_init_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_54)); return A_arbace_cpp_sema__init_part4_A_const_53 }



















func A_arbace_cpp_sema__init_part4_A_Unit429__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6517, 1); A_arbace_cpp_sema__init_part4_A_const_55.BindRoot_O__V(Lit_1610); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_55; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_56)); return A_arbace_cpp_sema__init_part4_A_const_55 }


















func A_arbace_cpp_sema__init_part4_A_Unit430__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6536, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_sema_strip_positions_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_sema_strip_positions_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1611, false, nil); A_arbace_cpp_sema_strip_positions_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_58)); return A_arbace_cpp_sema__init_part4_A_const_57 }




func A_arbace_cpp_sema__init_part4_A_Unit431__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6541, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_sema_prelude_nodes_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_sema_prelude_nodes_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1612, false, nil); A_arbace_cpp_sema_prelude_nodes_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_60)); return A_arbace_cpp_sema__init_part4_A_const_59 }






func A_arbace_cpp_sema__init_part4_A_Unit432__O() any { A_arbace_cpp_sema__init_part4_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6548, 1); var tmp1 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_sema_analyze_program_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_sema_analyze_program_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1613, false, nil); A_arbace_cpp_sema_analyze_program_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_sema__init_part4_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_sema__init_part4_A_const_62)); return A_arbace_cpp_sema__init_part4_A_const_61 }



type A_arbace_cpp_sema__init_A struct{ jrt.Object }

func A_arbace_cpp_sema__init_A_New() *A_arbace_cpp_sema__init_A { t := &A_arbace_cpp_sema__init_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_sema__init_A) Ctor() {}

func (t *A_arbace_cpp_sema__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_sema__init_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_sema__init_A_class }

func (t *A_arbace_cpp_sema__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_sema__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_sema__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_sema__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_sema__init_A); return ok }

func A_arbace_cpp_sema__init_A_Cast(x any) *A_arbace_cpp_sema__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_sema__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_sema__init_A_class)) }; return v }



type A_arbace_cpp_sema__init_part0_A struct{ jrt.Object }

var A_arbace_cpp_sema__init_part0_A_const_pool *jrt.RefArray

var A_arbace_cpp_sema__init_part0_A_const_0 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_1 any

var A_arbace_cpp_sema__init_part0_A_const_2 any

var A_arbace_cpp_sema__init_part0_A_const_3 any

var A_arbace_cpp_sema__init_part0_A_const_4 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_5 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_6 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_7 any

var A_arbace_cpp_sema__init_part0_A_const_8 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_9 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_10 any

var A_arbace_cpp_sema__init_part0_A_const_11 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_12 any

var A_arbace_cpp_sema__init_part0_A_const_13 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_14 any

var A_arbace_cpp_sema__init_part0_A_const_15 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_16 any

var A_arbace_cpp_sema__init_part0_A_const_17 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_18 any

var A_arbace_cpp_sema__init_part0_A_const_19 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_20 any

var A_arbace_cpp_sema__init_part0_A_const_21 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_22 any

var A_arbace_cpp_sema__init_part0_A_const_23 any

var A_arbace_cpp_sema__init_part0_A_const_24 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_25 any

var A_arbace_cpp_sema__init_part0_A_const_26 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_27 any

var A_arbace_cpp_sema__init_part0_A_const_28 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_29 any

var A_arbace_cpp_sema__init_part0_A_const_30 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_31 any

var A_arbace_cpp_sema__init_part0_A_const_32 any

var A_arbace_cpp_sema__init_part0_A_const_33 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_34 any

var A_arbace_cpp_sema__init_part0_A_const_35 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_36 any

var A_arbace_cpp_sema__init_part0_A_const_37 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_38 any

var A_arbace_cpp_sema__init_part0_A_const_39 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_40 any

var A_arbace_cpp_sema__init_part0_A_const_41 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_42 any

var A_arbace_cpp_sema__init_part0_A_const_43 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_44 any

var A_arbace_cpp_sema__init_part0_A_const_45 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_46 any

var A_arbace_cpp_sema__init_part0_A_const_47 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_48 any

var A_arbace_cpp_sema__init_part0_A_const_49 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_50 any

var A_arbace_cpp_sema__init_part0_A_const_51 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_52 any

var A_arbace_cpp_sema__init_part0_A_const_53 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_54 any

var A_arbace_cpp_sema__init_part0_A_const_55 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_56 any

var A_arbace_cpp_sema__init_part0_A_const_57 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_58 any

var A_arbace_cpp_sema__init_part0_A_const_59 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_60 any

var A_arbace_cpp_sema__init_part0_A_const_61 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_62 any

var A_arbace_cpp_sema__init_part0_A_const_63 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_64 any

var A_arbace_cpp_sema__init_part0_A_const_65 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_66 any

var A_arbace_cpp_sema__init_part0_A_const_67 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_68 any

var A_arbace_cpp_sema__init_part0_A_const_69 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_70 any

var A_arbace_cpp_sema__init_part0_A_const_71 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_72 any

var A_arbace_cpp_sema__init_part0_A_const_73 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_74 any

var A_arbace_cpp_sema__init_part0_A_const_75 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_76 any

var A_arbace_cpp_sema__init_part0_A_const_77 any

var A_arbace_cpp_sema__init_part0_A_const_78 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_79 any

var A_arbace_cpp_sema__init_part0_A_const_80 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_81 any

var A_arbace_cpp_sema__init_part0_A_const_82 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_83 any

var A_arbace_cpp_sema__init_part0_A_const_84 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_85 any

var A_arbace_cpp_sema__init_part0_A_const_86 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_87 any

var A_arbace_cpp_sema__init_part0_A_const_88 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_89 any

var A_arbace_cpp_sema__init_part0_A_const_90 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_91 any

var A_arbace_cpp_sema__init_part0_A_const_92 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_93 any

var A_arbace_cpp_sema__init_part0_A_const_94 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_95 any

var A_arbace_cpp_sema__init_part0_A_const_96 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_97 any

var A_arbace_cpp_sema__init_part0_A_const_98 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_99 any

var A_arbace_cpp_sema__init_part0_A_const_100 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_101 any

var A_arbace_cpp_sema__init_part0_A_const_102 any

var A_arbace_cpp_sema__init_part0_A_const_103 any

var A_arbace_cpp_sema__init_part0_A_const_104 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_105 any

var A_arbace_cpp_sema__init_part0_A_const_106 any

var A_arbace_cpp_sema__init_part0_A_const_107 any

var A_arbace_cpp_sema__init_part0_A_const_108 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_109 any

var A_arbace_cpp_sema__init_part0_A_const_110 any

var A_arbace_cpp_sema__init_part0_A_const_111 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_112 any

var A_arbace_cpp_sema__init_part0_A_const_113 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_114 any

var A_arbace_cpp_sema__init_part0_A_const_115 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_116 any

var A_arbace_cpp_sema__init_part0_A_const_117 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_118 any

var A_arbace_cpp_sema__init_part0_A_const_119 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_120 any

var A_arbace_cpp_sema__init_part0_A_const_121 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_122 any

var A_arbace_cpp_sema__init_part0_A_const_123 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_124 any

var A_arbace_cpp_sema__init_part0_A_const_125 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_126 any

var A_arbace_cpp_sema__init_part0_A_const_127 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_128 any

var A_arbace_cpp_sema__init_part0_A_const_129 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_130 any

var A_arbace_cpp_sema__init_part0_A_const_131 any

var A_arbace_cpp_sema__init_part0_A_const_132 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_133 any

var A_arbace_cpp_sema__init_part0_A_const_134 any

var A_arbace_cpp_sema__init_part0_A_const_135 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_136 any

var A_arbace_cpp_sema__init_part0_A_const_137 any

var A_arbace_cpp_sema__init_part0_A_const_138 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_139 any

var A_arbace_cpp_sema__init_part0_A_const_140 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_141 any

var A_arbace_cpp_sema__init_part0_A_const_142 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_143 any

var A_arbace_cpp_sema__init_part0_A_const_144 any

var A_arbace_cpp_sema__init_part0_A_const_145 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_146 any

var A_arbace_cpp_sema__init_part0_A_const_147 any

var A_arbace_cpp_sema__init_part0_A_const_148 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_149 any

var A_arbace_cpp_sema__init_part0_A_const_150 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_151 any

var A_arbace_cpp_sema__init_part0_A_const_152 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_153 any

var A_arbace_cpp_sema__init_part0_A_const_154 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_155 any

var A_arbace_cpp_sema__init_part0_A_const_156 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_157 any

var A_arbace_cpp_sema__init_part0_A_const_158 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_159 any

var A_arbace_cpp_sema__init_part0_A_const_160 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_161 any

var A_arbace_cpp_sema__init_part0_A_const_162 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_163 any

var A_arbace_cpp_sema__init_part0_A_const_164 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_165 any

var A_arbace_cpp_sema__init_part0_A_const_166 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_167 any

var A_arbace_cpp_sema__init_part0_A_const_168 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_169 any

var A_arbace_cpp_sema__init_part0_A_const_170 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_171 any

var A_arbace_cpp_sema__init_part0_A_const_172 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_173 any

var A_arbace_cpp_sema__init_part0_A_const_174 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_175 any

var A_arbace_cpp_sema__init_part0_A_const_176 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_177 any

var A_arbace_cpp_sema__init_part0_A_const_178 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_179 any

var A_arbace_cpp_sema__init_part0_A_const_180 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_181 any

var A_arbace_cpp_sema__init_part0_A_const_182 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_183 any

var A_arbace_cpp_sema__init_part0_A_const_184 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_185 any

var A_arbace_cpp_sema__init_part0_A_const_186 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_187 any

var A_arbace_cpp_sema__init_part0_A_const_188 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_189 any

var A_arbace_cpp_sema__init_part0_A_const_190 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_191 any

var A_arbace_cpp_sema__init_part0_A_const_192 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_193 any

var A_arbace_cpp_sema__init_part0_A_const_194 any

var A_arbace_cpp_sema__init_part0_A_const_195 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_196 any

var A_arbace_cpp_sema__init_part0_A_const_197 *lang.Var

var A_arbace_cpp_sema__init_part0_A_const_198 any

var A_arbace_cpp_sema__init_part0_A_init jrt.ClassInit

func A_arbace_cpp_sema__init_part0_A_Init() { if !A_arbace_cpp_sema__init_part0_A_init.Done() { A_arbace_cpp_sema__init_part0_A_init.Run(A_arbace_cpp_sema__init_part0_A_clinit) } }

func A_arbace_cpp_sema__init_part0_A_clinit() { A_arbace_cpp_sema__init_part0_A_clinit_p0(); A_arbace_cpp_sema__init_part0_A_clinit_p1(); A_arbace_cpp_sema__init_part0_A_clinit_p2(); A_arbace_cpp_sema__init_part0_A_clinit_p3(); A_arbace_cpp_sema__init_part0_A_clinit_p4(); A_arbace_cpp_sema__init_part0_A_clinit_p5(); A_arbace_cpp_sema__init_part0_A_clinit_p6(); A_arbace_cpp_sema__init_part0_A_clinit_p7(); A_arbace_cpp_sema__init_part0_A_clinit_p8(); A_arbace_cpp_sema__init_part0_A_clinit_p9(); A_arbace_cpp_sema__init_part0_A_clinit_p10(); A_arbace_cpp_sema__init_part0_A_clinit_p11(); A_arbace_cpp_sema__init_part0_A_clinit_p12(); A_arbace_cpp_sema__init_part0_A_clinit_p13(); A_arbace_cpp_sema__init_part0_A_clinit_p14() }

func A_arbace_cpp_sema__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_sema__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1311, 291); A_arbace_cpp_sema__init_part0_A_const_0 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[92]); A_arbace_cpp_sema__init_part0_A_const_1 = A_arbace_cpp_sema__init_part0_A_const_pool.A[93]; A_arbace_cpp_sema__init_part0_A_const_2 = A_arbace_cpp_sema__init_part0_A_const_pool.A[94]; A_arbace_cpp_sema__init_part0_A_const_3 = A_arbace_cpp_sema__init_part0_A_const_pool.A[95]; A_arbace_cpp_sema__init_part0_A_const_4 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[96]); A_arbace_cpp_sema__init_part0_A_const_5 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[97]); A_arbace_cpp_sema__init_part0_A_const_6 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[98]); A_arbace_cpp_sema__init_part0_A_const_7 = A_arbace_cpp_sema__init_part0_A_const_pool.A[99]; A_arbace_cpp_sema__init_part0_A_const_8 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[100]); A_arbace_cpp_sema__init_part0_A_const_9 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[101]); A_arbace_cpp_sema__init_part0_A_const_10 = A_arbace_cpp_sema__init_part0_A_const_pool.A[102]; A_arbace_cpp_sema__init_part0_A_const_11 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[103]) }

func A_arbace_cpp_sema__init_part0_A_clinit_p1() { A_arbace_cpp_sema__init_part0_A_const_12 = A_arbace_cpp_sema__init_part0_A_const_pool.A[104]; A_arbace_cpp_sema__init_part0_A_const_13 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[105]); A_arbace_cpp_sema__init_part0_A_const_14 = A_arbace_cpp_sema__init_part0_A_const_pool.A[106]; A_arbace_cpp_sema__init_part0_A_const_15 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[107]); A_arbace_cpp_sema__init_part0_A_const_16 = A_arbace_cpp_sema__init_part0_A_const_pool.A[108]; A_arbace_cpp_sema__init_part0_A_const_17 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[109]); A_arbace_cpp_sema__init_part0_A_const_18 = A_arbace_cpp_sema__init_part0_A_const_pool.A[110]; A_arbace_cpp_sema__init_part0_A_const_19 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[111]); A_arbace_cpp_sema__init_part0_A_const_20 = A_arbace_cpp_sema__init_part0_A_const_pool.A[112]; A_arbace_cpp_sema__init_part0_A_const_21 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[113]); A_arbace_cpp_sema__init_part0_A_const_22 = A_arbace_cpp_sema__init_part0_A_const_pool.A[114]; A_arbace_cpp_sema__init_part0_A_const_23 = A_arbace_cpp_sema__init_part0_A_const_pool.A[115]; A_arbace_cpp_sema__init_part0_A_const_24 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[116]); A_arbace_cpp_sema__init_part0_A_const_25 = A_arbace_cpp_sema__init_part0_A_const_pool.A[117] }

func A_arbace_cpp_sema__init_part0_A_clinit_p2() { A_arbace_cpp_sema__init_part0_A_const_26 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[118]); A_arbace_cpp_sema__init_part0_A_const_27 = A_arbace_cpp_sema__init_part0_A_const_pool.A[119]; A_arbace_cpp_sema__init_part0_A_const_28 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[120]); A_arbace_cpp_sema__init_part0_A_const_29 = A_arbace_cpp_sema__init_part0_A_const_pool.A[121]; A_arbace_cpp_sema__init_part0_A_const_30 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[122]); A_arbace_cpp_sema__init_part0_A_const_31 = A_arbace_cpp_sema__init_part0_A_const_pool.A[123]; A_arbace_cpp_sema__init_part0_A_const_32 = A_arbace_cpp_sema__init_part0_A_const_pool.A[124]; A_arbace_cpp_sema__init_part0_A_const_33 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[125]); A_arbace_cpp_sema__init_part0_A_const_34 = A_arbace_cpp_sema__init_part0_A_const_pool.A[126]; A_arbace_cpp_sema__init_part0_A_const_35 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[127]); A_arbace_cpp_sema__init_part0_A_const_36 = A_arbace_cpp_sema__init_part0_A_const_pool.A[128]; A_arbace_cpp_sema__init_part0_A_const_37 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[129]); A_arbace_cpp_sema__init_part0_A_const_38 = A_arbace_cpp_sema__init_part0_A_const_pool.A[130] }

func A_arbace_cpp_sema__init_part0_A_clinit_p3() { A_arbace_cpp_sema__init_part0_A_const_39 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[131]); A_arbace_cpp_sema__init_part0_A_const_40 = A_arbace_cpp_sema__init_part0_A_const_pool.A[132]; A_arbace_cpp_sema__init_part0_A_const_41 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[133]); A_arbace_cpp_sema__init_part0_A_const_42 = A_arbace_cpp_sema__init_part0_A_const_pool.A[134]; A_arbace_cpp_sema__init_part0_A_const_43 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[135]); A_arbace_cpp_sema__init_part0_A_const_44 = A_arbace_cpp_sema__init_part0_A_const_pool.A[136]; A_arbace_cpp_sema__init_part0_A_const_45 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[137]); A_arbace_cpp_sema__init_part0_A_const_46 = A_arbace_cpp_sema__init_part0_A_const_pool.A[138]; A_arbace_cpp_sema__init_part0_A_const_47 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[139]); A_arbace_cpp_sema__init_part0_A_const_48 = A_arbace_cpp_sema__init_part0_A_const_pool.A[140]; A_arbace_cpp_sema__init_part0_A_const_49 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[141]); A_arbace_cpp_sema__init_part0_A_const_50 = A_arbace_cpp_sema__init_part0_A_const_pool.A[142]; A_arbace_cpp_sema__init_part0_A_const_51 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[143]) }

func A_arbace_cpp_sema__init_part0_A_clinit_p4() { A_arbace_cpp_sema__init_part0_A_const_52 = A_arbace_cpp_sema__init_part0_A_const_pool.A[144]; A_arbace_cpp_sema__init_part0_A_const_53 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[145]); A_arbace_cpp_sema__init_part0_A_const_54 = A_arbace_cpp_sema__init_part0_A_const_pool.A[146]; A_arbace_cpp_sema__init_part0_A_const_55 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[147]); A_arbace_cpp_sema__init_part0_A_const_56 = A_arbace_cpp_sema__init_part0_A_const_pool.A[148]; A_arbace_cpp_sema__init_part0_A_const_57 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[149]); A_arbace_cpp_sema__init_part0_A_const_58 = A_arbace_cpp_sema__init_part0_A_const_pool.A[150]; A_arbace_cpp_sema__init_part0_A_const_59 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[151]); A_arbace_cpp_sema__init_part0_A_const_60 = A_arbace_cpp_sema__init_part0_A_const_pool.A[152]; A_arbace_cpp_sema__init_part0_A_const_61 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[153]); A_arbace_cpp_sema__init_part0_A_const_62 = A_arbace_cpp_sema__init_part0_A_const_pool.A[154]; A_arbace_cpp_sema__init_part0_A_const_63 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[155]); A_arbace_cpp_sema__init_part0_A_const_64 = A_arbace_cpp_sema__init_part0_A_const_pool.A[156] }

func A_arbace_cpp_sema__init_part0_A_clinit_p5() { A_arbace_cpp_sema__init_part0_A_const_65 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[157]); A_arbace_cpp_sema__init_part0_A_const_66 = A_arbace_cpp_sema__init_part0_A_const_pool.A[158]; A_arbace_cpp_sema__init_part0_A_const_67 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[159]); A_arbace_cpp_sema__init_part0_A_const_68 = A_arbace_cpp_sema__init_part0_A_const_pool.A[160]; A_arbace_cpp_sema__init_part0_A_const_69 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[161]); A_arbace_cpp_sema__init_part0_A_const_70 = A_arbace_cpp_sema__init_part0_A_const_pool.A[162]; A_arbace_cpp_sema__init_part0_A_const_71 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[163]); A_arbace_cpp_sema__init_part0_A_const_72 = A_arbace_cpp_sema__init_part0_A_const_pool.A[164]; A_arbace_cpp_sema__init_part0_A_const_73 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[165]); A_arbace_cpp_sema__init_part0_A_const_74 = A_arbace_cpp_sema__init_part0_A_const_pool.A[166]; A_arbace_cpp_sema__init_part0_A_const_75 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[167]); A_arbace_cpp_sema__init_part0_A_const_76 = A_arbace_cpp_sema__init_part0_A_const_pool.A[168]; A_arbace_cpp_sema__init_part0_A_const_77 = A_arbace_cpp_sema__init_part0_A_const_pool.A[169] }

func A_arbace_cpp_sema__init_part0_A_clinit_p6() { A_arbace_cpp_sema__init_part0_A_const_78 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[170]); A_arbace_cpp_sema__init_part0_A_const_79 = A_arbace_cpp_sema__init_part0_A_const_pool.A[171]; A_arbace_cpp_sema__init_part0_A_const_80 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[172]); A_arbace_cpp_sema__init_part0_A_const_81 = A_arbace_cpp_sema__init_part0_A_const_pool.A[173]; A_arbace_cpp_sema__init_part0_A_const_82 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[174]); A_arbace_cpp_sema__init_part0_A_const_83 = A_arbace_cpp_sema__init_part0_A_const_pool.A[175]; A_arbace_cpp_sema__init_part0_A_const_84 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[176]); A_arbace_cpp_sema__init_part0_A_const_85 = A_arbace_cpp_sema__init_part0_A_const_pool.A[177]; A_arbace_cpp_sema__init_part0_A_const_86 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[178]); A_arbace_cpp_sema__init_part0_A_const_87 = A_arbace_cpp_sema__init_part0_A_const_pool.A[179]; A_arbace_cpp_sema__init_part0_A_const_88 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[180]); A_arbace_cpp_sema__init_part0_A_const_89 = A_arbace_cpp_sema__init_part0_A_const_pool.A[181]; A_arbace_cpp_sema__init_part0_A_const_90 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[182]) }

func A_arbace_cpp_sema__init_part0_A_clinit_p7() { A_arbace_cpp_sema__init_part0_A_const_91 = A_arbace_cpp_sema__init_part0_A_const_pool.A[183]; A_arbace_cpp_sema__init_part0_A_const_92 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[184]); A_arbace_cpp_sema__init_part0_A_const_93 = A_arbace_cpp_sema__init_part0_A_const_pool.A[185]; A_arbace_cpp_sema__init_part0_A_const_94 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[186]); A_arbace_cpp_sema__init_part0_A_const_95 = A_arbace_cpp_sema__init_part0_A_const_pool.A[187]; A_arbace_cpp_sema__init_part0_A_const_96 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[188]); A_arbace_cpp_sema__init_part0_A_const_97 = A_arbace_cpp_sema__init_part0_A_const_pool.A[189]; A_arbace_cpp_sema__init_part0_A_const_98 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[190]); A_arbace_cpp_sema__init_part0_A_const_99 = A_arbace_cpp_sema__init_part0_A_const_pool.A[191]; A_arbace_cpp_sema__init_part0_A_const_100 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[192]); A_arbace_cpp_sema__init_part0_A_const_101 = A_arbace_cpp_sema__init_part0_A_const_pool.A[193]; A_arbace_cpp_sema__init_part0_A_const_102 = A_arbace_cpp_sema__init_part0_A_const_pool.A[194]; A_arbace_cpp_sema__init_part0_A_const_103 = A_arbace_cpp_sema__init_part0_A_const_pool.A[195]; A_arbace_cpp_sema__init_part0_A_const_104 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[196]) }

func A_arbace_cpp_sema__init_part0_A_clinit_p8() { A_arbace_cpp_sema__init_part0_A_const_105 = A_arbace_cpp_sema__init_part0_A_const_pool.A[197]; A_arbace_cpp_sema__init_part0_A_const_106 = A_arbace_cpp_sema__init_part0_A_const_pool.A[198]; A_arbace_cpp_sema__init_part0_A_const_107 = A_arbace_cpp_sema__init_part0_A_const_pool.A[199]; A_arbace_cpp_sema__init_part0_A_const_108 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[200]); A_arbace_cpp_sema__init_part0_A_const_109 = A_arbace_cpp_sema__init_part0_A_const_pool.A[201]; A_arbace_cpp_sema__init_part0_A_const_110 = A_arbace_cpp_sema__init_part0_A_const_pool.A[202]; A_arbace_cpp_sema__init_part0_A_const_111 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[203]); A_arbace_cpp_sema__init_part0_A_const_112 = A_arbace_cpp_sema__init_part0_A_const_pool.A[204]; A_arbace_cpp_sema__init_part0_A_const_113 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[205]); A_arbace_cpp_sema__init_part0_A_const_114 = A_arbace_cpp_sema__init_part0_A_const_pool.A[206]; A_arbace_cpp_sema__init_part0_A_const_115 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[207]); A_arbace_cpp_sema__init_part0_A_const_116 = A_arbace_cpp_sema__init_part0_A_const_pool.A[208]; A_arbace_cpp_sema__init_part0_A_const_117 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[209]); A_arbace_cpp_sema__init_part0_A_const_118 = A_arbace_cpp_sema__init_part0_A_const_pool.A[210] }

func A_arbace_cpp_sema__init_part0_A_clinit_p9() { A_arbace_cpp_sema__init_part0_A_const_119 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[211]); A_arbace_cpp_sema__init_part0_A_const_120 = A_arbace_cpp_sema__init_part0_A_const_pool.A[212]; A_arbace_cpp_sema__init_part0_A_const_121 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[213]); A_arbace_cpp_sema__init_part0_A_const_122 = A_arbace_cpp_sema__init_part0_A_const_pool.A[214]; A_arbace_cpp_sema__init_part0_A_const_123 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[215]); A_arbace_cpp_sema__init_part0_A_const_124 = A_arbace_cpp_sema__init_part0_A_const_pool.A[216]; A_arbace_cpp_sema__init_part0_A_const_125 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[217]); A_arbace_cpp_sema__init_part0_A_const_126 = A_arbace_cpp_sema__init_part0_A_const_pool.A[218]; A_arbace_cpp_sema__init_part0_A_const_127 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[219]); A_arbace_cpp_sema__init_part0_A_const_128 = A_arbace_cpp_sema__init_part0_A_const_pool.A[220]; A_arbace_cpp_sema__init_part0_A_const_129 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[221]); A_arbace_cpp_sema__init_part0_A_const_130 = A_arbace_cpp_sema__init_part0_A_const_pool.A[222]; A_arbace_cpp_sema__init_part0_A_const_131 = A_arbace_cpp_sema__init_part0_A_const_pool.A[223] }

func A_arbace_cpp_sema__init_part0_A_clinit_p10() { A_arbace_cpp_sema__init_part0_A_const_132 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[224]); A_arbace_cpp_sema__init_part0_A_const_133 = A_arbace_cpp_sema__init_part0_A_const_pool.A[225]; A_arbace_cpp_sema__init_part0_A_const_134 = A_arbace_cpp_sema__init_part0_A_const_pool.A[226]; A_arbace_cpp_sema__init_part0_A_const_135 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[227]); A_arbace_cpp_sema__init_part0_A_const_136 = A_arbace_cpp_sema__init_part0_A_const_pool.A[228]; A_arbace_cpp_sema__init_part0_A_const_137 = A_arbace_cpp_sema__init_part0_A_const_pool.A[229]; A_arbace_cpp_sema__init_part0_A_const_138 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[230]); A_arbace_cpp_sema__init_part0_A_const_139 = A_arbace_cpp_sema__init_part0_A_const_pool.A[231]; A_arbace_cpp_sema__init_part0_A_const_140 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[232]); A_arbace_cpp_sema__init_part0_A_const_141 = A_arbace_cpp_sema__init_part0_A_const_pool.A[233]; A_arbace_cpp_sema__init_part0_A_const_142 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[234]); A_arbace_cpp_sema__init_part0_A_const_143 = A_arbace_cpp_sema__init_part0_A_const_pool.A[235]; A_arbace_cpp_sema__init_part0_A_const_144 = A_arbace_cpp_sema__init_part0_A_const_pool.A[236]; A_arbace_cpp_sema__init_part0_A_const_145 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[237]) }

func A_arbace_cpp_sema__init_part0_A_clinit_p11() { A_arbace_cpp_sema__init_part0_A_const_146 = A_arbace_cpp_sema__init_part0_A_const_pool.A[238]; A_arbace_cpp_sema__init_part0_A_const_147 = A_arbace_cpp_sema__init_part0_A_const_pool.A[239]; A_arbace_cpp_sema__init_part0_A_const_148 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[240]); A_arbace_cpp_sema__init_part0_A_const_149 = A_arbace_cpp_sema__init_part0_A_const_pool.A[241]; A_arbace_cpp_sema__init_part0_A_const_150 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[242]); A_arbace_cpp_sema__init_part0_A_const_151 = A_arbace_cpp_sema__init_part0_A_const_pool.A[243]; A_arbace_cpp_sema__init_part0_A_const_152 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[244]); A_arbace_cpp_sema__init_part0_A_const_153 = A_arbace_cpp_sema__init_part0_A_const_pool.A[245]; A_arbace_cpp_sema__init_part0_A_const_154 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[246]); A_arbace_cpp_sema__init_part0_A_const_155 = A_arbace_cpp_sema__init_part0_A_const_pool.A[247]; A_arbace_cpp_sema__init_part0_A_const_156 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[248]); A_arbace_cpp_sema__init_part0_A_const_157 = A_arbace_cpp_sema__init_part0_A_const_pool.A[249]; A_arbace_cpp_sema__init_part0_A_const_158 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[250]); A_arbace_cpp_sema__init_part0_A_const_159 = A_arbace_cpp_sema__init_part0_A_const_pool.A[251] }

func A_arbace_cpp_sema__init_part0_A_clinit_p12() { A_arbace_cpp_sema__init_part0_A_const_160 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[252]); A_arbace_cpp_sema__init_part0_A_const_161 = A_arbace_cpp_sema__init_part0_A_const_pool.A[253]; A_arbace_cpp_sema__init_part0_A_const_162 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[254]); A_arbace_cpp_sema__init_part0_A_const_163 = A_arbace_cpp_sema__init_part0_A_const_pool.A[255]; A_arbace_cpp_sema__init_part0_A_const_164 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[256]); A_arbace_cpp_sema__init_part0_A_const_165 = A_arbace_cpp_sema__init_part0_A_const_pool.A[257]; A_arbace_cpp_sema__init_part0_A_const_166 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[258]); A_arbace_cpp_sema__init_part0_A_const_167 = A_arbace_cpp_sema__init_part0_A_const_pool.A[259]; A_arbace_cpp_sema__init_part0_A_const_168 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[260]); A_arbace_cpp_sema__init_part0_A_const_169 = A_arbace_cpp_sema__init_part0_A_const_pool.A[261]; A_arbace_cpp_sema__init_part0_A_const_170 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[262]); A_arbace_cpp_sema__init_part0_A_const_171 = A_arbace_cpp_sema__init_part0_A_const_pool.A[263]; A_arbace_cpp_sema__init_part0_A_const_172 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[264]) }

func A_arbace_cpp_sema__init_part0_A_clinit_p13() { A_arbace_cpp_sema__init_part0_A_const_173 = A_arbace_cpp_sema__init_part0_A_const_pool.A[265]; A_arbace_cpp_sema__init_part0_A_const_174 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[266]); A_arbace_cpp_sema__init_part0_A_const_175 = A_arbace_cpp_sema__init_part0_A_const_pool.A[267]; A_arbace_cpp_sema__init_part0_A_const_176 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[268]); A_arbace_cpp_sema__init_part0_A_const_177 = A_arbace_cpp_sema__init_part0_A_const_pool.A[269]; A_arbace_cpp_sema__init_part0_A_const_178 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[270]); A_arbace_cpp_sema__init_part0_A_const_179 = A_arbace_cpp_sema__init_part0_A_const_pool.A[271]; A_arbace_cpp_sema__init_part0_A_const_180 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[272]); A_arbace_cpp_sema__init_part0_A_const_181 = A_arbace_cpp_sema__init_part0_A_const_pool.A[273]; A_arbace_cpp_sema__init_part0_A_const_182 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[274]); A_arbace_cpp_sema__init_part0_A_const_183 = A_arbace_cpp_sema__init_part0_A_const_pool.A[275]; A_arbace_cpp_sema__init_part0_A_const_184 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[276]); A_arbace_cpp_sema__init_part0_A_const_185 = A_arbace_cpp_sema__init_part0_A_const_pool.A[277] }

func A_arbace_cpp_sema__init_part0_A_clinit_p14() { A_arbace_cpp_sema__init_part0_A_const_186 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[278]); A_arbace_cpp_sema__init_part0_A_const_187 = A_arbace_cpp_sema__init_part0_A_const_pool.A[279]; A_arbace_cpp_sema__init_part0_A_const_188 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[280]); A_arbace_cpp_sema__init_part0_A_const_189 = A_arbace_cpp_sema__init_part0_A_const_pool.A[281]; A_arbace_cpp_sema__init_part0_A_const_190 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[282]); A_arbace_cpp_sema__init_part0_A_const_191 = A_arbace_cpp_sema__init_part0_A_const_pool.A[283]; A_arbace_cpp_sema__init_part0_A_const_192 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[284]); A_arbace_cpp_sema__init_part0_A_const_193 = A_arbace_cpp_sema__init_part0_A_const_pool.A[285]; A_arbace_cpp_sema__init_part0_A_const_194 = A_arbace_cpp_sema__init_part0_A_const_pool.A[286]; A_arbace_cpp_sema__init_part0_A_const_195 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[287]); A_arbace_cpp_sema__init_part0_A_const_196 = A_arbace_cpp_sema__init_part0_A_const_pool.A[288]; A_arbace_cpp_sema__init_part0_A_const_197 = lang.Var_Cast(A_arbace_cpp_sema__init_part0_A_const_pool.A[289]); A_arbace_cpp_sema__init_part0_A_const_198 = A_arbace_cpp_sema__init_part0_A_const_pool.A[290] }

func A_arbace_cpp_sema__init_part0_A_New() *A_arbace_cpp_sema__init_part0_A { A_arbace_cpp_sema__init_part0_A_Init(); t := &A_arbace_cpp_sema__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_sema__init_part0_A) Ctor() {}

func (t *A_arbace_cpp_sema__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_sema__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_sema__init_part0_A_class }

func (t *A_arbace_cpp_sema__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_sema__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_sema__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_sema__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_sema__init_part0_A); return ok }

func A_arbace_cpp_sema__init_part0_A_Cast(x any) *A_arbace_cpp_sema__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_sema__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_sema__init_part0_A_class)) }; return v }



type A_arbace_cpp_sema__init_part1_A struct{ jrt.Object }

var A_arbace_cpp_sema__init_part1_A_const_pool *jrt.RefArray

var A_arbace_cpp_sema__init_part1_A_const_0 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_1 any

var A_arbace_cpp_sema__init_part1_A_const_2 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_3 any

var A_arbace_cpp_sema__init_part1_A_const_4 any

var A_arbace_cpp_sema__init_part1_A_const_5 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_6 any

var A_arbace_cpp_sema__init_part1_A_const_7 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_8 any

var A_arbace_cpp_sema__init_part1_A_const_9 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_10 any

var A_arbace_cpp_sema__init_part1_A_const_11 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_12 any

var A_arbace_cpp_sema__init_part1_A_const_13 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_14 any

var A_arbace_cpp_sema__init_part1_A_const_15 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_16 any

var A_arbace_cpp_sema__init_part1_A_const_17 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_18 any

var A_arbace_cpp_sema__init_part1_A_const_19 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_20 any

var A_arbace_cpp_sema__init_part1_A_const_21 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_22 any

var A_arbace_cpp_sema__init_part1_A_const_23 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_24 any

var A_arbace_cpp_sema__init_part1_A_const_25 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_26 any

var A_arbace_cpp_sema__init_part1_A_const_27 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_28 any

var A_arbace_cpp_sema__init_part1_A_const_29 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_30 any

var A_arbace_cpp_sema__init_part1_A_const_31 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_32 any

var A_arbace_cpp_sema__init_part1_A_const_33 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_34 any

var A_arbace_cpp_sema__init_part1_A_const_35 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_36 any

var A_arbace_cpp_sema__init_part1_A_const_37 any

var A_arbace_cpp_sema__init_part1_A_const_38 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_39 any

var A_arbace_cpp_sema__init_part1_A_const_40 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_41 any

var A_arbace_cpp_sema__init_part1_A_const_42 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_43 any

var A_arbace_cpp_sema__init_part1_A_const_44 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_45 any

var A_arbace_cpp_sema__init_part1_A_const_46 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_47 any

var A_arbace_cpp_sema__init_part1_A_const_48 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_49 any

var A_arbace_cpp_sema__init_part1_A_const_50 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_51 any

var A_arbace_cpp_sema__init_part1_A_const_52 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_53 any

var A_arbace_cpp_sema__init_part1_A_const_54 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_55 any

var A_arbace_cpp_sema__init_part1_A_const_56 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_57 any

var A_arbace_cpp_sema__init_part1_A_const_58 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_59 any

var A_arbace_cpp_sema__init_part1_A_const_60 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_61 any

var A_arbace_cpp_sema__init_part1_A_const_62 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_63 any

var A_arbace_cpp_sema__init_part1_A_const_64 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_65 any

var A_arbace_cpp_sema__init_part1_A_const_66 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_67 any

var A_arbace_cpp_sema__init_part1_A_const_68 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_69 any

var A_arbace_cpp_sema__init_part1_A_const_70 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_71 any

var A_arbace_cpp_sema__init_part1_A_const_72 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_73 any

var A_arbace_cpp_sema__init_part1_A_const_74 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_75 any

var A_arbace_cpp_sema__init_part1_A_const_76 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_77 any

var A_arbace_cpp_sema__init_part1_A_const_78 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_79 any

var A_arbace_cpp_sema__init_part1_A_const_80 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_81 any

var A_arbace_cpp_sema__init_part1_A_const_82 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_83 any

var A_arbace_cpp_sema__init_part1_A_const_84 any

var A_arbace_cpp_sema__init_part1_A_const_85 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_86 any

var A_arbace_cpp_sema__init_part1_A_const_87 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_88 any

var A_arbace_cpp_sema__init_part1_A_const_89 any

var A_arbace_cpp_sema__init_part1_A_const_90 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_91 any

var A_arbace_cpp_sema__init_part1_A_const_92 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_93 any

var A_arbace_cpp_sema__init_part1_A_const_94 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_95 any

var A_arbace_cpp_sema__init_part1_A_const_96 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_97 any

var A_arbace_cpp_sema__init_part1_A_const_98 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_99 any

var A_arbace_cpp_sema__init_part1_A_const_100 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_101 any

var A_arbace_cpp_sema__init_part1_A_const_102 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_103 any

var A_arbace_cpp_sema__init_part1_A_const_104 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_105 any

var A_arbace_cpp_sema__init_part1_A_const_106 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_107 any

var A_arbace_cpp_sema__init_part1_A_const_108 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_109 any

var A_arbace_cpp_sema__init_part1_A_const_110 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_111 any

var A_arbace_cpp_sema__init_part1_A_const_112 any

var A_arbace_cpp_sema__init_part1_A_const_113 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_114 any

var A_arbace_cpp_sema__init_part1_A_const_115 any

var A_arbace_cpp_sema__init_part1_A_const_116 any

var A_arbace_cpp_sema__init_part1_A_const_117 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_118 any

var A_arbace_cpp_sema__init_part1_A_const_119 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_120 any

var A_arbace_cpp_sema__init_part1_A_const_121 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_122 any

var A_arbace_cpp_sema__init_part1_A_const_123 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_124 any

var A_arbace_cpp_sema__init_part1_A_const_125 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_126 any

var A_arbace_cpp_sema__init_part1_A_const_127 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_128 any

var A_arbace_cpp_sema__init_part1_A_const_129 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_130 any

var A_arbace_cpp_sema__init_part1_A_const_131 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_132 any

var A_arbace_cpp_sema__init_part1_A_const_133 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_134 any

var A_arbace_cpp_sema__init_part1_A_const_135 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_136 any

var A_arbace_cpp_sema__init_part1_A_const_137 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_138 any

var A_arbace_cpp_sema__init_part1_A_const_139 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_140 any

var A_arbace_cpp_sema__init_part1_A_const_141 any

var A_arbace_cpp_sema__init_part1_A_const_142 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_143 any

var A_arbace_cpp_sema__init_part1_A_const_144 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_145 any

var A_arbace_cpp_sema__init_part1_A_const_146 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_147 any

var A_arbace_cpp_sema__init_part1_A_const_148 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_149 any

var A_arbace_cpp_sema__init_part1_A_const_150 any

var A_arbace_cpp_sema__init_part1_A_const_151 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_152 any

var A_arbace_cpp_sema__init_part1_A_const_153 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_154 any

var A_arbace_cpp_sema__init_part1_A_const_155 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_156 any

var A_arbace_cpp_sema__init_part1_A_const_157 any

var A_arbace_cpp_sema__init_part1_A_const_158 any

var A_arbace_cpp_sema__init_part1_A_const_159 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_160 any

var A_arbace_cpp_sema__init_part1_A_const_161 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_162 any

var A_arbace_cpp_sema__init_part1_A_const_163 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_164 any

var A_arbace_cpp_sema__init_part1_A_const_165 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_166 any

var A_arbace_cpp_sema__init_part1_A_const_167 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_168 any

var A_arbace_cpp_sema__init_part1_A_const_169 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_170 any

var A_arbace_cpp_sema__init_part1_A_const_171 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_172 any

var A_arbace_cpp_sema__init_part1_A_const_173 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_174 any

var A_arbace_cpp_sema__init_part1_A_const_175 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_176 any

var A_arbace_cpp_sema__init_part1_A_const_177 any

var A_arbace_cpp_sema__init_part1_A_const_178 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_179 any

var A_arbace_cpp_sema__init_part1_A_const_180 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_181 any

var A_arbace_cpp_sema__init_part1_A_const_182 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_183 any

var A_arbace_cpp_sema__init_part1_A_const_184 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_185 any

var A_arbace_cpp_sema__init_part1_A_const_186 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_187 any

var A_arbace_cpp_sema__init_part1_A_const_188 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_189 any

var A_arbace_cpp_sema__init_part1_A_const_190 *lang.Var

var A_arbace_cpp_sema__init_part1_A_const_191 any

var A_arbace_cpp_sema__init_part1_A_init jrt.ClassInit

func A_arbace_cpp_sema__init_part1_A_Init() { if !A_arbace_cpp_sema__init_part1_A_init.Done() { A_arbace_cpp_sema__init_part1_A_init.Run(A_arbace_cpp_sema__init_part1_A_clinit) } }

func A_arbace_cpp_sema__init_part1_A_clinit() { A_arbace_cpp_sema__init_part1_A_clinit_p0(); A_arbace_cpp_sema__init_part1_A_clinit_p1(); A_arbace_cpp_sema__init_part1_A_clinit_p2() }

func A_arbace_cpp_sema__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_sema__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1369, 227); A_arbace_cpp_sema__init_part1_A_const_0 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[39]); A_arbace_cpp_sema__init_part1_A_const_1 = A_arbace_cpp_sema__init_part1_A_const_pool.A[40]; A_arbace_cpp_sema__init_part1_A_const_2 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[41]); A_arbace_cpp_sema__init_part1_A_const_3 = A_arbace_cpp_sema__init_part1_A_const_pool.A[42]; A_arbace_cpp_sema__init_part1_A_const_4 = A_arbace_cpp_sema__init_part1_A_const_pool.A[43]; A_arbace_cpp_sema__init_part1_A_const_5 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[44]); A_arbace_cpp_sema__init_part1_A_const_6 = A_arbace_cpp_sema__init_part1_A_const_pool.A[45]; A_arbace_cpp_sema__init_part1_A_const_7 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[46]); A_arbace_cpp_sema__init_part1_A_const_8 = A_arbace_cpp_sema__init_part1_A_const_pool.A[47]; A_arbace_cpp_sema__init_part1_A_const_9 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[48]); A_arbace_cpp_sema__init_part1_A_const_10 = A_arbace_cpp_sema__init_part1_A_const_pool.A[49]; A_arbace_cpp_sema__init_part1_A_const_11 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[50]); A_arbace_cpp_sema__init_part1_A_const_12 = A_arbace_cpp_sema__init_part1_A_const_pool.A[51] }

func A_arbace_cpp_sema__init_part1_A_clinit_p1() { A_arbace_cpp_sema__init_part1_A_const_13 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[52]); A_arbace_cpp_sema__init_part1_A_const_14 = A_arbace_cpp_sema__init_part1_A_const_pool.A[53]; A_arbace_cpp_sema__init_part1_A_const_15 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[54]); A_arbace_cpp_sema__init_part1_A_const_16 = A_arbace_cpp_sema__init_part1_A_const_pool.A[55] }

func A_arbace_cpp_sema__init_part1_A_clinit_p2() { var tmp1 *lang.Var; A_arbace_cpp_sema__init_part0_A_Init(); tmp1 = A_arbace_cpp_sema__init_part0_A_const_94; A_arbace_cpp_sema__init_part1_A_const_17 = tmp1; A_arbace_cpp_sema__init_part1_A_const_18 = A_arbace_cpp_sema__init_part1_A_const_pool.A[56]; A_arbace_cpp_sema__init_part1_A_const_19 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[57]); A_arbace_cpp_sema__init_part1_A_const_20 = A_arbace_cpp_sema__init_part1_A_const_pool.A[58]; A_arbace_cpp_sema__init_part1_A_const_21 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[59]); A_arbace_cpp_sema__init_part1_A_const_22 = A_arbace_cpp_sema__init_part1_A_const_pool.A[60]; A_arbace_cpp_sema__init_part1_A_const_23 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[61]); A_arbace_cpp_sema__init_part1_A_const_24 = A_arbace_cpp_sema__init_part1_A_const_pool.A[62]; A_arbace_cpp_sema__init_part1_A_const_25 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[63]); A_arbace_cpp_sema__init_part1_A_const_26 = A_arbace_cpp_sema__init_part1_A_const_pool.A[64]; var tmp2 *lang.Var; A_arbace_cpp_sema__init_part0_A_Init(); tmp2 = A_arbace_cpp_sema__init_part0_A_const_117; A_arbace_cpp_sema__init_part1_A_const_27 = tmp2; A_arbace_cpp_sema__init_part1_A_const_28 = A_arbace_cpp_sema__init_part1_A_const_pool.A[65]; A_arbace_cpp_sema__init_part1_A_const_29 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[66]); A_arbace_cpp_sema__init_part1_A_const_30 = A_arbace_cpp_sema__init_part1_A_const_pool.A[67]; A_arbace_cpp_sema__init_part1_A_const_31 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[68]); A_arbace_cpp_sema__init_part1_A_const_32 = A_arbace_cpp_sema__init_part1_A_const_pool.A[69]; A_arbace_cpp_sema__init_part1_A_const_33 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[70]); A_arbace_cpp_sema__init_part1_A_const_34 = A_arbace_cpp_sema__init_part1_A_const_pool.A[71]; A_arbace_cpp_sema__init_part1_A_const_35 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[72]); var tmp3 any; A_arbace_cpp_sema__init_part0_A_Init(); tmp3 = A_arbace_cpp_sema__init_part0_A_const_22; A_arbace_cpp_sema__init_part1_A_const_36 = tmp3; A_arbace_cpp_sema__init_part1_A_const_37 = A_arbace_cpp_sema__init_part1_A_const_pool.A[73]; A_arbace_cpp_sema__init_part1_A_const_38 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[74]); A_arbace_cpp_sema__init_part1_A_const_39 = A_arbace_cpp_sema__init_part1_A_const_pool.A[75]; A_arbace_cpp_sema__init_part1_A_const_40 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[76]); A_arbace_cpp_sema__init_part1_A_const_41 = A_arbace_cpp_sema__init_part1_A_const_pool.A[77]; A_arbace_cpp_sema__init_part1_A_const_42 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[78]); A_arbace_cpp_sema__init_part1_A_const_43 = A_arbace_cpp_sema__init_part1_A_const_pool.A[79]; A_arbace_cpp_sema__init_part1_A_const_44 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[80]); A_arbace_cpp_sema__init_part1_A_const_45 = A_arbace_cpp_sema__init_part1_A_const_pool.A[81]; A_arbace_cpp_sema__init_part1_A_const_46 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[82]); A_arbace_cpp_sema__init_part1_A_const_47 = A_arbace_cpp_sema__init_part1_A_const_pool.A[83]; A_arbace_cpp_sema__init_part1_A_const_48 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[84]); A_arbace_cpp_sema__init_part1_A_const_49 = A_arbace_cpp_sema__init_part1_A_const_pool.A[85]; A_arbace_cpp_sema__init_part1_A_const_50 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[86]); A_arbace_cpp_sema__init_part1_A_const_51 = A_arbace_cpp_sema__init_part1_A_const_pool.A[87]; A_arbace_cpp_sema__init_part1_A_const_52 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[88]); A_arbace_cpp_sema__init_part1_A_const_53 = A_arbace_cpp_sema__init_part1_A_const_pool.A[89]; A_arbace_cpp_sema__init_part1_A_const_54 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[90]); A_arbace_cpp_sema__init_part1_A_const_55 = A_arbace_cpp_sema__init_part1_A_const_pool.A[91]; A_arbace_cpp_sema__init_part1_A_const_56 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[92]); A_arbace_cpp_sema__init_part1_A_const_57 = A_arbace_cpp_sema__init_part1_A_const_pool.A[93]; A_arbace_cpp_sema__init_part1_A_const_58 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[94]); A_arbace_cpp_sema__init_part1_A_const_59 = A_arbace_cpp_sema__init_part1_A_const_pool.A[95]; A_arbace_cpp_sema__init_part1_A_const_60 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[96]); A_arbace_cpp_sema__init_part1_A_const_61 = A_arbace_cpp_sema__init_part1_A_const_pool.A[97]; A_arbace_cpp_sema__init_part1_A_const_62 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[98]); A_arbace_cpp_sema__init_part1_A_const_63 = A_arbace_cpp_sema__init_part1_A_const_pool.A[99]; A_arbace_cpp_sema__init_part1_A_const_64 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[100]); A_arbace_cpp_sema__init_part1_A_const_65 = A_arbace_cpp_sema__init_part1_A_const_pool.A[101]; A_arbace_cpp_sema__init_part1_A_const_66 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[102]); A_arbace_cpp_sema__init_part1_A_const_67 = A_arbace_cpp_sema__init_part1_A_const_pool.A[103]; A_arbace_cpp_sema__init_part1_A_const_68 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[104]); A_arbace_cpp_sema__init_part1_A_const_69 = A_arbace_cpp_sema__init_part1_A_const_pool.A[105]; A_arbace_cpp_sema__init_part1_A_const_70 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[106]); A_arbace_cpp_sema__init_part1_A_const_71 = A_arbace_cpp_sema__init_part1_A_const_pool.A[107]; A_arbace_cpp_sema__init_part1_A_const_72 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[108]); A_arbace_cpp_sema__init_part1_A_const_73 = A_arbace_cpp_sema__init_part1_A_const_pool.A[109]; A_arbace_cpp_sema__init_part1_A_const_74 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[110]); A_arbace_cpp_sema__init_part1_A_const_75 = A_arbace_cpp_sema__init_part1_A_const_pool.A[111]; A_arbace_cpp_sema__init_part1_A_const_76 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[112]); A_arbace_cpp_sema__init_part1_A_const_77 = A_arbace_cpp_sema__init_part1_A_const_pool.A[113]; A_arbace_cpp_sema__init_part1_A_const_78 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[114]); A_arbace_cpp_sema__init_part1_A_const_79 = A_arbace_cpp_sema__init_part1_A_const_pool.A[115]; A_arbace_cpp_sema__init_part1_A_const_80 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[116]); A_arbace_cpp_sema__init_part1_A_const_81 = A_arbace_cpp_sema__init_part1_A_const_pool.A[117]; A_arbace_cpp_sema__init_part1_A_const_82 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[118]); A_arbace_cpp_sema__init_part1_A_const_83 = A_arbace_cpp_sema__init_part1_A_const_pool.A[119]; A_arbace_cpp_sema__init_part1_A_const_84 = A_arbace_cpp_sema__init_part1_A_const_pool.A[120]; A_arbace_cpp_sema__init_part1_A_const_85 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[121]); A_arbace_cpp_sema__init_part1_A_const_86 = A_arbace_cpp_sema__init_part1_A_const_pool.A[122]; A_arbace_cpp_sema__init_part1_A_const_87 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[123]); A_arbace_cpp_sema__init_part1_A_const_88 = A_arbace_cpp_sema__init_part1_A_const_pool.A[124]; A_arbace_cpp_sema__init_part1_A_const_89 = A_arbace_cpp_sema__init_part1_A_const_pool.A[125]; A_arbace_cpp_sema__init_part1_A_const_90 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[126]); A_arbace_cpp_sema__init_part1_A_const_91 = A_arbace_cpp_sema__init_part1_A_const_pool.A[127]; A_arbace_cpp_sema__init_part1_A_const_92 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[128]); A_arbace_cpp_sema__init_part1_A_const_93 = A_arbace_cpp_sema__init_part1_A_const_pool.A[129]; A_arbace_cpp_sema__init_part1_A_const_94 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[130]); A_arbace_cpp_sema__init_part1_A_const_95 = A_arbace_cpp_sema__init_part1_A_const_pool.A[131]; A_arbace_cpp_sema__init_part1_A_const_96 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[132]); A_arbace_cpp_sema__init_part1_A_const_97 = A_arbace_cpp_sema__init_part1_A_const_pool.A[133]; A_arbace_cpp_sema__init_part1_A_const_98 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[134]); A_arbace_cpp_sema__init_part1_A_const_99 = A_arbace_cpp_sema__init_part1_A_const_pool.A[135]; A_arbace_cpp_sema__init_part1_A_const_100 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[136]); A_arbace_cpp_sema__init_part1_A_const_101 = A_arbace_cpp_sema__init_part1_A_const_pool.A[137]; A_arbace_cpp_sema__init_part1_A_const_102 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[138]); A_arbace_cpp_sema__init_part1_A_const_103 = A_arbace_cpp_sema__init_part1_A_const_pool.A[139]; A_arbace_cpp_sema__init_part1_A_const_104 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[140]); A_arbace_cpp_sema__init_part1_A_const_105 = A_arbace_cpp_sema__init_part1_A_const_pool.A[141]; A_arbace_cpp_sema__init_part1_A_const_106 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[142]); A_arbace_cpp_sema__init_part1_A_const_107 = A_arbace_cpp_sema__init_part1_A_const_pool.A[143]; A_arbace_cpp_sema__init_part1_A_const_108 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[144]); A_arbace_cpp_sema__init_part1_A_const_109 = A_arbace_cpp_sema__init_part1_A_const_pool.A[145]; A_arbace_cpp_sema__init_part1_A_const_110 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[146]); A_arbace_cpp_sema__init_part1_A_const_111 = A_arbace_cpp_sema__init_part1_A_const_pool.A[147]; A_arbace_cpp_sema__init_part1_A_const_112 = A_arbace_cpp_sema__init_part1_A_const_pool.A[148]; A_arbace_cpp_sema__init_part1_A_const_113 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[149]); A_arbace_cpp_sema__init_part1_A_const_114 = A_arbace_cpp_sema__init_part1_A_const_pool.A[150]; A_arbace_cpp_sema__init_part1_A_const_115 = A_arbace_cpp_sema__init_part1_A_const_pool.A[151]; A_arbace_cpp_sema__init_part1_A_const_116 = A_arbace_cpp_sema__init_part1_A_const_pool.A[152]; A_arbace_cpp_sema__init_part1_A_const_117 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[153]); A_arbace_cpp_sema__init_part1_A_const_118 = A_arbace_cpp_sema__init_part1_A_const_pool.A[154]; A_arbace_cpp_sema__init_part1_A_const_119 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[155]); A_arbace_cpp_sema__init_part1_A_const_120 = A_arbace_cpp_sema__init_part1_A_const_pool.A[156]; A_arbace_cpp_sema__init_part1_A_const_121 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[157]); A_arbace_cpp_sema__init_part1_A_const_122 = A_arbace_cpp_sema__init_part1_A_const_pool.A[158]; A_arbace_cpp_sema__init_part1_A_const_123 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[159]); A_arbace_cpp_sema__init_part1_A_const_124 = A_arbace_cpp_sema__init_part1_A_const_pool.A[160]; A_arbace_cpp_sema__init_part1_A_const_125 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[161]); A_arbace_cpp_sema__init_part1_A_const_126 = A_arbace_cpp_sema__init_part1_A_const_pool.A[162]; A_arbace_cpp_sema__init_part1_A_const_127 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[163]); A_arbace_cpp_sema__init_part1_A_const_128 = A_arbace_cpp_sema__init_part1_A_const_pool.A[164]; A_arbace_cpp_sema__init_part1_A_const_129 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[165]); A_arbace_cpp_sema__init_part1_A_const_130 = A_arbace_cpp_sema__init_part1_A_const_pool.A[166]; A_arbace_cpp_sema__init_part1_A_const_131 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[167]); A_arbace_cpp_sema__init_part1_A_const_132 = A_arbace_cpp_sema__init_part1_A_const_pool.A[168]; A_arbace_cpp_sema__init_part1_A_const_133 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[169]); A_arbace_cpp_sema__init_part1_A_const_134 = A_arbace_cpp_sema__init_part1_A_const_pool.A[170]; A_arbace_cpp_sema__init_part1_A_const_135 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[171]); A_arbace_cpp_sema__init_part1_A_const_136 = A_arbace_cpp_sema__init_part1_A_const_pool.A[172]; A_arbace_cpp_sema__init_part1_A_const_137 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[173]); A_arbace_cpp_sema__init_part1_A_const_138 = A_arbace_cpp_sema__init_part1_A_const_pool.A[174]; A_arbace_cpp_sema__init_part1_A_const_139 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[175]); A_arbace_cpp_sema__init_part1_A_const_140 = A_arbace_cpp_sema__init_part1_A_const_pool.A[176]; A_arbace_cpp_sema__init_part1_A_const_141 = A_arbace_cpp_sema__init_part1_A_const_pool.A[177]; A_arbace_cpp_sema__init_part1_A_const_142 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[178]); A_arbace_cpp_sema__init_part1_A_const_143 = A_arbace_cpp_sema__init_part1_A_const_pool.A[179]; var tmp4 *lang.Var; A_arbace_cpp_sema__init_part0_A_Init(); tmp4 = A_arbace_cpp_sema__init_part0_A_const_84; A_arbace_cpp_sema__init_part1_A_const_144 = tmp4; A_arbace_cpp_sema__init_part1_A_const_145 = A_arbace_cpp_sema__init_part1_A_const_pool.A[180]; A_arbace_cpp_sema__init_part1_A_const_146 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[181]); A_arbace_cpp_sema__init_part1_A_const_147 = A_arbace_cpp_sema__init_part1_A_const_pool.A[182]; A_arbace_cpp_sema__init_part1_A_const_148 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[183]); A_arbace_cpp_sema__init_part1_A_const_149 = A_arbace_cpp_sema__init_part1_A_const_pool.A[184]; A_arbace_cpp_sema__init_part1_A_const_150 = A_arbace_cpp_sema__init_part1_A_const_pool.A[185]; A_arbace_cpp_sema__init_part1_A_const_151 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[186]); A_arbace_cpp_sema__init_part1_A_const_152 = A_arbace_cpp_sema__init_part1_A_const_pool.A[187]; A_arbace_cpp_sema__init_part1_A_const_153 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[188]); A_arbace_cpp_sema__init_part1_A_const_154 = A_arbace_cpp_sema__init_part1_A_const_pool.A[189]; A_arbace_cpp_sema__init_part1_A_const_155 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[190]); A_arbace_cpp_sema__init_part1_A_const_156 = A_arbace_cpp_sema__init_part1_A_const_pool.A[191]; A_arbace_cpp_sema__init_part1_A_const_157 = A_arbace_cpp_sema__init_part1_A_const_pool.A[192]; A_arbace_cpp_sema__init_part1_A_const_158 = A_arbace_cpp_sema__init_part1_A_const_pool.A[193]; A_arbace_cpp_sema__init_part1_A_const_159 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[194]); A_arbace_cpp_sema__init_part1_A_const_160 = A_arbace_cpp_sema__init_part1_A_const_pool.A[195]; A_arbace_cpp_sema__init_part1_A_const_161 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[196]); A_arbace_cpp_sema__init_part1_A_const_162 = A_arbace_cpp_sema__init_part1_A_const_pool.A[197]; A_arbace_cpp_sema__init_part1_A_const_163 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[198]); A_arbace_cpp_sema__init_part1_A_const_164 = A_arbace_cpp_sema__init_part1_A_const_pool.A[199]; A_arbace_cpp_sema__init_part1_A_const_165 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[200]); A_arbace_cpp_sema__init_part1_A_const_166 = A_arbace_cpp_sema__init_part1_A_const_pool.A[201]; A_arbace_cpp_sema__init_part1_A_const_167 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[202]); A_arbace_cpp_sema__init_part1_A_const_168 = A_arbace_cpp_sema__init_part1_A_const_pool.A[203]; A_arbace_cpp_sema__init_part1_A_const_169 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[204]); A_arbace_cpp_sema__init_part1_A_const_170 = A_arbace_cpp_sema__init_part1_A_const_pool.A[205]; A_arbace_cpp_sema__init_part1_A_const_171 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[206]); A_arbace_cpp_sema__init_part1_A_const_172 = A_arbace_cpp_sema__init_part1_A_const_pool.A[207]; A_arbace_cpp_sema__init_part1_A_const_173 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[208]); A_arbace_cpp_sema__init_part1_A_const_174 = A_arbace_cpp_sema__init_part1_A_const_pool.A[209]; A_arbace_cpp_sema__init_part1_A_const_175 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[210]); A_arbace_cpp_sema__init_part1_A_const_176 = A_arbace_cpp_sema__init_part1_A_const_pool.A[211]; A_arbace_cpp_sema__init_part1_A_const_177 = A_arbace_cpp_sema__init_part1_A_const_pool.A[212]; A_arbace_cpp_sema__init_part1_A_const_178 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[213]); A_arbace_cpp_sema__init_part1_A_const_179 = A_arbace_cpp_sema__init_part1_A_const_pool.A[214]; A_arbace_cpp_sema__init_part1_A_const_180 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[215]); A_arbace_cpp_sema__init_part1_A_const_181 = A_arbace_cpp_sema__init_part1_A_const_pool.A[216]; A_arbace_cpp_sema__init_part1_A_const_182 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[217]); A_arbace_cpp_sema__init_part1_A_const_183 = A_arbace_cpp_sema__init_part1_A_const_pool.A[218]; A_arbace_cpp_sema__init_part1_A_const_184 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[219]); A_arbace_cpp_sema__init_part1_A_const_185 = A_arbace_cpp_sema__init_part1_A_const_pool.A[220]; A_arbace_cpp_sema__init_part1_A_const_186 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[221]); A_arbace_cpp_sema__init_part1_A_const_187 = A_arbace_cpp_sema__init_part1_A_const_pool.A[222]; A_arbace_cpp_sema__init_part1_A_const_188 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[223]); A_arbace_cpp_sema__init_part1_A_const_189 = A_arbace_cpp_sema__init_part1_A_const_pool.A[224]; A_arbace_cpp_sema__init_part1_A_const_190 = lang.Var_Cast(A_arbace_cpp_sema__init_part1_A_const_pool.A[225]); A_arbace_cpp_sema__init_part1_A_const_191 = A_arbace_cpp_sema__init_part1_A_const_pool.A[226] }

func A_arbace_cpp_sema__init_part1_A_New() *A_arbace_cpp_sema__init_part1_A { A_arbace_cpp_sema__init_part1_A_Init(); t := &A_arbace_cpp_sema__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_sema__init_part1_A) Ctor() {}

func (t *A_arbace_cpp_sema__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_sema__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_sema__init_part1_A_class }

func (t *A_arbace_cpp_sema__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_sema__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_sema__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_sema__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_sema__init_part1_A); return ok }

func A_arbace_cpp_sema__init_part1_A_Cast(x any) *A_arbace_cpp_sema__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_sema__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_sema__init_part1_A_class)) }; return v }



type A_arbace_cpp_sema__init_part2_A struct{ jrt.Object }

var A_arbace_cpp_sema__init_part2_A_const_pool *jrt.RefArray

var A_arbace_cpp_sema__init_part2_A_const_0 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_1 any

var A_arbace_cpp_sema__init_part2_A_const_2 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_3 any

var A_arbace_cpp_sema__init_part2_A_const_4 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_5 any

var A_arbace_cpp_sema__init_part2_A_const_6 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_7 any

var A_arbace_cpp_sema__init_part2_A_const_8 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_9 any

var A_arbace_cpp_sema__init_part2_A_const_10 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_11 any

var A_arbace_cpp_sema__init_part2_A_const_12 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_13 any

var A_arbace_cpp_sema__init_part2_A_const_14 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_15 any

var A_arbace_cpp_sema__init_part2_A_const_16 any

var A_arbace_cpp_sema__init_part2_A_const_17 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_18 any

var A_arbace_cpp_sema__init_part2_A_const_19 any

var A_arbace_cpp_sema__init_part2_A_const_20 any

var A_arbace_cpp_sema__init_part2_A_const_21 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_22 any

var A_arbace_cpp_sema__init_part2_A_const_23 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_24 any

var A_arbace_cpp_sema__init_part2_A_const_25 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_26 any

var A_arbace_cpp_sema__init_part2_A_const_27 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_28 any

var A_arbace_cpp_sema__init_part2_A_const_29 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_30 any

var A_arbace_cpp_sema__init_part2_A_const_31 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_32 any

var A_arbace_cpp_sema__init_part2_A_const_33 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_34 any

var A_arbace_cpp_sema__init_part2_A_const_35 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_36 any

var A_arbace_cpp_sema__init_part2_A_const_37 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_38 any

var A_arbace_cpp_sema__init_part2_A_const_39 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_40 any

var A_arbace_cpp_sema__init_part2_A_const_41 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_42 any

var A_arbace_cpp_sema__init_part2_A_const_43 any

var A_arbace_cpp_sema__init_part2_A_const_44 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_45 any

var A_arbace_cpp_sema__init_part2_A_const_46 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_47 any

var A_arbace_cpp_sema__init_part2_A_const_48 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_49 any

var A_arbace_cpp_sema__init_part2_A_const_50 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_51 any

var A_arbace_cpp_sema__init_part2_A_const_52 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_53 any

var A_arbace_cpp_sema__init_part2_A_const_54 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_55 any

var A_arbace_cpp_sema__init_part2_A_const_56 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_57 any

var A_arbace_cpp_sema__init_part2_A_const_58 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_59 any

var A_arbace_cpp_sema__init_part2_A_const_60 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_61 any

var A_arbace_cpp_sema__init_part2_A_const_62 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_63 any

var A_arbace_cpp_sema__init_part2_A_const_64 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_65 any

var A_arbace_cpp_sema__init_part2_A_const_66 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_67 any

var A_arbace_cpp_sema__init_part2_A_const_68 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_69 any

var A_arbace_cpp_sema__init_part2_A_const_70 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_71 any

var A_arbace_cpp_sema__init_part2_A_const_72 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_73 any

var A_arbace_cpp_sema__init_part2_A_const_74 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_75 any

var A_arbace_cpp_sema__init_part2_A_const_76 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_77 any

var A_arbace_cpp_sema__init_part2_A_const_78 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_79 any

var A_arbace_cpp_sema__init_part2_A_const_80 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_81 any

var A_arbace_cpp_sema__init_part2_A_const_82 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_83 any

var A_arbace_cpp_sema__init_part2_A_const_84 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_85 any

var A_arbace_cpp_sema__init_part2_A_const_86 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_87 any

var A_arbace_cpp_sema__init_part2_A_const_88 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_89 any

var A_arbace_cpp_sema__init_part2_A_const_90 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_91 any

var A_arbace_cpp_sema__init_part2_A_const_92 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_93 any

var A_arbace_cpp_sema__init_part2_A_const_94 any

var A_arbace_cpp_sema__init_part2_A_const_95 any

var A_arbace_cpp_sema__init_part2_A_const_96 any

var A_arbace_cpp_sema__init_part2_A_const_97 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_98 any

var A_arbace_cpp_sema__init_part2_A_const_99 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_100 any

var A_arbace_cpp_sema__init_part2_A_const_101 any

var A_arbace_cpp_sema__init_part2_A_const_102 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_103 any

var A_arbace_cpp_sema__init_part2_A_const_104 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_105 any

var A_arbace_cpp_sema__init_part2_A_const_106 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_107 any

var A_arbace_cpp_sema__init_part2_A_const_108 any

var A_arbace_cpp_sema__init_part2_A_const_109 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_110 any

var A_arbace_cpp_sema__init_part2_A_const_111 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_112 any

var A_arbace_cpp_sema__init_part2_A_const_113 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_114 any

var A_arbace_cpp_sema__init_part2_A_const_115 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_116 any

var A_arbace_cpp_sema__init_part2_A_const_117 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_118 any

var A_arbace_cpp_sema__init_part2_A_const_119 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_120 any

var A_arbace_cpp_sema__init_part2_A_const_121 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_122 any

var A_arbace_cpp_sema__init_part2_A_const_123 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_124 any

var A_arbace_cpp_sema__init_part2_A_const_125 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_126 any

var A_arbace_cpp_sema__init_part2_A_const_127 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_128 any

var A_arbace_cpp_sema__init_part2_A_const_129 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_130 any

var A_arbace_cpp_sema__init_part2_A_const_131 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_132 any

var A_arbace_cpp_sema__init_part2_A_const_133 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_134 any

var A_arbace_cpp_sema__init_part2_A_const_135 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_136 any

var A_arbace_cpp_sema__init_part2_A_const_137 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_138 any

var A_arbace_cpp_sema__init_part2_A_const_139 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_140 any

var A_arbace_cpp_sema__init_part2_A_const_141 any

var A_arbace_cpp_sema__init_part2_A_const_142 any

var A_arbace_cpp_sema__init_part2_A_const_143 any

var A_arbace_cpp_sema__init_part2_A_const_144 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_145 any

var A_arbace_cpp_sema__init_part2_A_const_146 any

var A_arbace_cpp_sema__init_part2_A_const_147 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_148 any

var A_arbace_cpp_sema__init_part2_A_const_149 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_150 any

var A_arbace_cpp_sema__init_part2_A_const_151 any

var A_arbace_cpp_sema__init_part2_A_const_152 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_153 any

var A_arbace_cpp_sema__init_part2_A_const_154 any

var A_arbace_cpp_sema__init_part2_A_const_155 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_156 any

var A_arbace_cpp_sema__init_part2_A_const_157 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_158 any

var A_arbace_cpp_sema__init_part2_A_const_159 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_160 any

var A_arbace_cpp_sema__init_part2_A_const_161 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_162 any

var A_arbace_cpp_sema__init_part2_A_const_163 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_164 any

var A_arbace_cpp_sema__init_part2_A_const_165 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_166 any

var A_arbace_cpp_sema__init_part2_A_const_167 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_168 any

var A_arbace_cpp_sema__init_part2_A_const_169 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_170 any

var A_arbace_cpp_sema__init_part2_A_const_171 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_172 any

var A_arbace_cpp_sema__init_part2_A_const_173 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_174 any

var A_arbace_cpp_sema__init_part2_A_const_175 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_176 any

var A_arbace_cpp_sema__init_part2_A_const_177 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_178 any

var A_arbace_cpp_sema__init_part2_A_const_179 any

var A_arbace_cpp_sema__init_part2_A_const_180 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_181 any

var A_arbace_cpp_sema__init_part2_A_const_182 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_183 any

var A_arbace_cpp_sema__init_part2_A_const_184 *lang.Var

var A_arbace_cpp_sema__init_part2_A_const_185 any

var A_arbace_cpp_sema__init_part2_A_init jrt.ClassInit

func A_arbace_cpp_sema__init_part2_A_Init() { if !A_arbace_cpp_sema__init_part2_A_init.Done() { A_arbace_cpp_sema__init_part2_A_init.Run(A_arbace_cpp_sema__init_part2_A_clinit) } }

func A_arbace_cpp_sema__init_part2_A_clinit() { A_arbace_cpp_sema__init_part2_A_clinit_p0(); A_arbace_cpp_sema__init_part2_A_clinit_p1() }

func A_arbace_cpp_sema__init_part2_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_sema__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1431, 244); A_arbace_cpp_sema__init_part2_A_const_0 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[69]); A_arbace_cpp_sema__init_part2_A_const_1 = A_arbace_cpp_sema__init_part2_A_const_pool.A[70]; A_arbace_cpp_sema__init_part2_A_const_2 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[71]); A_arbace_cpp_sema__init_part2_A_const_3 = A_arbace_cpp_sema__init_part2_A_const_pool.A[72]; A_arbace_cpp_sema__init_part2_A_const_4 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[73]); A_arbace_cpp_sema__init_part2_A_const_5 = A_arbace_cpp_sema__init_part2_A_const_pool.A[74] }

func A_arbace_cpp_sema__init_part2_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp1 = A_arbace_cpp_sema__init_part1_A_const_119; A_arbace_cpp_sema__init_part2_A_const_6 = tmp1; A_arbace_cpp_sema__init_part2_A_const_7 = A_arbace_cpp_sema__init_part2_A_const_pool.A[75]; var tmp2 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp2 = A_arbace_cpp_sema__init_part1_A_const_155; A_arbace_cpp_sema__init_part2_A_const_8 = tmp2; A_arbace_cpp_sema__init_part2_A_const_9 = A_arbace_cpp_sema__init_part2_A_const_pool.A[76]; A_arbace_cpp_sema__init_part2_A_const_10 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[77]); A_arbace_cpp_sema__init_part2_A_const_11 = A_arbace_cpp_sema__init_part2_A_const_pool.A[78]; var tmp3 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp3 = A_arbace_cpp_sema__init_part1_A_const_186; A_arbace_cpp_sema__init_part2_A_const_12 = tmp3; A_arbace_cpp_sema__init_part2_A_const_13 = A_arbace_cpp_sema__init_part2_A_const_pool.A[79]; var tmp4 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp4 = A_arbace_cpp_sema__init_part1_A_const_190; A_arbace_cpp_sema__init_part2_A_const_14 = tmp4; A_arbace_cpp_sema__init_part2_A_const_15 = A_arbace_cpp_sema__init_part2_A_const_pool.A[80]; A_arbace_cpp_sema__init_part2_A_const_16 = A_arbace_cpp_sema__init_part2_A_const_pool.A[81]; A_arbace_cpp_sema__init_part2_A_const_17 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[82]); A_arbace_cpp_sema__init_part2_A_const_18 = A_arbace_cpp_sema__init_part2_A_const_pool.A[83]; A_arbace_cpp_sema__init_part2_A_const_19 = A_arbace_cpp_sema__init_part2_A_const_pool.A[84]; A_arbace_cpp_sema__init_part2_A_const_20 = A_arbace_cpp_sema__init_part2_A_const_pool.A[85]; var tmp5 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp5 = A_arbace_cpp_sema__init_part1_A_const_188; A_arbace_cpp_sema__init_part2_A_const_21 = tmp5; A_arbace_cpp_sema__init_part2_A_const_22 = A_arbace_cpp_sema__init_part2_A_const_pool.A[86]; A_arbace_cpp_sema__init_part2_A_const_23 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[87]); A_arbace_cpp_sema__init_part2_A_const_24 = A_arbace_cpp_sema__init_part2_A_const_pool.A[88]; var tmp6 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp6 = A_arbace_cpp_sema__init_part1_A_const_31; A_arbace_cpp_sema__init_part2_A_const_25 = tmp6; A_arbace_cpp_sema__init_part2_A_const_26 = A_arbace_cpp_sema__init_part2_A_const_pool.A[89]; A_arbace_cpp_sema__init_part2_A_const_27 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[90]); A_arbace_cpp_sema__init_part2_A_const_28 = A_arbace_cpp_sema__init_part2_A_const_pool.A[91]; A_arbace_cpp_sema__init_part2_A_const_29 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[92]); A_arbace_cpp_sema__init_part2_A_const_30 = A_arbace_cpp_sema__init_part2_A_const_pool.A[93]; A_arbace_cpp_sema__init_part2_A_const_31 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[94]); A_arbace_cpp_sema__init_part2_A_const_32 = A_arbace_cpp_sema__init_part2_A_const_pool.A[95]; A_arbace_cpp_sema__init_part2_A_const_33 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[96]); A_arbace_cpp_sema__init_part2_A_const_34 = A_arbace_cpp_sema__init_part2_A_const_pool.A[97]; A_arbace_cpp_sema__init_part2_A_const_35 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[98]); A_arbace_cpp_sema__init_part2_A_const_36 = A_arbace_cpp_sema__init_part2_A_const_pool.A[99]; var tmp7 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp7 = A_arbace_cpp_sema__init_part1_A_const_29; A_arbace_cpp_sema__init_part2_A_const_37 = tmp7; A_arbace_cpp_sema__init_part2_A_const_38 = A_arbace_cpp_sema__init_part2_A_const_pool.A[100]; A_arbace_cpp_sema__init_part2_A_const_39 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[101]); A_arbace_cpp_sema__init_part2_A_const_40 = A_arbace_cpp_sema__init_part2_A_const_pool.A[102]; A_arbace_cpp_sema__init_part2_A_const_41 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[103]); A_arbace_cpp_sema__init_part2_A_const_42 = A_arbace_cpp_sema__init_part2_A_const_pool.A[104]; A_arbace_cpp_sema__init_part2_A_const_43 = A_arbace_cpp_sema__init_part2_A_const_pool.A[105]; A_arbace_cpp_sema__init_part2_A_const_44 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[106]); A_arbace_cpp_sema__init_part2_A_const_45 = A_arbace_cpp_sema__init_part2_A_const_pool.A[107]; A_arbace_cpp_sema__init_part2_A_const_46 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[108]); A_arbace_cpp_sema__init_part2_A_const_47 = A_arbace_cpp_sema__init_part2_A_const_pool.A[109]; A_arbace_cpp_sema__init_part2_A_const_48 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[110]); A_arbace_cpp_sema__init_part2_A_const_49 = A_arbace_cpp_sema__init_part2_A_const_pool.A[111]; A_arbace_cpp_sema__init_part2_A_const_50 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[112]); A_arbace_cpp_sema__init_part2_A_const_51 = A_arbace_cpp_sema__init_part2_A_const_pool.A[113]; A_arbace_cpp_sema__init_part2_A_const_52 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[114]); A_arbace_cpp_sema__init_part2_A_const_53 = A_arbace_cpp_sema__init_part2_A_const_pool.A[115]; A_arbace_cpp_sema__init_part2_A_const_54 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[116]); A_arbace_cpp_sema__init_part2_A_const_55 = A_arbace_cpp_sema__init_part2_A_const_pool.A[117]; A_arbace_cpp_sema__init_part2_A_const_56 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[118]); A_arbace_cpp_sema__init_part2_A_const_57 = A_arbace_cpp_sema__init_part2_A_const_pool.A[119]; A_arbace_cpp_sema__init_part2_A_const_58 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[120]); A_arbace_cpp_sema__init_part2_A_const_59 = A_arbace_cpp_sema__init_part2_A_const_pool.A[121]; A_arbace_cpp_sema__init_part2_A_const_60 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[122]); A_arbace_cpp_sema__init_part2_A_const_61 = A_arbace_cpp_sema__init_part2_A_const_pool.A[123]; A_arbace_cpp_sema__init_part2_A_const_62 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[124]); A_arbace_cpp_sema__init_part2_A_const_63 = A_arbace_cpp_sema__init_part2_A_const_pool.A[125]; A_arbace_cpp_sema__init_part2_A_const_64 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[126]); A_arbace_cpp_sema__init_part2_A_const_65 = A_arbace_cpp_sema__init_part2_A_const_pool.A[127]; A_arbace_cpp_sema__init_part2_A_const_66 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[128]); A_arbace_cpp_sema__init_part2_A_const_67 = A_arbace_cpp_sema__init_part2_A_const_pool.A[129]; A_arbace_cpp_sema__init_part2_A_const_68 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[130]); A_arbace_cpp_sema__init_part2_A_const_69 = A_arbace_cpp_sema__init_part2_A_const_pool.A[131]; A_arbace_cpp_sema__init_part2_A_const_70 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[132]); A_arbace_cpp_sema__init_part2_A_const_71 = A_arbace_cpp_sema__init_part2_A_const_pool.A[133]; A_arbace_cpp_sema__init_part2_A_const_72 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[134]); A_arbace_cpp_sema__init_part2_A_const_73 = A_arbace_cpp_sema__init_part2_A_const_pool.A[135]; A_arbace_cpp_sema__init_part2_A_const_74 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[136]); A_arbace_cpp_sema__init_part2_A_const_75 = A_arbace_cpp_sema__init_part2_A_const_pool.A[137]; A_arbace_cpp_sema__init_part2_A_const_76 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[138]); A_arbace_cpp_sema__init_part2_A_const_77 = A_arbace_cpp_sema__init_part2_A_const_pool.A[139]; A_arbace_cpp_sema__init_part2_A_const_78 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[140]); A_arbace_cpp_sema__init_part2_A_const_79 = A_arbace_cpp_sema__init_part2_A_const_pool.A[141]; A_arbace_cpp_sema__init_part2_A_const_80 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[142]); A_arbace_cpp_sema__init_part2_A_const_81 = A_arbace_cpp_sema__init_part2_A_const_pool.A[143]; A_arbace_cpp_sema__init_part2_A_const_82 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[144]); A_arbace_cpp_sema__init_part2_A_const_83 = A_arbace_cpp_sema__init_part2_A_const_pool.A[145]; A_arbace_cpp_sema__init_part2_A_const_84 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[146]); A_arbace_cpp_sema__init_part2_A_const_85 = A_arbace_cpp_sema__init_part2_A_const_pool.A[147]; A_arbace_cpp_sema__init_part2_A_const_86 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[148]); A_arbace_cpp_sema__init_part2_A_const_87 = A_arbace_cpp_sema__init_part2_A_const_pool.A[149]; A_arbace_cpp_sema__init_part2_A_const_88 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[150]); A_arbace_cpp_sema__init_part2_A_const_89 = A_arbace_cpp_sema__init_part2_A_const_pool.A[151]; A_arbace_cpp_sema__init_part2_A_const_90 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[152]); A_arbace_cpp_sema__init_part2_A_const_91 = A_arbace_cpp_sema__init_part2_A_const_pool.A[153]; A_arbace_cpp_sema__init_part2_A_const_92 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[154]); A_arbace_cpp_sema__init_part2_A_const_93 = A_arbace_cpp_sema__init_part2_A_const_pool.A[155]; A_arbace_cpp_sema__init_part2_A_const_94 = A_arbace_cpp_sema__init_part2_A_const_pool.A[156]; A_arbace_cpp_sema__init_part2_A_const_95 = A_arbace_cpp_sema__init_part2_A_const_pool.A[157]; A_arbace_cpp_sema__init_part2_A_const_96 = A_arbace_cpp_sema__init_part2_A_const_pool.A[158]; A_arbace_cpp_sema__init_part2_A_const_97 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[159]); A_arbace_cpp_sema__init_part2_A_const_98 = A_arbace_cpp_sema__init_part2_A_const_pool.A[160]; A_arbace_cpp_sema__init_part2_A_const_99 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[161]); A_arbace_cpp_sema__init_part2_A_const_100 = A_arbace_cpp_sema__init_part2_A_const_pool.A[162]; A_arbace_cpp_sema__init_part2_A_const_101 = A_arbace_cpp_sema__init_part2_A_const_pool.A[163]; A_arbace_cpp_sema__init_part2_A_const_102 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[164]); A_arbace_cpp_sema__init_part2_A_const_103 = A_arbace_cpp_sema__init_part2_A_const_pool.A[165]; A_arbace_cpp_sema__init_part2_A_const_104 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[166]); A_arbace_cpp_sema__init_part2_A_const_105 = A_arbace_cpp_sema__init_part2_A_const_pool.A[167]; A_arbace_cpp_sema__init_part2_A_const_106 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[168]); A_arbace_cpp_sema__init_part2_A_const_107 = A_arbace_cpp_sema__init_part2_A_const_pool.A[169]; A_arbace_cpp_sema__init_part2_A_const_108 = A_arbace_cpp_sema__init_part2_A_const_pool.A[170]; A_arbace_cpp_sema__init_part2_A_const_109 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[171]); A_arbace_cpp_sema__init_part2_A_const_110 = A_arbace_cpp_sema__init_part2_A_const_pool.A[172]; var tmp8 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp8 = A_arbace_cpp_sema__init_part1_A_const_117; A_arbace_cpp_sema__init_part2_A_const_111 = tmp8; A_arbace_cpp_sema__init_part2_A_const_112 = A_arbace_cpp_sema__init_part2_A_const_pool.A[173]; A_arbace_cpp_sema__init_part2_A_const_113 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[174]); A_arbace_cpp_sema__init_part2_A_const_114 = A_arbace_cpp_sema__init_part2_A_const_pool.A[175]; A_arbace_cpp_sema__init_part2_A_const_115 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[176]); A_arbace_cpp_sema__init_part2_A_const_116 = A_arbace_cpp_sema__init_part2_A_const_pool.A[177]; A_arbace_cpp_sema__init_part2_A_const_117 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[178]); A_arbace_cpp_sema__init_part2_A_const_118 = A_arbace_cpp_sema__init_part2_A_const_pool.A[179]; A_arbace_cpp_sema__init_part2_A_const_119 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[180]); A_arbace_cpp_sema__init_part2_A_const_120 = A_arbace_cpp_sema__init_part2_A_const_pool.A[181]; A_arbace_cpp_sema__init_part2_A_const_121 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[182]); A_arbace_cpp_sema__init_part2_A_const_122 = A_arbace_cpp_sema__init_part2_A_const_pool.A[183]; A_arbace_cpp_sema__init_part2_A_const_123 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[184]); A_arbace_cpp_sema__init_part2_A_const_124 = A_arbace_cpp_sema__init_part2_A_const_pool.A[185]; A_arbace_cpp_sema__init_part2_A_const_125 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[186]); A_arbace_cpp_sema__init_part2_A_const_126 = A_arbace_cpp_sema__init_part2_A_const_pool.A[187]; A_arbace_cpp_sema__init_part2_A_const_127 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[188]); A_arbace_cpp_sema__init_part2_A_const_128 = A_arbace_cpp_sema__init_part2_A_const_pool.A[189]; A_arbace_cpp_sema__init_part2_A_const_129 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[190]); A_arbace_cpp_sema__init_part2_A_const_130 = A_arbace_cpp_sema__init_part2_A_const_pool.A[191]; var tmp9 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp9 = A_arbace_cpp_sema__init_part1_A_const_70; A_arbace_cpp_sema__init_part2_A_const_131 = tmp9; A_arbace_cpp_sema__init_part2_A_const_132 = A_arbace_cpp_sema__init_part2_A_const_pool.A[192]; A_arbace_cpp_sema__init_part2_A_const_133 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[193]); A_arbace_cpp_sema__init_part2_A_const_134 = A_arbace_cpp_sema__init_part2_A_const_pool.A[194]; A_arbace_cpp_sema__init_part2_A_const_135 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[195]); A_arbace_cpp_sema__init_part2_A_const_136 = A_arbace_cpp_sema__init_part2_A_const_pool.A[196]; A_arbace_cpp_sema__init_part2_A_const_137 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[197]); A_arbace_cpp_sema__init_part2_A_const_138 = A_arbace_cpp_sema__init_part2_A_const_pool.A[198]; A_arbace_cpp_sema__init_part2_A_const_139 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[199]); A_arbace_cpp_sema__init_part2_A_const_140 = A_arbace_cpp_sema__init_part2_A_const_pool.A[200]; A_arbace_cpp_sema__init_part2_A_const_141 = A_arbace_cpp_sema__init_part2_A_const_pool.A[201]; A_arbace_cpp_sema__init_part2_A_const_142 = A_arbace_cpp_sema__init_part2_A_const_pool.A[202]; A_arbace_cpp_sema__init_part2_A_const_143 = A_arbace_cpp_sema__init_part2_A_const_pool.A[203]; var tmp10 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp10 = A_arbace_cpp_sema__init_part1_A_const_113; A_arbace_cpp_sema__init_part2_A_const_144 = tmp10; A_arbace_cpp_sema__init_part2_A_const_145 = A_arbace_cpp_sema__init_part2_A_const_pool.A[204]; A_arbace_cpp_sema__init_part2_A_const_146 = A_arbace_cpp_sema__init_part2_A_const_pool.A[205]; A_arbace_cpp_sema__init_part2_A_const_147 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[206]); A_arbace_cpp_sema__init_part2_A_const_148 = A_arbace_cpp_sema__init_part2_A_const_pool.A[207]; A_arbace_cpp_sema__init_part2_A_const_149 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[208]); A_arbace_cpp_sema__init_part2_A_const_150 = A_arbace_cpp_sema__init_part2_A_const_pool.A[209]; A_arbace_cpp_sema__init_part2_A_const_151 = A_arbace_cpp_sema__init_part2_A_const_pool.A[210]; A_arbace_cpp_sema__init_part2_A_const_152 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[211]); A_arbace_cpp_sema__init_part2_A_const_153 = A_arbace_cpp_sema__init_part2_A_const_pool.A[212]; A_arbace_cpp_sema__init_part2_A_const_154 = A_arbace_cpp_sema__init_part2_A_const_pool.A[213]; A_arbace_cpp_sema__init_part2_A_const_155 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[214]); A_arbace_cpp_sema__init_part2_A_const_156 = A_arbace_cpp_sema__init_part2_A_const_pool.A[215]; A_arbace_cpp_sema__init_part2_A_const_157 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[216]); A_arbace_cpp_sema__init_part2_A_const_158 = A_arbace_cpp_sema__init_part2_A_const_pool.A[217]; A_arbace_cpp_sema__init_part2_A_const_159 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[218]); A_arbace_cpp_sema__init_part2_A_const_160 = A_arbace_cpp_sema__init_part2_A_const_pool.A[219]; var tmp11 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp11 = A_arbace_cpp_sema__init_part1_A_const_175; A_arbace_cpp_sema__init_part2_A_const_161 = tmp11; A_arbace_cpp_sema__init_part2_A_const_162 = A_arbace_cpp_sema__init_part2_A_const_pool.A[220]; A_arbace_cpp_sema__init_part2_A_const_163 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[221]); A_arbace_cpp_sema__init_part2_A_const_164 = A_arbace_cpp_sema__init_part2_A_const_pool.A[222]; A_arbace_cpp_sema__init_part2_A_const_165 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[223]); A_arbace_cpp_sema__init_part2_A_const_166 = A_arbace_cpp_sema__init_part2_A_const_pool.A[224]; A_arbace_cpp_sema__init_part2_A_const_167 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[225]); A_arbace_cpp_sema__init_part2_A_const_168 = A_arbace_cpp_sema__init_part2_A_const_pool.A[226]; A_arbace_cpp_sema__init_part2_A_const_169 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[227]); A_arbace_cpp_sema__init_part2_A_const_170 = A_arbace_cpp_sema__init_part2_A_const_pool.A[228]; A_arbace_cpp_sema__init_part2_A_const_171 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[229]); A_arbace_cpp_sema__init_part2_A_const_172 = A_arbace_cpp_sema__init_part2_A_const_pool.A[230]; A_arbace_cpp_sema__init_part2_A_const_173 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[231]); A_arbace_cpp_sema__init_part2_A_const_174 = A_arbace_cpp_sema__init_part2_A_const_pool.A[232]; A_arbace_cpp_sema__init_part2_A_const_175 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[233]); A_arbace_cpp_sema__init_part2_A_const_176 = A_arbace_cpp_sema__init_part2_A_const_pool.A[234]; A_arbace_cpp_sema__init_part2_A_const_177 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[235]); A_arbace_cpp_sema__init_part2_A_const_178 = A_arbace_cpp_sema__init_part2_A_const_pool.A[236]; A_arbace_cpp_sema__init_part2_A_const_179 = A_arbace_cpp_sema__init_part2_A_const_pool.A[237]; A_arbace_cpp_sema__init_part2_A_const_180 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[238]); A_arbace_cpp_sema__init_part2_A_const_181 = A_arbace_cpp_sema__init_part2_A_const_pool.A[239]; A_arbace_cpp_sema__init_part2_A_const_182 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[240]); A_arbace_cpp_sema__init_part2_A_const_183 = A_arbace_cpp_sema__init_part2_A_const_pool.A[241]; A_arbace_cpp_sema__init_part2_A_const_184 = lang.Var_Cast(A_arbace_cpp_sema__init_part2_A_const_pool.A[242]); A_arbace_cpp_sema__init_part2_A_const_185 = A_arbace_cpp_sema__init_part2_A_const_pool.A[243] }

func A_arbace_cpp_sema__init_part2_A_New() *A_arbace_cpp_sema__init_part2_A { A_arbace_cpp_sema__init_part2_A_Init(); t := &A_arbace_cpp_sema__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_sema__init_part2_A) Ctor() {}

func (t *A_arbace_cpp_sema__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_sema__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_sema__init_part2_A_class }

func (t *A_arbace_cpp_sema__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_sema__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_sema__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_sema__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_sema__init_part2_A); return ok }

func A_arbace_cpp_sema__init_part2_A_Cast(x any) *A_arbace_cpp_sema__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_sema__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_sema__init_part2_A_class)) }; return v }



type A_arbace_cpp_sema__init_part3_A struct{ jrt.Object }

var A_arbace_cpp_sema__init_part3_A_const_pool *jrt.RefArray

var A_arbace_cpp_sema__init_part3_A_const_0 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_1 any

var A_arbace_cpp_sema__init_part3_A_const_2 any

var A_arbace_cpp_sema__init_part3_A_const_3 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_4 any

var A_arbace_cpp_sema__init_part3_A_const_5 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_6 any

var A_arbace_cpp_sema__init_part3_A_const_7 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_8 any

var A_arbace_cpp_sema__init_part3_A_const_9 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_10 any

var A_arbace_cpp_sema__init_part3_A_const_11 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_12 any

var A_arbace_cpp_sema__init_part3_A_const_13 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_14 any

var A_arbace_cpp_sema__init_part3_A_const_15 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_16 any

var A_arbace_cpp_sema__init_part3_A_const_17 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_18 any

var A_arbace_cpp_sema__init_part3_A_const_19 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_20 any

var A_arbace_cpp_sema__init_part3_A_const_21 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_22 any

var A_arbace_cpp_sema__init_part3_A_const_23 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_24 any

var A_arbace_cpp_sema__init_part3_A_const_25 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_26 any

var A_arbace_cpp_sema__init_part3_A_const_27 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_28 any

var A_arbace_cpp_sema__init_part3_A_const_29 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_30 any

var A_arbace_cpp_sema__init_part3_A_const_31 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_32 any

var A_arbace_cpp_sema__init_part3_A_const_33 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_34 any

var A_arbace_cpp_sema__init_part3_A_const_35 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_36 any

var A_arbace_cpp_sema__init_part3_A_const_37 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_38 any

var A_arbace_cpp_sema__init_part3_A_const_39 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_40 any

var A_arbace_cpp_sema__init_part3_A_const_41 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_42 any

var A_arbace_cpp_sema__init_part3_A_const_43 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_44 any

var A_arbace_cpp_sema__init_part3_A_const_45 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_46 any

var A_arbace_cpp_sema__init_part3_A_const_47 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_48 any

var A_arbace_cpp_sema__init_part3_A_const_49 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_50 any

var A_arbace_cpp_sema__init_part3_A_const_51 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_52 any

var A_arbace_cpp_sema__init_part3_A_const_53 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_54 any

var A_arbace_cpp_sema__init_part3_A_const_55 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_56 any

var A_arbace_cpp_sema__init_part3_A_const_57 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_58 any

var A_arbace_cpp_sema__init_part3_A_const_59 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_60 any

var A_arbace_cpp_sema__init_part3_A_const_61 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_62 any

var A_arbace_cpp_sema__init_part3_A_const_63 any

var A_arbace_cpp_sema__init_part3_A_const_64 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_65 any

var A_arbace_cpp_sema__init_part3_A_const_66 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_67 any

var A_arbace_cpp_sema__init_part3_A_const_68 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_69 any

var A_arbace_cpp_sema__init_part3_A_const_70 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_71 any

var A_arbace_cpp_sema__init_part3_A_const_72 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_73 any

var A_arbace_cpp_sema__init_part3_A_const_74 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_75 any

var A_arbace_cpp_sema__init_part3_A_const_76 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_77 any

var A_arbace_cpp_sema__init_part3_A_const_78 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_79 any

var A_arbace_cpp_sema__init_part3_A_const_80 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_81 any

var A_arbace_cpp_sema__init_part3_A_const_82 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_83 any

var A_arbace_cpp_sema__init_part3_A_const_84 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_85 any

var A_arbace_cpp_sema__init_part3_A_const_86 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_87 any

var A_arbace_cpp_sema__init_part3_A_const_88 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_89 any

var A_arbace_cpp_sema__init_part3_A_const_90 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_91 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_92 any

var A_arbace_cpp_sema__init_part3_A_const_93 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_94 any

var A_arbace_cpp_sema__init_part3_A_const_95 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_96 any

var A_arbace_cpp_sema__init_part3_A_const_97 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_98 any

var A_arbace_cpp_sema__init_part3_A_const_99 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_100 any

var A_arbace_cpp_sema__init_part3_A_const_101 any

var A_arbace_cpp_sema__init_part3_A_const_102 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_103 any

var A_arbace_cpp_sema__init_part3_A_const_104 any

var A_arbace_cpp_sema__init_part3_A_const_105 any

var A_arbace_cpp_sema__init_part3_A_const_106 any

var A_arbace_cpp_sema__init_part3_A_const_107 any

var A_arbace_cpp_sema__init_part3_A_const_108 any

var A_arbace_cpp_sema__init_part3_A_const_109 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_110 any

var A_arbace_cpp_sema__init_part3_A_const_111 any

var A_arbace_cpp_sema__init_part3_A_const_112 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_113 any

var A_arbace_cpp_sema__init_part3_A_const_114 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_115 any

var A_arbace_cpp_sema__init_part3_A_const_116 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_117 any

var A_arbace_cpp_sema__init_part3_A_const_118 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_119 any

var A_arbace_cpp_sema__init_part3_A_const_120 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_121 any

var A_arbace_cpp_sema__init_part3_A_const_122 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_123 any

var A_arbace_cpp_sema__init_part3_A_const_124 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_125 any

var A_arbace_cpp_sema__init_part3_A_const_126 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_127 any

var A_arbace_cpp_sema__init_part3_A_const_128 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_129 any

var A_arbace_cpp_sema__init_part3_A_const_130 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_131 any

var A_arbace_cpp_sema__init_part3_A_const_132 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_133 any

var A_arbace_cpp_sema__init_part3_A_const_134 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_135 any

var A_arbace_cpp_sema__init_part3_A_const_136 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_137 any

var A_arbace_cpp_sema__init_part3_A_const_138 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_139 any

var A_arbace_cpp_sema__init_part3_A_const_140 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_141 any

var A_arbace_cpp_sema__init_part3_A_const_142 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_143 any

var A_arbace_cpp_sema__init_part3_A_const_144 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_145 any

var A_arbace_cpp_sema__init_part3_A_const_146 any

var A_arbace_cpp_sema__init_part3_A_const_147 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_148 any

var A_arbace_cpp_sema__init_part3_A_const_149 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_150 any

var A_arbace_cpp_sema__init_part3_A_const_151 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_152 any

var A_arbace_cpp_sema__init_part3_A_const_153 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_154 any

var A_arbace_cpp_sema__init_part3_A_const_155 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_156 any

var A_arbace_cpp_sema__init_part3_A_const_157 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_158 any

var A_arbace_cpp_sema__init_part3_A_const_159 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_160 any

var A_arbace_cpp_sema__init_part3_A_const_161 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_162 any

var A_arbace_cpp_sema__init_part3_A_const_163 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_164 any

var A_arbace_cpp_sema__init_part3_A_const_165 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_166 any

var A_arbace_cpp_sema__init_part3_A_const_167 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_168 any

var A_arbace_cpp_sema__init_part3_A_const_169 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_170 any

var A_arbace_cpp_sema__init_part3_A_const_171 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_172 any

var A_arbace_cpp_sema__init_part3_A_const_173 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_174 any

var A_arbace_cpp_sema__init_part3_A_const_175 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_176 any

var A_arbace_cpp_sema__init_part3_A_const_177 any

var A_arbace_cpp_sema__init_part3_A_const_178 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_179 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_180 any

var A_arbace_cpp_sema__init_part3_A_const_181 any

var A_arbace_cpp_sema__init_part3_A_const_182 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_183 any

var A_arbace_cpp_sema__init_part3_A_const_184 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_185 any

var A_arbace_cpp_sema__init_part3_A_const_186 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_187 any

var A_arbace_cpp_sema__init_part3_A_const_188 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_189 any

var A_arbace_cpp_sema__init_part3_A_const_190 any

var A_arbace_cpp_sema__init_part3_A_const_191 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_192 any

var A_arbace_cpp_sema__init_part3_A_const_193 any

var A_arbace_cpp_sema__init_part3_A_const_194 any

var A_arbace_cpp_sema__init_part3_A_const_195 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_196 any

var A_arbace_cpp_sema__init_part3_A_const_197 *lang.Var

var A_arbace_cpp_sema__init_part3_A_const_198 any

var A_arbace_cpp_sema__init_part3_A_init jrt.ClassInit

func A_arbace_cpp_sema__init_part3_A_Init() { if !A_arbace_cpp_sema__init_part3_A_init.Done() { A_arbace_cpp_sema__init_part3_A_init.Run(A_arbace_cpp_sema__init_part3_A_clinit) } }

func A_arbace_cpp_sema__init_part3_A_clinit() { A_arbace_cpp_sema__init_part3_A_clinit_p0(); A_arbace_cpp_sema__init_part3_A_clinit_p1(); A_arbace_cpp_sema__init_part3_A_clinit_p2(); A_arbace_cpp_sema__init_part3_A_clinit_p3() }

func A_arbace_cpp_sema__init_part3_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_sema__init_part3_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1507, 285); A_arbace_cpp_sema__init_part3_A_const_0 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[97]); A_arbace_cpp_sema__init_part3_A_const_1 = A_arbace_cpp_sema__init_part3_A_const_pool.A[98]; A_arbace_cpp_sema__init_part3_A_const_2 = A_arbace_cpp_sema__init_part3_A_const_pool.A[99]; A_arbace_cpp_sema__init_part3_A_const_3 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[100]); A_arbace_cpp_sema__init_part3_A_const_4 = A_arbace_cpp_sema__init_part3_A_const_pool.A[101]; A_arbace_cpp_sema__init_part3_A_const_5 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[102]); A_arbace_cpp_sema__init_part3_A_const_6 = A_arbace_cpp_sema__init_part3_A_const_pool.A[103]; A_arbace_cpp_sema__init_part3_A_const_7 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[104]); A_arbace_cpp_sema__init_part3_A_const_8 = A_arbace_cpp_sema__init_part3_A_const_pool.A[105]; A_arbace_cpp_sema__init_part3_A_const_9 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[106]); A_arbace_cpp_sema__init_part3_A_const_10 = A_arbace_cpp_sema__init_part3_A_const_pool.A[107]; A_arbace_cpp_sema__init_part3_A_const_11 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[108]); A_arbace_cpp_sema__init_part3_A_const_12 = A_arbace_cpp_sema__init_part3_A_const_pool.A[109] }

func A_arbace_cpp_sema__init_part3_A_clinit_p1() { A_arbace_cpp_sema__init_part3_A_const_13 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[110]); A_arbace_cpp_sema__init_part3_A_const_14 = A_arbace_cpp_sema__init_part3_A_const_pool.A[111]; A_arbace_cpp_sema__init_part3_A_const_15 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[112]); A_arbace_cpp_sema__init_part3_A_const_16 = A_arbace_cpp_sema__init_part3_A_const_pool.A[113]; A_arbace_cpp_sema__init_part3_A_const_17 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[114]); A_arbace_cpp_sema__init_part3_A_const_18 = A_arbace_cpp_sema__init_part3_A_const_pool.A[115]; A_arbace_cpp_sema__init_part3_A_const_19 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[116]); A_arbace_cpp_sema__init_part3_A_const_20 = A_arbace_cpp_sema__init_part3_A_const_pool.A[117]; A_arbace_cpp_sema__init_part3_A_const_21 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[118]); A_arbace_cpp_sema__init_part3_A_const_22 = A_arbace_cpp_sema__init_part3_A_const_pool.A[119]; A_arbace_cpp_sema__init_part3_A_const_23 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[120]); A_arbace_cpp_sema__init_part3_A_const_24 = A_arbace_cpp_sema__init_part3_A_const_pool.A[121]; A_arbace_cpp_sema__init_part3_A_const_25 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[122]) }

func A_arbace_cpp_sema__init_part3_A_clinit_p2() { A_arbace_cpp_sema__init_part3_A_const_26 = A_arbace_cpp_sema__init_part3_A_const_pool.A[123]; A_arbace_cpp_sema__init_part3_A_const_27 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[124]); A_arbace_cpp_sema__init_part3_A_const_28 = A_arbace_cpp_sema__init_part3_A_const_pool.A[125]; A_arbace_cpp_sema__init_part3_A_const_29 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[126]); A_arbace_cpp_sema__init_part3_A_const_30 = A_arbace_cpp_sema__init_part3_A_const_pool.A[127]; A_arbace_cpp_sema__init_part3_A_const_31 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[128]); A_arbace_cpp_sema__init_part3_A_const_32 = A_arbace_cpp_sema__init_part3_A_const_pool.A[129]; A_arbace_cpp_sema__init_part3_A_const_33 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[130]); A_arbace_cpp_sema__init_part3_A_const_34 = A_arbace_cpp_sema__init_part3_A_const_pool.A[131]; A_arbace_cpp_sema__init_part3_A_const_35 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[132]); A_arbace_cpp_sema__init_part3_A_const_36 = A_arbace_cpp_sema__init_part3_A_const_pool.A[133] }

func A_arbace_cpp_sema__init_part3_A_clinit_p3() { var tmp1 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp1 = A_arbace_cpp_sema__init_part1_A_const_72; A_arbace_cpp_sema__init_part3_A_const_37 = tmp1; A_arbace_cpp_sema__init_part3_A_const_38 = A_arbace_cpp_sema__init_part3_A_const_pool.A[134]; A_arbace_cpp_sema__init_part3_A_const_39 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[135]); A_arbace_cpp_sema__init_part3_A_const_40 = A_arbace_cpp_sema__init_part3_A_const_pool.A[136]; A_arbace_cpp_sema__init_part3_A_const_41 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[137]); A_arbace_cpp_sema__init_part3_A_const_42 = A_arbace_cpp_sema__init_part3_A_const_pool.A[138]; A_arbace_cpp_sema__init_part3_A_const_43 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[139]); A_arbace_cpp_sema__init_part3_A_const_44 = A_arbace_cpp_sema__init_part3_A_const_pool.A[140]; A_arbace_cpp_sema__init_part3_A_const_45 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[141]); A_arbace_cpp_sema__init_part3_A_const_46 = A_arbace_cpp_sema__init_part3_A_const_pool.A[142]; var tmp2 *lang.Var; A_arbace_cpp_sema__init_part2_A_Init(); tmp2 = A_arbace_cpp_sema__init_part2_A_const_182; A_arbace_cpp_sema__init_part3_A_const_47 = tmp2; A_arbace_cpp_sema__init_part3_A_const_48 = A_arbace_cpp_sema__init_part3_A_const_pool.A[143]; A_arbace_cpp_sema__init_part3_A_const_49 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[144]); A_arbace_cpp_sema__init_part3_A_const_50 = A_arbace_cpp_sema__init_part3_A_const_pool.A[145]; var tmp3 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp3 = A_arbace_cpp_sema__init_part1_A_const_151; A_arbace_cpp_sema__init_part3_A_const_51 = tmp3; A_arbace_cpp_sema__init_part3_A_const_52 = A_arbace_cpp_sema__init_part3_A_const_pool.A[146]; A_arbace_cpp_sema__init_part3_A_const_53 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[147]); A_arbace_cpp_sema__init_part3_A_const_54 = A_arbace_cpp_sema__init_part3_A_const_pool.A[148]; A_arbace_cpp_sema__init_part3_A_const_55 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[149]); A_arbace_cpp_sema__init_part3_A_const_56 = A_arbace_cpp_sema__init_part3_A_const_pool.A[150]; var tmp4 *lang.Var; A_arbace_cpp_sema__init_part2_A_Init(); tmp4 = A_arbace_cpp_sema__init_part2_A_const_64; A_arbace_cpp_sema__init_part3_A_const_57 = tmp4; A_arbace_cpp_sema__init_part3_A_const_58 = A_arbace_cpp_sema__init_part3_A_const_pool.A[151]; A_arbace_cpp_sema__init_part3_A_const_59 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[152]); A_arbace_cpp_sema__init_part3_A_const_60 = A_arbace_cpp_sema__init_part3_A_const_pool.A[153]; var tmp5 *lang.Var; A_arbace_cpp_sema__init_part2_A_Init(); tmp5 = A_arbace_cpp_sema__init_part2_A_const_66; A_arbace_cpp_sema__init_part3_A_const_61 = tmp5; A_arbace_cpp_sema__init_part3_A_const_62 = A_arbace_cpp_sema__init_part3_A_const_pool.A[154]; A_arbace_cpp_sema__init_part3_A_const_63 = A_arbace_cpp_sema__init_part3_A_const_pool.A[155]; A_arbace_cpp_sema__init_part3_A_const_64 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[156]); A_arbace_cpp_sema__init_part3_A_const_65 = A_arbace_cpp_sema__init_part3_A_const_pool.A[157]; A_arbace_cpp_sema__init_part3_A_const_66 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[158]); A_arbace_cpp_sema__init_part3_A_const_67 = A_arbace_cpp_sema__init_part3_A_const_pool.A[159]; A_arbace_cpp_sema__init_part3_A_const_68 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[160]); A_arbace_cpp_sema__init_part3_A_const_69 = A_arbace_cpp_sema__init_part3_A_const_pool.A[161]; A_arbace_cpp_sema__init_part3_A_const_70 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[162]); A_arbace_cpp_sema__init_part3_A_const_71 = A_arbace_cpp_sema__init_part3_A_const_pool.A[163]; A_arbace_cpp_sema__init_part3_A_const_72 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[164]); A_arbace_cpp_sema__init_part3_A_const_73 = A_arbace_cpp_sema__init_part3_A_const_pool.A[165]; A_arbace_cpp_sema__init_part3_A_const_74 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[166]); A_arbace_cpp_sema__init_part3_A_const_75 = A_arbace_cpp_sema__init_part3_A_const_pool.A[167]; A_arbace_cpp_sema__init_part3_A_const_76 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[168]); A_arbace_cpp_sema__init_part3_A_const_77 = A_arbace_cpp_sema__init_part3_A_const_pool.A[169]; A_arbace_cpp_sema__init_part3_A_const_78 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[170]); A_arbace_cpp_sema__init_part3_A_const_79 = A_arbace_cpp_sema__init_part3_A_const_pool.A[171]; A_arbace_cpp_sema__init_part3_A_const_80 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[172]); A_arbace_cpp_sema__init_part3_A_const_81 = A_arbace_cpp_sema__init_part3_A_const_pool.A[173]; A_arbace_cpp_sema__init_part3_A_const_82 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[174]); A_arbace_cpp_sema__init_part3_A_const_83 = A_arbace_cpp_sema__init_part3_A_const_pool.A[175]; A_arbace_cpp_sema__init_part3_A_const_84 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[176]); A_arbace_cpp_sema__init_part3_A_const_85 = A_arbace_cpp_sema__init_part3_A_const_pool.A[177]; A_arbace_cpp_sema__init_part3_A_const_86 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[178]); A_arbace_cpp_sema__init_part3_A_const_87 = A_arbace_cpp_sema__init_part3_A_const_pool.A[179]; A_arbace_cpp_sema__init_part3_A_const_88 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[180]); A_arbace_cpp_sema__init_part3_A_const_89 = A_arbace_cpp_sema__init_part3_A_const_pool.A[181]; A_arbace_cpp_sema__init_part3_A_const_90 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[182]); A_arbace_cpp_sema__init_part3_A_const_91 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[183]); A_arbace_cpp_sema__init_part3_A_const_92 = A_arbace_cpp_sema__init_part3_A_const_pool.A[184]; A_arbace_cpp_sema__init_part3_A_const_93 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[185]); A_arbace_cpp_sema__init_part3_A_const_94 = A_arbace_cpp_sema__init_part3_A_const_pool.A[186]; A_arbace_cpp_sema__init_part3_A_const_95 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[187]); A_arbace_cpp_sema__init_part3_A_const_96 = A_arbace_cpp_sema__init_part3_A_const_pool.A[188]; A_arbace_cpp_sema__init_part3_A_const_97 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[189]); A_arbace_cpp_sema__init_part3_A_const_98 = A_arbace_cpp_sema__init_part3_A_const_pool.A[190]; A_arbace_cpp_sema__init_part3_A_const_99 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[191]); A_arbace_cpp_sema__init_part3_A_const_100 = A_arbace_cpp_sema__init_part3_A_const_pool.A[192]; A_arbace_cpp_sema__init_part3_A_const_101 = A_arbace_cpp_sema__init_part3_A_const_pool.A[193]; A_arbace_cpp_sema__init_part3_A_const_102 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[194]); A_arbace_cpp_sema__init_part3_A_const_103 = A_arbace_cpp_sema__init_part3_A_const_pool.A[195]; A_arbace_cpp_sema__init_part3_A_const_104 = A_arbace_cpp_sema__init_part3_A_const_pool.A[196]; A_arbace_cpp_sema__init_part3_A_const_105 = A_arbace_cpp_sema__init_part3_A_const_pool.A[197]; A_arbace_cpp_sema__init_part3_A_const_106 = A_arbace_cpp_sema__init_part3_A_const_pool.A[198]; A_arbace_cpp_sema__init_part3_A_const_107 = A_arbace_cpp_sema__init_part3_A_const_pool.A[199]; A_arbace_cpp_sema__init_part3_A_const_108 = A_arbace_cpp_sema__init_part3_A_const_pool.A[200]; A_arbace_cpp_sema__init_part3_A_const_109 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[201]); A_arbace_cpp_sema__init_part3_A_const_110 = A_arbace_cpp_sema__init_part3_A_const_pool.A[202]; A_arbace_cpp_sema__init_part3_A_const_111 = A_arbace_cpp_sema__init_part3_A_const_pool.A[203]; A_arbace_cpp_sema__init_part3_A_const_112 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[204]); A_arbace_cpp_sema__init_part3_A_const_113 = A_arbace_cpp_sema__init_part3_A_const_pool.A[205]; A_arbace_cpp_sema__init_part3_A_const_114 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[206]); A_arbace_cpp_sema__init_part3_A_const_115 = A_arbace_cpp_sema__init_part3_A_const_pool.A[207]; A_arbace_cpp_sema__init_part3_A_const_116 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[208]); A_arbace_cpp_sema__init_part3_A_const_117 = A_arbace_cpp_sema__init_part3_A_const_pool.A[209]; A_arbace_cpp_sema__init_part3_A_const_118 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[210]); A_arbace_cpp_sema__init_part3_A_const_119 = A_arbace_cpp_sema__init_part3_A_const_pool.A[211]; A_arbace_cpp_sema__init_part3_A_const_120 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[212]); A_arbace_cpp_sema__init_part3_A_const_121 = A_arbace_cpp_sema__init_part3_A_const_pool.A[213]; A_arbace_cpp_sema__init_part3_A_const_122 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[214]); A_arbace_cpp_sema__init_part3_A_const_123 = A_arbace_cpp_sema__init_part3_A_const_pool.A[215]; A_arbace_cpp_sema__init_part3_A_const_124 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[216]); A_arbace_cpp_sema__init_part3_A_const_125 = A_arbace_cpp_sema__init_part3_A_const_pool.A[217]; A_arbace_cpp_sema__init_part3_A_const_126 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[218]); A_arbace_cpp_sema__init_part3_A_const_127 = A_arbace_cpp_sema__init_part3_A_const_pool.A[219]; A_arbace_cpp_sema__init_part3_A_const_128 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[220]); A_arbace_cpp_sema__init_part3_A_const_129 = A_arbace_cpp_sema__init_part3_A_const_pool.A[221]; A_arbace_cpp_sema__init_part3_A_const_130 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[222]); A_arbace_cpp_sema__init_part3_A_const_131 = A_arbace_cpp_sema__init_part3_A_const_pool.A[223]; A_arbace_cpp_sema__init_part3_A_const_132 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[224]); A_arbace_cpp_sema__init_part3_A_const_133 = A_arbace_cpp_sema__init_part3_A_const_pool.A[225]; A_arbace_cpp_sema__init_part3_A_const_134 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[226]); A_arbace_cpp_sema__init_part3_A_const_135 = A_arbace_cpp_sema__init_part3_A_const_pool.A[227]; A_arbace_cpp_sema__init_part3_A_const_136 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[228]); A_arbace_cpp_sema__init_part3_A_const_137 = A_arbace_cpp_sema__init_part3_A_const_pool.A[229]; A_arbace_cpp_sema__init_part3_A_const_138 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[230]); A_arbace_cpp_sema__init_part3_A_const_139 = A_arbace_cpp_sema__init_part3_A_const_pool.A[231]; A_arbace_cpp_sema__init_part3_A_const_140 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[232]); A_arbace_cpp_sema__init_part3_A_const_141 = A_arbace_cpp_sema__init_part3_A_const_pool.A[233]; A_arbace_cpp_sema__init_part3_A_const_142 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[234]); A_arbace_cpp_sema__init_part3_A_const_143 = A_arbace_cpp_sema__init_part3_A_const_pool.A[235]; A_arbace_cpp_sema__init_part3_A_const_144 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[236]); A_arbace_cpp_sema__init_part3_A_const_145 = A_arbace_cpp_sema__init_part3_A_const_pool.A[237]; A_arbace_cpp_sema__init_part3_A_const_146 = A_arbace_cpp_sema__init_part3_A_const_pool.A[238]; var tmp6 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp6 = A_arbace_cpp_sema__init_part1_A_const_153; A_arbace_cpp_sema__init_part3_A_const_147 = tmp6; A_arbace_cpp_sema__init_part3_A_const_148 = A_arbace_cpp_sema__init_part3_A_const_pool.A[239]; A_arbace_cpp_sema__init_part3_A_const_149 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[240]); A_arbace_cpp_sema__init_part3_A_const_150 = A_arbace_cpp_sema__init_part3_A_const_pool.A[241]; A_arbace_cpp_sema__init_part3_A_const_151 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[242]); A_arbace_cpp_sema__init_part3_A_const_152 = A_arbace_cpp_sema__init_part3_A_const_pool.A[243]; A_arbace_cpp_sema__init_part3_A_const_153 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[244]); A_arbace_cpp_sema__init_part3_A_const_154 = A_arbace_cpp_sema__init_part3_A_const_pool.A[245]; A_arbace_cpp_sema__init_part3_A_const_155 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[246]); A_arbace_cpp_sema__init_part3_A_const_156 = A_arbace_cpp_sema__init_part3_A_const_pool.A[247]; A_arbace_cpp_sema__init_part3_A_const_157 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[248]); A_arbace_cpp_sema__init_part3_A_const_158 = A_arbace_cpp_sema__init_part3_A_const_pool.A[249]; A_arbace_cpp_sema__init_part3_A_const_159 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[250]); A_arbace_cpp_sema__init_part3_A_const_160 = A_arbace_cpp_sema__init_part3_A_const_pool.A[251]; A_arbace_cpp_sema__init_part3_A_const_161 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[252]); A_arbace_cpp_sema__init_part3_A_const_162 = A_arbace_cpp_sema__init_part3_A_const_pool.A[253]; var tmp7 *lang.Var; A_arbace_cpp_sema__init_part2_A_Init(); tmp7 = A_arbace_cpp_sema__init_part2_A_const_163; A_arbace_cpp_sema__init_part3_A_const_163 = tmp7; A_arbace_cpp_sema__init_part3_A_const_164 = A_arbace_cpp_sema__init_part3_A_const_pool.A[254]; A_arbace_cpp_sema__init_part3_A_const_165 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[255]); A_arbace_cpp_sema__init_part3_A_const_166 = A_arbace_cpp_sema__init_part3_A_const_pool.A[256]; A_arbace_cpp_sema__init_part3_A_const_167 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[257]); A_arbace_cpp_sema__init_part3_A_const_168 = A_arbace_cpp_sema__init_part3_A_const_pool.A[258]; A_arbace_cpp_sema__init_part3_A_const_169 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[259]); A_arbace_cpp_sema__init_part3_A_const_170 = A_arbace_cpp_sema__init_part3_A_const_pool.A[260]; A_arbace_cpp_sema__init_part3_A_const_171 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[261]); A_arbace_cpp_sema__init_part3_A_const_172 = A_arbace_cpp_sema__init_part3_A_const_pool.A[262]; A_arbace_cpp_sema__init_part3_A_const_173 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[263]); A_arbace_cpp_sema__init_part3_A_const_174 = A_arbace_cpp_sema__init_part3_A_const_pool.A[264]; A_arbace_cpp_sema__init_part3_A_const_175 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[265]); A_arbace_cpp_sema__init_part3_A_const_176 = A_arbace_cpp_sema__init_part3_A_const_pool.A[266]; A_arbace_cpp_sema__init_part3_A_const_177 = A_arbace_cpp_sema__init_part3_A_const_pool.A[267]; A_arbace_cpp_sema__init_part3_A_const_178 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[268]); var tmp8 *lang.Var; A_arbace_cpp_sema__init_part0_A_Init(); tmp8 = A_arbace_cpp_sema__init_part0_A_const_9; A_arbace_cpp_sema__init_part3_A_const_179 = tmp8; var tmp9 any; A_arbace_cpp_sema__init_part0_A_Init(); tmp9 = A_arbace_cpp_sema__init_part0_A_const_22; A_arbace_cpp_sema__init_part3_A_const_180 = tmp9; A_arbace_cpp_sema__init_part3_A_const_181 = A_arbace_cpp_sema__init_part3_A_const_pool.A[269]; A_arbace_cpp_sema__init_part3_A_const_182 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[270]); A_arbace_cpp_sema__init_part3_A_const_183 = A_arbace_cpp_sema__init_part3_A_const_pool.A[271]; A_arbace_cpp_sema__init_part3_A_const_184 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[272]); A_arbace_cpp_sema__init_part3_A_const_185 = A_arbace_cpp_sema__init_part3_A_const_pool.A[273]; A_arbace_cpp_sema__init_part3_A_const_186 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[274]); A_arbace_cpp_sema__init_part3_A_const_187 = A_arbace_cpp_sema__init_part3_A_const_pool.A[275]; var tmp10 *lang.Var; A_arbace_cpp_sema__init_part0_A_Init(); tmp10 = A_arbace_cpp_sema__init_part0_A_const_117; A_arbace_cpp_sema__init_part3_A_const_188 = tmp10; A_arbace_cpp_sema__init_part3_A_const_189 = A_arbace_cpp_sema__init_part3_A_const_pool.A[276]; A_arbace_cpp_sema__init_part3_A_const_190 = A_arbace_cpp_sema__init_part3_A_const_pool.A[277]; A_arbace_cpp_sema__init_part3_A_const_191 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[278]); A_arbace_cpp_sema__init_part3_A_const_192 = A_arbace_cpp_sema__init_part3_A_const_pool.A[279]; A_arbace_cpp_sema__init_part3_A_const_193 = A_arbace_cpp_sema__init_part3_A_const_pool.A[280]; A_arbace_cpp_sema__init_part3_A_const_194 = A_arbace_cpp_sema__init_part3_A_const_pool.A[281]; A_arbace_cpp_sema__init_part3_A_const_195 = lang.Var_Cast(A_arbace_cpp_sema__init_part3_A_const_pool.A[282]); A_arbace_cpp_sema__init_part3_A_const_196 = A_arbace_cpp_sema__init_part3_A_const_pool.A[283]; var tmp11 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp11 = A_arbace_cpp_sema__init_part1_A_const_60; A_arbace_cpp_sema__init_part3_A_const_197 = tmp11; A_arbace_cpp_sema__init_part3_A_const_198 = A_arbace_cpp_sema__init_part3_A_const_pool.A[284] }

func A_arbace_cpp_sema__init_part3_A_New() *A_arbace_cpp_sema__init_part3_A { A_arbace_cpp_sema__init_part3_A_Init(); t := &A_arbace_cpp_sema__init_part3_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_sema__init_part3_A) Ctor() {}

func (t *A_arbace_cpp_sema__init_part3_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_sema__init_part3_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_sema__init_part3_A_class }

func (t *A_arbace_cpp_sema__init_part3_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_sema__init_part3_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_sema__init_part3_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_sema__init_part3_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_sema__init_part3_A); return ok }

func A_arbace_cpp_sema__init_part3_A_Cast(x any) *A_arbace_cpp_sema__init_part3_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_sema__init_part3_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_sema__init_part3_A_class)) }; return v }



type A_arbace_cpp_sema__init_part4_A struct{ jrt.Object }

var A_arbace_cpp_sema__init_part4_A_const_pool *jrt.RefArray

var A_arbace_cpp_sema__init_part4_A_const_0 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_1 any

var A_arbace_cpp_sema__init_part4_A_const_2 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_3 any

var A_arbace_cpp_sema__init_part4_A_const_4 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_5 any

var A_arbace_cpp_sema__init_part4_A_const_6 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_7 any

var A_arbace_cpp_sema__init_part4_A_const_8 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_9 any

var A_arbace_cpp_sema__init_part4_A_const_10 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_11 any

var A_arbace_cpp_sema__init_part4_A_const_12 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_13 any

var A_arbace_cpp_sema__init_part4_A_const_14 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_15 any

var A_arbace_cpp_sema__init_part4_A_const_16 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_17 any

var A_arbace_cpp_sema__init_part4_A_const_18 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_19 any

var A_arbace_cpp_sema__init_part4_A_const_20 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_21 any

var A_arbace_cpp_sema__init_part4_A_const_22 any

var A_arbace_cpp_sema__init_part4_A_const_23 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_24 any

var A_arbace_cpp_sema__init_part4_A_const_25 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_26 any

var A_arbace_cpp_sema__init_part4_A_const_27 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_28 any

var A_arbace_cpp_sema__init_part4_A_const_29 any

var A_arbace_cpp_sema__init_part4_A_const_30 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_31 any

var A_arbace_cpp_sema__init_part4_A_const_32 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_33 any

var A_arbace_cpp_sema__init_part4_A_const_34 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_35 any

var A_arbace_cpp_sema__init_part4_A_const_36 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_37 any

var A_arbace_cpp_sema__init_part4_A_const_38 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_39 any

var A_arbace_cpp_sema__init_part4_A_const_40 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_41 any

var A_arbace_cpp_sema__init_part4_A_const_42 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_43 any

var A_arbace_cpp_sema__init_part4_A_const_44 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_45 any

var A_arbace_cpp_sema__init_part4_A_const_46 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_47 any

var A_arbace_cpp_sema__init_part4_A_const_48 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_49 any

var A_arbace_cpp_sema__init_part4_A_const_50 any

var A_arbace_cpp_sema__init_part4_A_const_51 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_52 any

var A_arbace_cpp_sema__init_part4_A_const_53 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_54 any

var A_arbace_cpp_sema__init_part4_A_const_55 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_56 any

var A_arbace_cpp_sema__init_part4_A_const_57 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_58 any

var A_arbace_cpp_sema__init_part4_A_const_59 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_60 any

var A_arbace_cpp_sema__init_part4_A_const_61 *lang.Var

var A_arbace_cpp_sema__init_part4_A_const_62 any

var A_arbace_cpp_sema__init_part4_A_init jrt.ClassInit

func A_arbace_cpp_sema__init_part4_A_Init() { if !A_arbace_cpp_sema__init_part4_A_init.Done() { A_arbace_cpp_sema__init_part4_A_init.Run(A_arbace_cpp_sema__init_part4_A_clinit) } }

func A_arbace_cpp_sema__init_part4_A_clinit() { A_arbace_cpp_sema__init_part4_A_clinit_p0(); A_arbace_cpp_sema__init_part4_A_clinit_p1() }

func A_arbace_cpp_sema__init_part4_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_sema__init_part4_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1583, 87); A_arbace_cpp_sema__init_part4_A_const_0 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[33]); A_arbace_cpp_sema__init_part4_A_const_1 = A_arbace_cpp_sema__init_part4_A_const_pool.A[34] }

func A_arbace_cpp_sema__init_part4_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_cpp_sema__init_part3_A_Init(); tmp1 = A_arbace_cpp_sema__init_part3_A_const_53; A_arbace_cpp_sema__init_part4_A_const_2 = tmp1; A_arbace_cpp_sema__init_part4_A_const_3 = A_arbace_cpp_sema__init_part4_A_const_pool.A[35]; var tmp2 *lang.Var; A_arbace_cpp_sema__init_part3_A_Init(); tmp2 = A_arbace_cpp_sema__init_part3_A_const_153; A_arbace_cpp_sema__init_part4_A_const_4 = tmp2; A_arbace_cpp_sema__init_part4_A_const_5 = A_arbace_cpp_sema__init_part4_A_const_pool.A[36]; A_arbace_cpp_sema__init_part4_A_const_6 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[37]); A_arbace_cpp_sema__init_part4_A_const_7 = A_arbace_cpp_sema__init_part4_A_const_pool.A[38]; A_arbace_cpp_sema__init_part4_A_const_8 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[39]); A_arbace_cpp_sema__init_part4_A_const_9 = A_arbace_cpp_sema__init_part4_A_const_pool.A[40]; A_arbace_cpp_sema__init_part4_A_const_10 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[41]); A_arbace_cpp_sema__init_part4_A_const_11 = A_arbace_cpp_sema__init_part4_A_const_pool.A[42]; A_arbace_cpp_sema__init_part4_A_const_12 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[43]); A_arbace_cpp_sema__init_part4_A_const_13 = A_arbace_cpp_sema__init_part4_A_const_pool.A[44]; A_arbace_cpp_sema__init_part4_A_const_14 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[45]); A_arbace_cpp_sema__init_part4_A_const_15 = A_arbace_cpp_sema__init_part4_A_const_pool.A[46]; var tmp3 *lang.Var; A_arbace_cpp_sema__init_part3_A_Init(); tmp3 = A_arbace_cpp_sema__init_part3_A_const_88; A_arbace_cpp_sema__init_part4_A_const_16 = tmp3; A_arbace_cpp_sema__init_part4_A_const_17 = A_arbace_cpp_sema__init_part4_A_const_pool.A[47]; A_arbace_cpp_sema__init_part4_A_const_18 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[48]); A_arbace_cpp_sema__init_part4_A_const_19 = A_arbace_cpp_sema__init_part4_A_const_pool.A[49]; A_arbace_cpp_sema__init_part4_A_const_20 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[50]); A_arbace_cpp_sema__init_part4_A_const_21 = A_arbace_cpp_sema__init_part4_A_const_pool.A[51]; A_arbace_cpp_sema__init_part4_A_const_22 = A_arbace_cpp_sema__init_part4_A_const_pool.A[52]; var tmp4 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp4 = A_arbace_cpp_sema__init_part1_A_const_153; A_arbace_cpp_sema__init_part4_A_const_23 = tmp4; A_arbace_cpp_sema__init_part4_A_const_24 = A_arbace_cpp_sema__init_part4_A_const_pool.A[53]; A_arbace_cpp_sema__init_part4_A_const_25 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[54]); A_arbace_cpp_sema__init_part4_A_const_26 = A_arbace_cpp_sema__init_part4_A_const_pool.A[55]; A_arbace_cpp_sema__init_part4_A_const_27 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[56]); A_arbace_cpp_sema__init_part4_A_const_28 = A_arbace_cpp_sema__init_part4_A_const_pool.A[57]; A_arbace_cpp_sema__init_part4_A_const_29 = A_arbace_cpp_sema__init_part4_A_const_pool.A[58]; A_arbace_cpp_sema__init_part4_A_const_30 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[59]); A_arbace_cpp_sema__init_part4_A_const_31 = A_arbace_cpp_sema__init_part4_A_const_pool.A[60]; var tmp5 *lang.Var; A_arbace_cpp_sema__init_part3_A_Init(); tmp5 = A_arbace_cpp_sema__init_part3_A_const_149; A_arbace_cpp_sema__init_part4_A_const_32 = tmp5; A_arbace_cpp_sema__init_part4_A_const_33 = A_arbace_cpp_sema__init_part4_A_const_pool.A[61]; A_arbace_cpp_sema__init_part4_A_const_34 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[62]); A_arbace_cpp_sema__init_part4_A_const_35 = A_arbace_cpp_sema__init_part4_A_const_pool.A[63]; var tmp6 *lang.Var; A_arbace_cpp_sema__init_part1_A_Init(); tmp6 = A_arbace_cpp_sema__init_part1_A_const_151; A_arbace_cpp_sema__init_part4_A_const_36 = tmp6; A_arbace_cpp_sema__init_part4_A_const_37 = A_arbace_cpp_sema__init_part4_A_const_pool.A[64]; var tmp7 *lang.Var; A_arbace_cpp_sema__init_part3_A_Init(); tmp7 = A_arbace_cpp_sema__init_part3_A_const_55; A_arbace_cpp_sema__init_part4_A_const_38 = tmp7; A_arbace_cpp_sema__init_part4_A_const_39 = A_arbace_cpp_sema__init_part4_A_const_pool.A[65]; var tmp8 *lang.Var; A_arbace_cpp_sema__init_part3_A_Init(); tmp8 = A_arbace_cpp_sema__init_part3_A_const_151; A_arbace_cpp_sema__init_part4_A_const_40 = tmp8; A_arbace_cpp_sema__init_part4_A_const_41 = A_arbace_cpp_sema__init_part4_A_const_pool.A[66]; A_arbace_cpp_sema__init_part4_A_const_42 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[67]); A_arbace_cpp_sema__init_part4_A_const_43 = A_arbace_cpp_sema__init_part4_A_const_pool.A[68]; A_arbace_cpp_sema__init_part4_A_const_44 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[69]); A_arbace_cpp_sema__init_part4_A_const_45 = A_arbace_cpp_sema__init_part4_A_const_pool.A[70]; var tmp9 *lang.Var; A_arbace_cpp_sema__init_part3_A_Init(); tmp9 = A_arbace_cpp_sema__init_part3_A_const_155; A_arbace_cpp_sema__init_part4_A_const_46 = tmp9; A_arbace_cpp_sema__init_part4_A_const_47 = A_arbace_cpp_sema__init_part4_A_const_pool.A[71]; A_arbace_cpp_sema__init_part4_A_const_48 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[72]); A_arbace_cpp_sema__init_part4_A_const_49 = A_arbace_cpp_sema__init_part4_A_const_pool.A[73]; A_arbace_cpp_sema__init_part4_A_const_50 = A_arbace_cpp_sema__init_part4_A_const_pool.A[74]; A_arbace_cpp_sema__init_part4_A_const_51 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[75]); A_arbace_cpp_sema__init_part4_A_const_52 = A_arbace_cpp_sema__init_part4_A_const_pool.A[76]; A_arbace_cpp_sema__init_part4_A_const_53 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[77]); A_arbace_cpp_sema__init_part4_A_const_54 = A_arbace_cpp_sema__init_part4_A_const_pool.A[78]; A_arbace_cpp_sema__init_part4_A_const_55 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[79]); A_arbace_cpp_sema__init_part4_A_const_56 = A_arbace_cpp_sema__init_part4_A_const_pool.A[80]; A_arbace_cpp_sema__init_part4_A_const_57 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[81]); A_arbace_cpp_sema__init_part4_A_const_58 = A_arbace_cpp_sema__init_part4_A_const_pool.A[82]; A_arbace_cpp_sema__init_part4_A_const_59 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[83]); A_arbace_cpp_sema__init_part4_A_const_60 = A_arbace_cpp_sema__init_part4_A_const_pool.A[84]; A_arbace_cpp_sema__init_part4_A_const_61 = lang.Var_Cast(A_arbace_cpp_sema__init_part4_A_const_pool.A[85]); A_arbace_cpp_sema__init_part4_A_const_62 = A_arbace_cpp_sema__init_part4_A_const_pool.A[86] }

func A_arbace_cpp_sema__init_part4_A_New() *A_arbace_cpp_sema__init_part4_A { A_arbace_cpp_sema__init_part4_A_Init(); t := &A_arbace_cpp_sema__init_part4_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_sema__init_part4_A) Ctor() {}

func (t *A_arbace_cpp_sema__init_part4_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_sema__init_part4_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_sema__init_part4_A_class }

func (t *A_arbace_cpp_sema__init_part4_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_sema__init_part4_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_sema__init_part4_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_sema__init_part4_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_sema__init_part4_A); return ok }

func A_arbace_cpp_sema__init_part4_A_Cast(x any) *A_arbace_cpp_sema__init_part4_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_sema__init_part4_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_sema__init_part4_A_class)) }; return v }
