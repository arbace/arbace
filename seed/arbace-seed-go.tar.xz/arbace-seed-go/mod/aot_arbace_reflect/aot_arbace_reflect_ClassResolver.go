//line aot_arbace_reflect_ClassResolver.ae:1
package aot_arbace_reflect

import "arbace/jrt"




type A_arbace_reflect_ClassResolver_A interface{ jrt.Object_I; Is_A_arbace_reflect_ClassResolver_A(); Resolve_class_O__O(p0 any) any }

func A_arbace_reflect_ClassResolver_A_InstanceOf(x any) bool { _, ok := x.(A_arbace_reflect_ClassResolver_A); if !ok && x != nil && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_reflect_ClassResolver_A_class) } }; return ok }

func A_arbace_reflect_ClassResolver_A_Cast(x any) A_arbace_reflect_ClassResolver_A { if x == nil { return nil }; v, ok := x.(A_arbace_reflect_ClassResolver_A); if ok && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_reflect_ClassResolver_A_class) } }; if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_ClassResolver_A_class)) }; return v }
