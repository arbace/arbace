//line j2g_classes.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_reflect_access_flag_A_class, Name: "arbace.reflect$access_flag", Modifiers: 25, Simple: "access_flag", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_access_flag_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_constructor__GT_map_A_class, Name: "arbace.reflect$constructor__GT_map", Modifiers: 25, Simple: "constructor__GT_map", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_declared_constructors_A_class, Name: "arbace.reflect$declared_constructors", Modifiers: 25, Simple: "declared_constructors", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_declared_constructors_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_declared_fields_A_class, Name: "arbace.reflect$declared_fields", Modifiers: 25, Simple: "declared_fields", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_declared_fields_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_declared_methods_A_class, Name: "arbace.reflect$declared_methods", Modifiers: 25, Simple: "declared_methods", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_declared_methods_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_descriptor_class_name_A_class, Name: "arbace.reflect$descriptor_class_name", Modifiers: 25, Simple: "descriptor_class_name", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000010_fn__1939000011_A_class, Name: "arbace.reflect$eval1939000010$fn__1939000011", Modifiers: 25, Simple: "fn__1939000011", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000010_fn__1939000011_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000010_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000014_fn__1939000015_A_class, Name: "arbace.reflect$eval1939000014$fn__1939000015", Modifiers: 25, Simple: "fn__1939000015", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000014_fn__1939000015_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000014_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A_class, Name: "arbace.reflect$eval1939000036$__GT_Constructor__1939000052", Modifiers: 25, Simple: "__GT_Constructor__1939000052", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000036_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A_class, Name: "arbace.reflect$eval1939000036$map__GT_Constructor__1939000054", Modifiers: 25, Simple: "map__GT_Constructor__1939000054", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000036_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000060___GT_Method__1939000078_A_class, Name: "arbace.reflect$eval1939000060$__GT_Method__1939000078", Modifiers: 25, Simple: "__GT_Method__1939000078", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000060___GT_Method__1939000078_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000060_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF6_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A_class, Name: "arbace.reflect$eval1939000060$map__GT_Method__1939000080", Modifiers: 25, Simple: "map__GT_Method__1939000080", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000060_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000086___GT_Field__1939000100_A_class, Name: "arbace.reflect$eval1939000086$__GT_Field__1939000100", Modifiers: 25, Simple: "__GT_Field__1939000100", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000086___GT_Field__1939000100_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000086_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A_class, Name: "arbace.reflect$eval1939000086$map__GT_Field__1939000102", Modifiers: 25, Simple: "map__GT_Field__1939000102", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000086_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A_class, Name: "arbace.reflect$eval1939000108$__GT_JavaReflector__1939000110", Modifiers: 25, Simple: "__GT_JavaReflector__1939000110", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000108_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000121_fn__1939000122_A_class, Name: "arbace.reflect$eval1939000121$fn__1939000122", Modifiers: 25, Simple: "fn__1939000122", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000121_fn__1939000122_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000121_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A_class, Name: "arbace.reflect$eval1939000121$fn__1939000122$G__1939000113__1939000129", Modifiers: 25, Simple: "G__1939000113__1939000129", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000121_fn__1939000122_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A_class, Name: "arbace.reflect$eval1939000121$fn__1939000122$G__1939000114__1939000125", Modifiers: 25, Simple: "G__1939000114__1939000125", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000121_fn__1939000122_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000137_fn__1939000138_A_class, Name: "arbace.reflect$eval1939000137$fn__1939000138", Modifiers: 25, Simple: "fn__1939000138", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000137_fn__1939000138_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000137_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000141_fn__1939000142_A_class, Name: "arbace.reflect$eval1939000141$fn__1939000142", Modifiers: 25, Simple: "fn__1939000142", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000141_fn__1939000142_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000141_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A_class, Name: "arbace.reflect$eval1939000145$__GT_AsmReflector__1939000147", Modifiers: 25, Simple: "__GT_AsmReflector__1939000147", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A", Source: "java.ae", Declaring: &A_arbace_reflect_eval1939000145_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_class, Name: "arbace.reflect$eval659000004$loading__1927001464__auto____659000005", Modifiers: 25, Simple: "loading__1927001464__auto____659000005", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_eval659000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval659000008_fn__659000009_A_class, Name: "arbace.reflect$eval659000008$fn__659000009", Modifiers: 25, Simple: "fn__659000009", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000008_fn__659000009_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_eval659000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval659000020_fn__659000021_A_class, Name: "arbace.reflect$eval659000020$fn__659000021", Modifiers: 25, Simple: "fn__659000021", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000020_fn__659000021_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_eval659000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_class, Name: "arbace.reflect$eval659000020$fn__659000021$G__659000012__659000028", Modifiers: 25, Simple: "G__659000012__659000028", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_eval659000020_fn__659000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_class, Name: "arbace.reflect$eval659000020$fn__659000021$G__659000013__659000024", Modifiers: 25, Simple: "G__659000013__659000024", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_eval659000020_fn__659000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval659000044_fn__659000045_A_class, Name: "arbace.reflect$eval659000044$fn__659000045", Modifiers: 25, Simple: "fn__659000045", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000044_fn__659000045_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_eval659000044_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_class, Name: "arbace.reflect$eval659000044$fn__659000045$G__659000036__659000050", Modifiers: 25, Simple: "G__659000036__659000050", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_eval659000044_fn__659000045_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_class, Name: "arbace.reflect$eval659000044$fn__659000045$G__659000037__659000047", Modifiers: 25, Simple: "G__659000037__659000047", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_eval659000044_fn__659000045_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_field__GT_map_A_class, Name: "arbace.reflect$field__GT_map", Modifiers: 25, Simple: "field__GT_map", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_field__GT_map_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_field_descriptor__GT_class_symbol_A_class, Name: "arbace.reflect$field_descriptor__GT_class_symbol", Modifiers: 25, Simple: "field_descriptor__GT_class_symbol", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_internal_name__GT_class_symbol_A_class, Name: "arbace.reflect$internal_name__GT_class_symbol", Modifiers: 25, Simple: "internal_name__GT_class_symbol", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_method__GT_map_A_class, Name: "arbace.reflect$method__GT_map", Modifiers: 25, Simple: "method__GT_map", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_method__GT_map_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_parse_flags_A_class, Name: "arbace.reflect$parse_flags", Modifiers: 25, Simple: "parse_flags", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_parse_flags_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_parse_flags_fn__1939000032_A_class, Name: "arbace.reflect$parse_flags$fn__1939000032", Modifiers: 25, Simple: "fn__1939000032", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_parse_flags_fn__1939000032_A", Source: "java.ae", Declaring: &A_arbace_reflect_parse_flags_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_reflect_A_class, Name: "arbace.reflect$reflect", Modifiers: 25, Simple: "reflect", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_reflect_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_resource_name_A_class, Name: "arbace.reflect$resource_name", Modifiers: 25, Simple: "resource_name", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_resource_name_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_type_reflect_A_class, Name: "arbace.reflect$type_reflect", Modifiers: 25, Simple: "type_reflect", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_type_reflect_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_type_reflect_fn__659000063_A_class, Name: "arbace.reflect$type_reflect$fn__659000063", Modifiers: 25, Simple: "fn__659000063", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_type_reflect_fn__659000063_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_type_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_class, Name: "arbace.reflect$type_reflect$make_ancestor_map__659000061", Modifiers: 25, Simple: "make_ancestor_map__659000061", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A", Source: "reflect.ae", Declaring: &A_arbace_reflect_type_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_typeref__GT_class_A_class, Name: "arbace.reflect$typeref__GT_class", Modifiers: 25, Simple: "typeref__GT_class", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_typesym_A_class, Name: "arbace.reflect$typesym", Modifiers: 25, Simple: "typesym", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_typesym_A", Source: "java.ae", Declaring: &A_arbace_reflect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_reflect_typesym_fn__1939000019_A_class, Name: "arbace.reflect$typesym$fn__1939000019", Modifiers: 25, Simple: "fn__1939000019", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_typesym_fn__1939000019_A", Source: "java.ae", Declaring: &A_arbace_reflect_typesym_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_reflect_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_A_New()}; return nil }

var A_arbace_reflect_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_A_new}

var A_arbace_reflect_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_A"})

func init() { i := A_arbace_reflect_A_class.Info(); i.IsInstance = A_arbace_reflect_A_InstanceOf; i.Init = A_arbace_reflect_A_Init; i.Table = A_arbace_reflect_A_members }

var A_arbace_reflect_access_flag_A_class *jrt.Class

var A_arbace_reflect_constructor__GT_map_A_class *jrt.Class

var A_arbace_reflect_declared_constructors_A_class *jrt.Class

var A_arbace_reflect_declared_fields_A_class *jrt.Class

var A_arbace_reflect_declared_methods_A_class *jrt.Class

var A_arbace_reflect_descriptor_class_name_A_class *jrt.Class

func A_arbace_reflect_eval1939000010_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000010_A_New()}; return nil }

var A_arbace_reflect_eval1939000010_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000010_A_new}

var A_arbace_reflect_eval1939000010_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000010", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000010", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000010_A"})

func init() { i := A_arbace_reflect_eval1939000010_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000010_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000010_A_members }

var A_arbace_reflect_eval1939000010_fn__1939000011_A_class *jrt.Class

func A_arbace_reflect_eval1939000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000014_A_New()}; return nil }

var A_arbace_reflect_eval1939000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000014_A_new}

var A_arbace_reflect_eval1939000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000014", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000014_A"})

func init() { i := A_arbace_reflect_eval1939000014_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000014_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000014_A_members }

var A_arbace_reflect_eval1939000014_fn__1939000015_A_class *jrt.Class

func A_arbace_reflect_eval1939000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000036_A_New()}; return nil }

var A_arbace_reflect_eval1939000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000036_A_new}

var A_arbace_reflect_eval1939000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000036", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000036_A"})

func init() { i := A_arbace_reflect_eval1939000036_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000036_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000036_A_members }

var A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A_class *jrt.Class

var A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A_class *jrt.Class

func A_arbace_reflect_eval1939000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000060_A_New()}; return nil }

var A_arbace_reflect_eval1939000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000060_A_new}

var A_arbace_reflect_eval1939000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000060", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000060_A"})

func init() { i := A_arbace_reflect_eval1939000060_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000060_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000060_A_members }

var A_arbace_reflect_eval1939000060___GT_Method__1939000078_A_class *jrt.Class

var A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A_class *jrt.Class

func A_arbace_reflect_eval1939000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000086_A_New()}; return nil }

var A_arbace_reflect_eval1939000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000086_A_new}

var A_arbace_reflect_eval1939000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000086", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000086_A"})

func init() { i := A_arbace_reflect_eval1939000086_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000086_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000086_A_members }

var A_arbace_reflect_eval1939000086___GT_Field__1939000100_A_class *jrt.Class

var A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A_class *jrt.Class

func A_arbace_reflect_eval1939000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000108_A_New()}; return nil }

var A_arbace_reflect_eval1939000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000108_A_new}

var A_arbace_reflect_eval1939000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000108", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000108_A"})

func init() { i := A_arbace_reflect_eval1939000108_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000108_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000108_A_members }

var A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A_class *jrt.Class

func A_arbace_reflect_eval1939000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000121_A_New()}; return nil }

var A_arbace_reflect_eval1939000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000121_A_new}

var A_arbace_reflect_eval1939000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000121", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000121_A"})

func init() { i := A_arbace_reflect_eval1939000121_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000121_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000121_A_members }

var A_arbace_reflect_eval1939000121_fn__1939000122_A_class *jrt.Class

var A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A_class *jrt.Class

var A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A_class *jrt.Class

func A_arbace_reflect_eval1939000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000137_A_New()}; return nil }

var A_arbace_reflect_eval1939000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000137_A_new}

var A_arbace_reflect_eval1939000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000137", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000137_A"})

func init() { i := A_arbace_reflect_eval1939000137_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000137_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000137_A_members }

var A_arbace_reflect_eval1939000137_fn__1939000138_A_class *jrt.Class

func A_arbace_reflect_eval1939000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000141_A_New()}; return nil }

var A_arbace_reflect_eval1939000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000141_A_new}

var A_arbace_reflect_eval1939000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000141", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000141_A"})

func init() { i := A_arbace_reflect_eval1939000141_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000141_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000141_A_members }

var A_arbace_reflect_eval1939000141_fn__1939000142_A_class *jrt.Class

func A_arbace_reflect_eval1939000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval1939000145_A_New()}; return nil }

var A_arbace_reflect_eval1939000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval1939000145_A_new}

var A_arbace_reflect_eval1939000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval1939000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval1939000145", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval1939000145_A"})

func init() { i := A_arbace_reflect_eval1939000145_A_class.Info(); i.IsInstance = A_arbace_reflect_eval1939000145_A_InstanceOf; i.Table = A_arbace_reflect_eval1939000145_A_members }

var A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A_class *jrt.Class

func A_arbace_reflect_eval659000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval659000004_A_New()}; return nil }

var A_arbace_reflect_eval659000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval659000004_A_new}

var A_arbace_reflect_eval659000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval659000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval659000004", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000004_A"})

func init() { i := A_arbace_reflect_eval659000004_A_class.Info(); i.IsInstance = A_arbace_reflect_eval659000004_A_InstanceOf; i.Table = A_arbace_reflect_eval659000004_A_members }

var A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_class *jrt.Class

func A_arbace_reflect_eval659000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval659000008_A_New()}; return nil }

var A_arbace_reflect_eval659000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval659000008_A_new}

var A_arbace_reflect_eval659000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval659000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval659000008", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000008_A"})

func init() { i := A_arbace_reflect_eval659000008_A_class.Info(); i.IsInstance = A_arbace_reflect_eval659000008_A_InstanceOf; i.Table = A_arbace_reflect_eval659000008_A_members }

var A_arbace_reflect_eval659000008_fn__659000009_A_class *jrt.Class

func A_arbace_reflect_eval659000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval659000020_A_New()}; return nil }

var A_arbace_reflect_eval659000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval659000020_A_new}

var A_arbace_reflect_eval659000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval659000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval659000020", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000020_A"})

func init() { i := A_arbace_reflect_eval659000020_A_class.Info(); i.IsInstance = A_arbace_reflect_eval659000020_A_InstanceOf; i.Table = A_arbace_reflect_eval659000020_A_members }

var A_arbace_reflect_eval659000020_fn__659000021_A_class *jrt.Class

var A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_class *jrt.Class

var A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_class *jrt.Class

func A_arbace_reflect_eval659000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_eval659000044_A_New()}; return nil }

var A_arbace_reflect_eval659000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_reflect_eval659000044_A_new}

var A_arbace_reflect_eval659000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect$eval659000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_reflect_A_class, Simple: "eval659000044", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_eval659000044_A"})

func init() { i := A_arbace_reflect_eval659000044_A_class.Info(); i.IsInstance = A_arbace_reflect_eval659000044_A_InstanceOf; i.Table = A_arbace_reflect_eval659000044_A_members }

var A_arbace_reflect_eval659000044_fn__659000045_A_class *jrt.Class

var A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_class *jrt.Class

var A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_class *jrt.Class

var A_arbace_reflect_field__GT_map_A_class *jrt.Class

var A_arbace_reflect_field_descriptor__GT_class_symbol_A_class *jrt.Class

var A_arbace_reflect_internal_name__GT_class_symbol_A_class *jrt.Class

var A_arbace_reflect_method__GT_map_A_class *jrt.Class

var A_arbace_reflect_parse_flags_A_class *jrt.Class

var A_arbace_reflect_parse_flags_fn__1939000032_A_class *jrt.Class

var A_arbace_reflect_reflect_A_class *jrt.Class

var A_arbace_reflect_resource_name_A_class *jrt.Class

var A_arbace_reflect_type_reflect_A_class *jrt.Class

var A_arbace_reflect_type_reflect_fn__659000063_A_class *jrt.Class

var A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_class *jrt.Class

var A_arbace_reflect_typeref__GT_class_A_class *jrt.Class

var A_arbace_reflect_typesym_A_class *jrt.Class

var A_arbace_reflect_typesym_fn__1939000019_A_class *jrt.Class

func A_arbace_reflect_AsmReflector_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_AsmReflector_A).Do_reflect_O__O(args[0]); case 1: return A_arbace_reflect_AsmReflector_A_GetBasis__IPersistentVector()}; return nil }

func A_arbace_reflect_AsmReflector_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_AsmReflector_A_New_O(args[0])}; return nil }

func A_arbace_reflect_AsmReflector_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_reflect_AsmReflector_A).F_class_resolver}; return nil }

var A_arbace_reflect_AsmReflector_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 do_reflect (Ljava.lang.Object;)Ljava.lang.Object;\nM9 getBasis ()Larbace.lang.IPersistentVector;\nC1 (Ljava.lang.Object;)V\nG17 class_resolver Ljava.lang.Object;", Invoke: A_arbace_reflect_AsmReflector_A_invoke, New: A_arbace_reflect_AsmReflector_A_new, Get: A_arbace_reflect_AsmReflector_A_get}

var A_arbace_reflect_AsmReflector_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.AsmReflector", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_reflect_Reflector_A_class, lang.IType_class}, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_AsmReflector_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_AsmReflector_A_class.Info(); i.IsInstance = A_arbace_reflect_AsmReflector_A_InstanceOf; i.Init = A_arbace_reflect_AsmReflector_A_Init; i.Table = A_arbace_reflect_AsmReflector_A_members }

func A_arbace_reflect_ClassResolver_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_reflect_ClassResolver_A).Resolve_class_O__O(args[0])}; return nil }

var A_arbace_reflect_ClassResolver_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 resolve_class (Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_reflect_ClassResolver_A_invoke}

var A_arbace_reflect_ClassResolver_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.ClassResolver", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_ClassResolver_A"})

func init() { i := A_arbace_reflect_ClassResolver_A_class.Info(); i.IsInstance = A_arbace_reflect_ClassResolver_A_InstanceOf; i.Table = A_arbace_reflect_ClassResolver_A_members }

func A_arbace_reflect_Constructor_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Constructor_A).Assoc_O_O__Associative(args[0], args[1]); case 1: return this.(*A_arbace_reflect_Constructor_A).Assoc_O_O__IPersistentMap(args[0], args[1]); case 2: this.(*A_arbace_reflect_Constructor_A).Clear__V(); return nil; case 3: return this.(*A_arbace_reflect_Constructor_A).Cons_O__IPersistentCollection(args[0]); case 4: return this.(*A_arbace_reflect_Constructor_A).ContainsKey_O__Z(args[0]); case 5: return this.(*A_arbace_reflect_Constructor_A).ContainsValue_O__Z(args[0]); case 6: return this.(*A_arbace_reflect_Constructor_A).Count__I(); case 7: return jrt.J2g_RefP(A_arbace_reflect_Constructor_A_Create_IPersistentMap__A_arbace_reflect_Constructor_A(jrt.As[lang.IPersistentMap](args[0]))); case 8: return this.(*A_arbace_reflect_Constructor_A).Empty__IPersistentCollection(); case 9: return this.(*A_arbace_reflect_Constructor_A).EntryAt_O__IMapEntry(args[0]); case 10: return this.(*A_arbace_reflect_Constructor_A).EntrySet__Set(); case 11: return this.(*A_arbace_reflect_Constructor_A).Equals_O__Z(args[0]); case 12: return this.(*A_arbace_reflect_Constructor_A).Equiv_O__Z(args[0]); case 13: return this.(*A_arbace_reflect_Constructor_A).Get_O__O(args[0]); case 14: return A_arbace_reflect_Constructor_A_GetBasis__IPersistentVector(); case 15: return this.(*A_arbace_reflect_Constructor_A).GetLookupThunk_Keyword__ILookupThunk(jrt.As[*lang.Keyword](args[0])); case 16: return this.(*A_arbace_reflect_Constructor_A).HashCode__I(); case 17: return this.(*A_arbace_reflect_Constructor_A).Hasheq__I(); case 18: return this.(*A_arbace_reflect_Constructor_A).IsEmpty__Z(); case 19: return this.(*A_arbace_reflect_Constructor_A).Iterator__Iterator(); case 20: return this.(*A_arbace_reflect_Constructor_A).KeySet__Set(); case 21: return this.(*A_arbace_reflect_Constructor_A).Meta__IPersistentMap(); case 22: return this.(*A_arbace_reflect_Constructor_A).Put_O_O__O(args[0], args[1]); case 23: this.(*A_arbace_reflect_Constructor_A).PutAll_Map__V(jrt.As[jrt.Map](args[0])); return nil; case 24: return this.(*A_arbace_reflect_Constructor_A).Remove_O__O(args[0]); case 25: return this.(*A_arbace_reflect_Constructor_A).Seq__ISeq(); case 26: return this.(*A_arbace_reflect_Constructor_A).Size__I(); case 27: return this.(*A_arbace_reflect_Constructor_A).ValAt_O__O(args[0]); case 28: return this.(*A_arbace_reflect_Constructor_A).ValAt_O_O__O(args[0], args[1]); case 29: return this.(*A_arbace_reflect_Constructor_A).Values__Collection(); case 30: return this.(*A_arbace_reflect_Constructor_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 31: return this.(*A_arbace_reflect_Constructor_A).Without_O__IPersistentMap(args[0])}; return nil }

func A_arbace_reflect_Constructor_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O_I_I(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7].(int32), args[8].(int32)); case 1: return A_arbace_reflect_Constructor_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4]); case 2: return A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_reflect_Constructor_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_reflect_Constructor_A).F_name; case 1: return o.(*A_arbace_reflect_Constructor_A).F_declaring_class; case 2: return o.(*A_arbace_reflect_Constructor_A).F_parameter_types; case 3: return o.(*A_arbace_reflect_Constructor_A).F_exception_types; case 4: return o.(*A_arbace_reflect_Constructor_A).F_flags; case 5: return o.(*A_arbace_reflect_Constructor_A).F___meta; case 6: return o.(*A_arbace_reflect_Constructor_A).F___extmap}; return nil }

var A_arbace_reflect_Constructor_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M4161 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.Associative;\nM1 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nM1 clear ()V\nM1 cons (Ljava.lang.Object;)Larbace.lang.IPersistentCollection;\nM1 containsKey (Ljava.lang.Object;)Z\nM1 containsValue (Ljava.lang.Object;)Z\nM1 count ()I\nM9 create (Larbace.lang.IPersistentMap;)Larbace.reflect.Constructor;\nM1 empty ()Larbace.lang.IPersistentCollection;\nM1 entryAt (Ljava.lang.Object;)Larbace.lang.IMapEntry;\nM1 entrySet ()Ljava.util.Set;\nM1 equals (Ljava.lang.Object;)Z\nM1 equiv (Ljava.lang.Object;)Z\nM1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM9 getBasis ()Larbace.lang.IPersistentVector;\nM1 getLookupThunk (Larbace.lang.Keyword;)Larbace.lang.ILookupThunk;\nM1 hashCode ()I\nM1 hasheq ()I\nM1 isEmpty ()Z\nM1 iterator ()Ljava.util.Iterator;\nM1 keySet ()Ljava.util.Set;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 put (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 putAll (Ljava.util.Map;)V\nM1 remove (Ljava.lang.Object;)Ljava.lang.Object;\nM1 seq ()Larbace.lang.ISeq;\nM1 size ()I\nM1 valAt (Ljava.lang.Object;)Ljava.lang.Object;\nM1 valAt (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 values ()Ljava.util.Collection;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 without (Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;II)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG17 name Ljava.lang.Object;\nG17 declaring_class Ljava.lang.Object;\nG17 parameter_types Ljava.lang.Object;\nG17 exception_types Ljava.lang.Object;\nG17 flags Ljava.lang.Object;\nG17 __meta Ljava.lang.Object;\nG17 __extmap Ljava.lang.Object;", Invoke: A_arbace_reflect_Constructor_A_invoke, New: A_arbace_reflect_Constructor_A_new, Get: A_arbace_reflect_Constructor_A_get}

var A_arbace_reflect_Constructor_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Constructor", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.IRecord_class, lang.IHashEq_class, lang.IObj_class, lang.ILookup_class, lang.IKeywordLookup_class, lang.IPersistentMap_class, jrt.Map_class, jrt.Serializable_class}, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Constructor_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Constructor_A_class.Info(); i.IsInstance = A_arbace_reflect_Constructor_A_InstanceOf; i.Init = A_arbace_reflect_Constructor_A_Init; i.Table = A_arbace_reflect_Constructor_A_members }

func A_arbace_reflect_Constructor_reify__1939000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Constructor_reify__1939000040_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Constructor_reify__1939000040_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Constructor_reify__1939000040_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Constructor_reify__1939000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Constructor_reify__1939000040_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Constructor_reify__1939000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Constructor_reify__1939000040_A_invoke, New: A_arbace_reflect_Constructor_reify__1939000040_A_new}

var A_arbace_reflect_Constructor_reify__1939000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Constructor$reify__1939000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Constructor_A_class, Simple: "reify__1939000040", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Constructor_reify__1939000040_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Constructor_reify__1939000040_A_class.Info(); i.IsInstance = A_arbace_reflect_Constructor_reify__1939000040_A_InstanceOf; i.Table = A_arbace_reflect_Constructor_reify__1939000040_A_members }

func A_arbace_reflect_Constructor_reify__1939000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Constructor_reify__1939000042_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Constructor_reify__1939000042_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Constructor_reify__1939000042_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Constructor_reify__1939000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Constructor_reify__1939000042_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Constructor_reify__1939000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Constructor_reify__1939000042_A_invoke, New: A_arbace_reflect_Constructor_reify__1939000042_A_new}

var A_arbace_reflect_Constructor_reify__1939000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Constructor$reify__1939000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Constructor_A_class, Simple: "reify__1939000042", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Constructor_reify__1939000042_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Constructor_reify__1939000042_A_class.Info(); i.IsInstance = A_arbace_reflect_Constructor_reify__1939000042_A_InstanceOf; i.Table = A_arbace_reflect_Constructor_reify__1939000042_A_members }

func A_arbace_reflect_Constructor_reify__1939000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Constructor_reify__1939000044_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Constructor_reify__1939000044_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Constructor_reify__1939000044_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Constructor_reify__1939000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Constructor_reify__1939000044_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Constructor_reify__1939000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Constructor_reify__1939000044_A_invoke, New: A_arbace_reflect_Constructor_reify__1939000044_A_new}

var A_arbace_reflect_Constructor_reify__1939000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Constructor$reify__1939000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Constructor_A_class, Simple: "reify__1939000044", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Constructor_reify__1939000044_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Constructor_reify__1939000044_A_class.Info(); i.IsInstance = A_arbace_reflect_Constructor_reify__1939000044_A_InstanceOf; i.Table = A_arbace_reflect_Constructor_reify__1939000044_A_members }

func A_arbace_reflect_Constructor_reify__1939000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Constructor_reify__1939000046_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Constructor_reify__1939000046_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Constructor_reify__1939000046_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Constructor_reify__1939000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Constructor_reify__1939000046_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Constructor_reify__1939000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Constructor_reify__1939000046_A_invoke, New: A_arbace_reflect_Constructor_reify__1939000046_A_new}

var A_arbace_reflect_Constructor_reify__1939000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Constructor$reify__1939000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Constructor_A_class, Simple: "reify__1939000046", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Constructor_reify__1939000046_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Constructor_reify__1939000046_A_class.Info(); i.IsInstance = A_arbace_reflect_Constructor_reify__1939000046_A_InstanceOf; i.Table = A_arbace_reflect_Constructor_reify__1939000046_A_members }

func A_arbace_reflect_Constructor_reify__1939000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Constructor_reify__1939000048_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Constructor_reify__1939000048_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Constructor_reify__1939000048_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Constructor_reify__1939000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Constructor_reify__1939000048_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Constructor_reify__1939000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Constructor_reify__1939000048_A_invoke, New: A_arbace_reflect_Constructor_reify__1939000048_A_new}

var A_arbace_reflect_Constructor_reify__1939000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Constructor$reify__1939000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Constructor_A_class, Simple: "reify__1939000048", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Constructor_reify__1939000048_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Constructor_reify__1939000048_A_class.Info(); i.IsInstance = A_arbace_reflect_Constructor_reify__1939000048_A_InstanceOf; i.Table = A_arbace_reflect_Constructor_reify__1939000048_A_members }

func A_arbace_reflect_Field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Field_A).Assoc_O_O__Associative(args[0], args[1]); case 1: return this.(*A_arbace_reflect_Field_A).Assoc_O_O__IPersistentMap(args[0], args[1]); case 2: this.(*A_arbace_reflect_Field_A).Clear__V(); return nil; case 3: return this.(*A_arbace_reflect_Field_A).Cons_O__IPersistentCollection(args[0]); case 4: return this.(*A_arbace_reflect_Field_A).ContainsKey_O__Z(args[0]); case 5: return this.(*A_arbace_reflect_Field_A).ContainsValue_O__Z(args[0]); case 6: return this.(*A_arbace_reflect_Field_A).Count__I(); case 7: return jrt.J2g_RefP(A_arbace_reflect_Field_A_Create_IPersistentMap__A_arbace_reflect_Field_A(jrt.As[lang.IPersistentMap](args[0]))); case 8: return this.(*A_arbace_reflect_Field_A).Empty__IPersistentCollection(); case 9: return this.(*A_arbace_reflect_Field_A).EntryAt_O__IMapEntry(args[0]); case 10: return this.(*A_arbace_reflect_Field_A).EntrySet__Set(); case 11: return this.(*A_arbace_reflect_Field_A).Equals_O__Z(args[0]); case 12: return this.(*A_arbace_reflect_Field_A).Equiv_O__Z(args[0]); case 13: return this.(*A_arbace_reflect_Field_A).Get_O__O(args[0]); case 14: return A_arbace_reflect_Field_A_GetBasis__IPersistentVector(); case 15: return this.(*A_arbace_reflect_Field_A).GetLookupThunk_Keyword__ILookupThunk(jrt.As[*lang.Keyword](args[0])); case 16: return this.(*A_arbace_reflect_Field_A).HashCode__I(); case 17: return this.(*A_arbace_reflect_Field_A).Hasheq__I(); case 18: return this.(*A_arbace_reflect_Field_A).IsEmpty__Z(); case 19: return this.(*A_arbace_reflect_Field_A).Iterator__Iterator(); case 20: return this.(*A_arbace_reflect_Field_A).KeySet__Set(); case 21: return this.(*A_arbace_reflect_Field_A).Meta__IPersistentMap(); case 22: return this.(*A_arbace_reflect_Field_A).Put_O_O__O(args[0], args[1]); case 23: this.(*A_arbace_reflect_Field_A).PutAll_Map__V(jrt.As[jrt.Map](args[0])); return nil; case 24: return this.(*A_arbace_reflect_Field_A).Remove_O__O(args[0]); case 25: return this.(*A_arbace_reflect_Field_A).Seq__ISeq(); case 26: return this.(*A_arbace_reflect_Field_A).Size__I(); case 27: return this.(*A_arbace_reflect_Field_A).ValAt_O__O(args[0]); case 28: return this.(*A_arbace_reflect_Field_A).ValAt_O_O__O(args[0], args[1]); case 29: return this.(*A_arbace_reflect_Field_A).Values__Collection(); case 30: return this.(*A_arbace_reflect_Field_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 31: return this.(*A_arbace_reflect_Field_A).Without_O__IPersistentMap(args[0])}; return nil }

func A_arbace_reflect_Field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Field_A_New_O_O_O_O_O_O_I_I(args[0], args[1], args[2], args[3], args[4], args[5], args[6].(int32), args[7].(int32)); case 1: return A_arbace_reflect_Field_A_New_O_O_O_O(args[0], args[1], args[2], args[3]); case 2: return A_arbace_reflect_Field_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_reflect_Field_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_reflect_Field_A).F_name; case 1: return o.(*A_arbace_reflect_Field_A).F_type; case 2: return o.(*A_arbace_reflect_Field_A).F_declaring_class; case 3: return o.(*A_arbace_reflect_Field_A).F_flags; case 4: return o.(*A_arbace_reflect_Field_A).F___meta; case 5: return o.(*A_arbace_reflect_Field_A).F___extmap}; return nil }

var A_arbace_reflect_Field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M4161 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.Associative;\nM1 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nM1 clear ()V\nM1 cons (Ljava.lang.Object;)Larbace.lang.IPersistentCollection;\nM1 containsKey (Ljava.lang.Object;)Z\nM1 containsValue (Ljava.lang.Object;)Z\nM1 count ()I\nM9 create (Larbace.lang.IPersistentMap;)Larbace.reflect.Field;\nM1 empty ()Larbace.lang.IPersistentCollection;\nM1 entryAt (Ljava.lang.Object;)Larbace.lang.IMapEntry;\nM1 entrySet ()Ljava.util.Set;\nM1 equals (Ljava.lang.Object;)Z\nM1 equiv (Ljava.lang.Object;)Z\nM1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM9 getBasis ()Larbace.lang.IPersistentVector;\nM1 getLookupThunk (Larbace.lang.Keyword;)Larbace.lang.ILookupThunk;\nM1 hashCode ()I\nM1 hasheq ()I\nM1 isEmpty ()Z\nM1 iterator ()Ljava.util.Iterator;\nM1 keySet ()Ljava.util.Set;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 put (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 putAll (Ljava.util.Map;)V\nM1 remove (Ljava.lang.Object;)Ljava.lang.Object;\nM1 seq ()Larbace.lang.ISeq;\nM1 size ()I\nM1 valAt (Ljava.lang.Object;)Ljava.lang.Object;\nM1 valAt (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 values ()Ljava.util.Collection;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 without (Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;II)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG17 name Ljava.lang.Object;\nG17 type Ljava.lang.Object;\nG17 declaring_class Ljava.lang.Object;\nG17 flags Ljava.lang.Object;\nG17 __meta Ljava.lang.Object;\nG17 __extmap Ljava.lang.Object;", Invoke: A_arbace_reflect_Field_A_invoke, New: A_arbace_reflect_Field_A_new, Get: A_arbace_reflect_Field_A_get}

var A_arbace_reflect_Field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Field", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.IRecord_class, lang.IHashEq_class, lang.IObj_class, lang.ILookup_class, lang.IKeywordLookup_class, lang.IPersistentMap_class, jrt.Map_class, jrt.Serializable_class}, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Field_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Field_A_class.Info(); i.IsInstance = A_arbace_reflect_Field_A_InstanceOf; i.Init = A_arbace_reflect_Field_A_Init; i.Table = A_arbace_reflect_Field_A_members }

func A_arbace_reflect_Field_reify__1939000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Field_reify__1939000090_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Field_reify__1939000090_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Field_reify__1939000090_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Field_reify__1939000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Field_reify__1939000090_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Field_reify__1939000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Field_reify__1939000090_A_invoke, New: A_arbace_reflect_Field_reify__1939000090_A_new}

var A_arbace_reflect_Field_reify__1939000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Field$reify__1939000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Field_A_class, Simple: "reify__1939000090", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Field_reify__1939000090_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Field_reify__1939000090_A_class.Info(); i.IsInstance = A_arbace_reflect_Field_reify__1939000090_A_InstanceOf; i.Table = A_arbace_reflect_Field_reify__1939000090_A_members }

func A_arbace_reflect_Field_reify__1939000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Field_reify__1939000092_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Field_reify__1939000092_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Field_reify__1939000092_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Field_reify__1939000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Field_reify__1939000092_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Field_reify__1939000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Field_reify__1939000092_A_invoke, New: A_arbace_reflect_Field_reify__1939000092_A_new}

var A_arbace_reflect_Field_reify__1939000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Field$reify__1939000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Field_A_class, Simple: "reify__1939000092", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Field_reify__1939000092_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Field_reify__1939000092_A_class.Info(); i.IsInstance = A_arbace_reflect_Field_reify__1939000092_A_InstanceOf; i.Table = A_arbace_reflect_Field_reify__1939000092_A_members }

func A_arbace_reflect_Field_reify__1939000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Field_reify__1939000094_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Field_reify__1939000094_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Field_reify__1939000094_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Field_reify__1939000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Field_reify__1939000094_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Field_reify__1939000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Field_reify__1939000094_A_invoke, New: A_arbace_reflect_Field_reify__1939000094_A_new}

var A_arbace_reflect_Field_reify__1939000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Field$reify__1939000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Field_A_class, Simple: "reify__1939000094", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Field_reify__1939000094_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Field_reify__1939000094_A_class.Info(); i.IsInstance = A_arbace_reflect_Field_reify__1939000094_A_InstanceOf; i.Table = A_arbace_reflect_Field_reify__1939000094_A_members }

func A_arbace_reflect_Field_reify__1939000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Field_reify__1939000096_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Field_reify__1939000096_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Field_reify__1939000096_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Field_reify__1939000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Field_reify__1939000096_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Field_reify__1939000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Field_reify__1939000096_A_invoke, New: A_arbace_reflect_Field_reify__1939000096_A_new}

var A_arbace_reflect_Field_reify__1939000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Field$reify__1939000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Field_A_class, Simple: "reify__1939000096", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Field_reify__1939000096_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Field_reify__1939000096_A_class.Info(); i.IsInstance = A_arbace_reflect_Field_reify__1939000096_A_InstanceOf; i.Table = A_arbace_reflect_Field_reify__1939000096_A_members }

func A_arbace_reflect_JavaReflector_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_JavaReflector_A).Do_reflect_O__O(args[0]); case 1: return A_arbace_reflect_JavaReflector_A_GetBasis__IPersistentVector()}; return nil }

func A_arbace_reflect_JavaReflector_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_JavaReflector_A_New_O(args[0])}; return nil }

func A_arbace_reflect_JavaReflector_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_reflect_JavaReflector_A).F_classloader}; return nil }

var A_arbace_reflect_JavaReflector_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 do_reflect (Ljava.lang.Object;)Ljava.lang.Object;\nM9 getBasis ()Larbace.lang.IPersistentVector;\nC1 (Ljava.lang.Object;)V\nG17 classloader Ljava.lang.Object;", Invoke: A_arbace_reflect_JavaReflector_A_invoke, New: A_arbace_reflect_JavaReflector_A_new, Get: A_arbace_reflect_JavaReflector_A_get}

var A_arbace_reflect_JavaReflector_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.JavaReflector", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_reflect_Reflector_A_class, lang.IType_class}, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_JavaReflector_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_JavaReflector_A_class.Info(); i.IsInstance = A_arbace_reflect_JavaReflector_A_InstanceOf; i.Init = A_arbace_reflect_JavaReflector_A_Init; i.Table = A_arbace_reflect_JavaReflector_A_members }

func A_arbace_reflect_Method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Method_A).Assoc_O_O__Associative(args[0], args[1]); case 1: return this.(*A_arbace_reflect_Method_A).Assoc_O_O__IPersistentMap(args[0], args[1]); case 2: this.(*A_arbace_reflect_Method_A).Clear__V(); return nil; case 3: return this.(*A_arbace_reflect_Method_A).Cons_O__IPersistentCollection(args[0]); case 4: return this.(*A_arbace_reflect_Method_A).ContainsKey_O__Z(args[0]); case 5: return this.(*A_arbace_reflect_Method_A).ContainsValue_O__Z(args[0]); case 6: return this.(*A_arbace_reflect_Method_A).Count__I(); case 7: return jrt.J2g_RefP(A_arbace_reflect_Method_A_Create_IPersistentMap__A_arbace_reflect_Method_A(jrt.As[lang.IPersistentMap](args[0]))); case 8: return this.(*A_arbace_reflect_Method_A).Empty__IPersistentCollection(); case 9: return this.(*A_arbace_reflect_Method_A).EntryAt_O__IMapEntry(args[0]); case 10: return this.(*A_arbace_reflect_Method_A).EntrySet__Set(); case 11: return this.(*A_arbace_reflect_Method_A).Equals_O__Z(args[0]); case 12: return this.(*A_arbace_reflect_Method_A).Equiv_O__Z(args[0]); case 13: return this.(*A_arbace_reflect_Method_A).Get_O__O(args[0]); case 14: return A_arbace_reflect_Method_A_GetBasis__IPersistentVector(); case 15: return this.(*A_arbace_reflect_Method_A).GetLookupThunk_Keyword__ILookupThunk(jrt.As[*lang.Keyword](args[0])); case 16: return this.(*A_arbace_reflect_Method_A).HashCode__I(); case 17: return this.(*A_arbace_reflect_Method_A).Hasheq__I(); case 18: return this.(*A_arbace_reflect_Method_A).IsEmpty__Z(); case 19: return this.(*A_arbace_reflect_Method_A).Iterator__Iterator(); case 20: return this.(*A_arbace_reflect_Method_A).KeySet__Set(); case 21: return this.(*A_arbace_reflect_Method_A).Meta__IPersistentMap(); case 22: return this.(*A_arbace_reflect_Method_A).Put_O_O__O(args[0], args[1]); case 23: this.(*A_arbace_reflect_Method_A).PutAll_Map__V(jrt.As[jrt.Map](args[0])); return nil; case 24: return this.(*A_arbace_reflect_Method_A).Remove_O__O(args[0]); case 25: return this.(*A_arbace_reflect_Method_A).Seq__ISeq(); case 26: return this.(*A_arbace_reflect_Method_A).Size__I(); case 27: return this.(*A_arbace_reflect_Method_A).ValAt_O__O(args[0]); case 28: return this.(*A_arbace_reflect_Method_A).ValAt_O_O__O(args[0], args[1]); case 29: return this.(*A_arbace_reflect_Method_A).Values__Collection(); case 30: return this.(*A_arbace_reflect_Method_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 31: return this.(*A_arbace_reflect_Method_A).Without_O__IPersistentMap(args[0])}; return nil }

func A_arbace_reflect_Method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O_I_I(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8].(int32), args[9].(int32)); case 1: return A_arbace_reflect_Method_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5]); case 2: return A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_reflect_Method_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_reflect_Method_A).F_name; case 1: return o.(*A_arbace_reflect_Method_A).F_return_type; case 2: return o.(*A_arbace_reflect_Method_A).F_declaring_class; case 3: return o.(*A_arbace_reflect_Method_A).F_parameter_types; case 4: return o.(*A_arbace_reflect_Method_A).F_exception_types; case 5: return o.(*A_arbace_reflect_Method_A).F_flags; case 6: return o.(*A_arbace_reflect_Method_A).F___meta; case 7: return o.(*A_arbace_reflect_Method_A).F___extmap}; return nil }

var A_arbace_reflect_Method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M4161 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.Associative;\nM1 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nM1 clear ()V\nM1 cons (Ljava.lang.Object;)Larbace.lang.IPersistentCollection;\nM1 containsKey (Ljava.lang.Object;)Z\nM1 containsValue (Ljava.lang.Object;)Z\nM1 count ()I\nM9 create (Larbace.lang.IPersistentMap;)Larbace.reflect.Method;\nM1 empty ()Larbace.lang.IPersistentCollection;\nM1 entryAt (Ljava.lang.Object;)Larbace.lang.IMapEntry;\nM1 entrySet ()Ljava.util.Set;\nM1 equals (Ljava.lang.Object;)Z\nM1 equiv (Ljava.lang.Object;)Z\nM1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM9 getBasis ()Larbace.lang.IPersistentVector;\nM1 getLookupThunk (Larbace.lang.Keyword;)Larbace.lang.ILookupThunk;\nM1 hashCode ()I\nM1 hasheq ()I\nM1 isEmpty ()Z\nM1 iterator ()Ljava.util.Iterator;\nM1 keySet ()Ljava.util.Set;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 put (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 putAll (Ljava.util.Map;)V\nM1 remove (Ljava.lang.Object;)Ljava.lang.Object;\nM1 seq ()Larbace.lang.ISeq;\nM1 size ()I\nM1 valAt (Ljava.lang.Object;)Ljava.lang.Object;\nM1 valAt (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 values ()Ljava.util.Collection;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 without (Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;II)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG17 name Ljava.lang.Object;\nG17 return_type Ljava.lang.Object;\nG17 declaring_class Ljava.lang.Object;\nG17 parameter_types Ljava.lang.Object;\nG17 exception_types Ljava.lang.Object;\nG17 flags Ljava.lang.Object;\nG17 __meta Ljava.lang.Object;\nG17 __extmap Ljava.lang.Object;", Invoke: A_arbace_reflect_Method_A_invoke, New: A_arbace_reflect_Method_A_new, Get: A_arbace_reflect_Method_A_get}

var A_arbace_reflect_Method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Method", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.IRecord_class, lang.IHashEq_class, lang.IObj_class, lang.ILookup_class, lang.IKeywordLookup_class, lang.IPersistentMap_class, jrt.Map_class, jrt.Serializable_class}, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Method_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Method_A_class.Info(); i.IsInstance = A_arbace_reflect_Method_A_InstanceOf; i.Init = A_arbace_reflect_Method_A_Init; i.Table = A_arbace_reflect_Method_A_members }

func A_arbace_reflect_Method_reify__1939000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Method_reify__1939000064_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Method_reify__1939000064_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Method_reify__1939000064_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Method_reify__1939000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Method_reify__1939000064_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Method_reify__1939000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Method_reify__1939000064_A_invoke, New: A_arbace_reflect_Method_reify__1939000064_A_new}

var A_arbace_reflect_Method_reify__1939000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Method$reify__1939000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Method_A_class, Simple: "reify__1939000064", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Method_reify__1939000064_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Method_reify__1939000064_A_class.Info(); i.IsInstance = A_arbace_reflect_Method_reify__1939000064_A_InstanceOf; i.Table = A_arbace_reflect_Method_reify__1939000064_A_members }

func A_arbace_reflect_Method_reify__1939000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Method_reify__1939000066_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Method_reify__1939000066_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Method_reify__1939000066_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Method_reify__1939000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Method_reify__1939000066_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Method_reify__1939000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Method_reify__1939000066_A_invoke, New: A_arbace_reflect_Method_reify__1939000066_A_new}

var A_arbace_reflect_Method_reify__1939000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Method$reify__1939000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Method_A_class, Simple: "reify__1939000066", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Method_reify__1939000066_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Method_reify__1939000066_A_class.Info(); i.IsInstance = A_arbace_reflect_Method_reify__1939000066_A_InstanceOf; i.Table = A_arbace_reflect_Method_reify__1939000066_A_members }

func A_arbace_reflect_Method_reify__1939000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Method_reify__1939000068_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Method_reify__1939000068_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Method_reify__1939000068_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Method_reify__1939000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Method_reify__1939000068_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Method_reify__1939000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Method_reify__1939000068_A_invoke, New: A_arbace_reflect_Method_reify__1939000068_A_new}

var A_arbace_reflect_Method_reify__1939000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Method$reify__1939000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Method_A_class, Simple: "reify__1939000068", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Method_reify__1939000068_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Method_reify__1939000068_A_class.Info(); i.IsInstance = A_arbace_reflect_Method_reify__1939000068_A_InstanceOf; i.Table = A_arbace_reflect_Method_reify__1939000068_A_members }

func A_arbace_reflect_Method_reify__1939000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Method_reify__1939000070_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Method_reify__1939000070_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Method_reify__1939000070_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Method_reify__1939000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Method_reify__1939000070_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Method_reify__1939000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Method_reify__1939000070_A_invoke, New: A_arbace_reflect_Method_reify__1939000070_A_new}

var A_arbace_reflect_Method_reify__1939000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Method$reify__1939000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Method_A_class, Simple: "reify__1939000070", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Method_reify__1939000070_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Method_reify__1939000070_A_class.Info(); i.IsInstance = A_arbace_reflect_Method_reify__1939000070_A_InstanceOf; i.Table = A_arbace_reflect_Method_reify__1939000070_A_members }

func A_arbace_reflect_Method_reify__1939000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Method_reify__1939000072_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Method_reify__1939000072_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Method_reify__1939000072_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Method_reify__1939000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Method_reify__1939000072_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Method_reify__1939000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Method_reify__1939000072_A_invoke, New: A_arbace_reflect_Method_reify__1939000072_A_new}

var A_arbace_reflect_Method_reify__1939000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Method$reify__1939000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Method_A_class, Simple: "reify__1939000072", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Method_reify__1939000072_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Method_reify__1939000072_A_class.Info(); i.IsInstance = A_arbace_reflect_Method_reify__1939000072_A_InstanceOf; i.Table = A_arbace_reflect_Method_reify__1939000072_A_members }

func A_arbace_reflect_Method_reify__1939000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_reflect_Method_reify__1939000074_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_reflect_Method_reify__1939000074_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_reflect_Method_reify__1939000074_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_reflect_Method_reify__1939000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect_Method_reify__1939000074_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_reflect_Method_reify__1939000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_reflect_Method_reify__1939000074_A_invoke, New: A_arbace_reflect_Method_reify__1939000074_A_new}

var A_arbace_reflect_Method_reify__1939000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Method$reify__1939000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_reflect_Method_A_class, Simple: "reify__1939000074", Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Method_reify__1939000074_A", Source: "java.ae"})

func init() { i := A_arbace_reflect_Method_reify__1939000074_A_class.Info(); i.IsInstance = A_arbace_reflect_Method_reify__1939000074_A_InstanceOf; i.Table = A_arbace_reflect_Method_reify__1939000074_A_members }

func A_arbace_reflect_Reflector_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_reflect_Reflector_A).Do_reflect_O__O(args[0])}; return nil }

var A_arbace_reflect_Reflector_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 do_reflect (Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_reflect_Reflector_A_invoke}

var A_arbace_reflect_Reflector_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.Reflector", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_Reflector_A"})

func init() { i := A_arbace_reflect_Reflector_A_class.Info(); i.IsInstance = A_arbace_reflect_Reflector_A_InstanceOf; i.Table = A_arbace_reflect_Reflector_A_members }

func A_arbace_reflect_TypeReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_reflect_TypeReference_A).Typename__O()}; return nil }

var A_arbace_reflect_TypeReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 typename ()Ljava.lang.Object;", Invoke: A_arbace_reflect_TypeReference_A_invoke}

var A_arbace_reflect_TypeReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect.TypeReference", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_reflect.A_arbace_reflect_TypeReference_A"})

func init() { i := A_arbace_reflect_TypeReference_A_class.Info(); i.IsInstance = A_arbace_reflect_TypeReference_A_InstanceOf; i.Table = A_arbace_reflect_TypeReference_A_members }

func A_arbace_reflect__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_reflect__init_A_Load__O()}; return nil }

func A_arbace_reflect__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_reflect__init_A_New()}; return nil }

var A_arbace_reflect__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_reflect__init_A_invoke, New: A_arbace_reflect__init_A_new}

var A_arbace_reflect__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.reflect__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_reflect.A_arbace_reflect__init_A", Source: "reflect.ae"})

func init() { i := A_arbace_reflect__init_A_class.Info(); i.IsInstance = A_arbace_reflect__init_A_InstanceOf; i.Init = A_arbace_reflect__init_A_Init; i.Table = A_arbace_reflect__init_A_members }
