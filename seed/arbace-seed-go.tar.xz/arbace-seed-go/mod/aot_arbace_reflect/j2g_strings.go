//line j2g_strings.ae:1
package aot_arbace_reflect

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn10,arbace.setkn2,asyn3,setkn6,authorkn5,addedkn3,dockn9,ancestorskn9,reflectorkn5,baseskn7,membersys21,arbace.core.protocols6,datafykn4,namekn4,flagkn8,contextsyn7,string?yn1,dkn4,linekn6,columnkn6,methodkn5,fieldv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn14,arbace.reflectm6,R4,s15,Stuart HallowayR5,s3,1.3R6,s1112,Reflection on Host Types\nAlpha - subject to change.\n\nTwo main entry points:\n\n* type-reflect reflects on something that implements TypeReference.\n* reflect (for REPL use) reflects on the class of an instance, or\n  on a class if passed a class\n\nKey features:\n\n* Exposes the read side of reflection as pure data. Reflecting\n  on a type returns a map with keys :bases, :flags, and :members.\n\n* Canonicalizes class names as Clojure symbols. Types can extend\n  to the TypeReference protocol to indicate that they can be\n  unambiguously resolved as a type name. The canonical format\n  requires one non-Java-ish convention: array brackets are <>\n  instead of [] so they can be part of a Clojure symbol.\n\n* Pluggable Reflectors for different implementations. The default\n  JavaReflector is good when you have a class in hand. (Clojure's\n  AsmReflector reads class files with ASM, which Arbace has not: its\n  reflection throws.)\n\nPlatform implementers must:\n\n* Create an implementation of Reflector.\n* Create one or more implementations of TypeReference.\n* def default-reflector to be an instance that satisfies Reflector.v11,arbace.core13,*loaded-libs*v11,arbace.core18,-cache-protocol-fnC24,arbace.reflect.ReflectorC28,arbace.reflect.TypeReferencev11,arbace.core5,mergev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR7,R8,v11,arbace.core7,partialv11,arbace.core6,zipmapv11,arbace.core3,mapv11,arbace.core3,setv10,arbace.set10,differencev11,arbace.core5,applyv14,arbace.reflect17,default-reflectorv11,arbace.core8,hash-mapv14,arbace.reflect10,do-reflectR9,v11,arbace.core4,keysv11,arbace.core6,mapcatv11,arbace.core4,valsv11,arbace.core10,merge-withv11,arbace.core4,intov11,arbace.core11,select-keysV1,R10,v14,arbace.reflect12,type-reflectv11,arbace.core6,class?v11,arbace.core5,classv13,arbace.string7,replacev11,arbace.core3,strv14,arbace.reflect8,typenamev11,arbace.core6,symbolv11,arbace.core9,with-metaR11,v13,arbace.datafy6,datafyR12,R13,R14,v11,arbace.core7,keywordc76,c91,v14,arbace.reflect21,descriptor-class-namem18,s1,Js4,longs1,Ss5,shorts1,Zs7,booleans1,Cs4,chars1,Fs5,floats1,Bs4,bytes1,Vs4,voids1,Is3,ints1,Ds6,doublev11,arbace.core4,subsl1,v11,arbace.core7,string?v11,arbace.core6,pr-strML2,R15,R16,m4,R17,i70,R18,i10,ML2,R15,R16,m4,R17,i80,R18,i10,v11,arbace.core6,reducev11,arbace.core3,notv14,arbace.reflect16,flag-descriptorsv14,arbace.reflect7,typesymv11,arbace.core3,vecv14,arbace.reflect11,parse-flagsR19,v14,arbace.reflect16,constructor->mapv14,arbace.reflect11,method->mapR20,v14,arbace.reflect10,field->mapC28,arbace.reflect.ClassResolverC21,java.lang.ClassLoaderv14,arbace.reflect13,resource-name")

var Lit_1 *jrt.String = jrt.Intern("/")

var Lit_2 *jrt.String = jrt.Intern(".")

var Lit_3 *jrt.String = jrt.Intern("[]")

var Lit_4 *jrt.String = jrt.Intern("<>")

var Lit_5 *jrt.String = jrt.Intern("arbace.reflect$eval1938000121$fn__1938000122$G__1938000114__1938000125")

var Lit_6 *jrt.String = jrt.Intern("arbace.reflect$eval1938000121$fn__1938000122$G__1938000113__1938000129")

var Lit_7 *jrt.String = jrt.Intern("resolve_class")

var Lit_8 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_9 *jrt.String = jrt.Intern("arbace.reflect$eval659000020$fn__659000021$G__659000013__659000024")

var Lit_10 *jrt.String = jrt.Intern("arbace.reflect$eval659000020$fn__659000021$G__659000012__659000028")

var Lit_11 *jrt.String = jrt.Intern("do_reflect")

var Lit_12 *jrt.String = jrt.Intern("arbace.reflect$eval659000044$fn__659000045$G__659000037__659000047")

var Lit_13 *jrt.String = jrt.Intern("arbace.reflect$eval659000044$fn__659000045$G__659000036__659000050")

var Lit_14 *jrt.String = jrt.Intern("typename")

var Lit_15 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_16 *jrt.String = jrt.Intern("[")

var Lit_17 *jrt.String = jrt.Intern("arbace.reflect$parse_flags$fn__1938000032")

var Lit_18 *jrt.String = jrt.Intern(".class")

var Lit_19 *jrt.String = jrt.Intern("arbace.reflect$type_reflect$make_ancestor_map__659000061")

var Lit_20 *jrt.String = jrt.Intern("arbace.reflect$type_reflect$fn__659000063")

var Lit_21 *jrt.String = jrt.Intern("arbace.reflect$typesym$fn__1938000019")

var Lit_22 *jrt.String = jrt.Intern("v14,arbace.reflect8,typename")

var Lit_23 *jrt.String = jrt.Intern("class-resolver")

var Lit_24 *jrt.String = jrt.Intern("AsmReflector: no class file reader in Arbace (reflecting ")

var Lit_25 *jrt.String = jrt.Intern(")")

var Lit_26 *jrt.String = jrt.Intern("kn15,declaring-classkn4,namekn15,parameter-typeskn15,exception-typeskn5,flagsR0,R1,R2,R3,R4,v11,arbace.core5,classv11,arbace.core9,imap-consv11,arbace.core3,notv11,arbace.core3,seqv11,arbace.core6,concatV5,R1,R0,R2,R3,R4,v11,arbace.core10,identical?v11,arbace.core5,assocv11,arbace.core9,contains?v11,arbace.core6,dissocv11,arbace.core9,not-emptyS5,R1,R0,R2,R3,R4,v11,arbace.core9,with-metav11,arbace.core4,intov11,arbace.core4,somev11,arbace.core4,valsv11,arbace.core3,setv11,arbace.core4,keys")

var Lit_27 *jrt.String = jrt.Intern("name")

var Lit_28 *jrt.String = jrt.Intern("declaring-class")

var Lit_29 *jrt.String = jrt.Intern("parameter-types")

var Lit_30 *jrt.String = jrt.Intern("exception-types")

var Lit_31 *jrt.String = jrt.Intern("flags")

var Lit_32 *jrt.String = jrt.Intern("Can't create empty: ")

var Lit_33 *jrt.String = jrt.Intern("arbace.reflect.Constructor")

var Lit_34 *jrt.String = jrt.Intern("kn5,flagskn4,namekn4,typekn15,declaring-classR0,R1,R2,R3,v11,arbace.core5,classv11,arbace.core9,imap-consv11,arbace.core3,notv11,arbace.core3,seqv11,arbace.core6,concatV4,R1,R2,R3,R0,v11,arbace.core10,identical?v11,arbace.core5,assocv11,arbace.core9,contains?v11,arbace.core6,dissocv11,arbace.core9,not-emptyS4,R1,R2,R3,R0,v11,arbace.core9,with-metav11,arbace.core4,intov11,arbace.core4,somev11,arbace.core4,valsv11,arbace.core3,setv11,arbace.core4,keys")

var Lit_35 *jrt.String = jrt.Intern("type")

var Lit_36 *jrt.String = jrt.Intern("arbace.reflect.Field")

var Lit_37 *jrt.String = jrt.Intern("kn5,baseskn5,flagskn7,memberskn5,classv14,arbace.reflect14,typeref->classR0,v11,arbace.core9,not-emptyR1,v14,arbace.reflect11,parse-flagsR2,v10,arbace.set5,unionv11,arbace.core3,setv11,arbace.core3,mapv14,arbace.reflect7,typesymv11,arbace.core5,basesR3,v14,arbace.reflect15,declared-fieldsv14,arbace.reflect16,declared-methodsv14,arbace.reflect21,declared-constructors")

var Lit_38 *jrt.String = jrt.Intern("classloader")

var Lit_39 *jrt.String = jrt.Intern("kn15,declaring-classkn4,namekn11,return-typekn15,parameter-typeskn15,exception-typeskn5,flagsR0,R1,R2,R3,R4,R5,v11,arbace.core5,classv11,arbace.core9,imap-consv11,arbace.core3,notv11,arbace.core3,seqv11,arbace.core6,concatV6,R1,R2,R0,R3,R4,R5,v11,arbace.core10,identical?v11,arbace.core5,assocv11,arbace.core9,contains?v11,arbace.core6,dissocv11,arbace.core9,not-emptyS6,R2,R1,R0,R3,R4,R5,v11,arbace.core9,with-metav11,arbace.core4,intov11,arbace.core4,somev11,arbace.core4,valsv11,arbace.core3,setv11,arbace.core4,keys")

var Lit_40 *jrt.String = jrt.Intern("return-type")

var Lit_41 *jrt.String = jrt.Intern("arbace.reflect.Method")

var Lit_42 *jrt.String = jrt.Intern("kn6,authorkn5,addedkn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn8,arglistsyn9,reflectoryn7,typerefkn2,onyn24,arbace.reflect.Reflectorkn12,on-interfacekn4,sigskn10,do-reflectkn3,tagkn4,namekn3,varkn10,method-mapkn15,method-builderskn8,protocolyn9,Reflectoryn1,oyn28,arbace.reflect.TypeReferencekn8,typenameyn13,TypeReferencekn8,declaredyn1,&yn7,optionsyn3,objv11,arbace.core5,in-nsMyn14,arbace.reflectm6,R0,s15,Stuart HallowayR1,s3,1.3R2,s1112,Reflection on Host Types\nAlpha - subject to change.\n\nTwo main entry points:\n\n* type-reflect reflects on something that implements TypeReference.\n* reflect (for REPL use) reflects on the class of an instance, or\n  on a class if passed a class\n\nKey features:\n\n* Exposes the read side of reflection as pure data. Reflecting\n  on a type returns a map with keys :bases, :flags, and :members.\n\n* Canonicalizes class names as Clojure symbols. Types can extend\n  to the TypeReference protocol to indicate that they can be\n  unambiguously resolved as a type name. The canonical format\n  requires one non-Java-ish convention: array brackets are <>\n  instead of [] so they can be part of a Clojure symbol.\n\n* Pluggable Reflectors for different implementations. The default\n  JavaReflector is good when you have a class in hand. (Clojure's\n  AsmReflector reads class files with ASM, which Arbace has not: its\n  reflection throws.)\n\nPlatform implementers must:\n\n* Create an implementation of Reflector.\n* Create one or more implementations of TypeReference.\n* def default-reflector to be an instance that satisfies Reflector.m6,R0,s15,Stuart HallowayR1,s3,1.3R2,s1112,Reflection on Host Types\nAlpha - subject to change.\n\nTwo main entry points:\n\n* type-reflect reflects on something that implements TypeReference.\n* reflect (for REPL use) reflects on the class of an instance, or\n  on a class if passed a class\n\nKey features:\n\n* Exposes the read side of reflection as pure data. Reflecting\n  on a type returns a map with keys :bases, :flags, and :members.\n\n* Canonicalizes class names as Clojure symbols. Types can extend\n  to the TypeReference protocol to indicate that they can be\n  unambiguously resolved as a type name. The canonical format\n  requires one non-Java-ish convention: array brackets are <>\n  instead of [] so they can be part of a Clojure symbol.\n\n* Pluggable Reflectors for different implementations. The default\n  JavaReflector is good when you have a class in hand. (Clojure's\n  AsmReflector reads class files with ASM, which Arbace has not: its\n  reflection throws.)\n\nPlatform implementers must:\n\n* Create an implementation of Reflector.\n* Create one or more implementations of TypeReference.\n* def default-reflector to be an instance that satisfies Reflector.R3,v14,arbace.reflect9,Reflectorm6,R4,i44,R5,i1,R6,s17,arbace/reflect.aem6,R4,i44,R5,i1,R6,s17,arbace/reflect.aeC24,arbace.reflect.Reflectorv11,arbace.core11,alter-meta!v11,arbace.core5,assocR2,v11,arbace.core20,assert-same-protocolL1,Myn10,do-reflectm4,R2,nR7,L1,V2,R8,R9,v11,arbace.core14,alter-var-rootv11,arbace.core5,mergem6,R10,R11,R12,C24,arbace.reflect.ReflectorR2,s37,Protocol for reflection implementers.R13,m2,R14,m8,R15,nR16,Myn10,do-reflectm4,R2,nR7,L1,V2,R8,R9,R7,L1,V2,R8,R9,R2,nR17,R18,m2,R14,R14,R19,v11,arbace.core6,internv11,arbace.core4,*ns*v11,arbace.core9,with-metaMyn10,do-reflectm4,R2,nR7,L1,V2,R8,R9,m8,R15,nR16,Myn10,do-reflectm4,R2,nR7,L1,V2,R8,R9,R7,L1,V2,R8,R9,R2,nR20,v11,arbace.core14,-reset-methodsR21,v14,arbace.reflect13,TypeReferencem6,R4,i48,R5,i1,R6,s17,arbace/reflect.aem6,R4,i48,R5,i1,R6,s17,arbace/reflect.aeC28,arbace.reflect.TypeReferenceL1,Myn8,typenamem4,R2,s82,Returns Java name as returned by ASM getClassName, e.g. byte[], java.lang.String[]R7,L1,V1,R22,m6,R10,R23,R12,C28,arbace.reflect.TypeReferenceR2,s194,A TypeReference can be unambiguously converted to a type name on\n   the host platform.\n\n   All typerefs are normalized into symbols. If you need to\n   normalize a typeref yourself, call typesym.m2,R24,m8,R15,nR16,Myn8,typenamem4,R2,s82,Returns Java name as returned by ASM getClassName, e.g. byte[], java.lang.String[]R7,L1,V1,R22,R7,L1,V1,R22,R2,s82,Returns Java name as returned by ASM getClassName, e.g. byte[], java.lang.String[]m2,R24,R24,Myn8,typenamem4,R2,s82,Returns Java name as returned by ASM getClassName, e.g. byte[], java.lang.String[]R7,L1,V1,R22,m8,R15,nR16,Myn8,typenamem4,R2,s82,Returns Java name as returned by ASM getClassName, e.g. byte[], java.lang.String[]R7,L1,V1,R22,R7,L1,V1,R22,R2,s82,Returns Java name as returned by ASM getClassName, e.g. byte[], java.lang.String[]R25,v14,arbace.reflect17,default-reflectorm8,R26,TR4,i56,R5,i1,R6,s17,arbace/reflect.aev14,arbace.reflect12,type-reflectm12,R7,L1,V3,R9,R27,R28,R2,s1374,Alpha - subject to change.\n   Reflect on a typeref, returning a map with :bases, :flags, and\n  :members. In the discussion below, names are always Clojure symbols.\n\n   :bases            a set of names of the type's bases\n   :flags            a set of keywords naming the boolean attributes\n                     of the type.\n   :members          a set of the type's members. Each member is a map\n                     and can be a constructor, method, or field.\n\n   Keys common to all members:\n   :name             name of the type\n   :declaring-class  name of the declarer\n   :flags            keyword naming boolean attributes of the member\n\n   Keys specific to constructors:\n   :parameter-types  vector of parameter type names\n   :exception-types  vector of exception type names\n\n   Key specific to methods:\n   :parameter-types  vector of parameter type names\n   :exception-types  vector of exception type names\n   :return-type      return type name\n\n   Keys specific to fields:\n   :type             type name\n\n   Options:\n\n     :ancestors     in addition to the keys described above, also\n                    include an :ancestors key with the entire set of\n                    ancestors, and add all ancestor members to\n                    :members.\n     :reflector     implementation to use. Defaults to JavaReflector\n                    (AsmReflector throws in Arbace).R1,s3,1.3R4,i58,R5,i1,R6,s17,arbace/reflect.aev14,arbace.reflect7,reflectm12,R7,L1,V3,R29,R27,R28,R2,s154,Alpha - subject to change.\n   Reflect on the type of obj (or obj itself if obj is a class).\n   Return value and options are the same as for type-reflect. R1,s3,1.3R4,i115,R5,i1,R6,s17,arbace/reflect.aev11,arbace.core4,load")

var Lit_43 *jrt.String = jrt.Intern("arbace.reflect$eval659000004$loading__1927001464__auto____659000005")

var Lit_44 *jrt.String = jrt.Intern("arbace.reflect$eval659000008$fn__659000009")

var Lit_45 *jrt.String = jrt.Intern("Protocol for reflection implementers.")

var Lit_46 *jrt.String = jrt.Intern("arbace.reflect$eval659000020$fn__659000021")

var Lit_47 *jrt.String = jrt.Intern("A TypeReference can be unambiguously converted to a type name on\n   the host platform.\n\n   All typerefs are normalized into symbols. If you need to\n   normalize a typeref yourself, call typesym.")

var Lit_48 *jrt.String = jrt.Intern("arbace.reflect$eval659000044$fn__659000045")

var Lit_49 *jrt.String = jrt.Intern("arbace.reflect$type_reflect")

var Lit_50 *jrt.String = jrt.Intern("arbace.reflect$reflect")

var Lit_51 *jrt.String = jrt.Intern("reflect/java")
