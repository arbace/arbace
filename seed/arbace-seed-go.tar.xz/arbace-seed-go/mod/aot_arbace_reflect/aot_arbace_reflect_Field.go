//line aot_arbace_reflect_Field.ae:1
package aot_arbace_reflect

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)

























































































































































func A_arbace_reflect_Field_A_New_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5 any, p6, p7 int32) *A_arbace_reflect_Field_A { A_arbace_reflect_Field_A_Init(); t := &A_arbace_reflect_Field_A{}; t.Ctor_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :161:1
func (t *A_arbace_reflect_Field_A) Ctor_O_O_O_O_O_O_I_I(name, type_, declaring_class, flags, __meta, __extmap any, __hash, __hasheq int32) { t.F_name = name; t.F_type = type_; t.F_declaring_class = declaring_class; t.F_flags = flags; t.F___meta = __meta; t.F___extmap = __extmap; t.F___hash = __hash; t.F___hasheq = __hasheq }
//line :161:1
func A_arbace_reflect_Field_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_reflect_Field_A { A_arbace_reflect_Field_A_Init(); t := &A_arbace_reflect_Field_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :161:1
func (t *A_arbace_reflect_Field_A) Ctor_O_O_O_O(name, type_, declaring_class, flags any) { t.Ctor_O_O_O_O_O_O_I_I(name, type_, declaring_class, flags, nil, nil, 0, 0) }
//line :161:1
func A_arbace_reflect_Field_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_reflect_Field_A { A_arbace_reflect_Field_A_Init(); t := &A_arbace_reflect_Field_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :161:1
func (t *A_arbace_reflect_Field_A) Ctor_O_O_O_O_O_O(name, type_, declaring_class, flags, __meta, __extmap any) { t.Ctor_O_O_O_O_O_O_I_I(name, type_, declaring_class, flags, __meta, __extmap, 0, 0) }
//line :161:1
func A_arbace_reflect_Field_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_reflect_Field_A_Init(); return lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref()) }
//line :161:1
func A_arbace_reflect_Field_A_Create_IPersistentMap__A_arbace_reflect_Field_A(m__ lang.IPersistentMap) *A_arbace_reflect_Field_A { A_arbace_reflect_Field_A_Init(); var m___2 lang.IPersistentMap = m__; var v__0 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_27).Ref(), nil); var v__1 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_35).Ref(), nil); var v__2 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_28).Ref(), nil); var v__3 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_31).Ref(), nil); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_27).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_35).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_28).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_31).Ref()); return A_arbace_reflect_Field_A_New_O_O_O_O_O_O_I_I(v__0, v__1, v__2, v__3, nil, lang.RT_SeqOrElse_O__O_NoInit(m___2), 0, 0) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Hasheq__I() int32 { var hq__231000058__auto____1 int32 = t.F___hasheq; if lang.Numbers_IsZero_J__Z_NoInit(int64(hq__231000058__auto____1)) { var h__231000059__auto____2 int32 = lang.RT_IntCast_J__I_NoInit(lang.Numbers_Xor_J_J__J_NoInit(-161407059, int64(lang.APersistentMap_MapHasheq_IPersistentMap__I_NoInit(t)))); t.F___hasheq = h__231000059__auto____2; return h__231000059__auto____2 } else { return hq__231000058__auto____1 } }
//line :161:1
func (t *A_arbace_reflect_Field_A) HashCode__I() int32 { var hash__231000061__auto____1 int32 = t.F___hash; if lang.Numbers_IsZero_J__Z_NoInit(int64(hash__231000061__auto____1)) { var h__231000062__auto____2 int32 = lang.APersistentMap_MapHash_IPersistentMap__I_NoInit(t); t.F___hash = h__231000062__auto____2; return h__231000062__auto____2 } else { return hash__231000061__auto____1 } }
//line :161:1
func (t *A_arbace_reflect_Field_A) Equals_O__Z(G__1939000085__1_ any) bool { return lang.APersistentMap_MapEquals_IPersistentMap_O__Z_NoInit(t, G__1939000085__1_) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F___meta) }
//line :161:1
func (t *A_arbace_reflect_Field_A) WithMeta_IPersistentMap__IObj(G__1939000085__1_ lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Field_A_New_O_O_O_O_O_O_I_I(t.F_name, t.F_type, t.F_declaring_class, t.F_flags, G__1939000085__1_, t.F___extmap, t.F___hash, t.F___hasheq) }
//line :161:1
func (t *A_arbace_reflect_Field_A) ValAt_O__O(k__231000067__auto____1 any) any { return t.ValAt_O_O__O(k__231000067__auto____1, nil) }
//line :161:1
func (t *A_arbace_reflect_Field_A) ValAt_O_O__O(k__231000069__auto____1, else__231000070__auto____2 any) any { var G__1939000098__3_ any = k__231000069__auto____1; switch lang.Util_Hash_O__I_NoInit(G__1939000098__3_) >> 19 & 3 { case 0: if any(G__1939000098__3_) == any(A_arbace_reflect_Field_A_const_0) { return t.F_flags }; case 1: if any(G__1939000098__3_) == any(A_arbace_reflect_Field_A_const_1) { return t.F_name }; case 2: if any(G__1939000098__3_) == any(A_arbace_reflect_Field_A_const_2) { return t.F_type }; case 3: if any(G__1939000098__3_) == any(A_arbace_reflect_Field_A_const_3) { return t.F_declaring_class }; default:}; return lang.RT_Get_O_O_O__O_NoInit(t.F___extmap, k__231000069__auto____1, else__231000070__auto____2) }
//line :161:1
func (t *A_arbace_reflect_Field_A) GetLookupThunk_Keyword__ILookupThunk(k__231000072__auto____1 *lang.Keyword) lang.ILookupThunk { var tmp1 any; var gclass__2 any; var root_2 any = A_arbace_reflect_Field_A_const_4.GetRawRoot__O(); var linked_3 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_4 lang.IFn; if linked_3 == nil { ifn_4 = lang.IFn_Cast(root_2) } else { ifn_4 = nil }; var arg_5 any = t; if linked_3 == nil { gclass__2 = ifn_4.Invoke_O__O(arg_5) } else { gclass__2 = linked_3.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2, arg_5) }; var G__1939000089__3_ any = k__231000072__auto____1.Ref(); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1939000089__3_) >> 19 & 3 { case 0: if any(G__1939000089__3_) == any(A_arbace_reflect_Field_A_const_0) { tmp1 = A_arbace_reflect_Field_reify__1939000090_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 1: if any(G__1939000089__3_) == any(A_arbace_reflect_Field_A_const_1) { tmp1 = A_arbace_reflect_Field_reify__1939000092_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 2: if any(G__1939000089__3_) == any(A_arbace_reflect_Field_A_const_2) { tmp1 = A_arbace_reflect_Field_reify__1939000094_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 3: if any(G__1939000089__3_) == any(A_arbace_reflect_Field_A_const_3) { tmp1 = A_arbace_reflect_Field_reify__1939000096_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; default:}; tmp1 = nil}; return lang.ILookupThunk_Cast(tmp1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Count__I() int32 { return lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(4, int64(lang.RT_Count_O__I_NoInit(t.F___extmap)))) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Empty__IPersistentCollection() lang.IPersistentCollection { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, Lit_36), jrt.RefArrayOf(jrt.Object_class, nil, nil))))) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Cons_O__IPersistentCollection(e__231000076__auto____1 any) lang.IPersistentCollection { return lang.IPersistentCollection_Cast(A_arbace_reflect_Field_A_const_5.Invoke_O_O__O(t, e__231000076__auto____1)) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Equiv_O__Z(G__1939000085__1_ any) bool { var tmp1 *jrt.Boolean; var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(t, G__1939000085__1_); if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2) } else { var tmp2 any; var root_23 any = A_arbace_reflect_Field_A_const_4.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = t; if linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_23, arg_26) }; var tmp3 any = tmp2; var tmp4 any; var root_27 any = A_arbace_reflect_Field_A_const_4.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = G__1939000085__1_; if linked_28 == nil { tmp4 = ifn_29.Invoke_O__O(arg_30) } else { tmp4 = linked_28.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_27, arg_30) }; if lang.Util_Identical_O_O__Z_NoInit(tmp3, tmp4) { var G__1939000085__3_ any = G__1939000085__1_; var tmp5 any = t.F_name; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_reflect_Field_A_Cast(G__1939000085__3_).F_name); if and__1927000168__auto____4 { var tmp6 any = t.F_type; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_reflect_Field_A_Cast(G__1939000085__3_).F_type); if and__1927000168__auto____5 { var tmp7 any = t.F_declaring_class; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_reflect_Field_A_Cast(G__1939000085__3_).F_declaring_class); if and__1927000168__auto____6 { var tmp8 any = t.F_flags; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp8, A_arbace_reflect_Field_A_Cast(G__1939000085__3_).F_flags); if and__1927000168__auto____7 { var tmp9 any = t.F___extmap; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_reflect_Field_A_Cast(G__1939000085__3_).F___extmap)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4) } } else { tmp1 = nil } }; return lang.RT_BooleanCast_O__Z_NoInit(tmp1.Ref()) }
//line :161:1
func (t *A_arbace_reflect_Field_A) ContainsKey_O__Z(k__231000079__auto____1 any) bool { var tmp1 any; var root_31 any = A_arbace_reflect_Field_A_const_6.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t, t.ValAt_O_O__O(k__231000079__auto____1, t))).Ref(); if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_31, arg_34) }; return jrt.NN(jrt.Boolean_Cast(tmp1)).BooleanValue__Z() }
//line :161:1
func (t *A_arbace_reflect_Field_A) EntryAt_O__IMapEntry(k__231000081__auto____1 any) lang.IMapEntry { var tmp1 *lang.MapEntry; var v__231000082__auto____2 any = t.ValAt_O_O__O(k__231000081__auto____1, t); if lang.Util_Identical_O_O__Z_NoInit(t, v__231000082__auto____2) { tmp1 = nil } else { tmp1 = lang.MapEntry_Create_O_O__MapEntry(k__231000081__auto____1, v__231000082__auto____2) }; return Up_MapEntry_IMapEntry(tmp1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Seq__ISeq() lang.ISeq { var tmp1 any; var root_35 any = A_arbace_reflect_Field_A_const_7.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var root_39 any = A_arbace_reflect_Field_A_const_8.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Field_A_const_1, t.F_name).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Field_A_const_2, t.F_type).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Field_A_const_3, t.F_declaring_class).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Field_A_const_0, t.F_flags).Ref()); var arg_43 any = t.F___extmap; if linked_40 == nil { arg_38 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_38 = linked_40.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; if linked_36 == nil { tmp1 = ifn_37.Invoke_O__O(arg_38) } else { tmp1 = linked_36.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_35, arg_38) }; return lang.ISeq_Cast(tmp1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Iterator__Iterator() jrt.Iterator { var tmp1 lang.ILookup = t; var tmp2 lang.IPersistentVector = lang.IPersistentVector_Cast(A_arbace_reflect_Field_A_const_9); return lang.RecordIterator_New_ILookup_IPersistentVector_Iterator(tmp1, tmp2, lang.RT_Iter_O__Iterator_NoInit(t.F___extmap)) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Assoc_O_O__IPersistentMap(k__231000086__auto____1, G__1939000085__2_ any) lang.IPersistentMap { var tmp1 *A_arbace_reflect_Field_A; var pred__1939000087__3 any = A_arbace_reflect_Field_A_const_10.GetRawRoot__O(); var expr__1939000088__4 any = k__231000086__auto____1; if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000087__3).Invoke_O_O__O(A_arbace_reflect_Field_A_const_1, expr__1939000088__4)) { tmp1 = A_arbace_reflect_Field_A_New_O_O_O_O_O_O(G__1939000085__2_, t.F_type, t.F_declaring_class, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000087__3).Invoke_O_O__O(A_arbace_reflect_Field_A_const_2, expr__1939000088__4)) { tmp1 = A_arbace_reflect_Field_A_New_O_O_O_O_O_O(t.F_name, G__1939000085__2_, t.F_declaring_class, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000087__3).Invoke_O_O__O(A_arbace_reflect_Field_A_const_3, expr__1939000088__4)) { tmp1 = A_arbace_reflect_Field_A_New_O_O_O_O_O_O(t.F_name, t.F_type, G__1939000085__2_, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000087__3).Invoke_O_O__O(A_arbace_reflect_Field_A_const_0, expr__1939000088__4)) { tmp1 = A_arbace_reflect_Field_A_New_O_O_O_O_O_O(t.F_name, t.F_type, t.F_declaring_class, G__1939000085__2_, t.F___meta, t.F___extmap) } else { var tmp2 any = t.F_name; var tmp3 any = t.F_type; var tmp4 any = t.F_declaring_class; var tmp5 any = t.F_flags; var tmp6 any = t.F___meta; var tmp7 any; var root_44 any = A_arbace_reflect_Field_A_const_11.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = t.F___extmap; var arg_48 any = k__231000086__auto____1; var arg_49 any = G__1939000085__2_; if linked_45 == nil { tmp7 = ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { tmp7 = linked_45.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) }; tmp1 = A_arbace_reflect_Field_A_New_O_O_O_O_O_O(tmp2, tmp3, tmp4, tmp5, tmp6, tmp7) } } } }; return Up_A_arbace_reflect_Field_A_IPersistentMap(tmp1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Without_O__IPersistentMap(k__231000088__auto____1 any) lang.IPersistentMap { var tmp1 any; var tmp2 any; var root_50 any = A_arbace_reflect_Field_A_const_12.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = A_arbace_reflect_Field_A_const_13; var arg_54 any = k__231000088__auto____1; if linked_51 == nil { tmp2 = ifn_52.Invoke_O_O__O(arg_53, arg_54) } else { tmp2 = linked_51.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_50, arg_53, arg_54) }; if jrt.J2g_Truth(tmp2) { var root_55 any = A_arbace_reflect_Field_A_const_14.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any; var root_60 any = A_arbace_reflect_Field_A_const_15.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_65 any = A_arbace_reflect_Field_A_const_16.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_69 any = t; if linked_66 == nil { arg_63 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { arg_63 = linked_66.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; var arg_64 any = t.F___meta; if linked_61 == nil { arg_58 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { arg_58 = linked_61.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; var arg_59 any = k__231000088__auto____1; if linked_56 == nil { tmp1 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { tmp1 = linked_56.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) } } else { var tmp3 any = t.F_name; var tmp4 any = t.F_type; var tmp5 any = t.F_declaring_class; var tmp6 any = t.F_flags; var tmp7 any = t.F___meta; var tmp8 any; var root_70 any = A_arbace_reflect_Field_A_const_17.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var root_74 any = A_arbace_reflect_Field_A_const_14.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = t.F___extmap; var arg_78 any = k__231000088__auto____1; if linked_75 == nil { arg_73 = ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { arg_73 = linked_75.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_74, arg_77, arg_78) }; if linked_71 == nil { tmp8 = ifn_72.Invoke_O__O(arg_73) } else { tmp8 = linked_71.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_70, arg_73) }; tmp1 = A_arbace_reflect_Field_A_New_O_O_O_O_O_O(tmp3, tmp4, tmp5, tmp6, tmp7, tmp8) }; return lang.IPersistentMap_Cast(tmp1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Size__I() int32 { return t.Count__I() }
//line :161:1
func (t *A_arbace_reflect_Field_A) IsEmpty__Z() bool { return lang.Util_Equiv_J_J__Z_NoInit(0, int64(t.Count__I())) }
//line :161:1
func (t *A_arbace_reflect_Field_A) ContainsValue_O__Z(v__231000092__auto____1 any) bool { var tmp1 any; var root_79 any = A_arbace_reflect_Field_A_const_18.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, v__231000092__auto____1)); var arg_83 any; var root_84 any = A_arbace_reflect_Field_A_const_19.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = t; if linked_85 == nil { arg_83 = ifn_86.Invoke_O__O(arg_87) } else { arg_83 = linked_85.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_84, arg_87) }; if linked_80 == nil { tmp1 = ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { tmp1 = linked_80.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) }; return lang.RT_BooleanCast_O__Z_NoInit(tmp1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Get_O__O(k__231000094__auto____1 any) any { return t.ValAt_O__O(k__231000094__auto____1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Put_O_O__O(k__231000096__auto____1, v__231000097__auto____2 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Remove_O__O(k__231000099__auto____1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :161:1
func (t *A_arbace_reflect_Field_A) PutAll_Map__V(m__231000101__auto____1 jrt.Map) { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Clear__V() { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :161:1
func (t *A_arbace_reflect_Field_A) KeySet__Set() jrt.Set { var tmp1 any; var root_88 any = A_arbace_reflect_Field_A_const_20.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any; var root_92 any = A_arbace_reflect_Field_A_const_21.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t; if linked_93 == nil { arg_91 = ifn_94.Invoke_O__O(arg_95) } else { arg_91 = linked_93.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_92, arg_95) }; if linked_89 == nil { tmp1 = ifn_90.Invoke_O__O(arg_91) } else { tmp1 = linked_89.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_88, arg_91) }; return jrt.Set_Cast(tmp1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) Values__Collection() jrt.Collection { var tmp1 any; var root_96 any = A_arbace_reflect_Field_A_const_19.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = t; if linked_97 == nil { tmp1 = ifn_98.Invoke_O__O(arg_99) } else { tmp1 = linked_97.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_96, arg_99) }; return jrt.Collection_Cast(tmp1) }
//line :161:1
func (t *A_arbace_reflect_Field_A) EntrySet__Set() jrt.Set { var tmp1 any; var root_100 any = A_arbace_reflect_Field_A_const_20.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = t; if linked_101 == nil { tmp1 = ifn_102.Invoke_O__O(arg_103) } else { tmp1 = linked_101.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_100, arg_103) }; return jrt.Set_Cast(tmp1) }
//line :161:1
func A_arbace_reflect_Field_reify__1939000090_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Field_reify__1939000090_A { t := &A_arbace_reflect_Field_reify__1939000090_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000090_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000090_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_7 any; var tmp2 *lang.Var; A_arbace_reflect_Field_A_Init(); tmp2 = A_arbace_reflect_Field_A_const_4; root_7 = jrt.NN(tmp2).GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_9 lang.IFn; if linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = gtarget__1; if linked_8 == nil { tmp1 = ifn_9.Invoke_O__O(arg_10) } else { tmp1 = linked_8.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_7, arg_10) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Field_A_Cast(gtarget__1).F_flags } else { return t } }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000090_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000090_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Field_reify__1939000090_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :161:1
func A_arbace_reflect_Field_reify__1939000092_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Field_reify__1939000092_A { t := &A_arbace_reflect_Field_reify__1939000092_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000092_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000092_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_11 any; var tmp2 *lang.Var; A_arbace_reflect_Field_A_Init(); tmp2 = A_arbace_reflect_Field_A_const_4; root_11 = jrt.NN(tmp2).GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = gtarget__1; if linked_12 == nil { tmp1 = ifn_13.Invoke_O__O(arg_14) } else { tmp1 = linked_12.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_11, arg_14) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Field_A_Cast(gtarget__1).F_name } else { return t } }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000092_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000092_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Field_reify__1939000092_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :161:1
func A_arbace_reflect_Field_reify__1939000094_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Field_reify__1939000094_A { t := &A_arbace_reflect_Field_reify__1939000094_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000094_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000094_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_15 any; var tmp2 *lang.Var; A_arbace_reflect_Field_A_Init(); tmp2 = A_arbace_reflect_Field_A_const_4; root_15 = jrt.NN(tmp2).GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = gtarget__1; if linked_16 == nil { tmp1 = ifn_17.Invoke_O__O(arg_18) } else { tmp1 = linked_16.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_15, arg_18) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Field_A_Cast(gtarget__1).F_type } else { return t } }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000094_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000094_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Field_reify__1939000094_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :161:1
func A_arbace_reflect_Field_reify__1939000096_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Field_reify__1939000096_A { t := &A_arbace_reflect_Field_reify__1939000096_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000096_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000096_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_19 any; var tmp2 *lang.Var; A_arbace_reflect_Field_A_Init(); tmp2 = A_arbace_reflect_Field_A_const_4; root_19 = jrt.NN(tmp2).GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = gtarget__1; if linked_20 == nil { tmp1 = ifn_21.Invoke_O__O(arg_22) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_19, arg_22) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Field_A_Cast(gtarget__1).F_declaring_class } else { return t } }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000096_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :161:1
func (t *A_arbace_reflect_Field_reify__1939000096_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Field_reify__1939000096_A_New_IPersistentMap_O(m, t.F_gclass) }



















































































































type A_arbace_reflect_Field_A struct{ jrt.Object; F_name, F_type, F_declaring_class, F_flags, F___meta, F___extmap any; F___hash, F___hasheq int32 }

func (t *A_arbace_reflect_Field_A) Is_IRecord() {}

func (t *A_arbace_reflect_Field_A) Is_IHashEq() {}

func (t *A_arbace_reflect_Field_A) Is_IObj() {}

func (t *A_arbace_reflect_Field_A) Is_ILookup() {}

func (t *A_arbace_reflect_Field_A) Is_IKeywordLookup() {}

func (t *A_arbace_reflect_Field_A) Is_IPersistentMap() {}

func (t *A_arbace_reflect_Field_A) Is_Map() {}

func (t *A_arbace_reflect_Field_A) Is_Serializable() {}

func (t *A_arbace_reflect_Field_A) Is_IMeta() {}

func (t *A_arbace_reflect_Field_A) Is_Iterable() {}

func (t *A_arbace_reflect_Field_A) Is_Associative() {}

func (t *A_arbace_reflect_Field_A) Is_Counted() {}

func (t *A_arbace_reflect_Field_A) Is_IPersistentCollection() {}

func (t *A_arbace_reflect_Field_A) Is_Seqable() {}

var A_arbace_reflect_Field_A_const_pool *jrt.RefArray

var A_arbace_reflect_Field_A_const_0 *lang.Keyword

var A_arbace_reflect_Field_A_const_1 *lang.Keyword

var A_arbace_reflect_Field_A_const_2 *lang.Keyword

var A_arbace_reflect_Field_A_const_3 *lang.Keyword

var A_arbace_reflect_Field_A_const_4 *lang.Var

var A_arbace_reflect_Field_A_const_5 *lang.Var

var A_arbace_reflect_Field_A_const_6 *lang.Var

var A_arbace_reflect_Field_A_const_7 *lang.Var

var A_arbace_reflect_Field_A_const_8 *lang.Var

var A_arbace_reflect_Field_A_const_9 any

var A_arbace_reflect_Field_A_const_10 *lang.Var

var A_arbace_reflect_Field_A_const_11 *lang.Var

var A_arbace_reflect_Field_A_const_12 *lang.Var

var A_arbace_reflect_Field_A_const_13 any

var A_arbace_reflect_Field_A_const_14 *lang.Var

var A_arbace_reflect_Field_A_const_15 *lang.Var

var A_arbace_reflect_Field_A_const_16 *lang.Var

var A_arbace_reflect_Field_A_const_17 *lang.Var

var A_arbace_reflect_Field_A_const_18 *lang.Var

var A_arbace_reflect_Field_A_const_19 *lang.Var

var A_arbace_reflect_Field_A_const_20 *lang.Var

var A_arbace_reflect_Field_A_const_21 *lang.Var

var A_arbace_reflect_Field_A_init jrt.ClassInit

func A_arbace_reflect_Field_A_Init() { if !A_arbace_reflect_Field_A_init.Done() { A_arbace_reflect_Field_A_init.Run(A_arbace_reflect_Field_A_clinit) } }

func A_arbace_reflect_Field_A_clinit() { jrt.StartCheck(); A_arbace_reflect_Field_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_34, 26); A_arbace_reflect_Field_A_const_0 = lang.Keyword_Cast(A_arbace_reflect_Field_A_const_pool.A[4]); A_arbace_reflect_Field_A_const_1 = lang.Keyword_Cast(A_arbace_reflect_Field_A_const_pool.A[5]); A_arbace_reflect_Field_A_const_2 = lang.Keyword_Cast(A_arbace_reflect_Field_A_const_pool.A[6]); A_arbace_reflect_Field_A_const_3 = lang.Keyword_Cast(A_arbace_reflect_Field_A_const_pool.A[7]); A_arbace_reflect_Field_A_const_4 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[8]); A_arbace_reflect_Field_A_const_5 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[9]); A_arbace_reflect_Field_A_const_6 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[10]); A_arbace_reflect_Field_A_const_7 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[11]); A_arbace_reflect_Field_A_const_8 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[12]); A_arbace_reflect_Field_A_const_9 = A_arbace_reflect_Field_A_const_pool.A[13]; A_arbace_reflect_Field_A_const_10 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[14]); A_arbace_reflect_Field_A_const_11 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[15]); A_arbace_reflect_Field_A_const_12 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[16]); A_arbace_reflect_Field_A_const_13 = A_arbace_reflect_Field_A_const_pool.A[17]; A_arbace_reflect_Field_A_const_14 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[18]); A_arbace_reflect_Field_A_const_15 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[19]); A_arbace_reflect_Field_A_const_16 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[20]); A_arbace_reflect_Field_A_const_17 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[21]); A_arbace_reflect_Field_A_const_18 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[22]); A_arbace_reflect_Field_A_const_19 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[23]); A_arbace_reflect_Field_A_const_20 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[24]); A_arbace_reflect_Field_A_const_21 = lang.Var_Cast(A_arbace_reflect_Field_A_const_pool.A[25]) }

func (t *A_arbace_reflect_Field_A) Assoc_O_O__Associative(p0, p1 any) lang.Associative { return t.Assoc_O_O__IPersistentMap(p0, p1) }

func (t *A_arbace_reflect_Field_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_reflect_Field_A) Replace_O_O__O(p0, p1 any) any { return jrt.Map_Replace_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Field_A) AssocEx_O_O__IPersistentMap(p0, p1 any) lang.IPersistentMap { panic(jrt.AbstractMethodError_New_String(jrt.Str("Receiver class arbace.reflect.Field does not define or inherit an implementation of the resolved method 'abstract arbace.lang.IPersistentMap assocEx(java.lang.Object, java.lang.Object)' of interface arbace.lang.IPersistentMap."))) }

func (t *A_arbace_reflect_Field_A) Compute_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_reflect_Field_A) Remove_O_O__Z(p0, p1 any) bool { return jrt.Map_Remove_O_O__Z(t, p0, p1) }

func (t *A_arbace_reflect_Field_A) GetOrDefault_O_O__O(p0, p1 any) any { return jrt.Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Field_A) Merge_O_O_BiFunction__O(p0, p1 any, p2 jrt.BiFunction) any { return jrt.Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *A_arbace_reflect_Field_A) ComputeIfPresent_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_reflect_Field_A) ReplaceAll_BiFunction__V(p0 jrt.BiFunction) { jrt.Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *A_arbace_reflect_Field_A) PutIfAbsent_O_O__O(p0, p1 any) any { return jrt.Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Field_A) ForEach_BiConsumer__V(p0 jrt.BiConsumer) { jrt.Map_ForEach_BiConsumer__V(t, p0) }

func (t *A_arbace_reflect_Field_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_reflect_Field_A) Replace_O_O_O__Z(p0, p1, p2 any) bool { return jrt.Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *A_arbace_reflect_Field_A) ComputeIfAbsent_O_Function__O(p0 any, p1 jrt.Function) any { return jrt.Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *A_arbace_reflect_Field_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Field_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Field_A_class }

func (t *A_arbace_reflect_Field_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Field_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Field_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Field_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Field_A); return ok }

func A_arbace_reflect_Field_A_Cast(x any) *A_arbace_reflect_Field_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Field_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Field_A_class)) }; return v }



type A_arbace_reflect_Field_reify__1939000090_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Field_reify__1939000090_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Field_reify__1939000090_A) Is_IObj() {}

func (t *A_arbace_reflect_Field_reify__1939000090_A) Is_IMeta() {}

func (t *A_arbace_reflect_Field_reify__1939000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Field_reify__1939000090_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Field_reify__1939000090_A_class }

func (t *A_arbace_reflect_Field_reify__1939000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Field_reify__1939000090_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Field_reify__1939000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Field_reify__1939000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Field_reify__1939000090_A); return ok }

func A_arbace_reflect_Field_reify__1939000090_A_Cast(x any) *A_arbace_reflect_Field_reify__1939000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Field_reify__1939000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Field_reify__1939000090_A_class)) }; return v }



type A_arbace_reflect_Field_reify__1939000092_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Field_reify__1939000092_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Field_reify__1939000092_A) Is_IObj() {}

func (t *A_arbace_reflect_Field_reify__1939000092_A) Is_IMeta() {}

func (t *A_arbace_reflect_Field_reify__1939000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Field_reify__1939000092_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Field_reify__1939000092_A_class }

func (t *A_arbace_reflect_Field_reify__1939000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Field_reify__1939000092_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Field_reify__1939000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Field_reify__1939000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Field_reify__1939000092_A); return ok }

func A_arbace_reflect_Field_reify__1939000092_A_Cast(x any) *A_arbace_reflect_Field_reify__1939000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Field_reify__1939000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Field_reify__1939000092_A_class)) }; return v }



type A_arbace_reflect_Field_reify__1939000094_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Field_reify__1939000094_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Field_reify__1939000094_A) Is_IObj() {}

func (t *A_arbace_reflect_Field_reify__1939000094_A) Is_IMeta() {}

func (t *A_arbace_reflect_Field_reify__1939000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Field_reify__1939000094_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Field_reify__1939000094_A_class }

func (t *A_arbace_reflect_Field_reify__1939000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Field_reify__1939000094_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Field_reify__1939000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Field_reify__1939000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Field_reify__1939000094_A); return ok }

func A_arbace_reflect_Field_reify__1939000094_A_Cast(x any) *A_arbace_reflect_Field_reify__1939000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Field_reify__1939000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Field_reify__1939000094_A_class)) }; return v }



type A_arbace_reflect_Field_reify__1939000096_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Field_reify__1939000096_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Field_reify__1939000096_A) Is_IObj() {}

func (t *A_arbace_reflect_Field_reify__1939000096_A) Is_IMeta() {}

func (t *A_arbace_reflect_Field_reify__1939000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Field_reify__1939000096_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Field_reify__1939000096_A_class }

func (t *A_arbace_reflect_Field_reify__1939000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Field_reify__1939000096_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Field_reify__1939000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Field_reify__1939000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Field_reify__1939000096_A); return ok }

func A_arbace_reflect_Field_reify__1939000096_A_Cast(x any) *A_arbace_reflect_Field_reify__1939000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Field_reify__1939000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Field_reify__1939000096_A_class)) }; return v }
