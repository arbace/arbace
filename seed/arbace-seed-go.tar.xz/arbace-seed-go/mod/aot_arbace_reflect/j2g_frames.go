//line j2g_frames.ae:1
package aot_arbace_reflect

import "arbace/jrt"


func init() { jrt.RegisterFrames([]jrt.FrameInfo{{"arbace/aot_arbace_reflect.(*A_arbace_reflect_AsmReflector_A).Do_reflect_O__O", "arbace.reflect.AsmReflector", "do_reflect", 0}, {"arbace/aot_arbace_reflect.A_arbace_reflect_ClassResolver_A_Resolve_class_O__O", "arbace.reflect.ClassResolver", "resolve_class", 0}, {"arbace/aot_arbace_reflect.(*A_arbace_reflect_JavaReflector_A).Do_reflect_O__O", "arbace.reflect.JavaReflector", "do_reflect", 0}, {"arbace/aot_arbace_reflect.A_arbace_reflect_Reflector_A_Do_reflect_O__O", "arbace.reflect.Reflector", "do_reflect", 0}}) }
