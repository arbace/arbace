//line a2g_strings.ae:1
package aot_arbace_reflect

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.set")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("set")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.reflect")

var Lit_10 *jrt.String = jrt.Intern("author")

var Lit_11 *jrt.String = jrt.Intern("Stuart Halloway")

var Lit_12 *jrt.String = jrt.Intern("added")

var Lit_13 *jrt.String = jrt.Intern("1.3")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("Reflection on Host Types\nAlpha - subject to change.\n\nTwo main entry points:\n\n* type-reflect reflects on something that implements TypeReference.\n* reflect (for REPL use) reflects on the class of an instance, or\n  on a class if passed a class\n\nKey features:\n\n* Exposes the read side of reflection as pure data. Reflecting\n  on a type returns a map with keys :bases, :flags, and :members.\n\n* Canonicalizes class names as Clojure symbols. Types can extend\n  to the TypeReference protocol to indicate that they can be\n  unambiguously resolved as a type name. The canonical format\n  requires one non-Java-ish convention: array brackets are <>\n  instead of [] so they can be part of a Clojure symbol.\n\n* Pluggable Reflectors for different implementations. The default\n  JavaReflector is good when you have a class in hand. (Clojure's\n  AsmReflector reads class files with ASM, which Arbace has not: its\n  reflection throws.)\n\nPlatform implementers must:\n\n* Create an implementation of Reflector.\n* Create one or more implementations of TypeReference.\n* def default-reflector to be an instance that satisfies Reflector.")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("-cache-protocol-fn")

var Lit_18 *jrt.String = jrt.Intern("arbace.reflect.Reflector")

var Lit_19 *jrt.String = jrt.Intern("arbace.reflect.TypeReference")

var Lit_20 *jrt.String = jrt.Intern("merge")

var Lit_21 *jrt.String = jrt.Intern("next")

var Lit_22 *jrt.String = jrt.Intern("to-array")

var Lit_23 *jrt.String = jrt.Intern("seq")

var Lit_24 *jrt.String = jrt.Intern("first")

var Lit_25 *jrt.String = jrt.Intern("ancestors")

var Lit_26 *jrt.String = jrt.Intern("reflector")

var Lit_27 *jrt.String = jrt.Intern("partial")

var Lit_28 *jrt.String = jrt.Intern("zipmap")

var Lit_29 *jrt.String = jrt.Intern("map")

var Lit_30 *jrt.String = jrt.Intern("difference")

var Lit_31 *jrt.String = jrt.Intern("apply")

var Lit_32 *jrt.String = jrt.Intern("default-reflector")

var Lit_33 *jrt.String = jrt.Intern("hash-map")

var Lit_34 *jrt.String = jrt.Intern("do-reflect")

var Lit_35 *jrt.String = jrt.Intern("bases")

var Lit_36 *jrt.String = jrt.Intern("keys")

var Lit_37 *jrt.String = jrt.Intern("mapcat")

var Lit_38 *jrt.String = jrt.Intern("vals")

var Lit_39 *jrt.String = jrt.Intern("merge-with")

var Lit_40 *jrt.String = jrt.Intern("into")

var Lit_41 *jrt.String = jrt.Intern("select-keys")

var Lit_42 *jrt.String = jrt.Intern("members")

var Lit_43 *jrt.String = jrt.Intern("type-reflect")

var Lit_44 *jrt.String = jrt.Intern("class?")

var Lit_45 *jrt.String = jrt.Intern("class")

var Lit_46 *jrt.String = jrt.Intern("arbace.string")

var Lit_47 *jrt.String = jrt.Intern("replace")

var Lit_48 *jrt.String = jrt.Intern("str")

var Lit_49 *jrt.String = jrt.Intern("typename")

var Lit_50 *jrt.String = jrt.Intern("symbol")

var Lit_51 *jrt.String = jrt.Intern("with-meta")

var Lit_52 *jrt.String = jrt.Intern("arbace.core.protocols")

var Lit_53 *jrt.String = jrt.Intern("datafy")

var Lit_54 *jrt.String = jrt.Intern("arbace.datafy")

var Lit_55 *jrt.String = jrt.Intern("name")

var Lit_56 *jrt.String = jrt.Intern("flag")

var Lit_57 *jrt.String = jrt.Intern("contexts")

var Lit_58 *jrt.String = jrt.Intern("keyword")

var Lit_59 *jrt.String = jrt.Intern("descriptor-class-name")

var Lit_60 *jrt.String = jrt.Intern("subs")

var Lit_61 *jrt.String = jrt.Intern("string?")

var Lit_62 *jrt.String = jrt.Intern("pr-str")

var Lit_63 *jrt.String = jrt.Intern("d")

var Lit_64 *jrt.String = jrt.Intern("line")

var Lit_65 *jrt.String = jrt.Intern("column")

var Lit_66 *jrt.String = jrt.Intern("reduce")

var Lit_67 *jrt.String = jrt.Intern("not")

var Lit_68 *jrt.String = jrt.Intern("flag-descriptors")

var Lit_69 *jrt.String = jrt.Intern("typesym")

var Lit_70 *jrt.String = jrt.Intern("vec")

var Lit_71 *jrt.String = jrt.Intern("parse-flags")

var Lit_72 *jrt.String = jrt.Intern("method")

var Lit_73 *jrt.String = jrt.Intern("constructor->map")

var Lit_74 *jrt.String = jrt.Intern("method->map")

var Lit_75 *jrt.String = jrt.Intern("field")

var Lit_76 *jrt.String = jrt.Intern("field->map")

var Lit_77 *jrt.String = jrt.Intern("arbace.reflect.ClassResolver")

var Lit_78 *jrt.String = jrt.Intern("java.lang.ClassLoader")

var Lit_79 *jrt.String = jrt.Intern("resource-name")

var Lit_80 *jrt.String = jrt.Intern("arbace.reflect$access_flag")

var Lit_81 *jrt.String = jrt.Intern("arbace.reflect$constructor__GT_map")

var Lit_82 *jrt.String = jrt.Intern("arbace.reflect$declared_constructors")

var Lit_83 *jrt.String = jrt.Intern("arbace.reflect$declared_fields")

var Lit_84 *jrt.String = jrt.Intern("arbace.reflect$declared_methods")

var Lit_85 *jrt.String = jrt.Intern("arbace.reflect$descriptor_class_name")

var Lit_86 *jrt.String = jrt.Intern("/")

var Lit_87 *jrt.String = jrt.Intern(".")

var Lit_88 *jrt.String = jrt.Intern("[]")

var Lit_89 *jrt.String = jrt.Intern("arbace.reflect$eval1938000010$fn__1938000011")

var Lit_90 *jrt.String = jrt.Intern("<>")

var Lit_91 *jrt.String = jrt.Intern("arbace.reflect$eval1938000014$fn__1938000015")

var Lit_92 *jrt.String = jrt.Intern("arbace.reflect$eval1938000036$__GT_Constructor__1938000052")

var Lit_93 *jrt.String = jrt.Intern("arbace.reflect$eval1938000036$map__GT_Constructor__1938000054")

var Lit_94 *jrt.String = jrt.Intern("arbace.reflect$eval1938000060$__GT_Method__1938000078")

var Lit_95 *jrt.String = jrt.Intern("arbace.reflect$eval1938000060$map__GT_Method__1938000080")

var Lit_96 *jrt.String = jrt.Intern("arbace.reflect$eval1938000086$__GT_Field__1938000100")

var Lit_97 *jrt.String = jrt.Intern("arbace.reflect$eval1938000086$map__GT_Field__1938000102")

var Lit_98 *jrt.String = jrt.Intern("arbace.reflect$eval1938000108$__GT_JavaReflector__1938000110")

var Lit_99 *jrt.String = jrt.Intern("arbace.reflect$eval1938000121$fn__1938000122")

var Lit_100 *jrt.String = jrt.Intern("arbace.reflect$eval1938000121$fn__1938000122$G__1938000113__1938000129")

var Lit_101 *jrt.String = jrt.Intern("arbace.reflect$eval1938000121$fn__1938000122$G__1938000114__1938000125")

var Lit_102 *jrt.String = jrt.Intern("resolve_class")

var Lit_103 *jrt.String = jrt.Intern("arbace.reflect$eval1938000137$fn__1938000138")

var Lit_104 *jrt.String = jrt.Intern("arbace.reflect$eval1938000141$fn__1938000142")

var Lit_105 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_106 *jrt.String = jrt.Intern("arbace.reflect$eval1938000145$__GT_AsmReflector__1938000147")

var Lit_107 *jrt.String = jrt.Intern("arbace.reflect$eval659000004$loading__1927001464__auto____659000005")

var Lit_108 *jrt.String = jrt.Intern("arbace.reflect$eval659000008$fn__659000009")

var Lit_109 *jrt.String = jrt.Intern("arbace.reflect$eval659000020$fn__659000021")

var Lit_110 *jrt.String = jrt.Intern("arbace.reflect$eval659000020$fn__659000021$G__659000012__659000028")

var Lit_111 *jrt.String = jrt.Intern("arbace.reflect$eval659000020$fn__659000021$G__659000013__659000024")

var Lit_112 *jrt.String = jrt.Intern("do_reflect")

var Lit_113 *jrt.String = jrt.Intern("arbace.reflect$eval659000044$fn__659000045")

var Lit_114 *jrt.String = jrt.Intern("arbace.reflect$eval659000044$fn__659000045$G__659000036__659000050")

var Lit_115 *jrt.String = jrt.Intern("arbace.reflect$eval659000044$fn__659000045$G__659000037__659000047")

var Lit_116 *jrt.String = jrt.Intern("arbace.reflect$field__GT_map")

var Lit_117 *jrt.String = jrt.Intern("arbace.reflect$field_descriptor__GT_class_symbol")

var Lit_118 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_119 *jrt.String = jrt.Intern("arbace.reflect$internal_name__GT_class_symbol")

var Lit_120 *jrt.String = jrt.Intern("[")

var Lit_121 *jrt.String = jrt.Intern("arbace.reflect$method__GT_map")

var Lit_122 *jrt.String = jrt.Intern("arbace.reflect$parse_flags")

var Lit_123 *jrt.String = jrt.Intern("arbace.reflect$parse_flags$fn__1938000032")

var Lit_124 *jrt.String = jrt.Intern("arbace.reflect$reflect")

var Lit_125 *jrt.String = jrt.Intern("arbace.reflect$resource_name")

var Lit_126 *jrt.String = jrt.Intern(".class")

var Lit_127 *jrt.String = jrt.Intern("arbace.reflect$type_reflect")

var Lit_128 *jrt.String = jrt.Intern("arbace.reflect$type_reflect$fn__659000063")

var Lit_129 *jrt.String = jrt.Intern("arbace.reflect$type_reflect$make_ancestor_map__659000061")

var Lit_130 *jrt.String = jrt.Intern("arbace.reflect$typeref__GT_class")

var Lit_131 *jrt.String = jrt.Intern("arbace.reflect$typesym")

var Lit_132 *jrt.String = jrt.Intern("arbace.reflect$typesym$fn__1938000019")

var Lit_133 *jrt.String = jrt.Intern("class-resolver")

var Lit_134 *jrt.String = jrt.Intern("AsmReflector: no class file reader in Arbace (reflecting ")

var Lit_135 *jrt.String = jrt.Intern(")")

var Lit_136 *jrt.String = jrt.Intern("declaring-class")

var Lit_137 *jrt.String = jrt.Intern("parameter-types")

var Lit_138 *jrt.String = jrt.Intern("exception-types")

var Lit_139 *jrt.String = jrt.Intern("flags")

var Lit_140 *jrt.String = jrt.Intern("imap-cons")

var Lit_141 *jrt.String = jrt.Intern("concat")

var Lit_142 *jrt.String = jrt.Intern("identical?")

var Lit_143 *jrt.String = jrt.Intern("assoc")

var Lit_144 *jrt.String = jrt.Intern("contains?")

var Lit_145 *jrt.String = jrt.Intern("dissoc")

var Lit_146 *jrt.String = jrt.Intern("not-empty")

var Lit_147 *jrt.String = jrt.Intern("some")

var Lit_148 *jrt.String = jrt.Intern("Can't create empty: ")

var Lit_149 *jrt.String = jrt.Intern("arbace.reflect.Constructor")

var Lit_150 *jrt.String = jrt.Intern("type")

var Lit_151 *jrt.String = jrt.Intern("arbace.reflect.Field")

var Lit_152 *jrt.String = jrt.Intern("typeref->class")

var Lit_153 *jrt.String = jrt.Intern("union")

var Lit_154 *jrt.String = jrt.Intern("declared-fields")

var Lit_155 *jrt.String = jrt.Intern("declared-methods")

var Lit_156 *jrt.String = jrt.Intern("declared-constructors")

var Lit_157 *jrt.String = jrt.Intern("classloader")

var Lit_158 *jrt.String = jrt.Intern("return-type")

var Lit_159 *jrt.String = jrt.Intern("arbace.reflect.Method")

var Lit_160 *jrt.String = jrt.Intern("in-ns")

var Lit_161 *jrt.String = jrt.Intern("Reflector")

var Lit_162 *jrt.String = jrt.Intern("file")

var Lit_163 *jrt.String = jrt.Intern("arbace/reflect.ae")

var Lit_164 *jrt.String = jrt.Intern("alter-meta!")

var Lit_165 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_166 *jrt.String = jrt.Intern("arglists")

var Lit_167 *jrt.String = jrt.Intern("typeref")

var Lit_168 *jrt.String = jrt.Intern("alter-var-root")

var Lit_169 *jrt.String = jrt.Intern("on")

var Lit_170 *jrt.String = jrt.Intern("on-interface")

var Lit_171 *jrt.String = jrt.Intern("Protocol for reflection implementers.")

var Lit_172 *jrt.String = jrt.Intern("sigs")

var Lit_173 *jrt.String = jrt.Intern("tag")

var Lit_174 *jrt.String = jrt.Intern("var")

var Lit_175 *jrt.String = jrt.Intern("method-map")

var Lit_176 *jrt.String = jrt.Intern("method-builders")

var Lit_177 *jrt.String = jrt.Intern("intern")

var Lit_178 *jrt.String = jrt.Intern("*ns*")

var Lit_179 *jrt.String = jrt.Intern("protocol")

var Lit_180 *jrt.String = jrt.Intern("-reset-methods")

var Lit_181 *jrt.String = jrt.Intern("TypeReference")

var Lit_182 *jrt.String = jrt.Intern("Returns Java name as returned by ASM getClassName, e.g. byte[], java.lang.String[]")

var Lit_183 *jrt.String = jrt.Intern("o")

var Lit_184 *jrt.String = jrt.Intern("A TypeReference can be unambiguously converted to a type name on\n   the host platform.\n\n   All typerefs are normalized into symbols. If you need to\n   normalize a typeref yourself, call typesym.")

var Lit_185 *jrt.String = jrt.Intern("declared")

var Lit_186 *jrt.String = jrt.Intern("&")

var Lit_187 *jrt.String = jrt.Intern("options")

var Lit_188 *jrt.String = jrt.Intern("Alpha - subject to change.\n   Reflect on a typeref, returning a map with :bases, :flags, and\n  :members. In the discussion below, names are always Clojure symbols.\n\n   :bases            a set of names of the type's bases\n   :flags            a set of keywords naming the boolean attributes\n                     of the type.\n   :members          a set of the type's members. Each member is a map\n                     and can be a constructor, method, or field.\n\n   Keys common to all members:\n   :name             name of the type\n   :declaring-class  name of the declarer\n   :flags            keyword naming boolean attributes of the member\n\n   Keys specific to constructors:\n   :parameter-types  vector of parameter type names\n   :exception-types  vector of exception type names\n\n   Key specific to methods:\n   :parameter-types  vector of parameter type names\n   :exception-types  vector of exception type names\n   :return-type      return type name\n\n   Keys specific to fields:\n   :type             type name\n\n   Options:\n\n     :ancestors     in addition to the keys described above, also\n                    include an :ancestors key with the entire set of\n                    ancestors, and add all ancestor members to\n                    :members.\n     :reflector     implementation to use. Defaults to JavaReflector\n                    (AsmReflector throws in Arbace).")

var Lit_189 *jrt.String = jrt.Intern("reflect")

var Lit_190 *jrt.String = jrt.Intern("obj")

var Lit_191 *jrt.String = jrt.Intern("Alpha - subject to change.\n   Reflect on the type of obj (or obj itself if obj is a class).\n   Return value and options are the same as for type-reflect. ")

var Lit_192 *jrt.String = jrt.Intern("load")

var Lit_193 *jrt.String = jrt.Intern("reflect/java")
