//line aot_arbace_reflect_Constructor.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)



















































































































func A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5, p6 any, p7, p8 int32) *A_arbace_reflect_Constructor_A { A_arbace_reflect_Constructor_A_Init(); t := &A_arbace_reflect_Constructor_A{}; t.Ctor_O_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Ctor_O_O_O_O_O_O_O_I_I(name, declaring_class, parameter_types, exception_types, flags, __meta, __extmap any, __hash, __hasheq int32) { t.F_name = name; t.F_declaring_class = declaring_class; t.F_parameter_types = parameter_types; t.F_exception_types = exception_types; t.F_flags = flags; t.F___meta = __meta; t.F___extmap = __extmap; t.F___hash = __hash; t.F___hasheq = __hasheq }
//line :122:1
func A_arbace_reflect_Constructor_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_reflect_Constructor_A { A_arbace_reflect_Constructor_A_Init(); t := &A_arbace_reflect_Constructor_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Ctor_O_O_O_O_O(name, declaring_class, parameter_types, exception_types, flags any) { t.Ctor_O_O_O_O_O_O_O_I_I(name, declaring_class, parameter_types, exception_types, flags, nil, nil, 0, 0) }
//line :122:1
func A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_reflect_Constructor_A { A_arbace_reflect_Constructor_A_Init(); t := &A_arbace_reflect_Constructor_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Ctor_O_O_O_O_O_O_O(name, declaring_class, parameter_types, exception_types, flags, __meta, __extmap any) { t.Ctor_O_O_O_O_O_O_O_I_I(name, declaring_class, parameter_types, exception_types, flags, __meta, __extmap, 0, 0) }
//line :122:1
func A_arbace_reflect_Constructor_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_reflect_Constructor_A_Init(); return lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_136).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_137).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_138).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_139).Ref()) }
//line :122:1
func A_arbace_reflect_Constructor_A_Create_IPersistentMap__A_arbace_reflect_Constructor_A(m__ lang.IPersistentMap) *A_arbace_reflect_Constructor_A { A_arbace_reflect_Constructor_A_Init(); var m___2 lang.IPersistentMap = m__; var v__0 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_55).Ref(), nil); var v__1 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_136).Ref(), nil); var v__2 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_137).Ref(), nil); var v__3 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_138).Ref(), nil); var v__4 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_139).Ref(), nil); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_55).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_136).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_137).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_138).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_139).Ref()); return A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O_I_I(v__0, v__1, v__2, v__3, v__4, nil, lang.RT_SeqOrElse_O__O(m___2), 0, 0) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Hasheq__I() int32 { var hq__231000058__auto____1 int32 = t.F___hasheq; if lang.Numbers_IsZero_J__Z(int64(hq__231000058__auto____1)) { var h__231000059__auto____2 int32 = lang.RT_IntCast_J__I(lang.Numbers_Xor_J_J__J(-1750682835, int64(lang.APersistentMap_MapHasheq_IPersistentMap__I(t)))); t.F___hasheq = h__231000059__auto____2; return h__231000059__auto____2 } else { return hq__231000058__auto____1 } }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) HashCode__I() int32 { var hash__231000061__auto____1 int32 = t.F___hash; if lang.Numbers_IsZero_J__Z(int64(hash__231000061__auto____1)) { var h__231000062__auto____2 int32 = lang.APersistentMap_MapHash_IPersistentMap__I(t); t.F___hash = h__231000062__auto____2; return h__231000062__auto____2 } else { return hash__231000061__auto____1 } }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Equals_O__Z(G__1938000035__1_ any) bool { return lang.APersistentMap_MapEquals_IPersistentMap_O__Z(t, G__1938000035__1_) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F___meta) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) WithMeta_IPersistentMap__IObj(G__1938000035__1_ lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O_I_I(t.F_name, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, t.F_flags, G__1938000035__1_, t.F___extmap, t.F___hash, t.F___hasheq) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) ValAt_O__O(k__231000067__auto____1 any) any { return t.ValAt_O_O__O(k__231000067__auto____1, nil) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) ValAt_O_O__O(k__231000069__auto____1, else__231000070__auto____2 any) any { var G__1938000050__3_ any = k__231000069__auto____1; switch lang.Util_Hash_O__I(G__1938000050__3_) >> 0 & 7 { case 0: if any(G__1938000050__3_) == any(A_arbace_reflect_Constructor_A_const_0.Ref()) { return t.F_declaring_class }; case 1: if any(G__1938000050__3_) == any(A_arbace_reflect_Constructor_A_const_1.Ref()) { return t.F_name }; case 4: if any(G__1938000050__3_) == any(A_arbace_reflect_Constructor_A_const_2.Ref()) { return t.F_parameter_types }; case 5: if any(G__1938000050__3_) == any(A_arbace_reflect_Constructor_A_const_3.Ref()) { return t.F_exception_types }; case 6: if any(G__1938000050__3_) == any(A_arbace_reflect_Constructor_A_const_4.Ref()) { return t.F_flags }; default:}; return lang.RT_Get_O_O_O__O(t.F___extmap, k__231000069__auto____1, else__231000070__auto____2) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) GetLookupThunk_Keyword__ILookupThunk(k__231000072__auto____1 *lang.Keyword) lang.ILookupThunk { var tmp1 any; var gclass__2 any = lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_5).GetRawRoot__O()).Invoke_O__O(t); var G__1938000039__3_ any = k__231000072__auto____1.Ref(); L1: switch { default: switch lang.Util_Hash_O__I(G__1938000039__3_) >> 0 & 7 { case 0: if any(G__1938000039__3_) == any(A_arbace_reflect_Constructor_A_const_0.Ref()) { tmp1 = A_arbace_reflect_Constructor_reify__1938000040_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 1: if any(G__1938000039__3_) == any(A_arbace_reflect_Constructor_A_const_1.Ref()) { tmp1 = A_arbace_reflect_Constructor_reify__1938000042_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 4: if any(G__1938000039__3_) == any(A_arbace_reflect_Constructor_A_const_2.Ref()) { tmp1 = A_arbace_reflect_Constructor_reify__1938000044_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 5: if any(G__1938000039__3_) == any(A_arbace_reflect_Constructor_A_const_3.Ref()) { tmp1 = A_arbace_reflect_Constructor_reify__1938000046_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 6: if any(G__1938000039__3_) == any(A_arbace_reflect_Constructor_A_const_4.Ref()) { tmp1 = A_arbace_reflect_Constructor_reify__1938000048_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; default:}; tmp1 = nil}; return lang.ILookupThunk_Cast(tmp1) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Count__I() int32 { return lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(5, int64(lang.RT_Count_O__I(t.F___extmap)))) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Empty__IPersistentCollection() lang.IPersistentCollection { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_148, Lit_149), jrt.RefArrayOf(jrt.Object_class, nil, nil))))) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Cons_O__IPersistentCollection(e__231000076__auto____1 any) lang.IPersistentCollection { return lang.IPersistentCollection_Cast(Up_Var_IFn(A_arbace_reflect_Constructor_A_const_6).Invoke_O_O__O(t, e__231000076__auto____1)) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Equiv_O__Z(G__1938000035__1_ any) bool { var tmp1 *jrt.Boolean; var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z(t, G__1938000035__1_); if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2) } else { if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_5).GetRawRoot__O()).Invoke_O__O(t), lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_5).GetRawRoot__O()).Invoke_O__O(G__1938000035__1_)) { var G__1938000035__3_ any = G__1938000035__1_; var tmp2 any = t.F_name; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_reflect_Constructor_A_Cast(G__1938000035__3_).F_name); if and__1927000168__auto____4 { var tmp3 any = t.F_declaring_class; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp3, A_arbace_reflect_Constructor_A_Cast(G__1938000035__3_).F_declaring_class); if and__1927000168__auto____5 { var tmp4 any = t.F_parameter_types; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(tmp4, A_arbace_reflect_Constructor_A_Cast(G__1938000035__3_).F_parameter_types); if and__1927000168__auto____6 { var tmp5 any = t.F_exception_types; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp5, A_arbace_reflect_Constructor_A_Cast(G__1938000035__3_).F_exception_types); if and__1927000168__auto____7 { var tmp6 any = t.F_flags; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(tmp6, A_arbace_reflect_Constructor_A_Cast(G__1938000035__3_).F_flags); if and__1927000168__auto____8 { var tmp7 any = t.F___extmap; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp7, A_arbace_reflect_Constructor_A_Cast(G__1938000035__3_).F___extmap)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4) } } else { tmp1 = nil } }; return lang.RT_BooleanCast_O__Z(tmp1.Ref()) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) ContainsKey_O__Z(k__231000079__auto____1 any) bool { return jrt.NN(jrt.Boolean_Cast(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_7).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(t, t.ValAt_O_O__O(k__231000079__auto____1, t))).Ref()))).BooleanValue__Z() }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) EntryAt_O__IMapEntry(k__231000081__auto____1 any) lang.IMapEntry { var tmp1 *lang.MapEntry; var v__231000082__auto____2 any = t.ValAt_O_O__O(k__231000081__auto____1, t); if lang.Util_Identical_O_O__Z(t, v__231000082__auto____2) { tmp1 = nil } else { tmp1 = lang.MapEntry_Create_O_O__MapEntry(k__231000081__auto____1, v__231000082__auto____2) }; return Up_MapEntry_IMapEntry(tmp1) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Seq__ISeq() lang.ISeq { return lang.ISeq_Cast(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_8).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_9).GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Constructor_A_const_1.Ref(), t.F_name).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Constructor_A_const_0.Ref(), t.F_declaring_class).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Constructor_A_const_2.Ref(), t.F_parameter_types).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Constructor_A_const_3.Ref(), t.F_exception_types).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Constructor_A_const_4.Ref(), t.F_flags).Ref()), t.F___extmap))) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Iterator__Iterator() jrt.Iterator { var tmp1 lang.ILookup = t; var tmp2 lang.IPersistentVector = lang.IPersistentVector_Cast(A_arbace_reflect_Constructor_A_const_10); return lang.RecordIterator_New_ILookup_IPersistentVector_Iterator(tmp1, tmp2, lang.RT_Iter_O__Iterator(t.F___extmap)) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Assoc_O_O__IPersistentMap(k__231000086__auto____1, G__1938000035__2_ any) lang.IPersistentMap { var tmp1 *A_arbace_reflect_Constructor_A; var pred__1938000037__3 any = jrt.NN(A_arbace_reflect_Constructor_A_const_11).GetRawRoot__O(); var expr__1938000038__4 any = k__231000086__auto____1; if jrt.A2g_Truth(lang.IFn_Cast(pred__1938000037__3).Invoke_O_O__O(A_arbace_reflect_Constructor_A_const_1.Ref(), expr__1938000038__4)) { tmp1 = A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(G__1938000035__2_, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.A2g_Truth(lang.IFn_Cast(pred__1938000037__3).Invoke_O_O__O(A_arbace_reflect_Constructor_A_const_0.Ref(), expr__1938000038__4)) { tmp1 = A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(t.F_name, G__1938000035__2_, t.F_parameter_types, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.A2g_Truth(lang.IFn_Cast(pred__1938000037__3).Invoke_O_O__O(A_arbace_reflect_Constructor_A_const_2.Ref(), expr__1938000038__4)) { tmp1 = A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(t.F_name, t.F_declaring_class, G__1938000035__2_, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.A2g_Truth(lang.IFn_Cast(pred__1938000037__3).Invoke_O_O__O(A_arbace_reflect_Constructor_A_const_3.Ref(), expr__1938000038__4)) { tmp1 = A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(t.F_name, t.F_declaring_class, t.F_parameter_types, G__1938000035__2_, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.A2g_Truth(lang.IFn_Cast(pred__1938000037__3).Invoke_O_O__O(A_arbace_reflect_Constructor_A_const_4.Ref(), expr__1938000038__4)) { tmp1 = A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(t.F_name, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, G__1938000035__2_, t.F___meta, t.F___extmap) } else { var tmp2 any = t.F_name; var tmp3 any = t.F_declaring_class; var tmp4 any = t.F_parameter_types; var tmp5 any = t.F_exception_types; var tmp6 any = t.F_flags; var tmp7 any = t.F___meta; tmp1 = A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_12).GetRawRoot__O()).Invoke_O_O_O__O(t.F___extmap, k__231000086__auto____1, G__1938000035__2_)) } } } } }; return Up_A_arbace_reflect_Constructor_A_IPersistentMap(tmp1) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Without_O__IPersistentMap(k__231000088__auto____1 any) lang.IPersistentMap { var tmp1 any; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_13).GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_Constructor_A_const_16, k__231000088__auto____1)) { var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_14).GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_17).GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_18).GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp2.Invoke_O_O__O(tmp3.Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5.Ref(), t), t.F___meta), k__231000088__auto____1) } else { var tmp6 any = t.F_name; var tmp7 any = t.F_declaring_class; var tmp8 any = t.F_parameter_types; var tmp9 any = t.F_exception_types; var tmp10 any = t.F_flags; var tmp11 any = t.F___meta; tmp1 = A_arbace_reflect_Constructor_A_New_O_O_O_O_O_O_O(tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_15).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_14).GetRawRoot__O()).Invoke_O_O__O(t.F___extmap, k__231000088__auto____1))) }; return lang.IPersistentMap_Cast(tmp1) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Size__I() int32 { return t.Count__I() }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) IsEmpty__Z() bool { return lang.Util_Equiv_J_J__Z(0, int64(t.Count__I())) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) ContainsValue_O__Z(v__231000092__auto____1 any) bool { return lang.RT_BooleanCast_O__Z(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_19).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, v__231000092__auto____1)), lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_20).GetRawRoot__O()).Invoke_O__O(t))) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Get_O__O(k__231000094__auto____1 any) any { return t.ValAt_O__O(k__231000094__auto____1) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Put_O_O__O(k__231000096__auto____1, v__231000097__auto____2 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Remove_O__O(k__231000099__auto____1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) PutAll_Map__V(m__231000101__auto____1 jrt.Map) { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Clear__V() { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) KeySet__Set() jrt.Set { return jrt.Set_Cast(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_21).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_22).GetRawRoot__O()).Invoke_O__O(t))) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) Values__Collection() jrt.Collection { return jrt.Collection_Cast(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_20).GetRawRoot__O()).Invoke_O__O(t)) }
//line :122:1
func (t *A_arbace_reflect_Constructor_A) EntrySet__Set() jrt.Set { return jrt.Set_Cast(lang.IFn_Cast(jrt.NN(A_arbace_reflect_Constructor_A_const_21).GetRawRoot__O()).Invoke_O__O(t)) }
//line :122:1
func A_arbace_reflect_Constructor_reify__1938000040_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Constructor_reify__1938000040_A { t := &A_arbace_reflect_Constructor_reify__1938000040_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000040_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000040_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Constructor_A_Init(); tmp1 = A_arbace_reflect_Constructor_A_const_5; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Constructor_A_Cast(gtarget__1).F_declaring_class } else { return t } }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000040_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000040_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Constructor_reify__1938000040_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :122:1
func A_arbace_reflect_Constructor_reify__1938000042_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Constructor_reify__1938000042_A { t := &A_arbace_reflect_Constructor_reify__1938000042_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000042_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000042_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Constructor_A_Init(); tmp1 = A_arbace_reflect_Constructor_A_const_5; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Constructor_A_Cast(gtarget__1).F_name } else { return t } }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000042_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000042_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Constructor_reify__1938000042_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :122:1
func A_arbace_reflect_Constructor_reify__1938000044_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Constructor_reify__1938000044_A { t := &A_arbace_reflect_Constructor_reify__1938000044_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000044_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000044_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Constructor_A_Init(); tmp1 = A_arbace_reflect_Constructor_A_const_5; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Constructor_A_Cast(gtarget__1).F_parameter_types } else { return t } }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000044_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000044_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Constructor_reify__1938000044_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :122:1
func A_arbace_reflect_Constructor_reify__1938000046_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Constructor_reify__1938000046_A { t := &A_arbace_reflect_Constructor_reify__1938000046_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000046_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000046_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Constructor_A_Init(); tmp1 = A_arbace_reflect_Constructor_A_const_5; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Constructor_A_Cast(gtarget__1).F_exception_types } else { return t } }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000046_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000046_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Constructor_reify__1938000046_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :122:1
func A_arbace_reflect_Constructor_reify__1938000048_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Constructor_reify__1938000048_A { t := &A_arbace_reflect_Constructor_reify__1938000048_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000048_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000048_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Constructor_A_Init(); tmp1 = A_arbace_reflect_Constructor_A_const_5; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Constructor_A_Cast(gtarget__1).F_flags } else { return t } }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000048_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :122:1
func (t *A_arbace_reflect_Constructor_reify__1938000048_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Constructor_reify__1938000048_A_New_IPersistentMap_O(m, t.F_gclass) }





























































































































type A_arbace_reflect_Constructor_A struct{ jrt.Object; F_name, F_declaring_class, F_parameter_types, F_exception_types, F_flags, F___meta, F___extmap any; F___hash, F___hasheq int32 }

func (t *A_arbace_reflect_Constructor_A) Is_IRecord() {}

func (t *A_arbace_reflect_Constructor_A) Is_IHashEq() {}

func (t *A_arbace_reflect_Constructor_A) Is_IObj() {}

func (t *A_arbace_reflect_Constructor_A) Is_ILookup() {}

func (t *A_arbace_reflect_Constructor_A) Is_IKeywordLookup() {}

func (t *A_arbace_reflect_Constructor_A) Is_IPersistentMap() {}

func (t *A_arbace_reflect_Constructor_A) Is_Map() {}

func (t *A_arbace_reflect_Constructor_A) Is_Serializable() {}

func (t *A_arbace_reflect_Constructor_A) Is_IMeta() {}

func (t *A_arbace_reflect_Constructor_A) Is_Iterable() {}

func (t *A_arbace_reflect_Constructor_A) Is_Associative() {}

func (t *A_arbace_reflect_Constructor_A) Is_Counted() {}

func (t *A_arbace_reflect_Constructor_A) Is_IPersistentCollection() {}

func (t *A_arbace_reflect_Constructor_A) Is_Seqable() {}

var A_arbace_reflect_Constructor_A_const_0 *lang.Keyword

var A_arbace_reflect_Constructor_A_const_1 *lang.Keyword

var A_arbace_reflect_Constructor_A_const_2 *lang.Keyword

var A_arbace_reflect_Constructor_A_const_3 *lang.Keyword

var A_arbace_reflect_Constructor_A_const_4 *lang.Keyword

var A_arbace_reflect_Constructor_A_const_5 *lang.Var

var A_arbace_reflect_Constructor_A_const_6 *lang.Var

var A_arbace_reflect_Constructor_A_const_7 *lang.Var

var A_arbace_reflect_Constructor_A_const_8 *lang.Var

var A_arbace_reflect_Constructor_A_const_9 *lang.Var

var A_arbace_reflect_Constructor_A_const_10 any

var A_arbace_reflect_Constructor_A_const_11 *lang.Var

var A_arbace_reflect_Constructor_A_const_12 *lang.Var

var A_arbace_reflect_Constructor_A_const_13 *lang.Var

var A_arbace_reflect_Constructor_A_const_14 *lang.Var

var A_arbace_reflect_Constructor_A_const_15 *lang.Var

var A_arbace_reflect_Constructor_A_const_16 any

var A_arbace_reflect_Constructor_A_const_17 *lang.Var

var A_arbace_reflect_Constructor_A_const_18 *lang.Var

var A_arbace_reflect_Constructor_A_const_19 *lang.Var

var A_arbace_reflect_Constructor_A_const_20 *lang.Var

var A_arbace_reflect_Constructor_A_const_21 *lang.Var

var A_arbace_reflect_Constructor_A_const_22 *lang.Var

var A_arbace_reflect_Constructor_A_init jrt.ClassInit

func A_arbace_reflect_Constructor_A_Init() { if !A_arbace_reflect_Constructor_A_init.Done() { A_arbace_reflect_Constructor_A_init.Run(A_arbace_reflect_Constructor_A_clinit) } }

func A_arbace_reflect_Constructor_A_clinit() { A_arbace_reflect_Constructor_A_const_0 = lang.RT_Keyword_String_String__Keyword(nil, Lit_136); A_arbace_reflect_Constructor_A_const_1 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_reflect_Constructor_A_const_2 = lang.RT_Keyword_String_String__Keyword(nil, Lit_137); A_arbace_reflect_Constructor_A_const_3 = lang.RT_Keyword_String_String__Keyword(nil, Lit_138); A_arbace_reflect_Constructor_A_const_4 = lang.RT_Keyword_String_String__Keyword(nil, Lit_139); A_arbace_reflect_Constructor_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_reflect_Constructor_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_140); A_arbace_reflect_Constructor_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_reflect_Constructor_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_reflect_Constructor_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_141); A_arbace_reflect_Constructor_A_const_10 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref()); A_arbace_reflect_Constructor_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_142); A_arbace_reflect_Constructor_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_143); A_arbace_reflect_Constructor_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_144); A_arbace_reflect_Constructor_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_145); A_arbace_reflect_Constructor_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_146); A_arbace_reflect_Constructor_A_const_16 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref())).Ref(); A_arbace_reflect_Constructor_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_reflect_Constructor_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_reflect_Constructor_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_147); A_arbace_reflect_Constructor_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_reflect_Constructor_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_reflect_Constructor_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_36) }

func (t *A_arbace_reflect_Constructor_A) Assoc_O_O__Associative(p0, p1 any) lang.Associative { return t.Assoc_O_O__IPersistentMap(p0, p1) }

func (t *A_arbace_reflect_Constructor_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_reflect_Constructor_A) Replace_O_O__O(p0, p1 any) any { return jrt.Map_Replace_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Constructor_A) AssocEx_O_O__IPersistentMap(p0, p1 any) lang.IPersistentMap { panic(jrt.A2g_NotTranslated("abstract arbace.reflect.Constructor.assocEx(Ljava/lang/Object;Ljava/lang/Object;)Larbace/lang/IPersistentMap;")) }

func (t *A_arbace_reflect_Constructor_A) Compute_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_reflect_Constructor_A) Remove_O_O__Z(p0, p1 any) bool { return jrt.Map_Remove_O_O__Z(t, p0, p1) }

func (t *A_arbace_reflect_Constructor_A) GetOrDefault_O_O__O(p0, p1 any) any { return jrt.Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Constructor_A) Merge_O_O_BiFunction__O(p0, p1 any, p2 jrt.BiFunction) any { return jrt.Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *A_arbace_reflect_Constructor_A) ComputeIfPresent_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_reflect_Constructor_A) ReplaceAll_BiFunction__V(p0 jrt.BiFunction) { jrt.Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *A_arbace_reflect_Constructor_A) PutIfAbsent_O_O__O(p0, p1 any) any { return jrt.Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Constructor_A) ForEach_BiConsumer__V(p0 jrt.BiConsumer) { jrt.Map_ForEach_BiConsumer__V(t, p0) }

func (t *A_arbace_reflect_Constructor_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_reflect_Constructor_A) Replace_O_O_O__Z(p0, p1, p2 any) bool { return jrt.Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *A_arbace_reflect_Constructor_A) ComputeIfAbsent_O_Function__O(p0 any, p1 jrt.Function) any { return jrt.Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *A_arbace_reflect_Constructor_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Constructor_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Constructor_A_class }

func (t *A_arbace_reflect_Constructor_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Constructor_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_Constructor_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Constructor_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Constructor_A); return ok }

func A_arbace_reflect_Constructor_A_Cast(x any) *A_arbace_reflect_Constructor_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Constructor_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Constructor_A_class)) }; return v }



type A_arbace_reflect_Constructor_reify__1938000040_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Constructor_reify__1938000040_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Constructor_reify__1938000040_A) Is_IObj() {}

func (t *A_arbace_reflect_Constructor_reify__1938000040_A) Is_IMeta() {}

func (t *A_arbace_reflect_Constructor_reify__1938000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Constructor_reify__1938000040_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Constructor_reify__1938000040_A_class }

func (t *A_arbace_reflect_Constructor_reify__1938000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000040_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Constructor_reify__1938000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Constructor_reify__1938000040_A); return ok }

func A_arbace_reflect_Constructor_reify__1938000040_A_Cast(x any) *A_arbace_reflect_Constructor_reify__1938000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Constructor_reify__1938000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Constructor_reify__1938000040_A_class)) }; return v }



type A_arbace_reflect_Constructor_reify__1938000042_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Constructor_reify__1938000042_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Constructor_reify__1938000042_A) Is_IObj() {}

func (t *A_arbace_reflect_Constructor_reify__1938000042_A) Is_IMeta() {}

func (t *A_arbace_reflect_Constructor_reify__1938000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Constructor_reify__1938000042_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Constructor_reify__1938000042_A_class }

func (t *A_arbace_reflect_Constructor_reify__1938000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Constructor_reify__1938000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Constructor_reify__1938000042_A); return ok }

func A_arbace_reflect_Constructor_reify__1938000042_A_Cast(x any) *A_arbace_reflect_Constructor_reify__1938000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Constructor_reify__1938000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Constructor_reify__1938000042_A_class)) }; return v }



type A_arbace_reflect_Constructor_reify__1938000044_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Constructor_reify__1938000044_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Constructor_reify__1938000044_A) Is_IObj() {}

func (t *A_arbace_reflect_Constructor_reify__1938000044_A) Is_IMeta() {}

func (t *A_arbace_reflect_Constructor_reify__1938000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Constructor_reify__1938000044_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Constructor_reify__1938000044_A_class }

func (t *A_arbace_reflect_Constructor_reify__1938000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Constructor_reify__1938000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Constructor_reify__1938000044_A); return ok }

func A_arbace_reflect_Constructor_reify__1938000044_A_Cast(x any) *A_arbace_reflect_Constructor_reify__1938000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Constructor_reify__1938000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Constructor_reify__1938000044_A_class)) }; return v }



type A_arbace_reflect_Constructor_reify__1938000046_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Constructor_reify__1938000046_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Constructor_reify__1938000046_A) Is_IObj() {}

func (t *A_arbace_reflect_Constructor_reify__1938000046_A) Is_IMeta() {}

func (t *A_arbace_reflect_Constructor_reify__1938000046_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Constructor_reify__1938000046_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Constructor_reify__1938000046_A_class }

func (t *A_arbace_reflect_Constructor_reify__1938000046_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000046_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000046_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Constructor_reify__1938000046_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Constructor_reify__1938000046_A); return ok }

func A_arbace_reflect_Constructor_reify__1938000046_A_Cast(x any) *A_arbace_reflect_Constructor_reify__1938000046_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Constructor_reify__1938000046_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Constructor_reify__1938000046_A_class)) }; return v }



type A_arbace_reflect_Constructor_reify__1938000048_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Constructor_reify__1938000048_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Constructor_reify__1938000048_A) Is_IObj() {}

func (t *A_arbace_reflect_Constructor_reify__1938000048_A) Is_IMeta() {}

func (t *A_arbace_reflect_Constructor_reify__1938000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Constructor_reify__1938000048_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Constructor_reify__1938000048_A_class }

func (t *A_arbace_reflect_Constructor_reify__1938000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_Constructor_reify__1938000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Constructor_reify__1938000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Constructor_reify__1938000048_A); return ok }

func A_arbace_reflect_Constructor_reify__1938000048_A_Cast(x any) *A_arbace_reflect_Constructor_reify__1938000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Constructor_reify__1938000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Constructor_reify__1938000048_A_class)) }; return v }
