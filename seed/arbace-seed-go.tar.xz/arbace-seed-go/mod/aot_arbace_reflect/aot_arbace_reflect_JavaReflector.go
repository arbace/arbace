//line aot_arbace_reflect_JavaReflector.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)


















































































































































































func A_arbace_reflect_JavaReflector_A_New_O(p0 any) *A_arbace_reflect_JavaReflector_A { A_arbace_reflect_JavaReflector_A_Init(); t := &A_arbace_reflect_JavaReflector_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_reflect_JavaReflector_A) Ctor_O(classloader any) { t.F_classloader = classloader }
//line :185:1
func A_arbace_reflect_JavaReflector_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_reflect_JavaReflector_A_Init(); return lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()) }
//line :185:1
func (t *A_arbace_reflect_JavaReflector_A) Do_reflect_O__O(typeref__1 any) any { var cls__2 any = lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_0.GetRawRoot__O()).Invoke_O_O__O(typeref__1, t.F_classloader); var tmp1 any = A_arbace_reflect_JavaReflector_A_const_1; var tmp2 any = lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_2.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_8.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_JavaReflector_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_10.GetRawRoot__O()).Invoke_O__O(cls__2)))); var tmp3 any = A_arbace_reflect_JavaReflector_A_const_3; var tmp4 any = lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_4.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Class_Cast(cls__2)).GetModifiers__I()).Ref(), A_arbace_reflect_JavaReflector_A_const_11); var tmp5 any = A_arbace_reflect_JavaReflector_A_const_5; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_12.GetRawRoot__O()).Invoke_O__O(cls__2), lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_13.GetRawRoot__O()).Invoke_O__O(cls__2), lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_14.GetRawRoot__O()).Invoke_O__O(cls__2)))) }









type A_arbace_reflect_JavaReflector_A struct{ jrt.Object; F_classloader any }

func (t *A_arbace_reflect_JavaReflector_A) Is_A_arbace_reflect_Reflector_A() {}

func (t *A_arbace_reflect_JavaReflector_A) Is_IType() {}

var A_arbace_reflect_JavaReflector_A_const_pool *jrt.RefArray

var A_arbace_reflect_JavaReflector_A_const_0 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_1 *lang.Keyword

var A_arbace_reflect_JavaReflector_A_const_2 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_3 *lang.Keyword

var A_arbace_reflect_JavaReflector_A_const_4 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_5 *lang.Keyword

var A_arbace_reflect_JavaReflector_A_const_6 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_7 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_8 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_9 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_10 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_11 *lang.Keyword

var A_arbace_reflect_JavaReflector_A_const_12 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_13 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_14 *lang.Var

var A_arbace_reflect_JavaReflector_A_init jrt.ClassInit

func A_arbace_reflect_JavaReflector_A_Init() { if !A_arbace_reflect_JavaReflector_A_init.Done() { A_arbace_reflect_JavaReflector_A_init.Run(A_arbace_reflect_JavaReflector_A_clinit) } }

func A_arbace_reflect_JavaReflector_A_clinit() { A_arbace_reflect_JavaReflector_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_37, 19); A_arbace_reflect_JavaReflector_A_const_0 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[4]); A_arbace_reflect_JavaReflector_A_const_1 = lang.Keyword_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[5]); A_arbace_reflect_JavaReflector_A_const_2 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[6]); A_arbace_reflect_JavaReflector_A_const_3 = lang.Keyword_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[7]); A_arbace_reflect_JavaReflector_A_const_4 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[8]); A_arbace_reflect_JavaReflector_A_const_5 = lang.Keyword_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[9]); A_arbace_reflect_JavaReflector_A_const_6 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[10]); A_arbace_reflect_JavaReflector_A_const_7 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[11]); A_arbace_reflect_JavaReflector_A_const_8 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[12]); A_arbace_reflect_JavaReflector_A_const_9 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[13]); A_arbace_reflect_JavaReflector_A_const_10 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[14]); A_arbace_reflect_JavaReflector_A_const_11 = lang.Keyword_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[15]); A_arbace_reflect_JavaReflector_A_const_12 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[16]); A_arbace_reflect_JavaReflector_A_const_13 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[17]); A_arbace_reflect_JavaReflector_A_const_14 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[18]) }

func (t *A_arbace_reflect_JavaReflector_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_JavaReflector_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_JavaReflector_A_class }

func (t *A_arbace_reflect_JavaReflector_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_JavaReflector_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_JavaReflector_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_JavaReflector_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_JavaReflector_A); return ok }

func A_arbace_reflect_JavaReflector_A_Cast(x any) *A_arbace_reflect_JavaReflector_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_JavaReflector_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_JavaReflector_A_class)) }; return v }
