//line aot_arbace_reflect_JavaReflector.ae:1
package aot_arbace_reflect

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)

















































































































































































func A_arbace_reflect_JavaReflector_A_New_O(p0 any) *A_arbace_reflect_JavaReflector_A { A_arbace_reflect_JavaReflector_A_Init(); t := &A_arbace_reflect_JavaReflector_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_reflect_JavaReflector_A) Ctor_O(classloader any) { t.F_classloader = classloader }
//line :185:1
func A_arbace_reflect_JavaReflector_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_reflect_JavaReflector_A_Init(); return lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()) }
//line :185:1
func (t *A_arbace_reflect_JavaReflector_A) Do_reflect_O__O(typeref__1 any) any { var cls__2 any; var root_1 any = A_arbace_reflect_JavaReflector_A_const_0.GetRawRoot__O(); var linked_2 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1, A_arbace_reflect_typeref__GT_class_A_fn_class); var ifn_3 lang.IFn; if


	linked_2 == nil { ifn_3 = lang.IFn_Cast(root_1) } else { ifn_3 = nil }; var arg_4 any = typeref__1; var arg_5 any = t.F_classloader; if linked_2 == nil { cls__2 = ifn_3.Invoke_O_O__O(arg_4, arg_5) } else { cls__2 = linked_2.(*A_arbace_reflect_typeref__GT_class_A).Invoke_O_O_O__O(root_1, arg_4, arg_5) }; var tmp1 any = A_arbace_reflect_JavaReflector_A_const_1; var tmp2 any; var root_19 any = /*line :185:1*/A_arbace_reflect_JavaReflector_A_const_2.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_21 lang.IFn; if



	linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var root_15 any = A_arbace_reflect_JavaReflector_A_const_3.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var root_10 any = A_arbace_reflect_JavaReflector_A_const_4.GetRawRoot__O(); var linked_11 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_10, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_12 lang.IFn; if linked_11 == nil { ifn_12 = lang.IFn_Cast(root_10) } else { ifn_12 = nil }; var arg_13 any = A_arbace_reflect_JavaReflector_A_const_5.GetRawRoot__O(); var arg_14 any; var root_6 any = A_arbace_reflect_JavaReflector_A_const_6.GetRawRoot__O(); var linked_7 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_6, aot_arbace_core.A_arbace_core_bases_A_fn_class); var ifn_8 lang.IFn; if linked_7 == nil { ifn_8 = lang.IFn_Cast(root_6) } else { ifn_8 = nil }; var arg_9 any = cls__2; if linked_7 == nil { arg_14 = ifn_8.Invoke_O__O(arg_9) } else { arg_14 = linked_7.(*aot_arbace_core.A_arbace_core_bases_A).Invoke_O_O__O(root_6, arg_9) }; if linked_11 == nil { arg_18 = ifn_12.Invoke_O_O__O(arg_13, arg_14) } else { arg_18 = linked_11.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_10, arg_13, arg_14) }; if linked_16 == nil { arg_22 = ifn_17.Invoke_O__O(arg_18) } else { arg_22 = linked_16.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_15, arg_18) }; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_19, arg_22) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_reflect_JavaReflector_A_const_7; var tmp5 any; var root_23 any = /*line :185:1*/A_arbace_reflect_JavaReflector_A_const_8.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, A_arbace_reflect_parse_flags_A_fn_class); var ifn_25 lang.IFn; if




	linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Class_Cast(cls__2)).GetModifiers__I()).Ref(); var arg_27 any = A_arbace_reflect_JavaReflector_A_const_9; if linked_24 == nil { tmp5 = ifn_25.Invoke_O_O__O(arg_26, arg_27) } else { tmp5 = linked_24.(*A_arbace_reflect_parse_flags_A).Invoke_O_O_O__O(root_23, arg_26, arg_27) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_reflect_JavaReflector_A_const_10; var tmp8 lang.IFn = /*line :185:1*/lang.IFn_Cast(A_arbace_reflect_JavaReflector_A_const_11.GetRawRoot__O()); var tmp9 any; var root_28 any = A_arbace_reflect_JavaReflector_A_const_12.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_reflect_declared_fields_A_fn_class); var ifn_30 lang.IFn; if





	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = cls__2; if linked_29 == nil { tmp9 = ifn_30.Invoke_O__O(arg_31) } else { tmp9 = linked_29.(*A_arbace_reflect_declared_fields_A).Invoke_O_O__O(root_28, arg_31) }; var tmp10 any = tmp9; var tmp11 any; var root_32 any = /*line :185:1*/A_arbace_reflect_JavaReflector_A_const_13.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, A_arbace_reflect_declared_methods_A_fn_class); var ifn_34 lang.IFn; if






	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = cls__2; if linked_33 == nil { tmp11 = ifn_34.Invoke_O__O(arg_35) } else { tmp11 = linked_33.(*A_arbace_reflect_declared_methods_A).Invoke_O_O__O(root_32, arg_35) }; var tmp12 any = tmp11; var tmp13 any; var root_36 any = /*line :185:1*/A_arbace_reflect_JavaReflector_A_const_14.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_reflect_declared_constructors_A_fn_class); var ifn_38 lang.IFn; if







	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = cls__2; if linked_37 == nil { tmp13 = ifn_38.Invoke_O__O(arg_39) } else { tmp13 = linked_37.(*A_arbace_reflect_declared_constructors_A).Invoke_O_O__O(root_36, arg_39) }; return /*line :185:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp6, tmp7, tmp8.Invoke_O_O_O__O(tmp10, tmp12, tmp13))) }









type A_arbace_reflect_JavaReflector_A struct{ jrt.Object; F_classloader any }

func (t *A_arbace_reflect_JavaReflector_A) Is_A_arbace_reflect_Reflector_A() {}

func (t *A_arbace_reflect_JavaReflector_A) Is_IType() {}

var A_arbace_reflect_JavaReflector_A_const_pool *jrt.RefArray

var A_arbace_reflect_JavaReflector_A_const_0 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_1 *lang.Keyword

var A_arbace_reflect_JavaReflector_A_const_2 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_3 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_4 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_5 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_6 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_7 *lang.Keyword

var A_arbace_reflect_JavaReflector_A_const_8 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_9 *lang.Keyword

var A_arbace_reflect_JavaReflector_A_const_10 *lang.Keyword

var A_arbace_reflect_JavaReflector_A_const_11 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_12 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_13 *lang.Var

var A_arbace_reflect_JavaReflector_A_const_14 *lang.Var

var A_arbace_reflect_JavaReflector_A_init jrt.ClassInit

func A_arbace_reflect_JavaReflector_A_Init() { if !A_arbace_reflect_JavaReflector_A_init.Done() { A_arbace_reflect_JavaReflector_A_init.Run(A_arbace_reflect_JavaReflector_A_clinit) } }

func A_arbace_reflect_JavaReflector_A_clinit() { jrt.StartCheck(); A_arbace_reflect_JavaReflector_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_37, 19); A_arbace_reflect_JavaReflector_A_const_0 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[4]); A_arbace_reflect_JavaReflector_A_const_1 = lang.Keyword_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[5]); A_arbace_reflect_JavaReflector_A_const_2 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[6]); A_arbace_reflect_JavaReflector_A_const_3 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[7]); A_arbace_reflect_JavaReflector_A_const_4 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[8]); A_arbace_reflect_JavaReflector_A_const_5 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[9]); A_arbace_reflect_JavaReflector_A_const_6 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[10]); A_arbace_reflect_JavaReflector_A_const_7 = lang.Keyword_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[11]); A_arbace_reflect_JavaReflector_A_const_8 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[12]); A_arbace_reflect_JavaReflector_A_const_9 = lang.Keyword_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[13]); A_arbace_reflect_JavaReflector_A_const_10 = lang.Keyword_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[14]); A_arbace_reflect_JavaReflector_A_const_11 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[15]); A_arbace_reflect_JavaReflector_A_const_12 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[16]); A_arbace_reflect_JavaReflector_A_const_13 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[17]); A_arbace_reflect_JavaReflector_A_const_14 = lang.Var_Cast(A_arbace_reflect_JavaReflector_A_const_pool.A[18]) }

func (t *A_arbace_reflect_JavaReflector_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_JavaReflector_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_JavaReflector_A_class }

func (t *A_arbace_reflect_JavaReflector_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_JavaReflector_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_JavaReflector_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_JavaReflector_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_JavaReflector_A); return ok }

func A_arbace_reflect_JavaReflector_A_Cast(x any) *A_arbace_reflect_JavaReflector_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_JavaReflector_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_JavaReflector_A_class)) }; return v }
