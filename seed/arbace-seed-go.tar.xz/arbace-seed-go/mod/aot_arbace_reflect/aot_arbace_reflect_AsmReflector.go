//line aot_arbace_reflect_AsmReflector.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)














































































































































































































func A_arbace_reflect_AsmReflector_A_New_O(p0 any) *A_arbace_reflect_AsmReflector_A { A_arbace_reflect_AsmReflector_A_Init(); t := &A_arbace_reflect_AsmReflector_A{}; t.Ctor_O(p0); return t }
//line :213:1
func (t *A_arbace_reflect_AsmReflector_A) Ctor_O(class_resolver any) { t.F_class_resolver = class_resolver }
//line :213:1
func A_arbace_reflect_AsmReflector_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_reflect_AsmReflector_A_Init(); return lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref()) }
//line :213:1
func (t *A_arbace_reflect_AsmReflector_A) Do_reflect_O__O(typeref__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_24, nil, Lit_25); var tmp2 any; var target_1 any = typeref__1; var tmp3 bool; var tmp4 bool; tmp4 =



	A_arbace_reflect_TypeReference_A_InstanceOf(target_1); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp3 = tmp4; if tmp3 { tmp2 = A_arbace_reflect_TypeReference_A_Cast(target_1).Typename__O() } else { tmp2 = lang.IFn_Cast(A_arbace_reflect_AsmReflector_A_const_0.GetRawRoot__O()).Invoke_O__O(target_1) }; /*line :213:1*/panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil))))) }









type A_arbace_reflect_AsmReflector_A struct{ jrt.Object; F_class_resolver any }

func (t *A_arbace_reflect_AsmReflector_A) Is_A_arbace_reflect_Reflector_A() {}

func (t *A_arbace_reflect_AsmReflector_A) Is_IType() {}

var A_arbace_reflect_AsmReflector_A_const_pool *jrt.RefArray

var A_arbace_reflect_AsmReflector_A_const_0 *lang.Var

var A_arbace_reflect_AsmReflector_A_init jrt.ClassInit

func A_arbace_reflect_AsmReflector_A_Init() { if !A_arbace_reflect_AsmReflector_A_init.Done() { A_arbace_reflect_AsmReflector_A_init.Run(A_arbace_reflect_AsmReflector_A_clinit) } }

func A_arbace_reflect_AsmReflector_A_clinit() { A_arbace_reflect_AsmReflector_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_22, 1); A_arbace_reflect_AsmReflector_A_const_0 = lang.Var_Cast(A_arbace_reflect_AsmReflector_A_const_pool.A[0]) }

func (t *A_arbace_reflect_AsmReflector_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_AsmReflector_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_AsmReflector_A_class }

func (t *A_arbace_reflect_AsmReflector_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_AsmReflector_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_AsmReflector_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_AsmReflector_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_AsmReflector_A); return ok }

func A_arbace_reflect_AsmReflector_A_Cast(x any) *A_arbace_reflect_AsmReflector_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_AsmReflector_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_AsmReflector_A_class)) }; return v }
