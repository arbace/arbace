//line aot_arbace_reflect.ae:1
package aot_arbace_reflect

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_datafy"
	"arbace/aot_arbace_set"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :9:1
func A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_New() *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_reflect_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_reflect_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_reflect_eval659000008_fn__659000009_A_New() *A_arbace_reflect_eval659000008_fn__659000009_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000008_fn__659000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_reflect_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_reflect_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_reflect_A_const_7.GetRawRoot__O(), A_arbace_reflect_A_const_8) }










func A_arbace_reflect_eval1938000010_fn__1938000011_A_New() *A_arbace_reflect_eval1938000010_fn__1938000011_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000010_fn__1938000011_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Ctor() {}
//line :20:1
func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Invoke_O_O__O(self, s__1 any) any {

	var root_157 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_153 any = A_arbace_reflect_A_const_40.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = s__1; if linked_154 == nil { arg_160 = ifn_155.Invoke_O__O(arg_156) } else { arg_160 = linked_154.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_153, arg_156) }; var arg_161 any = Lit_4; var arg_162 any = Lit_3; if linked_158 == nil { return ifn_159.Invoke_O_O_O__O(arg_160, arg_161, arg_162) } else { return linked_158.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_157, arg_160, arg_161, arg_162) } }
//line :20:1
func A_arbace_reflect_eval1938000014_fn__1938000015_A_New() *A_arbace_reflect_eval1938000014_fn__1938000015_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000014_fn__1938000015_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Ctor() {}
//line :20:1
func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Invoke_O_O__O(self, c__1 any) any {








	if jrt.NN(jrt.Class_Cast(c__1)).IsArray__Z() {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3); var tmp2 any; var target_163 any = jrt.NN(jrt.Class_Cast(c__1)).GetComponentType__Class().Ref(); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_163); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_163) }; tmp3 = tmp4; if tmp3 { tmp2 = A_arbace_reflect_TypeReference_A_Cast(target_163).Typename__O() } else { tmp2 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_163) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() } else {
			return jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()
		} }
func A_arbace_reflect_typesym_A_New() *A_arbace_reflect_typesym_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typesym_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_reflect_typesym_A) Ctor() {}
//line :33:1
func (t *A_arbace_reflect_typesym_A) Invoke_O_O__O(self, t__0 any) any { var G__1938000018__2_ any; var root_171 any = A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_173 lang.IFn; if






	linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var root_165 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_167 lang.IFn; if /*line :39:1*/ linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any; var target_164 any = t__0; var tmp1 bool; var tmp2 bool; tmp2 = /*line :38:1*/A_arbace_reflect_TypeReference_A_InstanceOf(target_164); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_164) }; tmp1 = tmp2; if tmp1 { arg_168 = A_arbace_reflect_TypeReference_A_Cast(target_164).Typename__O() } else { arg_168 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_164) }; var arg_169 any = Lit_3; var arg_170 any = Lit_4; if
	linked_166 == nil { arg_174 = ifn_167.Invoke_O_O_O__O(arg_168, arg_169, arg_170) } else { arg_174 = linked_166.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_165, arg_168, arg_169, arg_170) }; if
	linked_172 == nil { G__1938000018__2_ = ifn_173.Invoke_O__O(arg_174) } else { G__1938000018__2_ = linked_172.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_171, arg_174) }; var tmp3 any; var root_175 any = /*line :37:1*/A_arbace_reflect_A_const_37.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_177 lang.IFn; if



	linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = t__0; if linked_176 == nil { tmp3 = ifn_177.Invoke_O__O(arg_178) } else { tmp3 = linked_176.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_175, arg_178) }; if /*line :37:1*/ jrt.J2g_Truth(tmp3) {



		var root_184 any = A_arbace_reflect_A_const_43.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = G__1938000018__2_; var arg_188 any; var tmp4 any = A_arbace_reflect_A_const_44; var tmp5 any = A_arbace_reflect_typesym_fn__1938000019_A_New_O(t__0); var tmp6 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_reflect_typesym_fn__1938000019_A_fn_class
		if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_reflect_typesym_fn__1938000019_A_fn_class = fncls__183d; tmp6 = fncls__183d } else { tmp6 = fncls__183 }
//line :41:1
		arg_188 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))); if linked_185 == nil { return ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { return linked_185.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_184, arg_187, arg_188) } } else {
//line :37:1
			return G__1938000018__2_ } }




func A_arbace_reflect_typesym_fn__1938000019_A_New_O(p0 any) *A_arbace_reflect_typesym_fn__1938000019_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typesym_fn__1938000019_A{}; t.Ctor_O(p0); return t }
//line :42:1
func (t *A_arbace_reflect_typesym_fn__1938000019_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :42:1
func (t *A_arbace_reflect_typesym_fn__1938000019_A) Invoke_O_O__O(self, ___1 any) any { var root_179 any = A_arbace_reflect_A_const_45.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_datafy.A_arbace_datafy_datafy_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = t.F_t; if linked_180 == nil { return ifn_181.Invoke_O__O(arg_182) } else { return linked_180.(*aot_arbace_datafy.A_arbace_datafy_datafy_A).Invoke_O_O__O(root_179, arg_182) } }

func A_arbace_reflect_eval659000020_fn__659000021_A_New() *A_arbace_reflect_eval659000020_fn__659000021_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__659000013__2_ any; var tmp1 any = A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_New(); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; G__659000013__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_New_O(G__659000013__2_); var tmp4 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class = fncls__28d; tmp4 = fncls__28d } else { tmp4 = fncls__28 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :44:1
func A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_New_O(p0 any) *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A{}; t.Ctor_O(p0); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Ctor_O(c__G__659000013 any) { t.F_G__659000013 = c__G__659000013 }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Invoke_O_O_O__O(self, gf__reflector__659000026__1, gf__typeref__659000027__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__reflector__659000026__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__reflector__659000026__1, gf__typeref__659000027__2) } else { var tmp1 any; var root_21 any = A_arbace_reflect_A_const_9.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = self; var arg_25 any = gf__reflector__659000026__1; var arg_26 any = A_arbace_reflect_A_const_10; var arg_27 any = t.F_G__659000013; if linked_22 == nil { tmp1 = ifn_23.Invoke_O_O_O_O__O(arg_24, arg_25, arg_26, arg_27) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_21, arg_24, arg_25, arg_26, arg_27) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__reflector__659000026__1, gf__typeref__659000027__2) } }
//line :44:1
func A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_New() *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Invoke_O_O_O__O(self, gf__reflector__659000022__1, gf__typeref__659000023__2 any) any { var target_19 any = gf__reflector__659000022__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_19 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_19) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_19, Lit_11, jrt.RefArrayOf(jrt.Object_class, gf__typeref__659000023__2)) } else { return A_arbace_reflect_Reflector_A_Cast(target_19).Do_reflect_O__O(gf__typeref__659000023__2) } }
//line :44:1
func A_arbace_reflect_resource_name_A_New() *A_arbace_reflect_resource_name_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_resource_name_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_resource_name_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_resource_name_A) Invoke_O_O__O(self, typeref__0 any) any {





	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_18); var tmp2 any; var root_190 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_192 lang.IFn
//line :49:1
	if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var target_189 any = typeref__0; var tmp3 bool; var tmp4 bool
//line :48:1
	tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_189); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_189) }; tmp3 = tmp4; if tmp3 { arg_193 = A_arbace_reflect_TypeReference_A_Cast(target_189).Typename__O() } else { arg_193 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_189) }
	var arg_194 any = Lit_2; var arg_195 any = Lit_1; if linked_191 == nil { tmp2 = ifn_192.Invoke_O_O_O__O(arg_193, arg_194, arg_195) } else { tmp2 = linked_191.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_190, arg_193, arg_194, arg_195) }
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_A_New() *A_arbace_reflect_eval659000044_fn__659000045_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Ctor() {}
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__659000037__2_ any; var tmp1 any = A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_New(); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; G__659000037__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_New_O(G__659000037__2_); var tmp4 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class = fncls__38d; tmp4 = fncls__38d } else { tmp4 = fncls__38 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_New_O(p0 any) *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Ctor_O(c__G__659000037 any) { t.F_G__659000037 = c__G__659000037 }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Invoke_O_O__O(self, gf__o__659000049__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__o__659000049__1)); if jrt.J2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__o__659000049__1) } else { var tmp1 any; var root_31 any = A_arbace_reflect_A_const_9.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = self; var arg_35 any = gf__o__659000049__1; var arg_36 any = A_arbace_reflect_A_const_11; var arg_37 any = t.F_G__659000037; if linked_32 == nil { tmp1 = ifn_33.Invoke_O_O_O_O__O(arg_34, arg_35, arg_36, arg_37) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_31, arg_34, arg_35, arg_36, arg_37) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gf__o__659000049__1) } }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_New() *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Ctor() {}
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Invoke_O_O__O(self, gf__o__659000046__1 any) any { var target_29 any = gf__o__659000046__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_29 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_29) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_29, Lit_14, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_reflect_TypeReference_A_Cast(target_29).Typename__O() } }



func A_arbace_reflect_access_flag_A_New() *A_arbace_reflect_access_flag_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_access_flag_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_reflect_access_flag_A) Ctor() {}
//line :52:1
func (t *A_arbace_reflect_access_flag_A) Invoke_O_O__O(self, p__1938000023__0 any) any { var vec__1938000024__2 any = p__1938000023__0; var seq__1938000025__3 any; var root_196 any = A_arbace_reflect_A_const_19.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = vec__1938000024__2; if linked_197 == nil { seq__1938000025__3 = ifn_198.Invoke_O__O(arg_199) } else { seq__1938000025__3 = linked_197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_196, arg_199) }; var first__1938000026__4 any; var root_200 any = A_arbace_reflect_A_const_20.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = seq__1938000025__3; if linked_201 == nil { first__1938000026__4 = ifn_202.Invoke_O__O(arg_203) } else { first__1938000026__4 = linked_201.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_200, arg_203) }; var seq__1938000025__5 any; var root_204 any = A_arbace_reflect_A_const_17.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = seq__1938000025__3; if linked_205 == nil { seq__1938000025__5 = ifn_206.Invoke_O__O(arg_207) } else { seq__1938000025__5 = linked_205.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_204, arg_207) }; var name__6 any = first__1938000026__4; var first__1938000026__7 any; var root_208 any = A_arbace_reflect_A_const_20.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = seq__1938000025__5; if linked_209 == nil { first__1938000026__7 = ifn_210.Invoke_O__O(arg_211) } else { first__1938000026__7 = linked_209.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_208, arg_211) }; var seq__1938000025__8 any; var root_212 any = A_arbace_reflect_A_const_17.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = seq__1938000025__5; if linked_213 == nil { seq__1938000025__8 = ifn_214.Invoke_O__O(arg_215) } else { seq__1938000025__8 = linked_213.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_212, arg_215) }; var flag__9 any = first__1938000026__7; var contexts__10 any = seq__1938000025__8; var tmp1 any = A_arbace_reflect_A_const_46; var tmp2 any = A_arbace_reflect_A_const_47; var tmp3 any = A_arbace_reflect_A_const_48; var tmp4 any; var root_221 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_223 lang.IFn; if

	linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var root_216 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = A_arbace_reflect_A_const_49.GetRawRoot__O(); var arg_220 any = contexts__10; if linked_217 == nil { arg_224 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { arg_224 = linked_217.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; if linked_222 == nil { tmp4 = ifn_223.Invoke_O__O(arg_224) } else { tmp4 = linked_222.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_221, arg_224) }; return /*line :52:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, name__6, tmp2, flag__9, tmp3, tmp4)) }



func A_arbace_reflect_descriptor_class_name_A_New() *A_arbace_reflect_descriptor_class_name_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_descriptor_class_name_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_reflect_descriptor_class_name_A) Ctor() {}
//line :56:1
func (t *A_arbace_reflect_descriptor_class_name_A) Invoke_O_O__O(self, d__0 any) any { var G__1938000028__2_ uint16 = jrt.NN(jrt.String_Cast(d__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)); switch


	lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1938000028__2_).Ref()) { case 76: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1938000028__2_).Ref(), A_arbace_reflect_A_const_50) {

		var root_232 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any; var root_226 any = A_arbace_reflect_A_const_51.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = d__0; var arg_230 any = A_arbace_reflect_A_const_52; var arg_231 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(d__0)))).Ref(); if linked_227 == nil { arg_235 = ifn_228.Invoke_O_O_O__O(arg_229, arg_230, arg_231) } else { arg_235 = linked_227.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_226, arg_229, arg_230, arg_231) }; var arg_236 any = Lit_1; var arg_237 any = Lit_2; if linked_233 == nil { return ifn_234.Invoke_O_O_O__O(arg_235, arg_236, arg_237) } else { return linked_233.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_232, arg_235, arg_236, arg_237) } }
//line :59:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1938000028__2_).Ref(), A_arbace_reflect_A_const_53) {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3); var tmp2 any; var root_243 any = A_arbace_reflect_A_const_54.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, A_arbace_reflect_descriptor_class_name_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var root_238 any = A_arbace_reflect_A_const_51.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = d__0; var arg_242 any = A_arbace_reflect_A_const_52; if linked_239 == nil { arg_246 = ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { arg_246 = linked_239.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_238, arg_241, arg_242) }; if linked_244 == nil { tmp2 = ifn_245.Invoke_O__O(arg_246) } else { tmp2 = linked_244.(*A_arbace_reflect_descriptor_class_name_A).Invoke_O_O__O(root_243, arg_246) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() }
//line :59:1
	default:}; return /*line :62:1*/ lang.IFn_Cast(A_arbace_reflect_A_const_55).Invoke_O__O(d__0) }
//line :58:1
func A_arbace_reflect_type_reflect_A_New() *A_arbace_reflect_type_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_reflect_type_reflect_A) Ctor() {}
//line :58:1
func (t *A_arbace_reflect_type_reflect_A) DoInvoke_O_O_O__O(self, typeref__0, options__1 any) any { { var map__659000059__3 any; var root_44 any = A_arbace_reflect_A_const_12.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_46 lang.IFn






































	if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var tmp1 any = A_arbace_reflect_A_const_13; var arg_47 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, A_arbace_reflect_A_const_14.GetRawRoot__O())); var arg_48 any; var root_39 any = A_arbace_reflect_A_const_15.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_41 lang.IFn
	if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_reflect_A_const_16.GetRawRoot__O(); var arg_43 any = options__1; if linked_40 == nil { arg_48 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_48 = linked_40.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }
//line :97:1
	if linked_45 == nil { map__659000059__3 = ifn_46.Invoke_O_O__O(arg_47, arg_48) } else { map__659000059__3 = linked_45.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_44, arg_47, arg_48) }
//line :58:1
	var map__659000059__4 any





































	if lang.ISeq_InstanceOf(map__659000059__3) { var tmp2 any; var root_49 any = A_arbace_reflect_A_const_17.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = map__659000059__3; if linked_50 == nil { tmp2 = ifn_51.Invoke_O__O(arg_52) } else { tmp2 = linked_50.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_53 any = A_arbace_reflect_A_const_18.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = map__659000059__3; if linked_54 == nil { tmp3 = ifn_55.Invoke_O__O(arg_56) } else { tmp3 = linked_54.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_53, arg_56) }; map__659000059__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_57 any = A_arbace_reflect_A_const_19.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = map__659000059__3; if linked_58 == nil { tmp4 = ifn_59.Invoke_O__O(arg_60) } else { tmp4 = linked_58.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_57, arg_60) }; if jrt.J2g_Truth(tmp4) { var root_61 any = A_arbace_reflect_A_const_20.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = map__659000059__3; if linked_62 == nil { map__659000059__4 = ifn_63.Invoke_O__O(arg_64) } else { map__659000059__4 = linked_62.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_61, arg_64) } } else { map__659000059__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__659000059__4 = map__659000059__3 }
//line :58:1
	var ancestors__5 any = lang.RT_Get_O_O__O_NoInit(map__659000059__4, A_arbace_reflect_A_const_21); var reflector__6 any = lang.RT_Get_O_O__O_NoInit(map__659000059__4, A_arbace_reflect_A_const_13); var refl__7 any; var root_65 any = A_arbace_reflect_A_const_22.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_67 lang.IFn








































	if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_reflect_A_const_23.GetRawRoot__O(); var arg_69 any = reflector__6; if linked_66 == nil { refl__7 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { refl__7 = linked_66.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }
//line :58:1
	var result__8 any = lang.IFn_Cast(refl__7).Invoke_O__O(typeref__0)











































	if jrt.J2g_Truth(ancestors__5) { var make_ancestor_map__9 any; var tmp5 any = A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_New_O(refl__7); var tmp6 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class
		if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class = fncls__80d; tmp6 = fncls__80d } else { tmp6 = fncls__80 }; make_ancestor_map__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
//line :102:1
		var reflections__10 any = lang.IFn_Cast(make_ancestor_map__9).Invoke_O__O(A_arbace_reflect_A_const_30.Invoke_O__O(result__8)); L1: for { var ancestors_visited__11 any; var root_85 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_87 lang.IFn



			if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any; var root_81 any = A_arbace_reflect_A_const_27.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = reflections__10; if linked_82 == nil { arg_88 = ifn_83.Invoke_O__O(arg_84) } else { arg_88 = linked_82.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_81, arg_84) }; if linked_86 == nil { ancestors_visited__11 = ifn_87.Invoke_O__O(arg_88) } else { ancestors_visited__11 = linked_86.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_85, arg_88) }
//line :102:1
			var ancestors_to_visit__12 any; var root_102 any = A_arbace_reflect_A_const_28.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_102, aot_arbace_set.A_arbace_set_difference_A_fn_class); var ifn_104 lang.IFn




			if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any; var root_98 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_29.GetRawRoot__O()); var tmp8 any = A_arbace_reflect_A_const_30; var tmp9 any; var root_89 any = A_arbace_reflect_A_const_31.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = reflections__10; if linked_90 == nil { tmp9 = ifn_91.Invoke_O__O(arg_92) } else { tmp9 = linked_90.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_89, arg_92) }; arg_101 = tmp7.Invoke_O_O__O(tmp8, tmp9); if linked_99 == nil { arg_105 = ifn_100.Invoke_O__O(arg_101) } else { arg_105 = linked_99.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_98, arg_101) }; var arg_106 any = ancestors_visited__11; if linked_103 == nil { ancestors_to_visit__12 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { ancestors_to_visit__12 = linked_103.(*aot_arbace_set.A_arbace_set_difference_A).Invoke_O_O_O__O(root_102, arg_105, arg_106)
			}
			var tmp10 any; var root_107 any = A_arbace_reflect_A_const_19.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = ancestors_to_visit__12; if linked_108 == nil { tmp10 = ifn_109.Invoke_O__O(arg_110) } else { tmp10 = linked_108.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_107, arg_110) }; if jrt.J2g_Truth(tmp10) {
				var tmp11 any; var root_134 any = A_arbace_reflect_A_const_12.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = reflections__10; var arg_138 any = lang.IFn_Cast(make_ancestor_map__9).Invoke_O__O(ancestors_to_visit__12); if linked_135 == nil { tmp11 = ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { tmp11 = linked_135.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_134, arg_137, arg_138) }; reflections__10 = tmp11; continue L1 } else {
					var root_126 any = A_arbace_reflect_A_const_15.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = A_arbace_reflect_A_const_32.GetRawRoot__O(); var arg_130 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var arg_131 any = result__8; var arg_132 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect_A_const_21, ancestors_visited__11)); var arg_133 any; var root_121 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_123 lang.IFn
					if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any; var tmp12 any = A_arbace_reflect_type_reflect_fn__659000063_A_New(); var tmp13 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_reflect_type_reflect_fn__659000063_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_reflect_type_reflect_fn__659000063_A_fn_class = fncls__116d; tmp13 = fncls__116d } else { tmp13 = fncls__116 }; arg_124 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_125 any; var root_117 any = A_arbace_reflect_A_const_31.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = reflections__10; if linked_118 == nil { arg_125 = ifn_119.Invoke_O__O(arg_120) } else { arg_125 = linked_118.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_117, arg_120) }; if linked_122 == nil { arg_133 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { arg_133 = linked_122.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }
//line :111:1
					if linked_127 == nil { return ifn_128.Invoke_O_O_O_O_O__O(arg_129, arg_130, arg_131, arg_132, arg_133) } else { return linked_127.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_126, arg_129, arg_130, arg_131, arg_132, arg_133) } } } } else {
//line :102:1
						return result__8 } }; /*line :58:1*/panic("j2g: unreachable") }






func A_arbace_reflect_field_descriptor__GT_class_symbol_A_New() *A_arbace_reflect_field_descriptor__GT_class_symbol_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_field_descriptor__GT_class_symbol_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Ctor() {}
//line :65:1
func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 any; var root_261 any = A_arbace_reflect_A_const_56.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_263 lang.IFn; if




	linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = d__0; if linked_262 == nil { tmp1 = ifn_263.Invoke_O__O(arg_264) } else { tmp1 = linked_262.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_261, arg_264) }; if /*line :65:1*/ jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_reflect_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_58))).Ref()))) }; var root_257 any =





	A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any; var root_251 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any; var root_247 any = A_arbace_reflect_A_const_54.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, A_arbace_reflect_descriptor_class_name_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = d__0; if linked_248 == nil { arg_254 = ifn_249.Invoke_O__O(arg_250) } else { arg_254 = linked_248.(*A_arbace_reflect_descriptor_class_name_A).Invoke_O_O__O(root_247, arg_250) }; var arg_255 any = Lit_3; var arg_256 any = Lit_4; if linked_252 == nil { arg_260 = ifn_253.Invoke_O_O_O__O(arg_254, arg_255, arg_256) } else { arg_260 = linked_252.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_251, arg_254, arg_255, arg_256) }; if linked_258 == nil { return ifn_259.Invoke_O__O(arg_260) } else { return linked_258.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_257, arg_260) } }

func A_arbace_reflect_internal_name__GT_class_symbol_A_New() *A_arbace_reflect_internal_name__GT_class_symbol_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_internal_name__GT_class_symbol_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Ctor() {}
//line :73:1
func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 any; var root_289 any = A_arbace_reflect_A_const_56.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_291 lang.IFn; if






	linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = d__0; if linked_290 == nil { tmp1 = ifn_291.Invoke_O__O(arg_292) } else { tmp1 = linked_290.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_289, arg_292) }; if /*line :73:1*/ jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_reflect_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_59))).Ref()))) }; var root_285 any =







	A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any; var root_279 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any; if jrt.NN(jrt.String_Cast(d__0)).StartsWith_String__Z(Lit_16) { var root_269 any = A_arbace_reflect_A_const_54.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_reflect_descriptor_class_name_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = d__0; if linked_270 == nil { arg_282 = ifn_271.Invoke_O__O(arg_272) } else { arg_282 = linked_270.(*A_arbace_reflect_descriptor_class_name_A).Invoke_O_O__O(root_269, arg_272) } } else { var root_273 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = d__0; var arg_277 any = Lit_1; var arg_278 any = Lit_2; if linked_274 == nil { arg_282 = ifn_275.Invoke_O_O_O__O(arg_276, arg_277, arg_278) } else { arg_282 = linked_274.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_273, arg_276, arg_277, arg_278) } }; var arg_283 any = Lit_3; var arg_284 any = Lit_4; if linked_280 == nil { arg_288 = ifn_281.Invoke_O_O_O__O(arg_282, arg_283, arg_284) } else { arg_288 = linked_280.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_279, arg_282, arg_283, arg_284) }; if linked_286 == nil { return ifn_287.Invoke_O__O(arg_288) } else { return linked_286.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_285, arg_288) } }





















func A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_New_O(p0 any) *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Ctor_O(c__refl any) { t.F_refl = c__refl }
//line :103:1
func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Invoke_O_O__O(self, names__1 any) any {
	var root_75 any = A_arbace_reflect_A_const_24.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = names__1; var arg_79 any; var root_70 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = t.F_refl; var arg_74 any = names__1; if linked_71 == nil { arg_79 = ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { arg_79 = linked_71.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) }; if linked_76 == nil { return ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { return linked_76.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_75, arg_78, arg_79)
	}
}



func A_arbace_reflect_parse_flags_A_New() *A_arbace_reflect_parse_flags_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_parse_flags_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_reflect_parse_flags_A) Ctor() {}
//line :110:1
func (t *A_arbace_reflect_parse_flags_A) Invoke_O_O_O__O(self, flags__0, context__1 any) any {


	var root_312 any = A_arbace_reflect_A_const_60.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any; var tmp1 any = A_arbace_reflect_parse_flags_fn__1938000032_A_New_O_O(flags__0, context__1); var tmp2 *jrt.Class; var fncls__311 *jrt.Class = A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class
	if fncls__311 == nil { var fncls__311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class = fncls__311d; tmp2 = fncls__311d } else { tmp2 = fncls__311 }; arg_315 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :113:1
	var arg_316 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_317 any = A_arbace_reflect_A_const_62.GetRawRoot__O(); if linked_313 == nil { return ifn_314.Invoke_O_O_O__O(arg_315, arg_316, arg_317) } else { return linked_313.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_312, arg_315, arg_316, arg_317) } }
//line :112:1
func A_arbace_reflect_type_reflect_fn__659000063_A_New() *A_arbace_reflect_type_reflect_fn__659000063_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_fn__659000063_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Ctor() {}
//line :112:1
func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Invoke_O_O__O(self, p1__659000058_SHARP___1 any) any { var root_111 any = A_arbace_reflect_A_const_34.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = p1__659000058_SHARP___1; var arg_115 any = A_arbace_reflect_A_const_35; if linked_112 == nil { return ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { return linked_112.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_111, arg_114, arg_115) } }

func A_arbace_reflect_parse_flags_fn__1938000032_A_New_O_O(p0, p1 any) *A_arbace_reflect_parse_flags_fn__1938000032_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_parse_flags_fn__1938000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Ctor_O_O(c__flags, c__context any) { t.F_flags = c__flags; t.F_context = c__context }
//line :114:1
func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Invoke_O_O_O__O(self, result__1, fd__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_reflect_A_const_48.Invoke_O__O(fd__2), t.F_context); if jrt.J2g_Truth(and__1927000168__auto____3) {
		var root_302 any = A_arbace_reflect_A_const_61.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var tmp2 int64; var na_297 any = t.F_flags; var na_298 any = A_arbace_reflect_A_const_47.Invoke_O__O(fd__2); var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_297); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_298) }; tmp3 = tmp4; if tmp3 { var n0_299 int64 = jrt.NN(jrt.Long_Cast(na_297)).LongValue__J(); var n1_300 int64 = jrt.NN(jrt.Long_Cast(na_298)).LongValue__J(); tmp2 = n0_299 & n1_300 } else { tmp2 = lang.Numbers_And_O_O__J_NoInit(na_297, na_298) }; arg_305 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp2)).Ref(); if linked_303 == nil { tmp1 = ifn_304.Invoke_O__O(arg_305) } else { tmp1 = linked_303.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_302, arg_305) } } else {
//line :115:1
			tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {

				var root_306 any = A_arbace_reflect_A_const_7.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = result__1; var arg_310 any = A_arbace_reflect_A_const_46.Invoke_O__O(fd__2); if linked_307 == nil { return ifn_308.Invoke_O_O__O(arg_309, arg_310) } else { return linked_307.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_306, arg_309, arg_310) } } else {
//line :115:1
					return result__1 } }
//line :115:1
func A_arbace_reflect_reflect_A_New() *A_arbace_reflect_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_reflect_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_reflect_reflect_A) Ctor() {}
//line :115:1
func (t *A_arbace_reflect_reflect_A) DoInvoke_O_O_O__O(self, obj__0, options__1 any) any {





	var root_147 any = A_arbace_reflect_A_const_15.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = A_arbace_reflect_A_const_36.GetRawRoot__O(); var arg_151 any; var tmp1 any; var root_139 any = A_arbace_reflect_A_const_37.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = obj__0; if linked_140 == nil { tmp1 = ifn_141.Invoke_O__O(arg_142) } else { tmp1 = linked_140.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_139, arg_142) }; if jrt.J2g_Truth(tmp1) { arg_151 = obj__0 } else { var root_143 any = A_arbace_reflect_A_const_38.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = obj__0; if linked_144 == nil { arg_151 = ifn_145.Invoke_O__O(arg_146) } else { arg_151 = linked_144.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_143, arg_146) } }; var arg_152 any = options__1; if linked_148 == nil { return ifn_149.Invoke_O_O_O__O(arg_150, arg_151, arg_152) } else { return linked_148.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_147, arg_150, arg_151, arg_152) } }
func A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_New() *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Ctor() {}
//line :122:1
func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Invoke_O_O_O_O_O_O__O(self, name__1, declaring_class__2, parameter_types__3, exception_types__4, flags__5 any) any { return A_arbace_reflect_Constructor_A_New_O_O_O_O_O(name__1, declaring_class__2, parameter_types__3, exception_types__4, flags__5) }
//line :122:1
func A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_New() *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Ctor() {}
//line :122:1
func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { var root_318 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_322 any = m__231000174__auto____1; if linked_319 == nil { tmp1 = ifn_320.Invoke_O_O__O(arg_321, arg_322) } else { tmp1 = linked_319.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_318, arg_321, arg_322) } }; return A_arbace_reflect_Constructor_A_Create_IPersistentMap__A_arbace_reflect_Constructor_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_constructor__GT_map_A_New() *A_arbace_reflect_constructor__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_constructor__GT_map_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_reflect_constructor__GT_map_A) Ctor() {}
//line :125:1
func (t *A_arbace_reflect_constructor__GT_map_A) Invoke_O_O__O(self, constructor__0 any) any { var tmp1 any; var root_323 any = A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_325 lang.IFn; if


	linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = jrt.NN(jrt.Constructor_Cast(constructor__0)).GetName__String().Ref(); if linked_324 == nil { tmp1 = ifn_325.Invoke_O__O(arg_326) } else { tmp1 = linked_324.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_323, arg_326) }; var tmp2 any = tmp1; var tmp3 any; var root_327 any = /*line :125:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, A_arbace_reflect_typesym_A_fn_class); var ifn_329 lang.IFn; if



	linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = jrt.NN(jrt.Constructor_Cast(constructor__0)).GetDeclaringClass__Class().Ref(); if linked_328 == nil { tmp3 = ifn_329.Invoke_O__O(arg_330) } else { tmp3 = linked_328.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_327, arg_330) }; var tmp4 any = tmp3; var tmp5 any; var root_336 any = /*line :125:1*/A_arbace_reflect_A_const_64.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_338 lang.IFn; if




	linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any; var root_331 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = A_arbace_reflect_A_const_63.GetRawRoot__O(); var arg_335 any = jrt.NN(jrt.Constructor_Cast(constructor__0)).GetParameterTypes__Class1().Ref(); if linked_332 == nil { arg_339 = ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { arg_339 = linked_332.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_331, arg_334, arg_335) }; if linked_337 == nil { tmp5 = ifn_338.Invoke_O__O(arg_339) } else { tmp5 = linked_337.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_336, arg_339) }; var tmp6 any = tmp5; var tmp7 any; var root_345 any = /*line :125:1*/A_arbace_reflect_A_const_64.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_347 lang.IFn; if





	linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any; var root_340 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = A_arbace_reflect_A_const_63.GetRawRoot__O(); var arg_344 any = jrt.NN(jrt.Constructor_Cast(constructor__0)).GetExceptionTypes__Class1().Ref(); if linked_341 == nil { arg_348 = ifn_342.Invoke_O_O__O(arg_343, arg_344) } else { arg_348 = linked_341.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_340, arg_343, arg_344) }; if linked_346 == nil { tmp7 = ifn_347.Invoke_O__O(arg_348) } else { tmp7 = linked_346.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_345, arg_348) }; var tmp8 any = tmp7; var tmp9 any; var root_349 any = /*line :125:1*/A_arbace_reflect_A_const_65.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, A_arbace_reflect_parse_flags_A_fn_class); var ifn_351 lang.IFn; if






	linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(constructor__0)).GetModifiers__I()).Ref(); var arg_353 any = A_arbace_reflect_A_const_66; if linked_350 == nil { tmp9 = ifn_351.Invoke_O_O__O(arg_352, arg_353) } else { tmp9 = linked_350.(*A_arbace_reflect_parse_flags_A).Invoke_O_O_O__O(root_349, arg_352, arg_353) }; return /*line :125:1*/ A_arbace_reflect_Constructor_A_New_O_O_O_O_O(tmp2, tmp4, tmp6, tmp8, tmp9) }








func A_arbace_reflect_declared_constructors_A_New() *A_arbace_reflect_declared_constructors_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_constructors_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_reflect_declared_constructors_A) Ctor() {}
//line :134:1
func (t *A_arbace_reflect_declared_constructors_A) Invoke_O_O__O(self, cls__0 any) any {


	var root_359 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var root_354 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_reflect_A_const_67.GetRawRoot__O(); var arg_358 any = jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredConstructors__Constructor1().Ref(); if linked_355 == nil { arg_362 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { arg_362 = linked_355.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }; if linked_360 == nil { return ifn_361.Invoke_O__O(arg_362) } else { return linked_360.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_359, arg_362)
	}
}

func A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_New() *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000060___GT_Method__1938000078_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Ctor() {}
//line :141:1
func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Invoke_O_O_O_O_O_O_O__O(self, name__1, return_type__2, declaring_class__3, parameter_types__4, exception_types__5, flags__6 any) any { return A_arbace_reflect_Method_A_New_O_O_O_O_O_O(name__1, return_type__2, declaring_class__3, parameter_types__4, exception_types__5, flags__6) }
//line :141:1
func A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_New() *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Ctor() {}
//line :141:1
func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { var root_363 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_367 any = m__231000174__auto____1; if linked_364 == nil { tmp1 = ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { tmp1 = linked_364.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_363, arg_366, arg_367) } }; return A_arbace_reflect_Method_A_Create_IPersistentMap__A_arbace_reflect_Method_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_method__GT_map_A_New() *A_arbace_reflect_method__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_method__GT_map_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_reflect_method__GT_map_A) Ctor() {}
//line :144:1
func (t *A_arbace_reflect_method__GT_map_A) Invoke_O_O__O(self, method__0 any) any { var tmp1 any; var root_368 any = A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_370 lang.IFn; if


	linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = jrt.NN(jrt.Method_Cast(method__0)).GetName__String().Ref(); if linked_369 == nil { tmp1 = ifn_370.Invoke_O__O(arg_371) } else { tmp1 = linked_369.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_368, arg_371) }; var tmp2 any = tmp1; var tmp3 any; var root_372 any = /*line :144:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, A_arbace_reflect_typesym_A_fn_class); var ifn_374 lang.IFn; if



	linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = jrt.NN(jrt.Method_Cast(method__0)).GetReturnType__Class().Ref(); if linked_373 == nil { tmp3 = ifn_374.Invoke_O__O(arg_375) } else { tmp3 = linked_373.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_372, arg_375) }; var tmp4 any = tmp3; var tmp5 any; var root_376 any = /*line :144:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, A_arbace_reflect_typesym_A_fn_class); var ifn_378 lang.IFn; if




	linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = jrt.NN(jrt.Method_Cast(method__0)).GetDeclaringClass__Class().Ref(); if linked_377 == nil { tmp5 = ifn_378.Invoke_O__O(arg_379) } else { tmp5 = linked_377.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_376, arg_379) }; var tmp6 any = tmp5; var tmp7 any; var root_385 any = /*line :144:1*/A_arbace_reflect_A_const_64.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_387 lang.IFn; if





	linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any; var root_380 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = A_arbace_reflect_A_const_63.GetRawRoot__O(); var arg_384 any = jrt.NN(jrt.Method_Cast(method__0)).GetParameterTypes__Class1().Ref(); if linked_381 == nil { arg_388 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { arg_388 = linked_381.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; if linked_386 == nil { tmp7 = ifn_387.Invoke_O__O(arg_388) } else { tmp7 = linked_386.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_385, arg_388) }; var tmp8 any = tmp7; var tmp9 any; var root_394 any = /*line :144:1*/A_arbace_reflect_A_const_64.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_396 lang.IFn; if






	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any; var root_389 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = A_arbace_reflect_A_const_63.GetRawRoot__O(); var arg_393 any = jrt.NN(jrt.Method_Cast(method__0)).GetExceptionTypes__Class1().Ref(); if linked_390 == nil { arg_397 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { arg_397 = linked_390.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }; if linked_395 == nil { tmp9 = ifn_396.Invoke_O__O(arg_397) } else { tmp9 = linked_395.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_394, arg_397) }; var tmp10 any = tmp9; var tmp11 any; var root_398 any = /*line :144:1*/A_arbace_reflect_A_const_65.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, A_arbace_reflect_parse_flags_A_fn_class); var ifn_400 lang.IFn; if







	linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(method__0)).GetModifiers__I()).Ref(); var arg_402 any = A_arbace_reflect_A_const_66; if linked_399 == nil { tmp11 = ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { tmp11 = linked_399.(*A_arbace_reflect_parse_flags_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) }; return /*line :144:1*/ A_arbace_reflect_Method_A_New_O_O_O_O_O_O(tmp2, tmp4, tmp6, tmp8, tmp10, tmp11) }









func A_arbace_reflect_declared_methods_A_New() *A_arbace_reflect_declared_methods_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_methods_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_reflect_declared_methods_A) Ctor() {}
//line :154:1
func (t *A_arbace_reflect_declared_methods_A) Invoke_O_O__O(self, cls__0 any) any {


	var root_408 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var root_403 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = A_arbace_reflect_A_const_68.GetRawRoot__O(); var arg_407 any = jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredMethods__Method1().Ref(); if linked_404 == nil { arg_411 = ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { arg_411 = linked_404.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_403, arg_406, arg_407) }; if linked_409 == nil { return ifn_410.Invoke_O__O(arg_411) } else { return linked_409.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_408, arg_411)
	}
}

func A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_New() *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000086___GT_Field__1938000100_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Ctor() {}
//line :161:1
func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Invoke_O_O_O_O_O__O(self, name__1, type__2, declaring_class__3, flags__4 any) any { return A_arbace_reflect_Field_A_New_O_O_O_O(name__1, type__2, declaring_class__3, flags__4) }
//line :161:1
func A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_New() *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Ctor() {}
//line :161:1
func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { var root_412 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_416 any = m__231000174__auto____1; if linked_413 == nil { tmp1 = ifn_414.Invoke_O_O__O(arg_415, arg_416) } else { tmp1 = linked_413.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_412, arg_415, arg_416) } }; return A_arbace_reflect_Field_A_Create_IPersistentMap__A_arbace_reflect_Field_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_field__GT_map_A_New() *A_arbace_reflect_field__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_field__GT_map_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_reflect_field__GT_map_A) Ctor() {}
//line :164:1
func (t *A_arbace_reflect_field__GT_map_A) Invoke_O_O__O(self, field__0 any) any { var tmp1 any; var root_417 any = A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_419 lang.IFn; if


	linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = jrt.NN(jrt.Field_Cast(field__0)).GetName__String().Ref(); if linked_418 == nil { tmp1 = ifn_419.Invoke_O__O(arg_420) } else { tmp1 = linked_418.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_417, arg_420) }; var tmp2 any = tmp1; var tmp3 any; var root_421 any = /*line :164:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_reflect_typesym_A_fn_class); var ifn_423 lang.IFn; if



	linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = jrt.NN(jrt.Field_Cast(field__0)).GetType__Class().Ref(); if linked_422 == nil { tmp3 = ifn_423.Invoke_O__O(arg_424) } else { tmp3 = linked_422.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_421, arg_424) }; var tmp4 any = tmp3; var tmp5 any; var root_425 any = /*line :164:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, A_arbace_reflect_typesym_A_fn_class); var ifn_427 lang.IFn; if




	linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = jrt.NN(jrt.Field_Cast(field__0)).GetDeclaringClass__Class().Ref(); if linked_426 == nil { tmp5 = ifn_427.Invoke_O__O(arg_428) } else { tmp5 = linked_426.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_425, arg_428) }; var tmp6 any = tmp5; var tmp7 any; var root_429 any = /*line :164:1*/A_arbace_reflect_A_const_65.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, A_arbace_reflect_parse_flags_A_fn_class); var ifn_431 lang.IFn; if





	linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(field__0)).GetModifiers__I()).Ref(); var arg_433 any = A_arbace_reflect_A_const_69; if linked_430 == nil { tmp7 = ifn_431.Invoke_O_O__O(arg_432, arg_433) } else { tmp7 = linked_430.(*A_arbace_reflect_parse_flags_A).Invoke_O_O_O__O(root_429, arg_432, arg_433) }; return /*line :164:1*/ A_arbace_reflect_Field_A_New_O_O_O_O(tmp2, tmp4, tmp6, tmp7) }







func A_arbace_reflect_declared_fields_A_New() *A_arbace_reflect_declared_fields_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_fields_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_reflect_declared_fields_A) Ctor() {}
//line :172:1
func (t *A_arbace_reflect_declared_fields_A) Invoke_O_O__O(self, cls__0 any) any {


	var root_439 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var root_434 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = A_arbace_reflect_A_const_70.GetRawRoot__O(); var arg_438 any = jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredFields__Field1().Ref(); if linked_435 == nil { arg_442 = ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { arg_442 = linked_435.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) }; if linked_440 == nil { return ifn_441.Invoke_O__O(arg_442) } else { return linked_440.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_439, arg_442)
	}
}

func A_arbace_reflect_typeref__GT_class_A_New() *A_arbace_reflect_typeref__GT_class_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typeref__GT_class_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_reflect_typeref__GT_class_A) Ctor() {}
//line :179:1
func (t *A_arbace_reflect_typeref__GT_class_A) Invoke_O_O_O__O(self, typeref__0, classloader__1 any) any {

	var tmp1 any; var root_443 any = A_arbace_reflect_A_const_37.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = typeref__0; if linked_444 == nil { tmp1 = ifn_445.Invoke_O__O(arg_446) } else { tmp1 = linked_444.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_443, arg_446) }; if jrt.J2g_Truth(tmp1) { return typeref__0 } else {

		var tmp2 any; var target_447 any = typeref__0; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_447); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_447) }; tmp3 = tmp4; if tmp3 { tmp2 = A_arbace_reflect_TypeReference_A_Cast(target_447).Typename__O() } else { tmp2 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_447) }; return lang.RT_ClassForName_String_Z_ClassLoader__Class_NoInit(jrt.String_Cast(tmp2), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_Cast(classloader__1)).Ref()
	} }
func A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_New() *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Ctor() {}
//line :185:1
func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Invoke_O_O__O(self, classloader__1 any) any { return A_arbace_reflect_JavaReflector_A_New_O(classloader__1) }












func A_arbace_reflect_eval1938000121_fn__1938000122_A_New() *A_arbace_reflect_eval1938000121_fn__1938000122_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Ctor() {}
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1938000114__2_ any; var tmp1 any = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_New(); var tmp2 *jrt.Class; var fncls__449 *jrt.Class = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class; if fncls__449 == nil { var fncls__449d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class = fncls__449d; tmp2 = fncls__449d } else { tmp2 = fncls__449 }; G__1938000114__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_New_O(G__1938000114__2_); var tmp4 *jrt.Class; var fncls__457 *jrt.Class = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class = fncls__457d; tmp4 = fncls__457d } else { tmp4 = fncls__457 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :198:1
func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_New_O(p0 any) *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Ctor_O(c__G__1938000114 any) { t.F_G__1938000114 = c__G__1938000114 }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Invoke_O_O_O__O(self, gf__this__1938000127__1, gf__name__1938000128__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__this__1938000127__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__this__1938000127__1, gf__name__1938000128__2) } else { var tmp1 any; var root_450 any = A_arbace_reflect_A_const_9.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = self; var arg_454 any = gf__this__1938000127__1; var arg_455 any = A_arbace_reflect_A_const_71; var arg_456 any = t.F_G__1938000114; if linked_451 == nil { tmp1 = ifn_452.Invoke_O_O_O_O__O(arg_453, arg_454, arg_455, arg_456) } else { tmp1 = linked_451.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_450, arg_453, arg_454, arg_455, arg_456) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__this__1938000127__1, gf__name__1938000128__2) } }
//line :198:1
func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_New() *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Ctor() {}
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Invoke_O_O_O__O(self, gf__this__1938000123__1, gf__name__1938000124__2 any) any { var target_448 any = gf__this__1938000123__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_448 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_448) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_448, Lit_7, jrt.RefArrayOf(jrt.Object_class, gf__name__1938000124__2)) } else { return A_arbace_reflect_ClassResolver_A_Cast(target_448).Resolve_class_O__O(gf__name__1938000124__2) } }



func A_arbace_reflect_eval1938000137_fn__1938000138_A_New() *A_arbace_reflect_eval1938000137_fn__1938000138_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000137_fn__1938000138_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Ctor() {}
//line :202:1
func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Invoke_O_O_O__O(self, this__1, typeref__2 any) any {

	return lang.IFn_Cast(this__1).Invoke_O__O(typeref__2) }
//line :202:1
func A_arbace_reflect_eval1938000141_fn__1938000142_A_New() *A_arbace_reflect_eval1938000141_fn__1938000142_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000141_fn__1938000142_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Ctor() {}
//line :202:1
func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Invoke_O_O_O__O(self, this__1, typeref__2 any) any {





	var tmp1 *jrt.Class = A_arbace_reflect_A_const_72; var tmp2 any; var root_458 any = A_arbace_reflect_A_const_73.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, A_arbace_reflect_resource_name_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = typeref__2; if linked_459 == nil { tmp2 = ifn_460.Invoke_O__O(arg_461) } else { tmp2 = linked_459.(*A_arbace_reflect_resource_name_A).Invoke_O_O__O(root_458, arg_461) }; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(this__1, tmp1, Lit_8, jrt.RefArrayOf(jrt.Object_class, tmp2))
}



func A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_New() *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Ctor() {}
//line :213:1
func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Invoke_O_O__O(self, class_resolver__1 any) any { return A_arbace_reflect_AsmReflector_A_New_O(class_resolver__1) }


























































type A_arbace_reflect_A struct{ jrt.Object }

var A_arbace_reflect_A_const_pool *jrt.RefArray

var A_arbace_reflect_A_const_0 *lang.Var

var A_arbace_reflect_A_const_1 any

var A_arbace_reflect_A_const_2 *lang.Var

var A_arbace_reflect_A_const_3 any

var A_arbace_reflect_A_const_4 *lang.Var

var A_arbace_reflect_A_const_5 *lang.Var

var A_arbace_reflect_A_const_6 *lang.Var

var A_arbace_reflect_A_const_7 *lang.Var

var A_arbace_reflect_A_const_8 any

var A_arbace_reflect_A_const_9 *lang.Var

var A_arbace_reflect_A_const_10 *jrt.Class

var A_arbace_reflect_A_const_11 *jrt.Class

var A_arbace_reflect_A_const_12 *lang.Var

var A_arbace_reflect_A_const_13 *lang.Keyword

var A_arbace_reflect_A_const_14 *lang.Var

var A_arbace_reflect_A_const_15 *lang.Var

var A_arbace_reflect_A_const_16 *lang.Var

var A_arbace_reflect_A_const_17 *lang.Var

var A_arbace_reflect_A_const_18 *lang.Var

var A_arbace_reflect_A_const_19 *lang.Var

var A_arbace_reflect_A_const_20 *lang.Var

var A_arbace_reflect_A_const_21 *lang.Keyword

var A_arbace_reflect_A_const_22 *lang.Var

var A_arbace_reflect_A_const_23 *lang.Var

var A_arbace_reflect_A_const_24 *lang.Var

var A_arbace_reflect_A_const_25 *lang.Var

var A_arbace_reflect_A_const_26 *lang.Var

var A_arbace_reflect_A_const_27 *lang.Var

var A_arbace_reflect_A_const_28 *lang.Var

var A_arbace_reflect_A_const_29 *lang.Var

var A_arbace_reflect_A_const_30 *lang.Keyword

var A_arbace_reflect_A_const_31 *lang.Var

var A_arbace_reflect_A_const_32 *lang.Var

var A_arbace_reflect_A_const_33 *lang.Var

var A_arbace_reflect_A_const_34 *lang.Var

var A_arbace_reflect_A_const_35 any

var A_arbace_reflect_A_const_36 *lang.Var

var A_arbace_reflect_A_const_37 *lang.Var

var A_arbace_reflect_A_const_38 *lang.Var

var A_arbace_reflect_A_const_39 *lang.Var

var A_arbace_reflect_A_const_40 *lang.Var

var A_arbace_reflect_A_const_41 *lang.Var

var A_arbace_reflect_A_const_42 *lang.Var

var A_arbace_reflect_A_const_43 *lang.Var

var A_arbace_reflect_A_const_44 any

var A_arbace_reflect_A_const_45 *lang.Var

var A_arbace_reflect_A_const_46 *lang.Keyword

var A_arbace_reflect_A_const_47 *lang.Keyword

var A_arbace_reflect_A_const_48 *lang.Keyword

var A_arbace_reflect_A_const_49 *lang.Var

var A_arbace_reflect_A_const_50 any

var A_arbace_reflect_A_const_51 *lang.Var

var A_arbace_reflect_A_const_52 any

var A_arbace_reflect_A_const_53 any

var A_arbace_reflect_A_const_54 *lang.Var

var A_arbace_reflect_A_const_55 any

var A_arbace_reflect_A_const_56 *lang.Var

var A_arbace_reflect_A_const_57 *lang.Var

var A_arbace_reflect_A_const_58 any

var A_arbace_reflect_A_const_59 any

var A_arbace_reflect_A_const_60 *lang.Var

var A_arbace_reflect_A_const_61 *lang.Var

var A_arbace_reflect_A_const_62 *lang.Var

var A_arbace_reflect_A_const_63 *lang.Var

var A_arbace_reflect_A_const_64 *lang.Var

var A_arbace_reflect_A_const_65 *lang.Var

var A_arbace_reflect_A_const_66 *lang.Keyword

var A_arbace_reflect_A_const_67 *lang.Var

var A_arbace_reflect_A_const_68 *lang.Var

var A_arbace_reflect_A_const_69 *lang.Keyword

var A_arbace_reflect_A_const_70 *lang.Var

var A_arbace_reflect_A_const_71 *jrt.Class

var A_arbace_reflect_A_const_72 *jrt.Class

var A_arbace_reflect_A_const_73 *lang.Var

var A_arbace_reflect_A_init jrt.ClassInit

func A_arbace_reflect_A_Init() { if !A_arbace_reflect_A_init.Done() { A_arbace_reflect_A_init.Run(A_arbace_reflect_A_clinit) } }

func A_arbace_reflect_A_clinit() { A_arbace_reflect_A_clinit_p0(); A_arbace_reflect_A_clinit_p1(); A_arbace_reflect_A_clinit_p2(); A_arbace_reflect_A_clinit_p3(); A_arbace_reflect_A_clinit_p4(); A_arbace_reflect_A_clinit_p5(); A_arbace_reflect_A_clinit_p6() }

func A_arbace_reflect_A_clinit_p0() { jrt.StartCheck(); A_arbace_reflect_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 95); A_arbace_reflect_A_const_0 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[21]); A_arbace_reflect_A_const_1 = A_arbace_reflect_A_const_pool.A[22]; A_arbace_reflect_A_const_2 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[23]); A_arbace_reflect_A_const_3 = A_arbace_reflect_A_const_pool.A[24]; A_arbace_reflect_A_const_4 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[25]); A_arbace_reflect_A_const_5 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[26]); A_arbace_reflect_A_const_6 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[27]); A_arbace_reflect_A_const_7 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[28]); A_arbace_reflect_A_const_8 = A_arbace_reflect_A_const_pool.A[29]; A_arbace_reflect_A_const_9 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[30]); A_arbace_reflect_A_const_10 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[31]); A_arbace_reflect_A_const_11 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[32]) }

func A_arbace_reflect_A_clinit_p1() { A_arbace_reflect_A_const_12 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[33]); A_arbace_reflect_A_const_13 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[34]); A_arbace_reflect_A_const_14 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[35]); A_arbace_reflect_A_const_15 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[36]); A_arbace_reflect_A_const_16 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[37]); A_arbace_reflect_A_const_17 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[38]); A_arbace_reflect_A_const_18 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[39]); A_arbace_reflect_A_const_19 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[40]); A_arbace_reflect_A_const_20 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[41]); A_arbace_reflect_A_const_21 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[42]); A_arbace_reflect_A_const_22 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[43]); A_arbace_reflect_A_const_23 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[44]) }

func A_arbace_reflect_A_clinit_p2() { A_arbace_reflect_A_const_24 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[45]); A_arbace_reflect_A_const_25 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[46]); A_arbace_reflect_A_const_26 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[47]); A_arbace_reflect_A_const_27 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[48]); A_arbace_reflect_A_const_28 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[49]); A_arbace_reflect_A_const_29 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[50]); A_arbace_reflect_A_const_30 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[51]); A_arbace_reflect_A_const_31 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[52]); A_arbace_reflect_A_const_32 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[53]); A_arbace_reflect_A_const_33 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[54]); A_arbace_reflect_A_const_34 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[55]); A_arbace_reflect_A_const_35 = A_arbace_reflect_A_const_pool.A[56] }

func A_arbace_reflect_A_clinit_p3() { A_arbace_reflect_A_const_36 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[57]); A_arbace_reflect_A_const_37 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[58]); A_arbace_reflect_A_const_38 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[59]); A_arbace_reflect_A_const_39 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[60]); A_arbace_reflect_A_const_40 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[61]); A_arbace_reflect_A_const_41 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[62]); A_arbace_reflect_A_const_42 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[63]); A_arbace_reflect_A_const_43 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[64]); A_arbace_reflect_A_const_44 = A_arbace_reflect_A_const_pool.A[65]; A_arbace_reflect_A_const_45 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[66]); A_arbace_reflect_A_const_46 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[67]); A_arbace_reflect_A_const_47 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[68]) }

func A_arbace_reflect_A_clinit_p4() { A_arbace_reflect_A_const_48 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[69]); A_arbace_reflect_A_const_49 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[70]); A_arbace_reflect_A_const_50 = A_arbace_reflect_A_const_pool.A[71]; A_arbace_reflect_A_const_51 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[72]); A_arbace_reflect_A_const_52 = A_arbace_reflect_A_const_pool.A[73]; A_arbace_reflect_A_const_53 = A_arbace_reflect_A_const_pool.A[74]; A_arbace_reflect_A_const_54 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[75]); A_arbace_reflect_A_const_55 = A_arbace_reflect_A_const_pool.A[76]; A_arbace_reflect_A_const_56 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[77]); A_arbace_reflect_A_const_57 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[78]); A_arbace_reflect_A_const_58 = A_arbace_reflect_A_const_pool.A[79]; A_arbace_reflect_A_const_59 = A_arbace_reflect_A_const_pool.A[80]; A_arbace_reflect_A_const_60 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[81]) }

func A_arbace_reflect_A_clinit_p5() { A_arbace_reflect_A_const_61 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[82]); A_arbace_reflect_A_const_62 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[83]); A_arbace_reflect_A_const_63 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[84]); A_arbace_reflect_A_const_64 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[85]); A_arbace_reflect_A_const_65 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[86]); A_arbace_reflect_A_const_66 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[87]); A_arbace_reflect_A_const_67 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[88]); A_arbace_reflect_A_const_68 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[89]); A_arbace_reflect_A_const_69 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[90]); A_arbace_reflect_A_const_70 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[91]); A_arbace_reflect_A_const_71 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[92]); A_arbace_reflect_A_const_72 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[93]) }

func A_arbace_reflect_A_clinit_p6() { A_arbace_reflect_A_const_73 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[94]) }

func A_arbace_reflect_A_New() *A_arbace_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_A) Ctor() {}

func (t *A_arbace_reflect_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_A_class }

func (t *A_arbace_reflect_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_A); return ok }

func A_arbace_reflect_A_Cast(x any) *A_arbace_reflect_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_A_class)) }; return v }



type A_arbace_reflect_access_flag_A struct{ j2g_header uint64 }

var A_arbace_reflect_access_flag_A_fn_class *jrt.Class



type A_arbace_reflect_constructor__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_constructor__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_declared_constructors_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_constructors_A_fn_class *jrt.Class



type A_arbace_reflect_declared_fields_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_fields_A_fn_class *jrt.Class



type A_arbace_reflect_declared_methods_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_methods_A_fn_class *jrt.Class



type A_arbace_reflect_descriptor_class_name_A struct{ j2g_header uint64 }

var A_arbace_reflect_descriptor_class_name_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000010_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000010_A_New() *A_arbace_reflect_eval1938000010_A { t := &A_arbace_reflect_eval1938000010_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000010_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000010_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000010_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000010_A_class }

func (t *A_arbace_reflect_eval1938000010_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000010_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000010_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000010_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000010_A); return ok }

func A_arbace_reflect_eval1938000010_A_Cast(x any) *A_arbace_reflect_eval1938000010_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000010_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000010_A_class)) }; return v }



type A_arbace_reflect_eval1938000010_fn__1938000011_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000014_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000014_A_New() *A_arbace_reflect_eval1938000014_A { t := &A_arbace_reflect_eval1938000014_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000014_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000014_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000014_A_class }

func (t *A_arbace_reflect_eval1938000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000014_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000014_A); return ok }

func A_arbace_reflect_eval1938000014_A_Cast(x any) *A_arbace_reflect_eval1938000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000014_A_class)) }; return v }



type A_arbace_reflect_eval1938000014_fn__1938000015_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000036_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000036_A_New() *A_arbace_reflect_eval1938000036_A { t := &A_arbace_reflect_eval1938000036_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000036_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000036_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000036_A_class }

func (t *A_arbace_reflect_eval1938000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000036_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000036_A); return ok }

func A_arbace_reflect_eval1938000036_A_Cast(x any) *A_arbace_reflect_eval1938000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000036_A_class)) }; return v }



type A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000060_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000060_A_New() *A_arbace_reflect_eval1938000060_A { t := &A_arbace_reflect_eval1938000060_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000060_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000060_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000060_A_class }

func (t *A_arbace_reflect_eval1938000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000060_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000060_A); return ok }

func A_arbace_reflect_eval1938000060_A_Cast(x any) *A_arbace_reflect_eval1938000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000060_A_class)) }; return v }



type A_arbace_reflect_eval1938000060___GT_Method__1938000078_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000086_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000086_A_New() *A_arbace_reflect_eval1938000086_A { t := &A_arbace_reflect_eval1938000086_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000086_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000086_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000086_A_class }

func (t *A_arbace_reflect_eval1938000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000086_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000086_A); return ok }

func A_arbace_reflect_eval1938000086_A_Cast(x any) *A_arbace_reflect_eval1938000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000086_A_class)) }; return v }



type A_arbace_reflect_eval1938000086___GT_Field__1938000100_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000108_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000108_A_New() *A_arbace_reflect_eval1938000108_A { t := &A_arbace_reflect_eval1938000108_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000108_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000108_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000108_A_class }

func (t *A_arbace_reflect_eval1938000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000108_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000108_A); return ok }

func A_arbace_reflect_eval1938000108_A_Cast(x any) *A_arbace_reflect_eval1938000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000108_A_class)) }; return v }



type A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000121_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000121_A_New() *A_arbace_reflect_eval1938000121_A { t := &A_arbace_reflect_eval1938000121_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000121_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000121_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000121_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000121_A_class }

func (t *A_arbace_reflect_eval1938000121_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000121_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000121_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000121_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000121_A); return ok }

func A_arbace_reflect_eval1938000121_A_Cast(x any) *A_arbace_reflect_eval1938000121_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000121_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000121_A_class)) }; return v }



type A_arbace_reflect_eval1938000121_fn__1938000122_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A struct{ j2g_header uint64; F_G__1938000114 any }

var A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000137_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000137_A_New() *A_arbace_reflect_eval1938000137_A { t := &A_arbace_reflect_eval1938000137_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000137_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000137_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000137_A_class }

func (t *A_arbace_reflect_eval1938000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000137_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000137_A); return ok }

func A_arbace_reflect_eval1938000137_A_Cast(x any) *A_arbace_reflect_eval1938000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000137_A_class)) }; return v }



type A_arbace_reflect_eval1938000137_fn__1938000138_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000141_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000141_A_New() *A_arbace_reflect_eval1938000141_A { t := &A_arbace_reflect_eval1938000141_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000141_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000141_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000141_A_class }

func (t *A_arbace_reflect_eval1938000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000141_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000141_A); return ok }

func A_arbace_reflect_eval1938000141_A_Cast(x any) *A_arbace_reflect_eval1938000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000141_A_class)) }; return v }



type A_arbace_reflect_eval1938000141_fn__1938000142_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000145_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000145_A_New() *A_arbace_reflect_eval1938000145_A { t := &A_arbace_reflect_eval1938000145_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000145_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000145_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000145_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000145_A_class }

func (t *A_arbace_reflect_eval1938000145_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000145_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000145_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000145_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000145_A); return ok }

func A_arbace_reflect_eval1938000145_A_Cast(x any) *A_arbace_reflect_eval1938000145_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000145_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000145_A_class)) }; return v }



type A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000004_A struct{ jrt.Object }

func A_arbace_reflect_eval659000004_A_New() *A_arbace_reflect_eval659000004_A { t := &A_arbace_reflect_eval659000004_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000004_A) Ctor() {}

func (t *A_arbace_reflect_eval659000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000004_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000004_A_class }

func (t *A_arbace_reflect_eval659000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000004_A); return ok }

func A_arbace_reflect_eval659000004_A_Cast(x any) *A_arbace_reflect_eval659000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000004_A_class)) }; return v }



type A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000008_A struct{ jrt.Object }

func A_arbace_reflect_eval659000008_A_New() *A_arbace_reflect_eval659000008_A { t := &A_arbace_reflect_eval659000008_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000008_A) Ctor() {}

func (t *A_arbace_reflect_eval659000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000008_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000008_A_class }

func (t *A_arbace_reflect_eval659000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000008_A); return ok }

func A_arbace_reflect_eval659000008_A_Cast(x any) *A_arbace_reflect_eval659000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000008_A_class)) }; return v }



type A_arbace_reflect_eval659000008_fn__659000009_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000008_fn__659000009_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_A struct{ jrt.Object }

func A_arbace_reflect_eval659000020_A_New() *A_arbace_reflect_eval659000020_A { t := &A_arbace_reflect_eval659000020_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000020_A) Ctor() {}

func (t *A_arbace_reflect_eval659000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000020_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000020_A_class }

func (t *A_arbace_reflect_eval659000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000020_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000020_A); return ok }

func A_arbace_reflect_eval659000020_A_Cast(x any) *A_arbace_reflect_eval659000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000020_A_class)) }; return v }



type A_arbace_reflect_eval659000020_fn__659000021_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000020_fn__659000021_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A struct{ j2g_header uint64; F_G__659000013 any }

var A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_A struct{ jrt.Object }

func A_arbace_reflect_eval659000044_A_New() *A_arbace_reflect_eval659000044_A { t := &A_arbace_reflect_eval659000044_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000044_A) Ctor() {}

func (t *A_arbace_reflect_eval659000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000044_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000044_A_class }

func (t *A_arbace_reflect_eval659000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000044_A); return ok }

func A_arbace_reflect_eval659000044_A_Cast(x any) *A_arbace_reflect_eval659000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000044_A_class)) }; return v }



type A_arbace_reflect_eval659000044_fn__659000045_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000044_fn__659000045_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A struct{ j2g_header uint64; F_G__659000037 any }

var A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class *jrt.Class



type A_arbace_reflect_field__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_field__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_field_descriptor__GT_class_symbol_A struct{ j2g_header uint64 }

var A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class *jrt.Class



type A_arbace_reflect_internal_name__GT_class_symbol_A struct{ j2g_header uint64 }

var A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class *jrt.Class



type A_arbace_reflect_method__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_method__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_parse_flags_A struct{ j2g_header uint64 }

var A_arbace_reflect_parse_flags_A_fn_class *jrt.Class



type A_arbace_reflect_parse_flags_fn__1938000032_A struct{ j2g_header uint64; F_flags, F_context any }

var A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class *jrt.Class



type A_arbace_reflect_reflect_A struct{ j2g_header uint64 }

var A_arbace_reflect_reflect_A_fn_class *jrt.Class



type A_arbace_reflect_resource_name_A struct{ j2g_header uint64 }

var A_arbace_reflect_resource_name_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_A struct{ j2g_header uint64 }

var A_arbace_reflect_type_reflect_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_fn__659000063_A struct{ j2g_header uint64 }

var A_arbace_reflect_type_reflect_fn__659000063_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A struct{ j2g_header uint64; F_refl any }

var A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class *jrt.Class



type A_arbace_reflect_typeref__GT_class_A struct{ j2g_header uint64 }

var A_arbace_reflect_typeref__GT_class_A_fn_class *jrt.Class



type A_arbace_reflect_typesym_A struct{ j2g_header uint64 }

var A_arbace_reflect_typesym_A_fn_class *jrt.Class



type A_arbace_reflect_typesym_fn__1938000019_A struct{ j2g_header uint64; F_t any }

var A_arbace_reflect_typesym_fn__1938000019_A_fn_class *jrt.Class
