//line aot_arbace_reflect.ae:1
package aot_arbace_reflect

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_datafy"
	"arbace/aot_arbace_set"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :9:1
func A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_New() *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_reflect_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_reflect_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_reflect_eval659000008_fn__659000009_A_New() *A_arbace_reflect_eval659000008_fn__659000009_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000008_fn__659000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_reflect_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_reflect_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_reflect_A_const_7.GetRawRoot__O(), A_arbace_reflect_A_const_8) }










func A_arbace_reflect_eval1939000010_fn__1939000011_A_New() *A_arbace_reflect_eval1939000010_fn__1939000011_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000010_fn__1939000011_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_reflect_eval1939000010_fn__1939000011_A) Ctor() {}
//line :20:1
func (t *A_arbace_reflect_eval1939000010_fn__1939000011_A) Invoke_O_O__O(self, s__1 any) any {

	var root_159 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_165 any = A_arbace_reflect_A_const_40.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = s__1; if linked_166 == nil { arg_162 = ifn_167.Invoke_O__O(arg_168) } else { arg_162 = linked_166.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_165, arg_168) }; var arg_163 any = Lit_4; var arg_164 any = Lit_3; if linked_160 == nil { return ifn_161.Invoke_O_O_O__O(arg_162, arg_163, arg_164) } else { return linked_160.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_159, arg_162, arg_163, arg_164) } }
//line :20:1
func A_arbace_reflect_eval1939000014_fn__1939000015_A_New() *A_arbace_reflect_eval1939000014_fn__1939000015_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000014_fn__1939000015_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_reflect_eval1939000014_fn__1939000015_A) Ctor() {}
//line :20:1
func (t *A_arbace_reflect_eval1939000014_fn__1939000015_A) Invoke_O_O__O(self, c__1 any) any {








	if jrt.NN(jrt.Class_Cast(c__1)).IsArray__Z() {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3); var tmp2 any; var target_169 any = jrt.NN(jrt.Class_Cast(c__1)).GetComponentType__Class().Ref(); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_169); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_169) }; tmp3 = tmp4; if tmp3 { tmp2 = A_arbace_reflect_TypeReference_A_Cast(target_169).Typename__O() } else { tmp2 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_169) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() } else {
			return jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()
		} }
func A_arbace_reflect_typesym_A_New() *A_arbace_reflect_typesym_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typesym_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_reflect_typesym_A) Ctor() {}
//line :33:1
func (t *A_arbace_reflect_typesym_A) Invoke_O_O__O(self, t__0 any) any { var G__1939000018__2_ any; var root_170 any = A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_172 lang.IFn; if






	linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any; var root_174 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_176 lang.IFn; if /*line :39:1*/ linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any; var target_180 any = t__0; var tmp1 bool; var tmp2 bool; tmp2 = /*line :38:1*/A_arbace_reflect_TypeReference_A_InstanceOf(target_180); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_180) }; tmp1 = tmp2; if tmp1 { arg_177 = A_arbace_reflect_TypeReference_A_Cast(target_180).Typename__O() } else { arg_177 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_180) }; var arg_178 any = Lit_3; var arg_179 any = Lit_4; if
	linked_175 == nil { arg_173 = ifn_176.Invoke_O_O_O__O(arg_177, arg_178, arg_179) } else { arg_173 = linked_175.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_174, arg_177, arg_178, arg_179) }; if
	linked_171 == nil { G__1939000018__2_ = ifn_172.Invoke_O__O(arg_173) } else { G__1939000018__2_ = linked_171.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_170, arg_173) }; var tmp3 any; var root_181 any = /*line :37:1*/A_arbace_reflect_A_const_37.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_183 lang.IFn; if



	linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = t__0; if linked_182 == nil { tmp3 = ifn_183.Invoke_O__O(arg_184) } else { tmp3 = linked_182.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_181, arg_184) }; if /*line :37:1*/ jrt.J2g_Truth(tmp3) {



		var root_185 any = A_arbace_reflect_A_const_43.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = G__1939000018__2_; var arg_189 any; var tmp4 any = A_arbace_reflect_A_const_44; var tmp5 *lang.Compiler_AOTFn; var fnbody__195 any = A_arbace_reflect_typesym_fn__1939000019_A_New_O(t__0); var tmp6 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_reflect_typesym_fn__1939000019_A_fn_class
		if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__195); A_arbace_reflect_typesym_fn__1939000019_A_fn_class = fncls__194d; tmp6 = fncls__194d } else { tmp6 = fncls__194 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__195, tmp6, nil)
//line :41:1
		arg_189 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref())); if linked_186 == nil { return ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { return linked_186.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_185, arg_188, arg_189) } } else {
//line :37:1
			return G__1939000018__2_ } }




func A_arbace_reflect_typesym_fn__1939000019_A_New_O(p0 any) *A_arbace_reflect_typesym_fn__1939000019_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typesym_fn__1939000019_A{}; t.Ctor_O(p0); return t }
//line :42:1
func (t *A_arbace_reflect_typesym_fn__1939000019_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :42:1
func (t *A_arbace_reflect_typesym_fn__1939000019_A) Invoke_O_O__O(self, ___1 any) any { var root_190 any = A_arbace_reflect_A_const_45.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_datafy.A_arbace_datafy_datafy_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = t.F_t; if linked_191 == nil { return ifn_192.Invoke_O__O(arg_193) } else { return linked_191.(*aot_arbace_datafy.A_arbace_datafy_datafy_A).Invoke_O_O__O(root_190, arg_193) } }

func A_arbace_reflect_eval659000020_fn__659000021_A_New() *A_arbace_reflect_eval659000020_fn__659000021_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__659000013__2_ any; var fnbody__21 any = A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_New(); var tmp1 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class = fncls__20d; tmp1 = fncls__20d } else { tmp1 = fncls__20 }; G__659000013__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__21, tmp1, nil); var f__231000283__auto____3 any; var fnbody__30 any = A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_New_O(G__659000013__2_); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__30); A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :44:1
func A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_New_O(p0 any) *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A{}; t.Ctor_O(p0); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Ctor_O(c__G__659000013 any) { t.F_G__659000013 = c__G__659000013 }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Invoke_O_O_O__O(self, gf__reflector__659000026__1, gf__typeref__659000027__2 any) any { var cache__231000280__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__reflector__659000026__1)); if jrt.J2g_Truth(f__231000281__auto____4) { return lang.IFn_Cast(f__231000281__auto____4).Invoke_O_O__O(gf__reflector__659000026__1, gf__typeref__659000027__2) } else { var tmp1 any; var root_22 any = A_arbace_reflect_A_const_9.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = self; var arg_26 any = gf__reflector__659000026__1; var arg_27 any = A_arbace_reflect_A_const_10; var arg_28 any = t.F_G__659000013; if linked_23 == nil { tmp1 = ifn_24.Invoke_O_O_O_O__O(arg_25, arg_26, arg_27, arg_28) } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_22, arg_25, arg_26, arg_27, arg_28) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__reflector__659000026__1, gf__typeref__659000027__2) } }
//line :44:1
func A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_New() *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Invoke_O_O_O__O(self, gf__reflector__659000022__1, gf__typeref__659000023__2 any) any { var target_19 any = gf__reflector__659000022__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_19 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_19) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_19, Lit_11, jrt.RefArrayOf(jrt.Object_class, gf__typeref__659000023__2)) } else { return A_arbace_reflect_Reflector_A_Cast(target_19).Do_reflect_O__O(gf__typeref__659000023__2) } }
//line :44:1
func A_arbace_reflect_resource_name_A_New() *A_arbace_reflect_resource_name_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_resource_name_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_resource_name_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_resource_name_A) Invoke_O_O__O(self, typeref__0 any) any {





	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_18); var tmp2 any; var root_196 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_198 lang.IFn
//line :49:1
	if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var target_202 any = typeref__0; var tmp3 bool; var tmp4 bool
//line :48:1
	tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_202); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_202) }; tmp3 = tmp4; if tmp3 { arg_199 = A_arbace_reflect_TypeReference_A_Cast(target_202).Typename__O() } else { arg_199 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_202) }
	var arg_200 any = Lit_2; var arg_201 any = Lit_1; if linked_197 == nil { tmp2 = ifn_198.Invoke_O_O_O__O(arg_199, arg_200, arg_201) } else { tmp2 = linked_197.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_196, arg_199, arg_200, arg_201) }
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_A_New() *A_arbace_reflect_eval659000044_fn__659000045_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Ctor() {}
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__659000037__2_ any; var fnbody__33 any = A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_New(); var tmp1 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class = fncls__32d; tmp1 = fncls__32d } else { tmp1 = fncls__32 }; G__659000037__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__33, tmp1, nil); var f__231000283__auto____3 any; var fnbody__42 any = A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_New_O(G__659000037__2_); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__42); A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_New_O(p0 any) *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Ctor_O(c__G__659000037 any) { t.F_G__659000037 = c__G__659000037 }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Invoke_O_O__O(self, gf__o__659000049__1 any) any { var cache__231000280__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__o__659000049__1)); if jrt.J2g_Truth(f__231000281__auto____3) { return lang.IFn_Cast(f__231000281__auto____3).Invoke_O__O(gf__o__659000049__1) } else { var tmp1 any; var root_34 any = A_arbace_reflect_A_const_9.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = self; var arg_38 any = gf__o__659000049__1; var arg_39 any = A_arbace_reflect_A_const_11; var arg_40 any = t.F_G__659000037; if linked_35 == nil { tmp1 = ifn_36.Invoke_O_O_O_O__O(arg_37, arg_38, arg_39, arg_40) } else { tmp1 = linked_35.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_34, arg_37, arg_38, arg_39, arg_40) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gf__o__659000049__1) } }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_New() *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Ctor() {}
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Invoke_O_O__O(self, gf__o__659000046__1 any) any { var target_31 any = gf__o__659000046__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_31 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_31) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_31, Lit_14, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_reflect_TypeReference_A_Cast(target_31).Typename__O() } }



func A_arbace_reflect_access_flag_A_New() *A_arbace_reflect_access_flag_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_access_flag_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_reflect_access_flag_A) Ctor() {}
//line :52:1
func (t *A_arbace_reflect_access_flag_A) Invoke_O_O__O(self, p__1939000023__0 any) any { var vec__1939000024__2 any = p__1939000023__0; var seq__1939000025__3 any; var root_203 any = A_arbace_reflect_A_const_19.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = vec__1939000024__2; if linked_204 == nil { seq__1939000025__3 = ifn_205.Invoke_O__O(arg_206) } else { seq__1939000025__3 = linked_204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_203, arg_206) }; var first__1939000026__4 any; var root_207 any = A_arbace_reflect_A_const_20.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = seq__1939000025__3; if linked_208 == nil { first__1939000026__4 = ifn_209.Invoke_O__O(arg_210) } else { first__1939000026__4 = linked_208.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_207, arg_210) }; var seq__1939000025__5 any; var root_211 any = A_arbace_reflect_A_const_17.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = seq__1939000025__3; if linked_212 == nil { seq__1939000025__5 = ifn_213.Invoke_O__O(arg_214) } else { seq__1939000025__5 = linked_212.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_211, arg_214) }; var name__6 any = first__1939000026__4; var first__1939000026__7 any; var root_215 any = A_arbace_reflect_A_const_20.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = seq__1939000025__5; if linked_216 == nil { first__1939000026__7 = ifn_217.Invoke_O__O(arg_218) } else { first__1939000026__7 = linked_216.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_215, arg_218) }; var seq__1939000025__8 any; var root_219 any = A_arbace_reflect_A_const_17.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = seq__1939000025__5; if linked_220 == nil { seq__1939000025__8 = ifn_221.Invoke_O__O(arg_222) } else { seq__1939000025__8 = linked_220.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_219, arg_222) }; var flag__9 any = first__1939000026__7; var contexts__10 any = seq__1939000025__8; var tmp1 any = A_arbace_reflect_A_const_46; var tmp2 any = A_arbace_reflect_A_const_47; var tmp3 any = A_arbace_reflect_A_const_48; var tmp4 any; var root_223 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_225 lang.IFn; if

	linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any; var root_227 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = A_arbace_reflect_A_const_49.GetRawRoot__O(); var arg_231 any = contexts__10; if linked_228 == nil { arg_226 = ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { arg_226 = linked_228.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) }; if linked_224 == nil { tmp4 = ifn_225.Invoke_O__O(arg_226) } else { tmp4 = linked_224.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_223, arg_226) }; return /*line :52:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, name__6, tmp2, flag__9, tmp3, tmp4)) }



func A_arbace_reflect_descriptor_class_name_A_New() *A_arbace_reflect_descriptor_class_name_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_descriptor_class_name_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_reflect_descriptor_class_name_A) Ctor() {}
//line :56:1
func (t *A_arbace_reflect_descriptor_class_name_A) Invoke_O_O__O(self, d__0 any) any { var G__1939000028__2_ uint16 = jrt.NN(jrt.String_Cast(d__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)); switch


	lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1939000028__2_).Ref()) { case 76: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1939000028__2_).Ref(), A_arbace_reflect_A_const_50) {

		var root_233 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any; var root_239 any = A_arbace_reflect_A_const_51.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = d__0; var arg_243 any = A_arbace_reflect_A_const_52; var arg_244 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(d__0)))).Ref(); if linked_240 == nil { arg_236 = ifn_241.Invoke_O_O_O__O(arg_242, arg_243, arg_244) } else { arg_236 = linked_240.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_239, arg_242, arg_243, arg_244) }; var arg_237 any = Lit_1; var arg_238 any = Lit_2; if linked_234 == nil { return ifn_235.Invoke_O_O_O__O(arg_236, arg_237, arg_238) } else { return linked_234.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_233, arg_236, arg_237, arg_238) } }
//line :59:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1939000028__2_).Ref(), A_arbace_reflect_A_const_53) {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3); var tmp2 any; var root_245 any = A_arbace_reflect_A_const_54.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_reflect_descriptor_class_name_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var root_249 any = A_arbace_reflect_A_const_51.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = d__0; var arg_253 any = A_arbace_reflect_A_const_52; if linked_250 == nil { arg_248 = ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { arg_248 = linked_250.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_249, arg_252, arg_253) }; if linked_246 == nil { tmp2 = ifn_247.Invoke_O__O(arg_248) } else { tmp2 = linked_246.(*A_arbace_reflect_descriptor_class_name_A).Invoke_O_O__O(root_245, arg_248) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() }
//line :59:1
	default:}; return /*line :62:1*/ lang.IFn_Cast(A_arbace_reflect_A_const_55).Invoke_O__O(d__0) }
//line :58:1
func A_arbace_reflect_type_reflect_A_New() *A_arbace_reflect_type_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_reflect_type_reflect_A) Ctor() {}
//line :58:1
func (t *A_arbace_reflect_type_reflect_A) DoInvoke_O_O_O__O(self, typeref__0, options__1 any) any { { var map__659000059__3 any; var root_43 any = A_arbace_reflect_A_const_12.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_45 lang.IFn






































	if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var tmp1 any = A_arbace_reflect_A_const_13; var arg_46 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, A_arbace_reflect_A_const_14.GetRawRoot__O())); var arg_47 any; var root_48 any = A_arbace_reflect_A_const_15.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_50 lang.IFn
	if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = A_arbace_reflect_A_const_16.GetRawRoot__O(); var arg_52 any = options__1; if linked_49 == nil { arg_47 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { arg_47 = linked_49.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }
//line :97:1
	if linked_44 == nil { map__659000059__3 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { map__659000059__3 = linked_44.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }
//line :58:1
	var map__659000059__4 any





































	if lang.ISeq_InstanceOf(map__659000059__3) { var tmp2 any; var root_53 any = A_arbace_reflect_A_const_17.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = map__659000059__3; if linked_54 == nil { tmp2 = ifn_55.Invoke_O__O(arg_56) } else { tmp2 = linked_54.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_53, arg_56) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_57 any = A_arbace_reflect_A_const_18.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = map__659000059__3; if linked_58 == nil { tmp3 = ifn_59.Invoke_O__O(arg_60) } else { tmp3 = linked_58.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_57, arg_60) }; map__659000059__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_61 any = A_arbace_reflect_A_const_19.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = map__659000059__3; if linked_62 == nil { tmp4 = ifn_63.Invoke_O__O(arg_64) } else { tmp4 = linked_62.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_61, arg_64) }; if jrt.J2g_Truth(tmp4) { var root_65 any = A_arbace_reflect_A_const_20.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = map__659000059__3; if linked_66 == nil { map__659000059__4 = ifn_67.Invoke_O__O(arg_68) } else { map__659000059__4 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) } } else { map__659000059__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__659000059__4 = map__659000059__3 }
//line :58:1
	var ancestors__5 any = lang.RT_Get_O_O__O_NoInit(map__659000059__4, A_arbace_reflect_A_const_21); var reflector__6 any = lang.RT_Get_O_O__O_NoInit(map__659000059__4, A_arbace_reflect_A_const_13); var refl__7 any; var root_69 any = A_arbace_reflect_A_const_22.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_71 lang.IFn








































	if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = A_arbace_reflect_A_const_23.GetRawRoot__O(); var arg_73 any = reflector__6; if linked_70 == nil { refl__7 = ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { refl__7 = linked_70.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O__O(root_69, arg_72, arg_73) }
//line :58:1
	var result__8 any = lang.IFn_Cast(refl__7).Invoke_O__O(typeref__0)











































	if jrt.J2g_Truth(ancestors__5) { var make_ancestor_map__9 any; var fnbody__85 any = A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_New_O(refl__7); var tmp5 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class
		if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__85); A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class = fncls__84d; tmp5 = fncls__84d } else { tmp5 = fncls__84 }; make_ancestor_map__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp5, nil)
//line :102:1
		var reflections__10 any = lang.IFn_Cast(make_ancestor_map__9).Invoke_O__O(A_arbace_reflect_A_const_30.Invoke_O__O(result__8)); L1: for { var ancestors_visited__11 any; var root_86 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_88 lang.IFn



			if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_90 any = A_arbace_reflect_A_const_27.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = reflections__10; if linked_91 == nil { arg_89 = ifn_92.Invoke_O__O(arg_93) } else { arg_89 = linked_91.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_90, arg_93) }; if linked_87 == nil { ancestors_visited__11 = ifn_88.Invoke_O__O(arg_89) } else { ancestors_visited__11 = linked_87.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_86, arg_89) }
//line :102:1
			var ancestors_to_visit__12 any; var root_94 any = A_arbace_reflect_A_const_28.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_94, aot_arbace_set.A_arbace_set_difference_A_fn_class); var ifn_96 lang.IFn




			if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_99 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_29.GetRawRoot__O()); var tmp7 any = A_arbace_reflect_A_const_30; var tmp8 any; var root_108 any = A_arbace_reflect_A_const_31.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = reflections__10; if linked_109 == nil { tmp8 = ifn_110.Invoke_O__O(arg_111) } else { tmp8 = linked_109.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_108, arg_111) }; arg_102 = tmp6.Invoke_O_O__O(tmp7, tmp8); if linked_100 == nil { arg_97 = ifn_101.Invoke_O__O(arg_102) } else { arg_97 = linked_100.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_99, arg_102) }; var arg_98 any = ancestors_visited__11; if linked_95 == nil { ancestors_to_visit__12 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { ancestors_to_visit__12 = linked_95.(*aot_arbace_set.A_arbace_set_difference_A).Invoke_O_O_O__O(root_94, arg_97, arg_98)
			}
			var tmp9 any; var root_112 any = A_arbace_reflect_A_const_19.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = ancestors_to_visit__12; if linked_113 == nil { tmp9 = ifn_114.Invoke_O__O(arg_115) } else { tmp9 = linked_113.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(tmp9) {
				var tmp10 any; var root_140 any = A_arbace_reflect_A_const_12.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = reflections__10; var arg_144 any = lang.IFn_Cast(make_ancestor_map__9).Invoke_O__O(ancestors_to_visit__12); if linked_141 == nil { tmp10 = ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { tmp10 = linked_141.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }; reflections__10 = tmp10; continue L1 } else {
					var root_116 any = A_arbace_reflect_A_const_15.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = A_arbace_reflect_A_const_32.GetRawRoot__O(); var arg_120 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var arg_121 any = result__8; var arg_122 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect_A_const_21, ancestors_visited__11)); var arg_123 any; var root_124 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_126 lang.IFn
					if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var fnbody__135 any = A_arbace_reflect_type_reflect_fn__659000063_A_New(); var tmp11 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_reflect_type_reflect_fn__659000063_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_reflect_type_reflect_fn__659000063_A_fn_class = fncls__134d; tmp11 = fncls__134d } else { tmp11 = fncls__134 }; arg_127 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp11, nil); var arg_128 any; var root_136 any = A_arbace_reflect_A_const_31.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = reflections__10; if linked_137 == nil { arg_128 = ifn_138.Invoke_O__O(arg_139) } else { arg_128 = linked_137.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_136, arg_139) }; if linked_125 == nil { arg_123 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { arg_123 = linked_125.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }
//line :111:1
					if linked_117 == nil { return ifn_118.Invoke_O_O_O_O_O__O(arg_119, arg_120, arg_121, arg_122, arg_123) } else { return linked_117.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_116, arg_119, arg_120, arg_121, arg_122, arg_123) } } } } else {
//line :102:1
						return result__8 } }; /*line :58:1*/panic("j2g: unreachable") }






func A_arbace_reflect_field_descriptor__GT_class_symbol_A_New() *A_arbace_reflect_field_descriptor__GT_class_symbol_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_field_descriptor__GT_class_symbol_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Ctor() {}
//line :65:1
func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 any; var root_268 any = A_arbace_reflect_A_const_56.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_270 lang.IFn; if




	linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = d__0; if linked_269 == nil { tmp1 = ifn_270.Invoke_O__O(arg_271) } else { tmp1 = linked_269.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_268, arg_271) }; if /*line :65:1*/ jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_reflect_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_58))).Ref()))) }; var root_254 any =





	A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var root_258 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any; var root_264 any = A_arbace_reflect_A_const_54.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, A_arbace_reflect_descriptor_class_name_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = d__0; if linked_265 == nil { arg_261 = ifn_266.Invoke_O__O(arg_267) } else { arg_261 = linked_265.(*A_arbace_reflect_descriptor_class_name_A).Invoke_O_O__O(root_264, arg_267) }; var arg_262 any = Lit_3; var arg_263 any = Lit_4; if linked_259 == nil { arg_257 = ifn_260.Invoke_O_O_O__O(arg_261, arg_262, arg_263) } else { arg_257 = linked_259.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_258, arg_261, arg_262, arg_263) }; if linked_255 == nil { return ifn_256.Invoke_O__O(arg_257) } else { return linked_255.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_254, arg_257) } }

func A_arbace_reflect_internal_name__GT_class_symbol_A_New() *A_arbace_reflect_internal_name__GT_class_symbol_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_internal_name__GT_class_symbol_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Ctor() {}
//line :73:1
func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 any; var root_296 any = A_arbace_reflect_A_const_56.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_298 lang.IFn; if






	linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = d__0; if linked_297 == nil { tmp1 = ifn_298.Invoke_O__O(arg_299) } else { tmp1 = linked_297.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_296, arg_299) }; if /*line :73:1*/ jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_reflect_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_59))).Ref()))) }; var root_276 any =







	A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any; var root_280 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any; if jrt.NN(jrt.String_Cast(d__0)).StartsWith_String__Z(Lit_16) { var root_286 any = A_arbace_reflect_A_const_54.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, A_arbace_reflect_descriptor_class_name_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = d__0; if linked_287 == nil { arg_283 = ifn_288.Invoke_O__O(arg_289) } else { arg_283 = linked_287.(*A_arbace_reflect_descriptor_class_name_A).Invoke_O_O__O(root_286, arg_289) } } else { var root_290 any = A_arbace_reflect_A_const_39.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = d__0; var arg_294 any = Lit_1; var arg_295 any = Lit_2; if linked_291 == nil { arg_283 = ifn_292.Invoke_O_O_O__O(arg_293, arg_294, arg_295) } else { arg_283 = linked_291.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_290, arg_293, arg_294, arg_295) } }; var arg_284 any = Lit_3; var arg_285 any = Lit_4; if linked_281 == nil { arg_279 = ifn_282.Invoke_O_O_O__O(arg_283, arg_284, arg_285) } else { arg_279 = linked_281.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_280, arg_283, arg_284, arg_285) }; if linked_277 == nil { return ifn_278.Invoke_O__O(arg_279) } else { return linked_277.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_276, arg_279) } }





















func A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_New_O(p0 any) *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Ctor_O(c__refl any) { t.F_refl = c__refl }
//line :103:1
func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Invoke_O_O__O(self, names__1 any) any {
	var root_74 any = A_arbace_reflect_A_const_24.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = names__1; var arg_78 any; var root_79 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = t.F_refl; var arg_83 any = names__1; if linked_80 == nil { arg_78 = ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { arg_78 = linked_80.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) }; if linked_75 == nil { return ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { return linked_75.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_74, arg_77, arg_78)
	}
}



func A_arbace_reflect_parse_flags_A_New() *A_arbace_reflect_parse_flags_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_parse_flags_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_reflect_parse_flags_A) Ctor() {}
//line :110:1
func (t *A_arbace_reflect_parse_flags_A) Invoke_O_O_O__O(self, flags__0, context__1 any) any {


	var root_304 any = A_arbace_reflect_A_const_60.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any; var fnbody__325 any = A_arbace_reflect_parse_flags_fn__1939000032_A_New_O_O(flags__0, context__1); var tmp1 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_reflect_parse_flags_fn__1939000032_A_fn_class
	if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__325); A_arbace_reflect_parse_flags_fn__1939000032_A_fn_class = fncls__324d; tmp1 = fncls__324d } else { tmp1 = fncls__324 }; arg_307 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__325, tmp1, nil)
//line :113:1
	var arg_308 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_309 any = A_arbace_reflect_A_const_62.GetRawRoot__O(); if linked_305 == nil { return ifn_306.Invoke_O_O_O__O(arg_307, arg_308, arg_309) } else { return linked_305.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_304, arg_307, arg_308, arg_309) } }
//line :112:1
func A_arbace_reflect_type_reflect_fn__659000063_A_New() *A_arbace_reflect_type_reflect_fn__659000063_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_fn__659000063_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Ctor() {}
//line :112:1
func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Invoke_O_O__O(self, p1__659000058_SHARP___1 any) any { var root_129 any = A_arbace_reflect_A_const_34.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = p1__659000058_SHARP___1; var arg_133 any = A_arbace_reflect_A_const_35; if linked_130 == nil { return ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { return linked_130.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) } }

func A_arbace_reflect_parse_flags_fn__1939000032_A_New_O_O(p0, p1 any) *A_arbace_reflect_parse_flags_fn__1939000032_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_parse_flags_fn__1939000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_reflect_parse_flags_fn__1939000032_A) Ctor_O_O(c__flags, c__context any) { t.F_flags = c__flags; t.F_context = c__context }
//line :114:1
func (t *A_arbace_reflect_parse_flags_fn__1939000032_A) Invoke_O_O_O__O(self, result__1, fd__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_reflect_A_const_48.Invoke_O__O(fd__2), t.F_context); if jrt.J2g_Truth(and__1927000168__auto____3) {
		var root_310 any = A_arbace_reflect_A_const_61.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any; var tmp2 int64; var na_314 any = t.F_flags; var na_315 any = A_arbace_reflect_A_const_47.Invoke_O__O(fd__2); var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_314); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_315) }; tmp3 = tmp4; if tmp3 { var n0_316 int64 = jrt.NN(jrt.Long_Cast(na_314)).LongValue__J(); var n1_317 int64 = jrt.NN(jrt.Long_Cast(na_315)).LongValue__J(); tmp2 = n0_316 & n1_317 } else { tmp2 = lang.Numbers_And_O_O__J_NoInit(na_314, na_315) }; arg_313 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp2)).Ref(); if linked_311 == nil { tmp1 = ifn_312.Invoke_O__O(arg_313) } else { tmp1 = linked_311.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_310, arg_313) } } else {
//line :115:1
			tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {

				var root_319 any = A_arbace_reflect_A_const_7.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = result__1; var arg_323 any = A_arbace_reflect_A_const_46.Invoke_O__O(fd__2); if linked_320 == nil { return ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { return linked_320.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_319, arg_322, arg_323) } } else {
//line :115:1
					return result__1 } }
//line :115:1
func A_arbace_reflect_reflect_A_New() *A_arbace_reflect_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_reflect_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_reflect_reflect_A) Ctor() {}
//line :115:1
func (t *A_arbace_reflect_reflect_A) DoInvoke_O_O_O__O(self, obj__0, options__1 any) any {





	var root_145 any = A_arbace_reflect_A_const_15.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = A_arbace_reflect_A_const_36.GetRawRoot__O(); var arg_149 any; var tmp1 any; var root_151 any = A_arbace_reflect_A_const_37.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = obj__0; if linked_152 == nil { tmp1 = ifn_153.Invoke_O__O(arg_154) } else { tmp1 = linked_152.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(tmp1) { arg_149 = obj__0 } else { var root_155 any = A_arbace_reflect_A_const_38.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = obj__0; if linked_156 == nil { arg_149 = ifn_157.Invoke_O__O(arg_158) } else { arg_149 = linked_156.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_155, arg_158) } }; var arg_150 any = options__1; if linked_146 == nil { return ifn_147.Invoke_O_O_O__O(arg_148, arg_149, arg_150) } else { return linked_146.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_145, arg_148, arg_149, arg_150) } }
func A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A_New() *A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A) Ctor() {}
//line :122:1
func (t *A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A) Invoke_O_O_O_O_O_O__O(self, name__1, declaring_class__2, parameter_types__3, exception_types__4, flags__5 any) any { return A_arbace_reflect_Constructor_A_New_O_O_O_O_O(name__1, declaring_class__2, parameter_types__3, exception_types__4, flags__5) }
//line :122:1
func A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A_New() *A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A) Ctor() {}
//line :122:1
func (t *A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A) Invoke_O_O__O(self, m__231000218__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000218__auto____1) { tmp1 = m__231000218__auto____1 } else { var root_326 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_330 any = m__231000218__auto____1; if linked_327 == nil { tmp1 = ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { tmp1 = linked_327.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) } }; return A_arbace_reflect_Constructor_A_Create_IPersistentMap__A_arbace_reflect_Constructor_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_constructor__GT_map_A_New() *A_arbace_reflect_constructor__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_constructor__GT_map_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_reflect_constructor__GT_map_A) Ctor() {}
//line :125:1
func (t *A_arbace_reflect_constructor__GT_map_A) Invoke_O_O__O(self, constructor__0 any) any { var tmp1 any; var root_331 any = A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_333 lang.IFn; if


	linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = jrt.NN(jrt.Constructor_Cast(constructor__0)).GetName__String().Ref(); if linked_332 == nil { tmp1 = ifn_333.Invoke_O__O(arg_334) } else { tmp1 = linked_332.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_331, arg_334) }; var tmp2 any = tmp1; var tmp3 any; var root_335 any = /*line :125:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, A_arbace_reflect_typesym_A_fn_class); var ifn_337 lang.IFn; if



	linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = jrt.NN(jrt.Constructor_Cast(constructor__0)).GetDeclaringClass__Class().Ref(); if linked_336 == nil { tmp3 = ifn_337.Invoke_O__O(arg_338) } else { tmp3 = linked_336.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_335, arg_338) }; var tmp4 any = tmp3; var tmp5 any; var root_339 any = /*line :125:1*/A_arbace_reflect_A_const_64.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_341 lang.IFn; if




	linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any; var root_343 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = A_arbace_reflect_A_const_63.GetRawRoot__O(); var arg_347 any = jrt.NN(jrt.Constructor_Cast(constructor__0)).GetParameterTypes__Class1().Ref(); if linked_344 == nil { arg_342 = ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { arg_342 = linked_344.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_343, arg_346, arg_347) }; if linked_340 == nil { tmp5 = ifn_341.Invoke_O__O(arg_342) } else { tmp5 = linked_340.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_339, arg_342) }; var tmp6 any = tmp5; var tmp7 any; var root_348 any = /*line :125:1*/A_arbace_reflect_A_const_64.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_350 lang.IFn; if





	linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any; var root_352 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = A_arbace_reflect_A_const_63.GetRawRoot__O(); var arg_356 any = jrt.NN(jrt.Constructor_Cast(constructor__0)).GetExceptionTypes__Class1().Ref(); if linked_353 == nil { arg_351 = ifn_354.Invoke_O_O__O(arg_355, arg_356) } else { arg_351 = linked_353.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_352, arg_355, arg_356) }; if linked_349 == nil { tmp7 = ifn_350.Invoke_O__O(arg_351) } else { tmp7 = linked_349.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_348, arg_351) }; var tmp8 any = tmp7; var tmp9 any; var root_357 any = /*line :125:1*/A_arbace_reflect_A_const_65.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, A_arbace_reflect_parse_flags_A_fn_class); var ifn_359 lang.IFn; if






	linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(constructor__0)).GetModifiers__I()).Ref(); var arg_361 any = A_arbace_reflect_A_const_66; if linked_358 == nil { tmp9 = ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { tmp9 = linked_358.(*A_arbace_reflect_parse_flags_A).Invoke_O_O_O__O(root_357, arg_360, arg_361) }; return /*line :125:1*/ A_arbace_reflect_Constructor_A_New_O_O_O_O_O(tmp2, tmp4, tmp6, tmp8, tmp9) }








func A_arbace_reflect_declared_constructors_A_New() *A_arbace_reflect_declared_constructors_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_constructors_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_reflect_declared_constructors_A) Ctor() {}
//line :134:1
func (t *A_arbace_reflect_declared_constructors_A) Invoke_O_O__O(self, cls__0 any) any {


	var root_362 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var root_366 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_reflect_A_const_67.GetRawRoot__O(); var arg_370 any = jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredConstructors__Constructor1().Ref(); if linked_367 == nil { arg_365 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { arg_365 = linked_367.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) }; if linked_363 == nil { return ifn_364.Invoke_O__O(arg_365) } else { return linked_363.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_362, arg_365)
	}
}

func A_arbace_reflect_eval1939000060___GT_Method__1939000078_A_New() *A_arbace_reflect_eval1939000060___GT_Method__1939000078_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000060___GT_Method__1939000078_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_reflect_eval1939000060___GT_Method__1939000078_A) Ctor() {}
//line :141:1
func (t *A_arbace_reflect_eval1939000060___GT_Method__1939000078_A) Invoke_O_O_O_O_O_O_O__O(self, name__1, return_type__2, declaring_class__3, parameter_types__4, exception_types__5, flags__6 any) any { return A_arbace_reflect_Method_A_New_O_O_O_O_O_O(name__1, return_type__2, declaring_class__3, parameter_types__4, exception_types__5, flags__6) }
//line :141:1
func A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A_New() *A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A) Ctor() {}
//line :141:1
func (t *A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A) Invoke_O_O__O(self, m__231000218__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000218__auto____1) { tmp1 = m__231000218__auto____1 } else { var root_371 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_375 any = m__231000218__auto____1; if linked_372 == nil { tmp1 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { tmp1 = linked_372.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) } }; return A_arbace_reflect_Method_A_Create_IPersistentMap__A_arbace_reflect_Method_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_method__GT_map_A_New() *A_arbace_reflect_method__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_method__GT_map_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_reflect_method__GT_map_A) Ctor() {}
//line :144:1
func (t *A_arbace_reflect_method__GT_map_A) Invoke_O_O__O(self, method__0 any) any { var tmp1 any; var root_376 any = A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_378 lang.IFn; if


	linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = jrt.NN(jrt.Method_Cast(method__0)).GetName__String().Ref(); if linked_377 == nil { tmp1 = ifn_378.Invoke_O__O(arg_379) } else { tmp1 = linked_377.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_376, arg_379) }; var tmp2 any = tmp1; var tmp3 any; var root_380 any = /*line :144:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_reflect_typesym_A_fn_class); var ifn_382 lang.IFn; if



	linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = jrt.NN(jrt.Method_Cast(method__0)).GetReturnType__Class().Ref(); if linked_381 == nil { tmp3 = ifn_382.Invoke_O__O(arg_383) } else { tmp3 = linked_381.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_380, arg_383) }; var tmp4 any = tmp3; var tmp5 any; var root_384 any = /*line :144:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, A_arbace_reflect_typesym_A_fn_class); var ifn_386 lang.IFn; if




	linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = jrt.NN(jrt.Method_Cast(method__0)).GetDeclaringClass__Class().Ref(); if linked_385 == nil { tmp5 = ifn_386.Invoke_O__O(arg_387) } else { tmp5 = linked_385.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_384, arg_387) }; var tmp6 any = tmp5; var tmp7 any; var root_388 any = /*line :144:1*/A_arbace_reflect_A_const_64.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_390 lang.IFn; if





	linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any; var root_392 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_reflect_A_const_63.GetRawRoot__O(); var arg_396 any = jrt.NN(jrt.Method_Cast(method__0)).GetParameterTypes__Class1().Ref(); if linked_393 == nil { arg_391 = ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { arg_391 = linked_393.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) }; if linked_389 == nil { tmp7 = ifn_390.Invoke_O__O(arg_391) } else { tmp7 = linked_389.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_388, arg_391) }; var tmp8 any = tmp7; var tmp9 any; var root_397 any = /*line :144:1*/A_arbace_reflect_A_const_64.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_399 lang.IFn; if






	linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any; var root_401 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = A_arbace_reflect_A_const_63.GetRawRoot__O(); var arg_405 any = jrt.NN(jrt.Method_Cast(method__0)).GetExceptionTypes__Class1().Ref(); if linked_402 == nil { arg_400 = ifn_403.Invoke_O_O__O(arg_404, arg_405) } else { arg_400 = linked_402.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_401, arg_404, arg_405) }; if linked_398 == nil { tmp9 = ifn_399.Invoke_O__O(arg_400) } else { tmp9 = linked_398.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_397, arg_400) }; var tmp10 any = tmp9; var tmp11 any; var root_406 any = /*line :144:1*/A_arbace_reflect_A_const_65.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_reflect_parse_flags_A_fn_class); var ifn_408 lang.IFn; if







	linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(method__0)).GetModifiers__I()).Ref(); var arg_410 any = A_arbace_reflect_A_const_66; if linked_407 == nil { tmp11 = ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { tmp11 = linked_407.(*A_arbace_reflect_parse_flags_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) }; return /*line :144:1*/ A_arbace_reflect_Method_A_New_O_O_O_O_O_O(tmp2, tmp4, tmp6, tmp8, tmp10, tmp11) }









func A_arbace_reflect_declared_methods_A_New() *A_arbace_reflect_declared_methods_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_methods_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_reflect_declared_methods_A) Ctor() {}
//line :154:1
func (t *A_arbace_reflect_declared_methods_A) Invoke_O_O__O(self, cls__0 any) any {


	var root_411 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var root_415 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = A_arbace_reflect_A_const_68.GetRawRoot__O(); var arg_419 any = jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredMethods__Method1().Ref(); if linked_416 == nil { arg_414 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { arg_414 = linked_416.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }; if linked_412 == nil { return ifn_413.Invoke_O__O(arg_414) } else { return linked_412.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_411, arg_414)
	}
}

func A_arbace_reflect_eval1939000086___GT_Field__1939000100_A_New() *A_arbace_reflect_eval1939000086___GT_Field__1939000100_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000086___GT_Field__1939000100_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_reflect_eval1939000086___GT_Field__1939000100_A) Ctor() {}
//line :161:1
func (t *A_arbace_reflect_eval1939000086___GT_Field__1939000100_A) Invoke_O_O_O_O_O__O(self, name__1, type__2, declaring_class__3, flags__4 any) any { return A_arbace_reflect_Field_A_New_O_O_O_O(name__1, type__2, declaring_class__3, flags__4) }
//line :161:1
func A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A_New() *A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A) Ctor() {}
//line :161:1
func (t *A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A) Invoke_O_O__O(self, m__231000218__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000218__auto____1) { tmp1 = m__231000218__auto____1 } else { var root_420 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_424 any = m__231000218__auto____1; if linked_421 == nil { tmp1 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { tmp1 = linked_421.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) } }; return A_arbace_reflect_Field_A_Create_IPersistentMap__A_arbace_reflect_Field_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_field__GT_map_A_New() *A_arbace_reflect_field__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_field__GT_map_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_reflect_field__GT_map_A) Ctor() {}
//line :164:1
func (t *A_arbace_reflect_field__GT_map_A) Invoke_O_O__O(self, field__0 any) any { var tmp1 any; var root_425 any = A_arbace_reflect_A_const_42.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_427 lang.IFn; if


	linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = jrt.NN(jrt.Field_Cast(field__0)).GetName__String().Ref(); if linked_426 == nil { tmp1 = ifn_427.Invoke_O__O(arg_428) } else { tmp1 = linked_426.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_425, arg_428) }; var tmp2 any = tmp1; var tmp3 any; var root_429 any = /*line :164:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, A_arbace_reflect_typesym_A_fn_class); var ifn_431 lang.IFn; if



	linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = jrt.NN(jrt.Field_Cast(field__0)).GetType__Class().Ref(); if linked_430 == nil { tmp3 = ifn_431.Invoke_O__O(arg_432) } else { tmp3 = linked_430.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_429, arg_432) }; var tmp4 any = tmp3; var tmp5 any; var root_433 any = /*line :164:1*/A_arbace_reflect_A_const_63.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_reflect_typesym_A_fn_class); var ifn_435 lang.IFn; if




	linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = jrt.NN(jrt.Field_Cast(field__0)).GetDeclaringClass__Class().Ref(); if linked_434 == nil { tmp5 = ifn_435.Invoke_O__O(arg_436) } else { tmp5 = linked_434.(*A_arbace_reflect_typesym_A).Invoke_O_O__O(root_433, arg_436) }; var tmp6 any = tmp5; var tmp7 any; var root_437 any = /*line :164:1*/A_arbace_reflect_A_const_65.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_reflect_parse_flags_A_fn_class); var ifn_439 lang.IFn; if





	linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(field__0)).GetModifiers__I()).Ref(); var arg_441 any = A_arbace_reflect_A_const_69; if linked_438 == nil { tmp7 = ifn_439.Invoke_O_O__O(arg_440, arg_441) } else { tmp7 = linked_438.(*A_arbace_reflect_parse_flags_A).Invoke_O_O_O__O(root_437, arg_440, arg_441) }; return /*line :164:1*/ A_arbace_reflect_Field_A_New_O_O_O_O(tmp2, tmp4, tmp6, tmp7) }







func A_arbace_reflect_declared_fields_A_New() *A_arbace_reflect_declared_fields_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_fields_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_reflect_declared_fields_A) Ctor() {}
//line :172:1
func (t *A_arbace_reflect_declared_fields_A) Invoke_O_O__O(self, cls__0 any) any {


	var root_442 any = A_arbace_reflect_A_const_26.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any; var root_446 any = A_arbace_reflect_A_const_25.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = A_arbace_reflect_A_const_70.GetRawRoot__O(); var arg_450 any = jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredFields__Field1().Ref(); if linked_447 == nil { arg_445 = ifn_448.Invoke_O_O__O(arg_449, arg_450) } else { arg_445 = linked_447.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_446, arg_449, arg_450) }; if linked_443 == nil { return ifn_444.Invoke_O__O(arg_445) } else { return linked_443.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_442, arg_445)
	}
}

func A_arbace_reflect_typeref__GT_class_A_New() *A_arbace_reflect_typeref__GT_class_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typeref__GT_class_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_reflect_typeref__GT_class_A) Ctor() {}
//line :179:1
func (t *A_arbace_reflect_typeref__GT_class_A) Invoke_O_O_O__O(self, typeref__0, classloader__1 any) any {

	var tmp1 any; var root_451 any = A_arbace_reflect_A_const_37.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = typeref__0; if linked_452 == nil { tmp1 = ifn_453.Invoke_O__O(arg_454) } else { tmp1 = linked_452.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_451, arg_454) }; if jrt.J2g_Truth(tmp1) { return typeref__0 } else {

		var tmp2 any; var target_455 any = typeref__0; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_455); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_455) }; tmp3 = tmp4; if tmp3 { tmp2 = A_arbace_reflect_TypeReference_A_Cast(target_455).Typename__O() } else { tmp2 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_455) }; return lang.RT_ClassForName_String_Z_ClassLoader__Class_NoInit(jrt.String_Cast(tmp2), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_Cast(classloader__1)).Ref()
	} }
func A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A_New() *A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A) Ctor() {}
//line :185:1
func (t *A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A) Invoke_O_O__O(self, classloader__1 any) any { return A_arbace_reflect_JavaReflector_A_New_O(classloader__1) }












func A_arbace_reflect_eval1939000121_fn__1939000122_A_New() *A_arbace_reflect_eval1939000121_fn__1939000122_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000121_fn__1939000122_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_reflect_eval1939000121_fn__1939000122_A) Ctor() {}
//line :198:1
func (t *A_arbace_reflect_eval1939000121_fn__1939000122_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__1939000114__2_ any; var fnbody__458 any = A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A_New(); var tmp1 *jrt.Class; var fncls__457 *jrt.Class = A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A_fn_class = fncls__457d; tmp1 = fncls__457d } else { tmp1 = fncls__457 }; G__1939000114__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__458, tmp1, nil); var f__231000283__auto____3 any; var fnbody__467 any = A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A_New_O(G__1939000114__2_); var tmp2 *jrt.Class; var fncls__466 *jrt.Class = A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A_fn_class; if fncls__466 == nil { var fncls__466d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__467); A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A_fn_class = fncls__466d; tmp2 = fncls__466d } else { tmp2 = fncls__466 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__467, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :198:1
func A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A_New_O(p0 any) *A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A) Ctor_O(c__G__1939000114 any) { t.F_G__1939000114 = c__G__1939000114 }
//line :198:1
func (t *A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A) Invoke_O_O_O__O(self, gf__this__1939000127__1, gf__name__1939000128__2 any) any { var cache__231000280__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__this__1939000127__1)); if jrt.J2g_Truth(f__231000281__auto____4) { return lang.IFn_Cast(f__231000281__auto____4).Invoke_O_O__O(gf__this__1939000127__1, gf__name__1939000128__2) } else { var tmp1 any; var root_459 any = A_arbace_reflect_A_const_9.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = self; var arg_463 any = gf__this__1939000127__1; var arg_464 any = A_arbace_reflect_A_const_71; var arg_465 any = t.F_G__1939000114; if linked_460 == nil { tmp1 = ifn_461.Invoke_O_O_O_O__O(arg_462, arg_463, arg_464, arg_465) } else { tmp1 = linked_460.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_459, arg_462, arg_463, arg_464, arg_465) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__this__1939000127__1, gf__name__1939000128__2) } }
//line :198:1
func A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A_New() *A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A) Ctor() {}
//line :198:1
func (t *A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A) Invoke_O_O_O__O(self, gf__this__1939000123__1, gf__name__1939000124__2 any) any { var target_456 any = gf__this__1939000123__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_456 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_456) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_456, Lit_7, jrt.RefArrayOf(jrt.Object_class, gf__name__1939000124__2)) } else { return A_arbace_reflect_ClassResolver_A_Cast(target_456).Resolve_class_O__O(gf__name__1939000124__2) } }



func A_arbace_reflect_eval1939000137_fn__1939000138_A_New() *A_arbace_reflect_eval1939000137_fn__1939000138_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000137_fn__1939000138_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_reflect_eval1939000137_fn__1939000138_A) Ctor() {}
//line :202:1
func (t *A_arbace_reflect_eval1939000137_fn__1939000138_A) Invoke_O_O_O__O(self, this__1, typeref__2 any) any {

	return lang.IFn_Cast(this__1).Invoke_O__O(typeref__2) }
//line :202:1
func A_arbace_reflect_eval1939000141_fn__1939000142_A_New() *A_arbace_reflect_eval1939000141_fn__1939000142_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000141_fn__1939000142_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_reflect_eval1939000141_fn__1939000142_A) Ctor() {}
//line :202:1
func (t *A_arbace_reflect_eval1939000141_fn__1939000142_A) Invoke_O_O_O__O(self, this__1, typeref__2 any) any {





	var tmp1 *jrt.Class = A_arbace_reflect_A_const_72; var tmp2 any; var root_468 any = A_arbace_reflect_A_const_73.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, A_arbace_reflect_resource_name_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = typeref__2; if linked_469 == nil { tmp2 = ifn_470.Invoke_O__O(arg_471) } else { tmp2 = linked_469.(*A_arbace_reflect_resource_name_A).Invoke_O_O__O(root_468, arg_471) }; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(this__1, tmp1, Lit_8, jrt.RefArrayOf(jrt.Object_class, tmp2))
}



func A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A_New() *A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A) Ctor() {}
//line :213:1
func (t *A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A) Invoke_O_O__O(self, class_resolver__1 any) any { return A_arbace_reflect_AsmReflector_A_New_O(class_resolver__1) }


























































type A_arbace_reflect_A struct{ jrt.Object }

var A_arbace_reflect_A_const_pool *jrt.RefArray

var A_arbace_reflect_A_const_0 *lang.Var

var A_arbace_reflect_A_const_1 any

var A_arbace_reflect_A_const_2 *lang.Var

var A_arbace_reflect_A_const_3 any

var A_arbace_reflect_A_const_4 *lang.Var

var A_arbace_reflect_A_const_5 *lang.Var

var A_arbace_reflect_A_const_6 *lang.Var

var A_arbace_reflect_A_const_7 *lang.Var

var A_arbace_reflect_A_const_8 any

var A_arbace_reflect_A_const_9 *lang.Var

var A_arbace_reflect_A_const_10 *jrt.Class

var A_arbace_reflect_A_const_11 *jrt.Class

var A_arbace_reflect_A_const_12 *lang.Var

var A_arbace_reflect_A_const_13 *lang.Keyword

var A_arbace_reflect_A_const_14 *lang.Var

var A_arbace_reflect_A_const_15 *lang.Var

var A_arbace_reflect_A_const_16 *lang.Var

var A_arbace_reflect_A_const_17 *lang.Var

var A_arbace_reflect_A_const_18 *lang.Var

var A_arbace_reflect_A_const_19 *lang.Var

var A_arbace_reflect_A_const_20 *lang.Var

var A_arbace_reflect_A_const_21 *lang.Keyword

var A_arbace_reflect_A_const_22 *lang.Var

var A_arbace_reflect_A_const_23 *lang.Var

var A_arbace_reflect_A_const_24 *lang.Var

var A_arbace_reflect_A_const_25 *lang.Var

var A_arbace_reflect_A_const_26 *lang.Var

var A_arbace_reflect_A_const_27 *lang.Var

var A_arbace_reflect_A_const_28 *lang.Var

var A_arbace_reflect_A_const_29 *lang.Var

var A_arbace_reflect_A_const_30 *lang.Keyword

var A_arbace_reflect_A_const_31 *lang.Var

var A_arbace_reflect_A_const_32 *lang.Var

var A_arbace_reflect_A_const_33 *lang.Var

var A_arbace_reflect_A_const_34 *lang.Var

var A_arbace_reflect_A_const_35 any

var A_arbace_reflect_A_const_36 *lang.Var

var A_arbace_reflect_A_const_37 *lang.Var

var A_arbace_reflect_A_const_38 *lang.Var

var A_arbace_reflect_A_const_39 *lang.Var

var A_arbace_reflect_A_const_40 *lang.Var

var A_arbace_reflect_A_const_41 *lang.Var

var A_arbace_reflect_A_const_42 *lang.Var

var A_arbace_reflect_A_const_43 *lang.Var

var A_arbace_reflect_A_const_44 any

var A_arbace_reflect_A_const_45 *lang.Var

var A_arbace_reflect_A_const_46 *lang.Keyword

var A_arbace_reflect_A_const_47 *lang.Keyword

var A_arbace_reflect_A_const_48 *lang.Keyword

var A_arbace_reflect_A_const_49 *lang.Var

var A_arbace_reflect_A_const_50 any

var A_arbace_reflect_A_const_51 *lang.Var

var A_arbace_reflect_A_const_52 any

var A_arbace_reflect_A_const_53 any

var A_arbace_reflect_A_const_54 *lang.Var

var A_arbace_reflect_A_const_55 any

var A_arbace_reflect_A_const_56 *lang.Var

var A_arbace_reflect_A_const_57 *lang.Var

var A_arbace_reflect_A_const_58 any

var A_arbace_reflect_A_const_59 any

var A_arbace_reflect_A_const_60 *lang.Var

var A_arbace_reflect_A_const_61 *lang.Var

var A_arbace_reflect_A_const_62 *lang.Var

var A_arbace_reflect_A_const_63 *lang.Var

var A_arbace_reflect_A_const_64 *lang.Var

var A_arbace_reflect_A_const_65 *lang.Var

var A_arbace_reflect_A_const_66 *lang.Keyword

var A_arbace_reflect_A_const_67 *lang.Var

var A_arbace_reflect_A_const_68 *lang.Var

var A_arbace_reflect_A_const_69 *lang.Keyword

var A_arbace_reflect_A_const_70 *lang.Var

var A_arbace_reflect_A_const_71 *jrt.Class

var A_arbace_reflect_A_const_72 *jrt.Class

var A_arbace_reflect_A_const_73 *lang.Var

var A_arbace_reflect_A_init jrt.ClassInit

func A_arbace_reflect_A_Init() { if !A_arbace_reflect_A_init.Done() { A_arbace_reflect_A_init.Run(A_arbace_reflect_A_clinit) } }

func A_arbace_reflect_A_clinit() { A_arbace_reflect_A_clinit_p0(); A_arbace_reflect_A_clinit_p1(); A_arbace_reflect_A_clinit_p2(); A_arbace_reflect_A_clinit_p3(); A_arbace_reflect_A_clinit_p4(); A_arbace_reflect_A_clinit_p5(); A_arbace_reflect_A_clinit_p6() }

func A_arbace_reflect_A_clinit_p0() { jrt.StartCheck(); A_arbace_reflect_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 95); A_arbace_reflect_A_const_0 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[21]); A_arbace_reflect_A_const_1 = A_arbace_reflect_A_const_pool.A[22]; A_arbace_reflect_A_const_2 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[23]); A_arbace_reflect_A_const_3 = A_arbace_reflect_A_const_pool.A[24]; A_arbace_reflect_A_const_4 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[25]); A_arbace_reflect_A_const_5 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[26]); A_arbace_reflect_A_const_6 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[27]); A_arbace_reflect_A_const_7 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[28]); A_arbace_reflect_A_const_8 = A_arbace_reflect_A_const_pool.A[29]; A_arbace_reflect_A_const_9 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[30]); A_arbace_reflect_A_const_10 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[31]); A_arbace_reflect_A_const_11 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[32]) }

func A_arbace_reflect_A_clinit_p1() { A_arbace_reflect_A_const_12 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[33]); A_arbace_reflect_A_const_13 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[34]); A_arbace_reflect_A_const_14 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[35]); A_arbace_reflect_A_const_15 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[36]); A_arbace_reflect_A_const_16 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[37]); A_arbace_reflect_A_const_17 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[38]); A_arbace_reflect_A_const_18 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[39]); A_arbace_reflect_A_const_19 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[40]); A_arbace_reflect_A_const_20 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[41]); A_arbace_reflect_A_const_21 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[42]); A_arbace_reflect_A_const_22 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[43]); A_arbace_reflect_A_const_23 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[44]) }

func A_arbace_reflect_A_clinit_p2() { A_arbace_reflect_A_const_24 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[45]); A_arbace_reflect_A_const_25 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[46]); A_arbace_reflect_A_const_26 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[47]); A_arbace_reflect_A_const_27 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[48]); A_arbace_reflect_A_const_28 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[49]); A_arbace_reflect_A_const_29 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[50]); A_arbace_reflect_A_const_30 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[51]); A_arbace_reflect_A_const_31 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[52]); A_arbace_reflect_A_const_32 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[53]); A_arbace_reflect_A_const_33 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[54]); A_arbace_reflect_A_const_34 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[55]); A_arbace_reflect_A_const_35 = A_arbace_reflect_A_const_pool.A[56] }

func A_arbace_reflect_A_clinit_p3() { A_arbace_reflect_A_const_36 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[57]); A_arbace_reflect_A_const_37 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[58]); A_arbace_reflect_A_const_38 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[59]); A_arbace_reflect_A_const_39 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[60]); A_arbace_reflect_A_const_40 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[61]); A_arbace_reflect_A_const_41 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[62]); A_arbace_reflect_A_const_42 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[63]); A_arbace_reflect_A_const_43 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[64]); A_arbace_reflect_A_const_44 = A_arbace_reflect_A_const_pool.A[65]; A_arbace_reflect_A_const_45 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[66]); A_arbace_reflect_A_const_46 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[67]); A_arbace_reflect_A_const_47 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[68]) }

func A_arbace_reflect_A_clinit_p4() { A_arbace_reflect_A_const_48 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[69]); A_arbace_reflect_A_const_49 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[70]); A_arbace_reflect_A_const_50 = A_arbace_reflect_A_const_pool.A[71]; A_arbace_reflect_A_const_51 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[72]); A_arbace_reflect_A_const_52 = A_arbace_reflect_A_const_pool.A[73]; A_arbace_reflect_A_const_53 = A_arbace_reflect_A_const_pool.A[74]; A_arbace_reflect_A_const_54 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[75]); A_arbace_reflect_A_const_55 = A_arbace_reflect_A_const_pool.A[76]; A_arbace_reflect_A_const_56 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[77]); A_arbace_reflect_A_const_57 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[78]); A_arbace_reflect_A_const_58 = A_arbace_reflect_A_const_pool.A[79]; A_arbace_reflect_A_const_59 = A_arbace_reflect_A_const_pool.A[80]; A_arbace_reflect_A_const_60 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[81]) }

func A_arbace_reflect_A_clinit_p5() { A_arbace_reflect_A_const_61 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[82]); A_arbace_reflect_A_const_62 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[83]); A_arbace_reflect_A_const_63 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[84]); A_arbace_reflect_A_const_64 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[85]); A_arbace_reflect_A_const_65 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[86]); A_arbace_reflect_A_const_66 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[87]); A_arbace_reflect_A_const_67 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[88]); A_arbace_reflect_A_const_68 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[89]); A_arbace_reflect_A_const_69 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[90]); A_arbace_reflect_A_const_70 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[91]); A_arbace_reflect_A_const_71 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[92]); A_arbace_reflect_A_const_72 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[93]) }

func A_arbace_reflect_A_clinit_p6() { A_arbace_reflect_A_const_73 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[94]) }

func A_arbace_reflect_A_New() *A_arbace_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_A) Ctor() {}

func (t *A_arbace_reflect_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_A_class }

func (t *A_arbace_reflect_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_A); return ok }

func A_arbace_reflect_A_Cast(x any) *A_arbace_reflect_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_A_class)) }; return v }



type A_arbace_reflect_access_flag_A struct{ j2g_header uint64 }

var A_arbace_reflect_access_flag_A_fn_class *jrt.Class



type A_arbace_reflect_constructor__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_constructor__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_declared_constructors_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_constructors_A_fn_class *jrt.Class



type A_arbace_reflect_declared_fields_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_fields_A_fn_class *jrt.Class



type A_arbace_reflect_declared_methods_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_methods_A_fn_class *jrt.Class



type A_arbace_reflect_descriptor_class_name_A struct{ j2g_header uint64 }

var A_arbace_reflect_descriptor_class_name_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000010_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000010_A_New() *A_arbace_reflect_eval1939000010_A { t := &A_arbace_reflect_eval1939000010_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000010_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000010_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000010_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000010_A_class }

func (t *A_arbace_reflect_eval1939000010_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000010_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000010_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000010_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000010_A); return ok }

func A_arbace_reflect_eval1939000010_A_Cast(x any) *A_arbace_reflect_eval1939000010_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000010_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000010_A_class)) }; return v }



type A_arbace_reflect_eval1939000010_fn__1939000011_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000010_fn__1939000011_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000014_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000014_A_New() *A_arbace_reflect_eval1939000014_A { t := &A_arbace_reflect_eval1939000014_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000014_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000014_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000014_A_class }

func (t *A_arbace_reflect_eval1939000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000014_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000014_A); return ok }

func A_arbace_reflect_eval1939000014_A_Cast(x any) *A_arbace_reflect_eval1939000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000014_A_class)) }; return v }



type A_arbace_reflect_eval1939000014_fn__1939000015_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000014_fn__1939000015_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000036_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000036_A_New() *A_arbace_reflect_eval1939000036_A { t := &A_arbace_reflect_eval1939000036_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000036_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000036_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000036_A_class }

func (t *A_arbace_reflect_eval1939000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000036_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000036_A); return ok }

func A_arbace_reflect_eval1939000036_A_Cast(x any) *A_arbace_reflect_eval1939000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000036_A_class)) }; return v }



type A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000060_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000060_A_New() *A_arbace_reflect_eval1939000060_A { t := &A_arbace_reflect_eval1939000060_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000060_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000060_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000060_A_class }

func (t *A_arbace_reflect_eval1939000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000060_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000060_A); return ok }

func A_arbace_reflect_eval1939000060_A_Cast(x any) *A_arbace_reflect_eval1939000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000060_A_class)) }; return v }



type A_arbace_reflect_eval1939000060___GT_Method__1939000078_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000060___GT_Method__1939000078_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000086_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000086_A_New() *A_arbace_reflect_eval1939000086_A { t := &A_arbace_reflect_eval1939000086_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000086_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000086_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000086_A_class }

func (t *A_arbace_reflect_eval1939000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000086_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000086_A); return ok }

func A_arbace_reflect_eval1939000086_A_Cast(x any) *A_arbace_reflect_eval1939000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000086_A_class)) }; return v }



type A_arbace_reflect_eval1939000086___GT_Field__1939000100_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000086___GT_Field__1939000100_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000108_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000108_A_New() *A_arbace_reflect_eval1939000108_A { t := &A_arbace_reflect_eval1939000108_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000108_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000108_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000108_A_class }

func (t *A_arbace_reflect_eval1939000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000108_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000108_A); return ok }

func A_arbace_reflect_eval1939000108_A_Cast(x any) *A_arbace_reflect_eval1939000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000108_A_class)) }; return v }



type A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000121_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000121_A_New() *A_arbace_reflect_eval1939000121_A { t := &A_arbace_reflect_eval1939000121_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000121_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000121_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000121_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000121_A_class }

func (t *A_arbace_reflect_eval1939000121_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000121_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000121_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000121_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000121_A); return ok }

func A_arbace_reflect_eval1939000121_A_Cast(x any) *A_arbace_reflect_eval1939000121_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000121_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000121_A_class)) }; return v }



type A_arbace_reflect_eval1939000121_fn__1939000122_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000121_fn__1939000122_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A struct{ j2g_header uint64; F_G__1939000114 any }

var A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000113__1939000129_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000121_fn__1939000122_G__1939000114__1939000125_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000137_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000137_A_New() *A_arbace_reflect_eval1939000137_A { t := &A_arbace_reflect_eval1939000137_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000137_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000137_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000137_A_class }

func (t *A_arbace_reflect_eval1939000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000137_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000137_A); return ok }

func A_arbace_reflect_eval1939000137_A_Cast(x any) *A_arbace_reflect_eval1939000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000137_A_class)) }; return v }



type A_arbace_reflect_eval1939000137_fn__1939000138_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000137_fn__1939000138_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000141_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000141_A_New() *A_arbace_reflect_eval1939000141_A { t := &A_arbace_reflect_eval1939000141_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000141_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000141_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000141_A_class }

func (t *A_arbace_reflect_eval1939000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000141_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000141_A); return ok }

func A_arbace_reflect_eval1939000141_A_Cast(x any) *A_arbace_reflect_eval1939000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000141_A_class)) }; return v }



type A_arbace_reflect_eval1939000141_fn__1939000142_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000141_fn__1939000142_A_fn_class *jrt.Class



type A_arbace_reflect_eval1939000145_A struct{ jrt.Object }

func A_arbace_reflect_eval1939000145_A_New() *A_arbace_reflect_eval1939000145_A { t := &A_arbace_reflect_eval1939000145_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1939000145_A) Ctor() {}

func (t *A_arbace_reflect_eval1939000145_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1939000145_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1939000145_A_class }

func (t *A_arbace_reflect_eval1939000145_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1939000145_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1939000145_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1939000145_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1939000145_A); return ok }

func A_arbace_reflect_eval1939000145_A_Cast(x any) *A_arbace_reflect_eval1939000145_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1939000145_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1939000145_A_class)) }; return v }



type A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000004_A struct{ jrt.Object }

func A_arbace_reflect_eval659000004_A_New() *A_arbace_reflect_eval659000004_A { t := &A_arbace_reflect_eval659000004_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000004_A) Ctor() {}

func (t *A_arbace_reflect_eval659000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000004_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000004_A_class }

func (t *A_arbace_reflect_eval659000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000004_A); return ok }

func A_arbace_reflect_eval659000004_A_Cast(x any) *A_arbace_reflect_eval659000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000004_A_class)) }; return v }



type A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000008_A struct{ jrt.Object }

func A_arbace_reflect_eval659000008_A_New() *A_arbace_reflect_eval659000008_A { t := &A_arbace_reflect_eval659000008_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000008_A) Ctor() {}

func (t *A_arbace_reflect_eval659000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000008_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000008_A_class }

func (t *A_arbace_reflect_eval659000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000008_A); return ok }

func A_arbace_reflect_eval659000008_A_Cast(x any) *A_arbace_reflect_eval659000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000008_A_class)) }; return v }



type A_arbace_reflect_eval659000008_fn__659000009_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000008_fn__659000009_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_A struct{ jrt.Object }

func A_arbace_reflect_eval659000020_A_New() *A_arbace_reflect_eval659000020_A { t := &A_arbace_reflect_eval659000020_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000020_A) Ctor() {}

func (t *A_arbace_reflect_eval659000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000020_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000020_A_class }

func (t *A_arbace_reflect_eval659000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000020_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000020_A); return ok }

func A_arbace_reflect_eval659000020_A_Cast(x any) *A_arbace_reflect_eval659000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000020_A_class)) }; return v }



type A_arbace_reflect_eval659000020_fn__659000021_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000020_fn__659000021_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A struct{ j2g_header uint64; F_G__659000013 any }

var A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_A struct{ jrt.Object }

func A_arbace_reflect_eval659000044_A_New() *A_arbace_reflect_eval659000044_A { t := &A_arbace_reflect_eval659000044_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000044_A) Ctor() {}

func (t *A_arbace_reflect_eval659000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000044_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000044_A_class }

func (t *A_arbace_reflect_eval659000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000044_A); return ok }

func A_arbace_reflect_eval659000044_A_Cast(x any) *A_arbace_reflect_eval659000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000044_A_class)) }; return v }



type A_arbace_reflect_eval659000044_fn__659000045_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000044_fn__659000045_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A struct{ j2g_header uint64; F_G__659000037 any }

var A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class *jrt.Class



type A_arbace_reflect_field__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_field__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_field_descriptor__GT_class_symbol_A struct{ j2g_header uint64 }

var A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class *jrt.Class



type A_arbace_reflect_internal_name__GT_class_symbol_A struct{ j2g_header uint64 }

var A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class *jrt.Class



type A_arbace_reflect_method__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_method__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_parse_flags_A struct{ j2g_header uint64 }

var A_arbace_reflect_parse_flags_A_fn_class *jrt.Class



type A_arbace_reflect_parse_flags_fn__1939000032_A struct{ j2g_header uint64; F_flags, F_context any }

var A_arbace_reflect_parse_flags_fn__1939000032_A_fn_class *jrt.Class



type A_arbace_reflect_reflect_A struct{ j2g_header uint64 }

var A_arbace_reflect_reflect_A_fn_class *jrt.Class



type A_arbace_reflect_resource_name_A struct{ j2g_header uint64 }

var A_arbace_reflect_resource_name_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_A struct{ j2g_header uint64 }

var A_arbace_reflect_type_reflect_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_fn__659000063_A struct{ j2g_header uint64 }

var A_arbace_reflect_type_reflect_fn__659000063_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A struct{ j2g_header uint64; F_refl any }

var A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class *jrt.Class



type A_arbace_reflect_typeref__GT_class_A struct{ j2g_header uint64 }

var A_arbace_reflect_typeref__GT_class_A_fn_class *jrt.Class



type A_arbace_reflect_typesym_A struct{ j2g_header uint64 }

var A_arbace_reflect_typesym_A_fn_class *jrt.Class



type A_arbace_reflect_typesym_fn__1939000019_A struct{ j2g_header uint64; F_t any }

var A_arbace_reflect_typesym_fn__1939000019_A_fn_class *jrt.Class
